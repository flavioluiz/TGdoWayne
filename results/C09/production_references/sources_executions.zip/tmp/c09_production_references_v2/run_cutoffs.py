from pathlib import Path
import json,subprocess,hashlib,sys
H=Path(__file__).resolve().parent;R=H.parents[1]
targets=[f'd{d}_{m}' for d in (0,31) for m in ('A0_CN','B_CN_full_variable','B_G_full_variable')]
activation=dict(targets=targets,LL_cap=300000,CPU_cap=720,per_worker_wall_timeout=190,
 source_sha256=hashlib.sha256((R/'scripts/referencias_producao_c09.py').read_bytes()).hexdigest(),
 prior_failure_values_preserved=3,refined_values_already_charged=6800,automatic_retry=False)
(H/'cutoff_activation.json').write_text(json.dumps(activation,indent=2)+'\n')
for target in targets:
 assert not (H/target).exists()
 with (H/(target+'.log')).open('w') as log:
  result=subprocess.run([str(R/'.venv/bin/python'),str(R/'scripts/referencias_producao_c09.py'),
    '--target',target,'--output',str(H/target)],stdout=log,stderr=subprocess.STDOUT,timeout=190)
 print(target,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
receipts=[json.loads((H/t/'receipt.json').read_text()) for t in ['refined']+targets]
summary=dict(status='COMPLETED_WITH_GATES',results=sum(r['results'] for r in receipts),passed=sum(r['passed'] for r in receipts),
 charged=sum(r['budget']['additional_charged_values'] for r in receipts),prior_failure_charged=3,
 cumulative_C09=54787607+sum(r['budget']['additional_charged_values'] for r in receipts),CPU=sum(r['CPU'] for r in receipts),C09_complete=False)
(H/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
