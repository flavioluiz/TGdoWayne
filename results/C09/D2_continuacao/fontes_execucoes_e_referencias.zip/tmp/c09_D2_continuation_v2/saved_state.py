"""Read-only bridge from the published, audited D2 attempt to continuation.

The new plan must bind manifest.json and its sources before this class is used.
This bridge checks the old source closure and actual values; it never evaluates
a likelihood or treats an incomplete panel as a usable integral.
"""
import hashlib
import json
from pathlib import Path
import numpy as np
from reference_runtime import reference_identity

ROOT=Path(__file__).resolve().parents[2]


def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def read(path):return json.loads(path.read_text())


class SavedState:
    def __init__(self,manifest_path,*,expected_manifest_sha256,fine_grid):
        manifest_path=Path(manifest_path)
        if sha(manifest_path)!=expected_manifest_sha256:
            raise ValueError('published D2 manifest changed')
        manifest=read(manifest_path)
        self.hashes={r['path']:r['sha256'] for r in manifest['files']}
        for name,digest in self.hashes.items():
            path=(ROOT/name).resolve()
            if not path.is_relative_to(ROOT) or sha(path)!=digest:
                raise ValueError('published D2 member changed: '+name)
        self.runtime=ROOT/'tmp/c09_D2_runtime_resume_v1'
        self.run=ROOT/'tmp/c09_D2_execution_resume_v1/worker'
        old_plan=read(self.runtime/'preflight.json')
        for name,digest in old_plan['bindings'].items():
            if sha(ROOT/name)!=digest:raise ValueError('old physical source/input changed: '+name)
        self.config=read(self.runtime/'runtime_config.json')
        self.rows={r['curve_id']:r for r in self.config['curves']}
        self.priors={r['id']:r for r in self.config['priors']}
        self.nominal=read(ROOT/self.config['nominal_config'])
        self.old_source_binding=hashlib.sha256(json.dumps(old_plan['bindings'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
        self.values={};self.shifts={};self.identities={}
        self.extra_panels={}
        for name,row in self.rows.items():
            identity=read(self.run/'caches'/(name+'_identity.json'))
            if (identity['curve']!=row or identity['source_and_input_binding']!=self.old_source_binding
                or identity['data_sha256']!=old_plan['bindings'][self.config['data_file']]
                or identity['table_sha256']!=self.nominal['table_sha256']):
                raise ValueError('D2 cache model or input identity changed')
            with np.load(self.run/'caches'/(name+'.npz'),allow_pickle=False) as f:
                u,ell=f['u'],f['log_likelihood']
            if (u.dtype!=np.float64 or ell.dtype!=np.float64 or u.ndim!=1 or ell.shape!=u.shape
                or len(u)!=identity['stored_values'] or not np.isfinite(ell).all()
                or not np.isfinite(u).all() or not np.all(np.diff(u)>0)
                or u[0]<0 or u[-1]>1):raise ValueError('malformed saved D2 values')
            indices=np.searchsorted(u,fine_grid)
            if not np.array_equal(u[indices],fine_grid):raise ValueError('same fine grid required')
            self.shifts[name]=float(np.max(ell[indices]))
            self.values[name]=(u,ell);self.identities[name]=identity

    def overlay_failed_continuation(self,guard):
        previous=ROOT/'tmp/c09_D2_continuation_execution_v1/worker'
        previous_plan_path=ROOT/'tmp/c09_D2_continuation_v1/preflight.json'
        def checked(path):
            name=str(path.relative_to(ROOT))
            if sha(path)!=guard.plan['bindings'][name]:raise ValueError('unbound or changed continuation input')
            return read(path)
        prior_plan=checked(previous_plan_path)
        source_binding=hashlib.sha256(json.dumps(prior_plan['bindings'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
        for path,digest in prior_plan['bindings'].items():
            if sha(ROOT/path)!=digest:raise ValueError('first continuation source changed')
        for name,(old_u,old_l) in self.values.items():
            identity=checked(previous/'caches'/(name+'_identity.json'))
            cache_path=previous/'caches'/(name+'.npz')
            if sha(cache_path)!=guard.plan['bindings'][str(cache_path.relative_to(ROOT))]:
                raise ValueError('first continuation cache changed')
            scientific=lambda row:{k:v for k,v in row.items() if k!='additional_likelihood_cap'}
            if (scientific(identity['curve'])!=scientific(self.rows[name])
                or identity['source_and_input_binding']!=source_binding
                or identity['data_sha256']!=self.identities[name]['data_sha256']
                or identity['table_sha256']!=self.identities[name]['table_sha256']):
                raise ValueError('first continuation physical identity differs')
            with np.load(cache_path,allow_pickle=False) as f:u,ell=f['u'],f['log_likelihood']
            index=np.searchsorted(u,old_u)
            if (not np.array_equal(u[index],old_u) or ell[index].tobytes()!=old_l.tobytes()
                or len(u)!=identity['stored_values'] or len(old_u)!=identity['imported_values']
                or not np.isfinite(ell).all() or not np.all(np.diff(u)>0)):
                raise ValueError('first continuation lost or changed saved values')
            self.values[name]=(u,ell)
            self.hashes[str((self.run/'caches'/(name+'.npz')).relative_to(ROOT))]=sha(cache_path)
            self.hashes[str((self.run/'caches'/(name+'_identity.json')).relative_to(ROOT))]=sha(previous/'caches'/(name+'_identity.json'))
            paths=sorted((previous/'references'/name).glob('panel_*.json'))
            self.extra_panels[name]=[checked(p) for p in paths]
            if paths and checked(previous/'cuts'/(name+'.json'))!=read(self.run/'cuts'/(name+'.json')):
                raise ValueError('first continuation changed fixed cuts')
        self.old_source_binding=source_binding

    def restore_cache(self,cache,rows):
        if set(cache.values)!=set(self.rows) or any(cache.values.values()):
            raise ValueError('restore once into an empty cache with identical curve IDs')
        if {r['curve_id'] for r in rows}!=set(self.rows):raise ValueError('all original functions required')
        for row in rows:
            name=row['curve_id']
            # The new budget is distinct; every scientific field must match.
            scientific=lambda r:{k:v for k,v in r.items() if k!='additional_likelihood_cap'}
            if scientific(row)!=scientific(self.rows[name]):raise ValueError('changed physical curve')
        for name,(u,ell) in self.values.items():
            values={np.float64(0. if x==0 else x).tobytes().hex():float(y) for x,y in zip(u,ell)}
            cache.values[name].update(values);cache.imported[name]=len(values)
            cache.bridges[name]=dict(kind='PUBLISHED_D2_SAME_FUNCTION_FROZEN_VALUES',
                source_identity_sha256=self.hashes[str((self.run/'caches'/(name+'_identity.json')).relative_to(ROOT))],
                source_cache_sha256=self.hashes[str((self.run/'caches'/(name+'.npz')).relative_to(ROOT))],
                previous_source_binding=self.old_source_binding,
                source_closure_verified=True,charged_values_not_refunded=True)

    def reference(self,name,priors,cuts,shift):
        paths=sorted((self.run/'references'/name).glob('panel_*.json'))
        extra=self.extra_panels.get(name,[])
        if not paths and not extra:return None
        old=read(self.run/'cuts'/(name+'.json'))
        expected_ids=self.rows[name]['prior_ids']
        if [p['prior_id'] for p in old['priors']]!=expected_ids or len(priors)!=len(expected_ids):
            raise ValueError('prior order changed for reference reuse')
        if float(shift).hex()!=self.shifts[name].hex():raise ValueError('reference scaling changed')
        for spec,p,c,old_cut in zip((self.priors[i] for i in expected_ids),priors,cuts,old['priors']):
            if (p.kind!=spec['kind'] or p.lower!=spec['lower'] or p.upper!=spec['upper']
                or not np.array_equal(np.asarray(c,float),old_cut['cuts'])):
                raise ValueError('saved prior measure or functional cuts changed')
        return dict(context_sha256=reference_identity(priors,cuts,shift),
                    likelihood_identity_sha256=self.hashes[str((self.run/'caches'/(name+'_identity.json')).relative_to(ROOT))],
                    source_hashes_verified=True,panels=[read(p) for p in paths]+extra)
