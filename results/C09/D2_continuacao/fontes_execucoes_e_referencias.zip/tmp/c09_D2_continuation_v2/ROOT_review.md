# Correção de persistência e continuação com saldo

Plano acd3977e9e8528f7539b87306b71f907028c582b12ebcb56e961e8014f856b04.
Continuação autorizada pelo usuário, revisada por ROOT após falha identificada.

A tentativa anterior encerrou em 3,293173 s CPU e 1411 avaliações, ao serializar
um numpy.bool no campo moments de table_gates. O kernel e a quadratura concluíram
a primeira curva; seus 956 novos valores e o painel final foram preservados.
A falha original não foi reclassificada nem apagada.

Correção: flags normalization/moments convertidas explicitamente para bool Python.
O teste de runtime agora serializa o resultado completo com allow_nan=False e
confere os tipos das flags. Os seis testes de runtime passaram. A regressão real
recuperou os 14 painéis da primeira curva sem fornecer novas likelihoods; o JSON
foi gravado e os cinco controles primários dessa curva passaram operacionalmente.

SavedState incorpora o cache e painel salvos na primeira continuação, verifica
fontes/identidades/valores binários e mantém os cortes e a escala. O worker e a
receita física permanecem os mesmos, salvo a importação desses valores reais.

Teto adicional de 98589 valores =100000-1411. CPU adicional limitada a 476,7 s,
abaixo do saldo 480-3,293173 s; não se aumenta a reserva original. O histórico é
721505 avaliações e 668,812165 s CPU. Mantêm-se as reservas de encerramento e o
registro da reserva superior do D2 original. A nova execução repete e contabiliza
os 455 controles pontuais, aproveitando todos os caches e painéis anteriores.

Autorizada uma única execução no novo diretório, sem repetição automática.
As funções são auditadas individualmente; C09, W1, eventos e D3 permanecem abertos
até que suas próprias evidências e requisitos estejam concluídos.
