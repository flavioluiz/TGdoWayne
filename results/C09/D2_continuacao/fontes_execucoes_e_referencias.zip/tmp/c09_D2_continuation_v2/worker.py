"""Prospective D2 physical worker. Guard validates before numerical imports."""
from pathlib import Path
import argparse,hashlib,io,json,sys,traceback,warnings
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
from supervisor import WorkerGuard,read,sha,require


def main():
    p=argparse.ArgumentParser();p.add_argument('--request',required=True);p.add_argument('--request-sha256',required=True);a=p.parse_args()
    guard=WorkerGuard.from_request(a.request,a.request_sha256)
    sys.path[:0]=[str(HERE),str(ROOT/'tmp/c09_D2_components_v1'),str(ROOT/'src'),
        str(ROOT/'tmp/c09_nominal14_v2'),str(ROOT/'tmp/c09_nominal14_v4'),str(ROOT/'tmp/c09_event_repair_v1')]
    import numpy as np
    from inference.model import experiment
    from pta.statistics import quadratic_moments
    from kernels import FixedNuisanceCovariance
    from runtime_adapter import load_table
    from d1.grid import event_grid,exact_union
    from d1.measure import Prior
    from kernel_group import KernelGroup
    from cache import CacheSet
    from loader import checked_npz
    from saved_state import SavedState
    from backend_checks import check_new_functions
    from engine import analyze_curve
    from budget import LimitReached
    warnings.simplefilter('error')
    runtime=read(ROOT/guard.parameters['runtime_config']);rows=runtime['curves'];cache=None;reports=[];completed=False
    try:
        require(runtime['schema']=='C09_D2_PHYSICAL_RUNTIME_v1'and runtime['execution_enabled_by_default']is False,'disabled-default D2 runtime required')
        nominal=read(ROOT/runtime['nominal_config'])
        data=checked_npz(ROOT/runtime['data_file'],guard,{'q':(14,4,12),'x_physical':(14,4,10),'x_gaussian':(14,4,10),'truth_u':(14,),'target':(14,)})
        require(np.array_equal(data['target'],np.arange(14))and np.array_equal(data['truth_u'],[r['fixed_truth_u']for r in nominal['rows']]),'fixed nominal14 observation identity differs')
        e=experiment(read(ROOT/nominal['experiment_config']))
        require(np.array_equal(e['weights'],np.full(4,.25)),'same frequency compression required')
        table=load_table(ROOT/nominal['table_file'],nominal['table_sha256'],guard,expected_shape=(8336,4,12,12))
        anchor=table(np.array([.5]))[0];group_rows={}
        for row in rows:group_rows.setdefault((tuple(row['eta_physical_coordinates']),row['analysis_contaminant_ratio']),[]).append(row)
        groups=[];curve_to_group={}
        for (eta,rho),members in group_rows.items():
            covariance=FixedNuisanceCovariance(e,eta,contaminant_ratio=rho)
            group=KernelGroup(members,{k:data[k]for k in('q','x_physical','x_gaussian')},covariance=covariance,
                             moments=lambda C:quadratic_moments(C,e['H']),weights=e['weights'],anchor_gamma=anchor,budget=guard.budget)
            for row in members:curve_to_group[row['curve_id']]=len(groups)
            groups.append(group)
        def provider(u,ids,reason):
            guard.checkpoint();gamma=table(u);out={};selected={}
            for name in ids:selected.setdefault(curve_to_group[name],[]).append(name)
            for index,names in selected.items():out.update(groups[index].evaluate_gamma(gamma,names,reason=reason))
            return out
        cache=CacheSet([r['curve_id']for r in rows],provider=provider,batch=32,checkpoint=guard.checkpoint)
        source_binding=hashlib.sha256(json.dumps(guard.plan['bindings'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
        grid=event_grid(table.nodes,Prior('uniform_u'),validation_count=1)
        edges=np.array([0.,1e-4,1e-3,.01,.8,1.]);coarse=exact_union(grid['coarse_u'],edges);fine=exact_union(grid['fine_u'],edges)
        require(rows==guard.plan['curves'],'runtime and budget curve identities differ')
        saved=SavedState(ROOT/runtime['previous_manifest'],
            expected_manifest_sha256=guard.plan['bindings'][runtime['previous_manifest']],fine_grid=fine)
        saved.overlay_failed_continuation(guard)
        require(sha(HERE/'kernel_group.py')==sha(ROOT/'tmp/c09_D2_runtime_resume_v1/kernel_group.py'),
                'same physical kernel required for cache continuation')
        saved.restore_cache(cache,rows)
        oracle=checked_npz(ROOT/runtime['harmonic_file'],guard,{'u':(16,),'Gamma':(16,4,12,12),'errors_nodes':(16,4),'errors_ell':(16,4)})
        require(np.array_equal(oracle['u'],nominal['sparse_exact_mass_nodes']),'saved harmonic mass controls differ')
        require(max(np.max(oracle['errors_nodes']),np.max(oracle['errors_ell']))<=1e-8,'saved harmonic refinement no longer satisfies gates')
        for g in oracle['Gamma']:
            require(np.max(abs(g-g.swapaxes(-1,-2).conj()))<=1e-12 and np.linalg.eigvalsh(g).min()>=-1e-12,'saved harmonic Hermiticity/PSD differs')
        evidence=check_new_functions(groups,curve_to_group,table,oracle,rows,e['H'],anchor,guard,source_binding=source_binding)
        if not all(r['new_curve_checks_passed']for r in evidence.values()):raise ArithmeticError('new-curve finite backend gate failed; no integral started')
        # Batched fill lets the newly introduced functions share covariance and
        # factorizations. Historical hits are not recalculated or charged twice.
        cache.evaluate(fine,[r['curve_id']for r in rows],reason='grid')
        by_prior={p['id']:p for p in runtime['priors']}
        for row in rows:
            name=row['curve_id'];guard.checkpoint()
            try:
                result=analyze_curve(row,[by_prior[k]for k in row['prior_ids']],coarse,fine,cache,
                    freeze_cuts=lambda value,n=name:guard.write_json('cuts/'+n+'.json',value),
                    save_reference_panel=lambda value,n=name:guard.write_json('references/'+n+'/panel_'+str(value['panel_index']).zfill(4)+'.json',value),
                    finite_backend_evidence=evidence[name],compute_table_W1=False,
                    resume_reference=lambda priors,cuts,shift,n=name:saved.reference(n,priors,cuts,shift))
                status='FUNCTIONALS_RECORDED_W1_EVENT_PENDING'
            except LimitReached as exc:
                result=dict(schema='C09_D2_FUNCTIONAL_FAILURE_v1',curve_id=name,data_id=row['data_id'],
                            status='UNRESOLVED_QUOTA_NO_RETRY',reason=str(exc),partial_reference_panels_preserved=True,
                            original_history_unchanged=True,C09_complete=False)
                status=result['status']
            guard.write_json('results/'+name+'.json',result);reports.append(dict(curve_id=name,status=status))
            print(json.dumps(reports[-1]),flush=True)
        completed=True
    except BaseException as exc:
        try:guard.write_json('failure.json',dict(status='FAILED_NO_AUTOMATIC_RETRY',error=type(exc).__name__+': '+str(exc),
                   traceback=traceback.format_exc(),recorded_curves=reports,resources=guard.report(),C09_complete=False))
        except BaseException:pass
        raise
    finally:
        # Persistence after a compute guard failure is bounded by the separate
        # reserved payload/receipt allowance; no new likelihoods are attempted.
        failures=[]
        if cache is not None:
            for row in rows:
                name=row['curve_id']
                try:
                    ordered=sorted((float(np.frombuffer(bytes.fromhex(k),dtype=np.float64)[0]),v)for k,v in cache.values[name].items())
                    stream=io.BytesIO();np.savez_compressed(stream,u=np.array([v[0]for v in ordered]),log_likelihood=np.array([v[1]for v in ordered]))
                    guard.write_bytes('caches/'+name+'.npz',stream.getvalue())
                    guard.write_json('caches/'+name+'_identity.json',dict(curve=row,stored_values=len(ordered),
                        imported_values=cache.imported[name],new_stored_values=len(ordered)-cache.imported[name],
                        charged_values=guard.budget.by_curve[name],cache_hits=cache.hits[name],bridge=cache.bridges.get(name),
                        data_sha256=guard.plan['bindings'][runtime['data_file']],table_sha256=nominal['table_sha256'],
                        source_and_input_binding=source_binding,noncacheable_controls_counted_separately=True))
                except BaseException as exc:failures.append(dict(curve_id=name,error=type(exc).__name__+': '+str(exc)))
        guard.finish('COMPLETED'if completed and not failures else'FAILED',dict(recorded_curves=reports,persistence_failures=failures,C09_complete=False))

if __name__=='__main__':main()
