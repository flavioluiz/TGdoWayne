"""Paired numerical contrasts from completed D2 functional records."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'tmp/c09_D2_continuation_execution_v3/worker/results'


def main():
    records={p.stem:json.loads(p.read_text()) for p in RUN.glob('*.json')}
    assert len(records)==13 and all(r.get('schema')=='C09_D2_FUNCTIONAL_RESULT_v1' for r in records.values())
    def result(curve,prior='uniform_u_a0_b1'):
        return next(r for r in records[curve]['results'] if r['prior_id']==prior)
    contrasts=[]
    def contrast(label,left,right):
        qa=next(q for q in left['quantiles'] if q['probability']==.95)
        qb=next(q for q in right['quantiles'] if q['probability']==.95)
        passed=all(r['table_gates']['normalization'] for r in (left,right)) and qa['table_gate'] and qb['table_gate']
        interval=[qa['lower']-qb['upper'],qa['upper']-qb['lower']] if passed else [-1.,1.]
        decision='POSITIVE' if interval[0]>0 else 'NEGATIVE' if interval[1]<0 else 'UNRESOLVED_SIGN'
        contrasts.append(dict(label=label,delta_Q95_interval=interval,
            operational_numerical_sign=decision,validated_quantile_brackets=passed,
            population_effect_not_estimated=True))
    for data,names in [(7,dict(full_variable='new_d7_BG_full_variable',full_fixed='new_d7_BG_full_fixed',
                             diagonal_variable='baseline_d7',diagonal_fixed='new_d7_BG_diagonal_fixed')),
                       (6,dict(full_variable='baseline_d6',full_fixed='new_d6_BCN_full_fixed',
                             diagonal_variable='new_d6_BCN_diagonal_variable',diagonal_fixed='new_d6_BCN_diagonal_fixed'))]:
        for a,b in [('diagonal_variable','full_variable'),('diagonal_fixed','full_fixed'),
                    ('full_fixed','full_variable'),('diagonal_fixed','diagonal_variable')]:
            contrast(f'data{data}: {a} minus {b}',result(names[a]),result(names[b]))
    contrast('data13: monopole included minus omitted',result('new_d13_BCN_monopole_included'),result('baseline_d13'))
    contrast('data7: compression B_G minus A_G',result('new_d7_BG_full_variable'),result('new_d7_AG'))
    for data in (2,3,6):
        base=result('baseline_d'+str(data))
        for row in records['baseline_d'+str(data)]['results']:
            if row['prior_id']!='uniform_u_a0_b1':
                contrast(f'data{data}: {row["prior_id"]} minus uniform_u_a0_b1',row,base)
    out=dict(status='PAIRED_FINITE_DOMAIN_OPERATIONAL_ENGINEERING',contrasts=contrasts,
        scope='One fixed observation per listed data ID, known nuisances; intervals describe numerical uncertainty, not population confidence.',
        physical_uniform_probability_certificate=None,SBC_executed=False,C09_complete=False)
    dest=ROOT/'tmp/c09_D2_continuation_v3/paired_summary.json'
    dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
