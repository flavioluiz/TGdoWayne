# Revisão da continuação D2

Plano 687b5dc0a9cff3d82b2baa8d5e60fb0a217f5520ca95725d61d6d620064f2535.
Autoridade técnica ROOT, dentro da autorização do usuário para implementar o plano.

O turno anterior foi progresso: implementou e testou a reutilização de prefixos.
Agora o worker foi conectado a SavedState. O plano vincula fontes, manifesto,
caches, cortes e os dados originais. A identidade física é mantida; o kernel
tem igualdade de SHA com o anterior e a cadeia de fontes físicas é verificada.
Os controles pontuais são repetidos e contabilizados (455 valores), sem novos ORFs.

Os 248 painéis completos são reutilizados somente se medidas, cortes, escala e
prefixo coincidirem. Seus erros não são zerados. Os 13 caches foram conferidos
e a importação não devolve crédito ao histórico. O histórico auditado de 720094
valores e 665,518992 s CPU preserva separadamente o recibo de falha e a reserva
superior de 200000 da execução anterior.

Novo teto prospectivo: 100000 valores, 480 s CPU e 600 s de parede. A grade fina
já está integralmente salva. Oito funções têm referências restantes na cauda
u>0,95 aproximadamente e recebem 5000 valores adicionais cada; baseline_d2 recebe
15000, d3 20000, d6 19000, d7/d13 3000 cada. A alocação amplia a referência das
curvas com dez prioris e não repete a grade de 133408 avaliações do lote anterior.
O teto de CPU considera o custo observado de cerca de 41755 avaliações de
referência mais a grade no lote de 181 s, permitindo as novas referências com
reserva separada de encerramento. É um teto, não garantia de convergência.

Seis testes específicos (retomada/alocação) e os seis testes de runtime passaram,
incluindo execução e falha de subprocessos. A revisão do worker confirma a
persistência sem novas likelihoods no finally. A referência continua com a mesma
quadratura, tolerâncias e critério funcional; não foi relaxada para obter PASS.

Autorizada uma única execução no diretório indicado pelo recibo. Falhas e
inconclusivos serão preservados; não há repetição automática. W1, eventos de
logL e D3/SBC ainda não ficam concluídos por este lote. C09 permanece aberto.
