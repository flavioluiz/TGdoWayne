"""Separate compute, worker cleanup, controller and final receipt CPU allowances."""
import math


def allocate(total, controller_used, *, cleanup=10., controller_remaining=5., final_receipt=1.):
    values=(total,controller_used,cleanup,controller_remaining,final_receipt)
    if not all(type(x) in (int,float) and math.isfinite(x) for x in values):
        raise ValueError('finite CPU accounting required')
    if min(total,cleanup,controller_remaining,final_receipt)<=0 or controller_used<0:
        raise ValueError('positive reservations and nonnegative consumed CPU required')
    hard=math.floor(total-controller_used-controller_remaining-final_receipt)
    soft=math.floor(hard-cleanup)
    if soft<1 or hard<=soft:
        raise ValueError('no compute allowance after cleanup and controller reserves')
    return dict(worker_soft=soft,worker_hard=hard,
                controller_stop=controller_used+controller_remaining,
                worker_cleanup_reserved=hard-soft,final_receipt_reserved=final_receipt,
                total=total)
