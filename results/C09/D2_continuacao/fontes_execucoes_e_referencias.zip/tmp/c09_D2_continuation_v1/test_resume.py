"""Synthetic continuation tests; no PTA input, draws or likelihoods."""
from pathlib import Path
import copy
import sys
import unittest
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.append(str(HERE.parents[1]/'tmp/c09_D2_components_v1'))
from priors import PriorMeasure
from reference_runtime import integrate_reference_bundle,reference_identity
from cpu_allocation import allocate


class CPUAllocationTests(unittest.TestCase):
    def test_worker_and_controller_allowances_fit_in_total(self):
        for consumed in (0.,.15,2.7,12.):
            a=allocate(180.,consumed)
            self.assertGreaterEqual(a['worker_cleanup_reserved'],10.)
            self.assertLessEqual(a['worker_hard']+a['controller_stop']+a['final_receipt_reserved'],180.)
            self.assertGreater(a['controller_stop'],consumed)

    def test_no_worker_if_reserves_leave_no_compute(self):
        for total,consumed in [(10.,0.),(180.,170.)]:
            with self.assertRaises(ValueError):allocate(total,consumed)


class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.priors=[PriorMeasure('uniform_u',0.,1.),PriorMeasure('log_uniform_u',.001,1.)]
        self.cuts=[np.array([0.,.2,.7,1.]),np.array([.001,.1,.8,1.])]
        self.panels=[]
        self.full=integrate_reference_bundle(lambda u:-3*u*u,self.priors,self.cuts,
            shift=0.,on_panel=self.panels.append)

    def receipt(self,panels):
        return dict(context_sha256=self.full['context_sha256'],likelihood_identity_sha256='a'*64,
                    source_hashes_verified=True,panels=panels)

    def test_prefix_resume_equals_uninterrupted_and_reduces_queries(self):
        visited=[];saved=[]
        def likelihood(u):visited.extend(u);return -3*u*u
        partial=self.panels[:3]
        result=integrate_reference_bundle(likelihood,self.priors,self.cuts,shift=0.,
                                         resume=self.receipt(partial),on_panel=saved.append)
        self.assertEqual(result['results'],self.full['results'])
        self.assertEqual(result['panels'],self.full['panels'])
        self.assertEqual(result['reused_panels'],3)
        self.assertLess(result['callback_queries'],self.full['callback_queries'])
        self.assertTrue(all(u>partial[-1]['integration_record']['upper'] for u in visited))
        self.assertEqual(saved[0]['panel_index'],3)

    def test_complete_resume_uses_no_callback(self):
        def forbidden(u):raise AssertionError('complete prefix must not evaluate')
        result=integrate_reference_bundle(forbidden,self.priors,self.cuts,shift=0.,
                                         resume=self.receipt(self.panels))
        self.assertEqual(result['results'],self.full['results'])
        self.assertEqual(result['callback_queries'],0)

    def test_corrupt_late_panel_rejected_before_any_callback(self):
        def forbidden(u):raise AssertionError('validation must precede callback')
        for field,value in [('panel_index',0),('offsets',[0,1]),('active_prior_indices',[]),
                            ('operational_error_contribution',[-1.]*16)]:
            panels=copy.deepcopy(self.panels[:4]);panels[-1][field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):
                integrate_reference_bundle(forbidden,self.priors,self.cuts,shift=0.,
                                           resume=self.receipt(panels))

    def test_changed_scaling_or_measure_rejected(self):
        for shift in [1.,-1.]:
            with self.assertRaises(ValueError):
                integrate_reference_bundle(lambda u:-3*u*u,self.priors,self.cuts,shift=shift,
                                           resume=self.receipt(self.panels))
        priors=[PriorMeasure('uniform_u_squared',0.,1.),self.priors[1]]
        with self.assertRaises(ValueError):
            integrate_reference_bundle(lambda u:-3*u*u,priors,self.cuts,shift=0.,
                                       resume=self.receipt(self.panels))


if __name__=='__main__':unittest.main()
