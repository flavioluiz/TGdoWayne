# Runtime copy of frozen pure reference, with append-only completed-panel hook.
"""Direct shared references for fixed cuts and proper priors; no PTA imports.

The callback returns normalized logL and must charge every uncached data/curve
value before work. Integration uses alpha=asin(u); each vector has its own
normalizer, moments and fixed-cut numerator. Priors share a likelihood call,
never a normalizer. quad_vec errors are operational estimates, not bounds.
"""
import math
import hashlib
import json
import warnings
import numpy as np
from scipy.integrate import quad_vec
from priors import PriorMeasure


def ratio_interval(n,en,z,ez):
    if not np.isfinite([n,en,z,ez]).all() or en<0 or ez<0 or z<=ez or n<0 or n>z+en+ez:
        raise ArithmeticError('invalid numerator/denominator and their separate error estimates')
    return max(0.,(n-en)/(z+ez)),min(1.,(n+en)/(z-ez))


def conservative_quantile_gate(p,lo,hi,low_interval,high_interval,*,width=.001):
    if not (0<p<1 and 0<=lo<=hi<=1 and 0<width<=.001):raise ValueError('invalid quantile bracket')
    for pair in (low_interval,high_interval):
        if len(pair)!=2 or not np.isfinite(pair).all() or not 0<=pair[0]<=pair[1]<=1:
            raise ValueError('valid CDF intervals required')
    return bool(hi-lo<=width and low_interval[1]<=p<=high_interval[0])


def reference_identity(priors, cuts, shift, epsabs=1e-9, epsrel=1e-8, limit=150):
    """Identity of measure, scaling and fixed integration recipe, not likelihood."""
    value = dict(priors=[dict(kind=p.kind, lower=p.lower, upper=p.upper) for p in priors],
                 cuts=[np.asarray(c, float).tolist() for c in cuts], shift=float(shift),
                 epsabs=epsabs, epsrel=epsrel, limit=limit, quadrature='gk21', norm='max')
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def integrate_reference_bundle(loglike,priors,cuts,*,shift,epsabs=1e-9,epsrel=1e-8,limit=150,on_panel=None,resume=None):
    if on_panel is not None and not callable(on_panel):raise ValueError("panel persistence callback required")
    if (not callable(loglike) or not priors or len(priors)!=len(cuts) or
        any(not isinstance(p,PriorMeasure) for p in priors) or not math.isfinite(shift)):
        raise ValueError('callback, priors, per-prior fixed cuts and a finite fixed shift required')
    if not (0<epsabs<=1e-6 and 0<epsrel<=1e-6) or type(limit)is not int or not 1<=limit<=2000:
        raise ValueError('bounded prospective quadrature settings required')
    cutarrays=[];offset=[0]
    for c in cuts:
        c=np.asarray(c,float)
        if c.ndim!=1 or not np.isfinite(c).all() or np.any((c<0)|(c>1)):
            raise ValueError('finite fixed cuts in[0,1] required')
        cutarrays.append(c.copy());offset.append(offset[-1]+4+len(c))
    # Split at every support boundary and indicator cut. No adaptive selection
    # of cuts is made from the reference likelihood being integrated.
    edges=np.unique(np.concatenate([np.array([p.lower,p.upper]) for p in priors]+cutarrays))
    lower=min(p.lower for p in priors);upper=max(p.upper for p in priors)
    edges=edges[(edges>=lower)&(edges<=upper)]
    context = reference_identity(priors, cutarrays, shift, epsabs, epsrel, limit)
    completed = []
    if resume is not None:
        if (not isinstance(resume,dict) or resume.get('context_sha256') != context
            or not isinstance(resume.get('likelihood_identity_sha256'),str)
            or len(resume['likelihood_identity_sha256']) != 64
            or resume.get('source_hashes_verified') is not True
            or not isinstance(resume.get('panels'),list)):
            raise ValueError('verified likelihood identity, reference context and saved prefix required')
        completed = resume['panels']
    eligible = []
    for left,right in zip(edges[:-1],edges[1:]):
        active=[i for i,p in enumerate(priors) if p.lower <= (left+right)/2 <= p.upper]
        if active: eligible.append((left,right,active))
    if len(completed) > len(eligible):
        raise ValueError('saved prefix longer than this reference plan')
    # Validate the ENTIRE prefix before any new callback, including panels that
    # would otherwise be encountered only after fresh physical work.
    for index,panel in enumerate(completed):
        left,right,active=eligible[index]
        record=panel['integration_record']
        val=np.asarray(panel['scaled_integral_contribution'],float)
        err=np.asarray(panel['operational_error_contribution'],float)
        error=record['estimated_max_error'];expected=np.zeros(offset[-1])
        for j in active:expected[offset[j]:offset[j+1]]=error
        if (panel.get('schema')!='C09_D2_COMPLETED_REFERENCE_PANEL_v1'
            or panel.get('panel_index')!=index or panel.get('offsets')!=offset
            or panel.get('active_prior_indices')!=active
            or record['lower']!=left or record['upper']!=right
            or type(record['neval'])is not int or record['neval']<1
            or not math.isfinite(error) or error<0
            or val.shape!=(offset[-1],) or not np.isfinite(val).all()
            or err.shape!=(offset[-1],) or not np.array_equal(err,expected)):
            raise ValueError('incompatible or malformed saved reference panel')
    values=np.zeros(offset[-1]);errors=np.zeros(offset[-1]);queries=0;records=[]
    for left,right in zip(edges[:-1],edges[1:]):
        mid=(left+right)/2
        active=[i for i,p in enumerate(priors) if p.lower<=mid<=p.upper]
        if not active:continue
        index=len(records)
        if index<len(completed):
            panel=completed[index]
            values+=np.asarray(panel['scaled_integral_contribution'],float)
            errors+=np.asarray(panel['operational_error_contribution'],float)
            records.append(dict(panel['integration_record']))
            continue
        al,ah=math.asin(left),math.asin(right)
        if not al<ah:raise ArithmeticError('collapsed reference panel')
        def integrand(alpha):
            nonlocal queries
            u=math.sin(alpha);raw=np.asarray(loglike(np.array([u])),float)
            queries+=1
            if raw.shape!=(1,) or not np.isfinite(raw).all():raise ArithmeticError('invalid direct reference logL')
            ell=float(raw[0])-shift
            if ell>700:raise ArithmeticError('fixed scaling insufficient; no silent shift/restart')
            out=np.zeros(offset[-1])
            for j in active:
                w=math.exp(ell+float(priors[j].alpha_logpdf(alpha)))
                start=offset[j]
                out[start:start+4]=w*np.array([1.,u,u*u,ell])
                out[start+4:offset[j+1]]=w*(mid<=cutarrays[j])
            return out
        with warnings.catch_warnings():
            warnings.simplefilter('error')
            val,error,info=quad_vec(integrand,al,ah,epsabs=epsabs,epsrel=epsrel,
                                    norm='max',limit=limit,workers=1,quadrature='gk21',full_output=True)
        if not info.success or not np.isfinite(val).all() or not math.isfinite(error):
            raise ArithmeticError('reference quadrature failed without a usable certificate')
        values+=val
        # max-norm error applies to every component of this panel. It is not
        # divided by vector dimension; inactive components receive zero error.
        for j in active:errors[offset[j]:offset[j+1]]+=error
        records.append(dict(lower=left,upper=right,neval=int(info.neval),estimated_max_error=float(error)))
        if on_panel is not None:
            panel_error=np.zeros(offset[-1])
            for j in active:panel_error[offset[j]:offset[j+1]]=error
            on_panel(dict(schema='C09_D2_COMPLETED_REFERENCE_PANEL_v1',panel_index=len(records)-1,
                integration_record=records[-1],offsets=offset,active_prior_indices=active,
                scaled_integral_contribution=val.tolist(),operational_error_contribution=panel_error.tolist(),
                callback_queries_so_far=queries,all_other_panels_required_for_normalization=True))
    result=[]
    for j,p in enumerate(priors):
        val=values[offset[j]:offset[j+1]];err=errors[offset[j]:offset[j+1]]
        z=val[0];ez=err[0]
        if z<=ez:raise ArithmeticError('reference denominator not resolved')
        probabilities=val[4:]/z
        intervals=[ratio_interval(n,en,z,ez) for n,en in zip(val[4:],err[4:])]
        logz_error=-math.log1p(-ez/z)
        ratio_errors=[float((err[k]+abs(val[k]/z)*ez)/(z-ez)) for k in (1,2,3)]
        result.append(dict(prior=dict(kind=p.kind,lower=p.lower,upper=p.upper),
                           logZ=shift+math.log(z),logZ_error_estimate=-math.log1p(-ez/z),
                           mean=float(val[1]/z),second=float(val[2]/z),
                           kl_to_prior=float(val[3]/z-math.log(z)),
                           normalized_moment_errors=ratio_errors,
                           kl_error_estimate=ratio_errors[2]+logz_error,
                           cut_values=cutarrays[j].tolist(),cdf=probabilities.tolist(),
                           cdf_intervals=intervals,numerators=val[4:].tolist(),
                           numerator_error_estimates=err[4:].tolist(),
                           denominator=float(z),denominator_error_estimate=float(ez)))
    return dict(results=result,callback_queries=queries,panels=records,
                context_sha256=context,reused_panels=len(completed),
                historical_panel_queries=sum(p['integration_record']['neval'] for p in completed),
                error_kind='operational_QUADPACK_max_norm_estimates_not_rigorous_bounds',
                uniform_physical_probability_certificate=None,
                backend_domain_evidence_not_assessed_by_component=True,
                logL_event_not_evaluated=True)
