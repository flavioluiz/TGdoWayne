"""Check the published partial-state bridge without a physical evaluator."""
from pathlib import Path
import json
import os
import resource
import sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
sys.path += [str(ROOT/'tmp/c09_D2_components_v1'),str(ROOT/'tmp/c09_event_repair_v1'),
             str(ROOT/'tmp/c09_D2_runtime_resume_v1')]
resource.setrlimit(resource.RLIMIT_CPU,(30,35))
import numpy as np
from d1.grid import event_grid,exact_union
from d1.measure import Prior
from priors import PriorMeasure
from cache import CacheSet
from saved_state import SavedState,read,sha
from reference_runtime import integrate_reference_bundle


class PendingPhysicalWork(Exception):pass


def forbidden(*args,**kwargs):raise PendingPhysicalWork('no physical likelihood supplied')


def main():
    nominal=read(ROOT/'tmp/c09_nominal14_v4/config.json')
    with np.load(ROOT/nominal['table_file'],allow_pickle=False) as f:nodes=f['nodes']
    grid=event_grid(nodes,Prior('uniform_u'),validation_count=1)
    fine=exact_union(grid['fine_u'],np.array([0.,1e-4,.001,.01,.8,1.]))
    manifest=ROOT/'results/C09/D2_retoma/manifest.json'
    saved=SavedState(manifest,expected_manifest_sha256='768dfbfa720051fcb761c14fe1248cf8e53a4e415ff5e242ad77d6d34c9da936',fine_grid=fine)
    cache=CacheSet(list(saved.rows),provider=forbidden,batch=32,checkpoint=lambda:None)
    saved.restore_cache(cache,list(saved.rows.values()))
    reports=[]
    for name,row in saved.rows.items():
        cuts_path=saved.run/'cuts'/(name+'.json')
        count=0;pending=False
        if cuts_path.exists():
            old=read(cuts_path)
            specs=[saved.priors[p] for p in row['prior_ids']]
            priors=[PriorMeasure(p['kind'],p['lower'],p['upper']) for p in specs]
            cuts=[np.array(p['cuts']) for p in old['priors']]
            resume=saved.reference(name,priors,cuts,saved.shifts[name])
            if resume:
                count=len(resume['panels'])
                try:
                    integrate_reference_bundle(forbidden,priors,cuts,shift=saved.shifts[name],resume=resume)
                except PendingPhysicalWork:pending=True
                else:raise AssertionError('historical partial references unexpectedly complete')
        reports.append(dict(curve_id=name,imported_cache_values=cache.imported[name],
                            reusable_panels=count,reference_started=bool(count),
                            saved_prefix_accepted_before_callback=pending,
                            pending_physical_reference=True))
    assert sum(r['reusable_panels'] for r in reports)==248
    usage=resource.getrusage(resource.RUSAGE_SELF)
    report=dict(status='PASS_SAVED_BRIDGE_NO_PHYSICAL_EVALUATOR',curves=reports,
        source_sha256={p.name:sha(p) for p in HERE.glob('*.py')},
        published_manifest_sha256=sha(manifest),new_likelihood_values=0,new_ORF=0,new_draws=0,
        CPU_seconds=usage.ru_utime+usage.ru_stime,RSS_bytes=usage.ru_maxrss)
    (HERE/'bridge_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
