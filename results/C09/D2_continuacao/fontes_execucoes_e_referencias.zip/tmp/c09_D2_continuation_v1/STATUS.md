# Continuação D2 — implementação local em andamento

Última publicação: v0.8.6, commit 2dd6dcb306680b2cfbbcb8fa49acebcaa81b7641.
O turno anterior foi progresso: publicou o lote parcial, PDF e resultados auditados.
Este turno implementou componentes necessários à continuação, sem novas likelihoods.

## Implementado e verificado

- `reference_runtime.py`: reutilização de prefixo completo de painéis com validação
  prévia de identidade da referência, medidas, cortes, escala, índices e erros.
  Novas avaliações começam somente após o último painel concluído. Os erros e
  integrais anteriores são somados na mesma ordem; a comparação sintética com
  execução contínua é exatamente igual.
- `saved_state.py`: ponte entre o manifesto publicado, as fontes físicas antigas,
  os caches e os cortes de referência. Importação única em cache vazio, mantendo
  os campos científicos; orçamento adicional não muda a identidade da função.
- `verify_saved.py`: conferiu os 13 caches e os 248 painéis reais sem fornecer
  uma função física de likelihood. Manifesto esperado fixado por SHA-256.
- `cpu_allocation.py` e supervisor candidato: reservas separadas de 10 s para
  encerramento do worker, 5 s adicionais para o controlador e 1 s para o recibo.
  O teto do worker não consome mais sozinho todo o teto da etapa.
- `engine.py`: aceita a referência retomada e registra os painéis reutilizados.
- Seis testes específicos passaram (quatro de retomada e dois de alocação).
  Os seis testes de runtime, incluindo subprocessos de sucesso/falha, passaram
  em `toy_validation_v1`: 1,748293 s CPU e 114688000 bytes RSS.

## Ainda necessário antes de executar

1. Completar o worker de continuação. Carregar todos os caches D2 por SavedState,
   validar cortes via callback do engine e reutilizar controles físicos cuja
   identidade seja efetivamente a mesma. Não chamar o loader D1 para duplicar
   crédito de valores já importados.
2. Fechar novo plano: histórico auditado 720094 avaliações e 665,518992 s CPU,
   preservando também a reserva superior de 200000 do supervisor anterior.
   `supervisor.py` ainda conserva schema, cotas e histórico do D2 original:
   NÃO está pronto para autorizar a continuação física.
3. Dimensionar novas cotas por curva a partir do trabalho restante. Nas oito
   curvas novas, os prefixos terminam entre u=0,95 e 0,966; baseline_d2 em
   0,9816945894, baseline_d3 em 0,0214002938. As três últimas referências
   ainda não começaram. Fração do eixo não é fração de probabilidade ou custo.
4. Vincular `cpu_allocation.py`, `saved_state.py`, o manifesto publicado, as
   fontes e dados na nova configuração. Revisar integração e executar lote
   limitado, preservando o resultado original sem repetição automática.
5. Auditar as funções concluídas e as ainda pendentes, depois seguir W1/D3/SBC.
   C09 e o objetivo integral permanecem incompletos.

Não há processo físico em execução. A preparação local ainda não é um marco
concluído; commit/PDF/push ocorrerão no fechamento da próxima entrega.
