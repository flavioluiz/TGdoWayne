"""Prospective continuation plan; hashes and metadata only."""
from pathlib import Path
import copy
import hashlib
import json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
from supervisor import CAPS,SCOPE,validate_plan


def read(p):return json.loads(p.read_text())


def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def save(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')


def main():
    old=ROOT/'tmp/c09_D2_runtime_resume_v1'
    config=copy.deepcopy(read(old/'runtime_config.json'))
    caps=[35]*11+[5000,5000]
    for row,cap in zip(config['curves'],caps):row['additional_likelihood_cap']=cap
    config['previous_manifest']='results/C09/D2_retoma/manifest.json'
    config['allocation_delta']='Reallocate unused original global reserve: 11 completed curves x35 controls, baseline7/13 each5000. Total10385 below remaining63296; all historical costs retained.'
    config['historical_supervisor_unresolved_reservation']=200000
    config['previous_execution_status']='FAILED_NO_AUTOMATIC_RETRY_NOT_RECLASSIFIED'
    config_path=HERE/'runtime_config.json';save(config_path,config)
    bindings=read(old/'preflight.json')['bindings']
    for path,digest in bindings.items():assert sha(ROOT/path)==digest,path
    manifest=read(ROOT/config['previous_manifest'])
    for entry in manifest['files']:
        assert sha(ROOT/entry['path'])==entry['sha256'],entry['path']
        bindings[entry['path']]=entry['sha256']
    previous_plan=ROOT/'tmp/c09_D2_continuation_v2/preflight.json'
    bindings.update(read(previous_plan)['bindings'])
    extra=[previous_plan,ROOT/'tmp/c09_D2_continuation_v2/result_audit.json']
    extra.extend(p for p in (ROOT/'tmp/c09_D2_continuation_execution_v2').rglob('*') if p.is_file())
    for path in extra:bindings[str(path.relative_to(ROOT))]=sha(path)
    paths=list(HERE.glob('*.py'))+[config_path,ROOT/config['previous_manifest'],
        ROOT/'results/C09/D2_retoma/audit.json',old/'preflight.json']
    for path in paths:bindings[str(path.relative_to(ROOT))]=sha(path)
    plan=dict(schema='C09_D2_EXECUTION_PLAN_v1',scope=SCOPE,mode='D2',
        execution_enabled_by_default=False,repository=str(ROOT),limits=CAPS,
        curves=config['curves'],history=dict(likelihood_values=756798,CPU_seconds=875.99818,
            previous_supervisor_reserved_upper_values=200000,previous_D2_audited_charged_values=175778),
        worker=str((HERE/'worker.py').relative_to(ROOT)),
        worker_parameters=dict(runtime_config=str(config_path.relative_to(ROOT))),bindings=bindings)
    path=HERE/'preflight.json';save(path,plan)
    _,digest=validate_plan(path)
    save(HERE/'preparation.json',dict(status='PREFLIGHT_ONLY',plan_sha256=digest,
         source_bindings=len(bindings),new_likelihood_values=0,new_ORF=0,new_draws=0))
    print(digest)


if __name__=='__main__':main()
