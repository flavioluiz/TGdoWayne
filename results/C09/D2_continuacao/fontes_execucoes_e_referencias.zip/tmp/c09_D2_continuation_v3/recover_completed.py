"""Regression: serialize the completed real reference using only saved values."""
from pathlib import Path
import json
import os
import sys
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
sys.path += [str(ROOT/'tmp/c09_D2_components_v1'),str(ROOT/'tmp/c09_event_repair_v1')]
import numpy as np
from saved_state import SavedState,read
from d1.grid import event_grid,exact_union
from d1.measure import Prior
from cache import CacheSet
from engine import analyze_curve


def forbidden(*args,**kwargs):raise AssertionError('regression cannot evaluate new likelihoods or reference panels')


def main():
    plan=read(HERE/'preflight.json');config=read(HERE/'runtime_config.json')
    nominal=read(ROOT/config['nominal_config'])
    with np.load(ROOT/nominal['table_file'],allow_pickle=False) as f:nodes=f['nodes']
    grid=event_grid(nodes,Prior('uniform_u'),validation_count=1)
    edges=np.array([0.,1e-4,.001,.01,.8,1.])
    fine=exact_union(grid['fine_u'],edges);coarse=exact_union(grid['coarse_u'],edges)
    saved=SavedState(ROOT/config['previous_manifest'],expected_manifest_sha256=plan['bindings'][config['previous_manifest']],fine_grid=fine)
    saved.overlay_failed_continuation(SimpleNamespace(plan=plan))
    saved.overlay_failed_continuation(SimpleNamespace(plan=plan),version=2)
    cache=CacheSet(list(saved.rows),provider=forbidden,batch=32,checkpoint=lambda:None)
    saved.restore_cache(cache,config['curves'])
    row=config['curves'][0];name=row['curve_id'];byprior={p['id']:p for p in config['priors']}
    old=ROOT/'tmp/c09_D2_continuation_execution_v1/worker'
    def check_cuts(value):assert json.loads(json.dumps(value))==read(old/'cuts'/(name+'.json'))
    result=analyze_curve(row,[byprior[k] for k in row['prior_ids']],coarse,fine,cache,
        freeze_cuts=check_cuts,save_reference_panel=forbidden,
        finite_backend_evidence=read(old/'backend_checks'/(name+'.json')),
        resume_reference=lambda priors,cuts,shift:saved.reference(name,priors,cuts,shift))
    encoded=json.dumps(result,allow_nan=False,indent=2)
    assert result['reference_queries']==0
    (HERE/'recovered_first_result.json').write_text(encoded+'\n')
    print(json.dumps(dict(status='PASS_REAL_RESULT_SERIALIZATION_NO_NEW_LIKELIHOODS',
        reused_panels=result['reused_reference_panels'],gates=result['results'][0]['table_gates'])))


if __name__=='__main__':main()
