"""Prospective D2 supervisor, stdlib only. Execution needs an external receipt.

The reviewed D1 helpers provide safe paths, hashes and new-file writes. D1
configuration, guards and historical caps are not changed or reinterpreted.
"""
import argparse,importlib.util,json,math,os,resource,selectors,signal,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
_spec=importlib.util.spec_from_file_location('_frozen_d1_primitives',ROOT/'tmp/c09_d1_supervisor_v1/supervisor.py')
_old=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_old)
require,sha,read,payload=_old.require,_old.sha,_old.read,_old.payload
path_under,saved_bytes,write_new,cpu,rss=_old.path_under,_old.saved_bytes,_old.write_new,_old.cpu,_old.rss
from budget import Budget
from cpu_allocation import allocate

SCOPE='D2_FINAL_TWO_REFERENCE_TAILS_WITH_FULL_CARRYOVER'
THREADS=('VECLIB_MAXIMUM_THREADS','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS')
CAPS=dict(new_likelihood_values=10385,new_cpu_seconds=180.,wall_seconds=240.,
          rss_bytes=1610612736,estimated_numeric_bytes=1400000000,
          new_output_bytes=16777216,control_reserve_bytes=65536,log_cap_bytes=65536)


def bindings(plan):
    for name,digest in plan['bindings'].items():
        require(isinstance(digest,str)and len(digest)==64 and sha(path_under(ROOT,name))==digest,'source/input hash changed: '+name)


def validate_plan(path):
    plan=read(path);require(plan.get('schema')=='C09_D2_EXECUTION_PLAN_v1','D2 plan schema required')
    require(plan.get('scope')==SCOPE and plan.get('mode')in('D2','TOY')and plan.get('execution_enabled_by_default')is False,'disabled-default scope/mode required')
    require(plan.get('repository')==str(ROOT),'same declared repository required')
    limits=plan['limits'];require(set(limits)==set(CAPS),'exact limit fields required')
    for k,maxvalue in CAPS.items():
        require(type(limits[k])in(int,float)and math.isfinite(limits[k])and 0<limits[k]<=maxvalue,'limit cannot exceed prospective cap '+k)
    for k in('new_likelihood_values','rss_bytes','estimated_numeric_bytes','new_output_bytes','control_reserve_bytes','log_cap_bytes'):
        require(type(limits[k])is int,'exact integer cap required '+k)
    require(limits['control_reserve_bytes']+limits['log_cap_bytes']<limits['new_output_bytes'],'room for worker payload required')
    rows=plan['curves'];history=plan['history']
    Budget(rows,additional_cap=limits['new_likelihood_values'],historical_values=history['likelihood_values'],checkpoint=lambda:None)
    require(type(history['CPU_seconds'])in(int,float)and math.isfinite(history['CPU_seconds'])and history['CPU_seconds']>=0,'finite historical CPU required')
    require(sum(r['additional_likelihood_cap']for r in rows)==limits['new_likelihood_values'],'all stage reservations explicitly allocated')
    required=[str((HERE/'supervisor.py').relative_to(ROOT)),str((HERE/'budget.py').relative_to(ROOT)),
              'tmp/c09_d1_supervisor_v1/supervisor.py',str((HERE/'cpu_allocation.py').relative_to(ROOT)),
              plan['worker'],plan['worker_parameters']['runtime_config']]
    require(all(p in plan['bindings']for p in required),'guard/worker/config source closure incomplete')
    if plan['mode']=='D2':
        require(limits==CAPS and len(rows)==13,'exact D2 stage envelope required')
        require(history['likelihood_values']==756798 and abs(history['CPU_seconds']-875.99818)<1e-9,'reviewed D2 history differs')
        require([r['additional_likelihood_cap']for r in rows]==[35]*11+[5000,5000],'prospective continuation allocation differs')
        require(plan['worker']==str((HERE/'worker.py').relative_to(ROOT)),'physical worker must be the reviewed candidate')
        for p in('src/inference/__init__.py','src/pta/__init__.py','tmp/c09_ROOT/DECISAO_AVANCO_FUNCIONAL.md',
                 'tmp/c09_ROOT/D1b_result_review_v1.json','results/C09/D2_retoma/manifest.json',
                 'results/C09/D2_retoma/audit.json',str((HERE/'saved_state.py').relative_to(ROOT))):
            require(p in plan['bindings'],'required semantic/identity binding missing '+p)
    else:
        require(plan['worker']==str((HERE/'toy_worker.py').relative_to(ROOT)),'TOY cannot call physical worker')
        require(history['likelihood_values']==0 and history['CPU_seconds']==0,'TOY history is synthetic zero')
    bindings(plan);return plan,sha(path)


def validate_authorization(path,plan,plan_sha,out):
    auth=read(path);expected='ROOT'if plan['mode']=='D2'else'SYNTHETIC_TEST_ONLY'
    require(auth.get('schema')=='C09_D2_EXECUTION_AUTHORIZATION_v1'and auth.get('authority')==expected,'explicit external authorization required')
    require(auth.get('approved')is True and auth.get('plan_sha256')==plan_sha and auth.get('scope')==SCOPE and auth.get('mode')==plan['mode'],'authorization scope/plan mismatch')
    require(auth.get('output')==str(out.resolve()),'authorization must name exact new output')
    require(auth.get('no_automatic_retry')is True,'no automatic retry required')
    if plan['mode']=='D2':
        require(bool(auth.get('ROOT_code_review_sha256'))and bool(auth.get('semantic_cache_bridge_approved')),'ROOT code/semantic bridge review binding required')
    return sha(path)


class WorkerGuard:
    @classmethod
    def from_request(cls,path,expected_sha):
        require(sha(path)==expected_sha,'worker request hash changed');req=read(path)
        require(req.get('schema')=='C09_D2_WORKER_REQUEST_v1','worker request schema differs')
        plan,psha=validate_plan(req['plan_path']);out=Path(req['output']).resolve()
        require(psha==req['plan_sha256'],'plan hash differs')
        authsha=validate_authorization(req['authorization_path'],plan,psha,out)
        require(authsha==req['authorization_sha256'],'authorization hash differs')
        require(Path(path).resolve()==out/'worker_request.json','request must be in authorized output')
        require(list(resource.getrlimit(resource.RLIMIT_CPU))==req['CPU_limits'],'supervised process CPU limits required')
        require(all(os.environ.get(k)=='1'for k in THREADS),'single-thread libraries required before numeric imports')
        identity=read(out/'execution_identity.json')
        require(identity['request_sha256']==expected_sha and identity['plan_sha256']==psha and identity['authorization_sha256']==authsha,'controller identity differs')
        self=cls();self.request=req;self.request_path=Path(path);self.request_sha256=expected_sha
        self.plan=plan;self.parameters=plan['worker_parameters'];self.repository=ROOT;self.config=plan['limits']
        self.output=out/'worker';self.output_path=self.output;self.output.mkdir(exist_ok=False)
        self.finished=False;self.stop_reason=None
        self.budget=Budget(plan['curves'],additional_cap=self.config['new_likelihood_values'],
                           historical_values=plan['history']['likelihood_values'],checkpoint=self.checkpoint)
        def stop_cpu(signum,frame):self.stop_reason='worker CPU soft limit';raise RuntimeError(self.stop_reason)
        signal.signal(signal.SIGXCPU,stop_cpu);self.checkpoint();return self

    def checkpoint(self):
        if self.stop_reason:raise RuntimeError(self.stop_reason)
        if cpu()>=self.request['CPU_limits'][0]:self.stop_reason='worker CPU allocation reached';raise RuntimeError(self.stop_reason)
        require(cpu()+self.request['controller_CPU_at_launch']<=self.config['new_cpu_seconds'],'D2 additional CPU cap reached')
        if rss()+self.request['controller_RSS_at_launch']>self.config['rss_bytes']:raise MemoryError('D2 total RSS allowance exceeded')
        require(saved_bytes(self.output)<=self.request['worker_payload_bytes'],'D2 output payload cap reached')

    def check(self):self.checkpoint()

    def write_bytes(self,name,data):
        require(not self.finished and name!='worker_end.json'and isinstance(data,bytes),'bounded nonreceipt payload required')
        require(saved_bytes(self.output)+len(data)<=self.request['worker_payload_bytes'],'output cap before write')
        target=path_under(self.output,name);target.parent.mkdir(parents=True,exist_ok=True)
        write_new(target,data,bytes_value=True)

    def write_json(self,name,value):self.write_bytes(name,payload(value))

    def report(self):
        return dict(**self.budget.report(),worker_CPU_seconds=cpu(),worker_RSS_bytes=rss(),
                    historical_CPU_seconds=self.plan['history']['CPU_seconds'],
                    historical_D1_caps_not_changed=True,new_ORF=0,new_sky=0,new_draws=0)

    def finish(self,status,summary):
        require(not self.finished and status in('COMPLETED','FAILED'),'one final worker status required');problems=[]
        try:
            bindings(self.plan)
            require(sha(self.request_path)==self.request_sha256 and sha(self.request['plan_path'])==self.request['plan_sha256']and
                    sha(self.request['authorization_path'])==self.request['authorization_sha256'],'request/plan/auth changed at finish')
            self.checkpoint()
        except BaseException as exc:problems.append(type(exc).__name__+': '+str(exc))
        value=dict(schema='C09_D2_WORKER_END_v1',status=status,resources=self.report(),summary=summary,
                   problems=problems,request_sha256=self.request_sha256,plan_sha256=self.request['plan_sha256'])
        raw=payload(value);require(len(raw)<=self.config['control_reserve_bytes']//4,'reserved receipt exhausted')
        write_new(self.output/'worker_end.json',raw,bytes_value=True);self.finished=True;return value


def execute(plan_path,auth_path,out):
    plan_path=Path(plan_path).resolve();auth_path=Path(auth_path).resolve();out=Path(out)
    require(not out.is_symlink(),'output symlink forbidden');out=out.resolve()
    plan,psha=validate_plan(plan_path);asha=validate_authorization(auth_path,plan,psha,out)
    require(not out.exists()and out.parent.is_dir(),'new output under existing directory required')
    require(not any((ROOT/p).resolve().is_relative_to(out)for p in plan['bindings']),'output may not contain bound inputs')
    require(not plan_path.is_relative_to(out)and not auth_path.is_relative_to(out),'output may not contain plan/auth')
    out.mkdir();limits=plan['limits'];parentcpu=cpu()
    allocation=allocate(limits['new_cpu_seconds'],parentcpu)
    soft,hard=allocation['worker_soft'],allocation['worker_hard']
    worker_payload=limits['new_output_bytes']-limits['control_reserve_bytes']-limits['log_cap_bytes']
    request=dict(schema='C09_D2_WORKER_REQUEST_v1',plan_path=str(plan_path),plan_sha256=psha,
                 authorization_path=str(auth_path),authorization_sha256=asha,output=str(out),CPU_limits=[soft,hard],
                 controller_CPU_at_launch=parentcpu,controller_RSS_at_launch=rss(),worker_payload_bytes=worker_payload,
                 CPU_allocation=allocation)
    write_new(out/'worker_request.json',request);rsha=sha(out/'worker_request.json')
    write_new(out/'execution_identity.json',dict(plan_sha256=psha,authorization_sha256=asha,request_sha256=rsha,
              reserved_stage_values=limits['new_likelihood_values'],reserved_by_curve={r['curve_id']:r['additional_likelihood_cap']for r in plan['curves']}))
    env=dict(os.environ,**{k:'1'for k in THREADS})
    command=[sys.executable,str(ROOT/plan['worker']),'--request',str(out/'worker_request.json'),'--request-sha256',rsha]
    def preexec():
        resource.setrlimit(resource.RLIMIT_CPU,(soft,hard));resource.setrlimit(resource.RLIMIT_FSIZE,(worker_payload,worker_payload))
    before=cpu(resource.RUSAGE_CHILDREN);start=time.monotonic();errors=[];selector=selectors.DefaultSelector();process=None;logbytes=0
    try:
        process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,preexec_fn=preexec)
        selector.register(process.stdout,selectors.EVENT_READ)
        with(out/'worker.log').open('xb')as log:
            while selector.get_map():
                for key,_ in selector.select(timeout=.1):
                    block=os.read(key.fd,16384)
                    if not block:selector.unregister(key.fileobj);continue
                    if logbytes+len(block)>limits['log_cap_bytes']:raise RuntimeError('worker log cap exceeded')
                    log.write(block);logbytes+=len(block)
                if time.monotonic()-start>limits['wall_seconds']:raise RuntimeError('D2 wall cap exceeded')
                if saved_bytes(out/'worker')>worker_payload+limits['control_reserve_bytes']//4:raise RuntimeError('worker payload cap exceeded')
                if cpu()>allocation['controller_stop']:raise RuntimeError('controller CPU reservation reached')
    except BaseException as exc:
        errors.append(type(exc).__name__+': '+str(exc))
        if process is not None and process.poll()is None:
            try:process.kill()
            except ProcessLookupError:pass
            except PermissionError as denied:errors.append('owned worker kill denied: '+str(denied))
    finally:
        selector.close()
        if process is not None:
            if process.stdout:process.stdout.close()
            while True:
                try:code=process.wait();break
                except (KeyboardInterrupt,InterruptedError):
                    errors.append('interrupted during reap')
                    try:process.kill()
                    except(ProcessLookupError,PermissionError):pass
        else:code=None
    childcpu=cpu(resource.RUSAGE_CHILDREN)-before;peak=rss()+rss(resource.RUSAGE_CHILDREN);receipt=None
    try:
        receipt=read(out/'worker/worker_end.json')
        require(receipt['schema']=='C09_D2_WORKER_END_v1'and receipt['request_sha256']==rsha and receipt['plan_sha256']==psha,'final worker identity differs')
        b=receipt['resources'];caps={r['curve_id']:r['additional_likelihood_cap']for r in plan['curves']}
        require(set(b['by_curve'])==set(caps)and all(type(v)is int and 0<=v<=caps[k]for k,v in b['by_curve'].items()),'final per-curve counts invalid')
        require(b['additional_charged_values']==sum(b['by_curve'].values())<=limits['new_likelihood_values'],'final global count invalid')
        require(b['cumulative_values']==plan['history']['likelihood_values']+b['additional_charged_values'],'historical count not preserved')
        require(not receipt['problems'],'worker reported resource/source problems')
        bindings(plan);require(sha(plan_path)==psha and sha(auth_path)==asha,'plan/auth changed after execution')
    except BaseException as exc:errors.append('final receipt: '+type(exc).__name__+': '+str(exc));receipt=None
    elapsed=time.monotonic()-start;stagecpu=cpu()+childcpu
    if stagecpu>limits['new_cpu_seconds']or peak>limits['rss_bytes']or elapsed>limits['wall_seconds']:errors.append('final stage resources exceeded')
    if code!=0:errors.append('worker exit code '+str(code))
    if receipt is not None and receipt['status']!='COMPLETED':errors.append('worker did not complete all planned recording')
    record=dict(schema='C09_D2_SUPERVISOR_END_v1',status='COMPLETED'if not errors else'FAILED_NO_AUTOMATIC_RETRY',
                errors=errors,returncode=code,plan_sha256=psha,authorization_sha256=asha,
                measured_stage_CPU_seconds=stagecpu,historical_CPU_seconds=plan['history']['CPU_seconds'],
                cumulative_CPU_seconds=plan['history']['CPU_seconds']+stagecpu,RSS_sum_peak_bytes=peak,wall_seconds=elapsed,
                observed_value_counts=None if receipt is None else receipt['resources'],
                unresolved_reservation_upper_values=limits['new_likelihood_values']if receipt is None else 0,
                unresolved_reservation_by_curve={r['curve_id']:r['additional_likelihood_cap']for r in plan['curves']}if receipt is None else{},
                no_automatic_retry=True,old_D1_caps_not_changed=True,C09_complete=False)
    raw=payload(record);require(saved_bytes(out)+len(raw)<=limits['new_output_bytes'],'final output cap exceeded')
    write_new(out/'execution_end.json',raw,bytes_value=True);return record


def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['preflight','execute']);p.add_argument('--plan',required=True)
    p.add_argument('--authorization');p.add_argument('--output');a=p.parse_args()
    if a.mode=='preflight':plan,digest=validate_plan(a.plan);print(json.dumps(dict(status='PREFLIGHT_ONLY',plan_sha256=digest,limits=plan['limits'])));return
    require(a.authorization and a.output,'explicit authorization and output required')
    print(json.dumps(execute(a.plan,a.authorization,a.output),indent=2))

if __name__=='__main__':main()
