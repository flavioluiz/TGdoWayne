"""Read-only numerical audit of the finished continuation; no physical calls."""
from pathlib import Path
import hashlib
import json
import numpy as np
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'tmp/c09_D2_continuation_v2'
RUN=ROOT/'tmp/c09_D2_continuation_execution_v2'
OLD=ROOT/'tmp/c09_D2_continuation_execution_v1'


def read(p):return json.loads(p.read_text())


def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def main():
    end=read(RUN/'execution_end.json');worker=read(RUN/'worker/worker_end.json')
    plan=read(HERE/'preflight.json');counts=worker['resources']
    assert end['plan_sha256']==sha(HERE/'preflight.json')
    for p,digest in plan['bindings'].items():assert sha(ROOT/p)==digest,p
    records=[];missing=[];reused=0;gap_sum=0;charged_sum=0
    for curve in plan['curves']:
        name=curve['curve_id'];identity=read(RUN/'worker/caches'/(name+'_identity.json'))
        with np.load(OLD/'worker/caches'/(name+'.npz'),allow_pickle=False) as f:
            old_u,old_l=f['u'],f['log_likelihood']
        with np.load(RUN/'worker/caches'/(name+'.npz'),allow_pickle=False) as f:
            u,ell=f['u'],f['log_likelihood']
        idx=np.searchsorted(u,old_u)
        assert np.array_equal(u[idx],old_u) and ell[idx].tobytes()==old_l.tobytes(),name
        assert len(u)==identity['stored_values'] and len(old_u)==identity['imported_values']
        assert np.isfinite(ell).all() and np.all(np.diff(u)>0)
        assert counts['by_curve'][name]==identity['charged_values']<=curve['additional_likelihood_cap']
        backend=read(RUN/'worker/backend_checks'/(name+'.json'))
        assert backend['new_curve_checks_passed']
        gap=identity['charged_values']-(len(u)-len(old_u))-35
        assert gap>=0;gap_sum+=gap;charged_sum+=identity['charged_values']
        path=RUN/'worker/results'/(name+'.json')
        if not path.exists():missing.append(dict(curve_id=name,status='NOT_RECORDED'));continue
        result=read(path)
        if result.get('schema')!='C09_D2_FUNCTIONAL_RESULT_v1':
            missing.append(dict(curve_id=name,status=result['status']));continue
        reused+=result['reused_reference_panels']
        assert [r['prior_id'] for r in result['results']]==curve['prior_ids']
        for r in result['results']:
            ref=r['reference'];cdf=np.array(ref['cdf']);intervals=np.array(ref['cdf_intervals'])
            z,ez=ref['denominator'],ref['denominator_error_estimate']
            assert z>ez>=0
            for j,(n,en) in enumerate(zip(ref['numerators'],ref['numerator_error_estimates'])):
                expected=[max(0.,(n-en)/(z+ez)),min(1.,(n+en)/(z-ez))]
                np.testing.assert_allclose(intervals[j],expected,rtol=0,atol=2e-15)
                assert abs(cdf[j]-n/z)<2e-15
            primary={k:r['table_gates'][k] for k in ('normalization','CDF','quantiles','moments','KL')}
            q95=next(q for q in r['quantiles'] if q['probability']==.95)
            records.append(dict(curve_id=name,prior_id=r['prior_id'],primary_gates=primary,
                all_primary_passed=all(primary.values()),quantile_95_bracket=[q95['lower'],q95['upper']],
                mean=r['summary']['mean'],KL=r['summary']['kl_to_prior'],logZ=r['summary']['logZ'],
                delta_logZ=r['delta_logZ'],delta_CDF=max(r['delta_CDF']),delta_KL=r['delta_KL'],
                functional_status=r['functional_status'],truth_outside_support=r['truth_outside_support']))
    assert gap_sum==counts['failed_reserved_values']
    assert charged_sum==counts['additional_charged_values']
    assert counts['cumulative_values']==721505+charged_sum
    out=dict(status='AUDITED_WITH_ORIGINAL_EXECUTION_STATUS_PRESERVED',execution_status=end['status'],
        measured_stage_CPU_seconds=end['measured_stage_CPU_seconds'],
        cumulative_CPU_seconds=end['cumulative_CPU_seconds'],
        additional_charged_values=charged_sum,cumulative_values=counts['cumulative_values'],
        original_values_verified_bitwise=True,reused_complete_reference_panels=reused,
        completed_analyses=len(records),primary_passed=sum(r['all_primary_passed'] for r in records),
        missing_or_incomplete_curves=missing,analyses=records,
        W1_direct_pending=True,logL_event_not_evaluated=True,SBC_executed=False,C09_complete=False)
    (HERE/'result_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='analyses'},indent=2))


if __name__=='__main__':main()
