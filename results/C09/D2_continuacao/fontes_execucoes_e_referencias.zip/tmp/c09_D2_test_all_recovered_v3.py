"""Recover all completed analyses without supplying a physical evaluator."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tmp/c09_D2_continuation_v3'))
import recover_completed as r


class PendingReference(Exception):pass


def forbidden(*args,**kwargs):raise PendingReference()


plan=r.read(r.HERE/'preflight.json');config=r.read(r.HERE/'runtime_config.json')
nominal=r.read(ROOT/config['nominal_config'])
with r.np.load(ROOT/nominal['table_file'],allow_pickle=False) as f:nodes=f['nodes']
grid=r.event_grid(nodes,r.Prior('uniform_u'),validation_count=1)
edges=r.np.array([0.,1e-4,.001,.01,.8,1.])
fine=r.exact_union(grid['fine_u'],edges);coarse=r.exact_union(grid['coarse_u'],edges)
saved=r.SavedState(ROOT/config['previous_manifest'],expected_manifest_sha256=plan['bindings'][config['previous_manifest']],fine_grid=fine)
for version in (1,2):saved.overlay_failed_continuation(r.SimpleNamespace(plan=plan),version=version)
cache=r.CacheSet(list(saved.rows),provider=forbidden,batch=32,checkpoint=lambda:None)
saved.restore_cache(cache,config['curves'])
byprior={p['id']:p for p in config['priors']};completed=0;pending=[]
for row in config['curves']:
    name=row['curve_id']
    def cuts(value):assert r.json.loads(r.json.dumps(value))==saved.cut_records[name]
    try:
        result=r.analyze_curve(row,[byprior[k] for k in row['prior_ids']],coarse,fine,cache,
            freeze_cuts=cuts,save_reference_panel=forbidden,
            finite_backend_evidence=r.read(ROOT/'tmp/c09_D2_continuation_execution_v2/worker/backend_checks'/(name+'.json')),
            resume_reference=lambda priors,c,shift:saved.reference(name,priors,c,shift))
    except PendingReference:pending.append(name);continue
    r.json.dumps(result,allow_nan=False)
    assert result['reference_queries']==0
    assert all(all(a['table_gates'][k] for k in ('normalization','CDF','quantiles','moments','KL')) for a in result['results'])
    completed+=len(result['results'])
assert completed==38 and pending==['baseline_d7','baseline_d13']
report=dict(status='PASS_38_RECOVERED_TWO_PENDING_NO_NEW_LIKELIHOODS',completed=completed,pending=pending,new_likelihood_values=0)
(ROOT/'tmp/c09_D2_all_recovered_v3.json').write_text(r.json.dumps(report,indent=2)+'\n')
print(report)
