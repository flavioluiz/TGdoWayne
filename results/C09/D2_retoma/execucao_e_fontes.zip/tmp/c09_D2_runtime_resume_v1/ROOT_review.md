# Revisão da retomada D2

O usuário autorizou retomar o trabalho. Esta revisão técnica autoriza uma única
execução do plano 974ccbfc9ff8eca3506da320f26cbe060dab2eafe0886bd0e1388be46a24f21d.

Os 1070 arquivos do snapshot C09 da v0.8.5 foram verificados. A configuração
preserva dados, tabela ORF, modelos e parâmetros do piloto nominal14. As cinco
funções históricas têm identidade de modelo conferida pelo preparador; o loader
exige hashes, comparação direta em 32 pontos e igualdade binária nas colisões
antes de importar os caches. Essa ponte semântica está aprovada para esses dados.

Foram revisados supervisor, worker, cache, orçamento, loader, kernels, controles
de backend, integração e referências funcionais. Os seis testes sintéticos da
cópia de retomada passaram (1,78677 s CPU; 114458624 bytes RSS), incluindo falhas
e persistência. Nenhuma simulação física ocorreu nesses testes.

Limites: 200000 novas avaliações, 180 s CPU, 360 s de parede, 1,5 GiB RSS e
16 MiB de saída; oito curvas novas e cinco históricas, totalizando 40 análises.
Não há novos sorteios, integrações ORF ou repetição automática. As cotas são
prospectivas. Resultados incompletos serão preservados como inconclusivos.

Os controles finitos de backend não constituem um certificado uniforme físico.
W1 e eventos de log-verossimilhança continuam pendentes. Este lote não conclui
C09 nem substitui a calibração SBC. O resultado deve ser auditado antes de uso.
