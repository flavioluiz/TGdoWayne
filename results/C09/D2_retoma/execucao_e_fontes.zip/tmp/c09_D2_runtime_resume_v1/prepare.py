"""Close the reviewed D2 configuration; hash-only inputs, no physical work."""
import copy
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')


def main():
    from supervisor import CAPS, SCOPE, validate_plan
    snapshot = read(ROOT/'results/pausa_v0.8.5/c09_manifest.json')
    for item in snapshot['files']:
        assert sha(ROOT/item['path']) == item['sha256'], item['path']
    design_path = ROOT/'tmp/c09_D2_components_v1/config_prospectiva_v2.json'
    design = read(design_path)
    rows = copy.deepcopy(design['new_curves'] + design['reused_functions'])
    for row, cap in zip(rows, [20500]*8+[10000]*3+[3000]*2):
        row['additional_likelihood_cap'] = cap
    assert len(rows) == 13 and sum(len(r['prior_ids']) for r in rows) == 40
    nominal_path = ROOT/'tmp/c09_nominal14_v4/config.json'
    nominal = read(nominal_path)
    histories = []
    for row in rows[8:]:
        target = row['data_id']
        previous = nominal['rows'][target]
        for key in ('analysis', 'eta_physical_coordinates', 'analysis_contaminant_ratio', 'fixed_truth_u'):
            assert row[key] == previous[key], (target, key)
        histories.append(dict(curve_id=row['curve_id'], data_id=target,
            cache_path=f'tmp/c09_D1_execution_v1/worker/target_{target:02d}_cache.npz',
            identity_path=f'tmp/c09_D1_execution_v1/worker/target_{target:02d}_cache_identity.json'))
    config = dict(schema='C09_D2_PHYSICAL_RUNTIME_v1', execution_enabled_by_default=False,
        curves=rows, priors=design['priors'], nominal_config=str(nominal_path.relative_to(ROOT)),
        data_file='tmp/c09_nominal14_backend_v4/gates/data.npz',
        harmonic_file='tmp/c09_nominal14_backend_v4/gates/harmonic_nodes.npz',
        historical_D1_plan='tmp/c09_event_repair_runtime_v1/preflight.json',
        historical_cache_inputs=histories, design_sha256=sha(design_path),
        allocation_delta='Same 200000 total: 8x20500 new curves; baseline 2/3/6 each10000, 7/13 each3000. Accepted prospectively before pause.',
        no_new_ORF_sky_or_observations=True, C09_complete=False)
    config_path = HERE/'runtime_config.json'
    save(config_path, config)
    old_plan = read(ROOT/config['historical_D1_plan'])
    # Keep the original closure and add all sources used by this driver.
    bindings = dict(old_plan['bindings'])
    for path, expected in bindings.items():
        assert sha(ROOT/path) == expected, path
    paths = [design_path, nominal_path, config_path,
        ROOT/config['historical_D1_plan'], ROOT/config['data_file'], ROOT/config['harmonic_file'],
        ROOT/'tmp/c09_ROOT/DECISAO_AVANCO_FUNCIONAL.md',
        ROOT/'tmp/c09_ROOT/D1b_result_review_v1.json',
        ROOT/'tmp/c09_ROOT/D2_design_review_v1.json',
        ROOT/'tmp/c09_D2_runtime_v1/toy_attempt3/validation.json']
    for history in histories:
        paths.extend(ROOT/history[k] for k in ('cache_path', 'identity_path'))
    for directory in (HERE, ROOT/'tmp/c09_D2_components_v1', ROOT/'tmp/c09_nominal14_v4'):
        paths.extend(directory.glob('*.py'))
    paths.extend((ROOT/'tmp/c09_event_repair_v1/d1').glob('*.py'))
    for path in paths:
        bindings[str(path.relative_to(ROOT))] = sha(path)
    plan = dict(schema='C09_D2_EXECUTION_PLAN_v1', scope=SCOPE, mode='D2',
        execution_enabled_by_default=False, repository=str(ROOT), limits=CAPS, curves=rows,
        history=dict(likelihood_values=544316, CPU_seconds=484.422282),
        worker=str((HERE/'worker.py').relative_to(ROOT)),
        worker_parameters=dict(runtime_config=str(config_path.relative_to(ROOT))), bindings=bindings)
    plan_path = HERE/'preflight.json'
    save(plan_path, plan)
    _, digest = validate_plan(plan_path)
    save(HERE/'preparation.json', dict(status='PREFLIGHT_PASSED_NO_PHYSICAL_EXECUTION',
        plan_sha256=digest, sources_and_inputs=len(bindings), snapshot_files_verified=len(snapshot['files']),
        prior_analyses=40, new_LL_cap=200000, new_CPU_cap_seconds=180,
        PTA_likelihood_values=0, new_ORF=0, new_draws=0))
    print(digest)


if __name__ == '__main__':
    main()
