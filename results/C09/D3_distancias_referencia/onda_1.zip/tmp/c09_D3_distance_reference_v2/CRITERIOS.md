# Continuação adaptativa da referência de distâncias

A primeira onda GK21 em u concordou com GL64 nos critérios funcionais,
mas seu maior estimador de erro embutido normalizado foi 0,0879.
Não é aceitação da referência. Refinar os quatro painéis de maior erro
e, se necessário, repetir uma vez com os quatro maiores da malha resultante.
As três ondas usam no máximo 1092 dos 1152 nós de distância reservados.

Conservar os critérios prospectivos: diferenças de logZ, momentos e KL
até 0,001; CDF até 0,002. Exigir também concordância com a onda anterior
nessas mesmas escalas e soma do estimador GK normalizado até 0,001 por curva.
O último é um diagnóstico de parada operacional da referência, não uma
garantia matemática de erro absoluto. Reportar cada função separadamente.
Se a reserva acabar, preservar todos os resultados como referência parcial;
não relaxar critérios, omitir curvas ou lançar uma tentativa adicional automaticamente.

CDFs aqui são somente as fronteiras originais dos painéis. Os quantis,
W1 e eventos de logL exigem validações próprias e não recebem aprovação
desse teste. Nenhuma execução deste piloto representa a produção SBC.
