"""Freeze first independent GK21 wave in u; no posterior interpolant."""
from pathlib import Path
import os,sys,json,hashlib,inspect
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
H=Path(__file__).resolve().parent;R=H.parents[1];sys.path.insert(0,str(R/'src'))
import numpy as np
from scipy.integrate._quad_vec import _quadrature_gk21
from inference.orf_blas import estimate
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
out=H/'prepared';out.mkdir(exist_ok=False)
old=R/'tmp/c09_D3_distances_v1/prepared/plan.json';plan=json.loads(old.read_text())
edges=np.array([0.,.0001,.001,.01,.05,.25,.5,.75,.9,.99,1.]);panels=np.column_stack((edges[:-1],edges[1:]))
nodes=[]
for a,b in panels:
 local=[]
 _quadrature_gk21(a,b,lambda u:(local.append(u) or np.array([1.,u,u*u])),np.linalg.norm)
 assert len(local)==21
 nodes.extend(local)
u=np.unique(nodes);assert len(u)==210
np.savez_compressed(out/'rules.npz',u=u,panels=panels)
(out/'scipy_gk21_source.txt').write_text(inspect.getsource(_quadrature_gk21))
products=0
for job in plan['jobs']:
 l,n=job['level']['lmax'],job['level']['nmu'];N=2*len(u)
 job['products']=4*n*(l-1)+6*144*(l-1)+N*(24*n*(l-1)+6*144*(l-1)+16*12*n)
 products+=job['products']
plan.update(schema='D3_DISTANCE_GK21_REFERENCE_WAVE_0',rules_file=str((out/'rules.npz').relative_to(R)),rules_sha256=sha(out/'rules.npz'),u_nodes_per_scale=len(u),new_full_four_channel_nodes=2*len(u),real_products=products,reference_nodes_remaining_after_wave=1152-2*len(u),prior_distance_products=json.loads(old.read_text())['real_products'],scope='First adaptive GK21 wave in u; convergence and comparison pending',bindings={str(p.relative_to(R)):sha(p) for p in [Path(__file__),old,R/'src/inference/orf_blas.py',R/'configs/calibration/prior_predictive_500_v1.json']})
assert products+plan['prior_distance_products']+132021670800<60_000_000_000_000
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(nodes=2*len(u),products=products,remaining_reference_nodes=plan['reference_nodes_remaining_after_wave'],new_likelihood_values=0)))
