"""Audit direct responses and compare initial density rules; no quantile claim."""
from pathlib import Path
import os,sys,json,hashlib,time,resource,math,traceback
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
H=Path(__file__).resolve().parent;R=H.parents[1];D=R/'tmp/c09_D3_components_v1'
sys.path[:0]=[str(D),str(R/'src'),str(R/'tmp/c09_nominal14_v2'),str(R/'tmp/c09_nominal14_v4'),str(R/'tmp/c09_D2_components_v1'),str(R/'tmp/c09_D2_continuation_v3')]
import numpy as np
from scipy.special import logsumexp
from scenarios import ScenarioCovariance
from inference.model import experiment
from pta.statistics import quadratic_moments
from runtime_adapter import load_table
from kernel_group import KernelGroup
from backend_checks import scipy_loglike
from budget import Budget
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def scalar(x):
 if isinstance(x,np.generic):return x.item()
 raise TypeError('unsupported JSON object')
def write(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False,default=scalar)+'\n')
out=H/'initial_execution';out.mkdir(exist_ok=False);start=time.process_time();wall=time.monotonic()
plan=read(H/'prepared/plan.json');summary=read(H/'backend_execution/summary.json');assert summary['all_jobs_completed']
stages=np.empty((3,2,plan['u_nodes_per_scale'],4,12,12),complex);products=0;cpu=0;rss=0
for job in plan['jobs']:
 path=H/'backend_execution'/job['name'];receipt=read(path/'receipt.json');assert receipt['status']=='COMPLETED' and sha(path/'matrices.npz')==receipt['matrix_sha256']
 products+=receipt['products'];cpu+=receipt['CPU'];rss=max(rss,receipt['RSS'])
 with np.load(path/'matrices.npz',allow_pickle=False) as f:stages[job['level_index'],:,:,job['channel']]=f['Gamma']
assert products==plan['real_products']==summary['products']
delta_nodes=np.max(abs(stages[1]-stages[0]),axis=(-2,-1));delta_ell=np.max(abs(stages[2]-stages[1]),axis=(-2,-1));minimum=float(np.linalg.eigvalsh(stages).min())
passed=float(delta_nodes.max())<=1e-8 and float(delta_ell.max())<=1e-8 and minimum>=-1e-12
audit=dict(passed=passed,max_nodes_delta=float(delta_nodes.max()),max_ell_delta=float(delta_ell.max()),minimum_eigenvalue=minimum,products=products,worker_CPU=cpu,maximum_worker_RSS=rss,new_nodes=2*plan['u_nodes_per_scale'],scope='finite density-rule nodes only; no uniform interpolation certificate')
write(out/'response_audit.json',audit)
assert passed,'density-node response refinements failed; no likelihood started'
gamma=stages[2].copy();del stages
np.savez_compressed(out/'responses.npz',Gamma=gamma,nodes_error=delta_nodes,ell_error=delta_ell)
curves=[dict(curve_id=f'd{i}_{model}',data_id=i,analysis=model,eta_physical_coordinates=[-15.,13/3,-15.5,0.],analysis_contaminant_ratio=0.,observation_field='q' if model=='A0_CN' else ('x_gaussian' if model=='B_G_full_variable' else 'x_physical'),additional_likelihood_cap=3*plan['u_nodes_per_scale']+9) for i in (13,14) for model in plan['models']]
names=[c['curve_id'] for c in curves]
class Guard:
 config={'estimated_numeric_bytes':1024**3}
 def check(self):
  if time.process_time()-start>60 or time.monotonic()-wall>90:raise RuntimeError('initial-rule time cap')
  if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>int(1.5*1024**3):raise RuntimeError('initial-rule RSS cap')
guard=Guard();budget=Budget(curves,additional_cap=18*plan['u_nodes_per_scale']+54,historical_values=5783577,checkpoint=guard.check)
write(out/'plan.json',dict(curves=curves,LL_cap=18*plan['u_nodes_per_scale']+54,CPU_cap=60,source_sha256=sha(Path(__file__)),rules_sha256=plan['rules_sha256'],response_sha256=sha(out/'responses.npz'),scope='GL32/64 density diagnostics only; quantiles/W1/events/independent adaptive reference pending'))
results=[];checks=[];status='FAILED';error=None
try:
 nominal=read(R/'tmp/c09_nominal14_v4/config.json');e=experiment(read(R/nominal['experiment_config']))
 with np.load(D/'backend_continuation/data.npz',allow_pickle=False) as f:data={k:f[k] for k in ('q','x_physical','x_gaussian')}
 with np.load(H/'prepared/rules.npz',allow_pickle=False) as f:rules={k:f[k] for k in f.files}
 u=rules['u'];table=load_table(R/nominal['table_file'],nominal['table_sha256'],guard,expected_shape=(8336,4,12,12));anchor=table(np.array([.5]))[0]
 group=KernelGroup(curves,data,covariance=ScenarioCovariance(e,curves[0]['eta_physical_coordinates'],ratio=0.),moments=lambda C:quadratic_moments(C,e['H']),weights=e['weights'],anchor_gamma=anchor,budget=budget)
 components=np.empty((3,len(u),len(names)))
 for s,scale in enumerate((.9,1.,1.1)):
  for first in range(0,len(u),16):
   g=table(u[first:first+16]) if scale==1. else gamma[0 if scale==.9 else 1,first:first+16]
   values=group.evaluate_gamma(g,names,reason='grid')
   for j,name in enumerate(names):components[s,first:first+len(g),j]=values[name]
  for j,c in enumerate(curves):
   for index in (0,len(u)//2,len(u)-1):
    g=table(u[index:index+1])[0] if scale==1. else gamma[0 if scale==.9 else 1,index]
    reservation=budget.reserve([c['curve_id']],1,reason='scipy_reference');success=False
    try:ref=scipy_loglike(group,c,g,e['H'],anchor);success=True
    finally:budget.complete(reservation,success=success)
    delta=abs(ref-components[s,index,j]);checks.append(dict(curve=c['curve_id'],scale=scale,u=float(u[index]),delta=delta))
 if max(x['delta'] for x in checks)>1e-8:raise ArithmeticError('independent normalized component density check failed')
 # Every component already represents ALL frequencies or the full compressed B
 # vector. A single global scale is marginalized outside this likelihood.
 mixture=logsumexp(components+np.log(np.array([.25,.5,.25]))[:,None,None],axis=0)
 np.savez_compressed(out/'likelihoods.npz',u=u,component_logL=components,mixture_logL=mixture)
 status='COMPLETED_REFERENCE_DENSITIES'
except Exception:error=traceback.format_exc();print(error,flush=True)
finally:
 receipt=dict(status=status,error=error,budget=budget.report(),CPU=time.process_time()-start,wall=time.monotonic()-wall,RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,C09_complete=False)
 write(out/'receipt.json',receipt);print(json.dumps({k:v for k,v in receipt.items() if k!='budget'},default=scalar),flush=True)
if status!='COMPLETED_REFERENCE_DENSITIES':sys.exit(1)
