"""Independent cached GK21 in u, own normalizers and adaptive error diagnostics."""
from pathlib import Path
import json,math
import numpy as np
from scipy.integrate._quad_vec import _quadrature_gk21
H=Path(__file__).resolve().parent;R=H.parents[1]
def read(p):return json.loads(p.read_text())
plan=read(H/'prepared/plan.json')
panels=np.array(plan['active_panels'])
lookup={}
for rel in plan['reference_wave_paths']:
 with np.load(R/rel/'initial_execution/likelihoods.npz') as f:
  u=f['u'];ell=np.stack((f['component_logL'][1],f['mixture_logL']),axis=-1).reshape(len(u),12)
 for x,v in zip(u,ell):
  key=float(x).hex()
  if key in lookup:assert np.array_equal(lookup[key],v)
  lookup[key]=v
initial=read(R/'tmp/c09_D3_distances_v1/initial_execution/results.json')
shift=np.array([r['summaries'][1]['logZ'] for r in initial])
integrals=[];errors=[]
for a,b in panels:
 values=[];err=[]
 for j in range(12):
  def fun(x):
   log=lookup[float(x).hex()][j]-shift[j];p=math.exp(log)
   return p*np.array([1.,x,x*x,log])
  q,e,rounding=_quadrature_gk21(a,b,fun,lambda v:float(np.max(abs(v))))
  values.append(q);err.append(e)
 integrals.append(values);errors.append(err)
integrals=np.array(integrals);errors=np.array(errors);total=integrals.sum(axis=0);z=total[:,0]
rows=[]
for j,r in enumerate(initial):
 ref=dict(logZ=float(shift[j]+np.log(z[j])),mean=float(total[j,1]/z[j]),second=float(total[j,2]/z[j]),KL=float(total[j,3]/z[j]-np.log(z[j])),CDF_at_panel_edges=[float(integrals[panels[:,1]<=cut,j,0].sum()/z[j]) for cut in (0.,.0001,.001,.01,.05,.25,.5,.75,.9,.99,1.)])
 a=r['summaries'][1];delta={k:abs(a[k]-ref[k]) for k in ('logZ','mean','second','KL')};delta['CDF']=max(abs(x-y) for x,y in zip(a['CDF_at_panel_edges'],ref['CDF_at_panel_edges']))
 rows.append(dict(curve=r['curve'],mode=r['mode'],reference=ref,deltas_GL64=delta,embedded_error_scaled=float(errors[:,j].sum()/z[j]),functional_agreement=all(delta[k]<=.001 for k in ('logZ','mean','second','KL')) and delta['CDF']<=.002,status='ADAPTIVE_REFINEMENT_PENDING',quantiles=None,W1=None))
priority=np.max(errors/z[None,:],axis=1)
out=dict(results=rows,panels=panels.tolist(),panel_priority=priority.tolist(),next_split_panel=int(np.argmax(priority)),all_functional_agreements=all(r['functional_agreement'] for r in rows),max_embedded_error=max(r['embedded_error_scaled'] for r in rows),new_likelihood_values=0,reference_complete=False)
(H/'initial_execution/integrals.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('results','panels','panel_priority')},indent=2))
