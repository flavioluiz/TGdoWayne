"""Analytic checks of node replay, column order, own normalizers and CDF cuts."""
import unittest
import numpy as np
from scipy.integrate._quad_vec import _quadrature_gk21
from scipy.integrate import quad
class CachedGKTests(unittest.TestCase):
 def test_distinct_densities_moments_information_and_cdf(self):
  edges=[0,.0001,.001,.01,.05,.25,.5,.75,.9,.99,1];lookup={}
  for a,b in zip(edges[:-1],edges[1:]):
   def sample(x):
    lookup[float(x).hex()]=np.array([2*x,-3*x]);return np.ones(2)
   _quadrature_gk21(a,b,sample,np.linalg.norm)
  for j,t in enumerate((2.,-3.)):
   parts=[]
   for a,b in zip(edges[:-1],edges[1:]):
    def f(x):
     ell=lookup[float(x).hex()][j];return np.exp(ell)*np.array([1.,x,x*x,ell])
    parts.append(_quadrature_gk21(a,b,f,np.linalg.norm)[0])
   q=np.sum(parts,axis=0)
   ref=np.array([quad(lambda x:np.exp(t*x)*v(x),0,1,epsabs=1e-12)[0] for v in (lambda x:1.,lambda x:x,lambda x:x*x,lambda x:t*x)])
   np.testing.assert_allclose(q,ref,rtol=0,atol=1e-12)
   self.assertLess(abs(sum(z[0] for z,b in zip(parts,edges[1:]) if b<=.5)/q[0]-np.expm1(t*.5)/np.expm1(t)),1e-12)
   self.assertLess(abs(q[3]/q[0]-np.log(q[0])-(ref[3]/ref[0]-np.log(ref[0]))),1e-12)
 def test_missing_nodes_are_not_interpolated(self):
  with self.assertRaises(KeyError):
   _quadrature_gk21(0.,1.,lambda x:{}[float(x).hex()],np.linalg.norm)
if __name__=='__main__':unittest.main(verbosity=2)
