"""Adaptively split four highest-error panels; preserve the frozen reserve."""
from pathlib import Path
import os,sys,json,hashlib
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
H=Path(__file__).resolve().parent;R=H.parents[1]
import numpy as np
from scipy.integrate._quad_vec import _quadrature_gk21
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
number=int(H.name.rsplit('v',1)[1]);prev=H.with_name('c09_D3_distance_reference_v'+str(number-1))
prior=read(prev/'prepared/plan.json');integrals=read(prev/'initial_execution/integrals.json')
assert read(prev/'initial_execution/receipt.json')['status']=='COMPLETED_REFERENCE_DENSITIES'
out=H/'prepared';out.mkdir(exist_ok=False)
selected=set(np.argsort(integrals['panel_priority'])[-4:].tolist());panels=[];active=[];nodes=[]
for i,(a,b) in enumerate(integrals['panels']):
 if i not in selected:active.append([a,b]);continue
 mid=(a+b)/2
 for lo,hi in ((a,mid),(mid,b)):
  panels.append([lo,hi]);active.append([lo,hi]);local=[]
  _quadrature_gk21(lo,hi,lambda u:(local.append(u) or np.array([1.,u,u*u])),np.linalg.norm)
  assert len(local)==21;nodes.extend(local)
u=np.unique(nodes);assert len(u)==168
np.savez_compressed(out/'rules.npz',u=u,panels=np.array(panels))
plan=prior.copy();products=0
for job in plan['jobs']:
 l,n=job['level']['lmax'],job['level']['nmu'];N=2*len(u)
 job['products']=4*n*(l-1)+6*144*(l-1)+N*(24*n*(l-1)+6*144*(l-1)+16*12*n);products+=job['products']
previous_LL=18*prior['u_nodes_per_scale']+54
plan.update(schema='D3_DISTANCE_ADAPTIVE_GK21_WAVE_'+str(number-1),rules_file=str((out/'rules.npz').relative_to(R)),rules_sha256=sha(out/'rules.npz'),u_nodes_per_scale=len(u),new_full_four_channel_nodes=2*len(u),real_products=products,reference_nodes_remaining_after_wave=prior['reference_nodes_remaining_after_wave']-2*len(u),prior_distance_products=prior['prior_distance_products']+prior['real_products'],historical_likelihood_values=prior.get('historical_likelihood_values',5783577)+previous_LL,active_panels=active,split_previous_panel_indices=sorted(selected),reference_wave_paths=prior.get('reference_wave_paths',[str(prev.relative_to(R))])+[str(H.relative_to(R))],scope='Adaptive GK21 in u, direct physical densities; convergence pending',bindings={str(p.relative_to(R)):sha(p) for p in [Path(__file__),prev/'prepared/plan.json',prev/'initial_execution/integrals.json',R/'src/inference/orf_blas.py',R/'configs/calibration/prior_predictive_500_v1.json']})
assert plan['reference_nodes_remaining_after_wave']>=0
assert products+plan['prior_distance_products']+132021670800<60_000_000_000_000
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(nodes=2*len(u),products=products,remaining_reference_nodes=plan['reference_nodes_remaining_after_wave'],split_panels=sorted(selected),new_likelihood_values=0)))
