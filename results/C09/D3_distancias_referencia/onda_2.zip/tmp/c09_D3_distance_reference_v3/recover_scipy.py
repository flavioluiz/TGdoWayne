"""Recover omitted SciPy records with 54 newly charged controls per wave."""
from pathlib import Path
import os,sys,json,time,hashlib
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
H=Path(__file__).resolve().parent;R=H.parents[1];D=R/'tmp/c09_D3_components_v1'
sys.path[:0]=[str(D),str(R/'src'),str(R/'tmp/c09_nominal14_v2'),str(R/'tmp/c09_nominal14_v4'),str(R/'tmp/c09_D2_components_v1'),str(R/'tmp/c09_D2_continuation_v3')]
import numpy as np
from scenarios import ScenarioCovariance
from inference.model import experiment
from pta.statistics import quadratic_moments
from runtime_adapter import load_table
from kernel_group import KernelGroup
from backend_checks import scipy_loglike
from budget import Budget
def read(p):return json.loads(p.read_text())
class Guard:
 config={'estimated_numeric_bytes':1024**3}
 def check(self):
  if time.process_time()-start>30:raise RuntimeError('recovery CPU cap')
start=time.process_time();guard=Guard();nominal=read(R/'tmp/c09_nominal14_v4/config.json');e=experiment(read(R/nominal['experiment_config']))
table=load_table(R/nominal['table_file'],nominal['table_sha256'],guard,expected_shape=(8336,4,12,12));anchor=table(np.array([.5]))[0]
with np.load(D/'backend_continuation/data.npz',allow_pickle=False) as f:data={k:f[k] for k in ('q','x_physical','x_gaussian')}
for number in (1,2,3):
 W=H.with_name('c09_D3_distance_reference_v'+str(number));out=W/'scipy_recovery';out.mkdir(exist_ok=False);begin=time.process_time()
 curves=read(W/'initial_execution/plan.json')['curves']
 for c in curves:c['additional_likelihood_cap']=9
 budget=Budget(curves,additional_cap=54,historical_values=5793567+54*(number-1),checkpoint=guard.check)
 group=KernelGroup(curves,data,covariance=ScenarioCovariance(e,curves[0]['eta_physical_coordinates'],ratio=0.),moments=lambda C:quadratic_moments(C,e['H']),weights=e['weights'],anchor_gamma=anchor,budget=budget)
 with np.load(W/'initial_execution/responses.npz',allow_pickle=False) as f:gamma=f['Gamma']
 with np.load(W/'initial_execution/likelihoods.npz',allow_pickle=False) as f:u=f['u'];components=f['component_logL']
 checks=[]
 for s,scale in enumerate((.9,1.,1.1)):
  for j,c in enumerate(curves):
   for index in (0,len(u)//2,len(u)-1):
    g=table(u[index:index+1])[0] if scale==1. else gamma[0 if scale==.9 else 1,index]
    reservation=budget.reserve([c['curve_id']],1,reason='scipy_reference');success=False
    try:ref=scipy_loglike(group,c,g,e['H'],anchor);success=True
    finally:budget.complete(reservation,success=success)
    delta=abs(ref-components[s,index,j]);checks.append(dict(curve=c['curve_id'],scale=scale,u=float(u[index]),delta=float(delta)))
 assert max(c['delta'] for c in checks)<=1e-8
 result=dict(status='COMPLETED',reason='Original successful SciPy controls were not serialized; these are additional charged evaluations, not recovery of their unavailable values.',checks=checks,budget=budget.report(),CPU=time.process_time()-begin,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
 (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(number,len(checks),max(c['delta'] for c in checks))
