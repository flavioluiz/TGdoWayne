"""Bounded W1 pilot: saved D2 data2, ten priors, no new response bank/data."""
from pathlib import Path
import os,sys,json,hashlib,time,resource,traceback,math,argparse
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(HERE),str(ROOT/'tmp/c09_D2_components_v1'),str(ROOT/'tmp/c09_D2_continuation_v3'),str(ROOT/'src'),str(ROOT/'tmp/c09_nominal14_v2'),str(ROOT/'tmp/c09_nominal14_v4'),str(ROOT/'tmp/c09_event_repair_v1')]
import numpy as np
from reference import integrate
from priors import PriorMeasure
from posterior_table import PosteriorTable,wasserstein_to_prior
from inference.model import experiment
from pta.statistics import quadratic_moments
from kernels import FixedNuisanceCovariance
from runtime_adapter import load_table
from kernel_group import KernelGroup
from budget import Budget
from cache import key
from d1.grid import event_grid,exact_union
from d1.measure import Prior

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--curve',default='baseline_d2');parser.add_argument('--output',default='pilot_execution');parser.add_argument('--cap',type=int,default=20000);parser.add_argument('--history',type=int,default=760969);args=parser.parse_args()
 if not 1<=args.cap<=20000:raise ValueError('per-curve cap must be within 20000')
 out=HERE/args.output;out.mkdir(exist_ok=False)
 start=time.process_time();wall=time.monotonic();bindings={};values={};budget=None;records=[]
 class Guard:
  config={'estimated_numeric_bytes':1024**3}
  def check(self):
   if time.process_time()-start>90 or time.monotonic()-wall>180:raise RuntimeError('pilot CPU90/wall180 cap')
   if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>int(1.5*1024**3):raise RuntimeError('pilot RSS1.5GiB cap')
 guard=Guard()
 manifest=read(ROOT/'results/C09/D2_continuacao/manifest.json')
 indexed={x['path']:x['sha256'] for x in manifest['files']}
 def checked(rel):
  p=ROOT/rel;h=sha(p)
  if rel in indexed and h!=indexed[rel]:raise ValueError('published input changed: '+rel)
  bindings[rel]=h;return p
 status='FAILED';error=None
 try:
  runtime=read(checked('tmp/c09_D2_continuation_v3/runtime_config.json'))
  nominal=read(checked(runtime['nominal_config']))
  row=next(r.copy() for r in runtime['curves'] if r['curve_id']==args.curve);name=row['curve_id']
  row['additional_likelihood_cap']=args.cap
  budget=Budget([row],additional_cap=args.cap,historical_values=args.history,checkpoint=guard.check)
  e=experiment(read(checked(nominal['experiment_config'])))
  table=load_table(checked(nominal['table_file']),nominal['table_sha256'],guard,expected_shape=(8336,4,12,12))
  datafile=checked(runtime['data_file'])
  if sha(datafile)!='c3a0c6c1d9842143384782df9ceee0acde0d21ea161a9a336de123465f19fad6':raise ValueError('frozen data changed')
  with np.load(datafile,allow_pickle=False) as d:data={k:d[k] for k in ('q','x_physical','x_gaussian')}
  group=KernelGroup([row],data,covariance=FixedNuisanceCovariance(e,row['eta_physical_coordinates'],contaminant_ratio=row['analysis_contaminant_ratio']),moments=lambda c:quadratic_moments(c,e['H']),weights=e['weights'],anchor_gamma=table(np.array([.5]))[0],budget=budget)
  cp=checked('tmp/c09_D2_continuation_execution_v3/worker/caches/'+name+'.npz')
  saved=read(checked('tmp/c09_D2_continuation_execution_v3/worker/results/'+name+'.json'))
  if not saved['finite_backend_evidence']['accepted_finite_domain'] or not saved['finite_backend_evidence']['new_curve_checks_passed']:raise ValueError('finite backend evidence missing')
  with np.load(cp,allow_pickle=False) as c:
   u=c['u'];ell=c['log_likelihood'];values=dict(zip(map(key,u),map(float,ell)))
  original=len(values)
  bridge_u=u[np.linspace(0,len(u)-1,3,dtype=int)]
  bridge=group.evaluate_gamma(table(bridge_u),[name],reason='cache_bridge_check')[name]
  delta=float(max(abs(v-values[key(x)]) for x,v in zip(bridge_u,bridge)))
  if delta>1e-10:raise ArithmeticError('cache bridge failed')
  def direct(points):
   guard.check();result=[]
   for x in points:
    k=key(x)
    if k not in values:values[k]=float(group.evaluate_gamma(table(np.array([x])),[name],reason='functional_reference')[name][0])
    result.append(values[k])
   return np.array(result)
  grid=event_grid(table.nodes,Prior('uniform_u'),validation_count=1)
  coarse=exact_union(grid['coarse_u'],np.array([0.,1e-4,.001,.01,.8,1.]))
  fine=exact_union(grid['fine_u'],np.array([0.,1e-4,.001,.01,.8,1.]))
  # Every representation value must already exist; no silent grid extension.
  lowell=np.array([values[key(x)] for x in coarse]);fineell=np.array([values[key(x)] for x in fine])
  shift=float(max(fineell));rs=saved['results'];ps=[PriorMeasure(**r['prior']) for r in rs]
  refs=[r['reference'] for r in rs];z=[r['denominator'] for r in refs];ez=[r['denominator_error_estimate'] for r in refs]
  if max(abs(shift+math.log(a)-r['logZ']) for a,r in zip(z,refs))>1e-12:raise ValueError('normalizer scaling differs')
  cuts=[r['cut_values'] for r in refs]
  write(out/'plan.json',dict(curve=name,bindings=bindings,CPU_cap=90,wall_cap=180,LL_cap=args.cap,W1_gate=.001,CDF_gate=.002,relative_Z_gate=.001,engineering_not_SBC=True,controls=[dict(rtol=1e-8,atol=1e-10,max_step=.01),dict(rtol=1e-9,atol=1e-11,max_step=.005)]))
  for controls in read(out/'plan.json')['controls']:
   result=integrate(direct,ps,z,ez,shift=shift,cuts=cuts,checkpoint=guard.check,**controls)
   records.append(result);write(out/('reference_'+str(len(records))+'.json'),result)
   print(json.dumps(dict(refinement=len(records),charged=budget.charged,CPU=time.process_time()-start)),flush=True)
  comparisons=[]
  for j,(p,r) in enumerate(zip(ps,rs)):
   guard.check();low=PosteriorTable(coarse,lowell,p,order=16);high=PosteriorTable(fine,fineell,p,order=32)
   w=[wasserstein_to_prior(low,order=12),wasserstein_to_prior(high,order=12),wasserstein_to_prior(high,order=24)]
   a,b=[x['results'][j] for x in records]
   err=max(abs(w[0]-w[2]),abs(w[1]-w[2]),abs(a['W1']-b['W1']),abs(w[2]-b['W1']))+b['normalizer_uncertainty_sensitivity']
   cdf=max(float(np.max(abs(np.array(x['cdf'])-refs[j]['cdf']))) for x in (a,b))
   zd=max(x['normalization_relative_discrepancy'] for x in (a,b))
   passed=err<=.001 and cdf<=.002 and zd<=.001
   comparisons.append(dict(prior_id=r['prior_id'],W1=w[2],W1_direct=b['W1'],operational_delta=err,CDF_delta=cdf,relative_Z_delta=zd,status='PASS_FINITE_DOMAIN_OPERATIONAL' if passed else 'UNRESOLVED',not_uniform_physical_bound=True))
   write(out/'comparisons.json',comparisons)
  status='COMPLETED'
 except Exception as exc:
  error=traceback.format_exc();print(error,flush=True)
 finally:
  if values:
   ordered=sorted((float(np.frombuffer(bytes.fromhex(k),dtype=np.float64)[0]),v) for k,v in values.items())
   np.savez_compressed(out/'cache.npz',u=np.array([x[0] for x in ordered]),log_likelihood=np.array([x[1] for x in ordered]))
  write(out/'receipt.json',dict(status=status,error=error,bindings=bindings,budget=None if budget is None else budget.report(),CPU=time.process_time()-start,wall=time.monotonic()-wall,RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,completed_references=len(records),C09_complete=False))
 if status!='COMPLETED':sys.exit(1)

if __name__=='__main__':main()
