"""Analytic W1 controls with no physical inputs."""
from pathlib import Path
import os,sys,unittest,math,json
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
ROOT=Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT/'tmp/c09_D2_components_v1'))
import numpy as np
from priors import PriorMeasure
from reference import integrate


class W1Tests(unittest.TestCase):
    def measures(self):
        return [PriorMeasure(k,a,b) for b in (1.,.8) for k,a in
                [('uniform_u',0.),('uniform_u_squared',0.),('log_uniform_u',.0001),
                 ('log_uniform_u',.001),('log_uniform_u',.01)]]

    def test_constant_likelihood_ten_proper_measures(self):
        priors=self.measures();cuts=[p.ppf([0.,.2,.8,1.]) for p in priors]
        r=integrate(lambda u:np.full(len(u),-17.),priors,np.ones(10),np.zeros(10),shift=-17.,cuts=cuts)
        for p,row in zip(priors,r['results']):
            self.assertLess(row['W1'],1e-8)
            np.testing.assert_allclose(row['cdf'],p.cdf(row['cuts']),atol=2e-8,rtol=0)
        json.dumps(r,allow_nan=False)

    def test_linear_tilt_equals_exact_mean_shift_for_every_measure(self):
        priors=self.measures();moments=[p.moments() for p in priors]
        z=[1+m['mean'] for m in moments]
        result=integrate(np.log1p,priors,z,np.zeros(10),shift=0.,cuts=[p.ppf([0.,.5,1.]) for p in priors])
        for m,row in zip(moments,result['results']):
            expected=(m['second']-m['mean']**2)/(1+m['mean'])
            self.assertAlmostEqual(row['W1'],expected,places=8)
            self.assertLess(row['normalization_relative_discrepancy'],1e-8)

    def test_multiple_cdf_crossings_absolute_integral(self):
        p=PriorMeasure('uniform_u',0.,1.)
        for cycles in (1,7):
            result=integrate(lambda u:np.log1p(.8*np.cos(2*np.pi*cycles*u)),[p],[1.],[0.],
                shift=0.,cuts=[np.linspace(0,1,19)],max_step=.01)
            self.assertAlmostEqual(result['results'][0]['W1'],.8/(math.pi**2*cycles),places=7)

    def test_normalizer_uncertainty_is_retained_and_invalid_input_rejected(self):
        p=PriorMeasure('uniform_u',0.,1.)
        result=integrate(lambda u:np.zeros(len(u)),[p],[1.],[.0001],shift=0.,cuts=[[0.,1.]])
        self.assertGreater(result['results'][0]['normalizer_uncertainty_sensitivity'],.0001)
        with self.assertRaises(ValueError):integrate(lambda u:u,[p],[1.],[1.],shift=0.,cuts=[[0.,1.]])
        with self.assertRaises(ValueError):integrate(lambda u:u,[p],[1.],[0.],shift=0.,cuts=[[1.1]])


if __name__=='__main__':unittest.main()
