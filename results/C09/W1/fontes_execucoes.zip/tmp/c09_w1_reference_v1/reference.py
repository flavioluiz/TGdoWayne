"""Independent W1 reference by coupled cumulative-mass ODEs in alpha=asin(u).

No posterior interpolant is used. The caller supplies direct log-likelihoods,
independently determined normalizers, and accounting for every fresh evaluation.
Solver tolerances are operational controls, not rigorous probability bounds.
"""
import math
import numpy as np
from scipy.integrate import solve_ivp


def integrate(loglike,priors,normalizers,errors,*,shift,cuts,rtol=1e-10,atol=1e-12,max_step=.02,checkpoint=lambda:None):
    n=len(priors);z=np.asarray(normalizers,float);ez=np.asarray(errors,float)
    if (not n or len(cuts)!=n or z.shape!=(n,) or ez.shape!=(n,)
        or not np.isfinite(z).all() or not np.isfinite(ez).all()
        or np.any(ez<0) or np.any(z<=ez) or not math.isfinite(shift)):
        raise ValueError('proper independent normalizers and per-prior cuts required')
    if not (1e-12<=rtol<=1e-5 and 1e-14<=atol<=1e-7 and 0<max_step<=.1):
        raise ValueError('bounded explicit integration controls required')
    cutarrays=[np.asarray(c,float) for c in cuts]
    for p,c in zip(priors,cutarrays):
        if c.ndim!=1 or not np.isfinite(c).all() or np.any((c<p.lower)|(c>p.upper)):
            raise ValueError('cuts must be within their own prior support')
    edges=np.unique(np.concatenate(cutarrays+[np.array([p.lower,p.upper]) for p in priors]))
    state=np.zeros(2*n);states={float(edges[0]):state.copy()};queries=0;steps=0
    for left,right in zip(edges[:-1],edges[1:]):
        checkpoint();active=[i for i,p in enumerate(priors) if p.lower<=(left+right)/2<=p.upper]
        if not active:states[float(right)]=state.copy();continue
        al,ar=math.asin(left),math.asin(right)
        def rhs(alpha,y):
            nonlocal queries
            checkpoint();u=math.sin(alpha)
            raw=np.asarray(loglike(np.array([u])),float);queries+=1
            if raw.shape!=(1,) or not np.isfinite(raw).all():raise ArithmeticError('finite direct logL required')
            ell=float(raw[0])-shift
            if ell>700:raise ArithmeticError('reference scaling insufficient')
            derivative=np.zeros(2*n)
            cosine=0. if alpha==math.pi/2 else math.cos(alpha)
            for j in active:
                p=priors[j]
                a=min(math.asin(p.upper),max(math.asin(p.lower),alpha))
                derivative[j]=math.exp(ell+float(p.alpha_logpdf(a)))
                derivative[n+j]=abs(y[j]/z[j]-float(p.cdf(u)))*cosine
            return derivative
        solved=solve_ivp(rhs,(al,ar),state,method='DOP853',rtol=rtol,atol=atol,max_step=max_step)
        if not solved.success or not np.isfinite(solved.y).all():raise ArithmeticError('W1 ODE failed')
        state=solved.y[:,-1];steps+=len(solved.t)-1;states[float(right)]=state.copy()
    results=[]
    for j,p in enumerate(priors):
        mass=float(states[float(p.upper)][j]);w=float(state[n+j])
        if mass<=0 or w<0:raise ArithmeticError('invalid integrated mass or W1')
        cdf=[float(states[float(u)][j]/z[j]) for u in cutarrays[j]]
        results.append(dict(W1=w,normalizer_from_ODE=mass,
            normalization_relative_discrepancy=abs(mass-z[j])/z[j],
            normalizer_uncertainty_sensitivity=(p.upper-p.lower)*max(mass,z[j]+ez[j])*ez[j]/(z[j]*(z[j]-ez[j])),
            cuts=cutarrays[j].tolist(),cdf=cdf))
    return dict(results=results,callback_queries=queries,accepted_steps=steps,
                method='DOP853_COUPLED_CUMULATIVE_MASS_AND_W1',rtol=rtol,atol=atol,max_step=max_step,
                error_scope='operational ODE/refinement and supplied normalizer errors; no rigorous uniform physical bound')
