"""Sequential capped extension of the successful ten-prior W1 pilot."""
from pathlib import Path
import subprocess,sys,json,hashlib
H=Path(__file__).resolve().parent;R=H.parents[1]
out=H/'remaining_execution';out.mkdir(exist_ok=False)
runtime=json.loads((R/'tmp/c09_D2_continuation_v3/runtime_config.json').read_text())
curves=[r['curve_id'] for r in runtime['curves'] if r['curve_id']!='baseline_d2']
plan=dict(curves=curves,LL_cap=120000,CPU_cap=180,per_curve_LL_cap=20000,per_curve_CPU_cap=90,
          pilot_excluded_from_new_budget=True,historical_values=771563,engineering_not_SBC=True,
          W1_gate=.001,CDF_gate=.002,relative_Z_gate=.001,C09_complete=False,
          sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in H.glob('*.py')})
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
charged=0;cpu=0.;receipts=[]
for curve in curves:
 if charged>=120000 or cpu+90>180:break
 dest='remaining_execution/'+curve
 run=subprocess.run([sys.executable,str(H/'pilot.py'),'--curve',curve,'--output',dest,'--cap',str(min(20000,120000-charged)),'--history',str(771563+charged)],timeout=200)
 receipt=json.loads((H/dest/'receipt.json').read_text())
 charged+=receipt['budget']['additional_charged_values'];cpu+=receipt['CPU']
 receipts.append(dict(curve=curve,returncode=run.returncode,receipt=dest+'/receipt.json'))
 (out/'summary.json').write_text(json.dumps(dict(receipts=receipts,charged=charged,CPU=cpu,cumulative_values=771563+charged,all_curves_attempted=len(receipts)==len(curves),C09_complete=False),indent=2)+'\n')
