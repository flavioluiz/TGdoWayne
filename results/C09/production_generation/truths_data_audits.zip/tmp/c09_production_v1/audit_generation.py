"""Reconstruct every production datum using whitened quadratic operators."""
from pathlib import Path
import os,sys,json,hashlib,time,resource
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
H=Path(__file__).resolve().parent;R=H.parents[1]
sys.path[:0]=[str(R/'src'),str(R/'tmp/c09_D3_components_v1'),str(R/'tmp/c09_nominal14_v2')]
import numpy as np
from inference.model import experiment
from scenarios import ScenarioCovariance
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
receipt=read(H/'generation/receipt.json');assert receipt['status']=='COMPLETED_PRODUCTION_OBSERVATIONS' and receipt['datasets_generated']==5396
for rel,h in read(H/'generation/activation.json')['source_sha256'].items():assert sha(R/rel)==h
for f in receipt['files']:assert sha(H/'generation'/f['path'])==f['sha256']
start=time.process_time();e=experiment(read(R/'configs/calibration/prior_predictive_500_v1.json'));rows=read(H/'prepared/rows.json');index=read(H/'generation/inference_index.json')
assert len(index)==len(rows)==5396 and {r['id'] for r in rows}=={r['id'] for r in index}
assert all('truth_u' not in r and 'distance_scale' not in r and 'latent_seed' not in r for r in index)
with np.load(H/'response_audit/truth_responses.npz',allow_pickle=False) as f:gamma=f['Gamma'];u=f['u'];scales=f['distance_scale']
anchor=gamma[np.flatnonzero((u==.5)&(scales==1.))[0]];covariances={};anchors={};checks=[];max_abs=0.;max_scaled=0.;files=[]
def moments(C):
 # Whitened operators F† H F, rather than the generator's H C contractions.
 F=np.linalg.cholesky(C);D=F.conj().swapaxes(-1,-2)[:,None]@e['H'][None]@F[:,None]
 mean=np.trace(D,axis1=-2,axis2=-1).real
 covariance=np.sum(D[:,:,None]*D[:,None].swapaxes(-1,-2),axis=(-2,-1)).real
 return F,mean,covariance
for stage in range(1,8):
 with np.load(H/f'generation/stage_{stage}.npz',allow_pickle=False) as f:data={k:f[k] for k in f.files}
 selected=[r for r in rows if r['stage_id']==stage];assert data['ids'].tolist()==[r['id'] for r in selected]
 for j,row in enumerate(selected):
  if time.process_time()-start>180:raise RuntimeError('independent generation audit CPU cap')
  i=row['truth_response_index'];assert u[i]==row['truth_u'] and scales[i]==row['distance_scale'];key=(tuple(row['eta']),row['kind'] if stage==5 else 'monopole_rank1',row.get('contaminant_ratio',0.))
  if key not in covariances:covariances[key]=ScenarioCovariance(e,row['eta'],kind=key[1],ratio=key[2])
  cov=covariances[key];F,mu,sigma=moments(cov(gamma[i][None])[0]);rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence(row['data_seed'])))
  if stage==2:
   mean=sum(e['weights'][k]*mu[k] for k in range(4));var=sum(e['weights'][k]**2*sigma[k] for k in range(4))
   if row['variant'].endswith('_fixed'):
    if key not in anchors:
     _,_,a=moments(cov(anchor[None])[0]);anchors[key]=sum(e['weights'][k]**2*a[k] for k in range(4))
    var=anchors[key]
   if row['variant'].startswith('diagonal_'):var=np.diag(np.diag(var))
   expected=mean+np.linalg.cholesky(var)@rng.standard_normal(10);pairs=[(expected,data['B_gaussian'][j])]
  else:
   real=rng.standard_normal((1,4,12))[0];imag=rng.standard_normal((1,4,12))[0];z=(real+1j*imag)/np.sqrt(2)
   q=(F@z[...,None])[...,0]
   physical=np.array([[np.vdot(q[k],matrix@q[k]).real for matrix in e['H']] for k in range(4)])
   control=mu+(np.linalg.cholesky(sigma)@real[:,:10,None])[...,0]
   pairs=[(q,data['q'][j]),(physical,data['x_physical'][j]),(control,data['x_gaussian'][j])]
  absolute=max(float(np.max(abs(a-b))) for a,b in pairs);scaled=max(float(np.max(abs(a-b)))/(1+float(np.max(abs(b)))) for a,b in pairs)
  assert scaled<=1e-10,(row['id'],absolute,scaled)
  if stage==6:
   latent=np.random.Generator(np.random.PCG64(np.random.SeedSequence(row['latent_seed']))).choice([.9,1.,1.1],p=[.25,.5,.25]);assert latent==row['distance_scale'] and row['latent_seed']!=row['data_seed']
  max_abs=max(max_abs,absolute);max_scaled=max(max_scaled,scaled);checks.append(dict(id=row['id'],max_absolute_difference=absolute,max_scaled_difference=scaled))
out=dict(status='PASS',datasets_reconstructed=len(checks),maximum_absolute_error=max_abs,maximum_scaled_error=max_scaled,tolerance_scaled=1e-10,CPU=time.process_time()-start,RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,source_sha256=sha(Path(__file__)),generator_receipt_sha256=sha(H/'generation/receipt.json'),checks=checks,new_observations=0,new_likelihood_values=0,new_ORFs=0,posterior_calibration_performed=False)
(H/'generation/audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
