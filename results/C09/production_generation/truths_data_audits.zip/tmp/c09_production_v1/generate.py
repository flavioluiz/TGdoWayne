"""Generate all prospectively frozen observations after response audit passes."""
from pathlib import Path
import os,sys,json,hashlib,time,resource,traceback
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
H=Path(__file__).resolve().parent;R=H.parents[1]
sys.path[:0]=[str(R/'src'),str(R/'tmp/c09_D3_components_v1'),str(R/'tmp/c09_nominal14_v2'),str(R/'tmp/c09_D2_components_v1')]
import numpy as np
from inference.model import experiment
from pta.simulation import paired_physical_and_gaussian
from pta.statistics import quadratic_moments
from factorial import compressed_moments
from scenarios import ScenarioCovariance,draw_self_control
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
config=read(R/'configs/robustness/c09_production_v1.json')
for rel,h in config['production_inputs'].items():assert sha(R/rel)==h
response=read(H/'response_audit/receipt.json');assert response['passed'] and response['status']=='COMPLETED_TRUTH_RESPONSE_AUDIT'
assert sha(H/'response_audit/truth_responses.npz')==response['truth_response_sha256']
rows=read(H/'prepared/rows.json');assert len(rows)==5396
out=H/'generation';out.mkdir(exist_ok=False);start=time.process_time();wall=time.monotonic();status='FAILED';error=None;files=[];count=0
write(out/'activation.json',dict(source_sha256={str(p.relative_to(R)):sha(p) for p in [Path(__file__),R/'configs/robustness/c09_production_v1.json',H/'prepared/rows.json',H/'response_audit/truth_responses.npz',R/'src/pta/simulation.py',R/'src/pta/statistics.py',R/'tmp/c09_D3_components_v1/scenarios.py',R/'tmp/c09_D2_components_v1/factorial.py']},CPU_cap=180,wall_cap=240,RSS_cap=int(1.5*1024**3),maximum_datasets=5396,seed_policy='Frozen five-integer PCG64 SeedSequence per observation; shared CN/G normals retain the existing paired-control construction'))
def check():
 if time.process_time()-start>180 or time.monotonic()-wall>240:raise RuntimeError('generation CPU/wall cap')
 if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>int(1.5*1024**3):raise RuntimeError('generation RSS cap')
try:
 e=experiment(read(R/'configs/calibration/prior_predictive_500_v1.json'))
 with np.load(H/'response_audit/truth_responses.npz',allow_pickle=False) as f:gamma=f['Gamma'];u=f['u'];scales=f['distance_scale']
 anchor=gamma[np.flatnonzero((u==.5)&(scales==1.))[0]]
 covariance_cache={};anchor_cache={};index=[]
 for stage in range(1,8):
  selected=[r for r in rows if r['stage_id']==stage];ids=[];qs=[];xs=[];gs=[];bs=[]
  for row in selected:
   check();i=row['truth_response_index'];assert u[i]==row['truth_u'] and scales[i]==row['distance_scale'];key=(tuple(row['eta']),row.get('kind') if stage==5 else 'monopole_rank1',row.get('contaminant_ratio',0.))
   if key not in covariance_cache:covariance_cache[key]=ScenarioCovariance(e,row['eta'],kind=key[1],ratio=key[2])
   cov=covariance_cache[key];C=cov(gamma[i][None])[0];rng=np.random.Generator(np.random.PCG64(np.random.SeedSequence(row['data_seed'])))
   if stage==2:
    m,s=quadratic_moments(C[None],e['H']);mu,var=compressed_moments(m,s,e['weights'])
    if key not in anchor_cache:
     a,b=quadratic_moments(cov(anchor[None]),e['H']);anchor_cache[key]=compressed_moments(a,b,e['weights'])[1][0]
    bs.append(draw_self_control(mu[0],var[0],anchor_cache[key],row['variant'],rng))
   else:
    q,x,g=paired_physical_and_gaussian(C,e['H'],1,rng);qs.append(q[0]);xs.append(x[0]);gs.append(g[0])
   ids.append(row['id']);index.append(dict(id=row['id'],file=f'stage_{stage}.npz',row=len(ids)-1,data_space='B10' if stage==2 else 'four_frequency_CN_and_paired_G10',stage_id=stage,prior_id=row['prior_id'],scenario_id=row['scenario_id'],datum_id=row['datum_id'],models=row['models'],eta=row['eta'],prior=row['prior'],kind=row['kind'],**({'variant':row['variant']} if stage==2 else {}),**({'contaminant_ratio':row['contaminant_ratio']} if stage==5 else {})))
   count+=1
  arrays=dict(ids=np.array(ids),B_gaussian=np.array(bs)) if stage==2 else dict(ids=np.array(ids),q=np.array(qs),x_physical=np.array(xs),x_gaussian=np.array(gs))
  path=out/f'stage_{stage}.npz';np.savez_compressed(path,**arrays);assert path.stat().st_size<=90*1024**2
  files.append(dict(path=path.name,sha256=sha(path),datasets=len(ids)));write(out/'progress.json',dict(datasets_generated=count,files=files));check()
 write(out/'inference_index.json',index);assert len(index)==5396 and all('truth_u' not in r and 'distance_scale' not in r and 'latent_seed' not in r for r in index)
 status='COMPLETED_PRODUCTION_OBSERVATIONS'
except Exception:error=traceback.format_exc();print(error,flush=True)
finally:
 receipt=dict(status=status,error=error,datasets_generated=count,CPU=time.process_time()-start,wall=time.monotonic()-wall,RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,new_ORF_nodes=0,new_likelihood_values=0,files=files,posteriors_evaluated=0,C09_complete=False)
 write(out/'receipt.json',receipt);print(json.dumps(receipt,indent=2),flush=True)
if status!='COMPLETED_PRODUCTION_OBSERVATIONS':sys.exit(1)
