"""Merge all checked truth batches and the three previously checked fixed nodes."""
from pathlib import Path
import json,hashlib,time,resource
import numpy as np
H=Path(__file__).resolve().parent;R=H.parents[1];B=R/'tmp/c09_production_truth_backend_v2'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
summary=read(B/'backend_execution/summary.json');assert summary['all_jobs_completed']
plan=read(B/'prepared/plan.json');activation=read(B/'backend_execution/activation.json')
assert sha(B/'prepared/plan.json')==activation['plan_sha256'] and sha(B/'worker.py')==activation['worker_sha256']
for rel,h in plan['bindings'].items():assert sha(R/rel)==h
out=H/'response_audit';out.mkdir(exist_ok=False);start=time.process_time()
N=plan['new_full_four_channel_nodes'];stages=np.empty((3,N,4,12,12),complex);covered=np.zeros((3,4,N),int);cost=0;cpu=0.;rss=0
for job in plan['jobs']:
 p=B/'backend_execution'/job['name'];r=read(p/'receipt.json');assert r['status']=='COMPLETED' and sha(p/'matrices.npz')==r['matrix_sha256']
 lo,hi=job['start'],job['stop'];j,k=job['level_index'],job['channel']
 with np.load(p/'matrices.npz',allow_pickle=False) as f:assert f['Gamma'].shape==(hi-lo,12,12);stages[j,lo:hi,k]=f['Gamma']
 covered[j,k,lo:hi]+=1;cost+=r['products'];cpu+=r['CPU'];rss=max(rss,r['RSS'])
assert np.all(covered==1) and cost==plan['real_products']==summary['products']
dn=np.max(abs(stages[1]-stages[0]),axis=(-2,-1));de=np.max(abs(stages[2]-stages[1]),axis=(-2,-1));eigen=float(np.linalg.eigvalsh(stages).min())
passed=bool(dn.max()<=1e-8 and de.max()<=1e-8 and eigen>=-1e-12)
result=dict(passed=passed,max_nodes=float(dn.max()),max_ell=float(de.max()),minimum_eigenvalue=eigen,products=cost,worker_CPU=cpu,max_worker_RSS=rss,new_nodes=N,reused_nodes=len(plan['reused_fixed_nodes']),scope='Finite generating truths; no posterior interpolation or SBC acceptance')
(out/'response_audit.json').write_text(json.dumps(result,indent=2)+'\n');assert passed
with np.load(H/'prepared/truths.npz',allow_pickle=False) as f:u=f['u'];scales=f['distance_scale']
with np.load(R/plan['rules_file'],allow_pickle=False) as f:indices=f['production_indices'];assert np.array_equal(f['u'],u[indices]) and np.array_equal(f['distance_scale'],scales[indices])
gamma=np.empty((len(u),4,12,12),complex);nodes=np.empty((len(u),4));ells=np.empty_like(nodes);gamma[indices]=stages[2];nodes[indices]=dn;ells[indices]=de
old=R/'tmp/c09_nominal14_backend_v4/gates/harmonic_nodes.npz'
with np.load(old,allow_pickle=False) as f:
 for item in plan['reused_fixed_nodes']:
  i,j=item['production_index'],item['old_index'];assert u[i]==f['u'][j] and scales[i]==1.
  gamma[i]=f['Gamma'][j];nodes[i]=f['errors_nodes'][j];ells[i]=f['errors_ell'][j]
np.savez_compressed(out/'truth_responses.npz',u=u,distance_scale=scales,Gamma=gamma,nodes_error=nodes,ell_error=ells)
result.update(status='COMPLETED_TRUTH_RESPONSE_AUDIT',controller_CPU=time.process_time()-start,controller_RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,truth_response_sha256=sha(out/'truth_responses.npz'),source_sha256=sha(Path(__file__)),new_likelihood_values=0,observations_generated=0)
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
