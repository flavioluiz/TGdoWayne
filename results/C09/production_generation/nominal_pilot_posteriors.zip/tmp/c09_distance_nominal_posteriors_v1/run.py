"""Six nominal-distance pilot analyses, primary and W1 controls; no altered-distance ORFs."""
from pathlib import Path
import os,sys,json,hashlib,time,resource,traceback,math
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
H=Path(__file__).resolve().parent;R=H.parents[1];D=R/'tmp/c09_D3_components_v1'
sys.path[:0]=[str(R/'tmp/c09_D3_w1_v1'),str(D),str(R/'src'),str(R/'tmp/c09_nominal14_v2'),str(R/'tmp/c09_nominal14_v4'),str(R/'tmp/c09_D2_components_v1'),str(R/'tmp/c09_D2_continuation_v3'),str(R/'tmp/c09_event_repair_v1')]
import numpy as np
from scenarios import ScenarioCovariance
from inference.model import experiment
from pta.statistics import quadratic_moments
from runtime_adapter import load_table
from kernel_group import KernelGroup
from backend_checks import check_new_functions
from budget import Budget
from cache import CacheSet,key
from engine import analyze_curve
from reference import integrate
from priors import PriorMeasure
from posterior_table import PosteriorTable,wasserstein_to_prior
from d1.grid import event_grid,exact_union
from d1.measure import Prior
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def scalar(x):
 if isinstance(x,np.generic):return x.item()
 raise TypeError('Unsupported JSON object')
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False,default=scalar)+'\n')

def main():
 out=H/'execution';out.mkdir(exist_ok=False);start=time.process_time();wall=time.monotonic();cache=None;error=None;status='FAILED';results=[];comparisons=[]
 rows=read(D/'backend_execution/plan.json')['rows']
 truth=read(D/'backend_execution/truths.json')['u']
 curves=[dict(curve_id=f'nominal_d{i}_{model}',data_id=i,analysis=model,eta_physical_coordinates=rows[i]['eta'],analysis_contaminant_ratio=0.,observation_field='q' if model=='A0_CN' else ('x_gaussian' if model=='B_G_full_variable' else 'x_physical'),fixed_truth_u=truth[i],additional_likelihood_cap=40000) for i in (13,14) for model in ('A0_CN','B_CN_full_variable','B_G_full_variable')]
 source=R/'tmp/c09_nominal14_backend_v4/gates/harmonic_nodes.npz'
 assert sha(source)=='9d32008737f74db237627b0a54f53f3c2163b4a85118c700238c6a764b631c96'
 for rel,h in read(D/'backend_continuation/receipt.json')['files'].items():assert sha(D/'backend_continuation'/rel)==h
 sources=[Path(__file__),source,D/'backend_continuation/data.npz',D/'scenarios.py',R/'tmp/c09_D3_w1_v1/reference.py',R/'tmp/c09_D2_continuation_v3/engine.py',R/'tmp/c09_D2_continuation_v3/kernel_group.py']
 bindings={str(p.relative_to(R)):sha(p) for p in sources};binding=hashlib.sha256(json.dumps(bindings,sort_keys=True).encode()).hexdigest()
 controls=[dict(rtol=1e-8,atol=1e-10,max_step=.01),dict(rtol=1e-9,atol=1e-11,max_step=.005)]
 write(out/'plan.json',dict(curves=curves,bindings=bindings,LL_cap=240000,CPU_cap=90,wall_cap=120,RSS_cap=int(1.5*1024**3),W1_controls=controls,primary_engine='unchanged D2',new_data=0,new_ORFs=0,engineering_not_SBC=True))
 class Guard:
  config={'estimated_numeric_bytes':1024**3}
  def check(self):
   if time.process_time()-start>90 or time.monotonic()-wall>120:raise RuntimeError('time cap')
   if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>int(1.5*1024**3):raise RuntimeError('RSS cap')
  def checkpoint(self):self.check()
  def write_json(self,rel,value):write(out/rel,value)
 guard=Guard();budget=Budget(curves,additional_cap=240000,historical_values=5812197,checkpoint=guard.check);guard.budget=budget
 try:
  nominal=read(R/'tmp/c09_nominal14_v4/config.json');e=experiment(read(R/nominal['experiment_config']))
  with np.load(D/'backend_continuation/data.npz',allow_pickle=False) as f:data={k:f[k] for k in ('q','x_physical','x_gaussian')}
  with np.load(source,allow_pickle=False) as f:oracle=dict(u=f['u'],Gamma=f['Gamma'])
  table=load_table(R/nominal['table_file'],nominal['table_sha256'],guard,expected_shape=(8336,4,12,12));anchor=table(np.array([.5]))[0]
  group=KernelGroup(curves,data,covariance=ScenarioCovariance(e,rows[13]['eta'],ratio=0.),moments=lambda C:quadratic_moments(C,e['H']),weights=e['weights'],anchor_gamma=anchor,budget=budget)
  names=[c['curve_id'] for c in curves]
  evidence=check_new_functions([group],{n:0 for n in names},table,oracle,curves,e['H'],anchor,guard,source_binding=binding)
  assert all(x['accepted_finite_domain'] for x in evidence.values())
  def provider(u,ids,reason):return group.evaluate_gamma(table(u),ids,reason=reason)
  cache=CacheSet(names,provider=provider,batch=32,checkpoint=guard.check)
  grid=event_grid(table.nodes,Prior('uniform_u'),validation_count=1);edges=np.array([0.,1e-4,.001,.01,.8,1.]);coarse=exact_union(grid['coarse_u'],edges);fine=exact_union(grid['fine_u'],edges)
  cache.evaluate(fine,names,reason='grid');prior=dict(id='uniform_u',kind='uniform_u',lower=0.,upper=1.)
  for c in curves:
   name=c['curve_id'];result=analyze_curve(c,[prior],coarse,fine,cache,freeze_cuts=lambda x,n=name:write(out/'cuts'/(n+'.json'),x),finite_backend_evidence=evidence[name],save_reference_panel=lambda x,n=name:write(out/'references'/n/(str(x['panel_index'])+'.json'),x),compute_table_W1=False)
   results.append(result);write(out/'results'/(name+'.json'),result)
  assert all(all(r['results'][0]['table_gates'][k] for k in ('normalization','CDF','quantiles','moments','KL')) for r in results)
  ps=[PriorMeasure(**r['results'][0]['prior']) for r in results];refs=[r['results'][0]['reference'] for r in results]
  fineell=[np.array([cache.values[n][key(x)] for x in fine]) for n in names];coarseell=[np.array([cache.values[n][key(x)] for x in coarse]) for n in names];shift=np.array([float(max(x)) for x in fineell])
  z=[r['denominator'] for r in refs];ez=[r['denominator_error_estimate'] for r in refs];cuts=[r['cut_values'] for r in refs]
  assert max(abs(shift[i]+math.log(z[i])-r['logZ']) for i,r in enumerate(refs))<1e-12
  def direct(u):
   x=cache.evaluate(u,names,reason='functional_reference');return np.stack([x[n] for n in names],axis=-1)
  references=[]
  for control in controls:
   value=integrate(direct,ps,z,ez,shift=shift,cuts=cuts,checkpoint=guard.check,**control);references.append(value);write(out/f'W1_reference_{len(references)}.json',value)
  for j,c in enumerate(curves):
   name=c['curve_id'];guard.check();low=PosteriorTable(coarse,coarseell[j],ps[j],order=16);high=PosteriorTable(fine,fineell[j],ps[j],order=32)
   ws=[wasserstein_to_prior(low,order=12),wasserstein_to_prior(high,order=12),wasserstein_to_prior(high,order=24)];a,b=[r['results'][j] for r in references]
   delta=max(abs(ws[0]-ws[2]),abs(ws[1]-ws[2]),abs(a['W1']-b['W1']),abs(ws[2]-b['W1']))+b['normalizer_uncertainty_sensitivity']
   cdf=max(float(np.max(abs(np.array(x['cdf'])-refs[j]['cdf']))) for x in (a,b));zd=max(x['normalization_relative_discrepancy'] for x in (a,b))
   q=next(q for q in results[j]['results'][0]['quantiles'] if q['probability']==.95)
   comparisons.append(dict(curve=name,data_id=c['data_id'],analysis=c['analysis'],mode='nominal',W1=ws[2],table_values=ws,W1_direct=b['W1'],W1_delta=delta,CDF_delta=cdf,Z_relative_delta=zd,W1_passed=delta<=.001 and cdf<=.002 and zd<=.001,q95=[q['lower'],q['upper']],primary_passed=True,altered_distance_mixture_validated=False))
   write(out/'comparisons.json',comparisons)
  status='COMPLETED'
 except Exception:error=traceback.format_exc();print(error,flush=True)
 finally:
  if cache is not None:
   for name,values in cache.values.items():
    ordered=sorted((float(np.frombuffer(bytes.fromhex(k),dtype=np.float64)[0]),v) for k,v in values.items());(out/'caches').mkdir(exist_ok=True)
    np.savez_compressed(out/'caches'/(name+'.npz'),u=np.array([x[0] for x in ordered]),log_likelihood=np.array([x[1] for x in ordered]))
  receipt=dict(status=status,error=error,budget=budget.report(),CPU=time.process_time()-start,wall=time.monotonic()-wall,RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,primary_results=len(results),W1_passed=sum(x['W1_passed'] for x in comparisons),C09_complete=False)
  write(out/'receipt.json',receipt);print(json.dumps({k:v for k,v in receipt.items() if k!='budget'},default=scalar),flush=True)
 if status!='COMPLETED':sys.exit(1)

if __name__=='__main__':main()
