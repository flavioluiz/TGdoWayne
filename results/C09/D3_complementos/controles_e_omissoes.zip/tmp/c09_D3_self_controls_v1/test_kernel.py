from pathlib import Path
import os,sys,unittest
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'src'),str(R/'tmp/c09_D2_components_v1'),str(R/'tmp/c09_D2_continuation_v3')]
import numpy as np
from scipy.stats import multivariate_normal
from pta.statistics import quadratic_moments
from budget import Budget
from kernel import SelfControlGroup

class SelfControlTests(unittest.TestCase):
 def test_three_matched_families_against_independent_densities(self):
  h=np.array([np.diag([1.,0.]),np.diag([0.,1.])]);w=np.array([.4,.6])
  g=np.array([[[[1.,.2],[.2,2.]],[[2.,-.1],[-.1,1.]]],[[[3.,.1],[.1,1.]],[[1.,.3],[.3,2.]]]])
  rows=[dict(curve_id=f'{i}_{v}',data_id=i,variant=v,additional_likelihood_cap=2) for i in range(3) for v in ('diagonal_variable','full_fixed','diagonal_fixed')]
  obs={r['curve_id']:np.array([.5+r['data_id'],1.5]) for r in rows}
  budget=Budget(rows,additional_cap=18,historical_values=0,checkpoint=lambda:None)
  covariance=lambda a:a+np.eye(2)
  group=SelfControlGroup(rows,obs,covariance=covariance,moments=lambda c:quadratic_moments(c,h),weights=w,anchor_gamma=g[0],budget=budget)
  actual=group.evaluate_gamma(g,list(obs),reason='functional_reference')
  def direct(c):
   means=np.array([[np.trace(H@C).real for H in h] for C in c])
   covs=np.array([[[np.trace(A@C@B@C).real for B in h] for A in h] for C in c])
   return np.sum(w[:,None]*means,axis=0),np.sum(w[:,None,None]**2*covs,axis=0)
  _,anchor=direct(covariance(g)[0])
  for i,c in enumerate(covariance(g)):
   m,s=direct(c)
   for r in rows:
    v=r['variant'];S=anchor if v.endswith('fixed') else s
    if v.startswith('diagonal'):S=np.diag(np.diag(S))
    self.assertAlmostEqual(actual[r['curve_id']][i],multivariate_normal.logpdf(obs[r['curve_id']],mean=m,cov=S),places=12)
  self.assertEqual(budget.charged,18)
  with self.assertRaises(RuntimeError):group.evaluate_gamma(g,list(obs),reason='functional_reference')
  self.assertEqual(budget.charged,18)

if __name__=='__main__':unittest.main()
