"""Saved-run audit and paired omission contrasts; no new likelihoods."""
from pathlib import Path
import hashlib,json
import numpy as np
H=Path(__file__).resolve().parent;R=H.parents[1];D=R/'tmp/c09_D3_components_v1'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];pairs=[];charged=0;cpu=0.
for directory in sorted((H/'execution').glob('*_*')):
 if not directory.is_dir():continue
 plan=read(directory/'plan.json');receipt=read(directory/'receipt.json');assert receipt['status']=='COMPLETED'
 for rel,h in plan['bindings'].items():assert sha(R/rel)==h
 charged+=receipt['budget']['additional_charged_values'];cpu+=receipt['CPU']
 stored=0
 for p in (directory/'caches').glob('*.npz'):
  with np.load(p,allow_pickle=False) as f:
   assert np.all(np.diff(f['u'])>0) and np.isfinite(f['log_likelihood']).all();stored+=len(f['u'])
 assert stored+111==receipt['budget']['additional_charged_values'] and receipt['budget']['failed_reserved_values']==0
 if plan['kind']=='self':
  with np.load(directory/'self_data.npz',allow_pickle=False) as f:assert f['observations'].shape==(3,10) and np.isfinite(f['observations']).all()
 for c in plan['curves']:
  result=read(directory/'results'/(c['curve_id']+'.json'));r=result['results'][0]
  passed=all(r['table_gates'][k] for k in ('normalization','CDF','quantiles','moments','KL'))
  assert result['finite_backend_evidence']['accepted_finite_domain']
  q=next(x for x in r['quantiles'] if x['probability']==.95)
  row=dict(curve=c['curve_id'],kind=plan['kind'],data_id=c['data_id'],analysis=c['analysis'],prior=r['prior_id'],primary_passed=passed,q95=[q['lower'],q['upper']],KL=r['summary']['kl_to_prior'],W1_status='PENDING',logL_event_status='PENDING')
  rows.append(row)
  if plan['kind']=='omitted':
   p=D/'posterior_execution'/f'd{c["data_id"]}'/'results'/f'd{c["data_id"]}_{c["analysis"]}.json';original=read(p)['results'][0]
   assert all(original['table_gates'][k] for k in ('normalization','CDF','quantiles','moments','KL'))
   origq=next(x for x in original['quantiles'] if x['probability']==.95)
   lo=q['lower']-origq['upper'];hi=q['upper']-origq['lower']
   pairs.append(dict(data_id=c['data_id'],analysis=c['analysis'],quantity='Q95_omitted_minus_included',interval=[lo,hi],direction='POSITIVE' if lo>0 else ('NEGATIVE' if hi<0 else 'UNRESOLVED'),original_result_sha256=sha(p),scope='same fixed datum; numerical interval, not population confidence interval'))
assert len(rows)==21 and len(pairs)==12
summary=dict(analyses=21,primary_passed=sum(r['primary_passed'] for r in rows),new_self_data=9,omission_pairs=12,charged_values=charged,CPU=cpu,cumulative_C09_values=3885164+charged,rows=rows,pairs=pairs,C09_complete=False,engineering_not_SBC=True)
(H/'audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('rows','pairs')},indent=2))
