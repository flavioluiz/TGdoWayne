"""Three matched controls or three omitted-contaminant analyses per datum."""
from pathlib import Path
import os,sys,json,hashlib,time,resource,argparse,traceback
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
H=Path(__file__).resolve().parent;R=H.parents[1];D=R/'tmp/c09_D3_components_v1'
sys.path[:0]=[str(H),str(D),str(R/'src'),str(R/'tmp/c09_nominal14_v2'),str(R/'tmp/c09_nominal14_v4'),str(R/'tmp/c09_D2_components_v1'),str(R/'tmp/c09_D2_continuation_v3'),str(R/'tmp/c09_event_repair_v1')]
import numpy as np
from scipy.stats import multivariate_normal
from scenarios import ScenarioCovariance,draw_self_control
from kernel import SelfControlGroup
from inference.model import experiment
from pta.statistics import quadratic_moments
from runtime_adapter import load_table
from kernel_group import KernelGroup
from factorial import compressed_moments
from backend_checks import check_new_functions,_direct_moments
from budget import Budget,LimitReached
from cache import CacheSet
from engine import analyze_curve
from d1.grid import event_grid,exact_union
from d1.measure import Prior
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--row',type=int,required=True);parser.add_argument('--kind',choices=['self','omitted'],required=True);args=parser.parse_args()
 assert (args.kind=='self' and args.row in (0,1,2)) or (args.kind=='omitted' and args.row in (9,10,11,12))
 out=H/'execution'/f'{args.kind}_{args.row}';out.mkdir(parents=True,exist_ok=False)
 start=time.process_time();wall=time.monotonic();cache=None;status='FAILED';error=None;reports=[]
 row=read(D/'backend_execution/plan.json')['rows'][args.row];truths=read(D/'backend_execution/truths.json');truth=truths['u'][args.row]
 for rel,h in read(D/'backend_continuation/receipt.json')['files'].items():assert sha(D/'backend_continuation'/rel)==h
 original=R/'tmp/c09_nominal14_backend_v4/gates/harmonic_nodes.npz'
 assert sha(original)=='9d32008737f74db237627b0a54f53f3c2163b4a85118c700238c6a764b631c96'
 prior=dict(id=row['prior'],kind=row['prior'],lower=.001 if row['prior']=='log_uniform_u' else 0.,upper=1.)
 curves=[]
 models=['diagonal_variable','full_fixed','diagonal_fixed'] if args.kind=='self' else ['A0_CN','A_G','B_CN_full_variable']
 for model in models:
  curves.append(dict(curve_id=f'{args.kind}_{args.row}_{model}',data_id=args.row,analysis='B_SELF_'+model if args.kind=='self' else model,
    variant=model if args.kind=='self' else None,eta_physical_coordinates=row['eta'],analysis_contaminant_ratio=0.,
    observation_field='q' if model=='A0_CN' else ('x_gaussian' if model=='A_G' else 'x_physical'),
    fixed_truth_u=truth,additional_likelihood_cap=30040))
 sources=[Path(__file__),H/'kernel.py',D/'scenarios.py',D/'backend_continuation/data.npz',D/'backend_continuation/truth_responses.npz',original,R/'tmp/c09_D2_continuation_v3/engine.py']
 bindings={str(p.relative_to(R)):sha(p) for p in sources};binding=hashlib.sha256(json.dumps(bindings,sort_keys=True).encode()).hexdigest()
 write(out/'plan.json',dict(kind=args.kind,row=row,curves=curves,prior=prior,LL_cap=90120,CPU_cap=60,wall_cap=90,RSS_cap=int(1.5*1024**3),
   data_generation='self: independent streams [909110801,3,row,2+variant]; omitted: reuse original data exactly',
   bindings=bindings,engineering_excluded_from_SBC=True,compute_W1=False,logL_event_pending=True))
 class Guard:
  config={'estimated_numeric_bytes':1024**3}
  def check(self):
   if time.process_time()-start>60 or time.monotonic()-wall>90:raise RuntimeError('time cap')
   if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>int(1.5*1024**3):raise RuntimeError('RSS cap')
  def checkpoint(self):self.check()
  def write_json(self,rel,x):write(out/rel,x)
 guard=Guard();budget=Budget(curves,additional_cap=90120,historical_values=3885164,checkpoint=guard.check);guard.budget=budget
 try:
  nominal=read(R/'tmp/c09_nominal14_v4/config.json');e=experiment(read(R/nominal['experiment_config']))
  with np.load(original,allow_pickle=False) as f:old_u=f['u'];old_g=f['Gamma']
  anchor_exact=old_g[np.flatnonzero(old_u==.5)[0]]
  with np.load(D/'backend_continuation/truth_responses.npz',allow_pickle=False) as f:gtruth=f['Gamma'][truths['row_response_indices'][args.row]]
  table=load_table(R/nominal['table_file'],nominal['table_sha256'],guard,expected_shape=(8336,4,12,12))
  cov=ScenarioCovariance(e,row['eta'],kind=row['kind'],ratio=0.)
  oracle=dict(u=np.r_[old_u,truth],Gamma=np.concatenate([old_g,gtruth[None]]))
  if args.kind=='self':
   mu,sv=quadratic_moments(cov(gtruth[None]),e['H']);m,s=compressed_moments(mu,sv,e['weights'])
   ma,sa=quadratic_moments(cov(anchor_exact[None]),e['H']);_,anchor_cov=compressed_moments(ma,sa,e['weights'])
   observations={}
   for j,c in enumerate(curves):
    rng=np.random.default_rng(np.random.SeedSequence([909110801,3,args.row,2+j]))
    observations[c['curve_id']]=draw_self_control(m[0],s[0],anchor_cov[0],c['variant'],rng)
   np.savez_compressed(out/'self_data.npz',observations=np.stack(list(observations.values())),truth_u=np.array([truth]))
   group=SelfControlGroup(curves,observations,covariance=cov,moments=lambda C:quadratic_moments(C,e['H']),weights=e['weights'],anchor_gamma=anchor_exact,budget=budget)
   ids=list(observations);tab=table(oracle['u']);lt=group.evaluate_gamma(tab,ids,reason='backend_check');le=group.evaluate_gamma(oracle['Gamma'],ids,reason='backend_check')
   evidence={}
   for c in curves:
    name=c['curve_id'];independent=[]
    for i in (0,8,16):
     reservation=budget.reserve([name],1,reason='scipy_reference');success=False
     try:
      mm,ss=_direct_moments(cov(tab[i][None])[0],e['H']);mean=sum(e['weights'][k]*mm[k] for k in range(4))
      sigma=sum(e['weights'][k]**2*ss[k] for k in range(4))
      if c['variant'].endswith('fixed'):
       _,ss=_direct_moments(cov(anchor_exact[None])[0],e['H']);sigma=sum(e['weights'][k]**2*ss[k] for k in range(4))
      if c['variant'].startswith('diagonal'):sigma=np.diag(np.diag(sigma))
      ref=float(multivariate_normal.logpdf(observations[name],mean=mean,cov=sigma));success=True
     finally:budget.complete(reservation,success=success)
     independent.append(dict(u=float(oracle['u'][i]),scipy_logL=ref,kernel_logL=float(lt[name][i]),delta=abs(ref-lt[name][i])))
    delta=float(np.max(abs(lt[name]-le[name])));dscipy=float(max(x['delta'] for x in independent));passed=delta<=.001 and dscipy<=1e-8
    evidence[name]=dict(curve_id=name,accepted_finite_domain=passed,new_curve_checks_passed=passed,source_and_input_binding=binding,
      saved_harmonic_control_count=17,maximum_absolute_logL_difference=delta,scipy_maximum_absolute_difference=dscipy,
      scipy_references=independent,table_logL=lt[name].tolist(),harmonic_logL=le[name].tolist(),uniform_probability_bound=None)
    write(out/'backend_checks'/(name+'.json'),evidence[name])
  else:
   with np.load(D/'backend_continuation/data.npz',allow_pickle=False) as f:data={k:f[k] for k in ('q','x_physical','x_gaussian')}
   anchor=table(np.array([.5]))[0]
   group=KernelGroup(curves,data,covariance=cov,moments=lambda C:quadratic_moments(C,e['H']),weights=e['weights'],anchor_gamma=anchor,budget=budget)
   evidence=check_new_functions([group],{c['curve_id']:0 for c in curves},table,oracle,curves,e['H'],anchor,guard,source_binding=binding)
  if not all(x['accepted_finite_domain'] for x in evidence.values()):raise ArithmeticError('finite checks failed; integration not started')
  def provider(u,ids,reason):return group.evaluate_gamma(table(u),ids,reason=reason)
  cache=CacheSet([c['curve_id'] for c in curves],provider=provider,batch=32,checkpoint=guard.check)
  grid=event_grid(table.nodes,Prior('uniform_u'),validation_count=1);edges=np.array([0.,1e-4,.001,.01,.8,1.]);coarse=exact_union(grid['coarse_u'],edges);fine=exact_union(grid['fine_u'],edges)
  cache.evaluate(fine,[c['curve_id'] for c in curves],reason='grid')
  for c in curves:
   name=c['curve_id'];guard.check()
   try:
    result=analyze_curve(c,[prior],coarse,fine,cache,freeze_cuts=lambda x,n=name:write(out/'cuts'/(n+'.json'),x),finite_backend_evidence=evidence[name],save_reference_panel=lambda x,n=name:write(out/'references'/n/(str(x['panel_index'])+'.json'),x),compute_table_W1=False)
   except LimitReached as exc:result=dict(curve_id=name,status='UNRESOLVED_LIKELIHOOD_CAP',reason=str(exc))
   write(out/'results'/(name+'.json'),result);reports.append(name)
  status='COMPLETED'
 except Exception:error=traceback.format_exc();print(error,flush=True)
 finally:
  if cache is not None:
   for name,values in cache.values.items():
    ordered=sorted((float(np.frombuffer(bytes.fromhex(k),dtype=np.float64)[0]),v) for k,v in values.items());(out/'caches').mkdir(exist_ok=True)
    np.savez_compressed(out/'caches'/(name+'.npz'),u=np.array([x[0] for x in ordered]),log_likelihood=np.array([x[1] for x in ordered]))
  receipt=dict(status=status,error=error,budget=budget.report(),CPU=time.process_time()-start,wall=time.monotonic()-wall,RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,recorded_curves=reports,C09_complete=False)
  write(out/'receipt.json',receipt);print(json.dumps({k:v for k,v in receipt.items() if k!='budget'}),flush=True)
 if status!='COMPLETED':sys.exit(1)

if __name__=='__main__':main()
