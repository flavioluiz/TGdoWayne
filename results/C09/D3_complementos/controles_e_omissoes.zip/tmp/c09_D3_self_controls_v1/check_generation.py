"""Independent trace moments and saved RNG streams reconstruct self data."""
from pathlib import Path
import sys,json
H=Path(__file__).resolve().parent;R=H.parents[1];D=R/'tmp/c09_D3_components_v1'
sys.path[:0]=[str(D),str(R/'src'),str(R/'tmp/c09_nominal14_v2'),str(R/'tmp/c09_D2_continuation_v3')]
import numpy as np
from scenarios import ScenarioCovariance
from inference.model import experiment
from backend_checks import _direct_moments
def read(p):return json.loads(p.read_text())
e=experiment(read(R/'configs/calibration/prior_predictive_500_v1.json'));truth=read(D/'backend_execution/truths.json')
with np.load(D/'backend_continuation/truth_responses.npz',allow_pickle=False) as f:gamma=f['Gamma']
with np.load(R/'tmp/c09_nominal14_backend_v4/gates/harmonic_nodes.npz',allow_pickle=False) as f:anchor=f['Gamma'][np.flatnonzero(f['u']==.5)[0]]
checks=[]
for i in (0,1,2):
 plan=read(H/f'execution/self_{i}/plan.json');row=plan['row'];cov=ScenarioCovariance(e,row['eta'],ratio=0.)
 m,s=_direct_moments(cov(gamma[truth['row_response_indices'][i]][None])[0],e['H'])
 _,a=_direct_moments(cov(anchor[None])[0],e['H'])
 mu=sum(e['weights'][k]*m[k] for k in range(4));var=sum(e['weights'][k]**2*s[k] for k in range(4));anc=sum(e['weights'][k]**2*a[k] for k in range(4))
 with np.load(H/f'execution/self_{i}/self_data.npz',allow_pickle=False) as f:observations=f['observations']
 for j,c in enumerate(plan['curves']):
  S=anc if c['variant'].endswith('fixed') else var
  if c['variant'].startswith('diagonal'):S=np.diag(np.diag(S))
  rng=np.random.default_rng(np.random.SeedSequence([909110801,3,i,2+j]));expected=mu+np.linalg.cholesky(S)@rng.standard_normal(10)
  error=float(np.max(abs(expected-observations[j])));assert error<=1e-12
  checks.append(dict(curve=c['curve_id'],max_absolute_reconstruction_error=error))
(H/'generation_audit.json').write_text(json.dumps(dict(passed=len(checks)==9,checks=checks,new_independent_observations=0,scope='deterministic reconstruction of the nine saved observations'),indent=2)+'\n')
print(max(c['max_absolute_reconstruction_error'] for c in checks))
