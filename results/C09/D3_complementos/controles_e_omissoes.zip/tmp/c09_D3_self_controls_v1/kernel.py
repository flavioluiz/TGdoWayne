"""Matched B-normal families, with genuinely compressed observations."""
import numpy as np
from batch_likelihood import normal_logpdf
from factorial import compressed_moments,factorial_moments

class SelfControlGroup:
    def __init__(self,rows,observations,*,covariance,moments,weights,anchor_gamma,budget):
        self.rows={r['curve_id']:dict(r) for r in rows};self.budget=budget
        if not rows or len(self.rows)!=len(rows):raise ValueError('distinct registered curves required')
        allowed={'diagonal_variable','full_fixed','diagonal_fixed'}
        if any(r['variant'] not in allowed for r in rows):raise ValueError('one of three additional matched controls required')
        self.observations={k:np.asarray(v,float).copy() for k,v in observations.items()}
        if set(self.observations)!=set(self.rows):raise ValueError('one compressed datum per control curve required')
        self.covariance,self.moments=covariance,moments;self.weights=np.asarray(weights,float).copy()
        m,s=moments(covariance(np.asarray(anchor_gamma)[None]));_,anchor=compressed_moments(m,s,self.weights);self.anchor=anchor[0]
        for y in self.observations.values():
            if y.shape!=(len(self.anchor),) or not np.isfinite(y).all():raise ValueError('finite compressed vector required')
            y.flags.writeable=False

    def evaluate_gamma(self,gamma,curve_ids,*,reason):
        g=np.asarray(gamma)
        if g.ndim!=4 or not len(g) or not curve_ids or any(k not in self.rows for k in curve_ids):raise ValueError('registered response batch required')
        reservation=self.budget.reserve(curve_ids,len(g),reason=reason);success=False
        try:
            mean,cov=self.moments(self.covariance(g));out={}
            variants={self.rows[k]['variant'] for k in curve_ids}
            for variant in sorted(variants):
                ids=[k for k in curve_ids if self.rows[k]['variant']==variant]
                mu,s=factorial_moments(mean,cov,self.weights,diagonal=variant.startswith('diagonal'),fixed=variant.endswith('fixed'),anchor_covariance=self.anchor)
                y=np.stack([self.observations[k] for k in ids])[:,None,:]
                ll,work=normal_logpdf(mu,s,y,reserve=lambda w:None)
                if work.normalized_log_likelihood_values!=len(g)*len(ids):raise ArithmeticError('count mismatch')
                out.update({k:ll[:,j] for j,k in enumerate(ids)})
            self.budget.checkpoint();success=True;return out
        finally:self.budget.complete(reservation,success=success)
