"""Seven bounded fresh workers; no statistical production or new ORFs."""
from pathlib import Path
import json,subprocess,sys,hashlib
H=Path(__file__).resolve().parent;out=H/'execution';out.mkdir(exist_ok=False)
jobs=[(kind,i) for kind,ids in [('self',(0,1,2)),('omitted',(9,10,11,12))] for i in ids]
plan=dict(jobs=jobs,LL_cap=630840,CPU_cap=420,per_worker_LL_cap=90120,per_worker_CPU_cap=60,
 new_ORFs=0,new_self_data=9,existing_data_reused_for_omission=4,engineering_excluded_from_SBC=True,
 sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in H.glob('*.py')})
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');charged=0;cpu=0.;runs=[]
for kind,i in jobs:
 assert charged+90120<=630840 and cpu+60<=420
 code=subprocess.run([sys.executable,str(H/'worker.py'),'--kind',kind,'--row',str(i)],timeout=100).returncode
 r=json.loads((out/f'{kind}_{i}/receipt.json').read_text());charged+=r['budget']['additional_charged_values'];cpu+=r['CPU'];runs.append(dict(kind=kind,row=i,status=r['status'],returncode=code))
 (out/'summary.json').write_text(json.dumps(dict(runs=runs,charged=charged,CPU=cpu,cumulative_C09_likelihood_values=3885164+charged,C09_complete=False),indent=2)+'\n')
