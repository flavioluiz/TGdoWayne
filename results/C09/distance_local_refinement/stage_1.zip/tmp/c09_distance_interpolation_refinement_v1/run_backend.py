"""Execute the bounded frozen distance response jobs, sequentially."""
from pathlib import Path
import json,hashlib,sys,subprocess
H=Path(__file__).resolve().parent;out=H/'backend_execution';out.mkdir(exist_ok=False)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(H/'prepared/plan.json');cpu=0.;products=0;runs=[]
activation=dict(plan_sha256=sha(H/'prepared/plan.json'),worker_sha256=sha(H/'worker.py'),driver_sha256=sha(Path(__file__)),execution_scope='96 direct local refinement/control nodes, three refinements, no likelihood/data generation',original_plan_execution_flag_unchanged=True)
(out/'activation.json').write_text(json.dumps(activation,indent=2)+'\n')
for index,job in enumerate(plan['jobs']):
 assert cpu+120<=plan['combined_worker_CPU_cap'] and products+job['products']<=plan['real_products']
 request=out/(job['name']+'.json');request.write_text(json.dumps(dict(job_index=index,**activation),indent=2)+'\n')
 code=subprocess.run([sys.executable,str(H/'worker.py'),str(request),sha(request)],timeout=190).returncode
 receipt=read(out/job['name']/'receipt.json');cpu+=receipt['CPU'];products+=receipt['products'];runs.append(dict(job=job['name'],status=receipt['status'],returncode=code))
 (out/'summary.json').write_text(json.dumps(dict(runs=runs,CPU=cpu,products=products,all_jobs_completed=len(runs)==len(plan['jobs']) and all(r['status']=='COMPLETED' for r in runs),C09_complete=False),indent=2)+'\n')
 if code:raise RuntimeError('response job failed; history preserved, no automatic retry')
