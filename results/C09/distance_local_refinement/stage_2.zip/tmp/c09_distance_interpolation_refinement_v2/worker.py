"""One fresh process per distance-rule harmonic resolution; no inference."""
from pathlib import Path
import os,sys,json,hashlib,time,resource,traceback
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
H=Path(__file__).resolve().parent;R=H.parents[1];sys.path.insert(0,str(R/'src'))
import numpy as np
from inference.model import experiment
from inference.orf_blas import RealHarmonicBasis,TableBudget
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
request=Path(sys.argv[1]);assert sha(request)==sys.argv[2];req=read(request);plan=read(H/'prepared/plan.json')
assert sha(H/'prepared/plan.json')==req['plan_sha256'] and sha(Path(__file__))==req['worker_sha256']
for rel,h in plan['bindings'].items():assert sha(R/rel)==h
assert sha(R/plan['rules_file'])==plan['rules_sha256']
job=plan['jobs'][req['job_index']];out=request.parent/job['name'];out.mkdir(exist_ok=False)
start=time.process_time();wall=time.monotonic();products=0;status='FAILED';error=None
def check():
 if time.process_time()-start>120 or time.monotonic()-wall>180:raise RuntimeError('worker CPU/wall cap')
 if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>plan['maximum_RSS_bytes']:raise RuntimeError('worker RSS cap')
try:
 e=experiment(read(R/'configs/calibration/prior_predictive_500_v1.json'));k=job['channel'];l=job['level']['lmax'];n=job['level']['nmu']
 with np.load(R/plan['rules_file'],allow_pickle=False) as f:u=f['u']
 products=4*n*(l-1)+6*144*(l-1)
 basis=RealHarmonicBasis(e['points'],lmax=l,nmu=n,budget=TableBudget(1024**3,50000000000,16),planned_batch=16);check()
 gamma=np.empty((2,len(u),12,12),complex)
 for s,scale in enumerate(plan['scales']):
  phase=2*np.pi*e['f'][k]*e['distance_ly']*365.25*86400*scale
  for first in range(0,len(u),16):
   masses=u[first:first+16];beta=np.sqrt((1-masses/(k+1))*(1+masses/(k+1)))
   cost=len(masses)*(24*n*(l-1)+6*144*(l-1)+16*12*n);check()
   if products+cost>job['products']:raise RuntimeError('product cap before evaluation')
   products+=cost;gamma[s,first:first+len(masses)]=basis.evaluate(beta,phase);check()
 assert products==job['products']
 np.savez_compressed(out/'matrices.npz',Gamma=gamma);status='COMPLETED'
except Exception:error=traceback.format_exc();print(error,flush=True)
finally:
 receipt=dict(status=status,error=error,CPU=time.process_time()-start,wall=time.monotonic()-wall,RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,products=products,new_likelihood_values=0,request_sha256=sha(request))
 if (out/'matrices.npz').exists():receipt['matrix_sha256']=sha(out/'matrices.npz')
 write(out/'receipt.json',receipt);print(json.dumps(receipt),flush=True)
if status!='COMPLETED':sys.exit(1)
