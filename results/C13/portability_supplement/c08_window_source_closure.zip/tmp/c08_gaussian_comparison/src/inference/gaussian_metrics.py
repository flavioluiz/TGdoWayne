"""Pure real-normal comparisons and local Fisher information; no PTA kernels.

Covariances must be SPD. Only explicitly reported roundoff-sized symmetry
averaging is allowed; no eigenvalue clipping, jitter, pseudo-inverse or repair.
"""
import math
import numpy as np
from scipy.linalg import solve_triangular, norm

EPS = np.finfo(float).eps
SERIES_ORDER = 20
SERIES_RADIUS = .125
SYMMETRY_RTOL = 64*EPS


def _real(value, ndim, name):
    a = np.asarray(value)
    if a.ndim != ndim or a.dtype.kind not in 'fiu' or not a.size or not np.isfinite(a).all():
        raise ValueError(name+' must be a nonempty finite real numeric array of rank'+str(ndim))
    return np.array(a, dtype=float, copy=True)


def _symmetric(a, name, *, rtol=SYMMETRY_RTOL):
    if a.ndim != 2 or a.shape[0] != a.shape[1]:
        raise ValueError(name+' must be square.')
    scale = float(np.max(np.abs(a)))
    relative_error = 0. if scale == 0 else float(np.max(np.abs(a/scale-a.T/scale)))
    if relative_error > rtol:
        raise ValueError(name+' is not symmetric within the declared roundoff tolerance.')
    if relative_error == 0.:
        return a.copy(), relative_error
    # Halve before adding to avoid overflow when large diagonals are finite.
    symmetric = a*.5+a.T*.5
    if not np.isfinite(symmetric).all():
        raise FloatingPointError('Symmetry averaging overflowed.')
    return symmetric, relative_error


def _covariance(value, dimension, name):
    a = _real(value, 2, name)
    if a.shape != (dimension, dimension):
        raise ValueError(name+' dimension differs from the mean/derivatives.')
    a, error = _symmetric(a, name)
    try:
        factor = np.linalg.cholesky(a)
    except np.linalg.LinAlgError as exc:
        raise ValueError(name+' must be positive definite; no jitter or clipping.') from exc
    return a, factor, error


def _whiten(a, factor):
    first = solve_triangular(factor, a, lower=True, check_finite=False)
    result = solve_triangular(factor, first.T, lower=True, check_finite=False).T
    if not np.isfinite(result).all():
        raise FloatingPointError('Whitening is not representable at float64 precision.')
    # A computed matrix has a distinct, slightly wider roundoff tolerance.
    return _symmetric(result, 'computed whitened matrix', rtol=256*EPS)


def _series(shifts):
    """Evaluate sum_{k=2}^20 (-1)^k t^k/k and a truncation remainder bound.

For |t|<1, |R_m| <= |t|^(m+1)/((m+1)(1-|t|)). The remainder bound
does not include eigensolver/whitening error. Nonzero underflowed bounds are
rounded up to the smallest positive float instead of reported as exact zero.
"""
    t = np.asarray(shifts, float)
    polynomial = np.full(t.shape, 1./SERIES_ORDER)
    for k in range(SERIES_ORDER-1, 1, -1):
        polynomial = ((-1.)**k)/k+t*polynomial
    value = t*t*polynomial
    x = abs(t)
    raw_bound = x**(SERIES_ORDER+1)/((SERIES_ORDER+1)*(1-x))
    bound = np.where(x == 0, 0., np.nextafter(raw_bound*(1+64*EPS), np.inf))
    # Standard arithmetic error model for the short polynomial evaluation.
    operations = 2*SERIES_ORDER+4
    gamma = operations*EPS/(1-operations*EPS)
    roundoff_model = gamma*x*x/(2*(1-x))
    return value, bound, roundoff_model


def stable_eigenvalue_deviance(eigenvalues):
    """lambda - 1 - log(lambda), including a stable near-one series.

Returns arrays and truncation bounds, not an error certificate for how the
eigenvalues themselves were computed. Inputs are positive float64 values.
"""
    eigenvalues = _real(eigenvalues, 1, 'eigenvalues')
    if np.any(eigenvalues <= 0):
        raise ValueError('Strictly positive covariance eigenvalues required.')
    shifts = eigenvalues-1.
    near = abs(shifts) <= SERIES_RADIUS
    values = np.empty_like(eigenvalues)
    bound = np.zeros_like(eigenvalues)
    roundoff = np.zeros_like(eigenvalues)
    values[near], bound[near], roundoff[near] = _series(shifts[near])
    # log(lambda), not log1p(lambda-1): the latter loses very small lambda.
    values[~near] = eigenvalues[~near]-1.-np.log(eigenvalues[~near])
    if not np.isfinite(values).all() or np.any(values < 0):
        raise FloatingPointError('Eigenvalue deviance failed; no clipping to zero.')
    return dict(values=values, near_one_series=near, series_order=SERIES_ORDER,
        series_remainder_upper_bound=bound, series_roundoff_error_model=roundoff,
        remainder_excludes_eigenvalue_error=True)


def gaussian_comparison(mean_p, covariance_p, mean_q, covariance_q):
    """KL[N_p || N_q], Mahalanobis mean shift and covariance discrepancy.

The orientation matters: whitening and the mean metric use covariance_q.
All dimensions are observed real-normal coordinates, not complex-CN modes.
"""
    p = _real(mean_p, 1, 'mean_p')
    q = _real(mean_q, 1, 'mean_q')
    if p.shape != q.shape:
        raise ValueError('Mean dimensions differ.')
    cp, _, error_p = _covariance(covariance_p, len(p), 'covariance_p')
    cq, factor, error_q = _covariance(covariance_q, len(p), 'covariance_q')
    with np.errstate(over='raise', invalid='raise', divide='raise'):
        white_difference, computed_error = _whiten(cp-cq, factor)
        delta, _ = _symmetric(white_difference, 'relative covariance difference', rtol=256*EPS)
        shifts = np.linalg.eigvalsh(delta)
        near_matrix = float(np.max(abs(shifts))) <= SERIES_RADIUS
        if near_matrix:
            # Do not form lambda then subtract1: a tiny off-diagonal change
            # can have eigenvalue shifts below one ulp at lambda=1.
            values, bound, roundoff = _series(shifts)
            eigenvalues = 1.+shifts
            series_mask = np.ones(len(p), bool)
            spectral_method = 'eigenvalues_of_whitened_covariance_difference'
        else:
            white_p, white_p_error = _whiten(cp, factor)
            computed_error = max(computed_error, white_p_error)
            eigenvalues = np.linalg.eigvalsh(white_p)
            if np.any(eigenvalues <= 0):
                raise FloatingPointError('Whitened SPD spectrum lost positivity; refine arithmetic, never clip.')
            result = stable_eigenvalue_deviance(eigenvalues)
            values = result['values']
            bound = result['series_remainder_upper_bound']
            roundoff = result['series_roundoff_error_model']
            series_mask = result['near_one_series']
            spectral_method = 'eigenvalues_of_whitened_covariance_p'
        d = solve_triangular(factor, p-q, lower=True, check_finite=False)
        mahalanobis = float(d@d)
        covariance_term = .5*math.fsum(float(v) for v in values)
        mean_term = .5*mahalanobis
        kl = covariance_term+mean_term
        if not np.isfinite([kl, mahalanobis]).all():
            raise FloatingPointError('Gaussian comparison overflows float64.')
        frobenius = float(norm(delta, 'fro', check_finite=False))
    return dict(kl_p_to_q=kl, kl_mean_term=mean_term, kl_covariance_term=covariance_term,
        mean_mahalanobis_squared=mahalanobis, mean_whitened_difference=d,
        covariance_whitened_difference=delta,
        covariance_whitened_frobenius=frobenius,
        covariance_whitened_spectral=float(np.max(abs(shifts))),
        covariance_generalized_eigenvalues=eigenvalues, covariance_eigenvalue_shifts=shifts,
        covariance_spectral_method=spectral_method,
        deviance_values=values, near_one_series=series_mask, series_order=SERIES_ORDER,
        kl_series_remainder_upper_bound=.5*math.fsum(float(x) for x in bound),
        kl_series_roundoff_error_model=.5*math.fsum(float(x) for x in roundoff),
        positive_deviance_underflow_count=int(np.count_nonzero((shifts != 0) & (values == 0))),
        mean_quadratic_underflow=bool(np.any(d != 0) and mahalanobis == 0),
        input_relative_symmetry_errors=[error_p, error_q],
        computed_relative_symmetry_error=computed_error,
        symmetry_roundoff_averaging_reported=True, no_eigenvalue_clipping_or_jitter=True,
        numerical_error_bound_excludes_linear_algebra_error=True)


def gaussian_fisher(mean_derivative, covariance_derivative, covariance):
    """Real-normal Fisher; dmu[D,P], dC[P,D,D], C[D,D].

F = dmu.T C^-1 dmu + .5 tr(C^-1 dC_i C^-1 dC_j).
The Fisher matrix may be singular; no regularized inverse is returned.
"""
    dm = _real(mean_derivative, 2, 'mean_derivative')
    dc = _real(covariance_derivative, 3, 'covariance_derivative')
    dimension, parameters = dm.shape
    if dc.shape != (parameters, dimension, dimension):
        raise ValueError('Derivative dimensions differ.')
    _, factor, covariance_error = _covariance(covariance, dimension, 'covariance')
    errors, whitened = [], []
    with np.errstate(over='raise', invalid='raise', divide='raise'):
        for derivative in dc:
            symmetric, error = _symmetric(derivative, 'covariance derivative')
            white, computed = _whiten(symmetric, factor)
            whitened.append(white)
            errors.append([error, computed])
        white_mean = solve_triangular(factor, dm, lower=True, check_finite=False)
        white_cov = np.asarray(whitened).reshape(parameters, -1)
        mean_information = white_mean.T@white_mean
        covariance_information = .5*(white_cov@white_cov.T)
        information = mean_information+covariance_information
        if not np.isfinite(information).all():
            raise FloatingPointError('Fisher matrix overflows float64.')
    return dict(information=information, mean_information=mean_information,
        covariance_information=covariance_information,
        mean_derivative_whitened=white_mean,
        covariance_derivative_whitened=np.asarray(whitened),
        covariance_relative_symmetry_error=covariance_error,
        derivative_relative_symmetry_errors=np.asarray(errors),
        convention='real multivariate normal; factor1/2 in covariance contribution',
        no_inverse_or_regularization_of_Fisher=True, no_eigenvalue_clipping_or_jitter=True)
