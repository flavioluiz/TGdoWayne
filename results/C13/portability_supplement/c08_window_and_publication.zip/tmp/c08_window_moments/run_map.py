"""Bounded C08 distributional map; execution requires a frozen ROOT record.

Separate fresh workers construct each harmonic basis, each direct-sky rule
pair and the moment map. No new posterior, data draw or likelihood is used.
"""
import os
os.environ['VECLIB_MAXIMUM_THREADS']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import argparse,hashlib,itertools,json,math,resource,subprocess,sys,time
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'tmp/c08_gaussian_comparison/src/inference'))
from inference.model import experiment,covariance_batch,YEAR
from inference.orf_blas import RealHarmonicBasis,TableBudget
from pta.orf import raw_direct_orf
from gaussian_metrics import gaussian_comparison
from window_moments import window_moments


def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def write_json(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')


def save_npz(path,**arrays):
    with Path(path).open('xb') as f:np.savez(f,**arrays)


def load_authorization(path):
    auth=json.loads(path.read_text());plan=json.loads((HERE/'map_preflight.json').read_text())
    if (auth.get('scope')!='C08_DURATION_WINDOW_DISTRIBUTIONAL_MAP_ONLY' or
            auth.get('execution_allowed') is not True or
            auth.get('preflight_sha256')!=sha(HERE/'map_preflight.json')):
        raise ValueError('Frozen map-only authorization required')
    expected=dict(real=200_000_000_000,angular=2_000_000_000,CPU_seconds=600,
                  numeric_ORF=1024**3,RSS=1536*1024**2,moment_numeric=256*1024**2)
    if auth.get('caps')!=expected:raise ValueError('Map resource caps changed')
    if not plan['within_proposed_budgets']:raise ValueError('Physical preflight exceeds caps')
    required={str(Path(__file__).relative_to(ROOT)),str((HERE/'window_moments.py').relative_to(ROOT)),
        'tmp/c08_gaussian_comparison/src/inference/gaussian_metrics.py',
        'src/inference/__init__.py','src/inference/model.py','src/inference/orf_blas.py'}
    required.update(str(p.relative_to(ROOT)) for p in (ROOT/'src/pta').glob('*.py'))
    if not required<=set(auth['source_sha256']):raise ValueError('Incomplete scientific source closure')
    if 64*1024**2+plan['moment_array_estimate_bytes']>expected['moment_numeric']:
        raise MemoryError('Moment accumulator and real-reference allowance exceed map budget')
    for name in set(plan['source_sha256']) & set(auth['source_sha256']):
        if plan['source_sha256'][name]!=auth['source_sha256'][name]:
            raise ValueError('Authorization cannot replace a preflight source hash: '+name)
    for name,digest in {**plan['source_sha256'],**auth['source_sha256']}.items():
        if sha(ROOT/name)!=digest:raise ValueError('Frozen map source changed: '+name)
    if auth['source_sha256'].get(str(Path(__file__).relative_to(ROOT)))!=sha(__file__):
        raise ValueError('Runner is absent from its own source closure')
    return auth,plan


def exp_at(T):
    cfg=json.loads((ROOT/'configs/calibration/prior_predictive_500_v1.json').read_text())
    return experiment(dict(cfg,duration_years=T))


def harmonic_worker(plan,row_index,level_index,out):
    row=plan['rows'][row_index];level=row['levels'][level_index];e=exp_at(row['duration_years'])
    beta=np.array(row['unique_beta']);y=2*np.pi*e['f'][row['channel']-1]*e['distance_ly']*YEAR
    budget=TableBudget(maximum_estimated_memory_bytes=1024**3-64*1024**2,
                       maximum_multiplications_per_batch=50_000_000_000,maximum_batch_size=4)
    basis=RealHarmonicBasis(e['points'],lmax=level['lmax'],nmu=level['nmu'],budget=budget,planned_batch=4)
    gamma=np.empty((len(beta),12,12),complex)
    for first in range(0,len(beta),4):gamma[first:first+4]=basis.evaluate(beta[first:first+4],y)
    if not np.isfinite(gamma).all() or np.max(abs(gamma-gamma.swapaxes(1,2).conj()))>1e-12:
        raise ValueError('Nonfinite/non-Hermitian map ORF')
    minimum=float(np.linalg.eigvalsh(gamma).min())
    if minimum < -1e-12:raise ValueError('Map ORF not PSD; no clipping')
    save_npz(out/'arrays.npz',beta=beta,Gamma=gamma)
    return dict(scope='RAW_HARMONIC_MAP_MATRICES',row=row_index,level=level_index,
                real_products=level['real_products'],angular=0,minimum_eigenvalue=minimum,
                arrays_sha256=sha(out/'arrays.npz'))


def load_harmonic(root,ri,li):
    execution=json.loads((root/'execution_request.json').read_text())
    auth,plan=load_authorization(Path(execution['authorization_path']))
    if execution['authorization_sha256']!=sha(execution['authorization_path']):
        raise ValueError('Campaign authorization identity changed')
    base=root/f'harmonic_{ri:02d}_{li}'
    r=json.loads((base/'report.json').read_text())
    if (r.get('scope')!='RAW_HARMONIC_MAP_MATRICES' or r.get('row')!=ri or r.get('level')!=li or
            r.get('authorization_sha256')!=execution['authorization_sha256'] or
            r.get('real_products')!=plan['rows'][ri]['levels'][li]['real_products'] or r.get('angular')!=0):
        raise ValueError('Harmonic cache row/level/authorization mismatch')
    if r['arrays_sha256']!=sha(base/'arrays.npz'):raise ValueError('Harmonic cache hash differs')
    with np.load(base/'arrays.npz',allow_pickle=False) as f:
        if set(f.files)!={'beta','Gamma'}:raise ValueError('Unexpected harmonic members')
        beta,gamma=f['beta'],f['Gamma']
    expected=np.array(plan['rows'][ri]['unique_beta'],dtype=float)
    if (beta.dtype!=np.dtype('float64') or beta.shape!=expected.shape or beta.tobytes()!=expected.tobytes() or
            gamma.dtype!=np.dtype('complex128') or gamma.shape!=(len(expected),12,12) or
            not np.isfinite(gamma).all() or np.max(abs(gamma-gamma.swapaxes(1,2).conj()))>1e-12 or
            np.linalg.eigvalsh(gamma).min() < -1e-12):
        raise ValueError('Invalid harmonic beta/shape/finitude/Hermiticity/PSD')
    return beta,gamma


def direct_worker(plan,index,out,root):
    row=plan['direct_checks'][index];e=exp_at(row['duration_years'])
    ri=next(i for i,r in enumerate(plan['rows']) if r['duration_years']==row['duration_years'] and r['channel']==row['channel'])
    beta,gamma=load_harmonic(root,ri,2);node=np.flatnonzero(beta==row['beta'])
    if len(node)!=1:raise ValueError('Direct beta is not the exact harmonic beta')
    y=2*np.pi*e['f'][row['channel']-1]*e['distance_ly']*YEAR;records=[]
    for a,b in row['pairs']:
        values=[raw_direct_orf(row['beta'],float(e['points'][a]@e['points'][b]),float(y[a]),float(y[b]),
                               nmu=nmu,nphi=nphi) for nmu,nphi in row['orders_nmu_nphi']]
        ref=gamma[node[0],a,b];diff=abs(values[0]-values[1]);error=abs(values[1]-ref)
        records.append(dict(pair=[a,b],coarse=[values[0].real,values[0].imag],
                            fine=[values[1].real,values[1].imag],harmonic=[ref.real,ref.imag],
                            coarse_fine=float(diff),fine_harmonic=float(error)))
    return dict(scope='INDEPENDENT_DIRECT_SKY_MAP_CHECK',real_products=0,angular=row['sky_points'],
                passed=all(x['coarse_fine']<=1e-7 and x['fine_harmonic']<=1e-7 for x in records),checks=records)


def response_stack(plan,root,T,u,variant,level):
    values=[]
    for k in range(1,5):
        channel=1 if variant=='C_full' else k
        ri=next(i for i,r in enumerate(plan['rows']) if r['duration_years']==T and r['channel']==channel)
        row=plan['rows'][ri];wanted='B' if variant=='B' else 'C_beta'
        beta=next(x['beta'] for x in row['requests'] if x['variant']==wanted and x['u']==u)
        nodes,gamma=load_harmonic(root,ri,level);where=np.flatnonzero(nodes==beta)
        if len(where)!=1:raise ValueError('Missing exact response node')
        values.append(gamma[where[0]])
    return np.array(values)


def independent_real_moments(c,h,scales,op):
    k,p,_=c.shape;d=len(h);big=np.zeros((k*p,k*p),complex)
    for a in range(k):big[a*p:(a+1)*p,a*p:(a+1)*p]=scales[a]*c[a]
    Q=np.kron(op,np.eye(p));big=Q@big@Q.conj().T
    si=np.repeat(1/np.sqrt(scales),p);big=si[:,None]*big*si[None,:]
    real=.5*np.block([[big.real,-big.imag],[big.imag,big.real]])
    J=[]
    for a in range(k):
        for b in range(d):
            A=np.zeros_like(big);A[a*p:(a+1)*p,a*p:(a+1)*p]=h[b]
            J.append(np.block([[A.real,-A.imag],[A.imag,A.real]]))
    JR=np.array(J)@real
    return np.trace(JR,axis1=-2,axis2=-1),2*np.einsum('iab,jba->ij',JR,JR,optimize=True)


def moments_worker(plan,out,root):
    d=plan['map_design'];etas=list(itertools.product(d['log10_Agw'],d['gamma_gw'],d['log10_Ar'],d['log10_EFAC']))
    variants=['B','C_beta','C_full'];operators=[np.eye(4),np.diag(np.full(4,.5))+np.diag(np.full(3,-.25),1)+np.diag(np.full(3,-.25),-1)]
    metadata=[];means=[];covariances=[];comparisons=[];references=[];wrong_compression=[]
    for T in d['duration_years']:
        e=exp_at(T)
        for u in d['u_nodes']:
            gamma=[[response_stack(plan,root,T,u,v,lev) for v in variants] for lev in range(3)]
            for eta_id,eta in enumerate(etas):
                for window_id,op in enumerate(operators):
                    perlevel=[]
                    for level in range(3):
                        values=[]
                        for vi,variant in enumerate(variants):
                            c=covariance_batch(np.array(eta),gamma[level][vi],e)[0][0]
                            result=window_moments(c,e['H'],e['scale'],op,e['weights'],maximum_numeric_bytes=256*1024**2)
                            metadata.append([T,u,eta_id,window_id,level,vi]);means.append(result['compressed_mean']);covariances.append(result['compressed_covariance']);values.append(result)
                            if level==2 and u in [0,.995] and eta_id in [0,15]:
                                mu,sigma=independent_real_moments(c,e['H'],e['scale'],op)
                                rm=float(np.max(abs(mu-result['mean_by_frequency'].ravel()))/max(1.,np.max(abs(mu))))
                                rs=float(np.max(abs(sigma-result['covariance_full']))/max(1.,np.max(abs(sigma))))
                                references.append(dict(T=T,u=u,eta=eta_id,window=window_id,variant=variant,mean_error=rm,covariance_error=rs))
                            if level==2:
                                full=result['covariance_full'];wrong=sum(e['weights'][k]**2*full[k*10:k*10+10,k*10:k*10+10] for k in range(4))
                                denominator=max(float(np.linalg.norm(result['compressed_covariance'])),np.finfo(float).tiny)
                                wrong_compression.append([T,u,eta_id,window_id,vi,float(np.linalg.norm(wrong-result['compressed_covariance'])/denominator)])
                        for p,q in [(0,1),(0,2),(1,2)]:
                            a,b=values[p],values[q]
                            forward=gaussian_comparison(a['compressed_mean'],a['compressed_covariance'],b['compressed_mean'],b['compressed_covariance'])
                            backward=gaussian_comparison(b['compressed_mean'],b['compressed_covariance'],a['compressed_mean'],a['compressed_covariance'])
                            comparisons.append([T,u,eta_id,window_id,level,p,q,forward['kl_p_to_q'],backward['mean_mahalanobis_squared'],forward['covariance_whitened_frobenius']])
    metadata=np.array(metadata);means=np.array(means);covariances=np.array(covariances);comparisons=np.array(comparisons)
    errors=[]
    # Ordering is fixed above: three variants within each of three levels.
    for start in range(0,len(means),9):
        for a,b in [(0,1),(1,2)]:
            for vi in range(3):
                ma,mb=means[start+3*a+vi],means[start+3*b+vi]
                sa,sb=covariances[start+3*a+vi],covariances[start+3*b+vi]
                errors.append([float(np.max(abs(ma-mb))/max(1.,np.max(abs(mb)))),float(np.max(abs(sa-sb))/max(1.,np.max(abs(sb))))])
    metric_errors=[]
    for start in range(0,len(comparisons),9):
        for a,b in [(0,1),(1,2)]:
            metric_errors.append(float(np.max(abs(comparisons[start+3*a:start+3*a+3,7:]-comparisons[start+3*b:start+3*b+3,7:]))))
    errors=np.array(errors)
    passed=(np.max(errors)<=1e-10 and max(metric_errors)<=.001 and
            all(max(x['mean_error'],x['covariance_error'])<=1e-10 for x in references))
    save_npz(out/'arrays.npz',metadata=metadata,eta=np.array(etas),means=means,covariances=covariances,
             comparisons=comparisons,coarse_fine_moment_errors=errors,wrong_compression=np.array(wrong_compression))
    return dict(scope='DISTRIBUTIONAL_MOMENTS_ONLY_NOT_POSTERIORS',passed=bool(passed),
        unique_moment_cases=len(means)//3,moment_evaluations_all_resolutions=len(means),
        independent_real_reference_cases=len(references),reference_checks=references,
        mean_and_covariance_normalized_resolution_max=float(np.max(errors)),
        distribution_metric_resolution_max=float(max(metric_errors)),
        arrays_sha256=sha(out/'arrays.npz'),real_products=0,angular=0,
        likelihood_evaluations=0,posterior_evaluations=0,
        KL_is_between_real_normal_controls_not_quadratic_CN_distributions=True,
        equal_u_at_different_T_is_different_physical_mass=True,
        array_columns=dict(metadata=['T','u','eta_index','window_index','resolution_index','variant_index'],
                           comparisons=['T','u','eta_index','window_index','resolution_index','variant_p','variant_q','KL_p_to_q','mean_shift_metric_p','covariance_difference_metric_q']),
        variants=variants,windows=plan['windows'])


def execute_worker(a,auth,plan):
    a.output.mkdir(parents=True,exist_ok=False);start=time.process_time();wall=time.perf_counter()
    try:
        if a.worker=='harmonic':report=harmonic_worker(plan,a.row,a.level,a.output)
        elif a.worker=='direct':report=direct_worker(plan,a.row,a.output,a.campaign)
        else:report=moments_worker(plan,a.output,a.campaign)
        report.update(CPU_seconds=time.process_time()-start,wall_seconds=time.perf_counter()-wall,
                      RSS_peak_bytes=int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),
                      authorization_sha256=sha(a.authorization))
        if report['RSS_peak_bytes']>auth['caps']['RSS']:raise MemoryError('Worker RSS cap exceeded')
        if report['CPU_seconds']>auth['caps']['CPU_seconds']:raise RuntimeError('Worker CPU cap exceeded')
        write_json(a.output/'report.json',report)
        if report.get('passed') is False:raise RuntimeError('Finite gate failed; no automatic retry')
    except Exception as exc:
        write_json(a.output/'failure.json',dict(status='FAILED_NO_AUTOMATIC_RETRY',error=str(exc),
            CPU_seconds=time.process_time()-start,RSS_peak_bytes=int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)))
        raise


def execute(a,auth,plan):
    a.output.mkdir(parents=True,exist_ok=False);charges=dict(real=0,angular=0,CPU_seconds=0.);records=[]
    write_json(a.output/'execution_request.json',dict(authorization_path=str(a.authorization.resolve()),
        authorization_sha256=sha(a.authorization),preflight_sha256=sha(HERE/'map_preflight.json'),
        moment_accumulator_and_reference_allowance_bytes=64*1024**2,
        total_moment_numeric_estimate_bytes=64*1024**2+plan['moment_array_estimate_bytes'],
        CPU_accounting='Child user+system CPU including process startup/imports, measured by controller RUSAGE_CHILDREN',
        real_product_accounting='Harmonic real BLAS products only; basis setup, moments, references and metrics additionally counted by measured CPU',
        child_CPU_limit='RLIMIT_CPU soft=floor(remaining CPU), hard=soft+1; default SIGXCPU stops worker; no retry'))
    jobs=[('harmonic',i,j) for i in range(len(plan['rows'])) for j in range(3)]
    jobs += [('direct',i,0) for i in range(len(plan['direct_checks']))]+[('moments',0,0)]
    try:
        for kind,row,level in jobs:
            if kind=='harmonic':cost=plan['rows'][row]['levels'][level]['real_products'];angular=0
            elif kind=='direct':cost=0;angular=plan['direct_checks'][row]['sky_points']
            else:cost=angular=0
            if charges['real']+cost>auth['caps']['real'] or charges['angular']+angular>auth['caps']['angular']:
                raise RuntimeError('Resource reservation exceeds map cap')
            remaining=auth['caps']['CPU_seconds']-charges['CPU_seconds']
            seconds_limit=math.floor(remaining)
            if seconds_limit<1:raise RuntimeError('Less than one second remains in cumulative CPU budget')
            charges['real']+=cost;charges['angular']+=angular
            name=f'harmonic_{row:02d}_{level}' if kind=='harmonic' else f'{kind}_{row:02d}'
            with (a.output/'ledger.jsonl').open('a') as f:f.write(json.dumps(dict(event='reserved',name=name,**charges))+'\n');f.flush();os.fsync(f.fileno())
            cmd=[sys.executable,str(Path(__file__).resolve()),'--worker',kind,'--row',str(row),'--level',str(level),
                 '--authorization',str(a.authorization.resolve()),'--campaign',str(a.output.resolve()),'--output',str((a.output/name).resolve())]
            def cpu_limit():resource.setrlimit(resource.RLIMIT_CPU,(seconds_limit,seconds_limit+1))
            before=resource.getrusage(resource.RUSAGE_CHILDREN)
            run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,preexec_fn=cpu_limit)
            after=resource.getrusage(resource.RUSAGE_CHILDREN)
            child_cpu=(after.ru_utime-before.ru_utime)+(after.ru_stime-before.ru_stime)
            charges['CPU_seconds']+=child_cpu
            (a.output/(name+'.log')).write_text(run.stdout)
            rp=a.output/name/'report.json';fp=a.output/name/'failure.json'
            if rp.exists():r=json.loads(rp.read_text());records.append(dict(name=name,report_sha256=sha(rp),child_CPU_seconds_including_startup=child_cpu,**r))
            if run.returncode:raise RuntimeError('Worker stopped; preserved '+name)
            if charges['CPU_seconds']>auth['caps']['CPU_seconds']:raise RuntimeError('Cumulative CPU cap exceeded')
            print(json.dumps(dict(event='worker_completed',name=name,**charges)),flush=True)
            if kind=='harmonic' and level==2:
                gamma=[load_harmonic(a.output,row,j)[1] for j in range(3)]
                errors=[float(np.max(abs(gamma[0]-gamma[1]))),float(np.max(abs(gamma[1]-gamma[2])))]
                write_json(a.output/f'harmonic_gate_{row:02d}.json',dict(errors=errors,passed=max(errors)<=1e-8))
                if max(errors)>1e-8:raise RuntimeError('Harmonic refinement failed')
        load_authorization(a.authorization)
        write_json(a.output/'complete.json',dict(status='FINITE_DISTRIBUTIONAL_MAP_GATES_PASS_NOT_POSTERIORS',
            authorization_sha256=sha(a.authorization),resources=charges,workers=records,
            actual_worker_peak_RSS_bytes=max(r['RSS_peak_bytes'] for r in records),
            table_or_interpolation_created=False,likelihood_evaluations=0,posterior_evaluations=0))
    except Exception as exc:
        write_json(a.output/'failure.json',dict(status='STOPPED_WITHOUT_AUTOMATIC_REFINEMENT',error=str(exc),resources=charges,completed_workers=len(records)))
        raise


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true')
    p.add_argument('--worker',choices=['harmonic','direct','moments']);p.add_argument('--row',type=int,default=0);p.add_argument('--level',type=int,default=0)
    for name in ['authorization','output','campaign']:p.add_argument('--'+name,type=Path)
    a=p.parse_args()
    if not a.execute and not a.worker:print('Design only. Review map_preflight.json and freeze explicit source-bound authorization.');sys.exit(0)
    if a.authorization is None or a.output is None:p.error('Execution needs authorization and a new output directory')
    auth,plan=load_authorization(a.authorization)
    if a.worker:execute_worker(a,auth,plan)
    else:execute(a,auth,plan)
