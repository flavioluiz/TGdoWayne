# Momentos após janela em frequência

Componente prospectivo C08. `window_moments.py` transforma covariâncias de canais independentes normalizados por sqrt(scale), aplicando a janela aos coeficientes físicos e retendo a covariância entre frequências. A hipótese é gaussiana complexa própria, com pseudocovariância zero, preservada por uma transformação complexa linear finita.

A saída fornece os momentos quadráticos completos e a compressão com pesos fixos. Não calcula uma ORF, uma densidade posterior ou uma cobertura. O caso Hann projetado e a identidade retangular podem usar esta álgebra; TOAs irregulares e ajuste de temporização não estão representados.

Seis testes sintéticos passaram em 0,099 s reportados por unittest. A referência independente transforma os coeficientes físicos e usa Isserlis na covariância real de dimensão 2KP. A retirada dos blocos entre frequências muda o resultado no controle Hann. A janela nula preserva a singularidade sem piso de autovalores. O teto de arrays é checado por metadados antes da leitura dos valores; a estimativa exclui retenção do alocador e não garante RSS.

Comando: `VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python tmp/c08_window_moments/test_window_moments.py`.

Nenhuma campanha científica foi executada para produzir este pacote.
