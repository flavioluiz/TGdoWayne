"""Metadata-only physical cost plan for the predeclared duration/window map."""
from pathlib import Path
import hashlib,json,math,sys
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'src'))
from inference.model import experiment,YEAR
from inference.orf_blas import estimate
from window_moments import estimated_numeric_bytes


def main():
    design=json.loads((ROOT/'tmp/c08_execution_design/config_prospectiva.json').read_text())
    cfg=json.loads((ROOT/'configs/calibration/prior_predictive_500_v1.json').read_text())
    mapcfg=design['duration_window_distribution_map'];rows=[];direct=[]
    sources=[Path(__file__),HERE/'window_moments.py',ROOT/'tmp/c08_execution_design/config_prospectiva.json',
             ROOT/'configs/calibration/prior_predictive_500_v1.json',ROOT/'src/inference/model.py',
             ROOT/'src/inference/orf_blas.py',ROOT/'src/pta/orf.py',ROOT/'src/pta/response.py']
    for T in mapcfg['duration_years']:
        local=dict(cfg,duration_years=T);e=experiment(local)
        y=2*np.pi*e['f'][:,None]*e['distance_ly'][None,:]*YEAR
        for k in range(1,5):
            requests=[]
            for u in mapcfg['u_nodes']:
                for variant in ['B','C_beta']:
                    b=np.sqrt((1-u/(k if variant=='B' else 1))*(1+u/(k if variant=='B' else 1)))
                    requests.append(dict(u=u,variant=variant,beta=float(b)))
            unique=np.unique([x['beta'] for x in requests]).tolist()
            ymax=float(y[k-1].max());ell=math.ceil(ymax)+100;nmu=math.ceil(2*ymax)+220
            levels=[dict(label='H00',lmax=ell,nmu=nmu),dict(label='H01',lmax=ell,nmu=nmu+80),
                    dict(label='H11',lmax=ell+40,nmu=nmu+80)]
            for level in levels:
                report=estimate(level['lmax'],level['nmu'],12,4)
                level.update(real_products=2*len(unique)*12*level['nmu']*(level['lmax']-1),
                             arrays_estimate_bytes=report['estimated_memory_bytes']+64*1024**2)
            rows.append(dict(duration_years=T,channel=k,phase_max=ymax,requests=requests,
                             unique_beta=unique,unique_nodes=len(unique),levels=levels,
                             workers='one fresh process per frequency/resolution; serial, BLAS1'))
        ymax=float(y[3].max())
        for u in [0.,.995]:
            beta=float(np.sqrt((1-u)*(1+u)));nmu=math.ceil(2*beta*ymax)+220
            orders=[[nmu,min(2*nmu,19840)],[nmu+80,min(2*(nmu+80),20000)]]
            direct.append(dict(duration_years=T,channel=4,variant='C_beta',u=u,beta=beta,
                pairs=[[3,8],[0,11]],orders_nmu_nphi=orders,
                sky_points=2*sum(a*b for a,b in orders),
                arrays_estimate_bytes=max(a for a,b in orders)*128*384+64*1024**2,
                harmonic_reference='H11 same represented beta/physical phases; no respline'))
    work=sum(x['real_products'] for r in rows for x in r['levels']);sky=sum(x['sky_points'] for x in direct)
    mem=max(x['arrays_estimate_bytes'] for r in rows for x in r['levels']);dm=max(x['arrays_estimate_bytes'] for x in direct)
    result=dict(schema='C08_DURATION_WINDOW_MAP_PREFLIGHT_v1',status='DESIGN_ONLY_NO_PHYSICAL_EXECUTION',
        execution_enabled=False,map_design=mapcfg,rows=rows,direct_checks=direct,
        total_unique_frequency_ORF_nodes=sum(r['unique_nodes'] for r in rows),
        quadrature_matrix_evaluations=3*sum(r['unique_nodes'] for r in rows),
        planned_real_products=work,maximum_real_products=200_000_000_000,
        planned_direct_sky_points=sky,maximum_direct_sky_points=2_000_000_000,
        maximum_harmonic_arrays_estimate_bytes=mem,maximum_direct_arrays_estimate_bytes=dm,
        maximum_numeric_ORF_bytes=1024**3,maximum_RSS_bytes=1536*1024**2,
        moment_array_estimate_bytes=estimated_numeric_bytes(4,12,10),
        maximum_moment_numeric_bytes=256*1024**2,maximum_CPU_seconds_proposed=600,
        gates=dict(harmonic_nmu_max_abs=1e-8,harmonic_lmax_max_abs=1e-8,
            direct_coarse_fine_max_abs=1e-7,direct_harmonic_max_abs=1e-7,
            moment_normalized_max_abs=1e-10,distribution_metric_resolution_max_abs=.001),
        moment_cases=1440,complex_covariance_dimension=48,quadratic_covariance_dimension=40,
        windows=['periodic_rectangle','periodic_Hann_projected_positive_modes1to4'],
        likelihood_evaluations=0,posterior_evaluations=0,
        weak_dispersion_expansion_and_extra8u_map_included=False,
        new_duration_ORFs_reused_as_C07_table=False,
        source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    result['within_proposed_budgets']=(work<=result['maximum_real_products'] and sky<=result['maximum_direct_sky_points'] and
                                     max(mem,dm)<=result['maximum_numeric_ORF_bytes'])
    with (HERE/'map_preflight.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['map_design','rows','direct_checks','source_sha256']},indent=2))


if __name__=='__main__':main()
