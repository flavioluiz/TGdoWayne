import unittest
from unittest.mock import patch
import numpy as np
from window_moments import window_moments,estimated_numeric_bytes


class WindowMomentsTests(unittest.TestCase):
    def fixture(self,k=4,p=3,d=5):
        r=np.random.default_rng(808160101)
        a=r.normal(size=(k,p,p))+1j*r.normal(size=(k,p,p))
        c=a@a.swapaxes(-2,-1).conj()+np.eye(p)
        b=r.normal(size=(d,p,p))+1j*r.normal(size=(d,p,p))
        h=(b+b.swapaxes(-2,-1).conj())/2
        return c,h,np.geomspace(.1,100,k),np.full(k,1/k)

    def independent_real_reference(self,c,h,s,op,w):
        k,p,_=c.shape;d=len(h)
        # Work entirely in physical coefficients, using a real 2KP covariance.
        big=np.zeros((k*p,k*p),complex)
        for a in range(k):big[a*p:(a+1)*p,a*p:(a+1)*p]=s[a]*c[a]
        q=np.kron(op,np.eye(p));big=q@big@q.conj().T
        scale=np.repeat(1/np.sqrt(s),p);big=scale[:,None]*big*scale[None,:]
        real=.5*np.block([[big.real,-big.imag],[big.imag,big.real]])
        j=[]
        for a in range(k):
            for b in range(d):
                mat=np.zeros_like(big);mat[a*p:(a+1)*p,a*p:(a+1)*p]=h[b]
                j.append(np.block([[mat.real,-mat.imag],[mat.imag,mat.real]]))
        jk=np.array(j)@real
        return np.trace(jk,axis1=-2,axis2=-1),2*np.einsum('iab,jba->ij',jk,jk)

    def test_hann_against_independent_real_Isserlis_and_scale_route(self):
        c,h,s,w=self.fixture();op=np.diag(np.full(4,.5))+np.diag(np.full(3,-.25),1)+np.diag(np.full(3,-.25),-1)
        got=window_moments(c,h,s,op,w);m,v=self.independent_real_reference(c,h,s,op,w)
        np.testing.assert_allclose(got['mean_by_frequency'].ravel(),m,atol=2e-12,rtol=2e-13)
        np.testing.assert_allclose(got['covariance_full'],v,atol=1e-10,rtol=2e-13)
        W=np.kron(w[None],np.eye(len(h)))
        np.testing.assert_allclose(got['compressed_covariance'],W@v@W.T,atol=1e-11,rtol=2e-13)
        wrong=sum(w[k]**2*v[k*len(h):(k+1)*len(h),k*len(h):(k+1)*len(h)] for k in range(4))
        self.assertGreater(np.max(abs(wrong-got['compressed_covariance']))/np.max(abs(got['compressed_covariance'])),.01)

    def test_complex_linear_window_against_real_reference(self):
        c,h,s,w=self.fixture(k=3,p=2,d=3)
        op=np.array([[1,.1j,0],[.3,.5,-.2j],[0,-.4j,.6]],complex)
        got=window_moments(c,h,s,op,w);m,v=self.independent_real_reference(c,h,s,op,w)
        np.testing.assert_allclose(got['mean_by_frequency'].ravel(),m,atol=1e-12,rtol=2e-13)
        np.testing.assert_allclose(got['covariance_full'],v,atol=1e-11,rtol=2e-13)

    def test_rectangle_matches_independent_frequency_formula(self):
        c,h,s,w=self.fixture();got=window_moments(c,h,s,np.eye(4),w)
        for a in range(4):
            hc=h@c[a];expected=np.einsum('iab,jba->ij',hc,hc).real
            np.testing.assert_allclose(got['covariance_full'][5*a:5*a+5,5*a:5*a+5],expected,atol=1e-12)
            for b in range(4):
                if a!=b:np.testing.assert_array_equal(got['covariance_full'][5*a:5*a+5,5*b:5*b+5],np.zeros((5,5)))

    def test_budget_before_value_scan_or_cholesky(self):
        c,h,s,w=self.fixture();c[0,0,0]=np.nan
        with patch('numpy.isfinite',side_effect=AssertionError('premature value scan')):
            with self.assertRaises(MemoryError):window_moments(c,h,s,np.eye(4),w,maximum_numeric_bytes=1)
        self.assertLess(estimated_numeric_bytes(8,16,16),64*1024**2)

    def test_input_guards_and_owned_readonly_outputs(self):
        c,h,s,w=self.fixture();original=c.copy();got=window_moments(c,h,s,np.eye(4),w)
        np.testing.assert_array_equal(c,original)
        for name,a in got.items():
            if name!='diagnostics':self.assertFalse(a.flags.writeable);self.assertFalse(np.shares_memory(a,c))
        with self.assertRaises(ValueError):window_moments(c,h,-s,np.eye(4),w)
        with self.assertRaises(TypeError):window_moments(c.tolist(),h,s,np.eye(4),w)
        bad=h.copy();bad[0,0,1]+=1
        with self.assertRaises(ValueError):window_moments(c,bad,s,np.eye(4),w)
        bad=c.copy();bad[0,0,0]=-100
        with self.assertRaises(np.linalg.LinAlgError):window_moments(bad,h,s,np.eye(4),w)

    def test_zero_window_keeps_singular_moments_without_floor(self):
        c,h,s,w=self.fixture();got=window_moments(c,h,s,np.zeros((4,4)),w)
        np.testing.assert_array_equal(got['compressed_mean'],np.zeros(5))
        np.testing.assert_array_equal(got['compressed_covariance'],np.zeros((5,5)))
        self.assertEqual(got['diagnostics']['minimum_quadratic_covariance_eigenvalue'],0)


if __name__=='__main__':unittest.main(verbosity=2)
