"""TOY derivative validation, no physical harmonic basis or ORF integration."""
from pathlib import Path
import hashlib,json,math,resource,sys,time,unittest
import numpy as np
import mpmath as mp
from derivative import transfer_dD


class DerivativeTests(unittest.TestCase):
    maximum_relative_or_absolute_error=0.
    comparisons=0

    def test_mpmath_closed_form(self):
        mp.mp.dps=70
        for y in [0.,1e-5,1.,70.,1396.2634015954636,5585.053606381854,6284.]:
            D=[0.,1e-16,1e-12,1e-8,.1,.9,1.,1.7,2.]
            if y>=1:D += [.5/y,(.5-1e-10)/y,(.5+1e-10)/y]
            got=transfer_dD(y,np.array(D))
            for d,value in zip(D,got):
                a,b=mp.mpf(y),mp.mpf(d)
                expected=a*a/2 if d==0 else ((1+1j*a*b)*mp.exp(-1j*a*b)-1)/(b*b)
                error=float(abs(mp.mpc(value)-expected)/max(mp.mpf(1),abs(expected)))
                type(self).comparisons+=1
                type(self).maximum_relative_or_absolute_error=max(type(self).maximum_relative_or_absolute_error,error)
                self.assertLess(error,4e-12,(y,d,error))

    def test_independent_integral_identity(self):
        # transfer(D)=i*y*int_0^1 exp(-i*y*D*t)dt;
        # derivative=y^2*int_0^1 t exp(-i*y*D*t)dt.
        mp.mp.dps=60
        for y,d in [(0.,0.),(1.,0.),(1.,.49),(7.,.5),(19.,1.2)]:
            expected=mp.mpf(y)**2*mp.quad(lambda t:t*mp.exp(-1j*y*d*t),[0,1])
            self.assertLess(abs(complex(transfer_dD(y,np.array(d)))-complex(expected)),2e-13)

    def test_removable_limit_and_shape(self):
        y=5585.053606381854
        a=transfer_dD(y,np.zeros((2,3)))
        self.assertEqual(a.shape,(2,3));self.assertTrue(np.all(a==y*y/2))
        self.assertEqual(transfer_dD(0,np.array([0.,.5,2.])).tolist(),[0j,0j,0j])

    def test_declared_domain_guards(self):
        for y,d in [(True,0),(-1,0),(6285,0),(math.nan,0),(1,-.01),(1,2.01),(1,complex(1)),(1,math.nan)]:
            with self.assertRaises(ValueError):transfer_dD(y,np.asarray(d))
        with self.assertRaises(ValueError):transfer_dD(1,np.zeros(1000001))


if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(29,30));start=time.process_time()
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(DerivativeTests))
    paths=[Path(__file__),Path(__file__).with_name('derivative.py')]
    report=dict(scope='SYNTHETIC_SCALAR_TRANSFER_DERIVATIVE_ONLY',tests=result.testsRun,passed=result.wasSuccessful(),
        high_precision_comparisons=DerivativeTests.comparisons,maximum_relative_or_absolute_error=DerivativeTests.maximum_relative_or_absolute_error,
        CPU_seconds=time.process_time()-start,RSS_bytes=int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),
        physical_ORFs=0,likelihoods=0,physical_data_draws=0,harmonic_derivative_contraction_not_yet_validated=True,
        source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    with Path(__file__).with_name('validation.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    sys.exit(not result.wasSuccessful())
