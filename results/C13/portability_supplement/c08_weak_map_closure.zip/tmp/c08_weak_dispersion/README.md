# Dispersão fraca: componente e preflight candidato

`derivative.py` implementa a derivada analítica da transferência removível,

\[
\partial_D\frac{1-e^{-iyD}}{D}
=\frac{(1+iyD)e^{-iyD}-1}{D^2},\qquad
\partial_D g(y,0)=y^2/2.
\]

Para `|yD|<=0.5`, usa uma série de 25 termos; fora desse intervalo, usa
`expm1` e a expressão fechada. A derivada em beta acrescenta o fator mu.
A derivada da matriz usa a regra do produto sobre os coeficientes complexos
da expansão harmônica, mantendo as fases de cada pulsar.

Foram executados quatro testes escalares (78 comparações com 70 dígitos,
erro relativo ou absoluto máximo4,49e−13;0,129sCPU,39,1MBRSS) e um teste da
derivada da matriz complexa completa com base deliberadamente não física
(nove entradas, erro1,09e−15;0,259sCPU,48,5MBRSS). O segundo teste diferencia
a expressão completa por mpmath, sem reutilizar a regra do produto
implementada. Nenhuma ORF física, likelihood, posterior ou dado físico foi
calculado. Logs e hashes ficam ao lado dos testes; o primeiro registro
antecede a verificação separada da contração.

`prepare.py` faz somente aritmética. Seu candidato combina o mapa de oito
massas de C08 com os três pontos de dispersão fraca e uma verificação da
derivada por diferenças unilaterais. O número de nós novos é67 por frequência
individual, antes das três resoluções, e não os24 novos nós dos canais2–4
que apareciam no desenho inicial do mapa simples. O acréscimo verifica também
o primeiro canal, a expansão e a derivada. Portanto, a execução exigirá
registrar explicitamente essa extensão finita do preflight; estar dentro do
teto de operações não autoriza silenciosamente uma alteração do desenho.

O proxy planejado é183.897.455.812 operações reais, abaixo do teto adicional
de200bilhões. A maior estimativa de arrays, com64MiB de reserva, é630.648.664
bytes. São12 processos sequenciais de quadratura, com um thread cada; nenhum
foi iniciado. O trabalhador posterior de momentos e métricas ainda não está
implementado/orçado neste candidato. Não há executor ou autorização física.

As matrizes já concluídas no mapa de duração/janela podem ser reutilizadas
apenas após conferir seus relatórios, arquivos, autorizações e fontes. Isso
evita repetir os nós comuns sem converter concordância de cache em nova
quadratura independente. A derivada será confrontada com diferenças
unilaterais e com refinamentos separados em número de nós e corte harmônico.
Não existe ainda uma integração independente da derivada no céu.

O alvo assintótico é a diferença **C_beta−B** em fases fixas:

\[
\delta\Gamma_k=-\tfrac12u^2(1-k^{-2})\partial_\beta\Gamma(1,y_k)+O(u^4).
\]

O mapa usa u=.001,.002,.004 e a guia max(y)u²/2=.04468. Essa guia não é
uma cota uniforme de erro. Os restos e razões entre normas devem ser
apresentados com a resolução numérica e possíveis cancelamentos; não exigir
razão exatamente16 para todo elemento. Os momentos devem usar os fatores
físicos `Pgw/scale`, os pesos de compressão e os termos cruzados com ruído.
C_full tem também uma discrepância de fase em u=0 e não deve ser ajustada
à mesma lei sem termo constante.

Reprodução leve: executar os testes em cópia nova, pois seus registros não
são sobrescritos. `prepare.py` também exige saída ainda inexistente. Os
artefatos atuais permanecem prospectivos e não integram o release C07.
