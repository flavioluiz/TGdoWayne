"""Analytic derivative of the removable PTA transfer, for future C08 checks.

No physical ORF evaluation is performed on import. Phase is dimensionless;
the derivative is with respect to D=1+beta*mu at fixed phase y.
"""
import math
import numpy as np


def transfer_dD(y, D):
    """d[(1-exp(-i*y*D))/D]/dD, continuous at D=0 with y**2/2."""
    if isinstance(y,bool) or not np.isscalar(y) or not np.isfinite(y) or not 0<=y<=6284:
        raise ValueError('Finite scalar phase in the declared interval [0,6284]')
    D=np.asarray(D)
    if D.dtype.kind not in 'fiu' or D.size>1_000_000 or not np.isfinite(D).all():
        raise ValueError('Finite real D array within the explicit size budget')
    D=np.asarray(D,float)
    if np.any((D<0)|(D>2)):raise ValueError('This physical derivative uses D in [0,2]')
    z=y*D;flat=z.ravel();answer=np.empty_like(flat,dtype=complex)
    small=abs(flat)<=.5
    # h(z)=sum_(n>=0) (n+1)(-i*z)^n/(n+2)!; 25 terms.
    v=-1j*flat[small]
    series=np.full(v.shape,25/math.factorial(26),complex)
    for n in range(23,-1,-1):series=series*v+(n+1)/math.factorial(n+2)
    answer[small]=series
    large=flat[~small]
    answer[~small]=(np.expm1(-1j*large)+1j*large*np.exp(-1j*large))/(large*large)
    result=(y*y*answer).reshape(z.shape)
    if not np.isfinite(result).all():raise ArithmeticError('Nonfinite transfer derivative')
    return result


def harmonic_value_and_beta_derivative(basis,y):
    """Analytic Gamma(1,y), partial_beta Gamma(1,y) on a preflighted basis.

    Caller must budget the basis and twice the transfer/coefficient products.
    This function never creates a basis, changes phase or differences two ORFs.
    """
    y=np.asarray(y,float);P=len(basis.points)
    if y.shape!=(P,) or not np.isfinite(y).all() or np.any((y<0)|(y>6284)):
        raise ValueError('One finite validated phase per pulsar')
    basis.preflight(2)
    from pta.response import transfer
    real=np.empty((2,P,basis.nmu));imag=np.empty_like(real)
    D=1+basis.x
    for j,phase in enumerate(y):
        t=transfer(float(phase),D)*basis.angular_weight
        dt=transfer_dD(float(phase),D)*basis.x*basis.angular_weight
        real[0,j]=t.real;imag[0,j]=t.imag
        real[1,j]=dt.real;imag[1,j]=dt.imag
    rc=real.reshape(2*P,basis.nmu)@basis.P
    ic=imag.reshape(2*P,basis.nmu)@basis.P
    c=(rc+1j*ic).reshape(2,P,basis.lmax-1)
    g=np.einsum('al,bl,abl->ab',c[0],c[0].conj(),basis.geometry,optimize=False)
    derivative=np.einsum('al,bl,abl->ab',c[1],c[0].conj(),basis.geometry,optimize=False)
    derivative+=derivative.conj().T.copy()
    return (g+g.conj().T)/2,derivative
