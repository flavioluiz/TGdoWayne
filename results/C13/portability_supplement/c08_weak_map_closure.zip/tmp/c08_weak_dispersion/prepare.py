"""Arithmetic-only candidate for weak dispersion and the fixed eight-mass map."""
from pathlib import Path
import hashlib,json,math

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def main():
    plan=json.loads((ROOT/'tmp/c08_window_moments/map_preflight.json').read_text())
    original=json.loads((ROOT/'tmp/c08_execution_design/config_prospectiva.json').read_text())
    map_us=[0.,.05,.25,.5,.75,.9,.99,1.];weak_us=[.001,.002,.004]
    rows=[];total=0;maximum=0
    for source in [r for r in plan['rows'] if r['duration_years']==4.5]:
        k=source['channel'];requested=[]
        for kind,values in [('G2_distributional_map',map_us),('weak_expansion',weak_us)]:
            for u in values:
                for variant in ['B','C_beta']:
                    den=k if variant=='B' else 1
                    requested.append(dict(kind=kind,u=u,variant=variant,beta=math.sqrt((1-u/den)*(1+u/den))))
        # A nested one-sided derivative check uses 1-h,1-2h and1-4h.
        # Both h and2h are evaluated against the analytic derivative; no nodes chosen by data.
        h=1e-7
        fd=[1-h,1-2*h,1-4*h]
        needed=sorted(set([r['beta'] for r in requested]+fd))
        cached=[b for b in needed if b in source['unique_beta']]
        fresh=[b for b in needed if b not in cached]
        levels=[]
        for lev in source['levels']:
            ell,n=lev['lmax'],lev['nmu'];P=12;B=4;L=ell-1
            # Analytic Gamma and derivative require two transfer/coefficient products.
            blas=2*(len(fresh)+2)*P*n*L
            contraction=6*len(fresh)*P*P*L+12*P*P*L
            basis_proxy=4*n*L+6*P*P*L
            transfer_proxy=40*(len(fresh)+2)*P*n
            arrays=8*n*L+8*P*P*L+64*n+16*B*P*n+96*B*n+64*B*P*L+64*B*P*P+64*1024**2
            cost=blas+contraction+basis_proxy+transfer_proxy
            total+=cost;maximum=max(maximum,arrays)
            levels.append(dict(label=lev['label'],lmax=ell,nmu=n,real_BLAS_products=blas,
                other_real_operation_proxy=contraction+basis_proxy+transfer_proxy,charged_real_proxy=cost,
                numeric_arrays_allowance_bytes=arrays))
        rows.append(dict(channel=k,phase_max=source['phase_max'],requests=requested,
            finite_difference_h=h,finite_difference_betas=fd,all_requested_betas=needed,
            reuse_existing_beta=cached,new_beta=fresh,new_nodes=len(fresh),levels=levels))
    record=dict(schema='C08_WEAK_AND_EIGHT_MASS_PREFLIGHT_CANDIDATE_v1',status='ARITHMETIC_ONLY_NOT_EXECUTABLE',
        execution_allowed=False,scope='G2 finite moments and analytic weak-dispersion expansion; no likelihood/posterior',
        map_u=map_us,weak_u=weak_us,nuisance_vertices=16,responses=['B','C_beta','C_full'],
        rows=rows,workers=12,BLAS_threads=1,planned_real_operation_proxy=total,
        maximum_real_operation_proxy=200000000000,within_original_extra_map_cap=total<=200000000000,
        new_frequency_ORF_nodes=sum(r['new_nodes'] for r in rows),
        quadrature_frequency_matrices=3*sum(r['new_nodes'] for r in rows),
        analytic_derivative_frequency_evaluations=12,
        maximum_numeric_arrays_allowance_bytes=maximum,maximum_numeric_ORF_bytes=1024**3,
        maximum_RSS_bytes=1536*1024**2,maximum_CPU_seconds_proposed=600,
        likelihood_evaluations=0,data_draws=0,posterior_evaluations=0,
        direct_sky_new_calls=0,direct_sky_rationale='Gamma cache at beta1 is independently checked in the complete T/window map; derivative has an independent high precision transfer/Gram test plus planned one-sided finite differences and separated angular resolutions. No direct sky derivative has yet been calculated.',
        weak_phase_guide_max=max(r['phase_max'] for r in rows)*max(weak_us)**2/2,
        weak_phase_guide_is_uniform_error_bound=False,
        proposed_gates=dict(Gamma_refinement_absolute=1e-8,derivative_refinement_relative_or_absolute=1e-7,
            derivative_finite_difference_relative_or_absolute=1e-5,moment_refinement_relative_or_absolute=1e-10),
        weak_remainder_policy='Report norms and consecutive scaling ratios for u=.001,.002,.004. O(u^4) is a fixed-phase asymptotic statement, not a requirement of an exact measured ratio16 at finite precision or cancellation.',
        memory_and_execution_limitations=['Fresh process per channel/resolution required.',
            'Moment worker and independent metrics not yet budgeted or implemented in this candidate.',
            'Caches must be verified against the completed map and authorization/source closure before reuse.',
            'No runner or execution authorization is created by this metadata script.'],
        source_sha256={str(p.relative_to(ROOT)):sha(p) for p in [Path(__file__),HERE/'derivative.py',HERE/'validation.json',HERE/'contraction_validation.json',ROOT/'tmp/c08_window_moments/map_preflight.json',ROOT/'tmp/c08_window_map_v1/complete.json',ROOT/'tmp/c08_execution_design/config_prospectiva.json']})
    path=HERE/'preflight_candidate.json'
    with path.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
    print(json.dumps({k:record[k] for k in ['status','planned_real_operation_proxy','within_original_extra_map_cap','new_frequency_ORF_nodes','maximum_numeric_arrays_allowance_bytes','weak_phase_guide_max']}))


if __name__=='__main__':main()
