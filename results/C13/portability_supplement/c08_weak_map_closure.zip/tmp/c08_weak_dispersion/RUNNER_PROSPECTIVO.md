# Executor candidato G2 e dispersão fraca

**Somente fontes, metadados e testes não físicos. Nenhuma autorização foi criada
e nenhum worker físico foi executado.** `derivative.py`, `prepare.py`,
`preflight_candidate.json`, o README e os testes/evidências anteriores do ROOT
permanecem inalterados.

O novo `execution_spec.json` é prospectivo (`execution_allowed=false`), SHA256
`0bf2a3a9a35bb3996b706f8375afbaac178ecba77d16363c7aa70d2a398729bb`.
Ele vincula 20 fontes e 38 insumos/relatórios. As identidades dos arrays em cache
foram copiadas dos relatórios já fechados; os arrays não foram abertos para
preparar esse spec. Sua leitura futura exige conferência por SHA antes do uso.

## Arquitetura e sequência futura

- `execution_contract.py`: valida escopo, orçamento, grades e autorização
  separada; reserva o trabalho antes de criar cada base.
- `run_weak_map.py`: controlador e workers. O comportamento padrão apenas
  inspeciona metadados. Importações científicas ocorrem nos workers autorizados.
- `weak_moment_deltas.py`: primeira variação dos momentos próprios complexos,
  com orçamento antes das contrações e sem fator real gaussiano extra.
- `prepare_execution_spec.py`: congela somente fontes e metadados; não autoriza.
- `test_execution_guards.py`: sete testes pequenos próprios, sem repetir os
  cinco testes anteriores da derivada.

A execução proposta usa **12 processos novos e sequenciais de quadratura**,
um por canal/resolução, com BLAS em um thread. Após cada conjunto de três
processos, o controlador confere os refinamentos separados H00/H01 e H01/H11.
O **13º processo** calcula momentos e métricas. Não se retêm duas bases no mesmo
processo. Esse requisito é explícito, inclusive diante do antecedente de RSS
observado em outra construção C09.

Cada worker grava arrays/relatório próprios, identidade da autorização e do
spec, custo e RSS. As fontes/insumos são conferidos antes e depois do cálculo.
Falhas deixam relatório e logs; não há retry, refinamento ou substituição
automática. Diretórios de saída devem ser novos.

## Desenho e acréscimo explícito de escopo

Usam-se T = 4,5 anos, geometria C07 de 12 pulsares/quatro canais e os mesmos
16 vértices cartesianos de nuisance do mapa T/janela. O operador de janela desta
extensão é a identidade: frequências de entrada independentes. A Hann do mapa
anterior não é reaplicada silenciosamente aqui.

O G2 cobre u = [0; 0,05; 0,25; 0,5; 0,75; 0,9; 0,99; 1], formando 128 pontos
fixos de parâmetros. B, C_beta e C_full produzem 384 momentos distintos e
1.152 avaliações nas três resoluções, com 1.152 comparações gaussianas nas três
resoluções. C_full usa o primeiro canal no mesmo u, sem nova quadratura própria.
Em u=0, B/C_beta devem ter momentos exatamente iguais. Isso não é exigido de
C_full, que congela também as fases.

Os três pontos fracos u = 0,001; 0,002; 0,004 acrescentam 288 avaliações físicas
de momentos B/C_beta e 144 primeiras variações analíticas. C_GR e seus fatores
espectrais vêm das avaliações G2 em u=0, sem repetir esse cálculo. Total:
**1.440 chamadas de momentos**, além de 144 variações algébricas.

O desenho ampliado requer **67 novos nós de frequência**, não os 24 do G2 simples
original. São 201 novas matrizes nas três resoluções e 12 avaliações analíticas
de Gamma/derivada em beta=1. O número maior inclui o primeiro canal, as massas
fracas, o limiar e os nós de diferenças finitas. O spec registra explicitamente
essa extensão; caber no teto anterior não concede autorização.

## Derivada, cache e limiar

Cada base avalia os betas novos em lotes de no máximo quatro. Os nós repetidos
reutilizam o cache T=4,5 do mapa fechado, com igualdade exata do beta e das
identidades de arquivo; não há interpolação nem escolha do vizinho mais próximo.
Os níveis lmax/nmu coincidem com os dos caches correspondentes.

`harmonic_value_and_beta_derivative(basis,y)` calcula Gamma(1,y) e sua derivada
analítica. Gamma é comparada ao cache beta=1. A derivada é comparada com duas
diferenças **unilaterais de segunda ordem**, usando h = 10⁻⁷ e 2h:

\[
D_h=\frac{3\Gamma(1)-4\Gamma(1-h)+\Gamma(1-2h)}{2h},\quad
D_{2h}=\frac{3\Gamma(1)-4\Gamma(1-2h)+\Gamma(1-4h)}{4h}.
\]

Portanto “h/2h” designa aqui os passos h e 2h, não h e h/2. Os betas já
constam do preflight histórico. O refinamento da derivada compara H00/H01 e
H01/H11 separadamente. Exige-se Hermiticidade da derivada, não PSD: uma derivada
de matrizes PSD pode ser indefinida.

Todos os canais incluem beta=0, comparado sem nova quadratura com

\[
\Gamma_{ab}(0)=
\frac{(1-e^{-iy_a})(1-e^{+iy_b})}{5}P_2(\hat p_a\cdot\hat p_b).
\]

**Limite da referência angular:** no mapa T/janela, o céu independente em
beta=1 verificou somente dois pares do canal 4 por duração. Isso não certifica
a matriz completa ou todos os canais. Os demais canais têm refinamentos e
antecedentes próprios. O novo spec corrige explicitamente a formulação ampla
do `direct_sky_rationale` histórico, que permanece preservado no candidato
original. Não há integração angular independente nova da derivada: seu suporte
vem dos testes anteriores em alta precisão da transferência/contração complexa,
dos refinamentos e das diferenças finitas propostas.

## Primeira ordem e restos

A comparação assintótica é exclusivamente C_beta−B, com fases fixas:

\[
\delta\Gamma_k^{(2)}=-\frac{u^2}{2}(1-k^{-2})D_k,\qquad
\delta C_k^{(2)}=s_{g,k}\delta\Gamma_k^{(2)},\quad s_{g,k}=P_{gw,k}/scale_k.
\]

As médias são comprimidas com w e as covariâncias com w². A primeira variação
usa C_GR completo, incluindo GW, ruído intrínseco e branco:

\[
\delta\mu_i=\sum_k w_k\operatorname{tr}(H_i\delta C_k),
\]
\[
\delta\Sigma_{ij}=\sum_k w_k^2\left[
\operatorname{tr}(H_i\delta C_kH_jC_{GR,k})+
\operatorname{tr}(H_iC_{GR,k}H_j\delta C_k)\right].
\]

Não há um fator dois adicional da lei gaussiana real. Os dois termos da
derivada do produto permanecem explícitos. O executor salva diferenças reais,
primeira ordem e restos de Gamma, C, média e covariância nas três resoluções,
além de normas e razões consecutivas nos três u fracos. Uma guia de arredondamento
identifica denominadores demasiado pequenos e registra `null` nesses quocientes.
Ela não é um limite certificado de erro. Não se exige razão exatamente 16 nem
se atribui prova global à concordância finita. C_full não recebe ajuste sem termo
constante em u², pois já difere por fase em u=0.

## Gates e recursos candidatos

Os limites herdados permanecem: Gamma/refinamento e limiar analítico, 10⁻⁸
absoluto; derivada entre resoluções, 10⁻⁷ relativo ou absoluto; diferenças
finitas da derivada, 10⁻⁵ relativo ou absoluto; momentos, 10⁻¹⁰ relativo ou
absoluto. O gate proposto para diferenças das métricas gaussianas entre
resoluções é 0,001 absoluto, como no mapa anterior. PSD/Hermiticidade de Gamma
são verificadas sem clipping/jitter. As métricas são de normais reais construídas
dos momentos, não da distribuição quadrática CN completa.

O proxy harmônico/bases/derivadas é **183.897.455.812**, abaixo de 200 bilhões.
Não é uma contagem universal de FLOPs: os momentos são limitados adicionalmente
por suas contagens fixas, memória e CPU medida. O máximo prospectivo de arrays
harmônicos é 630.648.664 bytes. Para o worker de momentos reservam-se 100 MiB
(4 MiB banco, 16 MiB saídas, 16 MiB temporários e 64 MiB de reserva), dentro de
256 MiB. As três resoluções no banco são pequenas; as bases jamais são guardadas.

Teto RSS: 1,5 GiB por processo, verificado no final do worker; a estimativa de
arrays não garante RSS. Teto cumulativo de CPU dos filhos: 600 s incluindo
importações, com `RLIMIT_CPU` por filho e guarda agregada após retorno. O
controlador limita-se a metadados/hashes e diferenças de arrays pequenas; sua
CPU é explicitamente excluída dessa contagem histórica. Zero céu novo, logL,
dados físicos sorteados e posteriores.

## Verificação realizada e próximos comandos

**Sete testes novos passaram**, cobrindo a primeira variação escalar própria
complexa, pesos ao quadrado, produtos complexos independentes, orçamento antes
das contrações, FD polinomial, mudanças de escopo/tetos e a recusa do CLI sem
autorização. O processo consumiu 0,467 s de CPU incluindo importações e
43.122.688 bytes de RSS; os dois subprocessos de teste executaram somente os
guards/CLI de metadados. A chamada completa durou menos de um segundo.
Logs e relatório: `execution_guard_tests.log`, `execution_guard_validation.json`.
A tentativa inicial do gerador de metadados teve um erro sintático, preservado
em `execution_spec_prepare.log`; foi corrigido antes da geração do spec e não
executou código físico. O log da geração válida é `execution_spec_prepare_v2.log`.

Consulta segura já coberta pelo teste:

```sh
.venv/bin/python -B tmp/c08_weak_dispersion/run_weak_map.py
```

Somente após revisão e autorização separada pelo ROOT:

```sh
.venv/bin/python -B tmp/c08_weak_dispersion/run_weak_map.py --execute \
  --authorization CAMINHO_DA_NOVA_AUTORIZACAO_ROOT.json \
  --output DIRETORIO_NOVO
```

A autorização deverá usar schema `ROOT_C08_G2_WEAK_AUTHORIZATION_v1`, escopo
`C08_G2_AND_WEAK_DISPERSION_MOMENTS_ONLY`, hash exato do spec, cópias idênticas de
`source_sha256`, `input_sha256` e `caps`, 13 workers, concorrência/thread 1,
`approved_by=ROOT` e `execution_allowed=true`. Esse registro **não foi criado**.
O runner físico e seus gates continuam candidatos para revisão; os testes TOY
não demonstram que os gates físicos passarão.
