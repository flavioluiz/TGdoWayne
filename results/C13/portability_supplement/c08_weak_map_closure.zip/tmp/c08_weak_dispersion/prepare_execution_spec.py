"""Read-only source/metadata freezing for ROOT review. Does not authorize."""
from pathlib import Path
import hashlib
import json
from execution_contract import CAPS, SCOPE, validate_spec

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]


def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def main():
    candidate_path=HERE/'preflight_candidate.json';candidate=json.loads(candidate_path.read_text())
    map_path=ROOT/'tmp/c08_window_moments/map_preflight.json';old=json.loads(map_path.read_text())
    complete_path=ROOT/'tmp/c08_window_map_v1/complete.json';complete=json.loads(complete_path.read_text())
    old_auth_path=ROOT/'tmp/c08_window_moments/ROOT_authorization_20260911.json'
    old_auth=json.loads(old_auth_path.read_text())
    assert sha(complete_path)=='f12f22ba45bd288ac39b8167b10f4238c0cd73498914e94bc338d6ae48837afa'
    assert complete['status']=='FINITE_DISTRIBUTIONAL_MAP_GATES_PASS_NOT_POSTERIORS' and len(complete['workers'])==43
    cached=[];inputs={str(p.relative_to(ROOT)):sha(p) for p in
        [candidate_path,map_path,complete_path,old_auth_path,
         ROOT/'configs/calibration/prior_predictive_500_v1.json']}
    for source_path,h in candidate['source_sha256'].items():
        assert sha(ROOT/source_path)==h
        inputs[source_path]=h
    for k in range(1,5):
        ri=next(i for i,r in enumerate(old['rows']) if r['duration_years']==4.5 and r['channel']==k)
        oldrow=old['rows'][ri]
        for lev in range(3):
            name=f'harmonic_{ri:02d}_{lev}'
            record=next(w for w in complete['workers'] if w['name']==name)
            p=complete_path.parent/name/'report.json';assert sha(p)==record['report_sha256']
            # Arrays are NOT opened/hashed in this prospective preparation.
            # Their published identity is verified before any later reuse.
            arrays=str((p.parent/'arrays.npz').relative_to(ROOT))
            report=json.loads(p.read_text())
            assert report['arrays_sha256']==record['arrays_sha256']
            current=candidate['rows'][k-1]['levels'][lev]
            assert (current['lmax'],current['nmu'])==(oldrow['levels'][lev]['lmax'],oldrow['levels'][lev]['nmu'])
            inputs[str(p.relative_to(ROOT))]=record['report_sha256'];inputs[arrays]=record['arrays_sha256']
            cached.append(dict(channel=k,level=lev,map_row=ri,report_path=str(p.relative_to(ROOT)),
                report_sha256=record['report_sha256'],arrays_path=arrays,arrays_sha256=record['arrays_sha256'],
                unique_beta=oldrow['unique_beta']))
        gate=complete_path.parent/f'harmonic_gate_{ri:02d}.json'
        assert json.loads(gate.read_text())['passed'] is True
        inputs[str(gate.relative_to(ROOT))]=sha(gate)
    sources=dict(old_auth['source_sha256'])
    for name,h in sources.items():assert sha(ROOT/name)==h
    for p in [HERE/'derivative.py',HERE/'execution_contract.py',HERE/'weak_moment_deltas.py',
              HERE/'run_weak_map.py',HERE/'prepare_execution_spec.py',HERE/'test_execution_guards.py']:
        sources[str(p.relative_to(ROOT))]=sha(p)
    spec=dict(schema='C08_G2_WEAK_EXECUTION_SPEC_v1',scope=SCOPE,
        status='PROSPECTIVE_SOURCES_AND_METADATA_ONLY_PENDING_ROOT_REVIEW',execution_allowed=False,
        candidate=candidate,candidate_sha256=sha(candidate_path),duration_years=4.5,
        experiment_config='configs/calibration/prior_predictive_500_v1.json',
        nuisance_vertices={k:old['map_design'][k] for k in ['log10_Agw','gamma_gw','log10_Ar','log10_EFAC']},
        operator='identity in four physical positive modes; independent frequencies; no Hann in this G2/weak extension',
        counts=dict(fresh_harmonic_workers=12,moment_workers=1,total_fresh_processes=13,
            new_frequency_nodes=67,new_frequency_matrices_all_resolutions=201,
            analytic_derivative_frequency_evaluations=12,G2_parameter_points=128,
            G2_distinct_moments=384,G2_moment_evaluations_all_resolutions=1152,
            G2_comparisons_all_resolutions=1152,weak_parameter_points=48,
            weak_physical_moment_calls=288,weak_first_variations=144,total_window_moment_calls=1440),
        scope_extension=dict(original_extra_G2_frequency_nodes=24,new_nodes=67,
            reason='Explicit extension includes first-channel new masses, three weak masses, beta0 and backward-difference nodes. Staying below the old work cap is not authorization.',
            C_full_new_channel_evaluations=0,C_full_reuses_channel1_at_the_same_u=True),
        derivative_checks=dict(at_beta=1.,fixed_pulsar_phases=True,step=1e-7,
            finite_difference='Second-order backward D_h=(3G1-4G(1-h)+G(1-2h))/(2h), and D_2h=(3G1-4G(1-2h)+G(1-4h))/(4h)',
            h_and_2h_not_h_and_half_h=True,refinement_pairs=['H00/H01','H01/H11'],
            Gamma_from_derivative_against_existing_beta1_cache=True,
            independent_direct_sky_derivative=False,
            direct_sky_rationale='Earlier T/window sky checks at beta=1 cover ONLY two pulsar pairs in channel4 per duration. They do not certify the whole matrix or every channel. Other channels retain harmonic refinement/antecedents. This candidate adds no sky calls; scalar and complex-contraction high-precision tests, separate resolution checks and backward differences support the derivative in the stated finite scope.',
            threshold_beta0='(1-exp(-i*y_a))*(1-exp(+i*y_b))*P2(p_a dot p_b)/5, compared at each channel/resolution without extra quadrature'),
        weak_expansion=dict(delta_Gamma='C_beta-B = -u^2/2*(1-k^-2)*D_k plus remainder',
            delta_C='s_g,k delta_Gamma; s_g=Pgw/scale; all noise retained in C_GR',
            delta_mean='sum_k w_k tr(H_i delta_C_k)',
            delta_covariance='sum_k w_k^2 [tr(H_i delta_C_k H_j C_GR,k)+tr(H_i C_GR,k H_j delta_C_k)]',
            proper_complex_covariance_has_no_extra_factor2=True,
            rest_policy='Save actual, first order, remainder norms and consecutive-u ratios; no required ratio16, no proof claim.',
            C_full_excluded_from_u_squared_fit='C_full has a finite-phase u=0 constant term.'),
        cached_rows=cached,cache_authorization_sha256=complete['authorization_sha256'],
        caps=CAPS,planned_real_operation_proxy=candidate['planned_real_operation_proxy'],
        memory=dict(maximum_harmonic_numeric_allowance_bytes=630648664,
            bank_array_allowance_bytes=4*1024**2,output_array_allowance_bytes=16*1024**2,
            transient_window_and_variation_allowance_bytes=16*1024**2,
            accumulators_python_numeric_reserve_bytes=64*1024**2,
            moment_peak_numeric_allowance_bytes=100*1024**2,
            moment_cap_bytes=256*1024**2,
            RSS_note='Postworker ru_maxrss check in Darwin bytes; array allowances do not guarantee RSS.'),
        gates={**candidate['proposed_gates'],'threshold_analytic_absolute':1e-8,
               'distribution_metric_resolution_absolute':.001},
        CPU_accounting='Cumulative child user+system including imports, RLIMIT_CPU per child; controller metadata/hash/refinement comparisons excluded. Every basis uses a fresh process. No automatic retry/refinement.',
        operation_accounting='183897455812 is the frozen harmonic/basis/derivative proxy, not a universal FLOP count. Moments and metric costs are bounded by the fixed call counts, numeric memory and measured child CPU.',
        execution_command='python run_weak_map.py --execute --authorization ROOT_AUTH.json --output NEW_DIRECTORY',
        authorization_created=False,physical_ORF_calls_during_preparation=0,
        likelihood_evaluations=0,data_draws=0,posterior_evaluations=0,new_direct_sky_calls=0,
        source_sha256=sources,input_sha256=inputs)
    validate_spec(spec)
    with (HERE/'execution_spec.json').open('x') as f:json.dump(spec,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps(dict(status=spec['status'],spec_sha256=sha(HERE/'execution_spec.json'),
                         sources=len(sources),inputs=len(inputs),physical_calls=0)))


if __name__=='__main__':main()
