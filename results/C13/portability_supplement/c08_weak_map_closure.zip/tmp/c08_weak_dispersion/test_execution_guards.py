"""Small nonphysical guards/algebra TOYs; not the existing derivative tests."""
import os
for k in ('VECLIB_MAXIMUM_THREADS','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[k]='1'
from pathlib import Path
import copy
import json
import resource
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
import numpy as np
from execution_contract import CAPS, validate_spec, load_authorized, reservation
from weak_moment_deltas import first_variation, backward_derivatives

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


class Tests(unittest.TestCase):
    def test_scalar_proper_complex_variation_and_weights_squared(self):
        c=np.array([[[2.]],[[3.]]]);dc=np.array([[[.1]],[[-.2]]])
        h=np.array([[[1.]],[[2.]]]);w=np.array([.25,-.75])
        mu,sigma=first_variation(c,dc,h,w,maximum_numeric_bytes=100_000)
        np.testing.assert_allclose(mu, np.array([1.,2.])*np.sum(w*dc[:,0,0]),rtol=1e-15)
        expected=np.outer([1.,2.],[1.,2.])*np.sum(w*w*2*c[:,0,0]*dc[:,0,0])
        np.testing.assert_allclose(sigma,expected,rtol=1e-15)

    def test_complex_first_variation_against_direct_quadratic_coefficient(self):
        c=np.array([[[2.,.2+.3j],[.2-.3j,1.]]],complex)
        dc=np.array([[[.4,.1-.2j],[.1+.2j,-.1]]],complex)
        h=np.array([np.eye(2),[[0.,1j],[-1j,1.]]],complex);w=np.array([.7])
        mu,sigma=first_variation(c,dc,h,w,maximum_numeric_bytes=100_000)
        # A quadratic function: central difference at finite step is exact algebraically.
        step=.125;plus=c[0]+step*dc[0];minus=c[0]-step*dc[0]
        expected=np.empty((2,2))
        for i in range(2):
            for j in range(2):
                expected[i,j]=(np.trace(h[i]@plus@h[j]@plus)-np.trace(h[i]@minus@h[j]@minus)).real/(2*step)*w[0]**2
        np.testing.assert_allclose(sigma,expected,rtol=2e-14,atol=2e-15)
        np.testing.assert_allclose(mu,[w[0]*np.trace(x@dc[0]).real for x in h],atol=1e-15)

    def test_budget_before_contractions_and_invalid_inputs(self):
        c=np.ones((1,1,1));h=np.ones((1,1,1));w=np.ones(1)
        with patch('weak_moment_deltas.np.einsum',side_effect=AssertionError('must not contract')):
            with self.assertRaises(MemoryError):first_variation(c,c,h,w,maximum_numeric_bytes=1)
        with self.assertRaises(TypeError):first_variation(c.tolist(),c,h,w,maximum_numeric_bytes=9999)
        with self.assertRaises(ValueError):first_variation(c,c,h,np.array([np.nan]),maximum_numeric_bytes=9999)

    def test_fd_polynomial_and_bad_step(self):
        a=np.array([[2.+0j,1j],[-1j,3.]])
        b=np.array([[.2+0j,.1j],[-.1j,-.4]])
        c=np.array([[1.+0j,.3j],[-.3j,2.]])
        f=lambda x:a+b*x+c*x*x
        h=.125;dh,d2h=backward_derivatives(f(1),f(1-h),f(1-2*h),f(1-4*h),h)
        np.testing.assert_allclose(dh,b+2*c,atol=5e-15)
        np.testing.assert_allclose(d2h,b+2*c,atol=5e-15)
        for bad in [True,0.,float('nan')]:
            with self.assertRaises(ValueError):backward_derivatives(a,a,a,a,bad)

    def test_spec_workload_and_mutated_caps(self):
        spec=json.loads((HERE/'execution_spec.json').read_text())
        self.assertEqual(validate_spec(spec),183897455812)
        for alter in [lambda x:x['caps'].__setitem__('angular',False),
                      lambda x:x['candidate']['rows'][0].__setitem__('new_nodes',13),
                      lambda x:x['counts'].__setitem__('fresh_harmonic_workers',1),
                      lambda x:x.__setitem__('execution_allowed',True)]:
            new=copy.deepcopy(spec);alter(new)
            with self.assertRaises(ValueError):validate_spec(new)
        for args in [(0,601.,1),(199_999_999_999,0.,2),(0,0.,True)]:
            with self.assertRaises(ValueError):reservation(*args)

    def test_default_cli_and_unauthorized_cli_do_not_import_physics(self):
        script=HERE/'run_weak_map.py'
        r=subprocess.run([sys.executable,'-B',str(script)],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(json.loads(r.stdout)['status'],'PROSPECTIVE_ONLY_NO_PHYSICS')
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'forbidden'
            r=subprocess.run([sys.executable,'-B',str(script),'--execute','--output',str(out)],capture_output=True,text=True)
            self.assertNotEqual(r.returncode,0)
            self.assertFalse(out.exists())

    def test_separate_authorization_required_before_hashes(self):
        with tempfile.TemporaryDirectory() as td:
            auth=Path(td)/'auth.json';auth.write_text(json.dumps({'execution_allowed':True,'scope':'wrong'}))
            with self.assertRaises(ValueError):
                load_authorized(ROOT,HERE/'execution_spec.json',auth)


if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(29,30))
    start=time.process_time()
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    report=dict(scope='SMALL_NONPHYSICAL_GUARDS_AND_MOMENT_ALGEBRA_TOY',tests=result.testsRun,
        passed=result.wasSuccessful(),CPU_seconds=time.process_time()-start,
        process_CPU_seconds_including_imports=time.process_time(),
        RSS_peak_bytes=int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),
        ORF_evaluations=0,likelihood_evaluations=0,physical_data_draws=0,
        existing_derivative_tests_repeated=0,root_map_executed=False)
    if report['RSS_peak_bytes']>128*1024**2:raise MemoryError('Synthetic test RSS cap')
    with (HERE/'execution_guard_validation.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
