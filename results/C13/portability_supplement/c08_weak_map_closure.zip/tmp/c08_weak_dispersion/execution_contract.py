"""Prospective fixed-scope guards; no numerical or physical imports."""
import hashlib
import json
from pathlib import Path

CAPS = dict(real_proxy=200_000_000_000, CPU_seconds=600, numeric_ORF=1024**3,
            RSS=1536*1024**2, moment_numeric=256*1024**2, angular=0)
SCOPE = 'C08_G2_AND_WEAK_DISPERSION_MOMENTS_ONLY'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def validate_spec(spec):
    require(spec['schema'] == 'C08_G2_WEAK_EXECUTION_SPEC_v1', 'Unknown execution spec')
    require(spec['scope'] == SCOPE and spec['execution_allowed'] is False,
            'Spec is prospective; only separate ROOT authorization permits execution')
    require(spec['caps'] == CAPS, 'Resource caps changed')
    require(all(type(spec['caps'][k]) is int for k in CAPS), 'Integer caps required, not booleans')
    require(spec['counts']['fresh_harmonic_workers'] == 12 and
            spec['counts']['moment_workers'] == 1, 'Fresh process per basis required')
    candidate = spec['candidate']
    require(candidate['map_u'] == [0.,.05,.25,.5,.75,.9,.99,1.] and
            candidate['weak_u'] == [.001,.002,.004], 'Mass grid changed')
    require(len(candidate['rows']) == 4, 'Exactly four frequency rows')
    work = sum(level['charged_real_proxy'] for row in candidate['rows'] for level in row['levels'])
    require(work == 183897455812 == candidate['planned_real_operation_proxy'], 'Operation proxy mismatch')
    require(sum(row['new_nodes'] for row in candidate['rows']) == 67, '67 new frequency nodes required')
    for k, row in enumerate(candidate['rows'], 1):
        require(row['channel'] == k and len(row['levels']) == 3, 'Frequency/resolution grid')
        require(row['new_beta'] == sorted(set(row['new_beta'])), 'Duplicate new beta')
        require(not set(row['new_beta']) & set(row['reuse_existing_beta']), 'Cached/new overlap')
        require(set(row['new_beta']) | set(row['reuse_existing_beta']) == set(row['all_requested_betas']), 'Missing beta')
        require(row['finite_difference_h'] == 1e-7 and
                row['finite_difference_betas'] == [1-1e-7,1-2e-7,1-4e-7], 'FD nodes changed')
        require(all(0 <= b <= 1 for b in row['all_requested_betas']), 'Beta domain')
        require(row['new_nodes'] == len(row['new_beta']), 'New node count')
        for level in row['levels']:
            require(level['numeric_arrays_allowance_bytes'] <= CAPS['numeric_ORF'], 'Basis estimate cap')
    require(spec['memory']['moment_peak_numeric_allowance_bytes'] <= CAPS['moment_numeric'], 'Moment budget')
    require(spec['source_sha256'] and spec['input_sha256'], 'Empty identity closure')
    return work


def load_authorized(root, spec_path, authorization_path):
    spec_path, authorization_path = Path(spec_path), Path(authorization_path)
    spec = json.loads(spec_path.read_text())
    validate_spec(spec)
    auth = json.loads(authorization_path.read_text())
    require(auth.get('schema') == 'ROOT_C08_G2_WEAK_AUTHORIZATION_v1' and
            auth.get('scope') == SCOPE and auth.get('execution_allowed') is True and
            auth.get('approved_by') == 'ROOT', 'Separate explicit ROOT authorization required')
    require(auth.get('execution_spec_sha256') == sha(spec_path), 'Spec identity changed')
    require(auth.get('caps') == CAPS and auth.get('workers') == 13 and
            auth.get('concurrency') == auth.get('BLAS_threads') == 1, 'Execution limits changed')
    require(all(type(auth['caps'][k]) is int for k in CAPS) and
            all(type(auth[k]) is int for k in ('workers','concurrency','BLAS_threads')),
            'Integer execution limits required, not booleans')
    require(auth.get('source_sha256') == spec['source_sha256'] and
            auth.get('input_sha256') == spec['input_sha256'], 'Authorization closure differs')
    for p, h in {**spec['source_sha256'], **spec['input_sha256']}.items():
        require(sha(Path(root)/p) == h, 'Frozen input/source changed: '+p)
    return auth, spec


def reservation(real_used, cpu_used, charge):
    require(type(charge) is int and charge >= 0, 'Nonnegative integer charge')
    require(type(real_used) is int and real_used >= 0, 'Nonnegative cumulative work')
    require(isinstance(cpu_used, (int,float)) and not isinstance(cpu_used,bool)
            and 0 <= cpu_used < CAPS['CPU_seconds']-2, 'Insufficient remaining child CPU')
    require(real_used+charge <= CAPS['real_proxy'], 'Work must be reserved before basis allocation')
    return real_used+charge
