"""Prospective runner. Default is metadata-only; physical execution needs ROOT."""
import os
for key in ('VECLIB_MAXIMUM_THREADS','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import argparse
import itertools
import json
import math
import resource
import subprocess
import sys
import time
from execution_contract import CAPS, SCOPE, require, sha, validate_spec, load_authorized, reservation

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def write_json(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n')


def numeric_imports():
    # Called only by explicitly authorized physical workers.
    sys.path.insert(0,str(ROOT/'src'))
    sys.path.insert(0,str(ROOT/'tmp/c08_window_moments'))
    sys.path.insert(0,str(ROOT/'tmp/c08_gaussian_comparison/src/inference'))
    import numpy as np
    from inference.model import experiment,covariance_batch,YEAR
    from inference.orf_blas import RealHarmonicBasis,TableBudget
    from gaussian_metrics import gaussian_comparison
    from window_moments import window_moments
    from derivative import harmonic_value_and_beta_derivative
    from weak_moment_deltas import first_variation,backward_derivatives,normalized_max
    return locals()


def exp_at(spec,n):
    cfg=json.loads((ROOT/spec['experiment_config']).read_text())
    return n['experiment'](dict(cfg,duration_years=spec['duration_years']))


def save_arrays(path,**arrays):
    import numpy as np
    with Path(path).open('xb') as f:np.savez(f,**arrays)


def load_npz(path):
    import numpy as np
    import zipfile
    with zipfile.ZipFile(path) as f:
        require(sum(x.file_size for x in f.infolist()) < 16*1024**2,'Saved numeric package exceeds 16 MiB')
    with np.load(path,allow_pickle=False) as f:
        arrays={k:f[k] for k in f.files}
    require(all(np.isfinite(v).all() for v in arrays.values()),'Nonfinite saved numeric value')
    return arrays


def cache_row(spec,channel,level):
    row=next(r for r in spec['cached_rows'] if r['channel']==channel and r['level']==level)
    p=ROOT/row['report_path'];r=json.loads(p.read_text())
    require(sha(p)==row['report_sha256'],'Cached report changed')
    require(r['row']==row['map_row'] and r['level']==level and
            r['authorization_sha256']==spec['cache_authorization_sha256'],'Cached row identity')
    arrays_path=ROOT/row['arrays_path']
    require(sha(arrays_path)==row['arrays_sha256']==r['arrays_sha256'],'Cached matrix identity')
    a=load_npz(arrays_path)
    import numpy as np
    require(set(a)=={'beta','Gamma'} and a['beta'].dtype==np.float64 and
            a['Gamma'].dtype==np.complex128 and a['Gamma'].shape==(len(row['unique_beta']),12,12),
            'Cache schema')
    require(a['beta'].tobytes()==np.array(row['unique_beta'],dtype=float).tobytes(),'Exact cache beta required')
    return a


def exact_index(nodes,beta):
    import numpy as np
    ix=np.flatnonzero(nodes==beta)
    require(len(ix)==1,'Exact frozen beta not found; interpolation/nearest lookup forbidden')
    return int(ix[0])


def harmonic_worker(spec,channel,level_index,out,n):
    np=n['np'];row=spec['candidate']['rows'][channel-1];level=row['levels'][level_index]
    require(level['numeric_arrays_allowance_bytes']<=CAPS['numeric_ORF'],'Basis allowance before allocation')
    old=cache_row(spec,channel,level_index)
    e=exp_at(spec,n);p=e['points'];y=2*np.pi*e['f'][channel-1]*e['distance_ly']*n['YEAR']
    require(len(p)==12 and len(e['f'])==4 and float(y.max())<=6284,'Frozen geometry/phase envelope')
    budget=n['TableBudget'](maximum_estimated_memory_bytes=CAPS['numeric_ORF']-64*1024**2,
                          maximum_multiplications_per_batch=50_000_000_000,maximum_batch_size=4)
    basis=n['RealHarmonicBasis'](p,lmax=level['lmax'],nmu=level['nmu'],budget=budget,planned_batch=4)
    fresh=np.array(row['new_beta'],dtype=float)
    newly=np.empty((len(fresh),12,12),complex)
    for first in range(0,len(fresh),4):
        newly[first:first+4]=basis.evaluate(fresh[first:first+4],y)
    g1,derivative=n['harmonic_value_and_beta_derivative'](basis,y)
    del basis
    nodes=np.array(row['all_requested_betas'],float)
    gamma=np.empty((len(nodes),12,12),complex)
    for i,beta in enumerate(nodes):
        if beta in row['reuse_existing_beta']:
            gamma[i]=old['Gamma'][exact_index(old['beta'],beta)]
        else:
            gamma[i]=newly[exact_index(fresh,beta)]
    require(np.isfinite(gamma).all() and np.isfinite(derivative).all(),'Nonfinite quadrature')
    herm=float(np.max(abs(gamma-gamma.swapaxes(-1,-2).conj())))
    minimum=float(np.linalg.eigvalsh(gamma).min())
    require(herm<=1e-12 and minimum>=-1e-12,'Quadrature PSD/Hermiticity; no repair')
    require(np.max(abs(derivative-derivative.conj().T))<=1e-10*max(1.,np.max(abs(derivative))),
            'Derivative must be Hermitian, not necessarily PSD')
    g_cached=gamma[exact_index(nodes,1.)]
    h=row['finite_difference_h']
    gh,g2h,g4h=[gamma[exact_index(nodes,b)] for b in row['finite_difference_betas']]
    dh,d2h=n['backward_derivatives'](g_cached,gh,g2h,g4h,h)
    fd=[n['normalized_max'](a,derivative) for a in [dh,d2h]]
    error_g1=float(np.max(abs(g1-g_cached)))
    # Exact beta=0 tensorial finite-phase expression, no additional quadrature.
    cosine=p@p.T;p2=(3*cosine*cosine-1)/2
    earth_pulsar=-np.expm1(-1j*y)
    threshold=earth_pulsar[:,None]*earth_pulsar.conj()[None,:]*p2/5
    threshold_error=float(np.max(abs(gamma[exact_index(nodes,0.)]-threshold)))
    gate=spec['gates']
    passed=(error_g1<=gate['Gamma_refinement_absolute'] and
            threshold_error<=gate['threshold_analytic_absolute'] and
            max(fd)<=gate['derivative_finite_difference_relative_or_absolute'])
    save_arrays(out/'arrays.npz',beta=nodes,Gamma=gamma,Gamma_analytic_beta1=g1,
                derivative_beta1=derivative,finite_difference_h=dh,finite_difference_2h=d2h,
                threshold_analytic=threshold)
    return dict(scope='FRESH_SINGLE_BASIS_WEAK_G2_MATRICES',channel=channel,level=level_index,
        passed=bool(passed),new_frequency_nodes=len(fresh),analytic_derivative_evaluations=1,
        real_proxy=level['charged_real_proxy'],angular=0,arrays_sha256=sha(out/'arrays.npz'),
        Gamma_beta1_against_frozen_cache=error_g1,derivative_backward_h_2h_errors=fd,
        threshold_beta0_analytic_error=threshold_error,minimum_Gamma_eigenvalue=minimum,
        Gamma_Hermiticity_absolute=herm,derivative_PSD_not_required=True,
        cached_beta_reused_exactly=row['reuse_existing_beta'],new_beta=row['new_beta'])


def read_worker_arrays(root,channel,level):
    path=root/f'harmonic_{channel:02d}_{level}'
    report=json.loads((path/'report.json').read_text())
    require(report['passed'] is True and report['channel']==channel and report['level']==level,'New harmonic worker incomplete')
    require(sha(path/'arrays.npz')==report['arrays_sha256'],'New harmonic arrays altered')
    return load_npz(path/'arrays.npz')


def check_channel_refinement(spec,root,channel):
    import numpy as np
    from weak_moment_deltas import normalized_max
    a=[read_worker_arrays(root,channel,j) for j in range(3)]
    records=[]
    for i,j in [(0,1),(1,2)]:
        require(np.array_equal(a[i]['beta'],a[j]['beta']),'Resolution grids differ')
        records.append(dict(levels=[i,j],Gamma=float(np.max(abs(a[i]['Gamma']-a[j]['Gamma']))),
            derivative=normalized_max(a[i]['derivative_beta1'],a[j]['derivative_beta1'])))
    passed=all(r['Gamma']<=spec['gates']['Gamma_refinement_absolute'] and
               r['derivative']<=spec['gates']['derivative_refinement_relative_or_absolute'] for r in records)
    return dict(passed=passed,channel=channel,checks=records)


def stack(spec,bank,u,variant,level,kind):
    import numpy as np
    parts=[]
    for k in range(1,5):
        channel=1 if variant=='C_full' else k
        wanted='B' if variant=='B' else 'C_beta'
        row=spec['candidate']['rows'][channel-1]
        request=next(r for r in row['requests'] if r['kind']==kind and r['variant']==wanted and r['u']==u)
        a=bank[channel,level]
        parts.append(a['Gamma'][exact_index(a['beta'],request['beta'])])
    return np.array(parts)


def moments_worker(spec,root,out,n):
    np=n['np'];require(spec['memory']['moment_peak_numeric_allowance_bytes']<=CAPS['moment_numeric'],
                       'Moment allowance before bank load')
    bank={(k,l):read_worker_arrays(root,k,l) for k in range(1,5) for l in range(3)}
    require(sum(x.nbytes for a in bank.values() for x in a.values())<spec['memory']['bank_array_allowance_bytes'],
            'Actual small harmonic bank exceeds allowance')
    e=exp_at(spec,n);H=e['H'];weights=e['weights'];identity=np.eye(4)
    design=spec['nuisance_vertices'];etas=list(itertools.product(*[design[k] for k in
                            ['log10_Agw','gamma_gw','log10_Ar','log10_EFAC']]))
    variants=['B','C_beta','C_full'];metadata=[];means=[];covs=[];comparisons=[];gr={}
    physical_moment_calls=0
    for u in spec['candidate']['map_u']:
        for ei,eta in enumerate(etas):
            for lev in range(3):
                per=[]
                for vi,variant in enumerate(variants):
                    gamma=stack(spec,bank,u,variant,lev,'G2_distributional_map')
                    c,coeff=n['covariance_batch'](np.array(eta),gamma,e);c=c[0]
                    result=n['window_moments'](c,H,e['scale'],identity,weights,
                                              maximum_numeric_bytes=CAPS['moment_numeric'])
                    physical_moment_calls+=1
                    mu,sigma=result['compressed_mean'],result['compressed_covariance']
                    metadata.append([u,ei,lev,vi]);means.append(mu);covs.append(sigma);per.append((mu,sigma))
                    if u==0 and vi==0:gr[ei,lev]=(c.copy(),coeff[0,:,0].copy(),mu.copy(),sigma.copy())
                for p,q in [(0,1),(0,2),(1,2)]:
                    f=n['gaussian_comparison'](*per[p],*per[q]);b=n['gaussian_comparison'](*per[q],*per[p])
                    comparisons.append([u,ei,lev,p,q,f['kl_p_to_q'],b['mean_mahalanobis_squared'],f['covariance_whitened_frobenius']])
                if u==0:
                    require(np.array_equal(per[0][0],per[1][0]) and np.array_equal(per[0][1],per[1][1]),
                            'u=0 B/C_beta moment identity must be exact')
    metadata=np.array(metadata);means=np.array(means);covs=np.array(covs);comparisons=np.array(comparisons)
    lookup={tuple(x):i for i,x in enumerate(metadata)}
    moment_errors=[];metric_errors=[]
    for u,ei in itertools.product(spec['candidate']['map_u'],range(16)):
        for a,b in [(0,1),(1,2)]:
            for vi in range(3):
                i,j=lookup[u,ei,a,vi],lookup[u,ei,b,vi]
                moment_errors.append([n['normalized_max'](means[i],means[j]),n['normalized_max'](covs[i],covs[j])])
            ca=comparisons[(comparisons[:,0]==u)&(comparisons[:,1]==ei)&(comparisons[:,2]==a),5:]
            cb=comparisons[(comparisons[:,0]==u)&(comparisons[:,1]==ei)&(comparisons[:,2]==b),5:]
            metric_errors.append(float(np.max(abs(ca-cb))))
    weak_meta=[];dg_exact=[];dg_first=[];dc_exact=[];dc_first=[]
    dm_exact=[];dm_first=[];ds_exact=[];ds_first=[];weak_values={}
    for u in spec['candidate']['weak_u']:
        for lev in range(3):
            gb=stack(spec,bank,u,'B',lev,'weak_expansion')
            gc=stack(spec,bank,u,'C_beta',lev,'weak_expansion')
            derivative=np.array([bank[k,lev]['derivative_beta1'] for k in range(1,5)])
            predicted=-(u*u)/2*(1-1/np.arange(1,5,dtype=float)**2)[:,None,None]*derivative
            for ei,eta in enumerate(etas):
                cb,coeff=n['covariance_batch'](np.array(eta),gb,e)
                cc,_=n['covariance_batch'](np.array(eta),gc,e)
                rb=n['window_moments'](cb[0],H,e['scale'],identity,weights,maximum_numeric_bytes=CAPS['moment_numeric'])
                rc=n['window_moments'](cc[0],H,e['scale'],identity,weights,maximum_numeric_bytes=CAPS['moment_numeric'])
                physical_moment_calls+=2
                c0,sg,_,_=gr[ei,lev];delta_c=sg[:,None,None]*predicted
                pm,ps=n['first_variation'](c0,delta_c,H,weights,maximum_numeric_bytes=CAPS['moment_numeric'])
                am=rc['compressed_mean']-rb['compressed_mean'];ass=rc['compressed_covariance']-rb['compressed_covariance']
                weak_meta.append([u,ei,lev]);dg_exact.append(gc-gb);dg_first.append(predicted)
                dc_exact.append(cc[0]-cb[0]);dc_first.append(delta_c)
                dm_exact.append(am);dm_first.append(pm);ds_exact.append(ass);ds_first.append(ps)
                weak_values[u,ei,lev]=(rb['compressed_mean'],rb['compressed_covariance'],rc['compressed_mean'],rc['compressed_covariance'])
    weak_ref=[]
    for u,ei in itertools.product(spec['candidate']['weak_u'],range(16)):
        for a,b in [(0,1),(1,2)]:
            weak_ref.extend(n['normalized_max'](x,y) for x,y in zip(weak_values[u,ei,a],weak_values[u,ei,b]))
    weak_meta=np.array(weak_meta)
    weak_arrays={k:np.array(v) for k,v in dict(delta_Gamma_actual=dg_exact,delta_Gamma_first=dg_first,
        delta_C_actual=dc_exact,delta_C_first=dc_first,delta_mean_actual=dm_exact,delta_mean_first=dm_first,
        delta_covariance_actual=ds_exact,delta_covariance_first=ds_first).items()}
    rest=[];ratios=[]
    for i,(u,ei,lev) in enumerate(weak_meta):
        r=dict(u=u,eta_index=int(ei),level=int(lev))
        for name in ['Gamma','C','mean','covariance']:
            a=weak_arrays['delta_'+name+'_actual'][i];b=weak_arrays['delta_'+name+'_first'][i]
            r[name]=dict(actual_Frobenius=float(np.linalg.norm(a)),first_order_Frobenius=float(np.linalg.norm(b)),
                         remainder_Frobenius=float(np.linalg.norm(a-b)))
        rest.append(r)
    for ei in range(16):
        values=[next(r for r in rest if r['eta_index']==ei and r['level']==2 and r['u']==u) for u in spec['candidate']['weak_u']]
        for name in ['Gamma','C','mean','covariance']:
            for a,b in [(0,1),(1,2)]:
                denominator=values[a][name]['remainder_Frobenius'];numerator=values[b][name]['remainder_Frobenius']
                floor=64*np.finfo(float).eps*max(1.,values[a][name]['actual_Frobenius'],values[a][name]['first_order_Frobenius'])
                ratios.append(dict(eta_index=ei,quantity=name,u_pair=[values[a]['u'],values[b]['u']],
                    remainder_ratio=numerator/denominator if denominator>floor else None,
                    denominator_above_roundoff_guide=bool(denominator>floor),roundoff_guide=floor,
                    guide_not_a_certified_error_bound=True))
    moment_max=float(np.max(moment_errors));metric_max=float(max(metric_errors));weak_max=float(max(weak_ref))
    passed=(moment_max<=spec['gates']['moment_refinement_relative_or_absolute'] and
            weak_max<=spec['gates']['moment_refinement_relative_or_absolute'] and
            metric_max<=spec['gates']['distribution_metric_resolution_absolute'])
    require(physical_moment_calls==1440,'Unexpected moment workload')
    output=dict(metadata=metadata,eta=np.array(etas),means=means,covariances=covs,comparisons=comparisons,
                moment_errors=np.array(moment_errors),weak_metadata=weak_meta,**weak_arrays)
    require(sum(a.nbytes for a in output.values())<spec['memory']['output_array_allowance_bytes'],'Output allowance exceeded')
    save_arrays(out/'arrays.npz',**output)
    write_json(out/'weak_remainders.json',dict(scope='DESCRIPTIVE_FINITE_REMAINDERS_NOT_PROOF',rows=rest,ratios=ratios,
        expansion='C_beta-B only; first variation at C_GR including GW plus intrinsic/white noise; no C_full u^2 fit'))
    return dict(scope='G2_AND_WEAK_FINITE_GAUSSIAN_MOMENTS_ONLY',passed=passed,real_proxy=0,angular=0,
        G2_fixed_parameter_points=128,G2_distinct_moments=384,G2_moments_all_resolutions=1152,
        G2_comparisons_all_resolutions=1152,weak_physical_moment_calls=288,weak_first_variations=144,
        total_physical_moment_calls=physical_moment_calls,moment_refinement_max=moment_max,
        metric_resolution_max=metric_max,weak_moment_refinement_max=weak_max,
        arrays_sha256=sha(out/'arrays.npz'),weak_remainders_sha256=sha(out/'weak_remainders.json'),
        data_draws=0,likelihood_evaluations=0,posterior_evaluations=0,
        no_C_full_power_law_fit=True,no_required_remainder_ratio16=True)


def worker(args,auth,spec):
    resource.setrlimit(resource.RLIMIT_CPU,(args.cpu_limit,args.cpu_limit+1))
    args.output.mkdir(parents=True,exist_ok=False)
    started=time.process_time();wall=time.perf_counter()
    try:
        n=numeric_imports()
        report=(harmonic_worker(spec,args.channel,args.level,args.output,n) if args.worker=='harmonic'
                else moments_worker(spec,args.campaign,args.output,n))
        load_authorized(ROOT,args.spec,args.authorization)
        report.update(CPU_seconds=time.process_time()-started,wall_seconds=time.perf_counter()-wall,
            RSS_peak_bytes=int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),
            authorization_sha256=sha(args.authorization),execution_spec_sha256=sha(args.spec))
        report['source_and_input_closure_unchanged_at_end']=True
        require(report['RSS_peak_bytes']<=CAPS['RSS'],'Worker peak RSS exceeds cap')
        write_json(args.output/'report.json',report)
        require(report['passed'] is True,'Finite gate failed; no automatic refinement')
    except Exception as exc:
        write_json(args.output/'failure.json',dict(error=repr(exc),status='FAILED_PRESERVED_NO_RETRY'))
        raise


def controller(args,auth,spec):
    args.output.mkdir(parents=True,exist_ok=False)
    write_json(args.output/'execution_request.json',dict(authorization_path=str(args.authorization.resolve()),
        authorization_sha256=sha(args.authorization),spec_path=str(args.spec.resolve()),
        execution_spec_sha256=sha(args.spec),scope=SCOPE))
    stages=[('harmonic',k,l) for k in range(1,5) for l in range(3)]+[('moments',0,0)]
    used=0;cpu=0.;records=[]
    try:
        for kind,k,l in stages:
            name=f'harmonic_{k:02d}_{l}' if kind=='harmonic' else 'moments_00'
            charge=spec['candidate']['rows'][k-1]['levels'][l]['charged_real_proxy'] if kind=='harmonic' else 0
            used=reservation(used,cpu,charge)
            with (args.output/'ledger.jsonl').open('a') as f:
                f.write(json.dumps(dict(event='reserved_before_allocation',name=name,real_proxy=used,child_CPU=cpu))+'\n')
            child=[sys.executable,'-B',str(Path(__file__).resolve()),'--execute','--spec',str(args.spec.resolve()),
                '--authorization',str(args.authorization.resolve()),'--worker',kind,'--channel',str(k),'--level',str(l),
                '--campaign',str(args.output.resolve()),'--output',str((args.output/name).resolve()),
                '--cpu-limit',str(int(math.floor(CAPS['CPU_seconds']-cpu)))]
            before=resource.getrusage(resource.RUSAGE_CHILDREN)
            with (args.output/(name+'.log')).open('x') as f:
                completed=subprocess.run(child,stdout=f,stderr=subprocess.STDOUT,env=os.environ.copy())
            after=resource.getrusage(resource.RUSAGE_CHILDREN)
            elapsed=(after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime);cpu+=elapsed
            require(completed.returncode==0,'Worker failed: '+name)
            p=args.output/name/'report.json';report=json.loads(p.read_text())
            require(report['passed'] is True and report['real_proxy']==charge,'Worker result/charge mismatch')
            require(cpu<=CAPS['CPU_seconds'],'Cumulative child CPU exceeded')
            records.append(dict(name=name,report_sha256=sha(p),child_CPU_seconds_including_startup=elapsed,**report))
            if kind=='harmonic' and l==2:
                gate=check_channel_refinement(spec,args.output,k)
                write_json(args.output/f'channel_gate_{k:02d}.json',gate)
                require(gate['passed'] is True,'Gamma/derivative refinement gate failed')
        require(len(records)==13 and used==183897455812,'Incomplete prospective workload')
        write_json(args.output/'complete.json',dict(status='FINITE_G2_WEAK_GATES_PASS_NOT_POSTERIORS_OR_ASYMPTOTIC_PROOF',
            scope=SCOPE,authorization_sha256=sha(args.authorization),execution_spec_sha256=sha(args.spec),
            resources=dict(real_proxy=used,child_CPU_seconds=cpu,angular=0),workers=records,
            new_frequency_nodes=67,analytic_derivative_frequency_evaluations=12,
            maximum_worker_RSS_bytes=max(r['RSS_peak_bytes'] for r in records),
            ORF_interpolation_created=False,likelihood_evaluations=0,posterior_evaluations=0,data_draws=0))
    except Exception as exc:
        write_json(args.output/'failure.json',dict(status='FAILED_PRESERVED_NO_AUTOMATIC_RETRY',error=repr(exc),
            completed_workers=[r['name'] for r in records],charged_real_proxy=used,child_CPU_seconds=cpu))
        raise


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--spec',type=Path,default=HERE/'execution_spec.json')
    p.add_argument('--execute',action='store_true');p.add_argument('--authorization',type=Path)
    p.add_argument('--output',type=Path);p.add_argument('--campaign',type=Path)
    p.add_argument('--worker',choices=['harmonic','moments']);p.add_argument('--channel',type=int,default=0)
    p.add_argument('--level',type=int,default=0);p.add_argument('--cpu-limit',type=int,default=0)
    a=p.parse_args();spec=json.loads(a.spec.read_text());work=validate_spec(spec)
    if not a.execute:
        require(a.worker is None,'Workers require separate authorization')
        print(json.dumps(dict(status='PROSPECTIVE_ONLY_NO_PHYSICS',workers=13,real_proxy=work,
                              execution_spec_sha256=sha(a.spec),authorization_created=False)));return
    require(a.authorization is not None and a.output is not None,'Explicit authorization and output required')
    auth,spec=load_authorized(ROOT,a.spec,a.authorization)
    if a.worker:
        require(a.campaign is not None and 1<=a.cpu_limit<=600,'Worker context/CPU allowance required')
        if a.worker=='harmonic':require(1<=a.channel<=4 and 0<=a.level<=2,'Worker indices')
        worker(a,auth,spec)
    else:
        controller(a,auth,spec)


if __name__=='__main__':main()
