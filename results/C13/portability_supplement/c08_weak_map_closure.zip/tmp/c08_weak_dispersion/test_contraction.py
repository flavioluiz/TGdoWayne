"""Small independent complex-matrix derivative TOY; no physical ORF basis."""
from pathlib import Path
from types import SimpleNamespace,ModuleType
from unittest.mock import patch
import hashlib,json,resource,sys,time,unittest
import numpy as np
import mpmath as mp
from derivative import harmonic_value_and_beta_derivative


class ContractionTest(unittest.TestCase):
    maximum_error=0.

    def test_high_precision_derivative_of_whole_gram(self):
        # Deliberately nonphysical finite coefficients. mpmath differentiates
        # the whole complex Gram, independently of the implemented product rule.
        rng=np.random.default_rng(808119301);P,N,L=3,6,4
        basis=SimpleNamespace(points=np.zeros((P,3)),x=np.linspace(-.8,.8,N),
            angular_weight=rng.uniform(.1,.8,N),P=rng.normal(size=(N,L)),
            geometry=rng.normal(size=(P,P,L)),nmu=N,lmax=L+1)
        basis.geometry=(basis.geometry+basis.geometry.swapaxes(0,1))/2
        checked=[];basis.preflight=lambda n:checked.append(n)
        response=ModuleType('pta.response')
        response.transfer=lambda y,d:-np.expm1(-1j*y*d)/d
        phases=np.array([.7,4.1,11.3])
        with patch.dict(sys.modules,{'pta.response':response}):
            actual,derivative=harmonic_value_and_beta_derivative(basis,phases)
        self.assertEqual(checked,[2]);mp.mp.dps=65
        def coefficient(beta,a,l):
            y=mp.mpf(phases[a]);value=mp.mpc(0)
            for j in range(N):
                d=1+beta*mp.mpf(basis.x[j])
                value+=(1-mp.exp(-1j*y*d))/d*mp.mpf(basis.angular_weight[j])*mp.mpf(basis.P[j,l])
            return value
        for a in range(P):
            for b in range(P):
                def gram(beta):
                    return sum(coefficient(beta,a,l)*mp.conj(coefficient(beta,b,l))*mp.mpf(basis.geometry[a,b,l]) for l in range(L))
                expected=complex(gram(mp.mpf(1)));expected_derivative=complex(mp.diff(gram,mp.mpf(1)))
                err=max(abs(actual[a,b]-expected)/max(1,abs(expected)),abs(derivative[a,b]-expected_derivative)/max(1,abs(expected_derivative)))
                type(self).maximum_error=max(type(self).maximum_error,err)
                self.assertLess(err,1e-12)
        np.testing.assert_array_equal(derivative,derivative.conj().T)


if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(29,30));start=time.process_time()
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ContractionTest))
    here=Path(__file__).resolve().parent
    record=dict(scope='NONPHYSICAL_FINITE_BASIS_COMPLEX_GRAM_DERIVATIVE_TOY',tests=result.testsRun,passed=result.wasSuccessful(),matrix_entries=9,maximum_relative_or_absolute_error=ContractionTest.maximum_error,physical_ORFs=0,likelihoods=0,physical_data_draws=0,CPU_seconds=time.process_time()-start,RSS_bytes=int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),here/'derivative.py']})
    with (here/'contraction_validation.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
    sys.exit(not result.wasSuccessful())
