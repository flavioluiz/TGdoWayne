# Controle gaussiano conjunto para populações aninhadas — candidato C11

Este componente transforma coordenadas normais padrão explícitas em controles
gaussianos com média e covariância das formas quadráticas de uma CN própria.
Ainda não foi integrado nem usado numa simulação física C11.

Para cada frequência, `C=L L†` e `A_i=L† H_i L`. As coordenadas de `A_i`
na base ortonormal de matrizes Hermitianas são a diagonal, `sqrt(2) Re A_ab`
e `sqrt(2) Im A_ab`, com `a<b`. O produto dessas coordenadas com um vetor
normal padrão equivale a `tr(A_i W)`. Assim, a matriz de coeficientes F
satisfaz `F Fᵀ = tr(H_i C H_j C)`. Não é necessário fatorar a covariância
conjunta dos estimadores, que pode ser singular.

Para preservar a covariância cruzada das populações, inserir H12 na matriz
16×16 com zeros, concatenar esse conjunto com H16 e usar o mesmo vetor de
coordenadas por frequência. Os resultados P12 dos quatro canais compartilhados
e P16 dos oito canais são marginais do mesmo controle. Compartilhar números
aleatórios entre duas fatorações arbitrárias separadas não asseguraria esse
acoplamento. A observação CN deve usar seu próprio banco RNG independente,
condicionado à mesma massa, conforme o protocolo prospectivo C11.

Os sete testes originais passaram em 0,070 s CPU:

- média, covariância e covariância cruzada conferidas em representação real
  independente, usando `2 tr(J_i K J_j K)`;
- orientação da parte imaginária conferida com W explícita;
- H12/H16 da geometria candidata, mas com covariâncias SPD sintéticas;
- estimadores duplicados e nulos mantêm a singularidade exata sem reparo;
- compressão de frequência coincide com o operador linear explícito;
- 32.768 realizações normais TOY com semente fixada: desvios máximos de
  0,993 erros padrão na média e 1,689 na covariância, abaixo da meta de 6;
- propriedade dos arrays, suporte e limites de memória verificados.

O teto prospectivo foi 64 MiB de arrays conhecidos e 30 s CPU. `validation.json`
registra hashes, custos e alcance. O componente não calcula ORFs, likelihoods,
posteriors ou dados físicos PTA; estes testes não aprovam C11 nem uma análise
observacional. A distribuição quadrática física continua diferente do controle
normal, mesmo que os primeiros dois momentos coincidam.

A revisão independente encontrou que fatores pequenos podem gerar uma saída
de covariância D×D grande: a API original não verificava esse custo no método
`covariance()`. A v2 faz o preflight da saída e de temporários antes do produto
matricial. O oitavo teste reproduz K=P=1, D=1000 e teto de 2 MiB, e exige a
interrupção antes de alocar 8 MB. A versão original e sua evidência permanecem
em `tmp/c11_coupling/`; a correção não altera os fatores ou resultados científicos.
