"""Joint normal controls of Hermitian quadratics, with explicit shared latents.

Only C=E[q q^dagger] of a proper complex normal is supported. This constructs
a normal control with exact first two moments; it is not the quadratic law.
No sky response, statistical RNG, likelihood, or posterior is evaluated here.
"""
import numpy as np


def _hermitian(value, name, ndim):
    raw=np.asarray(value)
    if raw.dtype.kind not in 'fciu' or raw.ndim!=ndim or raw.shape[-1]!=raw.shape[-2] or not all(raw.shape) or not np.isfinite(raw).all():
        raise ValueError(name+' requires finite nonempty square matrix axes.')
    x=np.array(raw,complex,copy=True)
    scale=np.maximum(np.max(abs(x),axis=(-2,-1)),np.finfo(float).tiny)
    if np.any(np.max(abs(x-x.swapaxes(-1,-2).conj()),axis=(-2,-1))>64*np.finfo(float).eps*scale):
        raise ValueError(name+' is not Hermitian within roundoff.')
    # Roundoff-only averaging, no PSD repair. The residual is independently
    # checked above; positive definiteness is checked by Cholesky below.
    return (x+x.swapaxes(-1,-2).conj())/2


def embed_estimators(matrices, dimension, indices):
    h=_hermitian(matrices,'estimators',3)
    index=np.asarray(indices)
    if isinstance(dimension,(bool,np.bool_)) or not isinstance(dimension,(int,np.integer)) or dimension<1:
        raise ValueError('Positive integer ambient dimension required.')
    if index.dtype.kind not in 'iu' or index.shape!=(h.shape[-1],) or len(set(index.tolist()))!=len(index) or np.any(index<0) or np.any(index>=dimension):
        raise ValueError('Unique, in-range integer embedding indices required.')
    out=np.zeros((len(h),dimension,dimension),complex)
    out[:,index[:,None],index[None,:]]=h
    return out


class HermitianControlFactors:
    """Y=mu+Fv for v[K,P²] independent standard real normal coordinates.

    For C_k=L_k L_k† and A_ki=L_k† H_i L_k, F contains diag(A),
    sqrt(2) Re(A_ab), sqrt(2) Im(A_ab), with a<b in NumPy upper-triangle
    order. These are the coefficients of tr(A W), where W has independent
    N(0,1) diagonals and W_ab=(v_Re+i v_Im)/sqrt(2). Concatenate embedded
    H sets BEFORE construction to preserve their joint cross covariance.
    """
    def __init__(self,covariance,estimators,*,maximum_numeric_bytes):
        if isinstance(maximum_numeric_bytes,(bool,np.bool_)) or not isinstance(maximum_numeric_bytes,(int,np.integer)) or maximum_numeric_bytes<=0:
            raise ValueError('Explicit positive memory limit required.')
        raw_c=np.asarray(covariance);raw_h=np.asarray(estimators)
        if raw_c.ndim!=3 or raw_h.ndim!=3 or raw_c.shape[-2:]!=raw_h.shape[-2:]:
            raise ValueError('Require matching C[K,P,P] and H[D,P,P].')
        k,p,_=raw_c.shape;d=raw_h.shape[0]
        estimate=16*(8*k*p*p+4*d*p*p+4*k*d*p*p)+8*(k*d*(p*p+1))+1024**2
        if estimate>maximum_numeric_bytes:raise MemoryError('Construction array budget exceeded before allocation.')
        c=_hermitian(raw_c,'covariance',3);h=_hermitian(raw_h,'estimators',3)
        factor=np.linalg.cholesky(c)
        a=factor[:,None,:,:].swapaxes(-1,-2).conj()@h[None,:,:,:]@factor[:,None,:,:]
        upper=np.triu_indices(p,1)
        self.mean=np.trace(a,axis1=-2,axis2=-1).real.copy()
        self.coefficients=np.concatenate((np.diagonal(a,axis1=-2,axis2=-1).real,
            np.sqrt(2)*a[...,upper[0],upper[1]].real,
            np.sqrt(2)*a[...,upper[0],upper[1]].imag),axis=-1)
        if not np.isfinite(self.coefficients).all() or not np.isfinite(self.mean).all():
            raise ValueError('Normal-control factor overflow.')
        self.mean.flags.writeable=False;self.coefficients.flags.writeable=False
        self.maximum_numeric_bytes=int(maximum_numeric_bytes)
        self.construction_estimated_bytes=int(estimate)
        self.shape=(k,d,p*p)

    def covariance(self):
        k,d,_=self.shape
        estimate=self.coefficients.nbytes+self.mean.nbytes+3*8*k*d*d
        if estimate>self.maximum_numeric_bytes:raise MemoryError('Covariance output/scratch array budget exceeded.')
        value=self.coefficients@self.coefficients.swapaxes(-1,-2)
        if not np.isfinite(value).all():raise ValueError('Normal-control covariance overflow.')
        return value

    def apply(self,latent):
        v=np.asarray(latent)
        k,d,p2=self.shape
        if v.dtype.kind not in 'fiu' or v.ndim!=3 or not len(v) or v.shape[1:]!=(k,p2):
            raise ValueError('Real nonempty latents[R,K,P²] required.')
        estimate=self.coefficients.nbytes+self.mean.nbytes+8*v.size+3*8*len(v)*k*d
        if estimate>self.maximum_numeric_bytes:raise MemoryError('Latent/output array budget exceeded.')
        if not np.isfinite(v).all():raise ValueError('Finite latents required.')
        out=np.einsum('kdi,rki->rkd',self.coefficients,v,optimize=True)+self.mean
        if not np.isfinite(out).all():raise ValueError('Normal-control output overflow.')
        return out
