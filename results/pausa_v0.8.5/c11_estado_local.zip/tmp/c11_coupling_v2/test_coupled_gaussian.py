"""Bounded algebra/TOY controls only. No C11 physical generation or ORF."""
import hashlib,json,sys,time,unittest
from pathlib import Path
import numpy as np
from coupled_gaussian import HermitianControlFactors,embed_estimators

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
from pta.statistics import angular_estimators

def independent_real_moments(c,h):
    means=[];covariances=[]
    j=np.array([np.block([[x.real,-x.imag],[x.imag,x.real]]) for x in h])
    for x in c:
        r=.5*np.block([[x.real,-x.imag],[x.imag,x.real]])
        means.append([np.trace(z@r) for z in j])
        covariances.append([[2*np.trace(a@r@b@r) for b in j] for a in j])
    return np.array(means),np.array(covariances)

def toy(k=2,p=4,d=3,seed=911120101):
    rng=np.random.default_rng(seed)
    z=rng.normal(size=(k,p,p))+1j*rng.normal(size=(k,p,p))
    c=z@z.swapaxes(-1,-2).conj()/p+np.eye(p)
    z=rng.normal(size=(d,p,p))+1j*rng.normal(size=(d,p,p))
    h=(z+z.swapaxes(-1,-2).conj())/(2*p)
    return c,h

class Tests(unittest.TestCase):
    def test_real_embedding_mean_covariance(self):
        c,h=toy();f=HermitianControlFactors(c,h,maximum_numeric_bytes=64*1024**2)
        mu,sigma=independent_real_moments(c,h)
        np.testing.assert_allclose(f.mean,mu,atol=2e-14,rtol=2e-14)
        np.testing.assert_allclose(f.covariance(),sigma,atol=2e-14,rtol=2e-14)

    def test_direct_W_orientation(self):
        c,h=toy();f=HermitianControlFactors(c,h,maximum_numeric_bytes=64*1024**2)
        rng=np.random.default_rng(911120102);v=rng.normal(size=(7,2,16));w=np.zeros((7,2,4,4),complex)
        upper=np.triu_indices(4,1);w[...,np.arange(4),np.arange(4)]=v[...,:4]
        w[...,upper[0],upper[1]]=(v[...,4:10]+1j*v[...,10:])/np.sqrt(2)
        w[...,upper[1],upper[0]]=w[...,upper[0],upper[1]].conj()
        l=np.linalg.cholesky(c);a=l[:,None,:,:].swapaxes(-1,-2).conj()@h[None,:,:,:]@l[:,None,:,:]
        expected=f.mean+np.einsum('kdab,rkba->rkd',a,w).real
        np.testing.assert_allclose(f.apply(v),expected,atol=2e-14,rtol=2e-14)

    def test_actual_C11_H_with_synthetic_SPD_cross_covariance(self):
        geometry=json.loads((ROOT/'tmp/c11_execution_design/geometry_candidate.json').read_text())
        p=np.array([r['unit_direction'] for r in geometry['selected']]);s=geometry['synthetic_nominal_TOA_sigma_seconds']
        h12=angular_estimators(p[:12],s[:12],cross_bins=4,auto_bins=2).matrices
        h16=angular_estimators(p,s,cross_bins=4,auto_bins=2).matrices
        h=np.concatenate((embed_estimators(h12,16,list(range(12))),h16))
        c,_=toy(k=2,p=16,d=1,seed=911120103)
        f=HermitianControlFactors(c,h,maximum_numeric_bytes=64*1024**2)
        mu,sigma=independent_real_moments(c,h)
        np.testing.assert_allclose(f.mean,mu,atol=2e-14,rtol=2e-14)
        np.testing.assert_allclose(f.covariance(),sigma,atol=2e-14,rtol=2e-14)
        sub=HermitianControlFactors(c[:,:12,:12],h12,maximum_numeric_bytes=64*1024**2)
        np.testing.assert_allclose(sub.mean,f.mean[:,:10],atol=2e-14,rtol=2e-14)
        np.testing.assert_allclose(sub.covariance(),sigma[:,:10,:10],atol=2e-14,rtol=2e-14)
        self.assertGreater(np.max(abs(sigma[:,:10,10:])),.01)

    def test_singular_joint_estimator_covariance_needs_no_repair(self):
        c,h=toy();h=np.concatenate((h,h[:1],np.zeros_like(h[:1])))
        f=HermitianControlFactors(c,h,maximum_numeric_bytes=64*1024**2)
        v=np.random.default_rng(911120104).normal(size=(17,2,16));y=f.apply(v)
        np.testing.assert_array_equal(y[:,:,0],y[:,:,3]);np.testing.assert_array_equal(y[:,:,4],0)
        # Joint estimator covariance is singular by construction; no Cholesky
        # of this covariance, eigenvalue floor, or jitter was necessary.

    def test_shared_latent_compression_is_exact_linear_map(self):
        c,h=toy();f=HermitianControlFactors(c,h,maximum_numeric_bytes=64*1024**2)
        v=np.random.default_rng(911120105).normal(size=(11,2,16));w=np.array([.25,.75])
        actual=np.einsum('k,rkd->rd',w,f.apply(v))
        expected=w@f.mean+np.einsum('k,kdi,rki->rd',w,f.coefficients,v)
        np.testing.assert_allclose(actual,expected,atol=2e-14,rtol=2e-14)
        compressed=np.einsum('k,kij->ij',w*w,f.covariance())
        global_factor=np.concatenate([w[k]*f.coefficients[k] for k in range(2)],axis=1)
        np.testing.assert_allclose(compressed,global_factor@global_factor.T,atol=2e-14,rtol=2e-14)

    def test_toy_moments_predeclared_32768_and_six_SE(self):
        c,h=toy();f=HermitianControlFactors(c,h,maximum_numeric_bytes=64*1024**2)
        n=32768;v=np.random.default_rng(911120106).normal(size=(n,2,16));y=f.apply(v)
        sigma=f.covariance();delta=y-f.mean
        mean_z=abs(delta.mean(axis=0))/np.sqrt(np.diagonal(sigma,axis1=-2,axis2=-1)/n)
        empirical=np.einsum('rki,rkj->kij',delta,delta)/n
        diag=np.diagonal(sigma,axis1=-2,axis2=-1)
        se=np.sqrt((sigma*sigma+diag[:,:,None]*diag[:,None,:])/n)
        covariance_z=abs(empirical-sigma)/se
        self.assertLess(float(mean_z.max()),6);self.assertLess(float(covariance_z.max()),6)
        self.__class__.moment_report={'iid_realizations':n,'seed':911120106,'maximum_mean_z':float(mean_z.max()),'maximum_covariance_z':float(covariance_z.max()),'threshold':6,'scope':'TOY_NORMAL_CONTROL_MOMENTS_NOT_PHYSICAL_PTA_SBC'}

    def test_input_ownership_and_guards(self):
        c,h=toy();f=HermitianControlFactors(c,h,maximum_numeric_bytes=64*1024**2);saved=f.mean.copy()
        c[:]=0;h[:]=0;np.testing.assert_array_equal(f.mean,saved)
        with self.assertRaises(ValueError):f.mean[:]=0
        with self.assertRaises(ValueError):f.apply(np.zeros((1,2,16),complex))
        with self.assertRaises(ValueError):f.apply(np.ones((1,2,16))*np.nan)
        with self.assertRaises(MemoryError):f.apply(np.broadcast_to(0.,(1000000,2,16)))
        c,h=toy()
        with self.assertRaises(MemoryError):HermitianControlFactors(c,h,maximum_numeric_bytes=1)
        c[0,0,1]+=1
        with self.assertRaises(ValueError):HermitianControlFactors(c,h,maximum_numeric_bytes=64*1024**2)
        with self.assertRaises(np.linalg.LinAlgError):HermitianControlFactors(np.zeros((1,2,2)),np.ones((1,2,2)),maximum_numeric_bytes=64*1024**2)
        with self.assertRaises(ValueError):embed_estimators(h,4,[0,1,1,3])

    def test_covariance_output_budget_before_Gram(self):
        # Small factors can produce a much larger D² covariance. The old
        # implementation accepted construction but forgot this output budget.
        f=HermitianControlFactors(np.ones((1,1,1)),np.ones((1000,1,1)),maximum_numeric_bytes=2*1024**2)
        self.assertLess(f.construction_estimated_bytes,2*1024**2)
        with self.assertRaisesRegex(MemoryError,'Covariance output'):f.covariance()

if __name__=='__main__':
    start=time.process_time();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    report={'status':'PASS_ALGEBRA_AND_TOY_ONLY' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'cpu_seconds':time.process_time()-start,'cpu_cap_seconds':30,'maximum_numeric_bytes':64*1024**2,'actual_ORFs':0,'actual_likelihood_evaluations':0,'actual_physical_PTA_draws':0,'moment_check':getattr(Tests,'moment_report',{}),'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name('coupled_gaussian.py'),ROOT/'src/pta/statistics.py',ROOT/'tmp/c11_execution_design/geometry_candidate.json']}}
    Path(__file__).with_name('validation.json').write_text(json.dumps(report,indent=2)+'\n')
    if report['cpu_seconds']>30:raise RuntimeError('Small-test CPU budget exceeded.')
    sys.exit(not result.wasSuccessful())
