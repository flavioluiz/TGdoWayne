"""C11 metadata/scalar cost arithmetic only: no NumPy/PTA/ORF/likelihood/RNG."""
from pathlib import Path
import argparse
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def positive_int(value, name):
    if type(value) is not int or value < 1:
        raise ValueError(name + ' must be a positive integer')
    return value

def harmonic_cost(k, p, max_distance, duration, batch=8):
    y = 2*math.pi*k*max_distance/duration
    l, n = int(y+100), int(2*y+220)
    lf, nf = l+40, n+80
    def memory(ll, nn):
        q = ll-1
        return (8*nn*q+8*p*p*q+64*nn+16*batch*p*nn
                +96*batch*nn+64*batch*p*q+64*batch*p*p)
    return dict(channel=k, maximum_fL_cycles=k*max_distance/duration,
                maximum_phase=y, lmax=l, nmu=n, fine_lmax=lf, fine_nmu=nf,
                basis_and_buffers_bytes=max(memory(l,n),memory(lf,nf)),
                real_GEMM_multiplications_per_mass_both_resolutions=
                2*p*((l-1)*n+(lf-1)*nf),
                beta_physical_range=[math.sqrt(1-1/k**2),1],
                physical_phase_variation=y*(1-math.sqrt(1-1/k**2)),
                frozen_beta_phase_variation=y)

def cost_table(rows, n, p=16):
    # Reuse k=1 completely; u=0 in C_beta is identical to B for every channel.
    per = [r['real_GEMM_multiplications_per_mass_both_resolutions'] for r in rows]
    k = len(rows)
    b = n*sum(per)
    cb = (n-1)*sum(per[1:])
    reserve = 16*n*(k+2)*p*p+8*n*k
    return dict(common_mass_nodes_upper_bound=n, physical_channel_nodes=n*k,
                additional_frozen_beta_channel_nodes=(n-1)*(k-1),
                physical_real_GEMM_multiplications=b,
                frozen_beta_additional_real_GEMM_multiplications=cb,
                total_real_GEMM_multiplications=b+cb,
                physical_fine_numeric_bytes=16*n*k*p*p,
                frozen_beta_additional_fine_numeric_bytes=16*(n-1)*(k-1)*p*p,
                estimated_peak_one_branch_arrays_bytes=reserve+max(r['basis_and_buffers_bytes'] for r in rows),
                memory_assumption='Build B and C_beta sequentially; release first branch arrays. No existing table resident. No Python/BLAS/RSS guarantee.',
                scope='Dominant two-real-GEMM multiplication count, not FLOPs or a bound on all work. Excludes sparse sky checks, oracles, roots, I/O, recurrence and factorizations.')

def metadata_check(g):
    if g.get('status') != 'METADATA_GEOMETRY_ONLY_NOT_APPLICATION_OR_INFERENCE' or g.get('execution_enabled') is not False:
        raise ValueError('Unexpected geometry scope')
    selected = g['selected']
    if len(selected) != 16 or len({x['pulsar'] for x in selected}) != 16:
        raise ValueError('Require 16 unique pulsars')
    if g['nested_P12_indices'] != list(range(12)):
        raise ValueError('Nested subset must preserve first 12')
    if g['proposed_positive_channels'] != list(range(1,9)) or g['proposed_duration_years'] != 4.5:
        raise ValueError('Candidate channel/duration contract changed')
    for name in ['synthetic_distance_light_years','synthetic_nominal_TOA_sigma_seconds','synthetic_red_noise_multipliers']:
        values=g[name]
        if len(values)!=16 or any(type(x) not in (int,float) or not math.isfinite(x) or x<=0 for x in values):
            raise ValueError(name+' must have 16 finite positive entries')
    for x in selected:
        v=x['unit_direction']
        if len(v)!=3 or any(not math.isfinite(t) for t in v) or abs(sum(t*t for t in v)-1)>1e-12:
            raise ValueError('Direction is not unit length')
    if min(g['synthetic_distance_light_years']) != 100 or max(g['synthetic_distance_light_years']) != 500:
        raise ValueError('Synthetic distance range changed')
    rows=[]
    for p,k in [(12,4),(16,8)]:
        dots=[sum(a*b for a,b in zip(selected[i]['unit_direction'],selected[j]['unit_direction'])) for i in range(p) for j in range(i+1,p)]
        npairs=p*(p-1)//2
        bins=[npairs//4+(j<npairs%4) for j in range(4)]
        phase=2*math.pi*k*max(g['synthetic_distance_light_years'][:p])/4.5
        if phase>2*math.pi*1000:
            raise ValueError('Outside C05 1000-cycle domain')
        rows.append(dict(name=f'P{p}K{k}',pulsars=p,channels=k,pairs=npairs,
                         A0_complex_dimension=p*k,A_dimension=10*k,B_dimension=10,
                         cross_bin_pair_counts=bins,auto_bin_pulsar_counts=[p//2,p//2],
                         maximum_fL_cycles=phase/(2*math.pi),maximum_phase=phase,
                         minimum_angular_separation_degrees=math.degrees(math.acos(min(1,max(dots)))),
                         maximum_distance_ly=max(g['synthetic_distance_light_years'][:p])))
    return rows

def report(g, inputs):
    geometry=metadata_check(g)
    rows=[harmonic_cost(k,16,500,4.5) for k in range(1,9)]
    unique_initial_nodes=10*(32+64)+11
    # Fresh production500, engineering16, fixed .995 outside panel edges.
    # Other fixed masses0/.5 already are edges. No random draws are made here.
    production_upper=unique_initial_nodes+500+1
    pilot_upper=production_upper+16
    stages=[dict(name='initial_GL32_64_and_edges',**cost_table(rows,unique_initial_nodes)),
            dict(name='plus_production_truths_and_fixed_truth',**cost_table(rows,production_upper)),
            dict(name='plus_engineering16_upper_bound',**cost_table(rows,pilot_upper)),
            dict(name='conditional_GL128_refinement_upper_bound_not_authorized',**cost_table(rows,pilot_upper+1280)),
            dict(name='dense8336_counterfactual_not_requested',**cost_table(rows,8336))]
    historical=json.loads((ROOT/'tmp/c07_orf_efficiency/results/benchmark.json').read_text())
    rates=[x['preflight']['real_multiplications_per_batch']/x['blas_evaluation_seconds'] for x in historical['rows']]
    for row in stages:
        work=row['total_real_GEMM_multiplications']
        row['historical_rate_illustration_evaluation_minutes']=[work/max(rates)/60,work/min(rates)/60]
    # Proposed 8 sparse sky cases: two k1 cross; three k8 B and three k8 C_beta.
    # Each independently refined nmu=n/nf with nphi=2*nmu.
    sky=sum(count*2*(rows[k-1]['nmu']**2+rows[k-1]['fine_nmu']**2) for k,count in [(1,2),(8,6)])
    curves=2*9*(500+3*32)
    return dict(schema='C11_SCALAR_PREFLIGHT_v1',status='CANDIDATE_COUNTS_ONLY_NO_PHYSICAL_EXECUTION',
                ORF_calls=0,likelihood_calls=0,generated_statistical_realizations=0,
                source_sha256={str(p.relative_to(ROOT)):sha(p) for p in inputs},
                configurations=geometry,frequencies=rows,table_stages=stages,
                quadrature_unique_initial_nodes=unique_initial_nodes,
                scalar_count_assumptions=dict(main_paired_joint_realizations=500,fixed_cells=3,
                     fixed_repetitions_per_cell=32,engineering_new_joint_realizations=16,
                     analyses_per_configuration=9,central_configurations=2,
                     conditional_posteriors_main=9000,conditional_posteriors_fixed=1728,
                     conditional_posteriors_total=curves,engineering_not_in_production_total=True,
                     initial_likelihood_values=curves*unique_initial_nodes,
                     main_and_fixed_raw_CN_bytes=596*8*16*16,
                     paired_gaussian_observables_bytes=596*(8*10+4*10)*8,
                     curve_numeric_bytes_per_configuration=9*596*unique_initial_nodes*8,
                     sky_control_cases=8,sky_direct_refined_angular_point_proxy=sky),
                matched_SBC=dict(groups=6,independent_ids_per_group=500,tests_per_group=7,
                     total_Holm_family=42,alpha=.05,paired_groups_not_independent=True),
                historical_throughput=dict(minimum_GEMM_real_multiplications_per_second=min(rates),
                     maximum_GEMM_real_multiplications_per_second=max(rates),
                     source='tmp/c07_orf_efficiency/results/benchmark.json',
                     comparable_phase_not_new_P16K8_measurement=True,wall_time_guarantee=False,
                     exclusions='basis creation, P16 geometry contractions, transfer behavior under C_beta, sky checks, disk, ORF oracles, likelihood/integration, concurrency'),
                recommended_preflight_only_headroom=dict(numeric_array_bytes=1024**3,RSS_bytes=2*1024**3,
                     maximum_saved_file_bytes=90*1024**2),
                final_execution_caps=None,
                pending_before_caps=['Independent physical pilot and sparse sky work measurement',
                     'Budget root/partial-integral/oracle ORF nodes from actual counts',
                     'Measure peak RSS and full integration time',
                     'Resolve GL/PCHIP/contour convergence, especially C_beta high channel',
                     'Guard semantic branch identity and highest-channel checks'])

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--geometry',type=Path,default=ROOT/'tmp/c11_execution_design/geometry_candidate.json')
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args()
    if a.output.exists():raise FileExistsError(a.output)
    inputs=[a.geometry.resolve(),Path(__file__).resolve(),ROOT/'tmp/c11_execution_design/prepare_geometry.py',
            ROOT/'src/inference/orf_blas.py',ROOT/'src/inference/orf_table_builder.py',ROOT/'src/inference/orf_backend.py',
            ROOT/'src/pta/statistics.py',ROOT/'tmp/c07_orf_efficiency/results/benchmark.json',
            ROOT/'implementation_plan/commits/C11_aplicacao.md',ROOT/'tmp/c11_feasibility/audit_summary.json']
    result=report(json.loads(a.geometry.read_text()),inputs)
    with a.output.open('x') as file:json.dump(result,file,indent=2,allow_nan=False);file.write('\n')
    print(json.dumps({'status':result['status'],'main_posterior_integrals':9000,
                      'initial_nodes':result['quadrature_unique_initial_nodes'],
                      'full_initial_work_T':result['table_stages'][2]['total_real_GEMM_multiplications']/1e12,
                      'final_caps':None,'output':str(a.output)}))

if __name__=='__main__':main()
