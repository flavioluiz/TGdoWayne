# C11 — extensão periódica pareada com geometria pública

**Proposta de ramo, não execução nem conclusão de C11.** Data: 11/09/2026. Esta entrega contém leitura de metadados e contas escalares. Não calcula ORFs, likelihoods, observações simuladas ou posteriores. A execução permanece condicionada a C10 publicado e validado, à decisão de ramo registrada e aos gates abaixo. `geometry_candidate.json`, criado pelo ROOT, fixa a geometria candidata; `preflight_costs.json` quantifica recursos sem instanciar o backend físico.

## Decisão de ramo e alcance

Adotar, como candidato executável, **simulação periódica ampliada**, com duas configurações: P12K4 e P16K8. O ramo observacional não está pronto porque falta um adaptador de timing, janela e ruído validado para um benchmark publicado. **TOAs reais estão disponíveis.** A auditoria de 10/09/2026 conferiu produtos MeerKAT, EPTA, NANOGrav e IPTA em graus de detalhe explicitados em `tmp/c11_feasibility/PARECER_C11.md`; não autoriza dizer que faltam dados em geral.

O plano C11 atualmente condiciona a extensão simulada à falta de produtos essenciais. A decisão formal deve precisar essa frase: neste caso existem insumos públicos, mas a reconstrução da verossimilhança observacional ainda não foi implementada e validada na janela do projeto. Registrar essa alteração de interpretação antes da execução. Não renomear o simulador atual como análise observacional para satisfazer o item 2 do plano.

A simulação testa a transferência da comparação metodológica para **outra geometria e uma dimensão maior**, com parâmetros espectrais e de ruído conhecidos. Não reproduz uma análise MeerKAT, não gera um limite observacional da massa e não testa amostragem irregular, ajuste temporal, ruído cromático ou incertezas individuais de distância. Aumentar população e banda simultaneamente não separa os efeitos causais de P e K; não expandir para P12K8/P16K4 ou TOAs reais neste ramo.

## Geometria pública e elementos sintéticos

A origem é o pacote oficial MeerKAT 4,5 anos, DOI [10.57891/j0vh-5g31](https://doi.org/10.57891/j0vh-5g31), licença CC BY 4.0 documentada pelo [registro DataCite](https://api.datacite.org/dois/10.57891/j0vh-5g31). O arquivo local tem SHA-256 `172eb9472f4788f22bfe3b24faad2dc0169fca680b80340e4c829201fdafc393`. O catálogo guarda a aquisição; esta proposta não copia o pacote para Git. A atribuição deve acompanhar os metadados derivados.

Dos 83 arquivos PAR, 72 possuem RAJ/DECJ explícitos. A exclusão dos outros 11 é um filtro de formato, não uma afirmação sobre sua localização ou utilidade: alguns podem usar outra parametrização astrométrica. O algoritmo inicia no PSRJ lexicograficamente primeiro e seleciona, de forma gulosa, a maior separação angular mínima; empates seguem a ordem lexicográfica. Nenhum resíduo, sinal, massa ou posterior orienta a seleção. As coordenadas são lidas em suas épocas de referência, sem propagação de movimento próprio: uma geometria fixa de simulação, não uma solução temporal nova. Maximin favorece espalhamento angular e não constitui amostra representativa da colaboração.

Os primeiros 12 dos 16 selecionados formam P12. Frequências, distâncias, precisão nominal e multiplicadores de ruído desses 12 são exatamente os mesmos em ambos os experimentos. Apenas posições são públicas; **distâncias de 100–500 anos-luz, precisões de 100–1000 ns e multiplicadores de ruído vermelho de .5–2 são sintéticos**. Os valores exatos e sementes usadas para preparar esses metadados constam do JSON. Não converter anos-luz em parsecs por troca de rótulo.

| Configuração | Pulsares; pares cruzados | Canais positivos | Dimensão A0 complexa; A real; B real | L máximo efetivo | Máximo fL/c | Separação mínima |
|---|---|---|---|---|---|---|
| P12K4 | 12; 66 | 1–4 | 48; 40; 10 | 446,667 ly | 397,037 ciclos | 31,797° |
| P16K8 | 16; 120 | 1–8 | 128; 80; 10 | 500 ly | 888,889 ciclos | 23,152° |

Ambos usam T=4,5 anos julianos e f_k=k/T. O maior y=2πfL/c é 5585,054 rad, abaixo do domínio C05 de 1000 ciclos. A banda maior preserva o máximo de fase do antigo P12K4 de Fibonacci por reduzir as distâncias sintéticas; portanto não testa alcance a fases arbitrariamente maiores. Estar dentro do domínio é necessário, mas não aprova ordens nem tabelas para a nova geometria.

## Modelo e pareamento dos dados

Fixar prospectivamente `(log10Agw, gammaGW, log10Ar, log10EFAC)=(-15,13/3,-15.5,0)`, índice vermelho 4 e cadência nominal de 14 dias. A cadência só define a PSD branca no experimento periódico; não se importa uma janela de observação real. Usar o mesmo `dt=T/ceil[T/(14 dias)]` em ambas as configurações. A única variável inferida é u=f_gT, com priori uniforme contínua em [0,1]. A conversão física é m_gc²=hu/T; o suporte e seu quantil sem dados não são uma restrição observacional.

Na geração física, em cada frequência,

`C_k(u)=P_GW(f_k) Γ_k(u)+diag[r_a² P_red(f_k)+2(EFAC σ_a)² dt]`,

`q_k ~ CN_própria(0,C_k)`, com frequências positivas independentes.

Conservar as unidades de C06: PSD unilateral de resíduos em s³, q em s^(3/2), coeficiente periódico a_k=q_k/√(2T). A normalização auxiliar deve ser **a mesma nos canais compartilhados**: propor a escala determinística `s_k=P(f_k;log10A=-14.7,gamma=13/3)+2 median(σ_16)² dt`, usar C_k/s_k e q_k/√s_k nos dois experimentos. Não recalcular a mediana para P12. Essa escolha de coordenada é fixa antes dos dados; seu Jacobiano entra em evidências físicas quando necessário. Comparar posteriores/CDFs na mesma medida, não valores absolutos de logZ entre espaços de dados diferentes.

Cada uma das 500 massas novas produz **um único q de shape 8×16**. P12K4 recebe `q[:4,:12]`, sem novo sorteio. Suas covariâncias são as submatrizes principais correspondentes. São 500 realizações independentes por configuração e 500 pares de experimentos; não 1000 realizações independentes. Distâncias/ruídos/nuisances dos mesmos pulsares e os quatro canais comuns não mudam no subconjunto.

Fixar H pela função C06 `angular_estimators`: quatro bins angulares de contagens iguais, em Re e Im, mais dois bins de autos por precisão nominal. P12 tem bins cruzados 17/17/16/16 e autos 6/6; P16 tem 30/30/30/30 e 8/8. As fronteiras e matrizes H diferem entre populações, mas são fixadas antes dos dados. Em cada configuração, A empilha os dez estimadores por frequência e B aplica pesos uniformes 1/K. Os componentes imaginários e autos são conservados.

### Controle G com acoplamento explícito entre populações

Gerar G com os momentos físicos verdadeiros **uma vez por realização**, antes de avaliar modelos alternativos. Para cada canal, seja C=LL† a covariância 16×16. Gere W hermitiana: diagonal real N(0,1), elementos acima da diagonal `(x+iy)/√2`, com todos os escalares normais independentes; a parte inferior é conjugada. Para qualquer estimador H, defina

`Y_H=tr(HC)+tr[(L†HL)W]`.

Assim `Cov(Y_H,Y_J)=tr(H C J C)`, porque `Cov[tr(AW),tr(BW)]=tr(AB)` para A,B hermitianas. Usar H16 e H12 embutido com zeros na matriz 16×16 produz conjuntamente as marginais corretas dos dois conjuntos de estimadores, inclusive sua covariância cruzada. A construção evita fatorar uma covariância conjunta de estimadores potencialmente singular; não requer recorte de autovalores. É uma proposta algébrica a testar contra uma representação real independente, não um controle já executado.

W é compartilhada entre populações nos quatro canais comuns; as frequências continuam independentes. Os latentes CN e W usam bancos RNG independentes, condicionados à mesma massa, com sementes/receita explícitas. A diferença frente ao compartilhamento CN/G da receita C07 deve constar do manifesto; preserva as marginais e o pareamento de A/B/C dentro de cada família. A_G/B_G/C_G usam esse mesmo Y; C_beta e C_full alteram **apenas a likelihood**, nunca regeneram o dado observado.

## Análises e interpretações permitidas

Aplicar nove análises por população: `A0_CN`, `A_CN`, `B_CN`, `C_beta_CN`, `C_full_CN`, `A_G`, `B_G`, `C_beta_G`, `C_full_G`. A0 usa a CN própria completa nos canais; A/B/C usam normais para os estimadores, com média, covariância e logdet completos. A normal de A/B sobre dados CN físicos continua sendo aproximação; quatro ou oito frequências não criam segmentos independentes adicionais fictícios.

| Comparação | Interpretação |
|---|---|
| A_G → B_G, dentro de cada configuração | Compressão de frequência dentro da mesma família normal correta e operador W conhecido |
| B → C_beta | Congelar `β_1=√(1−u²)` em todos os canais, mantendo fases físicas f_kL, PSD e ruídos |
| B → C_full | Usar Γ(f_1,u) inteira em todos os canais, mantendo PSD e ruídos nas frequências físicas |
| A0_CN versus A_CN/B_CN | Mudança de informação e de família probabilística; não atribuir diferença exclusivamente à compressão |
| P12K4 versus P16K8 | Ampliação conjunta de geometria/população e frequências, sob nuisances conhecidos |

Em B, `β_k=√[1−(u/k)²]`. Em u=0, C_beta deve coincidir com B; C_full pode diferir por congelar também fases pulsar–Terra. Os pares B/C usam sempre o mesmo B observado e recalculam **média e covariância**. No núcleo isotrópico TT, cada ORF é hermitiana PSD; não corrigir respostas inválidas com clipping.

A0 de P16 contém A0 de P12 por marginalização, permitindo a desigualdade de informação **esperada sob a priori** do teorema de processamento de dados, com ruídos conhecidos. Limites superiores em realizações individuais não precisam ordenar-se. B16 não contém necessariamente B12, pois H e W diferem; nem A_G16 determina A_G12. Seu acoplamento não autoriza aplicar a mesma desigualdade a esses espaços comprimidos. A curva posterior completa, KL em relação à priori, W1, diferenças de CDF, limites e incerteza entre realizações são resultados; não inferir informação somente da proximidade do quantil90 a .9.

## Bancos candidatos e síntese

Núcleo: 500 massas contínuas novas da priori uniforme, 500 realizações conjuntas CN/G e as duas populações pareadas. Total: **9000 posteriores 1D**, nove análises × duas configurações × 500. Não reutilizar dados de engenharia, verdades C07 ou sortear massas de nós GL. Propor 16 realizações novas de engenharia, separadas de SBC, com casos internos/limiar e ambas as populações; IDs, seeds e funções de validação devem ser congelados antes de gerar o piloto.

Subconjunto condicional pequeno, sem cruzamento fatorial: três células de 32 realizações novas cada — u=0 com ruído central; u=.995 com ruído central; u=.5 com log10Ar=-14.7 e demais nuisances centrais. O ruído alterado é conhecido também na inferência. As mesmas duas populações e nove análises acrescentam 1728 posteriores. Não fazer KS de uniformidade dessas 96 massas fixas, nem exigir cobertura Bayes nominal universal a cada verdade; apresentar contagens, intervalos binomiais ponto a ponto e erro da comparação pareada. Em u=0, PITu estrutural=0; limites superiores incluem zero, intervalos centrais da priori contínua o excluem. Não empregar a cobertura estrutural como evidência de sensibilidade.

A família correta do núcleo tem **seis grupos**: duas populações × A0_CN/A_G/B_G. Propor uma família Holm de42 testes (por grupo: KS de PITu e PITlogL, quatro coberturas .05/.5/.9/.95 e uma central .05–.95), α=.05. As dependências entre grupos pareados não invalidam Holm; a independência exigida é entre os500 IDs de cada grupo. Os outros12 grupos são aproximações explícitas, reportados separadamente; não exigir uniformidade deles para aprovar a integração. Separar falha científica de calibração da família, falha numérica por função e hipótese fora de priori.

Guardar todos os IDs e flags. Para produtos determinísticos aprovados operacionalmente, usar a margem C09 ±.002; unresolved recebe [0,1]. Não converter precisão insuficiente em errozero ou descartar dados. A síntese deve propagar esses envelopes para a sensibilidade dos testes, não aprovar cálculo porque KS foi favorável. O PIT de logL precisa de contornos e tratamento explícito de platôs/átomos; uma likelihood constante não fornece automaticamente PIT de logL contínuo uniforme sem convenção de empates apropriada.

## Integrador 1D e gates independentes

Aproveitar C09 após sua integração/validação, preservando α=asin(u), Jacobiano cosα, suportes e tolerâncias. Começar com dez painéis nas bordas emu `[0,.0001,.001,.01,.05,.25,.5,.75,.9,.99,1]` e GL32/64. São960 nós internos distintos mais11 bordas compartilhadas =971 logL distintas por curva quando há cache exato. A v2 candidata usa PCHIP da **densidade escalada**, não das massas de quadratura; sua antiderivada produz CDFs/quantis sem novas likelihoods. Não é interpolação certificada da ORF.

Preservar os gates C09: diferenças de logZ, momentos, KL e W1 ≤.001; CDF/PIT≤.002; brackets de quantis com largura≤.001 emu, confirmados nos níveis. Comparar Z_PCHIP com Z_GL, além dos dois níveis. Contornos de logL requerem refinamento de raízes, segmentos e massas não resolvidas; a aprovação operacional finita deve trazer domínio, evidências e margem. Não exige uma prova global de monotonicidade da likelihood, mas concordância de duas malhas sozinha não basta. O contraexemplo sintético de pico estreito perdido por32/64 em `tmp/c09_integrator_v2/VIABILIDADE.md` permanece relevante.

Antes de produção:

1. Validar a construção da geometria/subconjunto, escala comum, matrizes H e acoplamento G com referência real simétrica de formas quadráticas. Demonstrar marginais CN e normais, covariância cruzada das populações e compressão exata W em pequeno teste de momentos, com critério prospectivo; não executar nem alegar essa verificação nesta entrega.
2. Repetir limites analíticos TT de C05: β=0, auto/cross, paridade, conjugação e GR; não usar Hellings–Downs de Terra como igualdade para pulsar terms finitos. Conferir a normalização de PSD/resíduos e uma rotação global da geometria. Benchmark publicado significa limite/expressão compatível com as hipóteses, não reprodução de um limite observacional MeerKAT.
3. Conferir cada matriz nos nós por duas resoluções harmônicas, hermiticidade/PSD e valores finitos. Comparar **integração direta no céu** em pares prospectivos de separação mínima/máxima e auto de pulsar novo, nos canais1 e8, com fases/distâncias reais da candidata, cobrindo B e C_beta. Repetir resolução angular da referência; acordo entre duas resoluções harmônicas não é referência independente.
4. Conferir matrizes e logL do subconjunto contra construção P12 independente em âncoras; conferir kernels em lotes contra Cholesky direta e normalização da CN em representação real. Para B/C usar o mesmo dado, momentos e determinante; documentar igualdade B/C_beta emu0 e o possível desvio C_full.
5. Executar engenharia16 com duas regras e referência adaptativa emu ou na CDF da priori. Escolher antes dos resultados ao menos16 pares dado/modelo, cobrindo nove famílias, duas populações, caudas/limiar e ruído forte. Confrontar CDFs/quantis PCHIP com integrais parciais diretas, logL fora dos nós e contornos segmentados. Não remover alvos que falhem; registrar refinamento ou UNRESOLVED.
6. Medir custo de **todo** o fluxo e recursos antes de congelar cap e ativar500. ORFs para verdades e oráculos são calculadas diretamente e checadas; a mesma interpolação de inferência não gera verdades. Não usar diagnóstico SBC para escolher refinamento, tolerância ou encerrar tentativa favorável.

A seleção exata dos pares/casos, IDs e seeds de C11 é parte da abertura formal; esta proposta só prepara metadados e contagens. O piloto não começa por criar estes documentos.

## Recursos, pontos cegos e bloqueios concretos

`preflight_costs.py` usa apenas a biblioteca padrão e metadados. As ordens candidatas transcrevem o backend C07: `l=floor(ymax+100)`, `n=floor(2ymax+220)`, e refinamento `(+40,+80)`. Elas não foram aprovadas para C11. No canal8 de P16 chegam a l=5685/5725 e n=11390/11470; as duas multiplicações reais por matriz compartilham a base de Legendre. O custo registrado é uma contagem dos GEMMs dominantes, **não FLOPs totais nem promessa de tempo**.

| Construção candidata P16, B físico + C_beta | Nós de massa comuns (limite de união) | Multiplicações reais dominantes | Pico estimado de arrays, uma tabela por vez |
|---|---|---|---|
| GL32/64 + bordas | 971 | 26,200 trilhões | 626,4 MiB |
| Mais500 verdades e .995 fixa | 1472 | 39,725 trilhões | 646,0 MiB |
| Mais16 verdades de engenharia | 1488 | 40,157 trilhões | 646,6 MiB |
| Adição eventual GL128 | 2768 | 74,712 trilhões | 696,7 MiB |

Os números reutilizam k1 entre B/C_beta e u0 em todos os canais. Tal reuso deve ser implementado com identidade explícita; o construtor atual só sabe a lei β_k física. C_full reutiliza k1 físico, mas seus momentos/covariâncias ainda são recalculados nas PSDs físicas. P12 é uma view validada da tabela16 nos canais compartilhados, sem uma segunda campanha ORF completa. Se o adaptador não explorar esse reuso, deve recalcular o preflight para sua contagem efetiva.

As taxas históricas de um benchmark C07 de fase comparável, com12 pulsares, dariam **32–52 minutos apenas para avaliações ORF** do conjunto inicial com engenharia. É extrapolação aritmética, não tempo medido P16K8: exclui construção das bases, contrações geométricas maiores, referência direta, raízes, I/O, factorização, integração e concorrência. O ensaio prospectivo de oito referências de céu com duas resoluções acrescentaria cerca de3,157 bilhões de pontos angulares; o guard histórico de1bilhão precisa de orçamento próprio, não desativação silenciosa. Pode-se escolher controles com custo mais eficiente antes do piloto, desde que mantenham independência e cobertura de k8/C_beta.

A maior ameaça à resolução é **C_beta**, cujo canal8 percorre uma variação de fase de5585 rad quando β1 vai de0 a1; a resposta física β8 varia só≈43,8 rad nesse canal. O primeiro canal físico varia≈698 rad. GL32/64 pode integrar a contribuição relevante sem resolver toda oscilação da ORF, mas isso deve ser demonstrado por oráculos e precisão da posterior, nunca inferido do aspecto suave dos nós. Se houver aliasing, refinar painéis/ordens e registrar custo. Não aplicar retrospectivamente médias de fase que mudam o modelo.

Um banco denso8336 herdado sem necessidade custaria≈225 trilhões e **273 MB apenas para Γ físico**, acima do limite por arquivo GitHub. Não está proposto. Nos1472 nós iniciais sem engenharia, Γ físico fino tem48,23 MB e o adicional C_beta42,18 MB: guardar separadamente por função, com nós/assinaturas/hashes e relatório coarse–fine. Arrays de gerações CN/G ocupam≈1,79 MB para as596 realizações pareadas; uma tabela de logL dos nove modelos/cenários por configuração ocupa≈41,67 MB. Não replicar covariâncias por dado. Reutilizar fatorações por nó/nuisance, processar uma configuração ou cenário por vez, e arquivar compactos/receitas com todos os IDs. O orçamento total começa em10.416.888 valores de logL para971 nós ×10728 posteriores, **sem** raízes, oráculos e engenharia.

Recomenda-se considerar1GiB de arrays,2GiB de margemRSS e arquivos de até90MiB no preflight físico inicial; **os caps finais ficam nulos** até medir oráculos/fluxo completo. A reserva de nós adaptativos não pode ser escolhida fingindo que as971 avaliações incluem o PITlogL ou toda validação independente. Manter falhas numéricas explícitas se o custo admissível não alcançar a precisão.

Duas lacunas de código exigem correção prospectiva, sem modificar C07 em execução: `ExactNodeORF.direct_checks()` fixa `k=3` na chamada rotulada “highest”; isso testaria o quarto canal, não o oitavo. E a assinatura/cache atual codifica apenas a lei β física: C_beta precisa incluir sua regra no identificador, além de geometria, fases, normalização, resoluções e massas. Um token igual emu não torna duas respostas iguais.

## Suficiência para C11 e entregas de fechamento

Este ramo atende à **extensão simulada rigorosa** do C11 se forem executados o benchmark independente, calibração/diagnósticos, rastreabilidade, validação de recurso e comparação com literatura pertinente. As posições externas e maior dimensão acrescentam um teste delimitado; a simulação periódica e nuisance conhecido restringem sua generalização. A análise5D de C07/C08 continua sendo base separada; este exercício1D não replica sua marginalização.

Antes do commitv0.11.0: registrar decisão de ramo, versões/licenças reconsultadas, config/seed/hash, testes e falhas; incorporar resultados e limites ao capítulo, README e notas; compilar e inspecionar o PDF acumulado e verificar release/hash. Esta entrega não marca nenhum desses passos como concluído. Uma futura alegação observacional ainda exigirá os TOAs, timing/janela/ruído e um resultado publicado reproduzido no modelo adequado.
