"""Extract only public sky coordinates; do not read TOA bodies or infer PTA data."""
from pathlib import Path
import tarfile,hashlib,json,math
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'tmp/c11_feasibility/evidence/meerkat_partim.tar.gz'
OUT=Path(__file__).with_name('geometry_candidate.json')


def sexagesimal(value,ra):
    fields=value.split(':')
    if len(fields)!=3: raise ValueError('Expected sexagesimal metadata')
    sign=-1 if fields[0].startswith('-') else 1
    a,b,c=map(float,fields)
    if not all(math.isfinite(x) for x in [a,b,c]) or not 0<=b<60 or not 0<=c<60: raise ValueError('Invalid sexagesimal fields')
    coordinate=sign*(abs(a)+b/60+c/3600)
    if ra:
        if not 0<=coordinate<24: raise ValueError('RA outside [0,24) hours')
        return coordinate*math.pi/12
    if not -90<=coordinate<=90: raise ValueError('Declination outside [-90,90] degrees')
    return coordinate*math.pi/180


def main():
    if OUT.exists(): raise FileExistsError('Preserve existing selection; use a new version')
    rows=[]; excluded=[]
    with tarfile.open(SOURCE,'r:gz') as archive:
        for member in sorted(archive.getmembers(),key=lambda x:x.name):
            if not member.isfile() or not member.name.endswith('.par'): continue
            if member.size>1_000_000: raise ValueError('Unexpected large PAR metadata')
            raw=archive.extractfile(member).read()
            values={line.split()[0]:line.split()[1] for line in raw.decode().splitlines() if len(line.split())>=2 and not line.startswith('#')}
            if not all(k in values for k in ['PSRJ','RAJ','DECJ']):
                excluded.append({'member':member.name,'reason':'No explicit equatorial coordinates'});continue
            ra,dec=sexagesimal(values['RAJ'],True),sexagesimal(values['DECJ'],False)
            direction=[math.cos(dec)*math.cos(ra),math.cos(dec)*math.sin(ra),math.sin(dec)]
            rows.append({'pulsar':values['PSRJ'],'archive_member':member.name,'member_sha256':hashlib.sha256(raw).hexdigest(),'RAJ':values['RAJ'],'DECJ':values['DECJ'],'position_epoch_mjd':values.get('POSEPOCH',values.get('PEPOCH')),'unit_direction':direction})
    rows.sort(key=lambda x:x['pulsar'])
    if len({r['pulsar'] for r in rows})!=len(rows): raise ValueError('Duplicate pulsar')
    points=np.array([r['unit_direction'] for r in rows])
    selected=[0]
    while len(selected)<16:
        candidates=[i for i in range(len(rows)) if i not in selected]
        # Largest minimum angular separation equals smallest maximum cosine.
        scores=np.max(points[candidates]@points[selected].T,axis=1)
        selected.append(candidates[int(np.argmin(scores))])
    p=points[selected]
    if np.max(abs(np.sum(p*p,axis=1)-1))>1e-12: raise ArithmeticError('Unit-vector conversion failed')
    distance=np.linspace(100,500,16)[np.random.default_rng(911110101).permutation(16)]
    sigma=np.geomspace(1e-7,1e-6,16)[np.random.default_rng(911110102).permutation(16)]
    red=np.geomspace(.5,2,16)[np.random.default_rng(911110103).permutation(16)]
    package={'status':'METADATA_GEOMETRY_ONLY_NOT_APPLICATION_OR_INFERENCE','execution_enabled':False,'source_url':'https://doi.org/10.57891/j0vh-5g31','source_license':'CC BY 4.0 as recorded by DataCite in the independent audit','source_archive_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'source_archive_bytes':SOURCE.stat().st_size,'PARs_with_equatorial_positions':len(rows),'excluded':excluded,'selection':'Start lexicographically first PSRJ, then maximize minimum angular separation; ties use lexicographic order. No likelihood, timing residual or inferred mass consulted.','selected':[rows[i] for i in selected],'nested_P12_indices':list(range(12)),'synthetic_distance_light_years':distance.tolist(),'synthetic_nominal_TOA_sigma_seconds':sigma.tolist(),'synthetic_red_noise_multipliers':red.tolist(),'synthetic_seeds':[911110101,911110102,911110103],'proposed_duration_years':4.5,'proposed_positive_channels':list(range(1,9)),'maximum_fL_cycles':8*float(distance.max())/4.5,'maximum_phase_radians':2*math.pi*8*float(distance.max())/4.5,'scope_notes':['Only sky coordinates come from public metadata; distances, precision and red noise here are synthetic, not measured MeerKAT properties.','Coordinates are read at the supplied reference epochs; no proper motion propagation or timing fit is claimed.','No .tim content was read by this script. No observational likelihood or new graviton bound has been computed.','This prepares a candidate enlarged periodic simulation, not a validated observation-window model.'],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    OUT.write_text(json.dumps(package,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:package[k] for k in ['status','PARs_with_equatorial_positions','maximum_fL_cycles','maximum_phase_radians']},ensure_ascii=False))

if __name__=='__main__':main()
