"""Deterministic covariance-level review; no Monte Carlo, ORF or likelihood."""
from pathlib import Path
import hashlib,json,sys,time
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'review_sources'))
from coupled_gaussian import HermitianControlFactors,embed_estimators


def main():
    start=time.process_time();rng=np.random.default_rng(911120701)
    K,P,D=2,3,4
    z=rng.normal(size=(K,P,P))+1j*rng.normal(size=(K,P,P))
    C=z@z.swapaxes(-1,-2).conj()+np.eye(P)
    z=rng.normal(size=(D,P,P))+1j*rng.normal(size=(D,P,P))
    H=(z+z.swapaxes(-1,-2).conj())/2
    f=HermitianControlFactors(C,H,maximum_numeric_bytes=32*1024**2)
    checks=[]
    def check(name,actual,expected,tol=1e-10):
        err=float(np.max(abs(np.asarray(actual)-np.asarray(expected))))
        checks.append(dict(name=name,maximum_absolute_error=err,tolerance=tol,passed=err<=tol))
    mu=np.array([[np.trace(h@c).real for h in H] for c in C])
    sigma=np.array([[[np.trace(h@c@j@c).real for j in H] for h in H] for c in C])
    # 2M signed coordinate nodes have exactly zero mean and identity covariance;
    # this integrates all quadratic polynomials, with no statistical uncertainty.
    M=K*P*P
    v=np.r_[np.sqrt(M)*np.eye(M),-np.sqrt(M)*np.eye(M)].reshape(2*M,K,P*P)
    y=f.apply(v);dy=(y-mu).reshape(2*M,K*D)
    expected=np.zeros((K*D,K*D))
    for k in range(K):expected[k*D:(k+1)*D,k*D:(k+1)*D]=sigma[k]
    check('deterministic signed-coordinate mean',y.mean(axis=0),mu)
    check('deterministic complete joint covariance including zero cross frequency',dy.T@dy/(2*M),expected)
    # Embedding is checked for a nontrivial order, not just a leading block.
    C4=np.eye(4,dtype=complex);C4[0,2]=.2+.3j;C4[2,0]=.2-.3j
    H2=np.array([[[1,.4+.2j],[.4-.2j,-.3]],[[0,1j],[-1j,1]]])
    index=[2,0];embedded=embed_estimators(H2,4,index)
    fe=HermitianControlFactors(C4[None],embedded,maximum_numeric_bytes=32*1024**2)
    sub=C4[np.ix_(index,index)]
    check('ordered noncontiguous embedded mean',fe.mean[0],[np.trace(h@sub).real for h in H2])
    check('ordered noncontiguous embedded covariance',fe.covariance()[0],[[np.trace(h@sub@j@sub).real for j in H2] for h in H2])
    # Linear combinations of statistics act on the same latent realization.
    T=np.array([[1,.2,0,-.1],[0,1,.3,0]])
    ft=HermitianControlFactors(C,np.einsum('ad,dij->aij',T,H),maximum_numeric_bytes=32*1024**2)
    check('pathwise statistic linear map',ft.apply(v),np.einsum('ad,rkd->rka',T,y))
    # Unitary changes of the pulsar basis preserve the distribution, not arbitrary
    # identical-latent paths under separately computed Cholesky factors.
    U,_=np.linalg.qr(rng.normal(size=(P,P))+1j*rng.normal(size=(P,P)))
    fu=HermitianControlFactors(U@C@U.conj().T,U@H@U.conj().T,maximum_numeric_bytes=32*1024**2)
    check('unitary basis invariant distribution covariance',fu.covariance(),sigma)
    check('unitary basis invariant distribution mean',fu.mean,mu)
    # The standalone covariance method has no budget gate in archived v1.
    small=HermitianControlFactors(np.ones((1,1,1)),np.ones((1000,1,1)),maximum_numeric_bytes=2*1024**2)
    dense=small.covariance()
    finding=dict(id='G1',reproduced=dense.nbytes>small.maximum_numeric_bytes,
        construction_estimate=small.construction_estimated_bytes,declared_limit=small.maximum_numeric_bytes,
        covariance_output_bytes=dense.nbytes,parameters=dict(K=1,P=1,D=1000),
        scope='GENERIC_API_MEMORY_GUARD_NOT_A_FAILURE_AT_THE_PLANNED_C11_DIMENSIONS')
    report=dict(status='DETERMINISTIC_COUPLING_CHECKS_PASS_WITH_COVARIANCE_MEMORY_FINDING',
        checks=checks,passed=sum(c['passed'] for c in checks),CPU_seconds=time.process_time()-start,
        geometry_seed=911120701,statistical_MC_draws=0,deterministic_quadrature_nodes=2*M,
        actual_ORFs=0,likelihood_values=0,physical_PTA_draws=0,finding=finding,
        source_sha256=hashlib.sha256((HERE/'review_sources/coupled_gaussian.py').read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (HERE/'independent_results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['status','passed','CPU_seconds','finding']}))
    if not all(c['passed'] for c in checks):raise SystemExit(1)


if __name__=='__main__':main()
