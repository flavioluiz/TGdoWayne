# Auditoria independente do acoplamento gaussiano C11

O núcleo matemático examinado está correto para o controle normal dos estimadores quadráticos de um vetor CN próprio. Com C=LL† e A_i=L†H_iL, a média é tr(A_i), e os coeficientes reais são diag(A_i), √2 Re(A_i,ab) e √2 Im(A_i,ab). O sinal positivo da parte imaginária reproduz tr(A_iW), pois os dois fatores Hermitianos conjugam os índices opostos. O Gram dos coeficientes é Re tr(H_i C H_j C).

Os sete controles adicionais em `independent_results.json` usaram cubatura determinística de coordenadas com média zero e covariância identidade; não repetiram os sorteios Monte Carlo do autor. Foram conferidos os momentos conjuntos, os termos entre frequências independentes, incorporação ordenada não contígua de estimadores, transformações lineares dos observáveis e invariância distributiva sob mudança unitária da base dos pulsares. O maior erro absoluto foi 1,60×10⁻¹², abaixo da tolerância 10⁻¹⁰, em 0,054 s CPU. Nenhuma ORF, likelihood ou realização física PTA foi calculada.

Para acoplar geometrias, os estimadores menores devem ser incorporados no mesmo espaço de pulsares e concatenados antes da fatoração com a covariância física comum. O mesmo vetor latente é então aplicado ao conjunto completo. Fatorar duas covariâncias separadas e apenas reutilizar a seed não define, em geral, esse acoplamento. As aproximações A/B/C entram na análise dos mesmos dados; não devem substituir a covariância verdadeira da geração. A normal conjunta pode ser singular e a construção por fatores continua válida sem jitter ou clipping. Ela reproduz os dois primeiros momentos, não a distribuição quadrática CN inteira.

## Achado G1 e regressão separada

A v1, preservada em `review_sources/`, não reservava a saída K×D×D de `covariance()`. O caso K=P=1, D=1000 e teto de 2 MiB era aceito na construção e alocava uma saída de 8.000.000 bytes. Trata-se de uma guarda genérica; não foi observado defeito nas dimensões C11 planejadas.

O ROOT corrigiu a guarda em `tmp/c11_coupling_v2`, mantendo a v1 intacta. `regression_v2.json` registra o mesmo caso rejeitado antes do Gram em 0,00084 s CPU, sob SHA d0073007645ced4d18c5fe96c332a7de327450c65f54f2e7cf554ff94fa96ed4. A regressão foi leve, sem repetir o Monte Carlo. A revisão não aprova uma campanha C11 nem a precisão de ORFs ainda não examinadas.
