"""Fresh basis or sparse-sky process; physical hooks run only through ROOT auth."""
import sys
from pathlib import Path
from io_contract import ROOT,read_json,write_json,sha,verify_bindings,verify_worker_request,WorkerBudget


def run(request,guard):
    verify_worker_request(request)
    # Lifecycle guard and import-time accounting already exist before NumPy.
    import numpy as np
    from semantics import beta,cache_identity,sky_arguments
    plan=read_json(ROOT/request['plan']);g=read_json(ROOT/plan['geometry_path'])
    manifest=read_json(ROOT/request['manifest']);verify_bindings(manifest)
    source_sha=sha(ROOT/request['manifest'])
    sys.path.insert(0,str(ROOT/'src'))
    output=Path(request['output']);output.mkdir(exist_ok=False)
    if request['operation']=='basis_probe':
        from inference.orf_blas import RealHarmonicBasis,TableBudget
        probe=plan['basis_probes'][request['probe']];k=probe['channel']
        r=plan['frequencies'][k-1]['resolutions'][probe['resolution']]
        points=np.array([p['unit_direction'] for p in g['selected']]);dist=np.array(g['synthetic_distance_light_years'])
        if probe['kind']=='subset12':points=points[:12];dist=dist[:12]
        else:
            angle=.37;c=np.cos(angle);s=np.sin(angle)
            points=points@np.array([[c,-s,0.],[s,c,0.],[0.,0.,1.]]).T
        basis=RealHarmonicBasis(points,lmax=r['lmax'],nmu=r['nmu'],planned_batch=1,
           budget=TableBudget(maximum_estimated_memory_bytes=request['caps']['numeric']))
        guard.reserve('real',2*len(points)*r['nmu']*(r['lmax']-1))
        matrix=basis.evaluate(np.array([beta(probe['u'],k,'B')]),2*np.pi*k*dist/4.5)[0]
        if not np.isfinite(matrix).all():raise ArithmeticError('Nonfinite independent basis probe')
        target=output/'probe.npz'
        with target.open('xb') as f:np.savez(f,Gamma=matrix)
        guard.checkpoint()
        return dict(probe=probe,path=str(target),sha256=sha(target))
    if request['operation']=='harmonic':
        from inference.orf_blas import RealHarmonicBasis,TableBudget
        k=request['channel'];r=plan['frequencies'][k-1]['resolutions'][request['resolution']]
        points=np.array([p['unit_direction'] for p in g['selected']]);dist=np.array(g['synthetic_distance_light_years'])
        y=2*np.pi*k*dist/4.5
        basis=RealHarmonicBasis(points,lmax=r['lmax'],nmu=r['nmu'],planned_batch=8,
          budget=TableBudget(maximum_estimated_memory_bytes=request['caps']['numeric'],
                  maximum_multiplications_per_batch=50_000_000_000,maximum_batch_size=8))
        guard.checkpoint();saved=[]
        for law in ('B','C_beta'):
            nodes=[u for u in request['nodes'] if not (law=='C_beta' and (k==1 or u==0))]
            for start in range(0,len(nodes),8):
                batch=nodes[start:start+8];guard.reserve('real',len(batch)*r['real_per_gamma'])
                values=basis.evaluate(np.array([beta(u,k,law) for u in batch]),y)
                for u,matrix in zip(batch,values):
                    if not np.isfinite(matrix).all():raise ArithmeticError('Nonfinite harmonic Gamma')
                    scale=max(float(abs(matrix).max()),np.finfo(float).tiny)
                    herm=float(abs(matrix-matrix.conj().T).max());eig=float(np.linalg.eigvalsh(matrix).min())
                    if herm>1e-12*scale or eig < -plan['gates']['psd_negative_tolerance']:
                        raise ArithmeticError('Harmonic Hermitian/PSD gate failed; no repair')
                    ident=cache_identity(u,k,law,geometry_sha256=plan['geometry_sha256'],source_sha256=source_sha,
                                         resolution={x:r[x] for x in ('name','lmax','nmu')})
                    target=output/(ident['token']+'.npz')
                    with target.open('xb') as stream:np.savez(stream,Gamma=matrix)
                    record=dict(**ident,array_file=str(target),file_sha256=sha(target),
                                array_sha256=__import__('hashlib').sha256(matrix.tobytes()).hexdigest(),
                                minimum_eigenvalue=eig,hermiticity_residual=herm)
                    record_sha=write_json(output/(ident['token']+'.json'),record)
                    saved.append(dict(token=ident['token'],record=str(output/(ident['token']+'.json')),record_sha256=record_sha))
                guard.checkpoint()
        return dict(operation='harmonic',channel=k,resolution=r,saved=saved)
    if request['operation']=='sky':
        from pta.orf import raw_direct_orf
        case=plan['sky_cases'][request['case']];values=[]
        for r in plan['frequencies'][case['channel']-1]['resolutions']:
            args=sky_arguments(case,g,r['nmu']);guard.reserve('sky',args['nmu']*args['nphi'])
            value=complex(raw_direct_orf(**args))
            if not np.isfinite([value.real,value.imag]).all():raise ArithmeticError('Nonfinite direct sky')
            record=dict(arguments=args,value=[value.real,value.imag])
            write_json(output/('sky_'+r['name']+'.json'),record);values.append(value);guard.checkpoint()
        difference=abs(values[1]-values[0])
        if difference>plan['gates']['sky_coarse_fine']:raise ArithmeticError('Independent sky refinement failed')
        return dict(operation='sky',case=case,values=[[z.real,z.imag] for z in values],difference=difference)
    raise ValueError('Unknown response operation')


if __name__=='__main__':
    request=read_json(sys.argv[1]);guard=WorkerBudget(request);result=None;failure=None
    try:result=run(request,guard);guard.checkpoint()
    except BaseException as exc:failure=dict(type=type(exc).__name__,message=str(exc))
    finally:
        write_json(request['receipt'],dict(schema='C11_WORKER_END_v1',request_sha256=sha(sys.argv[1]),
               passed=failure is None,result=result,failure=failure,**guard.report()))
    sys.exit(1 if failure else 0)
