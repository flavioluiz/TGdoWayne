"""Metadata-only node selection and scalar work estimates. No physical calls."""
from pathlib import Path
import hashlib
import json
import math
import numpy as np
from semantics import sky_cases

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
EDGES=[0.,.0001,.001,.01,.05,.25,.5,.75,.9,.99,1.]
TRUTHS=[0.,.0001,.001,.01,.05,.15,.3,.5,.7,.85,.95,.99,.995,.999,.9999,1.]
MODELS=['A0_CN','A_CN','B_CN','C_beta_CN','C_full_CN','A_G','B_G','C_beta_G','C_full_G']


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(65536),b''):h.update(chunk)
    return h.hexdigest()


def rule(order,coordinate):
    x,w=np.polynomial.legendre.leggauss(order);nodes=[];weights=[];panels=[]
    for j,(lo,hi) in enumerate(zip(EDGES[:-1],EDGES[1:])):
        a,b=(math.asin(lo),math.asin(hi)) if coordinate=='alpha' else (lo,hi)
        t=a+(b-a)*(x+1)/2; ww=w*(b-a)/2
        u=np.sin(t) if coordinate=='alpha' else t
        if coordinate=='alpha':ww=ww*np.cos(t)
        nodes.extend(float(v) for v in u); weights.extend(float(v) for v in ww)
        panels.extend([j]*order)
    return dict(order=order,coordinate=coordinate,u=nodes,du_weights=weights,panels=panels)


def frequency(k):
    y=2*math.pi*k*500/4.5;l,n=int(y+100),int(2*y+220)
    rows=[]
    for name,dl,dn in [('coarse',0,0),('fine',40,80)]:
        ll,nn=l+dl,n+dn;B=8;p=16
        memory=8*nn*(ll-1)+8*p*p*(ll-1)+64*nn+16*B*p*nn+96*B*nn+64*B*p*(ll-1)+64*B*p*p
        rows.append(dict(name=name,lmax=ll,nmu=nn,real_per_gamma=2*p*nn*(ll-1),
                         estimated_numeric_bytes=memory,recurrence_elements=nn*(ll-1)))
    return dict(channel=k,maximum_phase=y,resolutions=rows)


def build():
    gp=ROOT/'tmp/c11_execution_design/geometry_candidate.json';g=json.loads(gp.read_text())
    if digest(gp)!='aa0c82276e7baf858d39f22fe0bbbbce212c5784ec547ca3e142987124ead10c':
        raise ValueError('Public geometry metadata changed; require a new prospective plan')
    rules={name:rule(order,coord) for name,order,coord in
           [('alpha32',32,'alpha'),('alpha64',64,'alpha'),('u8',8,'u'),('u16',16,'u')]}
    grid=sorted(set(EDGES+rules['alpha32']['u']+rules['alpha64']['u']))
    universe=sorted(set(grid+TRUTHS+rules['u8']['u']+rules['u16']['u']))
    if len(grid)!=971:raise AssertionError('Unexpected GL node identity')
    frequencies=[frequency(k) for k in range(1,9)]
    probes=[dict(kind=kind,channel=k,u=.5,resolution=level)
            for kind,k in [('subset12',1),('subset12',4),('rotation16',8)] for level in (0,1)]
    probe_real=sum(frequencies[p['channel']-1]['resolutions'][p['resolution']]['real_per_gamma']
                   *(12 if p['kind']=='subset12' else 16)//16 for p in probes)
    costs=[]
    for name,nodes,cpu,output in [('benchmark',TRUTHS,900,32*1024**2),
                                  ('curves',universe,7200,768*1024**2)]:
        n=len(nodes);physical=n*8;cb=(n-1)*7
        real=sum((n if k==1 else 2*n-1)*sum(r['real_per_gamma'] for r in row['resolutions'])
                 for k,row in enumerate(frequencies,1))
        gamma=2*(physical+cb)
        sky=sum(2*sum(r['nmu']**2 for r in frequencies[c['channel']-1]['resolutions']) for c in sky_cases(g))
        # Both levels saved immediately as one small NPZ per canonical response.
        npz_payload=gamma*16*16*16
        # Conservative 4KiB per NPZ+8KiB per identity/report, plus compact products/log reserve.
        out_est=npz_payload+gamma*12288+16*65536+8*1024**2
        # Curves phase uses the reviewed benchmark artifacts. Its job list only
        # contains remaining nodes; these totals deliberately include both phases.
        likelihood=0 if name=='benchmark' else 2*16*9*2*(len(grid)+len(set(TRUTHS)-set(grid)))+18*2*(80+160)
        costs.append(dict(name=name,mass_nodes=n,nodes=nodes,canonical_Gamma_per_level=physical+cb,
            Gamma_evaluations_both_levels=gamma,independent_probe_Gamma=6,
            real_GEMM_multiplications=real+probe_real,probe_real_GEMM_multiplications=probe_real,
            sky_angular_points=sky,maximum_likelihood_values=likelihood,
            cpu_seconds_candidate=cpu,RSS_bytes_candidate=2*1024**3,
            numeric_bytes_candidate=1024**3,maximum_output_bytes_candidate=output,
            output_estimated_bytes=out_est,output_estimate_pass=out_est<=output,
            saved_Gamma_numeric_bytes=npz_payload,maximum_file_bytes_candidate=32*1024**2,
            worker_jobs=dict(harmonic=16,sky=8 if name=='benchmark' else 0,
                             basis_probes=6 if name=='benchmark' else 0,gate=1,generation=0 if name=='benchmark' else 1,
                             likelihood=0 if name=='benchmark' else 1),
            maximum_batch_real_multiplications=max(r['real_per_gamma']*8 for f in frequencies for r in f['resolutions']),
            raw_physical_draws=0 if name=='benchmark' else 16,
            scope='cumulative phase ceiling; dominant GEMM count, not full FLOPs or measured CPU'))
    rows=[dict(id=i,u=u,scenario='strong_red' if i in (6,7,8,13) else 'central',
               eta=[-15.,13/3,-14.7 if i in (6,7,8,13) else -15.5,0.]) for i,u in enumerate(TRUTHS)]
    # Eighteen predetermined pairs cover all nine models in each population.
    references=[dict(population=pop,model=model,datum_id=(2*j+(0 if pop=='P12K4' else 1))%16)
                for pop in ('P12K4','P16K8') for j,model in enumerate(MODELS)]
    return dict(schema='C11_PILOT16_SOURCE_CANDIDATE_v1',execution_enabled=False,
        status='PROSPECTIVE_NO_PHYSICAL_EXECUTION',required_release='v0.10.0',
        required_branch_decision='periodic_simulation_with_public_sky_geometry',
        geometry_path=str(gp.relative_to(ROOT)),geometry_sha256=digest(gp),
        master_seed=9111162026,rows=rows,statistical_truth_draws=0,
        engineering_fixed_truths_excluded_from_SBC=True,models=MODELS,rules=rules,
        grid_nodes=grid,frequencies=frequencies,sky_cases=sky_cases(g),basis_probes=probes,stages=costs,
        reference_pairs=references,reference_cuts=EDGES,
        gates=dict(matrix_coarse_fine=1e-8,sky_coarse_fine=1e-7,sky_harmonic=1e-7,
                   psd_negative_tolerance=1e-12,logL_coarse_fine=.001,
                   logZ_moment_KL_W1=.001,CDF=.002,quantile_width=.001),
        integration_scope='finite fixed-cut alpha32/64 versus exact-response u8/16; not complete CDF/quantile/event validation',
        blocked_functional_products=['quantile brackets lack independent endpoint integrals',
             'logL-PIT event crossing and ambiguous-mass engine not integrated',
             'fixed-cut/u8-u16 controls may fail; no automatic refinement or replacement seeds'],
        physical_execution_authorization=None,benchmark_receipt_required_before_curves=True,
        main500_execution_supported=False)


if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    plan=build()
    with args.output.open('x') as stream:json.dump(plan,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'status':plan['status'],'stages':[{k:v for k,v in s.items() if k not in ('nodes',)} for s in plan['stages']]}))
