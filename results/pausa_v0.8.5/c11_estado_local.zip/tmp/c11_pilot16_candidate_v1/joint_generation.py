"""Joint P12K4 subset of P16K8. Imports and draws are explicit and local."""
import hashlib
import json
from pathlib import Path
import numpy as np
from pta.statistics import angular_estimators, quadratic_statistics
from pta.simulation import JULIAN_YEAR_SECONDS, residual_power_spectrum
from coupled_gaussian import HermitianControlFactors, embed_estimators


def public_experiments(g):
    """Only public direction metadata and declared synthetic distance/noise."""
    points=np.array([p['unit_direction'] for p in g['selected']],float)
    sigma=np.array(g['synthetic_nominal_TOA_sigma_seconds'],float)
    distance=np.array(g['synthetic_distance_light_years'],float)
    red=np.array(g['synthetic_red_noise_multipliers'],float)
    if points.shape!=(16,3) or any(x.shape!=(16,) for x in (sigma,distance,red)):
        raise ValueError('Frozen P16 metadata required')
    T=4.5*JULIAN_YEAR_SECONDS
    dt=T/int(np.ceil(T/(14*86400.))); f=np.arange(1,9)/T
    scale=residual_power_spectrum(f,-14.7,13/3)+2*np.median(sigma)**2*dt
    result={}
    for p,k in [(12,4),(16,8)]:
        h=angular_estimators(points[:p],sigma[:p],cross_bins=4,auto_bins=2)
        result[f'P{p}K{k}']=dict(points=points[:p],sigma=sigma[:p],distance_ly=distance[:p],
             red=red[:p],T=T,dt=dt,f=f[:k],scale=scale[:k],H=h.matrices,
             H_metadata=h.metadata,weights=np.full(k,1/k))
    if not np.array_equal(result['P12K4']['scale'],result['P16K8']['scale'][:4]):
        raise AssertionError('Scale must retain the full16 median')
    return result


def joint_from_latents(covariance, h12, h16, z, v):
    """Pure algebra; z standard proper-CN, v independent standard-real latents."""
    c=np.asarray(covariance)
    if c.shape!=(8,16,16) or np.shape(z)!=(8,16) or np.shape(v)!=(8,256):
        raise ValueError('Production joint shapes are fixed P16K8')
    if not np.isfinite(c).all() or not np.isfinite(z).all() or not np.isfinite(v).all():
        raise ValueError('Finite inputs required')
    factor=np.linalg.cholesky(c)
    q=np.einsum('kab,kb->ka',factor,z,optimize=True)
    hh=np.concatenate([embed_estimators(h12,16,np.arange(12)),h16])
    controls=HermitianControlFactors(c,hh,maximum_numeric_bytes=32*1024**2)
    y=controls.apply(np.asarray(v)[None])[0]
    out=dict(q16=q,q12=q[:4,:12].copy(),
         x16=quadratic_statistics(q,h16),x12=quadratic_statistics(q[:4,:12],h12),
         g16=y[:,len(h12):].copy(),g12=y[:4,:len(h12)].copy())
    if not np.array_equal(out['q12'],out['q16'][:4,:12]):
        raise AssertionError('Nested CN data changed')
    return out


def draw_joint(covariance,h12,h16,*,datum_id,master_seed,persist_before,persist_after):
    """The callback must durably save every initial RNG state before any draw.

    It is forbidden to recover a failed ID by assigning a new seed. No truth RNG:
    all 16 engineering masses are prospective fixed anchors, outside SBC.
    """
    if type(datum_id)is not int or not 0<=datum_id<16 or type(master_seed)is not int:
        raise ValueError('Frozen engineering ID and seed required')
    streams={}
    for bank in (1,2):
        for k in range(1,9):
            ss=np.random.SeedSequence([master_seed,11,datum_id,bank,k])
            streams[f'{bank}:{k}']=np.random.Generator(np.random.PCG64(ss))
    before={name:rng.bit_generator.state for name,rng in streams.items()}
    persist_before(dict(schema='C11_RNG_BEFORE_v1',datum_id=datum_id,
                        recipe=[master_seed,11,datum_id,'bank','physical_channel'],states=before))
    z=np.empty((8,16),complex);v=np.empty((8,256))
    for k in range(1,9):
        rng=streams[f'1:{k}']
        z[k-1]=(rng.standard_normal(16)+1j*rng.standard_normal(16))/np.sqrt(2)
        v[k-1]=streams[f'2:{k}'].standard_normal(256)
    persist_after(dict(schema='C11_RNG_AFTER_v1',datum_id=datum_id,
                       states={name:rng.bit_generator.state for name,rng in streams.items()}))
    return joint_from_latents(covariance,h12,h16,z,v)
