"""Bounded exact-node reader; no spline, implicit mass tolerance or cache credit."""
from pathlib import Path
import hashlib
import zipfile
import numpy as np
from io_contract import read_json,sha
from semantics import cache_identity


class ResponseCache:
    def __init__(self,plan,manifest_sha,records):
        self.plan=plan;self.manifest_sha=manifest_sha;self.records={}
        for binding in records:
            path=binding['path']
            if sha(path)!=binding['sha256']:raise ValueError('Response identity receipt changed')
            r=read_json(path,16384)
            if sha(path)!=binding['sha256']:raise ValueError('Response identity changed during read')
            if r['token'] in self.records:raise ValueError('Duplicate canonical response cache')
            self.records[r['token']]=r
    def matrix(self,u,channel,law,level):
        k=1 if law=='C_full' else channel
        r=self.plan['frequencies'][k-1]['resolutions'][level]
        identity=cache_identity(u,channel,law,geometry_sha256=self.plan['geometry_sha256'],
            source_sha256=self.manifest_sha,resolution={x:r[x] for x in ('name','lmax','nmu')})
        record=self.records[identity['token']]
        if record['identity']!=identity['identity']:raise ValueError('Response cache identity mismatch')
        p=Path(record['array_file'])
        if p.stat().st_size>8192 or sha(p)!=record['file_sha256']:raise ValueError('Gamma artifact SHA/size')
        with zipfile.ZipFile(p) as z:
            if z.namelist()!=['Gamma.npy'] or z.infolist()[0].file_size>8192:raise ValueError('Gamma ZIP contract')
        with np.load(p,allow_pickle=False) as z:matrix=z['Gamma']
        if matrix.shape!=(16,16) or matrix.dtype!=np.dtype('complex128') or not np.isfinite(matrix).all():
            raise ValueError('Gamma shape/dtype/finite contract')
        if hashlib.sha256(matrix.tobytes()).hexdigest()!=record['array_sha256'] or sha(p)!=record['file_sha256']:
            raise ValueError('Gamma array SHA or post-read file change')
        return matrix
    def stack(self,nodes,law,level,population):
        p,k=(12,4) if population=='P12K4' else (16,8) if population=='P16K8' else (0,0)
        if p==0:raise ValueError('Explicit nested population required')
        if len(nodes)>8:raise ValueError('Eight-node controlled workspace')
        return np.array([[self.matrix(u,c,law,level)[:p,:p] for c in range(1,k+1)] for u in nodes])
