"""New tiny deterministic fixtures only. No public-response ORF, PTA LL or draws."""
import json
import math
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
for relative in ('src','tmp/c11_coupling_v2','tmp/c09_D2_components_v1'):
    sys.path.insert(0,str(ROOT/relative))
from semantics import beta,canonical_response,cache_identity,sky_cases,sky_arguments
from planning import build,rule,digest
from joint_generation import public_experiments,joint_from_latents,draw_joint
from model_routes import covariance_for_gamma,score,MODELS,response_law
from batch_likelihood import NamedLedger
from pta.statistics import quadratic_statistics,quadratic_moments,compress_independent_moments
from finite_assessment import summarize,compare
from io_contract import write_json,read_json
from io_contract import WorkerBudget
from run_candidate import authorization


class CandidateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.g=json.loads((ROOT/'tmp/c11_execution_design/geometry_candidate.json').read_text())
        cls.plan=build();cls.exp=public_experiments(cls.g)

    def test_k8_semantics_and_exact_aliases(self):
        self.assertAlmostEqual(beta(1,8,'B'),math.sqrt(63/64))
        self.assertEqual(beta(1,8,'C_beta'),0.)
        common=dict(geometry_sha256='toyG',source_sha256='toyS',resolution={'lmax':3,'nmu':8})
        token=lambda u,k,law:cache_identity(u,k,law,**common)['token']
        self.assertEqual(token(.4,1,'B'),token(.4,8,'C_full'))
        self.assertEqual(token(.4,1,'B'),token(.4,1,'C_beta'))
        self.assertEqual(token(0.,8,'B'),token(0.,8,'C_beta'))
        self.assertNotEqual(token(.4,8,'B'),token(.4,8,'C_beta'))
        self.assertNotEqual(token(.4,4,'B'),token(.4,8,'B'))
        for case in sky_cases(self.g):
            args=sky_arguments(case,self.g,8)
            self.assertEqual(args['beta'],beta(case['u'],case['channel'],case['law']))
            self.assertEqual(args['nphi'],16)
            self.assertAlmostEqual(args['ya'],2*math.pi*case['channel']*self.g['synthetic_distance_light_years'][case['pair'][0]]/4.5)
        self.assertEqual(sum(c['channel']==8 for c in sky_cases(self.g)),6)

    def test_public_scale_and_nested_algebra(self):
        e12,e16=self.exp['P12K4'],self.exp['P16K8']
        self.assertTrue(np.array_equal(e12['scale'],e16['scale'][:4]))
        c=np.array([np.diag(1+np.arange(16)/32+k/16) for k in range(8)],complex)
        z=(np.arange(128).reshape(8,16)/128+1j*np.arange(128,256).reshape(8,16)/256)
        v=np.arange(2048).reshape(8,256)/2048-.5
        value=joint_from_latents(c,e12['H'],e16['H'],z,v)
        self.assertTrue(np.array_equal(value['q12'],value['q16'][:4,:12]))
        self.assertTrue(np.array_equal(value['x12'],quadratic_statistics(value['q16'][:4,:12],e12['H'])))
        # A deterministic Hermitian W reference checks the complete joint map.
        L=np.linalg.cholesky(c);W=np.zeros((8,16,16),complex);ii,jj=np.triu_indices(16,1)
        W[:,np.arange(16),np.arange(16)]=v[:,:16]
        W[:,ii,jj]=(v[:,16:136]+1j*v[:,136:])/np.sqrt(2)
        W[:,jj,ii]=W[:,ii,jj].conj()
        for e,suffix,k,p in [(e12,'12',4,12),(e16,'16',8,16)]:
            random_cov=L@(np.eye(16)[None]+W)@L.conj().swapaxes(-1,-2)
            ref=np.einsum('dab,kba->kd',e['H'],random_cov[:k,:p,:p]).real
            np.testing.assert_allclose(value['g'+suffix],ref,rtol=3e-13,atol=2e-14)

    def test_rng_before_any_draw_and_distinct_banks(self):
        calls=[];seeds=[]
        class ToyGenerator:
            def __init__(self,bitgen):self.bit_generator=bitgen
            def standard_normal(self,n):calls.append(n);return np.linspace(-.3,.4,n)
        e=self.exp;cov=np.broadcast_to(np.eye(16),(8,16,16)).copy()
        def reject(state):
            self.assertEqual(calls,[]);self.assertEqual(len(state['states']),16)
            raise RuntimeError('Durable before-state failed')
        with patch('numpy.random.Generator',ToyGenerator):
            with self.assertRaises(RuntimeError):draw_joint(cov,e['P12K4']['H'],e['P16K8']['H'],datum_id=0,
                     master_seed=123,persist_before=reject,persist_after=lambda _:None)
        self.assertEqual(calls,[])
        captured=[]
        with patch('numpy.random.Generator',ToyGenerator):
            draw_joint(cov,e['P12K4']['H'],e['P16K8']['H'],datum_id=0,master_seed=123,
                       persist_before=lambda x:captured.append(x),persist_after=lambda x:captured.append(x))
        self.assertEqual(calls,[16,16,256]*8)
        states=captured[0]['states'];self.assertEqual(len({json.dumps(s,sort_keys=True) for s in states.values()}),16)

    def test_nine_routes_reference_and_scientific_counts(self):
        # Identity response is a TOY covariance input, never a public sky response.
        e=self.exp['P12K4'];g=np.broadcast_to(np.eye(12),(2,4,12,12)).copy().astype(complex)
        eta=[-15.,13/3,-15.5,0.];cov=covariance_for_gamma(g,e,eta)
        q=np.full((2,4,12),.01+.02j);x=quadratic_statistics(q,e['H'])
        data=dict(q=q,x=x,g=x+.001);ledger=NamedLedger(global_cap=100,per_curve_cap=10,per_data_cap=100)
        for model in MODELS:
            values=score(model,g,e,eta,data,datum_ids=['toy0','toy1'],ledger=ledger)
            if model=='A0_CN':
                expected=[]
                for c in cov:
                    expected.append([-4*12*math.log(math.pi)-sum(np.linalg.slogdet(v)[1] for v in c)
                                      -sum(np.vdot(v,np.linalg.solve(m,v)).real for v,m in zip(obs,c)) for obs in q])
                np.testing.assert_allclose(values,expected,rtol=2e-14)
            else:
                mu,var=quadratic_moments(cov,e['H']);obs=data['g' if model.endswith('_G') else 'x']
                if model not in ('A_CN','A_G'):
                    mu,var=compress_independent_moments(mu,var,e['weights']);mu=mu[:,None];var=var[:,None]
                    obs=np.einsum('k,rkd->rd',e['weights'],obs)[:,None]
                expected=[]
                for mean,variance in zip(mu,var):
                    expected.append([sum(-.5*(len(m)*math.log(2*math.pi)+np.linalg.slogdet(c)[1]
                      +(y-m)@np.linalg.solve(c,y-m)) for y,m,c in zip(o,mean,variance)) for o in obs])
                np.testing.assert_allclose(values,expected,rtol=2e-13,atol=1e-8)
        self.assertEqual(ledger.total,36)
        self.assertEqual(response_law('C_beta_G'),'C_beta');self.assertEqual(response_law('C_full_CN'),'C_full')

    def test_positive_measure_fixed_cuts_and_unresolved_flags(self):
        a=rule(8,'u');b=rule(16,'u')
        aa=summarize(a,np.array(a['u']));bb=summarize(b,np.array(b['u']))
        self.assertAlmostEqual(bb['logZ'],math.log(math.expm1(1)),places=13)
        for cut,value in zip(self.plan['reference_cuts'],bb['CDF_at_panel_edges']):
            self.assertAlmostEqual(value,math.expm1(cut)/math.expm1(1),places=13)
        result=compare(aa,bb,self.plan['gates']);self.assertTrue(result['passed'])
        self.assertEqual(result['logL_PIT_interval'],[0.,1.]);self.assertTrue(result['quantiles_not_validated'])

    def test_counts_shape_and_nooverwrite(self):
        bench,curves=self.plan['stages'];self.assertEqual(len(self.plan['grid_nodes']),971)
        self.assertEqual(bench['canonical_Gamma_per_level'],16*8+15*7)
        self.assertEqual(bench['Gamma_evaluations_both_levels'],466)
        self.assertEqual(bench['sky_angular_points'],3157467488)
        self.assertEqual(len(self.plan['reference_pairs']),18)
        self.assertTrue(all(s['output_estimate_pass'] for s in self.plan['stages']))
        # Protect the advanced-index assignment used for batched observations.
        a=np.full((2,5,16),np.nan);ids=[2,5,7];v=np.arange(9).reshape(3,3)
        a[1,1:4,ids]=v.T
        for j,i in enumerate(ids):np.testing.assert_array_equal(a[1,1:4,i],v[:,j])
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'receipt.json';write_json(path,{'toy':True})
            with self.assertRaises(FileExistsError):write_json(path,{'toy':False})
            self.assertEqual(read_json(path),{'toy':True})

    def test_guards_without_physical_worker(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);plan=root/'plan.json';auth=root/'auth.json';manifest=root/'manifest.json'
            write_json(plan,{'execution_enabled':False});write_json(auth,{'authorized':False});write_json(manifest,{})
            with self.assertRaises(ValueError):authorization(auth,'benchmark',plan,manifest)
            budget=WorkerBudget(dict(output=str(root),caps=dict(cpu=15,rss=128*1024**2,output=1024**2,real=10,sky=20,LL=0)))
            budget.reserve('real',10)
            with self.assertRaises(RuntimeError):budget.reserve('real',1)
            with self.assertRaises(RuntimeError):budget.reserve('LL',1)
            self.assertEqual(budget.counts,dict(real=10,sky=0,LL=0))


if __name__=='__main__':unittest.main()
