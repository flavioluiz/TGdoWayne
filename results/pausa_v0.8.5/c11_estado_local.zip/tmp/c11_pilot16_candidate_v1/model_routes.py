"""Nine normalized C11 conditional curves; observations never regenerated for C."""
import numpy as np
from inference.model import covariance_batch
from pta.statistics import quadratic_moments,compress_independent_moments,compress_frequencies
from batch_likelihood import cn_logpdf,normal_logpdf,NamedLedger

MODELS=('A0_CN','A_CN','B_CN','C_beta_CN','C_full_CN','A_G','B_G','C_beta_G','C_full_G')


def covariance_for_gamma(gamma,exp,eta):
    g=np.asarray(gamma)
    if g.ndim!=4 or g.shape[1:]!=(len(exp['f']),len(exp['points']),len(exp['points'])):
        raise ValueError('Explicit node/frequency/pulsar response axes required')
    zero=np.zeros(g.shape[1:],complex)
    noise,weights=covariance_batch(np.asarray(eta)[None],zero,exp)
    return weights[0,:,0][None,:,None,None]*g+noise[0]


def score(model,gamma,exp,eta,data,*,datum_ids,ledger):
    if model not in MODELS:raise ValueError('Unknown model')
    g=np.asarray(gamma)
    if g.ndim!=4 or g.shape[1:]!=(len(exp['f']),len(exp['points']),len(exp['points'])):
        raise ValueError('Explicit node/frequency/pulsar response axes required')
    # The caller provides exactly the law requested; no response interpolation.
    cov=covariance_for_gamma(g,exp,eta)
    targets=[(str(i),model) for i in datum_ids]
    reserve=lambda work:ledger.reserve(work,targets)
    if model=='A0_CN':return cn_logpdf(cov,data['q'],reserve=reserve)[0]
    mean,var=quadratic_moments(cov,exp['H'])
    y=data['g'] if model.endswith('_G') else data['x']
    if model in ('A_CN','A_G'):
        return normal_logpdf(mean,var,y,reserve=reserve)[0]
    mean,var=compress_independent_moments(mean,var,exp['weights'])
    y=compress_frequencies(y,exp['weights'])
    return normal_logpdf(mean[:,None],var[:,None],y[:,None],reserve=reserve)[0]


def response_law(model):
    if model not in MODELS:raise ValueError('Unknown model')
    return 'C_beta' if model.startswith('C_beta') else 'C_full' if model.startswith('C_full') else 'B'
