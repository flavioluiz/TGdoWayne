"""Small stdlib transport primitives. No overwrite, no automatic continuation."""
from pathlib import Path
import hashlib
import json
import os
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[2]


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(65536),b''):h.update(block)
    return h.hexdigest()


def read_json(path,maximum=32*1024**2):
    path=Path(path)
    if path.stat().st_size>maximum:raise ValueError('Input exceeds explicit byte cap')
    with path.open() as f:return json.load(f)


def write_json(path,value):
    data=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    path=Path(path)
    with path.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    return sha(path)


def rss_bytes(usage):
    return int(usage.ru_maxrss*(1 if sys.platform=='darwin' else 1024))


def usage():
    a=resource.getrusage(resource.RUSAGE_SELF);b=resource.getrusage(resource.RUSAGE_CHILDREN)
    return dict(cpu_seconds=a.ru_utime+a.ru_stime+b.ru_utime+b.ru_stime,
                rss_parent_bytes=rss_bytes(a),rss_child_max_bytes=rss_bytes(b),
                rss_sum_of_maxima_bytes=rss_bytes(a)+rss_bytes(b))


def bytes_under(path):
    return sum(p.stat().st_size for p in Path(path).rglob('*') if p.is_file())


def verify_bindings(manifest):
    for relative,record in manifest['bindings'].items():
        p=(ROOT/relative).resolve()
        if not p.is_relative_to(ROOT) or p.stat().st_size!=record['bytes'] or sha(p)!=record['sha256']:
            raise ValueError('Input/source binding changed: '+relative)


def verify_worker_request(request):
    from run_candidate import authorization
    auth_path=ROOT/request['root_authorization']
    if sha(auth_path)!=request['root_authorization_sha256']:raise ValueError('Worker authorization SHA')
    auth=authorization(auth_path,request['stage'],ROOT/request['plan'],ROOT/request['manifest'])
    root=Path(auth['output_path']).resolve()
    if not Path(request['output']).resolve().is_relative_to(root):raise ValueError('Worker destination outside authorized phase')
    plan=read_json(ROOT/request['plan']);stage=next(s for s in plan['stages'] if s['name']==request['stage'])
    maximum=dict(cpu=stage['cpu_seconds_candidate'],rss=stage['RSS_bytes_candidate'],
                 numeric=stage['numeric_bytes_candidate'],output=stage['maximum_output_bytes_candidate'],
                 real=stage['real_GEMM_multiplications'],sky=stage['sky_angular_points'],LL=stage['maximum_likelihood_values'])
    if set(request['caps'])!=set(maximum) or any(type(value)not in (int,float) or not 0<=value<=maximum[key]
             for key,value in request['caps'].items()):raise ValueError('Worker cap enlargement or malformed caps')
    if request['stage']=='benchmark' and request['operation'] in ('generation','likelihood'):
        raise ValueError('Benchmark cannot draw or evaluate likelihood')
    op=request['operation']
    if op=='harmonic':
        if type(request['channel'])is not int or not 1<=request['channel']<=8 or request['resolution']not in (0,1):
            raise ValueError('Explicit physical channel/resolution')
        nodes=request['nodes']
        if not nodes or nodes!=sorted(set(nodes)) or any(u not in stage['nodes'] for u in nodes):
            raise ValueError('Only frozen phase mass nodes, with no duplicate work')
    elif op=='sky':
        if type(request['case'])is not int or not 0<=request['case']<len(plan['sky_cases']):raise ValueError('Frozen sky case')
    elif op=='basis_probe':
        if type(request['probe'])is not int or not 0<=request['probe']<len(plan['basis_probes']):raise ValueError('Frozen basis probe')
    elif op not in ('gate','generation','likelihood'):raise ValueError('Unknown operation')


class WorkerBudget:
    def __init__(self,request):
        self.request=request;self.counts={'real':0,'sky':0,'LL':0};self.output=Path(request['output'])
        self.started=time.monotonic()
    def checkpoint(self):
        u=usage();caps=self.request['caps']
        if u['cpu_seconds']>caps['cpu'] or u['rss_parent_bytes']>caps['rss']:
            raise RuntimeError('Worker CPU/RSS cap')
        if bytes_under(self.output)>caps['output']:raise RuntimeError('Worker output cap')
    def reserve(self,kind,count):
        if kind not in self.counts or type(count)is not int or count<0:raise ValueError('Explicit work count')
        self.checkpoint()
        if self.counts[kind]+count>self.request['caps'][kind]:raise RuntimeError(kind+' reservation cap')
        self.counts[kind]+=count
    def report(self):
        return dict(counts=self.counts,resources=usage(),wall_seconds=time.monotonic()-self.started)
