"""Close metadata/source bindings. No physical simulation or authorization."""
from pathlib import Path
import importlib.metadata
import json
import sys
from planning import build,digest,ROOT,HERE

DEPENDENCIES=[
 'tmp/c11_execution_design/PROTOCOLO_CANDIDATO.md','tmp/c11_execution_design/config_candidata.json',
 'tmp/c11_execution_design/preflight_costs.json','tmp/c11_execution_design/preflight_costs.py',
 'tmp/c11_execution_design/geometry_candidate.json','tmp/c11_execution_design/prepare_geometry.py',
 'tmp/c11_coupling_v2/coupled_gaussian.py','tmp/c11_coupling_v2/preflight.json',
 'tmp/c11_coupling_v2/validation.json','tmp/c11_feasibility/PARECER_C11.md',
 'implementation_plan/commits/C11_aplicacao.md',
 'tmp/c09_D2_components_v1/batch_likelihood.py','tmp/c09_D2_components_v1/manifest.json',
 'tmp/c09_D2_components_v1/toy_attempt4/validation.json',
 'src/inference/__init__.py','src/inference/model.py','src/inference/orf_blas.py',
 'src/inference/orf_backend.py','src/pta/__init__.py','src/pta/_domain.py',
 'src/pta/statistics.py','src/pta/simulation.py','src/pta/response.py','src/pta/orf.py','src/pta/validation.py',
 'tmp/c07_orf_efficiency/results/benchmark.json']


def main():
    for file in HERE.glob('*.py'):compile(file.read_text(),str(file),'exec')
    plan=build()
    deps={p:dict(sha256=digest(ROOT/p),bytes=(ROOT/p).stat().st_size) for p in DEPENDENCIES}
    plan['dependency_bindings']=deps
    plan['environment_versions']={name:importlib.metadata.version(name) for name in ('numpy','scipy')}
    plan['environment_versions']['python']=sys.version.split()[0]
    with (HERE/'preflight.json').open('x') as f:json.dump(plan,f,indent=2,allow_nan=False);f.write('\n')
    files=list(HERE.glob('*.py'))+[HERE/'PREFLIGHT.md',HERE/'README.md',HERE/'preflight.json',HERE/'toy_attempt2/result.json']
    bindings={str(p.relative_to(ROOT)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in files}
    bindings.update(deps)
    manifest=dict(schema='C11_PILOT16_CANDIDATE_CLOSURE_v1',status='FROZEN_FOR_ROOT_REVIEW_NOT_EXECUTION',
                  bindings=bindings,bound_files=len(bindings),bound_bytes=sum(x['bytes'] for x in bindings.values()),
                  physical_ORF=0,physical_logL=0,physical_draws=0,
                  authorized=False,main500_supported=False)
    with (HERE/'manifest.json').open('x') as f:json.dump(manifest,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps(dict(preflight_sha256=digest(HERE/'preflight.json'),manifest_sha256=digest(HERE/'manifest.json'),
                          bindings=len(bindings),stages=[{k:v for k,v in row.items() if k!='nodes'} for row in plan['stages']])))


if __name__=='__main__':main()
