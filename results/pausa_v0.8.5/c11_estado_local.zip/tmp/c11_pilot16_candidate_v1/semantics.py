"""Explicit C11 response semantics; no quadrature, likelihood or random draw."""
import hashlib
import json
import math


def canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def beta(u, channel, law):
    if type(channel) is not int or not 1 <= channel <= 8:
        raise ValueError('Physical channel must be the explicit integer 1..8')
    if type(u) not in (int, float) or not math.isfinite(u) or not 0 <= u <= 1:
        raise ValueError('Finite mass ratio u in [0,1] required')
    if law not in ('B', 'C_beta'):
        raise ValueError('C_full is an explicit alias to B channel1, not a beta law')
    v = float(u) / (channel if law == 'B' else 1)
    return math.sqrt((1-v)*(1+v))


def canonical_response(u, channel, law):
    beta(u, channel, 'B' if law == 'C_full' else law)
    if law == 'C_full':
        return dict(u_hex=float(u).hex(), channel=1, law='B')
    # Equality is analytic only at k=1 or exactly u=0. Never tolerance-based.
    if law == 'C_beta' and (channel == 1 or u == 0):
        law = 'B'
    return dict(u_hex=float(u).hex(), channel=channel, law=law)


def cache_identity(u, channel, law, *, geometry_sha256, source_sha256, resolution):
    request = dict(u_hex=float(u).hex(), channel=channel, law=law)
    canonical = canonical_response(u, channel, law)
    payload = dict(schema='C11_EXACT_GAMMA_ID_v1', response=canonical,
                   geometry_sha256=geometry_sha256, source_sha256=source_sha256,
                   resolution=resolution, phase='y_k=2*pi*k*distance_ly/4.5',
                   normalization='raw_finite_pulsar_TT_3_over_32', dtype='<c16', shape=[16,16])
    return dict(token=hashlib.sha256(canonical_json(payload)).hexdigest(),
                identity=payload, requested=request, alias=request != canonical)


def sky_cases(geometry):
    p = [row['unit_direction'] for row in geometry['selected']]
    pairs = [(sum(a*b for a,b in zip(p[i],p[j])),i,j)
             for i in range(16) for j in range(i+1,16)]
    nearest = max(pairs, key=lambda r: (r[0],-r[1],-r[2]))[1:]
    farthest = min(pairs, key=lambda r: (r[0],r[1],r[2]))[1:]
    auto = max(range(12,16), key=lambda i: (geometry['synthetic_distance_light_years'][i],-i))
    result = []
    for channel, law, cases in [(1,'B',[(.5,nearest),(.995,farthest)]),
                               (8,'B',[(.5,nearest),(.995,farthest),(1.,(auto,auto))]),
                               (8,'C_beta',[(.5,nearest),(.995,farthest),(1.,(auto,auto))])]:
        for u, pair in cases:
            result.append(dict(id=len(result),channel=channel,law=law,u=u,
                               pair=list(pair),beta=beta(u,channel,law)))
    return result


def sky_arguments(case, geometry, nmu):
    if type(nmu) is not int or nmu < 2:
        raise ValueError('Explicit angular resolution required')
    a,b = case['pair']; p=geometry['selected']; d=geometry['synthetic_distance_light_years']
    cosine = sum(x*y for x,y in zip(p[a]['unit_direction'],p[b]['unit_direction']))
    if not -1-1e-12 <= cosine <= 1+1e-12:
        raise ValueError('Unit-vector cosine invalid')
    k=case['channel']
    return dict(beta=beta(case['u'],k,case['law']), cosine=max(-1.,min(1.,cosine)),
                ya=2*math.pi*k*d[a]/4.5, yb=2*math.pi*k*d[b]/4.5,
                nmu=nmu,nphi=2*nmu)
