"""Fresh small post-response process. No basis survives into draws/likelihoods."""
import sys
from pathlib import Path
from io_contract import ROOT,read_json,write_json,sha,verify_bindings,verify_worker_request,WorkerBudget


def run(request,guard):
    verify_worker_request(request)
    for relative in ['src','tmp/c11_coupling_v2','tmp/c09_D2_components_v1']:
        sys.path.insert(0,str(ROOT/relative))
    import numpy as np
    from cache_reader import ResponseCache
    from joint_generation import public_experiments,draw_joint
    from model_routes import covariance_for_gamma,score,response_law
    from batch_likelihood import NamedLedger
    from finite_assessment import summarize,compare
    plan=read_json(ROOT/request['plan']);manifest=read_json(ROOT/request['manifest']);verify_bindings(manifest)
    output=Path(request['output']);output.mkdir(exist_ok=False)
    cache=ResponseCache(plan,sha(ROOT/request['manifest']),read_json(request['cache_index'])['records'])
    experiments=public_experiments(read_json(ROOT/plan['geometry_path']))
    if request['operation']=='gate':
        from pta.orf import gr_auto_exact,threshold_full
        maximum=0.;sky_max=0.;analytic_max=0.;probe_max=0.
        for u in request['nodes']:
            for law in ('B','C_beta'):
                a=cache.stack([u],law,0,'P16K8');b=cache.stack([u],law,1,'P16K8')
                maximum=max(maximum,float(abs(a-b).max()))
            guard.checkpoint()
        for k in range(1,9):
            phase=2*np.pi*k*np.asarray(experiments['P16K8']['distance_ly'])/4.5
            m=cache.matrix(0.,k,'B',1)
            analytic_max=max(analytic_max,max(abs(m[j,j]-gr_auto_exact(float(y))) for j,y in enumerate(phase)))
            m=cache.matrix(1.,k,'C_beta',1);points=experiments['P16K8']['points']
            for a in range(16):
                for b in range(16):
                    cosine=max(-1.,min(1.,float(np.dot(points[a],points[b]))))
                    analytic_max=max(analytic_max,abs(m[a,b]-threshold_full(cosine,float(phase[a]),float(phase[b]))))
        for path in request['probe_receipts']:
            receipt=read_json(path)['result'];probe=receipt['probe']
            if sha(receipt['path'])!=receipt['sha256']:raise ValueError('Probe artifact SHA')
            with np.load(receipt['path'],allow_pickle=False) as z:matrix=z['Gamma']
            size=12 if probe['kind']=='subset12' else 16
            baseline=cache.matrix(probe['u'],probe['channel'],'B',probe['resolution'])[:size,:size]
            probe_max=max(probe_max,float(abs(matrix-baseline).max()))
        for path in request['sky_receipts']:
            receipt=read_json(path);case=receipt['result']['case']
            a,b=case['pair'];fine=cache.matrix(case['u'],case['channel'],case['law'],1)
            direct=complex(*receipt['result']['values'][1]);sky_max=max(sky_max,abs(direct-fine[a,b]))
        if (maximum>plan['gates']['matrix_coarse_fine'] or sky_max>plan['gates']['sky_harmonic']
            or analytic_max>plan['gates']['sky_harmonic'] or probe_max>1e-10):
            raise ArithmeticError('Response or independent-sky gate failed')
        return dict(maximum_matrix_coarse_fine=maximum,maximum_harmonic_sky=sky_max,
                    maximum_analytic_endpoint_error=analytic_max,maximum_subset_rotation_error=probe_max,
                    scope='finite frozen nodes and eight sparse sky cases')
    if request['operation']=='generation':
        records=[];e=experiments['P16K8']
        for row in plan['rows']:
            i=row['id'];gamma=cache.stack([row['u']],'B',1,'P16K8')
            covariance=covariance_for_gamma(gamma,e,row['eta'])[0]
            data=draw_joint(covariance,experiments['P12K4']['H'],e['H'],datum_id=i,
              master_seed=plan['master_seed'],
              persist_before=lambda state:write_json(output/f'rng_before_{i:02d}.json',state),
              persist_after=lambda state:write_json(output/f'rng_after_{i:02d}.json',state))
            path=output/f'datum_{i:02d}.npz'
            with path.open('xb') as f:np.savez(f,**data)
            record=dict(id=i,u=row['u'],eta=row['eta'],path=str(path),sha256=sha(path),
                 rng_before_sha256=sha(output/f'rng_before_{i:02d}.json'),rng_after_sha256=sha(output/f'rng_after_{i:02d}.json'))
            write_json(output/f'datum_{i:02d}.json',record);records.append(record);guard.checkpoint()
        return dict(data=records,engineering_joint_realizations=16,SBC_realizations=0)
    if request['operation']!='likelihood':raise ValueError('Unknown analysis operation')
    receipt=read_json(request['generation_receipt']);data={}
    for record in receipt['result']['data']:
        path=Path(record['path'])
        if path.stat().st_size>65536 or sha(path)!=record['sha256']:raise ValueError('Data SHA/size')
        with np.load(path,allow_pickle=False) as z:data[record['id']]={k:z[k] for k in z.files}
        if sha(path)!=record['sha256']:raise ValueError('Data changed during read')
    class Ledger:
        def __init__(self):self.named=NamedLedger(global_cap=request['caps']['LL'],per_curve_cap=6000,per_data_cap=100000)
        def reserve(self,work,targets):
            guard.reserve('LL',work.normalized_log_likelihood_values);self.named.reserve(work,targets)
    ledger=Ledger();tables={};records=[]
    nodes=sorted(set(plan['grid_nodes']+[r['u'] for r in plan['rows']]))
    reference={(r['population'],r['model']):r['datum_id'] for r in plan['reference_pairs']}
    for pop,e in experiments.items():
        suffix='12' if pop=='P12K4' else '16'
        for model in plan['models']:
            arrays=np.empty((2,len(nodes),16));oracle=np.empty((2,240))
            for level in (0,1):
                for scenario in ('central','strong_red'):
                    rows=[r for r in plan['rows'] if r['scenario']==scenario];ids=[r['id'] for r in rows]
                    observed={key:np.array([data[i][key+suffix] for i in ids]) for key in ('q','x','g')}
                    for start in range(0,len(nodes),8):
                        batch=nodes[start:start+8];gamma=cache.stack(batch,response_law(model),level,pop)
                        values=score(model,gamma,e,rows[0]['eta'],observed,
                               datum_ids=[f'{pop}:{i}' for i in ids],ledger=ledger)
                        arrays[level,start:start+len(batch),ids]=values.T
                        guard.checkpoint()
                datum=reference[(pop,model)];row=plan['rows'][datum]
                observed={key:data[datum][key+suffix][None] for key in ('q','x','g')}
                oracle_nodes=plan['rules']['u8']['u']+plan['rules']['u16']['u']
                for start in range(0,240,8):
                    batch=oracle_nodes[start:start+8];gamma=cache.stack(batch,response_law(model),level,pop)
                    oracle[level,start:start+len(batch)]=score(model,gamma,e,row['eta'],observed,
                           datum_ids=[f'{pop}:{datum}'],ledger=ledger)[:,0]
                    guard.checkpoint()
            path=output/f'{pop}_{model}.npz'
            with path.open('xb') as f:np.savez(f,u=np.array(nodes),logL=arrays,reference_logL=oracle)
            index={float(u).hex():i for i,u in enumerate(nodes)};results=[]
            for row in plan['rows']:
                summaries={name:summarize(rule,arrays[1,[index[float(u).hex()] for u in rule['u']],row['id']])
                           for name,rule in plan['rules'].items() if name.startswith('alpha')}
                result=dict(id=row['id'],alpha_comparison=compare(summaries['alpha32'],summaries['alpha64'],plan['gates']),
                            harmonic_logL_max_delta=float(abs(arrays[0,:,row['id']]-arrays[1,:,row['id']]).max()))
                if row['id']==reference[(pop,model)]:
                    a=summarize(plan['rules']['u8'],oracle[1,:80]);b=summarize(plan['rules']['u16'],oracle[1,80:])
                    result['independent_u_refinement']=compare(a,b,plan['gates'])
                    result['alpha_vs_independent_u']=compare(summaries['alpha64'],b,plan['gates'])
                    result['independent_harmonic_logL_max_delta']=float(abs(oracle[0]-oracle[1]).max())
                results.append(result)
            record=dict(population=pop,model=model,path=str(path),sha256=sha(path),rows=results,
                        complete_functional_validation=False,production500_approved=False)
            write_json(output/f'{pop}_{model}.json',record);records.append(record)
    return dict(curves=records,likelihood_values=ledger.named.total,all_288_targets_retained=True,
                status='FINITE_ENGINEERING_PRODUCTS_ONLY_NOT_FUNCTIONAL_OR_SBC_APPROVAL')


if __name__=='__main__':
    request=read_json(sys.argv[1]);guard=WorkerBudget(request);result=None;failure=None
    try:result=run(request,guard);guard.checkpoint()
    except BaseException as exc:failure=dict(type=type(exc).__name__,message=str(exc))
    finally:write_json(request['receipt'],dict(schema='C11_WORKER_END_v1',request_sha256=sha(sys.argv[1]),
            passed=failure is None,result=result,failure=failure,**guard.report()))
    sys.exit(1 if failure else 0)
