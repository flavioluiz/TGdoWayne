"""Positive quadrature comparisons. Never a uniform CDF or event certificate."""
import math
import numpy as np


def summarize(rule,loglike):
    u=np.asarray(rule['u']);w=np.asarray(rule['du_weights']);p=np.asarray(rule['panels'])
    ell=np.asarray(loglike)
    if ell.shape!=u.shape or not np.isfinite(ell).all() or not np.all(w>0):raise ValueError('Finite positive-rule arrays')
    shift=float(ell.max());weighted=w*np.exp(ell-shift);Z=math.fsum(weighted)
    if not math.isfinite(Z) or Z<=0:raise ArithmeticError('Normalization unresolved')
    cdf=[0.]+[math.fsum(weighted[p<j])/Z for j in range(1,11)]
    normalized=weighted/Z;logZ=shift+math.log(Z)
    return dict(logZ=logZ,mean=float(normalized@u),second=float(normalized@(u*u)),
                KL_to_uniform_prior=float(normalized@ell-logZ),CDF_at_panel_edges=cdf,
                scope='finite_positive_quadrature_on_uniform_u_not_continuous_CDF_certificate')


def compare(a,b,tolerances):
    deltas={key:abs(a[key]-b[key]) for key in ('logZ','mean','second','KL_to_uniform_prior')}
    deltas['CDF_at_panel_edges']=max(abs(x-y) for x,y in zip(a['CDF_at_panel_edges'],b['CDF_at_panel_edges']))
    passed=all(v<=tolerances['logZ_moment_KL_W1'] for k,v in deltas.items() if k!='CDF_at_panel_edges')
    passed=passed and deltas['CDF_at_panel_edges']<=tolerances['CDF']
    return dict(passed=passed,differences=deltas,finite_fixed_cuts_only=True,
                W1_not_assessed=True,quantiles_not_validated=True,logL_PIT_interval=[0.,1.],
                mass_PIT_unvalidated_interval=[0.,1.],uniform_error_bound=None)
