"""Prospective C11 phase controller. Default is metadata preflight only.

--run requires a separate, exact ROOT authorization plus release/branch receipts.
The candidate never creates that authorization and never advances phases itself.
"""
import argparse
import math
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
from io_contract import ROOT,read_json,write_json,sha,usage,bytes_under,verify_bindings

HERE=Path(__file__).resolve().parent


def authorization(path,stage,plan_path,manifest_path):
    auth=read_json(path);plan=read_json(plan_path)
    if (auth.get('schema')!='C11_ROOT_PHASE_AUTHORIZATION_v1' or auth.get('authorized')is not True
        or auth.get('stage')!=stage or auth.get('plan_sha256')!=sha(plan_path)
        or auth.get('manifest_sha256')!=sha(manifest_path)
        or auth.get('single_attempt')is not True):raise ValueError('Explicit ROOT phase authorization required')
    for name in ('published_C10','simulation_branch_decision'):
        binding=auth[name];p=ROOT/binding['path']
        if sha(p)!=binding['sha256']:raise ValueError('ROOT prerequisite receipt binding')
        receipt=read_json(p)
        if name=='published_C10' and not (receipt.get('published')is True and receipt.get('tag')=='v0.10.0'):
            raise ValueError('Published C10 prerequisite pending')
        if name=='simulation_branch_decision' and receipt.get('approved_branch')!=plan['required_branch_decision']:
            raise ValueError('Explicit periodic-simulation branch decision pending')
    return auth


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['benchmark','curves'],default='benchmark')
    ap.add_argument('--run',action='store_true');ap.add_argument('--authorization',type=Path)
    ap.add_argument('--output',type=Path);a=ap.parse_args()
    pp=HERE/'preflight.json';mp=HERE/'manifest.json';plan=read_json(pp);manifest=read_json(mp)
    verify_bindings(manifest);stage=next(s for s in plan['stages'] if s['name']==a.stage)
    if not a.run:
        print(__import__('json').dumps(dict(status='PREFLIGHT_ONLY_NO_PHYSICS',stage=a.stage,
          manifest_sha256=sha(mp),counts={k:v for k,v in stage.items() if k!='nodes'},
          functional_validation_pending=plan['blocked_functional_products'])));return
    if a.authorization is None or a.output is None:raise ValueError('Authorization and fresh output required')
    auth=authorization(a.authorization,a.stage,pp,mp)
    out=a.output.resolve()
    if not out.is_relative_to(ROOT/'tmp') or out.exists():raise ValueError('Fresh prospective tmp destination required')
    if auth.get('output_path')!=str(out):raise ValueError('Authorized output identity mismatch')
    out.mkdir();lock=out/'ACTIVE.lock';lock.write_text(str(os.getpid()))
    write_json(out/'authorization_received.json',dict(path=str(a.authorization.resolve()),sha256=sha(a.authorization)))
    initial=dict(real=0,sky=0,LL=0,cpu=0.);initial_output=0
    records=[];old_nodes=[];sky_receipts=[];probe_receipts=[]
    results=[];failure=None;started=time.monotonic();process=None;pending=None
    # All errors after the output is claimed are preserved as terminal failures.
    try:
        if a.stage=='curves':
            previous=auth['approved_benchmark'];end=read_json(ROOT/previous['end_path'])
            if (sha(ROOT/previous['end_path'])!=previous['end_sha256'] or end.get('passed')is not True
                or end.get('stage')!='benchmark' or end.get('manifest_sha256')!=sha(mp)):
                raise ValueError('Reviewed successful benchmark with identical closure required')
            index=ROOT/previous['cache_index_path']
            if sha(index)!=previous['cache_index_sha256']:raise ValueError('Benchmark cache inventory binding')
            records=read_json(index)['records'];old_nodes=plan['rows'];old_nodes=[r['u'] for r in old_nodes]
            initial.update(end['counts']);initial['cpu']=previous['total_external_cpu_seconds']
            initial_output=next(s for s in plan['stages'] if s['name']=='benchmark')['maximum_output_bytes_candidate']
            if initial['cpu']<end['resources']['cpu_seconds']:raise ValueError('Cannot discard benchmark lifecycle CPU')
            sky_receipts=end['sky_receipts']
            probe_receipts=end['probe_receipts']
            for binding in end['worker_receipts']:
                if sha(binding['receipt'])!=binding['sha256']:raise ValueError('Benchmark worker receipt changed')
        effective_nodes=[u for u in stage['nodes'] if u not in old_nodes]
        totals={k:initial[k] for k in ('real','sky','LL')}
        cap_map={'real':stage['real_GEMM_multiplications'],'sky':stage['sky_angular_points'],
                 'LL':stage['maximum_likelihood_values']}
        def checkpoint():
            u=usage()
            if initial['cpu']+u['cpu_seconds']>stage['cpu_seconds_candidate']:
                raise RuntimeError('Cumulative import/controller/children CPU cap')
            if u['rss_sum_of_maxima_bytes']>stage['RSS_bytes_candidate']:raise RuntimeError('RSS sum-of-maxima cap')
            if initial_output+bytes_under(out)+65536>stage['maximum_output_bytes_candidate']:raise RuntimeError('Cumulative output cap with final-receipt reserve')
        def job(operation,**parameters):
            nonlocal process,pending
            checkpoint();j=len(results);folder=out/f'job_{j:02d}';receipt=out/f'job_{j:02d}_end.json'
            remaining=stage['cpu_seconds_candidate']-initial['cpu']-usage()['cpu_seconds']
            if remaining<1:raise RuntimeError('No CPU left before child import')
            caps=dict(cpu=remaining,rss=stage['RSS_bytes_candidate']-usage()['rss_parent_bytes'],
               numeric=stage['numeric_bytes_candidate'],output=stage['maximum_output_bytes_candidate']-initial_output-bytes_under(out)-65536,
               **{k:cap_map[k]-totals[k] for k in totals})
            request=dict(operation=operation,plan=str(pp.relative_to(ROOT)),manifest=str(mp.relative_to(ROOT)),
                  output=str(folder),receipt=str(receipt),caps=caps,stage=a.stage,
                  root_authorization=str(a.authorization.resolve().relative_to(ROOT)),
                  root_authorization_sha256=sha(a.authorization),**parameters)
            rp=out/f'job_{j:02d}_request.json';write_json(rp,request)
            source='response_worker.py' if operation in ('harmonic','sky','basis_probe') else 'analysis_worker.py'
            env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',
                     MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
            def limits():
                seconds=max(1,math.ceil(remaining));resource.setrlimit(resource.RLIMIT_CPU,(seconds,seconds))
                resource.setrlimit(resource.RLIMIT_FSIZE,(stage['maximum_file_bytes_candidate'],)*2)
            with (out/f'job_{j:02d}.log').open('xb') as log:
                pending=dict(operation=operation,upper={k:caps[k] for k in totals},request_sha256=sha(rp))
                process=subprocess.Popen([str(ROOT/'.venv/bin/python'),'-B',str(HERE/source),str(rp)],
                  cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
                began=time.monotonic()
                try:
                    while True:
                        try:code=process.wait(timeout=.5);break
                        except subprocess.TimeoutExpired:
                            checkpoint()
                            rss=subprocess.run(['/bin/ps','-o','rss=','-p',str(process.pid)],
                              capture_output=True,text=True,check=False)
                            if rss.stdout.strip() and int(rss.stdout.strip())*1024+usage()['rss_parent_bytes']>stage['RSS_bytes_candidate']:
                                raise RuntimeError('Live worker plus controller RSS cap')
                            if time.monotonic()-began>2*remaining+30:raise RuntimeError('Prospective wall stop')
                except BaseException:
                    if process.poll() is None:
                        try:process.kill()
                        except PermissionError:
                            # Own single child: retain the outstanding reservation
                            # and reap under its already-installed hard CPU limit.
                            pass
                    process.wait();raise
                finally:
                    if process.poll() is not None:process.wait()
            # RUSAGE_CHILDREN now includes all child imports and process teardown.
            if not receipt.exists():raise RuntimeError('Missing worker end; charged upper reservation remains uncertain')
            value=read_json(receipt)
            for k in totals:totals[k]+=value['counts'][k]
            pending=None
            results.append(dict(operation=operation,receipt=str(receipt),sha256=sha(receipt),exit_code=code))
            checkpoint()
            if code!=0 or not value['passed']:raise RuntimeError('Worker failure preserved: '+str(value.get('failure')))
            return value
        for k in range(1,9):
            for level in (0,1):
                value=job('harmonic',channel=k,resolution=level,nodes=effective_nodes)
                records.extend(dict(path=r['record'],sha256=r['record_sha256']) for r in value['result']['saved'])
        if a.stage=='benchmark':
            for case in plan['sky_cases']:
                job('sky',case=case['id']);sky_receipts.append(results[-1]['receipt'])
            for i,_ in enumerate(plan['basis_probes']):
                job('basis_probe',probe=i);probe_receipts.append(results[-1]['receipt'])
        index=out/'cache_index.json';write_json(index,dict(records=records,manifest_sha256=sha(mp)))
        job('gate',nodes=stage['nodes'],cache_index=str(index),sky_receipts=sky_receipts,probe_receipts=probe_receipts)
        if a.stage=='curves':
            job('generation',cache_index=str(index));generation_receipt=results[-1]['receipt']
            job('likelihood',cache_index=str(index),generation_receipt=generation_receipt)
        verify_bindings(manifest);checkpoint()
    except BaseException as exc:failure=dict(type=type(exc).__name__,message=str(exc))
    finally:
        uncertain=process is not None and process.poll() is None
        end=dict(schema='C11_PHASE_END_v1',stage=a.stage,passed=failure is None and not uncertain,
          manifest_sha256=sha(mp),plan_sha256=sha(pp),authorization_sha256=sha(a.authorization),
          counts=locals().get('totals',initial),failure=failure,uncertain_child_state=uncertain,
          unresolved_worker_upper_reservation=pending,counts_complete=pending is None,
          resources=usage(),historical_cpu_seconds=initial['cpu'],wall_seconds=time.monotonic()-started,
          historical_output_upper_bytes=initial_output,output_bytes_before_final_receipt=bytes_under(out),
          worker_receipts=results,sky_receipts=sky_receipts,probe_receipts=probe_receipts,
          CPU_scope='process start imports plus all waited child exits; ROOT must append controller-exit receipt',
          no_automatic_next_stage=True,functional_validation_complete=False,production500_approved=False)
        write_json(out/'execution_end.json',end)
        if not uncertain:lock.unlink()
    print(__import__('json').dumps(dict(passed=end['passed'],failure=failure,output=str(out))))
    if failure:sys.exit(1)


if __name__=='__main__':main()
