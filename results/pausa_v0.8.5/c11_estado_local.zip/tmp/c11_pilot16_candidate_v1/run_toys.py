"""Bounded deterministic tests only; no physical inputs, statistical RNG or ORF."""
from pathlib import Path
import json
import os
import resource
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]

if __name__=='__main__':
    destination=Path(sys.argv[1]);destination.mkdir(exist_ok=False)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',
             MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
    def limits():
        resource.setrlimit(resource.RLIMIT_CPU,(15,15));resource.setrlimit(resource.RLIMIT_FSIZE,(1024**2,1024**2))
    start=time.monotonic();a=resource.getrusage(resource.RUSAGE_CHILDREN)
    with (destination/'stdout.txt').open('xb') as log:
        p=subprocess.run([str(ROOT/'.venv/bin/python'),'-B',str(HERE/'test_candidate.py'),'-v'],
                         env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits,timeout=30)
    b=resource.getrusage(resource.RUSAGE_CHILDREN);cpu=b.ru_utime+b.ru_stime-a.ru_utime-a.ru_stime
    rss=int(b.ru_maxrss*(1 if sys.platform=='darwin' else 1024))
    result=dict(passed=p.returncode==0 and cpu<=30 and rss<=128*1024**2,exit_code=p.returncode,
                cpu_seconds=cpu,RSS_bytes=rss,wall_seconds=time.monotonic()-start,
                physical_ORF_calls=0,physical_logL_calls=0,physical_or_statistical_draws=0,
                new_deterministic_TOYs=7)
    (destination/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
    sys.exit(0 if result['passed'] else 1)
