"""Bounded, metadata-only audit downloads; never run any retrieved code."""
import datetime
import hashlib
import json
from pathlib import Path
import sys
import urllib.request

BASE = Path(__file__).resolve().parent / "evidence"
LIMIT = 20_000_000
PER_FILE = 2_000_000
path = BASE / "download_manifest.json"
manifest = json.loads(path.read_text()) if path.exists() else []
for name, url in zip(sys.argv[1::2], sys.argv[2::2], strict=True):
    try:
        used = sum(p.stat().st_size for p in BASE.iterdir() if p.is_file())
        cap = min(PER_FILE, LIMIT - used)
        if cap <= 0:
            raise ValueError("20 MB budget exhausted")
        req = urllib.request.Request(url, headers={"User-Agent": "TGdoWayne-source-audit/1.0"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            length = resp.headers.get("Content-Length")
            if length is not None and int(length) > cap:
                raise ValueError("metadata Content-Length exceeds cap")
            raw = resp.read(cap + 1)
            if len(raw) > cap:
                raise ValueError("metadata response exceeds cap")
            resolved_url = resp.url
        (BASE / name).write_bytes(raw)
        manifest.append(dict(file=name, url=url, resolved_url=resolved_url, bytes=len(raw),
                             sha256=hashlib.sha256(raw).hexdigest(),
                             accessed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        print(name, len(raw), flush=True)
    except Exception as exc:
        print(name, type(exc).__name__, str(exc), flush=True)
path.write_text(json.dumps(manifest, indent=2) + "\n")
