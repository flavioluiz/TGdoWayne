"""Explicit process-local loader binding for unchanged v2 pilot mathematics."""
from pathlib import Path
import hashlib,json
import numpy as np
from channelwise_table import ChannelwiseEvenThresholdCubicORF


def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()


def load_table(path,expected_sha256,budget,*,expected_shape=None):
 budget.check()
 if sha(path)!=expected_sha256:raise ValueError('Frozen table changed before loading')
 with np.load(path,allow_pickle=False) as data:
  if set(data.files)!={'nodes','matrices'}:raise ValueError('Unexpected table NPZ members')
  nodes,matrices=data['nodes'],data['matrices']
  if expected_shape is not None and matrices.shape!=expected_shape:raise ValueError('Frozen C07 table shape differs')
  table=ChannelwiseEvenThresholdCubicORF(nodes,matrices,coordinate='beta',
   maximum_estimated_bytes=budget.config['estimated_numeric_bytes'],checkpoint=budget.check)
 if sha(path)!=expected_sha256:raise ValueError('Frozen table changed by the end of loading')
 budget.check()
 if len(table.fallback):raise RuntimeError('Unexpected ORF fallback compared with frozen8336 table')
 return table


def experiment_and_table(config,budget):
 from inference.model import experiment
 root=Path(__file__).resolve().parents[2]
 e=experiment(json.loads((root/config['experiment_config']).read_text()))
 table=load_table(root/config['table_file'],config['table_sha256'],budget,expected_shape=(8336,4,12,12))
 return e,table


def pilot(core,config,out,budget,backend_dir,*,factory=experiment_and_table):
 """Bind the global factory looked up by core.pilot; restore it on every exit."""
 previous=core.experiment_and_table
 core.experiment_and_table=factory
 try:return core.pilot(config,out,budget,backend_dir)
 finally:core.experiment_and_table=previous
