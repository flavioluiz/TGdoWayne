"""Same even-threshold spline, built one channel at a time; no physical ORF."""
import numpy as np
from scipy.interpolate import CubicSpline
from inference.orf_cubic_reference import CertifiedCubicORF


def estimate(n,k,p,tile=64):
 """Simultaneous arithmetic allowance, including caller matrices; not RSS proof."""
 if any(type(x) is not int or x<1 for x in (n,k,p,tile)) or n<2:raise ValueError('Positive table dimensions required')
 matrix=n*k*p*p*16;coeff=4*(n-1)*k*p*p*16;channel=4*(n-1)*p*p*16
 tiled=max(12,3*k)*min(tile,n-1)*p*p*16+4*min(tile,n-1)*p*8
 axes=(5*n+1)*8
 return dict(caller_matrix_bytes=matrix,owned_final_coefficient_bytes=coeff,
  one_channel_coefficient_bytes=channel,channel_construction_allowance_bytes=8*channel,
  tiled_checks_allowance_bytes=tiled,axes_and_minima_bytes=axes,library_allowance_bytes=64*1024**2,
  estimated_simultaneous_numeric_and_allowance_bytes=matrix+coeff+8*channel+tiled+axes+64*1024**2,
  scope='Caller matrices + final coeff + eight per-channel coeff allowances + tiles/axes +64MiB; not RSS certificate')


class ChannelwiseEvenThresholdCubicORF(CertifiedCubicORF):
 def __init__(self,nodes,matrices,*,coordinate='beta',tile=64,maximum_estimated_bytes=1400000000,checkpoint=None):
  self.nodes=np.asarray(nodes,float);self.matrices=np.asarray(matrices)
  if coordinate not in ('alpha','beta'):raise ValueError('Unsupported interpolation coordinate.')
  if (self.nodes.ndim!=1 or len(self.nodes)<2 or self.nodes[0]!=0 or self.nodes[-1]!=1
      or not np.isfinite(self.nodes).all() or np.any(np.diff(self.nodes)<=0)):raise ValueError('Ordered full [0,1] table required.')
  if (self.matrices.ndim!=4 or self.matrices.shape[0]!=len(self.nodes)
      or self.matrices.shape[2]!=self.matrices.shape[3] or self.matrices.dtype.kind not in 'fiuc'):
   raise ValueError('Numeric (node,channel,pulsar,pulsar) matrices required')
  n,k,p,_=self.matrices.shape
  self.memory_estimate=estimate(n,k,p,tile)
  if type(maximum_estimated_bytes) is not int or maximum_estimated_bytes<1:raise ValueError('Positive estimate cap required')
  if self.memory_estimate['estimated_simultaneous_numeric_and_allowance_bytes']>maximum_estimated_bytes:
   raise MemoryError('Channelwise estimate exceeds original numerical cap before coefficients/check temporaries')
  check=checkpoint or (lambda:None)
  # Same ConvexORF acceptance conditions; tile before boolean/Hermitian/eigh temporaries.
  for lo in range(0,n,tile):
   part=self.matrices[lo:lo+tile]
   if not np.isfinite(part).all():raise ValueError('Invalid matrices.')
   if np.max(abs(part-part.swapaxes(-1,-2).conj()))>1e-12:raise ValueError('Not Hermitian.')
   if np.linalg.eigvalsh(part).min()<-1e-12:raise ValueError('Not PSD; no clipping.')
   check()
  self.coordinate_name=coordinate
  self.coordinate=np.arcsin if coordinate=='alpha' else lambda u:-np.sqrt((1-u)*(1+u))
  self.alpha=self.coordinate(self.nodes);width=np.diff(self.alpha)
  dtype=np.complex128 if self.matrices.dtype.kind=='c' else np.float64
  self.coeff=np.empty((n-1,4,k,p,p),dtype=dtype)
  mineig=np.full(n-1,np.inf)
  for channel in range(k):
   c=CubicSpline(self.alpha,self.matrices[:,channel:channel+1],
    bc_type=('not-a-knot',(1,np.zeros((1,p,p))))).c
   check()
   # Identical expressions/order to the frozen constructor; avoid list/stack of all channels.
   for j in range(4):self.coeff[:,j,channel:channel+1]=c[3-j]*width[:,None,None,None]**j
   del c
   for lo in range(0,n-1,tile):
    hi=min(lo+tile,n-1)
    a0,a1,a2,a3=np.moveaxis(self.coeff[lo:hi,:,channel:channel+1],1,0)
    bernstein=np.stack([a0,a0+a1/3,a0+2*a1/3+a2/3,a0+a1+a2+a3],axis=1)
    local=np.linalg.eigvalsh(bernstein).min(axis=(1,2,3))
    mineig[lo:hi]=np.minimum(mineig[lo:hi],local)
    del bernstein,local,a0,a1,a2,a3
    check()
  # Original fallback is GLOBAL BY INTERVAL, including all channels.
  self.fallback=np.where(mineig< -1e-12)[0]
  for j in self.fallback:
   self.coeff[j,0]=self.matrices[j];self.coeff[j,1]=self.matrices[j+1]-self.matrices[j];self.coeff[j,2:]=0
  self.bernstein_minimum_eigenvalue=mineig
  self.threshold_derivative_condition='zero from exact beta parity of isotropic unpolarized TT integral'
  check()
