# C09 nominal14 v4 — tabela por canal e continuação candidata

**Nenhuma autorização ou execução física neste pacote.** As falhas v2/v3, os 192 Γ e os dados v3 permanecem intactos. O v4 não contém chamada para calcular nova ORF, céu direto ou geração.

`channelwise_table.py` constrói a mesma spline `EvenThresholdCubicORF` um canal por vez, mantendo coeficientes conjuntos e fallback global por intervalo. `runtime_adapter.py` fornece o loader e vincula explicitamente essa fábrica à função `pilot` v2 durante sua chamada; restaura a fábrica anterior ao sair. Nenhuma fonte v2/v3 é editada.

`common.py` verifica a falha v3 e vincula 44 artefatos históricos. O controlador `run_nominal14.py` usa somente stdlib, `preexec`/`RLIMIT_CPU` e CPU final de filhos por `RUSAGE_CHILDREN`. Um futuro worker backend (`worker.py`) carregará caches/dados arquivados, reconstruirá somente a tabela em memória e avaliará os 448 valores de likelihood pendentes. Um piloto ainda requer autorização posterior vinculada ao backend PASS revisado e ao seu receipt final.

O reuso dos gates diretos exige aceitação ROOT explícita de **evidência do fluxo congelado**, porque os máximos numéricos diretos não foram arquivados. `PREFLIGHT.md` expõe o raciocínio, os limites e a transferência da reserva de 448 valores comprovadamente não avaliados. Não há JSON direto reconstruído nem número inventado.

Os 12 testes novos usam somente matrizes TOY. Verificam igualdade bitexact dos coeficientes, valores, mínimos de Bernstein e fallback, incluindo um canal que obriga fallback em todos os canais. Não carregam a tabela real nem chamam likelihood física.

Sem `--execute`, o runner apenas imprime preflight de metadados:

```sh
.venv/bin/python -B tmp/c09_nominal14_v4/run_nominal14.py
```

A revisão deve partir de `PREFLIGHT.md`, `historical_evidence.json`, `preflight.json` e `manifest.json`. C10 continua somente com seus metadados parciais, em espera.
