"""V4 metadata/identity contract, no numerical imports or physical operations."""
from pathlib import Path
import hashlib,json,math,platform,resource,sys
from importlib.metadata import version
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
V2=ROOT/'tmp/c09_nominal14_v2';V3=ROOT/'tmp/c09_nominal14_v3';FAILED=ROOT/'tmp/c09_nominal14_backend_v3'
AUTH_SCHEMA='ROOT_C09_NOMINAL14_TABLE_CONTINUATION_APPROVAL_v4'
REPEAT_SCOPE='RESUME_TABLE_AND_448_LL_WITH_V3_GAMMA_DATA_NO_NEW_ORF_SKY_DRAWS'

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def read(path):return json.loads(Path(path).read_text())
def saved_bytes(root):return sum(p.stat().st_size for p in Path(root).rglob('*') if p.is_file())
def write_new(path,value,*,output_root=None,cap=None):
 payload=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
 if output_root is not None and saved_bytes(output_root)+len(payload)>cap:raise RuntimeError('Output ceiling exceeded before writing')
 with Path(path).open('xb') as f:f.write(payload)
def rss():
 value=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 return int(value if sys.platform=='darwin' else value*1024)
def cpu_limits(remaining):
 if not math.isfinite(remaining):raise ValueError('Finite CPU remainder required')
 n=math.floor(remaining)
 if n<1:raise RuntimeError('Less than one second remains in combined CPU budget')
 return n,n+1

def source_hashes(config):
 names=set(read(FAILED/'execution_identity.json')['source_sha256'])
 names.update(str((HERE/name).relative_to(ROOT)) for name in ('common.py','run_nominal14.py','worker.py','channelwise_table.py','runtime_adapter.py'))
 names.add(str((V3/'config.json').relative_to(ROOT)))
 return {name:sha(ROOT/name) for name in sorted(names)}

def historical_evidence():
 end=read(FAILED/'execution_end.json');identity=read(FAILED/'execution_identity.json')
 failure=read(FAILED/'execution_failure.json');gate=FAILED/'gates'
 gf=read(gate/'worker_failure.json');ge=read(gate/'worker_end.json');r=end['resources'];gr=ge['resources']
 if (end['status']!='CONTROLLER_STAGE_FAILED' or end['inputs_unchanged'] is not True or end['within_resource_limits'] is not False
     or r['combined_CPU_seconds']!=149.10019599999998 or r['charged_ORF_multiplication_proxy']!=214577271056
     or r['charged_sky_config_points']!=74530432 or r['charged_likelihood_values']!=0
     or r['charged_likelihood_values_by_target']!={} or r['reserved_likelihood_values']!=448
     or r['reserved_likelihood_values_by_target']!={str(i):32 for i in range(14)}
     or ge['status']!='WORKER_FAILED' or ge['inputs_unchanged'] is not True
     or gr['charged_ORF_multiplication_proxy']!=0 or gr['charged_sky_config_points']!=74530432
     or gr['charged_likelihood_values']!=0 or gr['charged_likelihood_values_by_target']!={}
     or gf['error']!='Operational RSS ceiling reached'):
  raise ValueError('Frozen v3 failure/cumulative ledger differs')
 trace=gf['traceback']
 required=('tmp/c09_nominal14_v3/worker.py','line 134, in gates','experiment_and_table(config,budget)',
           'tmp/c09_nominal14_v2/run_nominal14.py','line 155, in experiment_and_table','budget.check()','MemoryError: Operational RSS ceiling reached')
 if any(s not in trace for s in required):raise ValueError('Expected post-direct/pre-likelihood failure witness differs')
 if (gate/'backend_result.json').exists():raise ValueError('Unexpected numeric gate report: must not silently change evidence class')
 if sha(V3/'config.json')!=identity['config_sha256']:raise ValueError('Executed v3 config changed')
 for name,digest in identity['source_sha256'].items():
  if sha(ROOT/name)!=digest:raise ValueError('Executed v3 source changed: '+name)
 bindings={}
 for path in [FAILED/'execution_identity.json',FAILED/'execution_end.json',FAILED/'execution_failure.json',
              gate/'worker_failure.json',gate/'worker_end.json',gate/'harmonic_nodes.npz',gate/'data.npz',FAILED/'gates_request.json']:
  bindings[str(path.relative_to(ROOT))]=sha(path)
 if ge['request_sha256']!=bindings[str((FAILED/'gates_request.json').relative_to(ROOT))]:raise ValueError('Historical gate request changed')
 for record in end['workers'][:12]:
  name=record['job'];base=FAILED/name;we=read(base/'worker_end.json');cache=read(base/'matrices.json')
  if (record['returncode']!=0 or we['status']!='WORKER_COMPLETED' or we['inputs_unchanged'] is not True
      or sha(base/'worker_end.json')!=record['worker_end_sha256']
      or cache['source_sha256']!=identity['source_sha256'] or cache['config_sha256']!=identity['config_sha256']
      or cache['authorization_sha256']!=identity['authorization_sha256'] or cache['arrays_sha256']!=sha(base/'matrices.npz')
      or cache['mass_count']!=16):raise ValueError('Historical harmonic cache identity differs')
  for path in (base/'worker_end.json',base/'matrices.json',base/'matrices.npz'):
   bindings[str(path.relative_to(ROOT))]=sha(path)
 if len(end['workers'])!=13 or {x['job'] for x in end['workers'][:12]}!={f'harmonic_{k}_{j}' for k in range(4) for j in range(3)}:
  raise ValueError('Expected 12 distinct successful harmonic jobs')
 code=(V3/'worker.py').read_text()
 markers=[' if not harmonic_pass:',' if not direct_pass:'," save_npz_new(out/'data.npz'"," _,table=experiment_and_table(config,budget)","  budget.likelihood(N*2,row['id'])"]
 positions=[code.index(x) for x in markers]
 if positions!=sorted(positions):raise ValueError('Reviewed sequential gate/data/LL flow differs')
 evidence=dict(schema='C09_V3_FROZEN_FLOW_EVIDENCE_v4',artifact_sha256=bindings,
  historical_status='FAILED_RSS_PRESERVED',harmonic_jobs_completed=12,harmonic_matrices_archived=192,
  direct_evidence_kind='FROZEN_SEQUENTIAL_CONTROL_FLOW_AND_TRACEBACK_NO_SAVED_NUMERIC_DIRECT_REPORT',
  direct_comparisons_satisfied_in_that_flow=True,direct_numeric_maxima=None,direct_numeric_record_available=False,
  evidence_scope='Passing direct guard is inferred from frozen sequential code, saved data and later traceback; not a reconstructed numeric report or independent reproduction.',
  requires_explicit_ROOT_flow_reuse_approval=True,global_ORF_error_certificate=False,
  CPU_seconds=r['combined_CPU_seconds'],real_products=r['charged_ORF_multiplication_proxy'],sky_points=r['charged_sky_config_points'],
  likelihood_values=0,likelihood_by_target={},historical_unspent_likelihood_reservation=448,
  historical_unspent_likelihood_reservation_by_target={str(i):32 for i in range(14)},repeat_scope=REPEAT_SCOPE,
  failure_sha256=sha(FAILED/'execution_failure.json'),execution_end_sha256=sha(FAILED/'execution_end.json'),
  execution_identity_sha256=sha(FAILED/'execution_identity.json'))
 evidence['evidence_sha256']=hashlib.sha256(json.dumps(evidence,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 return evidence

def preflight():
 c=read(HERE/'config.json');old=read(V3/'config.json')
 if c['versions']!={'python':platform.python_version(),'numpy':version('numpy'),'scipy':version('scipy')}:raise ValueError('Numerical versions differ')
 if {k:v for k,v in c.items() if k!='schema'}!={k:v for k,v in old.items() if k!='schema'}:raise ValueError('Scientific configuration changed')
 if sha(ROOT/c['table_file'])!=c['table_sha256']:raise ValueError('Frozen C07 table changed')
 evidence=historical_evidence()
 return dict(schema='C09_TABLE_RESUME_PREFLIGHT_v4',status='CANDIDATE_NO_EXECUTION_AUTHORIZATION',execution_enabled=False,
  config_sha256=sha(HERE/'config.json'),source_sha256=source_hashes(c),table_sha256=c['table_sha256'],
  failure=evidence,historical_evidence_sha256=evidence['evidence_sha256'],unchanged_budgets=c['budgets'],
  cumulative_real_products=evidence['real_products'],cumulative_sky_points=evidence['sky_points'],
  new_real_products=0,new_sky_points=0,new_draws=0,new_likelihood_values=448,
  jobs=[dict(name='gates',kind='table_likelihood',real_products=0,sky_points=0,likelihood_values=448,likelihood_by_target={str(i):32 for i in range(14)})],
  remaining_reported_CPU_seconds=600-evidence['CPU_seconds'],automatic_retry=False)

def validate_authorization(path,stage,plan):
 a=read(path)
 if (a.get('schema')!=AUTH_SCHEMA or a.get('approved') is not True or a.get('execution_allowed') is not True
     or stage not in a.get('stages',[]) or a.get('config_sha256')!=plan['config_sha256']
     or a.get('source_sha256')!=plan['source_sha256'] or a.get('table_sha256')!=plan['table_sha256']
     or a.get('historical_evidence_sha256')!=plan['historical_evidence_sha256']
     or a.get('approve_control_flow_direct_gate_reuse') is not True
     or a.get('carry_unspent_448_likelihood_reservation') is not True
     or a.get('repeat_scope')!=REPEAT_SCOPE or a.get('budgets')!=plan['unchanged_budgets']):
  raise ValueError('Exact v4 source/history/flow-reuse/unspent-reservation approval required')
 return a

def validate_backend_for_pilot(path,authorization,plan):
 path=Path(path);end=read(path/'execution_end.json');result=read(path/'backend_result.json');identity=read(path/'execution_identity.json')
 if (end.get('status')!='CONTROLLER_STAGE_COMPLETED' or end.get('inputs_unchanged') is not True or end.get('within_resource_limits') is not True
     or result.get('status')!='BACKEND_AND_GENERATION_PASS_ON_SPARSE_NOMINAL14_DOMAIN'
     or identity.get('stage')!='backend' or identity.get('config_sha256')!=plan['config_sha256']
     or identity.get('source_sha256')!=plan['source_sha256'] or identity.get('failure_sha256')!=plan['failure']['failure_sha256']
     or result.get('historical_evidence_sha256')!=plan['historical_evidence_sha256']
     or authorization.get('backend_result_sha256')!=sha(path/'backend_result.json')
     or authorization.get('backend_execution_end_sha256')!=sha(path/'execution_end.json')):
  raise ValueError('Pilot requires separately approved v4 backend and final lifecycle')
 gate=path/'gates'
 if result['gate_report_sha256']!=sha(gate/'backend_result.json'):raise ValueError('Passed gate report changed')
 for name,key in [('data.npz','data_sha256'),('harmonic_nodes.npz','harmonic_nodes_sha256')]:
  if sha(gate/name)!=result[key]:raise ValueError('Passed backend data/cache changed')
 r=end['resources'];cpu=r['combined_CPU_seconds']
 if (r['charged_likelihood_values']!=448 or r['charged_likelihood_values_by_target']!={str(i):32 for i in range(14)}
     or r['charged_ORF_multiplication_proxy']!=plan['cumulative_real_products'] or r['charged_sky_config_points']!=plan['cumulative_sky_points']):
  raise ValueError('Passed backend cumulative ledger differs')
 if isinstance(cpu,bool) or not isinstance(cpu,(int,float)) or not math.isfinite(cpu) or not plan['failure']['CPU_seconds']<=cpu<600:
  raise ValueError('No valid remaining CPU for pilot')
 return r
