"""TOY only: same spline/fallback and new continuation guards; no physical calls."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(30,31))
import ast,json,sys,tempfile,time,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));sys.path.insert(0,str(ROOT/'src'))
import common
import run_nominal14 as controller
import worker
STDLIB_ONLY='numpy' not in sys.modules and 'scipy' not in sys.modules
import numpy as np
from inference.orf_interpolation import EvenThresholdCubicORF
from channelwise_table import ChannelwiseEvenThresholdCubicORF,estimate
import runtime_adapter

class BudgetToy:
 def __init__(self,callback=None):self.config={'estimated_numeric_bytes':128*1024**2};self.calls=0;self.callback=callback
 def check(self):
  self.calls+=1
  if self.callback:self.callback(self.calls)

class ToyTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(prefix='TOY_ONLY_',dir=HERE);self.p=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def matrices(self,n=13,complex=True):
  u=np.linspace(0,1,n);a=np.empty((n,4,2,2),dtype=np.complex128 if complex else np.float64)
  for i,x in enumerate(u):
   for k in range(4):
    off=.03*np.sin((k+1)*x)+(.02j*np.cos(2*x) if complex else 0)
    a[i,k]=[[2+.2*x*x+.1*k,off],[np.conjugate(off),1+.1*np.sin(x+k)]]
  return u,a
 def same(self,old,new):
  for name in ('nodes','matrices','alpha','coeff','fallback','bernstein_minimum_eigenvalue'):
   a,b=getattr(old,name),getattr(new,name)
   self.assertEqual(a.shape,b.shape,name);self.assertEqual(a.dtype,b.dtype,name);self.assertEqual(a.tobytes(),b.tobytes(),name)
  self.assertEqual(old.coordinate_name,new.coordinate_name)
  self.assertEqual(old.threshold_derivative_condition,new.threshold_derivative_condition)
  q=np.linspace(0,1,31)
  self.assertEqual(old(q).tobytes(),new(q).tobytes())
  for a,b in zip(old.location(q),new.location(q)):self.assertEqual(a.tobytes(),b.tobytes())
 def plan(self):
  return dict(config_sha256='TOY_CFG',source_sha256={'TOY.py':'TOY_SOURCE'},table_sha256='TOY_TABLE',
   historical_evidence_sha256='TOY_EVIDENCE',unchanged_budgets={'TOY':1})
 def authorization(self,plan):
  return dict(schema=common.AUTH_SCHEMA,approved=True,execution_allowed=True,stages=['backend'],
   config_sha256=plan['config_sha256'],source_sha256=plan['source_sha256'],table_sha256=plan['table_sha256'],
   historical_evidence_sha256='TOY_EVIDENCE',approve_control_flow_direct_gate_reuse=True,
   carry_unspent_448_likelihood_reservation=True,repeat_scope=common.REPEAT_SCOPE,budgets=plan['unchanged_budgets'])
 def test_01_controller_worker_stdlib_imports(self):self.assertTrue(STDLIB_ONLY)
 def test_02_whole_and_channelwise_bitexact_real_complex_coordinates_tiles(self):
  for complex in (False,True):
   u,m=self.matrices(complex=complex)
   for coordinate in ('alpha','beta'):
    old=EvenThresholdCubicORF(u,m,coordinate=coordinate)
    for tile in (1,3,64):
     with self.subTest(complex=complex,coordinate=coordinate,tile=tile):
      self.same(old,ChannelwiseEvenThresholdCubicORF(u,m,coordinate=coordinate,tile=tile))
 def test_03_one_bad_channel_forces_global_interval_fallback(self):
  u=np.linspace(0,1,7);m=np.zeros((7,2,1,1),complex)
  m[:,0,0,0]=[1,0,0,1,1,1,1];m[:,1,0,0]=2+u*u
  old=EvenThresholdCubicORF(u,m);new=ChannelwiseEvenThresholdCubicORF(u,m,tile=2)
  self.assertGreater(len(old.fallback),0);self.same(old,new)
  isolated=EvenThresholdCubicORF(u,m[:,1:2]);self.assertEqual(len(isolated.fallback),0)
  for index in old.fallback:
   self.assertEqual(new.coeff[index,2:,1].tobytes(),np.zeros_like(new.coeff[index,2:,1]).tobytes())
   self.assertEqual(new.coeff[index,1,1].tobytes(),(m[index+1,1]-m[index,1]).tobytes())
 def test_04_estimate_before_eig_or_coefficient_allocation(self):
  u,m=self.matrices()
  with patch('channelwise_table.np.linalg.eigvalsh',side_effect=AssertionError('must not run')):
   with self.assertRaises(MemoryError):ChannelwiseEvenThresholdCubicORF(u,m,maximum_estimated_bytes=1)
 def test_05_tiled_same_invalid_matrix_guards(self):
  u,m=self.matrices()
  for kind in ('nan','hermitian','PSD'):
   a=m.copy()
   if kind=='nan':a[2,0,0,0]=np.nan
   elif kind=='hermitian':a[2,0,0,1]=10j
   else:a[2,0,0,0]=-1
   for cls in (EvenThresholdCubicORF,ChannelwiseEvenThresholdCubicORF):
    with self.subTest(kind=kind,cls=cls),self.assertRaises(ValueError):cls(u,a)
 def test_06_TOY_npz_loader_and_before_after_hash(self):
  u,m=self.matrices();path=self.p/'TOY_table.npz';np.savez(path,nodes=u,matrices=m);digest=common.sha(path)
  old=EvenThresholdCubicORF(u,m);new=runtime_adapter.load_table(path,digest,BudgetToy(),expected_shape=m.shape);self.same(old,new)
  with self.assertRaises(ValueError):runtime_adapter.load_table(path,'WRONG',BudgetToy())
  def mutate(calls):
   if calls==2:path.write_bytes(b'TOY_CHANGED_AFTER_EXTRACTION')
  with self.assertRaisesRegex(ValueError,'end of loading'):runtime_adapter.load_table(path,digest,BudgetToy(mutate))
 def test_07_pilot_factory_binding_and_restore_on_both_exits(self):
  original=lambda *a: (_ for _ in ()).throw(AssertionError('legacy factory reached'))
  core=SimpleNamespace(experiment_and_table=original)
  replacement=lambda c,b:('TOY_E','TOY_CHANNELWISE_TABLE')
  core.pilot=lambda c,o,b,d:core.experiment_and_table(c,b)
  self.assertEqual(runtime_adapter.pilot(core,{},None,None,None,factory=replacement),('TOY_E','TOY_CHANNELWISE_TABLE'))
  self.assertIs(core.experiment_and_table,original)
  def fail(*a):raise RuntimeError('TOY_FAILURE')
  core.pilot=fail
  with self.assertRaises(RuntimeError):runtime_adapter.pilot(core,{},None,None,None,factory=replacement)
  self.assertIs(core.experiment_and_table,original)
 def test_08_authorization_must_accept_specific_missing_numeric_evidence(self):
  plan=self.plan();a=self.authorization(plan);path=self.p/'TOY_auth.json'
  path.write_text(json.dumps(a));self.assertEqual(common.validate_authorization(path,'backend',plan),a)
  for key,value in [('approve_control_flow_direct_gate_reuse',False),('carry_unspent_448_likelihood_reservation',False),
   ('historical_evidence_sha256','WRONG'),('repeat_scope','REPEAT_ORF'),('approved',False)]:
   path.write_text(json.dumps({**a,key:value}))
   with self.assertRaises(ValueError):common.validate_authorization(path,'backend',plan)
 def test_09_real_sky_cpu_baseline_are_not_reset(self):
  f=dict(CPU_seconds=149.10019599999998,real_products=214577271056,sky_points=74530432)
  baseline=controller.initial_resources({'failure':f})
  self.assertEqual(baseline['charged_ORF_multiplication_proxy'],214577271056)
  self.assertEqual(baseline['charged_sky_config_points'],74530432)
  self.assertEqual(baseline['charged_likelihood_values'],0)
  caps=dict(CPU_seconds_combined=600,real_multiplications=250000000000,direct_sky_points=80000000,
   likelihood_component_values=1000000,likelihood_values_per_target=60000)
  ledger=controller.Ledger(baseline,caps)
  with patch.object(controller.time,'process_time',return_value=2.):
   ledger.child_CPU=.5;self.assertAlmostEqual(ledger.cpu(),151.600196)
   ledger.reserve(dict(real_products=0,sky_points=0,likelihood_values=448,likelihood_by_target={str(i):32 for i in range(14)}))
  self.assertEqual(ledger.real,214577271056);self.assertEqual(ledger.sky,74530432);self.assertEqual(ledger.reserved_values,448)
 def test_10_no_direct_ORF_or_generation_entrypoint_in_v4_worker(self):
  source=(HERE/'worker.py').read_text();ast.parse(source)
  for forbidden in ('RealHarmonicBasis','raw_direct_orf','generate_row','direct_tt_fp'):
   self.assertNotIn(forbidden,source)
  self.assertIn('runtime_adapter.pilot(core,config,out,budget',source)
 def test_11_memory_arithmetic_C07_shape_metadata_only(self):
  e=estimate(8336,4,12)
  self.assertEqual(e['caller_matrix_bytes'],76824576);self.assertEqual(e['owned_final_coefficient_bytes'],307261440)
  self.assertEqual(e['one_channel_coefficient_bytes'],76815360)
  self.assertLess(e['estimated_simultaneous_numeric_and_allowance_bytes']+128*1024**2,1610612736)
 def test_12_shape_coordinate_and_tile_rejections(self):
  u,m=self.matrices()
  for kw in (dict(coordinate='u'),dict(tile=0),dict(tile=True)):
   with self.assertRaises(ValueError):ChannelwiseEvenThresholdCubicORF(u,m,**kw)
  with self.assertRaises(ValueError):ChannelwiseEvenThresholdCubicORF(u,m[:,:,0])

if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ToyTests))
 r=resource.getrusage(resource.RUSAGE_CHILDREN)
 report=dict(schema='C09_V4_TOY_TESTS',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
  CPU_seconds_self=time.process_time(),CPU_seconds_children=r.ru_utime+r.ru_stime,peak_RSS_bytes=common.rss(),
  physical_ORF=0,physical_sky=0,physical_likelihood=0,physical_draws=0,posterior=0,
  whole_vs_channelwise_coefficient_bytes_compared=True,global_fallback_compared=True,
  real_table_loaded=False,estimated_real_table_memory=estimate(8336,4,12))
 report['within_limits']=report['CPU_seconds_self']+report['CPU_seconds_children']<=30 and report['peak_RSS_bytes']<=128*1024**2
 (HERE/'toy_test_result.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 print(json.dumps(report));sys.exit(0 if result.wasSuccessful() and report['within_limits'] else 1)
