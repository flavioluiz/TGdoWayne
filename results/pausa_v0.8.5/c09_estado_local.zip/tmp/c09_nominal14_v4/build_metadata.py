"""Stdlib-only preflight evidence/hash/arithmetic writer; no scientific imports."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(30,31))
import ast,json,time
from common import HERE,ROOT,FAILED,sha,read,write_new,preflight,saved_bytes,rss
if __name__=='__main__':
 for name in ('common.py','run_nominal14.py','worker.py','channelwise_table.py','runtime_adapter.py','test_channelwise_toy.py'):
  ast.parse((HERE/name).read_text(),filename=name)
 p=preflight();tests=read(HERE/'toy_test_result.json')
 p['memory']=tests['estimated_real_table_memory']
 p['memory']['plus_128MiB_process_allowance_bytes']=p['memory']['estimated_simultaneous_numeric_and_allowance_bytes']+128*1024**2
 p['memory']['RSS_margin_to_1_5GiB_with_that_allowance']=1610612736-p['memory']['plus_128MiB_process_allowance_bytes']
 p['historical_output_bytes']=dict(v2=saved_bytes(ROOT/'tmp/c09_nominal14_backend_v2'),v3=saved_bytes(FAILED))
 p['validation']=dict(tests=tests,total_two_TOY_runs_CPU_seconds=1.615333+1.551565,
  metadata_CPU_seconds_through_sample=time.process_time(),metadata_RSS_peak_bytes=rss(),
  real_numeric_table_or_gamma_arrays_loaded=False,physical_ORF=0,physical_sky=0,physical_likelihood=0,physical_draws=0,posterior=0)
 p['prior_numeric_direct_record_search']=dict(files={str((ROOT/name).relative_to(ROOT)):sha(ROOT/name) for name in
  ('results/C07/orf_interpolation/dense_construction.json','results/C07/orf_interpolation/evenness_direct_validation.json')},
  result='Only partial u=.5/channel1/pair3,8 candidate; no complete matching two-case/two-resolution C09 numeric record. Not substituted.')
 write_new(HERE/'historical_evidence.json',p['failure'])
 write_new(HERE/'preflight.json',p)
 files=('config.json','common.py','run_nominal14.py','worker.py','channelwise_table.py','runtime_adapter.py',
        'README.md','PREFLIGHT.md','historical_evidence.json','preflight.json','test_channelwise_toy.py','toy_test_result.json','toy_test.log','build_metadata.py')
 m=dict(schema='C09_NOMINAL14_CANDIDATE_MANIFEST_v4',execution_enabled=False,physical_execution_performed=False,
  status='CANDIDATE_REQUIRES_ROOT_REVIEW_AND_NEW_AUTHORIZATION',config_sha256=p['config_sha256'],source_sha256=p['source_sha256'],
  historical_evidence_sha256=p['historical_evidence_sha256'],artifact_sha256={n:sha(HERE/n) for n in files})
 write_new(HERE/'manifest.json',m)
 print(json.dumps(dict(preflight_sha256=sha(HERE/'preflight.json'),manifest_sha256=sha(HERE/'manifest.json'),
  historical_evidence_sha256=p['historical_evidence_sha256'],historical_evidence_file_sha256=sha(HERE/'historical_evidence.json'),
  sources=len(p['source_sha256']),historical_artifacts=len(p['failure']['artifact_sha256']),CPU_seconds=time.process_time(),RSS_peak_bytes=rss(),execution_enabled=False),indent=2))
