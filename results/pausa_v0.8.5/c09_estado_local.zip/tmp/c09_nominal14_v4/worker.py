"""V4 table/likelihood continuation only; no new ORF, direct sky or draws."""
from pathlib import Path
import argparse,json,math,os,resource,sys,traceback
from common import (HERE,ROOT,V2,FAILED,sha,read,preflight,source_hashes,validate_authorization,validate_backend_for_pilot)


def validate_request(path,expected_hash,plan):
 if sha(path)!=expected_hash:raise ValueError('Worker request hash differs')
 r=read(path);campaign=Path(r['campaign']);identity=read(campaign/'execution_identity.json')
 a=validate_authorization(Path(r['authorization_path']),r['stage'],plan)
 if (r.get('schema')!='C09_FRESH_WORKER_REQUEST_v4' or r['authorization_sha256']!=sha(r['authorization_path'])
     or r['config_sha256']!=plan['config_sha256'] or r['source_sha256']!=plan['source_sha256']
     or r['failure_sha256']!=plan['failure']['failure_sha256']
     or identity.get('historical_evidence_sha256')!=plan['historical_evidence_sha256']
     or any(identity.get(k)!=r[k] for k in ('config_sha256','source_sha256','authorization_sha256','failure_sha256'))):
  raise ValueError('Worker/source/authorization/history identity differs')
 job=r['job'];previous=r['previous_CPU_seconds']
 if r['stage']=='backend':
  if job!=plan['jobs'][0] or r['previous_likelihood_values']!=0 or r['previous_likelihood_by_target']!={}:raise ValueError('Only unspent table+448 likelihood work can resume')
 elif r['stage']=='pilot':
  inherited=validate_backend_for_pilot(Path(r['backend_path']),a,plan)
  if (job['kind']!='pilot' or job['name']!='pilot' or r['previous_likelihood_values']!=448
      or r['previous_likelihood_by_target']!={str(i):32 for i in range(14)}
      or previous<inherited['combined_CPU_seconds']):raise ValueError('Pilot must inherit final passed backend counts')
 else:raise ValueError('Unsupported stage')
 if isinstance(previous,bool) or not isinstance(previous,(int,float)) or not math.isfinite(previous) or not plan['failure']['CPU_seconds']<=previous<600:
  raise ValueError('Cumulative CPU baseline differs')
 if path.resolve()!=campaign.resolve()/(job['name']+'_request.json'):raise ValueError('Request path is outside its job')
 return r,identity


def load_npz_bound(np,path,bindings):
 expected=bindings[str(path.relative_to(ROOT))]
 if sha(path)!=expected:raise ValueError('Historical array changed before load')
 with np.load(path,allow_pickle=False) as f:values={name:f[name] for name in f.files}
 if sha(path)!=expected:raise ValueError('Historical array changed after load')
 return values


def resume_table_likelihood(np,core,config,out,budget,plan):
 from inference.model import experiment
 from kernels import ConditionalKernel
 from runtime_adapter import experiment_and_table
 e=experiment(read(ROOT/config['experiment_config']));masses=np.array(config['sparse_exact_mass_nodes'])
 bindings=plan['failure']['artifact_sha256'];stages=np.empty((3,16,4,12,12),dtype=complex)
 for k in range(4):
  for j in range(3):
   d=load_npz_bound(np,FAILED/f'harmonic_{k}_{j}'/'matrices.npz',bindings)
   if (set(d)!={'u','Gamma'} or d['u'].dtype!=np.dtype('float64') or d['u'].tobytes()!=masses.tobytes()
       or d['Gamma'].dtype!=np.dtype('complex128') or d['Gamma'].shape!=(16,12,12)
       or not np.isfinite(d['Gamma']).all() or np.max(abs(d['Gamma']-d['Gamma'].swapaxes(-1,-2).conj()))>1e-12
       or np.linalg.eigvalsh(d['Gamma']).min()<-1e-12):raise ValueError('Archived harmonic array failed same guards')
   stages[j,:,k]=d['Gamma']
 errors=dict(nodes=float(np.max(abs(stages[1]-stages[0]))),ell=float(np.max(abs(stages[2]-stages[1]))))
 minimum=float(np.linalg.eigvalsh(stages).min());gamma=stages[2].copy()
 if (errors['nodes']>config['gates']['harmonic_nodes_abs'] or errors['ell']>config['gates']['harmonic_ell_abs']
     or minimum<config['gates']['PSD_minimum']):raise ValueError('Archived harmonic refinement/PSD differs')
 archived=load_npz_bound(np,FAILED/'gates'/'harmonic_nodes.npz',bindings)
 if (archived['u'].tobytes()!=masses.tobytes() or archived['Gamma'].dtype!=gamma.dtype
     or archived['Gamma'].shape!=gamma.shape or archived['Gamma'].tobytes()!=gamma.tobytes()):raise ValueError('Saved fine harmonic table differs from 12 caches')
 del stages,archived,d
 data=load_npz_bound(np,FAILED/'gates'/'data.npz',bindings)
 expected_shapes=dict(q=(14,4,12),x_physical=(14,4,10),x_gaussian=(14,4,10),truth_u=(14,),target=(14,))
 if set(data)!=set(expected_shapes) or any(data[name].shape!=shape or not np.isfinite(data[name]).all() for name,shape in expected_shapes.items()):raise ValueError('Archived generated data shape/finitude differs')
 if not np.array_equal(data['target'],np.arange(14)) or not np.array_equal(data['truth_u'],np.array([r['fixed_truth_u'] for r in config['rows']])):raise ValueError('Archived data IDs/truth metadata differ')
 for name in ('data.npz','harmonic_nodes.npz'):
  # Exact small-file copy for unchanged core.pilot input contract; never write coefficients.
  core.write_bytes_new(out/name,(FAILED/'gates'/name).read_bytes())
 _,table=experiment_and_table(config,budget);interpolated=table(masses)
 anchor=gamma[np.flatnonzero(masses==config['anchor_mass'])[0]];anchor_table=table(np.array([config['anchor_mass']]))[0]
 differences=[]
 for row in config['rows']:
  i=row['id'];d={name:data[name][i:i+1] for name in ('q','x_physical','x_gaussian')}
  exact_kernel=ConditionalKernel(e,row,d,anchor);table_kernel=ConditionalKernel(e,row,d,anchor_table)
  budget.likelihood(32,i)
  lexact=exact_kernel(gamma);ltable=table_kernel(interpolated);budget.check()
  differences.append(dict(target=i,analysis=row['analysis'],max_abs_logL_difference=float(np.max(abs(lexact-ltable))),
   argmax_u=float(masses[np.argmax(abs(lexact-ltable))])))
 passed=all(x['max_abs_logL_difference']<=config['gates']['table_sparse_abs_logL'] for x in differences)
 core.write_new(out/'backend_result.json',dict(status='BACKEND_AND_GENERATION_PASS_ON_SPARSE_NOMINAL14_DOMAIN' if passed else 'NEW_SCENARIO_TABLE_LOG_LIKELIHOOD_UNRESOLVED',
  scope='SPARSE_ENGINEERING_COMPOSITE_WITH_APPROVED_HISTORICAL_DIRECT_FLOW_EVIDENCE_NOT_POSTERIOR',
  harmonic_errors=errors,minimum_eigenvalue=minimum,table_likelihood_checks=differences,
  table_matrix_max_abs_difference_descriptive=float(np.max(abs(interpolated-gamma))),
  historical_evidence_sha256=plan['historical_evidence_sha256'],direct_evidence_kind=plan['failure']['direct_evidence_kind'],
  direct_numeric_maxima=None,direct_numeric_record_available=False,direct_comparisons_inferred_from_frozen_flow=True,
  new_ORF_evaluations=0,new_sky_points=0,new_draws=0,table_memory_estimate=table.memory_estimate,
  data_sha256=sha(out/'data.npz'),harmonic_nodes_sha256=sha(out/'harmonic_nodes.npz'),
  resources=budget.report(),global_ORF_error_certificate=False))
 return passed


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--request',type=Path,required=True);parser.add_argument('--request-sha256',required=True)
 args=parser.parse_args();plan=preflight();request,identity=validate_request(args.request,args.request_sha256,plan)
 if list(resource.getrlimit(resource.RLIMIT_CPU))!=request['CPU_limits']:raise RuntimeError('Controller pre-exec CPU limit required')
 for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
  if os.environ.get(key)!='1':raise RuntimeError('Single-thread environment required before imports')
 config=read(HERE/'config.json');campaign=Path(request['campaign']);out=campaign/request['job']['name'];out.mkdir(exist_ok=False)
 sys.path.insert(0,str(V2));sys.path.insert(0,str(ROOT/'src'))
 import numpy as np
 import run_nominal14 as core
 import runtime_adapter
 core.ACTIVE_OUTPUT_BUDGET=(campaign,config['budgets']['output_bytes'])
 budget=core.Budget(config['budgets'],previous=request['previous_CPU_seconds'],previous_values=request['previous_likelihood_values'],previous_by_target=request['previous_likelihood_by_target'])
 complete=False
 try:
  budget.check()
  if request['stage']=='backend':
   if not resume_table_likelihood(np,core,config,out,budget,plan):raise RuntimeError('Sparse likelihood gate unresolved')
  else:runtime_adapter.pilot(core,config,out,budget,Path(request['backend_path'])/'gates')
  budget.check();complete=True
 except Exception as exc:
  core.write_new(out/'worker_failure.json',dict(status='FAILED_NO_AUTOMATIC_RETRY',error=str(exc),traceback=traceback.format_exc(),resources=budget.report()))
  raise
 finally:
  unchanged=(source_hashes(config)==plan['source_sha256'] and sha(HERE/'config.json')==plan['config_sha256']
             and sha(ROOT/config['table_file'])==plan['table_sha256']
             and all(sha(ROOT/name)==value for name,value in plan['failure']['artifact_sha256'].items()))
  r=budget.report();within=r['combined_CPU_seconds']<=600 and r['peak_RSS_bytes']<=config['budgets']['RSS_bytes']
  core.write_new(out/'worker_end.json',dict(schema='C09_FRESH_WORKER_END_v4',status='WORKER_COMPLETED' if complete and unchanged and within else 'WORKER_FAILED',
   request_sha256=args.request_sha256,inputs_unchanged=unchanged,resources=r,CPU_final_child_exit_measured_by_controller=True))
  if not unchanged or not within:raise RuntimeError('Final worker input/resource guard failed')

if __name__=='__main__':main()
