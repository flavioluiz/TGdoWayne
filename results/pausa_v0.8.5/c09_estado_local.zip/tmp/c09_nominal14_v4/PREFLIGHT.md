# C09 nominal14 v4 — candidato, execução desabilitada

## Falha preservada e continuação limitada

O v3 concluiu os **12 workers harmônicos e salvou 192 Γ**. O processo de gates avançou pelos testes harmônicos e diretos, salvou `harmonic_nodes.npz` e `data.npz` e falhou no guard RSS imediatamente depois do construtor original `EvenThresholdCubicORF`. Pico do worker: **1.963.507.712 B**; soma conservadora com o parent: **1.995.341.824 B**. As falhas v2 e v3 continuam FAILED e seus arquivos não foram alterados.

O `execution_end.json` v3 fornece **149.10019599999998 s CPU**, **214.577.271.056 produtos reais**, **74.530.432 pontos de céu**, **zero valores de likelihood observados**, e uma reserva não consumida de **448 valores, 32 por ID**. O v4 herda o CPU final do controller, incluindo os filhos, não o valor parcial do relatório do gate.

O candidato retoma exclusivamente carregamento/validação dos arquivos, construção da mesma spline e os **448 valores de likelihood** pendentes. Não repete harmônicos, quadratura direta ou geração; não aumenta nenhum teto. As pequenas cópias byte-idênticas dos dois NPZ para a saída futura preservam a API de entrada do piloto v2. Nenhum arquivo de coeficientes de centenas de MiB será produzido: a tabela permanece em RAM.

## Evidência rigorosa, mas incompleta numericamente, dos diretos

O contrato preserva e verifica 44 artefatos históricos por SHA256: identidade/falha/end v3, request/end/falha do gate, dados e matrizes finas, além de recibos/end/cache dos 12 workers. Os 29 vínculos de fontes executadas v3 e seu config são reconferidos; a closure v4 possui 35 fontes/vínculos de leitura, além do config v4. `historical_evidence.json` contém os hashes completos.

A inferência de aprovação dos testes diretos usa estas premissas verificáveis no fluxo executado:

1. O worker v3 usa saída nova e escrita exclusiva. Não há `backend_result.json` numérico do gate.
2. O código congelado executa os dois casos diretos em duas resoluções e define `direct_pass` com os testes de refinamento e diferença harmônica, ambos ≤1e−7. NaN/Inf não satisfazem esses `<=`.
3. `if not direct_pass` escreve um resultado de falha e retorna **antes** de qualquer geração ou escrita de `data.npz`. Não há captura local que permita continuar depois desse retorno.
4. Os dados existem, e o traceback passa por `worker.py:134`, chamada `experiment_and_table(config,budget)`, até `run_nominal14.py` v2:155, o guard **após** construir a tabela. As fontes/requests/end permanecem vinculadas. Portanto o caminho que alcançou esse ponto passou pelo guard direto.
5. O receipt do gate cobra exatamente 74.530.432 pontos de céu e zero likelihood. O primeiro `budget.likelihood` fica depois da chamada que falhou; sua reserva nunca ocorreu no worker.

Isso sustenta a afirmação limitada **“as comparações diretas satisfizeram os critérios nesse fluxo congelado”**, sob a proveniência da execução registrada. Não fornece os valores complexos nem seus máximos. O campo `direct_numeric_maxima` é **null**, `direct_numeric_record_available=false`, e a origem é `FROZEN_SEQUENTIAL_CONTROL_FLOW_AND_TRACEBACK_NO_SAVED_NUMERIC_DIRECT_REPORT`. Nenhum `direct.json` foi fabricado. O novo backend só poderá usar essa evidência se ROOT aprovar explicitamente essa classe de reuso.

A busca read-only em registros C07 encontrou um candidato parcial para u=0,5, canal1, par(3,8), em `dense_construction.json`; não há ali o registro requerido u=0,995, par(0,11), nem o mesmo par de resoluções explicitado por registro. A validação de paridade usa outras entradas. Não se usaram esses números como substitutos dos gates C09.

Os números harmônicos, ao contrário, permanecem nas matrizes arquivadas: o futuro worker reconfere hash/forma/dtype/bytes de massa, Hermiticidade/PSD e diferenças H00/H01/H11 diretamente dos 12 caches pequenos, sem avaliar ORFs. Confere também que `harmonic_nodes.npz` coincide bitexact com os quatro canais H11. O fato de esses dados estarem disponíveis não aprova o posterior.

## Mesma spline, construção por canal

A classe candidata herda as funções `location` e `__call__` de `CertifiedCubicORF`. Preserva `.nodes`, `.matrices`, `.coordinate_name`, `.coordinate`, `.alpha`, `.coeff`, `.fallback`, `.bernstein_minimum_eigenvalue` e `.threshold_derivative_condition`.

No uso físico, `x=−sqrt((1−u)*(1+u))=−β`, crescente de −1 a0. A primeira extremidade mantém `not-a-knot`; a última mantém derivada zero, a condição par no limiar β=0. Não se troca d/dβ por um eixo diferente. A chamada SciPy por canal mantém dimensão de canal unitária `(N,1,P,P)` e o mesmo `bc_type=('not-a-knot',(1,zeros((1,P,P))))`.

Para cada canal, usam-se exatamente as expressões `c[3−j]*width[:,None,None,None]**j`, j=0…3. A alocação final continua `(N−1,4,K,P,P)`. O temporário SciPy `c` é liberado antes de montar Bernstein em blocos de 64 intervalos daquele canal. Os quatro controles são `a0`, `a0+a1/3`, `a0+2*a1/3+a2/3` e `a0+a1+a2+a3`, com as mesmas operações/ordem.

**Fallback é global por intervalo.** Primeiro se agrega o mínimo de Bernstein de todos os canais. Se qualquer canal tem mínimo <−1e−12, linearizam-se todos os canais naquele intervalo com os mesmos coeficientes v2. Não se aplicam fallbacks independentes por canal. O loader físico ainda exige zero fallback, como no runner congelado. Não há clipping de autovalores, jitter ou nova regra de interpolação.

A validação de finitude/Hermiticidade/PSD de entrada é tiled e ocorre sob estimativa prévia de orçamento. As chamadas SciPy independentes resolvem o mesmo problema linear por componente e as mesmas condições de contorno. **Igualdade bitexact foi observada nos testes TOY descritos abaixo; não se afirma uma comparação bitexact já executada com a tabela real.** Versões Python/NumPy/SciPy e fontes estão vinculadas ao preflight.

## Adaptação funcional do piloto v2

Chamar diretamente o piloto v2 usaria sua fábrica antiga e repetiria o pico de memória. `runtime_adapter.pilot` substitui explicitamente, no objeto módulo desse processo, `core.experiment_and_table` pela fábrica local durante `core.pilot(...)`; um `finally` restaura a referência anterior, inclusive após falha. O arquivo e a matemática do piloto v2 permanecem intactos, incluindo GK/erro do numerador, contornos, raízes, prioridades e contadores.

A fábrica local rehasha o arquivo antes de carregar e imediatamente após a construção. O worker e o controller reconferem ao final config, fontes, tabela e todos os arquivos históricos vinculados. O backend/piloto em processo novo não conserva o construtor antigo na memória. Nenhuma alteração é feita a fontes congeladas em disco.

## Contagem e orçamento

| Quantidade | Ancestral v3 | Nova continuação backend | Cumulativo |
|---|---:|---:|---:|
| Produtos reais ORF | 214.577.271.056 | 0 | 214.577.271.056 |
| Pontos de céu | 74.530.432 | 0 | 74.530.432 |
| Γ avaliadas novamente | — | 0 | nenhuma repetição v4 |
| Dados/controles gerados novamente | — | 0 | nenhuma repetição v4 |
| Likelihood avaliada | 0 | 448 | 448 |
| CPU conhecido | 149,100196 s | não medido | teto600 s |

Restam nominalmente **450,899804 s CPU**, antes dos novos imports/preflight/controller/worker, **35.422.728.944 reais** e **5.469.568 pontos de céu**. Essas duas últimas margens não autorizam novos cálculos: o executor v4 não oferece esse trabalho.

A reserva administrativa de 448 valores v3 permanece no histórico. Como o receipt e o fluxo provam zero execução dessa etapa, a nova autorização deve permitir **transferi-la à mesma etapa pendente**; não se declara custo físico perdido zero para ORF/céu/CPU, nem se inventam 448 avaliações anteriores. Após backend PASS, o piloto herda 448 e32/ID do end final, deixando59.968/ID e839.552 valores adicionais; limite efetivo total840.000 sob teto global1 M e60.000 por ID. Sem aprovação dessa transferência, a continuação fica bloqueada.

Tetos científicos/operacionais inalterados:600 s CPU,1,5 GiB RSS,1.400.000.000 B de estimativa numérica,250 G reais,80 M céu,1 M likelihood/60 k por ID,20 MiB de saída, lotes4/32 e um thread BLAS. O orçamento de saída cobre a nova campanha; a aritmética de metadados também registra o volume dos diretórios históricos preservados. Não se serializa o coeficiente307 MB.

O controller usa stdlib, reserva antes do filho, define `RLIMIT_CPU=(floor(restante),floor(restante)+1)` no `preexec` e mede o CPU final de cada filho com `RUSAGE_CHILDREN`, incluindo imports/exit. Soma seu próprio `time.process_time()` desde startup ao histórico. O guard RSS também exige soma conservadora do pico do controller com o maior pico do novo worker ≤1,5 GiB. Não há retry automático.

O mesmo limite de telemetria anterior fica explícito: os samples ancestrais não incluem suas próprias serializações finais/exit, e o controller novo só mede a si mesmo até os hashes finais; seus últimos bytes/exit precisam de observação externa para uma conta completa. Todos os novos exits de filhos são medidos pelo controller. Não se atribui zero inventado ao restante não observado.

## Memória prospectiva

Para N8336/K4/P12:

| Componente | Bytes |
|---|---:|
| Matrizes caller | 76.824.576 |
| Coeficientes finais conjuntos | 307.261.440 |
| `c` de um canal | 76.815.360 |
| Allowance construção =8×`c` de um canal | 614.522.880 |
| Checks tiled | 1.794.048 |
| Eixos/mínimos | 333.448 |
| Reserva de bibliotecas | 67.108.864 |
| **Estimativa simultânea total** | **1.067.845.256** |

Com mais128 MiB para overhead do worker/controller, a projeção fica **1.202.062.984 B**, abaixo de1.610.612.736 B, com408.549.752 B de margem. O coeficiente de um canal está incluído no allowance8×; não é somado de novo ao total.

Esse allowance é deliberadamente maior que a contagem que subestimou o v3. Ainda é **estimativa**, não benchmark do construtor real, garantia RSS nem limite OS duro. O allocator/BLAS pode reter buffers. O processo futuro será observado pelos mesmos guards; qualquer falha permanece falha, sem elevar automaticamente o teto. As verificações de pré-orçamento evitam criar grandes coeficientes/temporários antes de aceitar a estimativa; inputs reais já são arrays NPZ caller. O custo de referências Python/metadata é pequeno, mas não é tratado como prova de RSS.

## Autorização prospectiva e testes

Schema requerido: `ROOT_C09_NOMINAL14_TABLE_CONTINUATION_APPROVAL_v4`. Exige aprovação explícita de estágio, hashes exatos do config/source/table, `historical_evidence_sha256`, os mesmos budgets e:

- `approve_control_flow_direct_gate_reuse=true`;
- `carry_unspent_448_likelihood_reservation=true`;
- `repeat_scope=RESUME_TABLE_AND_448_LL_WITH_V3_GAMMA_DATA_NO_NEW_ORF_SKY_DRAWS`.

O hash de evidência é SHA256 do JSON canônico ordenado do payload, excluído o próprio campo `evidence_sha256`; o hash do arquivo formatado é separado no manifest. Nenhuma autorização é criada aqui. O piloto ainda exige hashes do novo backend PASS revisado e do seu end final. Default `execution_enabled=false`.

**12 testes novos TOY passaram.** Cobrem igualdade bitexact whole/perchannel para matrizes reais e complexas, coordenadas beta/alpha, tiles1/3/64, mínimos/coeff/valores/location; fallback global disparado por um só canal; rejeições/budget antes de eig/coef; hashes antes/depois da carga TOY; binding/restauração da fábrica do piloto; autorização do tipo de evidência; ledger ancestral; ausência de entradas para nova física e aritmética de memória. Última execução:1,551565 s CPU,89.587.712 B RSS. As duas execuções motivadas por ajustes finais somaram3,166898 s CPU, abaixo de30 s/128 MiB. Não se repetiram os seis testes antigos de kernels/adaptadores.

Nenhuma tabela real, banco, ORF, céu, likelihood, draw ou posterior foi executado/carregado numericamente nesta preparação. As operações reais foram somente leitura de metadata e streaming de hashes. O pacote é candidato técnico para revisão; os gates esparsos de likelihood e qualquer posterior continuam pendentes.
