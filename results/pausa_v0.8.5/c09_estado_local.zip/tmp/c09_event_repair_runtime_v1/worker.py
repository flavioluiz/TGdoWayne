"""ROOT-authorized D1 worker; no physics is reachable before WorkerGuard validation."""
from pathlib import Path
import argparse,hashlib,io,json,sys,traceback,warnings
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'tmp/c09_d1_supervisor_v1'))
from supervisor import WorkerGuard


def read(path):return json.loads(Path(path).read_text())
def digest_bytes(value):return hashlib.sha256(value).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--request',type=Path,required=True);p.add_argument('--request-sha256',required=True)
    args=p.parse_args();guard=WorkerGuard.from_request(args.request,args.request_sha256)
    # All scientific imports occur after source/input/config/authorization/limit checks.
    sys.path[:0]=[str(ROOT/'src'),str(ROOT/'tmp/c09_nominal14_v2'),str(ROOT/'tmp/c09_nominal14_v4'),
                 str(ROOT/'tmp/c09_event_repair_v1'),str(ROOT/'tmp/c09_integrator'),str(ROOT/'tmp/c09_contour'),str(HERE)]
    import numpy as np
    from inference.model import experiment
    from kernels import ConditionalKernel
    from runtime_adapter import load_table
    from engine import target_engine
    warnings.simplefilter('error')
    params=guard.parameters;runtime=read(ROOT/params['runtime_config']);config=read(ROOT/runtime['nominal_config'])
    table=None;reports=[];caches=[];completed=False
    try:
        guard.checkpoint()
        if runtime['schema']!='C09_D1_RUNTIME_CONFIG_v1' or runtime['physical_execution_enabled_by_default'] is not False:
            raise ValueError('immutable disabled-default runtime config required')
        # Hashes are checked both by the supervisor and again before each NPZ load.
        data_path=ROOT/runtime['data_file']
        from supervisor import sha
        if sha(data_path)!=guard.plan['bindings'][runtime['data_file']]:raise ValueError('data changed before decoding')
        with np.load(data_path,allow_pickle=False) as f:
            expected={'q':(14,4,12),'x_physical':(14,4,10),'x_gaussian':(14,4,10),'truth_u':(14,),'target':(14,)}
            if set(f.files)!=set(expected):raise ValueError('data member names differ')
            data={k:f[k] for k in expected}
        if any(data[k].shape!=s or not np.isfinite(data[k]).all() for k,s in expected.items()):raise ValueError('data shape/finitude differs')
        if not np.array_equal(data['target'],np.arange(14)) or not np.array_equal(data['truth_u'],[r['fixed_truth_u'] for r in config['rows']]):
            raise ValueError('fixed nominal14 targets/truths differ')
        if sha(data_path)!=guard.plan['bindings'][runtime['data_file']]:raise ValueError('data changed after decoding')
        e=experiment(read(ROOT/config['experiment_config']))
        table=load_table(ROOT/config['table_file'],config['table_sha256'],guard,expected_shape=(8336,4,12,12))
        guard.checkpoint();anchor=table(np.array([config['anchor_mass']]))[0]
        sources_sha=hashlib.sha256(json.dumps(guard.plan['bindings'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
        for row in config['rows']:
            target=row['id'];holder={};entry_prefix='target_'+str(target).zfill(2)
            try:
                guard.checkpoint()
                historical_path=ROOT/runtime['historical_pilot_directory']/('target_'+str(target).zfill(2)+'.json')
                historical=read(historical_path)
                observed={k:data[k][target:target+1] for k in ('q','x_physical','x_gaussian')}
                kernel=ConditionalKernel(e,row,observed,anchor)
                identity={'target_id':target,'data_sha256':guard.plan['bindings'][runtime['data_file']],
                          'model_sha256':digest_bytes(json.dumps(row,sort_keys=True,separators=(',',':')).encode()),
                          'table_sha256':config['table_sha256'],'sources_sha256':sources_sha}
                report,cache,cells=target_engine(row=row,config=config,runtime_config=runtime,table=table,kernel=kernel,
                       historical=historical,identity=identity,guard=guard,output=guard.output,
                       on_cache_ready=lambda value:holder.update(cache=value))
                # Archived arrays are sufficient to replay event arithmetic; no matrices are duplicated.
                stream=io.BytesIO();np.savez_compressed(stream,cells=cells)
                guard.write_bytes(entry_prefix+'_cells.npz',stream.getvalue())
                report['historical_report_sha256']=guard.plan['bindings'][str(historical_path.relative_to(ROOT))]
            except (ValueError,RuntimeError,ArithmeticError,MemoryError) as exc:
                report={'schema':'C09_D1_TARGET_FAILURE_v1','target':target,'status':'UNRESOLVED_NO_AUTOMATIC_RETRY',
                        'reason':type(exc).__name__+': '+str(exc),'traceback':traceback.format_exc(),
                        'logL_PIT_interval':[0,1],'historical_result_preserved':True,'C09_complete':False}
                # Numerical failure is preserved; resource guard decides whether other IDs may proceed.
            cache=holder.get('cache')
            if cache is not None:
                ordered=sorted((float(np.frombuffer(bytes.fromhex(k),dtype=np.float64)[0]),v)for k,v in cache.values.items())
                u=np.array([v[0]for v in ordered]);ell=np.array([v[1]for v in ordered])
                stream=io.BytesIO();np.savez_compressed(stream,u=u,log_likelihood=ell)
                guard.write_bytes(entry_prefix+'_cache.npz',stream.getvalue())
                guard.write_json(entry_prefix+'_cache_identity.json',{'identity':cache.identity,'identity_sha256':cache.identity_sha256,
                    'stored_values':len(u),'shadow_reserved_values':cache.target_ledger.charged,
                    'shadow_failed_reservations':[r for r in cache.target_ledger.records if r['status']!='COMPLETE'],
                    'canonical_reserved_for_target':guard.report()['stage_likelihood_by_target'][str(target)],
                    'shadow_counts_not_added_to_canonical':True})
            guard.write_json(entry_prefix+'.json',report);reports.append({'target':target,'status':report['status']})
            print(json.dumps(reports[-1]),flush=True)
        guard.write_json('result.json',{'schema':'C09_D1_RUNTIME_RESULT_v1','status':'ALL14_RECORDED_NOT_C09_COMPLETE',
            'targets':reports,'physical_backend_margin_configured':runtime['backend_probability_margin_by_target'] is not None,
            'resources':guard.report(),'no_new_ORF':True,'no_new_sky':True,'no_new_draws':True,'C09_complete':False})
        guard.checkpoint();completed=True
    except BaseException as error:
        # Best effort final failure payload; reserved receipt remains available after payload exhaustion.
        try:guard.write_json('failure.json',{'status':'FAILED_NO_RETRY','error':type(error).__name__+': '+str(error),
              'traceback':traceback.format_exc(),'recorded_targets':reports,'remaining_targets':[i for i in range(14)if i not in [r['target']for r in reports]],
              'remaining_probability_interval':[0,1],'resources':guard.report()})
        except BaseException:pass
        raise
    finally:
        guard.finish('COMPLETED' if completed else 'FAILED',{'recorded_targets':reports,'C09_complete':False})

if __name__=='__main__':main()
