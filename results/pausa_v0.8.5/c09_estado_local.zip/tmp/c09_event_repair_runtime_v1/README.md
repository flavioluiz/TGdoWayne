# D1: runtime prospectivo com likelihood e referências de massa

**Pronto para leitura e autorização ROOT, ainda sem execução física.** O worker implementa o mesmo nominal14 com nuisances conhecidas e mantém os 13 resultados v4 não resolvidos. Não conclui C09 nem realiza SBC. Nenhuma ORF, likelihood real, banco, geração Monte Carlo ou leitura de conteúdo binário/decodificação de NPZ científico foi executada nesta preparação.

O núcleo puro em `tmp/c09_event_repair_v1` permanece congelado (manifesto `116f99a1b22f43bddad0bf938ef0fb309f13aef811d7bf5475e632091ca1cfd8`), com 26 TOYs e revisão independente. Este pacote usa suas interfaces e acrescenta o worker, a referência direta de massa e uma implementação equivalente mais rápida da convolução de momentos. Não modifica fontes C07, C08 ou nominal14 v4.

## Arquivos para a revisão

| Arquivo | Papel |
|---|---|
| `preflight.json` | Plano do supervisor, 114 bindings de fontes/entradas, histórico cumulativo, todos os tetos e execução desabilitada por padrão. |
| `runtime_config.json` | Regras D1, tolerâncias, referências históricas e política de backend `None`. |
| `metadata_preparation.json` | Como o plano foi preparado, quais hashes binários foram herdados de recibos e a projeção de custo. |
| `worker.py` | Valida autorização/limites antes de importar NumPy, carrega uma tabela/dado, processa os 14 IDs e salva resultados/caches. |
| `engine.py` | Grade L0/L1, GL32/64 e controles, envelopes por célula, refinamento e referência final N/A/Z. |
| `mass_reference.py` | QUADPACK/GK21 escalar na CDF da priori, regiões contíguas e erros N/A/Z separados. |
| `surrogate_event.py` | Evento exato somente do PCHIP finito, incluindo constantes/platôs; não declara topologia física. |
| `polynomial_fast.py`, `cells_runtime.py` | Mesmos polinômios/traços, convolução simétrica por BLAS; adapter puro copiado com import explícito dessa função. |
| `batched_cache.py` | Cada lote concluído de até32 valores entra no cache antes do próximo lote, permitindo preservação após falha. |
| `deltas/` | Deltas do engine desde a leitura anterior ROOT, incluindo o cache por lote e a separação do resultado da tabela. |

O supervisor externo é `tmp/c09_d1_supervisor_v1/supervisor.py`, SHA `ab65e0868700b7d74f3f919cbfe6a6ac8846da1d16cdbc8a2550c3d16b609946`. Seu manifesto `33130c0da9f8f2add1f23ac661c38a917136784925b67e5dd54c8cfda3ef3cbd` e o parecer ROOT registram 11 TOYs e um teste de negativa de encerramento. Ele fornece `WorkerGuard`, quotas de escrita e recibo externo incluindo startup/exit do worker. O supervisor usa somente biblioteca padrão.

## Entrada e execução futura

`build_metadata.py` preparou os arquivos uma única vez, sem sobrescrever. Ele lê fontes/JSON e tamanhos de arquivos; os três hashes NPZ vêm dos recibos já revisados, não de nova abertura dos binários. A verificação dos bytes reais permanece para o supervisor no lançamento. O histórico de saída, contado conservadoramente nos quatro diretórios de resultados v2/v3/v4/piloto, soma 2.543.953 B; histórico mais reserva nova12 MiB soma 15.126.865 B, abaixo de20 MiB.

O plano utiliza um worker fresco e sequencial para todos os IDs, uma tabela e BLAS1. A aprovação deve conter o SHA exato do plano, o diretório novo de saída, modo D1, escopo e `automatic_retry=false`, conforme o schema do supervisor. O pacote não cria uma autorização ROOT.

```sh
# Verificação futura pelo ROOT; este comando ainda não foi executado para o plano físico.
.venv/bin/python tmp/c09_d1_supervisor_v1/supervisor.py preflight \
  --plan tmp/c09_event_repair_runtime_v1/preflight.json

# Somente após autorização ROOT explícita, ligada ao SHA do plano e à nova saída:
.venv/bin/python tmp/c09_d1_supervisor_v1/supervisor.py execute \
  --plan tmp/c09_event_repair_runtime_v1/preflight.json \
  --authorization /caminho/da/autorizacao_ROOT.json \
  --output /caminho/novo/para/a_execucao
```

O caminho absoluto canônico do repositório compõe o plano atual. Mover/integrar as fontes exige novos bindings e revisão do plano; não reapresentar o SHA histórico como se cobrisse os caminhos novos.

## Integração e reuso sem crédito fictício

As observações e o nominal14 são os originais. O loader v4 reconstrói a mesma interpolação por canal dos 8.336 nós congelados e confere os SHA antes/depois; não faz quadratura de Γ. Os 16 oráculos harmônicos e sua evidência histórica ficam vinculados, sem nova avaliação ou alegação de exatidão analítica.

A sequência por ID é L1 (com L0 contido), GL32/64 e arestas da densidade, scouts antigos e 1.024 sondas beta novas separadas do ajuste. Cada valor ausente é cobrado antes de sua chamada e avaliado em lote de até32. Os ledgers do núcleo puro são espelhos de controle; não são somados ao contador canônico do supervisor. A versão histórica não armazenou esses valores completos: sua primeira reavaliação é trabalho novo.

As referências históricas de logZ, CDF, momentos e brackets podem ser reutilizadas porque pertencem à mesma função e estão salvas em JSON. Antes desse reuso, o runtime confere identidade do ID/modelo/prior e recompõe GL32/64 e logZ dos PCHIPs, exigindo concordância≤10⁻¹⁰ com os valores antigos. Os nós GL devem coincidir bit a bit com o plano original. Essa validação não reaproveita as aprovações antigas de evento/forma, que precisam de resultados novos.

A densidade usa alpha=asin(u) com o Jacobiano da priori, ou v=F_prior(u) na referência independente. O evento usa x=−beta. `CanonicalCoordinates` preserva cortes/knots originais, sem drift por conversão inversa. Os coeficientes são divididos algebricamente na fração local, sem refit.

A0 usa a densidade CN; A_G usa quatro blocos normais; os sete B, inclusive B_CN, usam um bloco normal da compressão. Médias continuam variáveis nas rotas fixed e diagonal. A implementação rápida só reúne os pares i,j e j,i da convolução, com a identidade de traço `M_ji=M_ij^T`. Não muda a densidade ou a distribuição científica.

Envelopes são confrontados com valores já cobrados dos controles; violação produz falha, sem aumentar a margem. O allowance1e−9 de logL é uma escolha prospectiva operacional, não uma prova de arredondamento. Depois, as células ambíguas são subdivididas pela massa superior, dentro do orçamento. A massa superior usada na seleção vem da medida exata da priori vezes a envoltória exponencial, limitada pelo Z superior histórico na mesma escala.

A referência final integra somente as uniões de regiões inside e ambiguous com GK21 escalar; não executa uma GK para cada célula. Numerador N, massa ambígua A e denominador Z têm erros separados. As referências precisam intersectar as restrições das células e da massa total. A soma dos erros de quadratura é operacional, e warnings/falha de convergência interrompem o caso.

## Separação entre tabela salva e probabilidade física

`backend_probability_margin_by_target` está **None**. O runtime não converte o máximo esparso de delta logL em erro de probabilidade. Portanto o intervalo físico retido continua `[0,1]` até existir evidência probabilística aprovada e novo plano vinculado a ela.

O subregistro `saved_table_result` pode, independentemente, fechar o evento da tabela sob seus controles numéricos. Ele exige os gates originais de normalização/CDF/brackets/momentos/KL/forma/warnings, massa ambígua≤0,001, quadratura≤0,00025, diferença entre representações≤0,0005 e soma≤0,002. A comparação L0/L1 é de probabilidades dos surrogates separados; não prova uniformidade da função física. A tabela recebe o rótulo operacional explícito, jamais um certificado uniforme de ORF ou ponto flutuante.

As prioris D1 têm suporte superior1. Alterar o suporte para0,8, previsto em D2, requer novas medidas normalizadas, integradores e identidades; não é implementado por esta configuração.

## Recursos e persistência

Mantêm-se **350.000 LL novas**, **25.000 por ID**, **270 s CPU adicionais**, CPU cumulativa≤600 s, RSS soma conservadora controller/worker≤1.610.612.736 B, arrays estimados≤1.400.000.000 B, saída nova≤12 MiB e cumulativa≤20 MiB. Histórico: 210.588 LL, 296,087524 s CPU, 214.577.271.056 produtos harmônicos e74.530.432 pontos de céu. Não há nova reserva ORF/céu/geração.

Os 4.798 valores restantes após a grade fixa por ID são compartilhados pelo limiar, subdivisões e referências. O engine mantém 2.048 valores dessa folga para referências ao planejar os pares de novos centros; não garante que GK caberá nessa reserva. O guard central interrompe qualquer extrapolação. Nenhum teto é aumentado.

O cache retém cada lote concluído. Ao terminar ou falhar um ID, salva os valores existentes em NPZ e sua identidade, com reservas falhas separadas. Uma chamada interrompida pode não ter produzido valores aproveitáveis; ela não vira hit de cache. Resultados/células ficam em arquivos novos. CPU/RSS esgotadas impedem novo cálculo; a escrita limitada de parciais e recibos continua disponível durante a margem de encerramento. Um hard kill pode impedir o recibo exato: o supervisor conserva então toda a reserva superior e o consumo fica explicitamente desconhecido dentro dela. Não declarar zero e não retomar automaticamente.

O worker confere recursos a cada lote, célula e integrando. O supervisor aplica RLIMIT_CPU/FSIZE, monitora o processo próprio e mede o child após exit; sua soma de RSS é conservadora e não uma garantia de hard limit do SO. Os recibos declaram o pequeno intervalo de serialização/exit do controller depois da amostra. Todas as falhas históricas são preservadas.

## Testes e custo sintético

`toy_validation_attempt4.json`: **cinco testes passaram**, incluindo quatro combinações sintéticas de modelo/prior no engine, três prioris na GK, evento constante, backend ausente, equivalência complexa dos momentos contra a versão congelada/traços e retenção de cache após falha do segundo lote. Não foi executado o worker físico ou o plano D1. O supervisor tem sua suíte independente.

Os benchmarks usaram somente matrizes sintéticas de dimensão4×12 e10 formas, sem dados reais. Trinta e duas células por implementação custaram0,049653 s (convolução congelada) e0,012014 s (pares/BLAS), com equivalência verificada. O benchmark por rota, 16 células cada, projeta **34,37 s** para os envelopes iniciais do nominal14: seis A0, um A_G e sete B. O tempo medido dessa rodada foi apenas0,016253 s; os34,37 s são extrapolação.

Somando a taxa histórica de LL e25 s de setup, a projeção para282.828 valores fixos é **246,09 s** adicionais; para350.000 valores é **290,44 s**, antes do custo adicional de envelopes refinados. O teto continua270 s. A likelihood vetorial pode ter custo diferente dos GK escalares históricos, mas não foi medida fisicamente nesta preparação. O candidato pode terminar parcialmente pelo guard; não se promete consumir toda a reserva ou resolver14 casos.

Os históricos de fontes/testes permanecem em `history/`. A tentativa3 de testes abortou antes dos imports de teste porque um helper de metadados misturou caminhos relativos/absolutos e não atualizou o preflight; o guard de SHA corretamente rejeitou o engine alterado. O helper foi corrigido, o aborto preservado e a tentativa4 passou. Não houve falha científica nem execução real escondida nesse episódio.
