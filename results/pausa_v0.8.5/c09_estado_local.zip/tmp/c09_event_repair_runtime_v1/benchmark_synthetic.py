"""Thirty-two synthetic 4x12/10-form cells per method, never real data or ORF."""
from pathlib import Path
import json,resource,sys,time
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT/'tmp/c09_event_repair_v1'),str(HERE)]
from polynomial_fast import quadratic_moment_coefficients as fast
from d1.polynomial import quadratic_moment_coefficients as reference,compress_coefficients,evaluate
from d1.envelope import normal_envelope

def main():
    p=HERE/'synthetic_cost.json'
    if p.exists():raise FileExistsError(p)
    v=np.arange(4*4*12*12).reshape(4,4,12,12)
    a=np.sin(.13*v)+1j*np.cos(.07*v);c=(a+a.swapaxes(-1,-2).conj())*.00001;c[0]+=2*np.eye(12)
    H=np.zeros((10,12,12));H[np.arange(10),np.arange(10),np.arange(10)]=1
    rows=[]
    for name,fn in [('frozen_convolution',reference),('paired_BLAS',fast)]:
        started=time.process_time()
        for _ in range(32):
            mu,sigma=fn(c,H);mu,sigma=compress_coefficients(mu,sigma,np.full(4,.25))
            bound=normal_envelope(mu,sigma,np.zeros((1,10)),0.,roundoff_allowance=1e-9)
            if not np.isfinite([bound.lower,bound.upper]).all():raise RuntimeError('synthetic envelope unresolved')
        cost=time.process_time()-started
        rows.append({'method':name,'cells':32,'CPU_seconds':cost,'CPU_per_cell':cost/32,
                     'projected_8335_cells_times_14_seconds':cost/32*8335*14,'projection_not_measured':True})
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)
    result={'schema':'C09_D1_SYNTHETIC_ENVELOPE_COST_v1','rows':rows,'RSS_peak_bytes':rss,
      'dimension':{'frequencies':4,'pulsars':12,'quadratic_forms':10},'predeclared_iterations':32,
      'predeclared_CPU_cap':10,'predeclared_RSS_cap':536870912,'physical_data':False,'physical_LL':0,'ORF':0,'bank':0,'MC':0}
    result['within_predeclared_caps']=sum(x['CPU_seconds'] for x in rows)<=10 and rss<=536870912
    with p.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
