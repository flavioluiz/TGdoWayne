import unittest
from pathlib import Path
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'tmp/c09_event_repair_v1'),str(ROOT/'tmp/c09_event_repair_runtime_v1')]
from d1.polynomial import quadratic_moment_coefficients as reference,evaluate
from polynomial_fast import quadratic_moment_coefficients as candidate

class FasterPolynomial(unittest.TestCase):
    def test_dense_complex_hermitian_coefficients_against_reference_and_traces(self):
        # Deterministic arrays; no PTA data, draws or physical covariance.
        v=np.arange(4*4*12*12,dtype=float).reshape(4,4,12,12)
        a=np.sin(v*.13)+1j*np.cos(v*.07)
        c=(a+a.swapaxes(-1,-2).conj())*.001
        c[0]+=2*np.eye(12)
        v=np.arange(10*12*12,dtype=float).reshape(10,12,12)
        h=np.sin(v*.17)+1j*np.cos(v*.21)
        H=(h+h.swapaxes(-1,-2).conj())/24
        mr,sr=reference(c,H);m,s=candidate(c,H)
        np.testing.assert_allclose(m,mr,rtol=2e-13,atol=2e-13)
        np.testing.assert_allclose(s,sr,rtol=2e-13,atol=2e-13)
        for t in (0,.3,.7,1):
            C=evaluate(c,t)
            direct=np.array([[[np.trace(x@block@y@block).real for y in H]for x in H]for block in C])
            np.testing.assert_allclose(evaluate(s,t),direct,rtol=2e-13,atol=2e-13)

if __name__=='__main__':unittest.main()
