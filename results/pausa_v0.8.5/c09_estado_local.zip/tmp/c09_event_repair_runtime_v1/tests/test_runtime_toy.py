import math
from pathlib import Path
import sys
import unittest
from types import SimpleNamespace
import numpy as np
from scipy.interpolate import PchipInterpolator
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'tmp/c09_event_repair_v1'),str(ROOT/'tmp/c09_event_repair_runtime_v1'),
               str(ROOT/'tmp/c09_integrator'),str(ROOT/'tmp/c09_contour')]
from integrator import Posterior1D,MassPrior,EvaluationBudget
from pchip_density import PositivePchipCDF
from d1.measure import Prior,CanonicalCoordinates,u_to_x
from mass_reference import DirectUnionMass,historical_denominator
from surrogate_event import probability
from engine import target_engine

class ToyGuard:
    def __init__(self):self.values=0;self.calls=0
    def reserve(self,n,target):
        if self.values+n>25000:raise RuntimeError('toy ceiling')
        self.values+=n;self.calls+=1
    def checkpoint(self):pass

class ToyTable:
    def __init__(self):
        self.nodes=np.array([0.,.6,1.]);self.alpha=u_to_x(self.nodes)
        self.coeff=np.zeros((2,4,1,1,1),complex);self.coeff[:,0]=1
    def __call__(self,u):return np.ones((len(u),1,1,1),complex)

class ToyKernel:
    def __init__(self,name):
        self.name=name;self.covariance=SimpleNamespace(pg=np.ones(1),noise=np.zeros((1,1,1)))
        self.e={'H':np.ones((1,1,1)),'weights':np.ones(1)}
        self.data={'q':np.array([[[.3+.2j]]]),'x_gaussian':np.array([[[.7]]]),'x_physical':np.array([[[.13]]])}
        self.anchor_cov=np.ones((1,1,1))
    def __call__(self,gamma):
        if self.name=='A0_CN':value=-math.log(math.pi)-.13
        else:
            y=.7 if '_G' in self.name else .13
            value=-.5*(math.log(2*math.pi)+(y-1)**2)
        return np.full(len(gamma),value)


def fixture(name,kind):
    kernel=ToyKernel(name);table=ToyTable();prior=MassPrior(kind)
    ell=lambda u:kernel(table(u))
    nodes={};summaries=[];densities=[]
    edges=[0,.0001,.001,.01,.05,.25,.5,.75,.9,.99,1]
    for order in (32,64):
        d=Posterior1D(ell,prior,order=order,panel_edges=edges,budget=EvaluationBudget(maximum_values=10000,maximum_cpu_seconds=20))
        nodes[str(order)]=d._u.tolist();summaries.append(d.summary());densities.append(PositivePchipCDF(d))
    value=float(ell(np.array([.5]))[0]);mean=.5 if kind=='uniform_u' else (2/3 if kind=='uniform_u_squared' else .999/math.log(1000))
    second=1/3 if kind=='uniform_u' else (.5 if kind=='uniform_u_squared' else (1-1e-6)/(2*math.log(1000)))
    hist={'target':0,'analysis':name,'prior':kind,'GL_summaries':summaries,'PCHIP_logZ':[d.logz for d in densities],
       'reference_logZ':value,'reference_relative_error_estimate':1e-12,'reference_warnings':[],
       'reference_moments':{'mean_u':mean,'second_moment_u':second,'kl_posterior_to_prior':0},
       'CDFs':[{'u':.2,'reference':float(prior.cdf(.2))}],
       'quantile_brackets':[{'width':.0001,'reference_confirms':True}],
       'status':'SYNTHETIC_HISTORICAL_FIXTURE','logL_PIT_operational_interval':[0,1]}
    config={'quadrature':{'orders':[32,64],'panel_edges_u':edges,'GL_mass_nodes':{kind:nodes},
       'scout_u_coarse':np.linspace(0,1,9).tolist(),'scout_u_fine':np.linspace(0,1,17).tolist(),
       'reference_epsabs_scaled':1e-9,'reference_epsrel':1e-8,'reference_subinterval_limit':150},
       'budgets':{'batch_size_likelihood':32},'gates':{'delta_logZ':.001}}
    runtime={'algorithm':{'envelope_roundoff_allowance_logL':1e-9,'new_validation_count':16,
       'historical_same_function_abs_tolerance':1e-10,'reserve_reference_values':2048,'maximum_depth':0,'ambiguity_goal':.0008},
       'historical_backend_evidence_accepted_for_domain':False,'backend_probability_margin_by_target':None}
    row={'id':0,'analysis':name,'prior':kind,'fixed_truth_u':.5}
    identity={'target_id':0,**{k:'c'*64 for k in ('data_sha256','model_sha256','table_sha256','sources_sha256')}}
    return row,config,runtime,table,kernel,hist,identity

class RuntimeToy(unittest.TestCase):
    def test_direct_scalar_GK_in_prior_measure_all_three_priors(self):
        for kind in ('uniform_u','uniform_u_squared','log_uniform_u'):
            prior=Prior(kind);ref=DirectUnionMass(lambda u:np.zeros_like(u),prior,log_shift=0,scale_identity='s',
                epsabs=1e-11,epsrel=1e-11,limit=150,checkpoint=lambda:None)
            a=.2;b=.9;r=ref(((a,b),));exact=float(prior.cdf(b)-prior.cdf(a))
            self.assertLessEqual(r.lower,exact);self.assertGreaterEqual(r.upper,exact)
            self.assertEqual(ref.calls[0]['quad_neval'],21)
            self.assertEqual(ref.warning_messages,[])

    def test_surrogate_plateau_and_oscillation_are_not_physical_certificates(self):
        x=np.linspace(-1,0,17);coord=CanonicalCoordinates([-1,0],[0,1])
        spline=PchipInterpolator(x,np.zeros_like(x))
        out=probability(spline,lambda u:u,0,canonical_coordinates=coord)
        self.assertEqual(out['probability'],1)
        self.assertIn('NOT_PHYSICAL',out['scope'])
        self.assertEqual(probability(spline,lambda u:u,-1,canonical_coordinates=coord)['probability'],0)

    def test_end_to_end_callback_engine_keeps_unknown_physical_gate(self):
        for name,kind in (('A0_CN','uniform_u'),('A_G','uniform_u_squared'),
                          ('B_CN_full_variable','log_uniform_u'),('B_G_diagonal_fixed','uniform_u')):
            row,config,runtime,table,kernel,hist,identity=fixture(name,kind);guard=ToyGuard()
            report,cache,cells=target_engine(row=row,config=config,runtime_config=runtime,table=table,kernel=kernel,
                    historical=hist,identity=identity,guard=guard,output=None)
            self.assertEqual(report['status'],'UNRESOLVED')
            self.assertEqual(report['logL_PIT']['interval'],[0,1])
            self.assertFalse(report['C09_complete']);self.assertFalse(report['SBC'])
            self.assertEqual(guard.values,cache.target_ledger.charged)
            self.assertLess(guard.values,1300)
            self.assertEqual(cells.shape[1],7)

if __name__=='__main__':unittest.main()
