import unittest
from pathlib import Path
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'tmp/c09_event_repair_v1'),str(ROOT/'tmp/c09_event_repair_runtime_v1')]
from d1.cache import ChargedCache,Ledger
from batched_cache import BatchedCache

class DurableCompletedBatches(unittest.TestCase):
    def test_failure_preserves_previous_callback_values_and_charged_failure(self):
        n=[0]
        def fn(u):
            n[0]+=1
            if n[0]==2:raise RuntimeError('synthetic interrupt after completed batch')
            return -u
        identity={'target_id':0,**{k:'d'*64 for k in ('data_sha256','model_sha256','table_sha256','sources_sha256')}}
        raw=ChargedCache(fn,identity,Ledger(maximum_values=20,maximum_cpu_seconds=10),Ledger(maximum_values=20,maximum_cpu_seconds=10))
        cache=BatchedCache(raw,batch=3,checkpoint=lambda:None)
        with self.assertRaises(RuntimeError):cache(np.linspace(0,1,10))
        self.assertEqual(len(cache.values),3)
        self.assertEqual(cache.target_ledger.charged,6)
        self.assertEqual([x['status']for x in cache.target_ledger.records],['COMPLETE','FAILED_CHARGED'])

if __name__=='__main__':unittest.main()
