"""Prepare immutable D1 runtime metadata; never decode/read binary scientific inputs.

The NPZ digests are inherited from reviewed receipts. The future supervisor
checks actual bytes only after ROOT chooses to run preflight/execute.
"""
from pathlib import Path
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'tmp/c09_d1_supervisor_v1'))
from supervisor import CAPS,HISTORY_BY_ID,SCOPE


def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def put(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')


def main():
    nominal=ROOT/'tmp/c09_nominal14_v4/config.json';old=read(nominal)
    gate=ROOT/'tmp/c09_nominal14_backend_v4/gates/backend_result.json';g=read(gate)
    end=ROOT/'tmp/c09_nominal14_pilot_v4/execution_end.json';h=read(end)['resources']
    if h['charged_likelihood_values']!=210588 or h['charged_likelihood_values_by_target']!=HISTORY_BY_ID:
        raise ValueError('inherited ledger differs')
    output_dirs=['tmp/c09_nominal14_backend_v2','tmp/c09_nominal14_backend_v3',
                 'tmp/c09_nominal14_backend_v4','tmp/c09_nominal14_pilot_v4']
    inherited_bytes=sum(f.stat().st_size for name in output_dirs for f in (ROOT/name).rglob('*')if f.is_file())
    runtime={'schema':'C09_D1_RUNTIME_CONFIG_v1','physical_execution_enabled_by_default':False,
       'scope':'SAME_NOMINAL14_KNOWN_NUISANCE_ENGINEERING_D1_ONLY_NOT_SBC',
       'nominal_config':str(nominal.relative_to(ROOT)),'data_file':'tmp/c09_nominal14_backend_v4/gates/data.npz',
       'historical_pilot_directory':'tmp/c09_nominal14_pilot_v4/pilot',
       'historical_backend_evidence_accepted_for_domain':True,
       'historical_backend_evidence_scope':'The previously ROOT-reviewed sparse16 Gamma/LL controls only, with historical direct-flow evidence; no uniform ORF or probability certificate.',
       'backend_probability_margin_by_target':None,
       'backend_margin_policy':'Unset: physical probability interval stays [0,1]. Sparse max delta logL is never converted to a probability margin by this runtime.',
       'algorithm':{'envelope_roundoff_allowance_logL':1e-9,'roundoff_allowance_kind':'prospective operational allowance, finite enclosure checks required; no directed-rounding certificate',
          'new_validation_count':1024,'historical_same_function_abs_tolerance':1e-10,
          'reserve_reference_values':2048,'maximum_depth':32,'ambiguity_goal':.0008,
          'mass_reference':'Direct scalar QUADPACK GK21 in prior CDF, same epsabs1e-9/epsrel1e-8/limit150; merged inside and ambiguous regions',
          'reference_budget':'Shares remaining4798 values with truth threshold and two center misses per split; upper2399 splits automatically limited by charged values and2048 reserved for references',
          'surrogate':'Separate PCHIP in x at L0/L1; original density PCHIP in alpha unchanged',
          'warnings':'Any warning raises; no silent warning-free flag',
          'cache_batch':32,'no_history_LL_cache_credit':True},
       'historical_13_unresolved_ids':[0,1,2,3,4,5,6,8,9,10,11,12,13],
       'existing_upper_support':1,'D2_alternative_upper_support_not_implemented':True,
       'physical_work_preparation':{'ORF':0,'LL':0,'bank':0,'MC':0,'NPZ_decoded':0}}
    put(HERE/'runtime_config.json',runtime)
    sources=set([*HERE.glob('*.py'),*ROOT.glob('tmp/c09_event_repair_v1/d1/*.py'),
                 *ROOT.glob('src/inference/*.py'),*ROOT.glob('src/pta/*.py')])
    sources.update(ROOT/name for name in ['tmp/c09_nominal14_v2/kernels.py','tmp/c09_nominal14_v4/runtime_adapter.py',
        'tmp/c09_nominal14_v4/channelwise_table.py','tmp/c09_integrator/integrator.py',
        'tmp/c09_contour/pchip_density.py','tmp/c09_d1_supervisor_v1/supervisor.py'])
    metadata=[nominal,ROOT/old['experiment_config'],gate,end,ROOT/'tmp/c09_nominal14_pilot_v4/ROOT_review.json',
       ROOT/'tmp/c09_nominal14_v4/ROOT_review.json',ROOT/'tmp/c09_nominal14_v4/ROOT_pilot_review.json',
       ROOT/'tmp/c09_event_repair_v1/manifest.json',ROOT/'tmp/c09_event_repair_independent_review_v1/review.json',
       ROOT/'tmp/c09_d1_supervisor_v1/manifest.json',HERE/'runtime_config.json']
    metadata.extend((ROOT/runtime['historical_pilot_directory']).glob('target_*.json'))
    bindings={str(p.relative_to(ROOT)):sha(p)for p in sorted(sources|set(metadata))}
    inherited_binary={old['table_file']:old['table_sha256'],runtime['data_file']:g['data_sha256'],
         'tmp/c09_nominal14_backend_v4/gates/harmonic_nodes.npz':g['harmonic_nodes_sha256']}
    bindings.update(inherited_binary)
    plan={'schema':'C09_D1_SUPERVISOR_PLAN_v1','mode':'D1','scope':SCOPE,
       'execution_enabled_by_default':False,'repository':str(ROOT),'worker':str((HERE/'worker.py').relative_to(ROOT)),
       'worker_parameters':{'runtime_config':str((HERE/'runtime_config.json').relative_to(ROOT))},
       'bindings':bindings,'history':{'cpu_seconds':h['combined_CPU_seconds'],'likelihood_values':210588,
           'likelihood_by_target':HISTORY_BY_ID,'output_bytes':inherited_bytes,'output_directories':output_dirs,
           'real_products':214577271056,'sky_points':74530432,
           'previous_receipt_scope':'Keeps historical sampled CPU including its documented missing old receipt serialization/exit; no fabricated remeasurement'},
       'limits':CAPS,'C09_complete':False,'automatic_retry':False}
    put(HERE/'preflight.json',plan)
    cost=read(HERE/'synthetic_route_cost.json')
    note={'schema':'C09_D1_METADATA_PREPARATION_v1','status':'PREPARED_NOT_EXECUTED_REQUIRES_ROOT',
       'preflight_sha256':sha(HERE/'preflight.json'),'runtime_config_sha256':sha(HERE/'runtime_config.json'),
       'supervisor_sha256':sha(ROOT/'tmp/c09_d1_supervisor_v1/supervisor.py'),
       'binding_count':len(bindings),'binary_digests_inherited_without_decoding_or_reading_binary_content':inherited_binary,
       'binary_actual_verification_pending_launch':True,'source_and_JSON_hashes_computed':len(bindings)-len(inherited_binary),
       'historical_output_bytes_by_stat':inherited_bytes,'cumulative_reserved_output_bytes':inherited_bytes+CAPS['new_output_bytes'],
       'prospective_cost':{'fixed_values_upper':282828,'additional_LL_cap':350000,'additional_CPU_cap':270,
          'synthetic_initial_envelope_projection_seconds':cost['initial_envelopes_projection'],
          'fixed_grid_plus_old_LL_rate_plus25setup_seconds':cost['fixed_282828_values_old_rate_projection_plus25setup'],
          'all_350k_plus_old_LL_rate_plus25setup_seconds':cost['maximum_values_350k_old_rate_projection_plus25setup'],
          'additional_refinement_envelope_cost_not_included_in_these_projections':True,
          'may_fail270s_and_preserve_partial_outputs':True,'no_physical_throughput_measurement':True},
       'physical_evaluations':0,'new_ORF':0,'new_draws':0}
    put(HERE/'metadata_preparation.json',note)
    print(json.dumps(note,indent=2))

if __name__=='__main__':main()
