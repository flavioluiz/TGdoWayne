"""Prospective D1 per-target engine. Import is inert; actual inputs come from worker.

All real scalar/vector scores pass through guard.reserve and the charged cache.
No new Gamma quadrature, generation or ORF refit is performed here.
"""
import math
import warnings
import numpy as np
from scipy.interpolate import PchipInterpolator
from d1.measure import Prior,CanonicalCoordinates,u_to_x
from d1.grid import event_grid,exact_union
from d1.cache import Ledger,ChargedCache
from d1.envelope import LogRange
from d1.partition import Cell,MassRange,refine,classification
from cells_runtime import SavedPolynomialCells
from d1.referenced_event import selection_mass,referenced_probability_interval
from mass_reference import DirectUnionMass,historical_denominator
from surrogate_event import probability as surrogate_probability


def _finite_records(cells):
    # Finite numeric archive arrays: unlimited ranges encoded by +/-inf are NOT
    # put in JSON. NPZ records legitimately preserve their IEEE representations.
    return np.array([[c.left,c.right,c.loglike.lower,c.loglike.upper,c.mass.lower,c.mass.upper,c.depth]
                     for c in cells],float)


def target_engine(*,row,config,runtime_config,table,kernel,historical,identity,guard,output,
                  on_cache_ready=lambda cache:None):
    """The worker owns source validation and failure/persistence policy."""
    from integrator import Posterior1D,MassPrior,EvaluationBudget
    from pchip_density import PositivePchipCDF
    prior=Prior(row['prior']);old_prior=MassPrior(row['prior'])
    qcfg=config['quadrature'];options=runtime_config['algorithm'];target=row['id']
    allowance=options['envelope_roundoff_allowance_logL']
    global_shadow=Ledger(maximum_values=25000,maximum_cpu_seconds=270)
    target_shadow=Ledger(maximum_values=25000,maximum_cpu_seconds=270)
    def callback(u):
        if np.any((u<prior.lower)|(u>1)):raise ValueError('likelihood outside exact prior support')
        guard.reserve(len(u),target)
        result=np.empty(len(u))
        batch=config['budgets']['batch_size_likelihood']
        for lo in range(0,len(u),batch):
            guard.checkpoint();result[lo:lo+batch]=kernel(table(u[lo:lo+batch]));guard.checkpoint()
        return result
    cache=ChargedCache(callback,identity,global_shadow,target_shadow);on_cache_ready(cache)
    grid=event_grid(table.nodes,prior,validation_count=options['new_validation_count'])
    if len(grid['fine_u'])>16671:raise ValueError('fine event grid exceeds frozen count')
    canonical=CanonicalCoordinates(grid['coarse_x'],grid['coarse_u'])
    guard.checkpoint()
    # L0 is contained in L1; this is the first new physical scoring request.
    fine_ell=cache(grid['fine_u']);coarse_ell=cache(grid['coarse_u'])
    event0=PchipInterpolator(grid['coarse_x'],coarse_ell,extrapolate=False)
    event1=PchipInterpolator(grid['fine_x'],fine_ell,extrapolate=False)
    direct=[];densities=[]
    for order in qcfg['orders']:
        obj=Posterior1D(cache,old_prior,order=order,panel_edges=qcfg['panel_edges_u'],
                budget=EvaluationBudget(maximum_values=60000,maximum_cpu_seconds=270))
        if not np.array_equal(obj._u,np.array(qcfg['GL_mass_nodes'][prior.kind][str(order)])):
            raise ArithmeticError('GL nodes differ from original frozen function controls')
        direct.append(obj);densities.append(PositivePchipCDF(obj))
    scouts=[]
    for name in ('scout_u_coarse','scout_u_fine'):
        a=np.array(qcfg[name]);u=exact_union([prior.lower,1.],a[a>prior.lower]);scouts.append((u,cache(u)))
    heldout=grid['validation_u'];heldout_ell=cache(heldout)
    # Validation does not alter either event spline, even when a control fails.
    controls_u=exact_union(heldout,*[s[0] for s in scouts],*[d._u for d in direct])
    controls_ell=cache(controls_u);controls_x=u_to_x(controls_u)
    shape0=float(np.max(abs(event0(controls_x)-controls_ell)))
    shape1=float(np.max(abs(event1(controls_x)-controls_ell)))
    truth_level=float(cache(np.array([row['fixed_truth_u']]))[0])
    level=LogRange(truth_level-allowance,truth_level+allowance,'charged_truth_reference_with_operational_roundoff')
    summaries=[d.summary() for d in direct]
    # Reuse the published old reference integrals only after same-function checks.
    if historical['target']!=target or historical['analysis']!=row['analysis'] or historical['prior']!=row['prior']:
        raise ValueError('historical target/model/prior mismatch')
    history_deltas=[]
    keys=('logz','mean_u','second_moment_u','expected_log_likelihood','kl_posterior_to_prior')
    for now,old in zip(summaries,historical['GL_summaries']):
        history_deltas.extend(abs(now[k]-old[k]) for k in keys)
    history_deltas.extend(abs(d.logz-z) for d,z in zip(densities,historical['PCHIP_logZ']))
    if max(history_deltas)>options['historical_same_function_abs_tolerance']:
        raise ArithmeticError('new direct summaries differ from frozen function; no historical mass reuse')
    shift=float(max(np.max(fine_ell),np.max(controls_ell)))
    scale=identity['sources_sha256']+':'+str(target)+':'+float(shift).hex()
    Z=historical_denominator(historical,shift=shift,scale_identity=scale)
    ref=DirectUnionMass(cache,prior,log_shift=shift,scale_identity=scale,
            epsabs=qcfg['reference_epsabs_scaled'],epsrel=qcfg['reference_epsrel'],
            limit=qcfg['reference_subinterval_limit'],checkpoint=guard.checkpoint)
    cdf_records=[]
    for old in historical['CDFs']:
        vals=[d.cdf(old['u']) for d in densities]
        cdf_records.append({'u':old['u'],'coarse':vals[0],'fine':vals[1],'historical_reference':old['reference']})
    flags={
        'normalization':max(abs(d.logz-historical['reference_logZ']) for d in direct+densities)<=config['gates']['delta_logZ'],
        'cdf':max(max(abs(r['fine']-r['historical_reference']),abs(r['fine']-r['coarse'])) for r in cdf_records)+2*historical['reference_relative_error_estimate']<=.002,
        'quantiles':all(b['width']<=.001 and b['reference_confirms'] for b in historical['quantile_brackets']),
        'moments':all(abs(summaries[-1][k]-historical['reference_moments'][k])<=.001 for k in ('mean_u','second_moment_u')),
        'kl':abs(summaries[-1]['kl_posterior_to_prior']-historical['reference_moments']['kl_posterior_to_prior'])<=.001,
        'offgrid_loglike':shape1<=.001,'warning_free':not any(d.construction_warnings for d in densities),
        'finite_mass_reference':True,'finite_physical_response_evidence':runtime_config['historical_backend_evidence_accepted_for_domain']}
    # Continuous mean polynomial stays variable for both fixed covariance models.
    if row['analysis']=='A0_CN':observed=kernel.data['q'][0]
    else:
        key='x_gaussian' if '_G' in row['analysis'] else 'x_physical'
        observed=kernel.data[key][0]
        if row['analysis']!='A_G':observed=np.einsum('k,kd->d',kernel.e['weights'],observed)[None]
    fixed=kernel.anchor_cov[0] if row['analysis'].endswith('_fixed') else None
    def covariance_coefficients(segment):
        c=np.array(table.coeff[segment]*kernel.covariance.pg[None,:,None,None],copy=True)
        c[0]+=kernel.covariance.noise
        return c
    factory=SavedPolynomialCells(table.alpha,covariance_coefficients,model=row['analysis'],H=kernel.e['H'],
        observation=observed,weights=kernel.e['weights'],center_loglike=cache,
        mass_interval=lambda a,b:MassRange(0.,Z.upper,scale),roundoff_allowance=allowance,
        canonical_coordinates=canonical,fixed_covariance=fixed)
    def make_cell(a,b,depth=0):
        guard.checkpoint();cell=factory(a,b,depth)
        mass=selection_mass(cell.loglike,prior,canonical(a),canonical(b),log_shift=shift,
                             denominator_upper=Z.upper,scale_identity=scale)
        return Cell(a,b,cell.loglike,mass,depth)
    cells=[make_cell(a,b) for a,b in zip(grid['coarse_x'][:-1],grid['coarse_x'][1:])]
    # Confirm computed envelopes against already charged controls, without more LL.
    envelope_violations=[]
    for u,ell in zip(controls_u,controls_ell):
        x=float(u_to_x(u));i=min(len(cells)-1,max(0,int(np.searchsorted(grid['coarse_x'],x,side='right')-1)))
        c=cells[i]
        if not c.loglike.lower<=ell<=c.loglike.upper:envelope_violations.append({'u':float(u),'logL':float(ell),'cell':i})
    if envelope_violations:raise ArithmeticError('saved polynomial enclosure failed finite charged controls')
    remaining=25000-target_shadow.charged
    max_splits=max(0,min(2399,(remaining-options['reserve_reference_values'])//2))
    cells,refinement=refine(cells,level,Z.lower,support=(grid['coarse_x'][0],0.),make_cell=make_cell,
          maximum_splits=max_splits,maximum_depth=options['maximum_depth'],ambiguity_goal=options['ambiguity_goal'],
          checkpoint=guard.checkpoint)
    s0=surrogate_probability(event0,densities[0].cdf,truth_level,canonical_coordinates=canonical)
    s1=surrogate_probability(event1,densities[1].cdf,truth_level,canonical_coordinates=canonical)
    rep=abs(s0['probability']-s1['probability'])
    backend=runtime_config['backend_probability_margin_by_target']
    backend_margin=None if backend is None else backend[str(target)]['operational_probability_margin']
    # The config defaults to None. A sparse logL maximum is never converted here.
    result=referenced_probability_interval(cells,level,Z,support=(grid['coarse_x'][0],0.),reference_mass=ref,
          backend_probability_margin=backend_margin,representation_probability_margin=rep,controls=flags,
          canonical_coordinates=canonical)
    flags['finite_mass_reference']=not ref.warning_messages
    table_error=result['ambiguous_mass_upper']+result['quadrature_operational_error']+rep
    table_flags={k:v for k,v in flags.items() if k!='finite_physical_response_evidence'}
    table_pass=(all(table_flags.values()) and result['ambiguous_mass_upper']<=.001
                and result['quadrature_operational_error']<=.00025 and rep<=.0005 and table_error<=.002)
    table_interval=[max(0.,result['core_interval'][0]-rep),min(1.,result['core_interval'][1]+rep)]
    result['saved_table_result']={'status':'RESOLVED_TABLE_OPERATIONAL' if table_pass else 'UNRESOLVED_TABLE',
          'interval':table_interval if table_pass else [0.,1.],'candidate_interval':table_interval,
          'total_operational_error':table_error,'finite_control_evidence_not_uniform_certificate':True,
          'physical_probability_approval_inferred':False}
    result['scope']='NOMINAL14_FIXED_NUISANCE_SAVED_TABLE_EVENT_WITH_SEPARATE_FINITE_BACKEND_GATE' 
    result['historical_logL_PIT_interval']=historical['logL_PIT_operational_interval']
    result['historical_status_unchanged']=historical['status']
    report={'schema':'C09_D1_TARGET_RESULT_v1','target':target,'analysis':row['analysis'],'prior':row['prior'],
        'status':result['status'],'flags':flags,'logL_PIT':result,'C09_complete':False,'SBC':False,
        'grid':{'L0':len(grid['coarse_u']),'L1':len(grid['fine_u']),'heldout':len(heldout),
                'accidental_validation_overlap':grid['validation_overlap_count']},
        'same_function_historical_max_abs_delta':max(history_deltas),
        'offgrid_event_max_abs_logL':{'L0':shape0,'L1':shape1},'envelope_control_violations':envelope_violations,
        'envelope_calls':factory.envelope_calls,'refinement':refinement,'surrogate_probabilities':[s0,s1],
        'mass_references':ref.calls,'shadow_cache_values':target_shadow.charged,'cache_hits':cache.hits,
        'batch_coalescences':cache.coalesced_same_batch,'historical_reference_reuse':True,
        'historical_integral_error_is_operational_estimate':True,'global_error_certificate':False}
    return report,cache,_finite_records(cells)
