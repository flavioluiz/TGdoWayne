"""Synthetic-only validation; no worker or physical data imports."""
import argparse,hashlib,json,resource,sys,time,unittest,warnings
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if a.output.exists():raise FileExistsError('new output required')
 plan=json.loads((HERE/'toy_preflight.json').read_text())
 for f,h in plan['sources'].items():
  if hashlib.sha256((ROOT/f).read_bytes()).hexdigest()!=h:raise ValueError('TOY source drift: '+f)
 warnings.simplefilter('error');start=time.process_time()
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover(str(HERE/'tests')))
 cpu=time.process_time()-start;rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)
 receipt={'schema':'C09_D1_RUNTIME_TOYS_v1','passed':r.wasSuccessful(),'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),
  'CPU_seconds':cpu,'RSS_peak_bytes':rss,'budget_pass':cpu<=plan['maximum_CPU_seconds'] and rss<=plan['maximum_RSS_bytes'],
  'preflight_sha256':hashlib.sha256((HERE/'toy_preflight.json').read_bytes()).hexdigest(),
  'physical_ORF':0,'physical_LL':0,'physical_bank':0,'new_MC':0,'real_NPZ_read':0}
 with a.output.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 return 0 if receipt['passed'] and receipt['budget_pass'] else 1
if __name__=='__main__':raise SystemExit(main())
