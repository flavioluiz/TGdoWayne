"""Prospective16 synthetic cells per actual nominal14 route; cap10s/512MiB."""
from pathlib import Path
import json,resource,sys,time
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT/'tmp/c09_event_repair_v1'),str(HERE)]
from polynomial_fast import quadratic_moment_coefficients
from d1.polynomial import compress_coefficients
from d1.envelope import normal_envelope,cn_envelope


def main():
    out=HERE/'synthetic_route_cost.json'
    if out.exists():raise FileExistsError(out)
    v=np.arange(4*4*12*12).reshape(4,4,12,12);a=np.sin(.13*v)+1j*np.cos(.07*v)
    c=(a+a.swapaxes(-1,-2).conj())*.00001;c[0]+=2*np.eye(12)
    H=np.zeros((10,12,12));H[np.arange(10),np.arange(10),np.arange(10)]=1
    rows=[]
    for name,multiplicity in [('A0_CN',6),('A_G',1),('B_normal',7)]:
        start=time.process_time()
        for _ in range(16):
            if name=='A0_CN':bound=cn_envelope(c,np.zeros((4,12),complex),0,roundoff_allowance=1e-9)
            else:
                mu,sigma=quadratic_moment_coefficients(c,H)
                if name=='B_normal':mu,sigma=compress_coefficients(mu,sigma,np.full(4,.25))
                bound=normal_envelope(mu,sigma,np.zeros(mu.shape[1:]),0,roundoff_allowance=1e-9)
            if not np.isfinite([bound.lower,bound.upper]).all():raise RuntimeError('synthetic envelope unresolved')
        cost=time.process_time()-start
        rows.append({'route':name,'nominal14_count':multiplicity,'synthetic_cells':16,'CPU_seconds':cost,
                     'CPU_per_cell':cost/16,'projected_initial_envelopes_seconds':cost/16*8335*multiplicity})
    total=sum(r['projected_initial_envelopes_seconds'] for r in rows)
    llrate=.0006601911106881127
    report={'schema':'C09_D1_ROUTE_COST_SYNTHETIC_v1','rows':rows,'initial_envelopes_projection':total,
       'maximum_values_350k_old_rate_projection_plus25setup':350000*llrate+25+total,
       'fixed_282828_values_old_rate_projection_plus25setup':282828*llrate+25+total,
       'additional_CPU_cap_unchanged':270,'physical_measurement':False,'projection_not_guarantee':True,
       'RSS_peak_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024),
       'physical_LL':0,'ORF':0,'bank':0,'MC':0,'declared_CPU_cap':10,'declared_RSS_cap':536870912}
    with out.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps(report))
if __name__=='__main__':main()
