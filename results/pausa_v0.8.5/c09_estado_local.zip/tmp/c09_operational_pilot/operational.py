"""Pure operational uncertainty algebra; no physical posterior is approved here."""
from numbers import Real, Integral
import math


def _real(value, name, *, nonnegative=False):
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(name + ' must be a real scalar')
    value = float(value)
    if not math.isfinite(value) or (nonnegative and value < 0):
        raise ValueError(name + ' must be finite' + (' and nonnegative' if nonnegative else ''))
    return value


def ratio_envelope(numerator, denominator, numerator_error, denominator_error):
    """Conditional bound if the supplied integral error bounds hold.

    Empirically estimated errors do not acquire rigorous coverage by using this
    identity. N is an event numerator, so 0<=N<=Z is used explicitly.
    """
    n = _real(numerator, 'numerator', nonnegative=True)
    z = _real(denominator, 'denominator', nonnegative=True)
    en = _real(numerator_error, 'numerator_error', nonnegative=True)
    ez = _real(denominator_error, 'denominator_error', nonnegative=True)
    if z <= 0 or n > z:
        raise ValueError('require 0 <= numerator <= positive denominator')
    sums = (n+en, z+ez)
    if not all(math.isfinite(x) for x in sums):
        raise OverflowError('integral envelope overflow')
    if z-ez <= 0:
        return (0., 1.)
    return (max(0., (n-en)/(z+ez)), min(1., (n+en)/(z-ez)))


def event_band_envelope(event_cdf, threshold, log_event_error, *, threshold_error=0., density_tv_error=0.):
    """Sandwich for |ell-ell_tilde|<=d and TV(p,p_tilde)<=eta.

    The caller, not this algebra, supplies evidence for these assumptions.
    Positive mass at an event plateau remains inside the band.
    """
    t = _real(threshold, 'threshold')
    d = _real(log_event_error, 'log_event_error', nonnegative=True)
    dt = _real(threshold_error, 'threshold_error', nonnegative=True)
    eta = _real(density_tv_error, 'density_tv_error', nonnegative=True)
    if eta > 1:
        raise ValueError('TV bound must lie in [0,1]')
    width = d+dt
    if not math.isfinite(width) or not math.isfinite(t-width) or not math.isfinite(t+width):
        raise OverflowError('event threshold envelope overflow')
    low = _real(event_cdf(t-width), 'lower event CDF')
    high = _real(event_cdf(t+width), 'upper event CDF')
    if not 0 <= low <= high <= 1:
        raise ValueError('event CDF must be ordered in [0,1]')
    return (max(0., low-eta), min(1., high+eta))


def operational_status(*, refinement_pass, independent_integral_pass, offgrid_form_pass,
                       physical_backend_pass, domain_identity_pass, budget_pass,
                       event_contour_pass=None):
    """Finite-evidence status only, never a mathematical global certificate."""
    checks = (refinement_pass, independent_integral_pass, offgrid_form_pass,
              physical_backend_pass, domain_identity_pass, budget_pass)
    if any(type(x) is not bool for x in checks):
        raise TypeError('all required evidence flags must be actual booleans')
    if event_contour_pass is not None and type(event_contour_pass) is not bool:
        raise TypeError('event_contour_pass must be bool or None')
    passed = all(checks) and event_contour_pass is not False
    return 'OPERATIONALLY_RESOLVED_ON_TESTED_DOMAIN' if passed else 'UNRESOLVED'


def phase_scout_intervals(maximum_phase, phase_step):
    y = _real(maximum_phase, 'maximum_phase', nonnegative=True)
    h = _real(phase_step, 'phase_step', nonnegative=True)
    if h <= 0:
        raise ValueError('positive phase step required')
    # phi=y*(1+beta*mu); |delta phi| <= y*|delta beta|, |mu|<=1.
    quotient = y/h
    if not math.isfinite(quotient):
        raise OverflowError('phase interval count overflow')
    return max(1, math.ceil(quotient))


def fixed_feature_miss_probability(prior_width, independent_uniform_probes):
    """For a FIXED interval of known prior-CDF width and perfect detection.

    Does not bound unknown peak widths or their posterior mass, and cannot
    certify a scan adapted after inspecting the same probes.
    """
    w = _real(prior_width, 'prior_width', nonnegative=True)
    if w > 1:
        raise ValueError('width must lie in [0,1]')
    m = independent_uniform_probes
    if isinstance(m, bool) or not isinstance(m, Integral) or m < 1:
        raise ValueError('positive integer probe count required')
    return 0. if w == 1 else math.exp(int(m)*math.log1p(-w))
