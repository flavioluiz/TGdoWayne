import math
import unittest
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from operational import ratio_envelope, event_band_envelope, operational_status, phase_scout_intervals, fixed_feature_miss_probability

class OperationalTests(unittest.TestCase):
    def test_ratio_corners_with_event_constraint(self):
        n,z,en,ez=.3,1.,.1,.2
        low,high=ratio_envelope(n,z,en,ez)
        for true_z in np.linspace(z-ez,z+ez,17):
            for true_n in np.linspace(n-en,n+en,17):
                if true_n <= true_z:
                    self.assertLessEqual(low,true_n/true_z)
                    self.assertGreaterEqual(high,true_n/true_z)
        self.assertEqual(ratio_envelope(.3,1.,.1,1.),(0.,1.))

    def test_event_perturbation_bound_against_independent_root(self):
        # Uniform density, surrogate ell=u, analytic sup error <=d.
        d=.025;t=.43
        true_root=brentq(lambda u:u+d*math.sin(8*u)-t,0,1)
        low,high=event_band_envelope(lambda x:max(0.,min(1.,x)),t,d)
        self.assertLessEqual(low,true_root);self.assertGreaterEqual(high,true_root)
        self.assertGreater(high-low,0)

    def test_atom_is_not_hidden_by_event_band(self):
        atom_cdf=lambda x:float(x>=2.)
        self.assertEqual(event_band_envelope(atom_cdf,2.,0.),(1.,1.))
        self.assertEqual(event_band_envelope(atom_cdf,2.,.0001),(0.,1.))

    def test_no_backend_or_reference_no_resolution(self):
        k=dict(refinement_pass=True,independent_integral_pass=True,offgrid_form_pass=True,
               physical_backend_pass=True,domain_identity_pass=True,budget_pass=True)
        self.assertEqual(operational_status(**k),'OPERATIONALLY_RESOLVED_ON_TESTED_DOMAIN')
        for key in k:
            q=dict(k);q[key]=False
            self.assertEqual(operational_status(**q),'UNRESOLVED')
        self.assertEqual(operational_status(**k,event_contour_pass=False),'UNRESOLVED')

    def test_strict_guards(self):
        for args in [(.1,0.,0.,0.),(.2,.1,0.,0.),(.1,1.,-1.,0.),(.1,math.inf,0.,0.),(True,1.,0.,0.)]:
            with self.assertRaises((ValueError,TypeError)):
                ratio_envelope(*args)
        with self.assertRaises(OverflowError):ratio_envelope(1e308,1e308,1e308,1e308)
        with self.assertRaises(ValueError):event_band_envelope(lambda x:.8 if x<0 else .2,0.,1.)
        with self.assertRaises(TypeError):event_band_envelope(lambda x:.5,True,0.)
        with self.assertRaises(ValueError):fixed_feature_miss_probability(.01,True)

    def test_phase_and_known_feature_miss(self):
        y=2*math.pi*4*1100/4.5
        self.assertEqual(phase_scout_intervals(y,math.pi/8),15645)
        self.assertAlmostEqual(fixed_feature_miss_probability(.00002,256),(1-.00002)**256,places=13)
        self.assertGreater(fixed_feature_miss_probability(.00002,256),.994)

if __name__=='__main__':unittest.main()
