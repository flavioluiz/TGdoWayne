"""Lightweight independent probes; intentionally reproduces an unresolved spike."""
from pathlib import Path
import hashlib,json,math,resource,sys,time,unittest
import numpy as np
from scipy.integrate import quad

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(25,30))
START=time.process_time()
sys.path[:0]=[str(HERE),str(ROOT/'tmp/c09_contour'),str(ROOT/'tmp/c09_integrator')]
from integrator import MassPrior,Posterior1D
from pchip_density import PositivePchipCDF
from contour import LogLikelihoodContour
from operational import operational_status, phase_scout_intervals,fixed_feature_miss_probability
from test_operational import OperationalTests

cases=[]
for kind in ('uniform_u','uniform_u_squared','log_uniform_u'):
 prior=MassPrior(kind)
 ll=lambda u:7*u-1000
 a,b=[Posterior1D(ll,prior,order=n) for n in (32,64)]
 pa,pb=PositivePchipCDF(a),PositivePchipCDF(b)
 # Different coordinate and adaptive nodes; no physical likelihood is involved.
 value,err=quad(lambda v:math.exp(7*float(prior.ppf(v))-7),0,1,epsabs=1e-11,epsrel=1e-11,limit=150)
 independent_logz=math.log(value)-993
 cuts=[x for x in (.001,.13,.5,.95,.999) if prior.lower<x<1]
 cdfs=[]
 for u in cuts:
  top,e=quad(lambda v:math.exp(7*float(prior.ppf(v))-7),0,float(prior.cdf(u)),epsabs=1e-11,epsrel=1e-11,limit=150)
  cdfs.append({'u':u,'pchip':pb.cdf(u),'independent':top/value,'absolute_difference':abs(pb.cdf(u)-top/value),'GK_estimate_scaled_numerator_error':e})
 assert abs(pb.logz-independent_logz)<.001
 assert max(x['absolute_difference'] for x in cdfs)<.002
 cases.append({'prior':kind,'GL32_logz':a.logz,'GL64_logz':b.logz,'PCHIP64_logz':pb.logz,
  'independent_prior_CDF_coordinate_logz':independent_logz,'GK_estimate_scaled_Z_error':err,'CDFs':cdfs,
  'scope':'SMOOTH_SYNTHETIC_ONLY','physical_status':'NOT_EVALUATED'})

c=.41234;w=1e-5;amp=1000.
ell=lambda u:np.log1p(amp*np.exp(-((u-c)/w)**2))
a,b=[Posterior1D(ell,MassPrior('uniform_u'),order=n) for n in (32,64)]
pa,pb=PositivePchipCDF(a),PositivePchipCDF(b)
fun=lambda u:1+amp*math.exp(-((u-c)/w)**2)
blind,blind_error=quad(fun,0,1,epsabs=1e-11,epsrel=1e-11,limit=100)
known,known_error=quad(fun,0,1,points=[c-8*w,c,c+8*w],epsabs=1e-11,epsrel=1e-11,limit=100)
exact=1+amp*w*math.sqrt(math.pi)*.5*(math.erf((1-c)/w)+math.erf(c/w))
radius=w*math.sqrt(math.log(amp))
inside=2*radius+amp*w*math.sqrt(math.pi)*math.erf(radius/w)
exact_event=1-inside/exact
surrogate_event=LogLikelihoodContour(pb).cdf(math.log(2.))
base=dict(refinement_pass=True,independent_integral_pass=False,offgrid_form_pass=False,
          physical_backend_pass=False,domain_identity_pass=True,budget_pass=True,event_contour_pass=False)
spike={'centre':c,'width_parameter':w,'amplitude':amp,'GL32':a.logz,'GL64':b.logz,
 'PCHIP32':pa.logz,'PCHIP64':pb.logz,'blind_GK_logZ':math.log(blind),'blind_GK_reported_scaled_error':blind_error,
 'analytic_logZ':math.log(exact),'GK_known_breakpoints_logZ':math.log(known),'GK_known_breakpoints_reported_scaled_error':known_error,
 'same_nodes_refinement_misses_spike':abs(pa.logz-pb.logz)<.001 and abs(pb.logz-math.log(exact))>.001,
 'blind_independent_adaptive_also_misses_spike':abs(math.log(blind)-math.log(exact))>.001,
 'analytic_event_CDF_at_log2':exact_event,'surrogate_event_CDF_at_log2':surrogate_event['probability'],
 'surrogate_event_CDF_error':abs(surrogate_event['probability']-exact_event),
 'known_feature_interval_width_2w_prior_mass':2*w,
 'probability_256_blind_uniform_probes_miss_fixed_interval':fixed_feature_miss_probability(2*w,256),
 'status':operational_status(**base),'operational_probability_envelope':[0,1],
 'known_breakpoints_scope':'analytic synthetic oracle only; unavailable automatically for physical likelihood'}
assert spike['same_nodes_refinement_misses_spike'] and spike['blind_independent_adaptive_also_misses_spike']
assert abs(math.log(known)-math.log(exact))<1e-10
assert spike['surrogate_event_CDF_error']>.002

suite=unittest.defaultTestLoader.loadTestsFromTestCase(OperationalTests)
result=unittest.TextTestRunner(verbosity=2).run(suite)
sources=[HERE/'operational.py',HERE/'test_operational.py',Path(__file__),ROOT/'tmp/c09_integrator/integrator.py',ROOT/'tmp/c09_contour/pchip_density.py',ROOT/'tmp/c09_contour/contour.py']
out={'status':'SYNTHETIC_CHECKS_PASS_WITH_REQUIRED_UNRESOLVED_COUNTEREXAMPLE' if result.wasSuccessful() else 'TEST_FAILURE',
 'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'CPU_seconds':time.process_time()-START,
 'maximum_CPU_seconds':30,'new_ORFs':0,'PTA_likelihood_evaluations':0,'PTA_draws':0,'synthetic_smooth_cases':cases,'counterexample':spike,
 'phase_resolution_cost':{'maximum_C09_phase':2*math.pi*4*1100/4.5,'phase_step':math.pi/8,'beta_intervals':phase_scout_intervals(2*math.pi*4*1100/4.5,math.pi/8),'interpretation':'Phase sampling diagnostic, not posterior regularity proof'},
 'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}}
(HERE/'validation.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':out['status'],'CPU_seconds':out['CPU_seconds'],'tests':result.testsRun,'counterexample':spike},indent=2))
if not result.wasSuccessful():raise SystemExit(1)
