import math
import unittest
import warnings
import numpy as np
from scipy.integrate import quad
from scipy.special import logsumexp
from d1.measure import CanonicalCoordinates,Prior,u_to_x,x_to_u,quadrature_rule,integrate
from d1.grid import ordered_x,event_grid,exact_union
from d1.polynomial import evaluate,restrict,bernstein,quadratic_moment_coefficients,compress_coefficients
from d1.envelope import LogRange,cn_envelope,normal_envelope
from d1.partition import Cell,MassRange,classification,coverage,probability_interval,refine
from d1.cache import Ledger,ChargedCache,BudgetExceeded
from d1.cells import SavedPolynomialCells,MODELS

ALL_CONTROLS = dict.fromkeys(('normalization','cdf','quantiles','moments','kl','offgrid_loglike',
                             'warning_free','finite_mass_reference','finite_physical_response_evidence'),True)


def cn_direct(c,q):
    # Independent determinant/solve formula; no envelope Cholesky/whitening.
    return float(sum(-len(v)*math.log(math.pi)-np.linalg.slogdet(a)[1]
                     -np.vdot(v,np.linalg.solve(a,v)).real for a,v in zip(c,q)))


def normal_direct(mu,c,y):
    return float(sum(-.5*(len(v)*math.log(2*math.pi)+np.linalg.slogdet(a)[1]
                         +(v-m)@np.linalg.solve(a,v-m)) for m,a,v in zip(mu,c,y)))


def fixtures():
    c = np.zeros((4,2,2,2),complex)
    c[0] = np.array([[[1.4,.1+.07j],[.1-.07j,.8]],[[.9,-.05j],[.05j,1.2]]])
    c[1] = np.array([[[.012,.003j],[-.003j,-.007]],[[.005,.002],[.002,.008]]])
    c[2] = -.4*c[1]; c[3] = .2*c[1]
    H = np.array([[[1,0],[0,0]],[[0,0],[0,1]],[[0,.5j],[-.5j,0]]],complex)
    q = np.array([[.2+.1j,-.8+.3j],[1.2-.1j,.4+.5j]])
    return c,H,q


class CoordinatesAndMeasure(unittest.TestCase):
    def test_grid_preserves_original_knots_and_probe_separation(self):
        nodes = x_to_u(np.linspace(-1,0,17))
        for prior in (Prior('uniform_u'),Prior('log_uniform_u')):
            grid = event_grid(nodes,prior,validation_count=31)
            self.assertLessEqual(len(grid['fine_x']),33)
            self.assertEqual(grid['fine_u'][0],prior.lower)
            self.assertEqual(grid['fine_u'][-1],1)
            self.assertTrue(np.all(np.diff(grid['fine_x'])>0))
            self.assertFalse(np.isin(grid['validation_u'],grid['fine_u']).any())
            old = nodes[nodes>=prior.lower]
            self.assertTrue(np.isin(old,grid['fine_u']).all())
            self.assertFalse(np.isin(grid['validation_u'],grid['coarse_u']).any())

    def test_grid_rejects_roundoff_collapsed_knots(self):
        with self.assertRaises(ValueError): ordered_x(np.array([0,1e-12,1]))
        with self.assertRaises(ValueError): ordered_x(np.array([0,.5,.5,1]))
        with self.assertRaises(ValueError): event_grid([0,1],Prior('uniform_u'),validation_count=0)
        self.assertEqual(len(exact_union([0,-0.,np.nextafter(0.,1.),1])),3)

    def test_prior_endpoints_and_inverse(self):
        for p in (Prior('uniform_u'),Prior('uniform_u_squared'),Prior('log_uniform_u',1e-4)):
            v = np.linspace(0,1,33)
            self.assertTrue(np.allclose(p.cdf(p.ppf(v)),v,atol=4e-16,rtol=0))
            self.assertEqual(p.ppf(0),p.lower); self.assertEqual(p.ppf(1),1)
            self.assertEqual(p.cdf(-2),0); self.assertEqual(p.cdf(2),1)
        self.assertTrue(np.array_equal(x_to_u(np.array([-1.,0.])),[0,1]))
        self.assertTrue(np.array_equal(u_to_x(np.array([0.,1.])),[-1,0]))

    def test_alpha_and_prior_cdf_normalization(self):
        for p in (Prior('uniform_u'),Prior('uniform_u_squared'),Prior('log_uniform_u',1e-4)):
            edges = np.unique(np.r_[p.lower,[.0001,.001,.01,.1,.5,1]])
            edges = edges[edges>=p.lower]
            for coord in ('alpha','prior_cdf'):
                r = integrate(lambda u:np.zeros_like(u),p,edges,48,coordinate=coord)
                self.assertAlmostEqual(r['logz'],0,places=12)
                mean = .5 if p.kind=='uniform_u' else (2/3 if p.kind=='uniform_u_squared' else (1-p.lower)/math.log(1/p.lower))
                self.assertAlmostEqual(r['mean_u'],mean,places=8)

    def test_independent_measure_integrals_with_log_cutoff_and_constant_shift(self):
        for p in (Prior('uniform_u'),Prior('uniform_u_squared'),Prior('log_uniform_u',1e-4)):
            edges = np.unique(np.r_[p.lower,[.0001,.001,.01,.1,.5,1]])
            edges = edges[edges>=p.lower]
            fn = lambda u:-4*u*u+.3*u
            a = integrate(fn,p,edges,64,coordinate='alpha')
            b = integrate(fn,p,edges,96,coordinate='prior_cdf')
            # Independent adaptive quadrature in the prior-CDF measure.
            z = quad(lambda v:math.exp(float(fn(p.ppf(v)))),0,1,epsabs=2e-12,epsrel=2e-12)[0]
            self.assertAlmostEqual(a['logz'],math.log(z),places=10)
            self.assertAlmostEqual(a['logz'],b['logz'],places=9)
            shifted = integrate(lambda u:fn(u)+700,p,edges,64,coordinate='alpha')
            self.assertAlmostEqual(shifted['logz']-700,a['logz'],places=11)
            self.assertAlmostEqual(shifted['kl_posterior_prior'],a['kl_posterior_prior'],places=11)


class PolynomialAndBounds(unittest.TestCase):
    def test_subdivision_and_bernstein_whole_cell(self):
        a = np.array([.1,-2.,3.,-1.])
        sub = restrict(a,.17,.81)
        for t in np.linspace(0,1,101):
            self.assertAlmostEqual(evaluate(sub,t),evaluate(a,.17+.64*t),places=14)
            self.assertGreaterEqual(evaluate(sub,t),min(bernstein(sub))-1e-14)
            self.assertLessEqual(evaluate(sub,t),max(bernstein(sub))+1e-14)
        with self.assertRaises(ValueError): restrict(np.array([0,1]),0,.5)
        with self.assertRaises(ValueError): restrict(a,.5,.5)

    def test_complex_cn_envelope_independent_direct_formula(self):
        c,H,q = fixtures(); mid = cn_direct(evaluate(c,.5),q)
        bound = cn_envelope(c,q,mid,roundoff_allowance=1e-12)
        self.assertLess(bound.maximum_eta,1)
        for t in np.linspace(0,1,151):
            ll = cn_direct(evaluate(c,t),q)
            self.assertTrue(bound.lower<=ll<=bound.upper)
        shifted = cn_envelope(c,q,mid-701,roundoff_allowance=1e-12)
        self.assertAlmostEqual(shifted.lower+701,bound.lower,places=12)

    def test_degree_six_moments_against_explicit_traces(self):
        c,H,q = fixtures(); mu,sigma = quadratic_moment_coefficients(c,H)
        self.assertEqual(len(sigma),7)
        for t in np.linspace(0,1,19):
            C = evaluate(c,t)
            direct_mu = np.array([[np.trace(h@a).real for h in H] for a in C])
            direct_cov = np.array([[[np.trace(h@a@g@a).real for g in H] for h in H] for a in C])
            np.testing.assert_allclose(evaluate(mu,t),direct_mu,atol=5e-15,rtol=5e-15)
            np.testing.assert_allclose(evaluate(sigma,t),direct_cov,atol=5e-15,rtol=5e-15)

    def test_normal_envelopes_all_effective_routes(self):
        c,H,q = fixtures(); mu,cov = quadratic_moment_coefficients(c,H)
        w = np.array([.3,.7]); y = np.array([[.4,1.5,.2],[1.2,.1,-.1]])
        for fixed in (None,evaluate(compress_coefficients(mu,cov,w)[1],.5)[0]):
            for diagonal in (False,True):
                m,s = compress_coefficients(mu,cov,w,fixed_covariance=fixed,diagonal=diagonal)
                yy = np.einsum('k,kd->d',w,y)[None]
                ref = normal_direct(evaluate(m,.5),evaluate(s,.5),yy)
                bound = normal_envelope(m,s,yy,ref,roundoff_allowance=1e-12)
                self.assertLess(bound.maximum_eta,1)
                for t in np.linspace(0,1,41):
                    self.assertTrue(bound.lower<=normal_direct(evaluate(m,t),evaluate(s,t),yy)<=bound.upper)
                if fixed is not None: self.assertEqual(len(s),1)
        ref = normal_direct(evaluate(mu,.5),evaluate(cov,.5),y)
        bound = normal_envelope(mu,cov,y,ref,roundoff_allowance=1e-12)
        for t in np.linspace(0,1,41):
            self.assertTrue(bound.lower<=normal_direct(evaluate(mu,t),evaluate(cov,t),y)<=bound.upper)

    def test_near_singular_and_eta_failure_are_not_repaired(self):
        c = np.zeros((2,1,2,2)); c[0,0] = np.diag([1e-12,1]); c[1,0,0,0] = 1e-13
        q = np.array([[1e-6,.4]])
        b = cn_envelope(c,q,cn_direct(evaluate(c,.5),q),roundoff_allowance=1e-12)
        self.assertTrue(math.isfinite(b.upper)); self.assertLess(b.maximum_eta,1)
        bad = np.array([[[[2.501]]],[[[-10.]]],[[[10.]]]])  # SPD quadratic, center .001, large controls
        b = cn_envelope(bad,np.array([[0.]]),0,roundoff_allowance=0)
        self.assertEqual((b.lower,b.upper),(-math.inf,math.inf))
        singular = np.zeros((1,1,1,1))
        self.assertEqual(cn_envelope(singular,np.zeros((1,1)),0,roundoff_allowance=0).upper,math.inf)


class ConservativeEvents(unittest.TestCase):
    def output(self,cells,level,**kwargs):
        return probability_interval(cells,level,MassRange(1,1,'toy'),support=(-1,0),
                backend_probability_margin=kwargs.get('backend',0),representation_probability_margin=0,
                controls=kwargs.get('controls',ALL_CONTROLS))

    def test_full_empty_plateau_without_roots(self):
        c = Cell(-1,0,LogRange(2,2),MassRange(1,1,'toy'))
        self.assertEqual(self.output([c],LogRange(2,2))['interval'],[1,1])
        self.assertEqual(self.output([c],LogRange(1,1))['interval'],[0,0])
        self.assertEqual(self.output([c],LogRange(1.99,2.01))['interval'],[0,1])
        self.assertEqual(classification(c,LogRange(2,2)),'inside')

    def test_simple_and_double_root_cover_with_ambiguous_mass(self):
        for power,level in ((1,.37),(2,0.)):
            def make(a,b,depth=0):
                points = [a+.5,b+.5]
                vals = [v**power for v in points]
                if power==2 and a<=-.5<=b: vals.append(0)
                return Cell(a,b,LogRange(min(vals),max(vals)),MassRange(b-a,b-a,'toy'),depth)
            cells,r = refine([make(-1,0)],LogRange(level,level),1,support=(-1,0),make_cell=make,
                             maximum_splits=32,maximum_depth=24,ambiguity_goal=.0009)
            out = self.output(cells,LogRange(level,level))
            self.assertEqual(out['status'],'RESOLVED_OPERATIONAL')
            truth = .87 if power==1 else 0.
            self.assertLessEqual(out['interval'][0],truth)
            self.assertGreaterEqual(out['interval'][1],truth)

    def test_ambiguous_high_density_is_not_geometric_width(self):
        cells = [Cell(-1,-.999,LogRange(-1,1),MassRange(.8,.8,'toy')),
                 Cell(-.999,0,LogRange(-2,-2),MassRange(.2,.2,'toy'))]
        out = self.output(cells,LogRange(0,0))
        self.assertEqual(out['status'],'UNRESOLVED'); self.assertEqual(out['interval'],[0,1])
        self.assertAlmostEqual(out['ambiguity_mass_upper'],.8)

    def test_gap_scale_threshold_and_unknown_backend_guards(self):
        c = Cell(-1,0,LogRange(0,0),MassRange(1,1,'toy'))
        self.assertEqual(self.output([c],LogRange(0,0),backend=None)['interval'],[0,1])
        controls = dict(ALL_CONTROLS,offgrid_loglike=False)
        self.assertEqual(self.output([c],LogRange(0,0),controls=controls)['interval'],[0,1])
        with self.assertRaises(ValueError): coverage([c],(-.9,0))
        with self.assertRaises(ValueError): self.output([c],LogRange(-math.inf,0))
        with self.assertRaises(ValueError): coverage([Cell(-1,-.5,LogRange(0,0),MassRange(.5,.5,'x')),
                      Cell(-.5,0,LogRange(0,0),MassRange(.5,.5,'y'))],(-1,0))

    def test_mass_numerator_ambiguity_denominator_errors_separate(self):
        cells = [Cell(-1,-.5,LogRange(-2,-1),MassRange(.19999,.20001,'toy')),
                 Cell(-.5,-.4,LogRange(-1,1),MassRange(.00019,.00021,'toy')),
                 Cell(-.4,0,LogRange(1,2),MassRange(.79978,.79982,'toy'))]
        out = probability_interval(cells,LogRange(0,0),MassRange(.99999,1.00001,'toy'),support=(-1,0),
                  backend_probability_margin=0,representation_probability_margin=0,controls=ALL_CONTROLS)
        self.assertEqual(out['status'],'RESOLVED_OPERATIONAL')
        self.assertAlmostEqual(out['core_interval'][0],.19999/1.00001)
        self.assertAlmostEqual(out['core_interval'][1],(.20001+.00021)/.99999)
        self.assertLessEqual(out['interval'][0],.2); self.assertGreaterEqual(out['interval'][1],.2002)

    def test_density_convergence_does_not_establish_event_resolution(self):
        # Periodic high-frequency logL has near-constant integral but alternating event.
        n=64; amp=1e-4
        coarse = amp*np.cos(2*np.pi*n*np.linspace(0,1,n+1))
        hidden = amp*np.cos(2*np.pi*n*((np.arange(n)+.5)/n))
        self.assertGreater(coarse.min(),0); self.assertLess(hidden.max(),0)
        z = quad(lambda u:math.exp(amp*math.cos(2*math.pi*n*u)),0,1,epsabs=1e-11,limit=300)[0]
        self.assertLess(abs(z-1),3e-9)
        c = Cell(-1,0,LogRange(-amp,amp),MassRange(1,1,'toy'))
        self.assertEqual(self.output([c],LogRange(0,0))['status'],'UNRESOLVED')


class CallbackAndCache(unittest.TestCase):
    def cache(self,fn,limit=100):
        identity = dict(target_id=0,**{k:'a'*64 for k in ('data_sha256','model_sha256','table_sha256','sources_sha256')})
        g = Ledger(maximum_values=limit,maximum_cpu_seconds=10)
        t = Ledger(maximum_values=limit,maximum_cpu_seconds=10)
        return ChargedCache(fn,identity,g,t)

    def test_exact_cache_reservation_and_failed_call(self):
        c = self.cache(lambda u:-u*u,limit=3)
        np.testing.assert_equal(c(np.array([0,0,.5])),[0,0,-.25])
        self.assertEqual(c.global_ledger.charged,2)
        c(np.array([np.nextafter(.5,1)])); self.assertEqual(c.global_ledger.charged,3)
        with self.assertRaises(BudgetExceeded): c(np.array([1.]))
        self.assertEqual(c.global_ledger.charged,3)
        bad = self.cache(lambda u:np.full_like(u,np.nan))
        with self.assertRaises(ValueError): bad(np.array([.5]))
        self.assertEqual(bad.global_ledger.charged,1)
        self.assertEqual(bad.global_ledger.records[0]['status'],'FAILED_CHARGED')
        self.assertEqual(bad.values,{})

    def test_cell_adapter_routes_compression_and_no_refit(self):
        c,H,q = fixtures(); mu,cov = quadratic_moment_coefficients(c,H)
        w = np.array([.3,.7]); y = np.array([[.4,1.5,.2],[1.2,.1,-.1]])
        for name in MODELS:
            fixed = evaluate(compress_coefficients(mu,cov,w)[1],.5)[0] if name.endswith('_fixed') else None
            obs = q if name=='A0_CN' else (y if name=='A_G' else np.einsum('k,kd->d',w,y)[None])
            def direct(u):
                values=[]
                for t in u_to_x(u)+1:
                    if name=='A0_CN': val=cn_direct(evaluate(c,t),obs)
                    else:
                        m,s=(mu,cov) if name=='A_G' else compress_coefficients(mu,cov,w,fixed_covariance=fixed,diagonal='_diagonal_' in name)
                        val=normal_direct(evaluate(m,t),evaluate(s,t),obs)
                    values.append(val)
                return np.array(values)
            cache=self.cache(direct)
            f=SavedPolynomialCells(np.array([-1.,0.]),lambda i:c,model=name,H=H,observation=obs,weights=w,
                    center_loglike=cache,mass_interval=lambda a,b:MassRange(b-a,b-a,'toy'),roundoff_allowance=1e-11,
                    canonical_coordinates=CanonicalCoordinates([-1,0],[0,1]),fixed_covariance=fixed)
            cell=f(-.9,-.2)
            for x in np.linspace(-.9,-.2,31):
                val=direct(np.array([float(x_to_u(x))]))[0]
                self.assertTrue(cell.loglike.lower<=val<=cell.loglike.upper)
            self.assertEqual(cache.global_ledger.charged,1)
            with self.assertRaises(ValueError): f(-1.1,-.2)


if __name__=='__main__':
    warnings.simplefilter('error')
    unittest.main()
