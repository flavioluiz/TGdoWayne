import unittest
import numpy as np
from d1.measure import Prior,CanonicalCoordinates,u_to_x
from d1.partition import Cell,MassRange
from d1.envelope import LogRange
from d1.referenced_event import merged_regions,selection_mass
from d1.cache import Ledger,ChargedCache,BudgetExceeded
from d1.cells import SavedPolynomialCells

class IndependentReviewGuards(unittest.TestCase):
    def make_cache(self,fn):
        i=dict(target_id=0,**{k:'b'*64 for k in ('data_sha256','model_sha256','table_sha256','sources_sha256')})
        return ChargedCache(fn,i,Ledger(maximum_values=2,maximum_cpu_seconds=10),Ledger(maximum_values=2,maximum_cpu_seconds=10))

    def test_interrupted_callback_keeps_original_exception_and_both_reservations(self):
        def interrupted(u):raise KeyboardInterrupt('synthetic only')
        cache=self.make_cache(interrupted)
        with self.assertRaises(KeyboardInterrupt):cache(np.array([.2]))
        for ledger in (cache.global_ledger,cache.target_ledger):
            self.assertEqual(ledger.charged,1);self.assertEqual(ledger.records[0]['status'],'FAILED_CHARGED')

    def test_expiry_after_precheck_is_paired_charged_failure(self):
        calls=[];cache=self.make_cache(lambda u:calls.append(1) or -u)
        seen=[0]
        def expires():
            seen[0]+=1
            if seen[0]==2:raise BudgetExceeded('synthetic expiry after common preflight')
        cache.target_ledger.checkpoint=expires
        with self.assertRaises(BudgetExceeded):cache(np.array([.2]))
        self.assertEqual(calls,[])
        for ledger in (cache.global_ledger,cache.target_ledger):
            self.assertEqual(ledger.charged,1);self.assertEqual(ledger.records[0]['status'],'FAILED_CHARGED')

    def test_both_cutoffs_are_exact_in_cell_mass_and_region_references(self):
        for cutoff in (.001,.01):
            p=Prior('log_uniform_u',cutoff);start=float(u_to_x(cutoff))
            mapping=CanonicalCoordinates([start,0],[cutoff,1]);seen=[]
            def mass(a,b):
                seen.append((a,b))
                return selection_mass(LogRange(0,0),p,a,b,log_shift=0,denominator_upper=1,scale_identity='s')
            f=SavedPolynomialCells(np.array([-1.,0.]),lambda i:np.ones((1,1,1,1)),model='A0_CN',
                    H=np.ones((1,1,1)),observation=np.zeros((1,1)),weights=np.ones(1),
                    center_loglike=lambda u:np.full_like(u,-np.log(np.pi)),mass_interval=mass,
                    roundoff_allowance=0,canonical_coordinates=mapping)
            cell=f(start,0)
            self.assertEqual(seen,[(cutoff,1)])
            regions=merged_regions([cell],LogRange(0,0),support=(start,0),canonical_coordinates=mapping)
            self.assertEqual(regions['inside'],((cutoff,1),))

if __name__=='__main__':unittest.main()
