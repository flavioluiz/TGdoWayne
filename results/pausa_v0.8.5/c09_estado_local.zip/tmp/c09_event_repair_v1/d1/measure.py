"""Normalized priors and quadrature measures; never integrate density in beta."""
from dataclasses import dataclass
import math
import numpy as np
from scipy.special import logsumexp

KINDS = ('uniform_u', 'uniform_u_squared', 'log_uniform_u')


def _finite(a):
    a = np.asarray(a, dtype=float)
    if not np.isfinite(a).all():
        raise ValueError('finite coordinates required')
    return a


def u_to_x(u):
    u = _finite(u)
    if np.any((u < 0) | (u > 1)):
        raise ValueError('u outside [0,1]')
    return -np.sqrt((1-u)*(1+u))


def x_to_u(x):
    x = _finite(x)
    if np.any((x < -1) | (x > 0)):
        raise ValueError('x outside [-1,0]')
    return np.sqrt((1-x)*(1+x))


@dataclass(frozen=True)
class Prior:
    kind: str
    cutoff: float = .001

    def __post_init__(self):
        if self.kind not in KINDS or not np.isfinite(self.cutoff) or not 0 < self.cutoff < 1:
            raise ValueError('valid normalized nominal14 prior required')

    @property
    def lower(self):
        return self.cutoff if self.kind == 'log_uniform_u' else 0.

    def cdf(self, u):
        u = np.clip(_finite(u), self.lower, 1.)  # CDF extends constantly outside support.
        if self.kind == 'uniform_u': return u
        if self.kind == 'uniform_u_squared': return u*u
        return np.log(u/self.cutoff)/math.log(1/self.cutoff)

    def ppf(self, v):
        v = _finite(v)
        if np.any((v < 0) | (v > 1)): raise ValueError('prior probability outside [0,1]')
        if self.kind == 'uniform_u': return v
        if self.kind == 'uniform_u_squared': return np.sqrt(v)
        # Pin exact endpoints to avoid an unsupported u after exp rounding.
        value = np.exp((1-v)*math.log(self.cutoff))
        return np.where(v == 0, self.cutoff, np.where(v == 1, 1., value))

    def log_alpha_density(self, alpha):
        a = _finite(alpha)
        if np.any((a < math.asin(self.lower)) | (a >= math.pi/2)):
            raise ValueError('alpha nodes must be interior at the upper endpoint')
        u = np.sin(a)
        if self.kind == 'uniform_u_squared' and np.any(u == 0):
            raise ValueError('zero-measure endpoint is not an interior quadrature node')
        out = np.log(np.cos(a))
        if self.kind == 'uniform_u_squared': out = out + np.log(2*u)
        if self.kind == 'log_uniform_u': out = out - np.log(u) - math.log(math.log(1/self.cutoff))
        return out


def quadrature_rule(prior, edges_u, order, *, coordinate):
    """Piecewise GL rule. Both alpha and v=F_prior return log prior measure."""
    edges = _finite(edges_u)
    if (edges.ndim != 1 or len(edges) < 2 or edges[0] < prior.lower or edges[-1] > 1
            or np.any(np.diff(edges) <= 0)):
        raise ValueError('strict panel edges within prior support required')
    if type(order) is not int or not 2 <= order <= 4096:
        raise ValueError('explicit GL order in [2,4096] required')
    z,w = np.polynomial.legendre.leggauss(order)
    us, logweights = [], []
    for low,high in zip(edges[:-1], edges[1:]):
        if coordinate == 'alpha':
            # Half of asin(high)-asin(low), stable for short panels.
            half = math.atan2(high-low, math.sqrt((1-low)*(1+low))+math.sqrt((1-high)*(1+high)))
            a = math.asin(low)+half*(1+z)
            us.append(np.sin(a))
            logweights.append(np.log(half*w)+prior.log_alpha_density(a))
        elif coordinate == 'prior_cdf':
            lo,hi = prior.cdf(np.array([low,high]))
            half = (hi-lo)/2
            if half <= 0: raise ArithmeticError('prior-CDF cell collapsed')
            us.append(prior.ppf(lo+half*(1+z)))
            logweights.append(np.log(half*w))
        else:
            raise ValueError('only alpha or prior_cdf density coordinates supported')
    return np.concatenate(us), np.concatenate(logweights)


def integrate(log_likelihood, prior, edges_u, order, *, coordinate):
    """Callback-only normalized logZ/moments; no physical imports or hidden cache."""
    u,lm = quadrature_rule(prior, edges_u, order, coordinate=coordinate)
    ell = np.asarray(log_likelihood(u), float)
    if ell.shape != u.shape or not np.isfinite(ell).all():
        raise ValueError('finite logL with shape(nodes,) required')
    logz = float(logsumexp(ell+lm))
    weights = np.exp(ell+lm-logz)
    return {'logz':logz, 'mean_u':float(weights@u),
            'second_moment_u':float(weights@(u*u)),
            'expected_log_likelihood':float(weights@ell),
            'kl_posterior_prior':float(weights@(ell-logz)),
            'values':len(u), 'coordinate':coordinate,
            'error_certificate':False}


class CanonicalCoordinates:
    """Pin original table/cutoff u values at their x keys; avoid inverse-rounding drift."""
    def __init__(self,x_values,u_values):
        x,u = _finite(x_values),_finite(u_values)
        if (x.ndim != 1 or u.shape != x.shape or len(x)<2 or np.any(np.diff(x)<=0)
                or np.any(np.diff(u)<=0) or not np.array_equal(u_to_x(u),x)):
            raise ValueError('strict paired canonical x/u coordinates required')
        self._mapping = dict(zip(x.tolist(),u.tolist()))

    def __call__(self,x):
        x = float(x)
        fallback = float(x_to_u(x))  # validates domain even for mapped endpoints.
        return self._mapping.get(x,fallback)
