"""Ascending powers in normalized local t in [0,1]; never a new ORF spline."""
from math import comb
import numpy as np


def coefficients(a):
    a = np.asarray(a)
    if a.ndim < 1 or len(a) < 1 or a.dtype.kind not in 'fc' or not np.isfinite(a).all():
        raise ValueError('finite float/complex ascending coefficients required')
    return a


def evaluate(a,t):
    a = coefficients(a)
    if not np.isfinite(t) or not 0 <= t <= 1: raise ValueError('local t outside [0,1]')
    out = np.zeros_like(a[0])
    for c in a[::-1]: out = out*t+c
    return out


def restrict(a,lo,hi):
    """a(lo+(hi-lo)s), no refit. Integer inputs rejected to avoid truncation."""
    a = coefficients(a)
    if not np.isfinite([lo,hi]).all() or not 0 <= lo < hi <= 1:
        raise ValueError('nonempty local subinterval required')
    b = np.zeros_like(a)
    for k in range(len(a)):
        for j in range(k+1): b[j] += a[k]*comb(k,j)*lo**(k-j)*(hi-lo)**j
    return b


def bernstein(a):
    a = coefficients(a); n = len(a)-1
    out = np.zeros_like(a)
    for k in range(n+1):
        for j in range(k+1): out[k] += a[j]*comb(k,j)/comb(n,j)
    return out


def quadratic_moment_coefficients(c,H):
    """C:(degree+1,K,P,P), H:(D,P,P); CN proper quadratic trace moments."""
    c,H = coefficients(c),np.asarray(H)
    if c.ndim != 4 or c.shape[-1] != c.shape[-2] or H.ndim != 3 or H.shape[-2:] != c.shape[-2:]:
        raise ValueError('covariance polynomial and Hermitian quadratic forms required')
    for a in (c,H):
        if not np.isfinite(a).all() or not np.allclose(a,a.swapaxes(-1,-2).conj(),atol=1e-12,rtol=1e-12):
            raise ValueError('finite Hermitian coefficients/forms required')
    mu = np.einsum('aij,rkji->rka',H,c)
    hc = np.einsum('aij,rkjl->rkail',H,c)
    cov = np.zeros((2*len(c)-1,c.shape[1],len(H),len(H)),complex)
    for i in range(len(c)):
        for j in range(len(c)):
            cov[i+j] += np.einsum('kaij,kbji->kab',hc[i],hc[j])
    for a in (mu,cov):
        if np.max(abs(a.imag),initial=0) > 1e-10*max(1.,float(np.max(abs(a.real),initial=0))):
            raise ArithmeticError('quadratic trace should be real')
    # Coefficients need not be PSD individually; only the full polynomial does.
    return mu.real,cov.real


def compress_coefficients(mu,cov,weights,*,fixed_covariance=None,diagonal=False):
    w = np.asarray(weights,float)
    if (mu.ndim != 3 or cov.ndim != 4 or w.shape != (mu.shape[1],)
            or cov.shape[1] != len(w) or not np.isfinite(w).all()):
        raise ValueError('one finite fixed weight per independent frequency required')
    mb = np.einsum('k,rkd->rd',w,mu)[:,None,:]
    cb = np.einsum('k,rkab->rab',w*w,cov)[:,None,:,:]
    if fixed_covariance is not None:
        fixed = np.asarray(fixed_covariance,float)
        if fixed.shape != cb.shape[-2:] or not np.isfinite(fixed).all(): raise ValueError('fixed covariance shape')
        cb = fixed[None,None].copy()  # degree zero; mean continues to vary.
    if diagonal:
        cb = cb*np.eye(cb.shape[-1])
    return mb,cb
