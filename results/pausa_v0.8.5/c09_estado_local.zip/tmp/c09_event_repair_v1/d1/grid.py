"""Frozen event grids. Held-out probes never enter the fitting arrays."""
import numpy as np
from .measure import Prior, u_to_x, x_to_u


def ordered_x(nodes_u):
    u = np.asarray(nodes_u, float)
    if (u.ndim != 1 or len(u) < 2 or not np.isfinite(u).all()
            or u[0] != 0 or u[-1] != 1 or np.any(np.diff(u) <= 0)):
        raise ValueError('full, finite, strictly increasing [0,1] knots required')
    x = u_to_x(u)
    if np.any(np.diff(x) <= 0):
        raise ValueError('table knots collapse in x=-beta; no deduplication of cells')
    return x


def exact_union(*arrays):
    """Numerical float64 equality, with one +0 convention; preserves close distinct values."""
    a = np.concatenate([np.asarray(v,dtype=np.float64).reshape(-1) for v in arrays])
    if not np.isfinite(a).all(): raise ValueError('finite grid required')
    a[a == 0] = 0.
    return np.unique(a)


def event_grid(nodes_u, prior, *, validation_count=1024):
    if not isinstance(prior, Prior): raise TypeError('Prior required')
    if type(validation_count) is not int or validation_count < 1: raise ValueError('positive validation count required')
    x = ordered_x(nodes_u)
    start = float(u_to_x(prior.lower))
    coarse_x = exact_union(np.array([start,0.]),x[(x > start) & (x < 0)])
    midpoint_x = coarse_x[:-1]+.5*np.diff(coarse_x)
    if np.any((midpoint_x <= coarse_x[:-1]) | (midpoint_x >= coarse_x[1:])):
        raise ArithmeticError('midpoint cell below representable resolution')
    fine_x = exact_union(coarse_x,midpoint_x)
    coarse_u, fine_u = x_to_u(coarse_x),x_to_u(fine_x)
    # Preserve original u values at original knots: inverse rounding does not redefine the table.
    lookup = {float(a):float(b) for a,b in zip(x,np.asarray(nodes_u,float))}
    lookup[start],lookup[0.] = prior.lower,1.
    coarse_u = np.array([lookup.get(float(a),float(b)) for a,b in zip(coarse_x,coarse_u)])
    fine_u = np.array([lookup.get(float(a),float(b)) for a,b in zip(fine_x,fine_u)])
    if np.any(np.diff(fine_u) <= 0): raise ArithmeticError('fine u grid collapsed')
    beta = (np.arange(validation_count,dtype=float)+.37)/validation_count
    heldout = x_to_u(-beta)
    heldout = np.sort(heldout[(heldout >= prior.lower) & (heldout <= 1)])
    # Accidental overlap must be reported; it is not independent validation.
    disjoint = heldout[~np.isin(heldout,fine_u)]
    return {'coarse_x':coarse_x,'coarse_u':coarse_u,'fine_x':fine_x,'fine_u':fine_u,
            'validation_u':disjoint,'validation_overlap_count':len(heldout)-len(disjoint),
            'cutoff_splits_original_cell':bool(start not in x),
            'training_coordinates':'x=-beta1', 'density_coordinates':'alpha or prior_cdf'}
