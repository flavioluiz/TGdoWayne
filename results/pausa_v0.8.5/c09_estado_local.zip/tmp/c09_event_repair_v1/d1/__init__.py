"""D1 candidate: pure callback interfaces, no physical execution on import."""
