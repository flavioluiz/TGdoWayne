"""Whole-support classification; a root count is neither needed nor sufficient."""
from dataclasses import dataclass
import math
from .envelope import LogRange


@dataclass(frozen=True)
class MassRange:
    lower: float
    upper: float
    scale_identity: str

    def __post_init__(self):
        if (not math.isfinite(self.lower) or not math.isfinite(self.upper)
                or not 0 <= self.lower <= self.upper or not self.scale_identity):
            raise ValueError('finite nonnegative unnormalized masses in a common scale required')


@dataclass(frozen=True)
class Cell:
    left: float
    right: float
    loglike: LogRange
    mass: MassRange
    depth: int = 0

    def __post_init__(self):
        if (not math.isfinite(self.left) or not math.isfinite(self.right)
                or not -1 <= self.left < self.right <= 0 or type(self.depth) is not int or self.depth < 0):
            raise ValueError('strict x=-beta cell required')


def classification(cell,level):
    if cell.loglike.upper <= level.lower: return 'inside'  # event is <=, including plateaus.
    if cell.loglike.lower > level.upper: return 'outside'
    return 'ambiguous'


def coverage(cells,support):
    if not cells or cells[0].left != support[0] or cells[-1].right != support[1]:
        raise ValueError('cell partition does not cover prior support')
    for a,b in zip(cells[:-1],cells[1:]):
        if a.right != b.left: raise ValueError('gap/overlap in cell partition')
    scale = cells[0].mass.scale_identity
    if any(c.mass.scale_identity != scale for c in cells): raise ValueError('mixed mass normalization scales')


def probability_interval(cells,level,denominator,*,support,backend_probability_margin,
                         representation_probability_margin,controls):
    """Intervals plus operational margins, never a uniform physical certificate.

    Caller controls must contain all nine named booleans. `None` evidence leaves
    [0,1]; nominal tolerances cannot be supplied as if they were measured errors.
    """
    coverage(cells,support)
    if denominator.scale_identity != cells[0].mass.scale_identity or denominator.lower <= 0:
        raise ValueError('strictly positive denominator in the same likelihood scale required')
    if not (math.isfinite(level.lower) and math.isfinite(level.upper)):
        raise ValueError('finite threshold interval required')
    kinds = [classification(c,level) for c in cells]
    inside = [c for c,k in zip(cells,kinds) if k == 'inside']
    ambiguous = [c for c,k in zip(cells,kinds) if k == 'ambiguous']
    mass_lo = math.fsum(c.mass.lower for c in cells)
    mass_hi = math.fsum(c.mass.upper for c in cells)
    if mass_lo > denominator.upper or mass_hi < denominator.lower:
        raise ArithmeticError('partition mass intervals incompatible with independent denominator')
    low = math.fsum(c.mass.lower for c in inside)/denominator.upper
    high = math.fsum(c.mass.upper for c in inside+ambiguous)/denominator.lower
    if low > 1: raise ArithmeticError('positive numerator lower exceeds denominator upper')
    # Intersect with structural probability bounds, never repair a covariance.
    core = [max(0.,low),min(1.,high)]
    ambiguity = min(1.,math.fsum(c.mass.upper for c in ambiguous)/denominator.lower)
    mass_error = (mass_hi-mass_lo+denominator.upper-denominator.lower)/denominator.lower
    evidence = all(v is not None and math.isfinite(v) and v >= 0
                   for v in (backend_probability_margin,representation_probability_margin))
    named = ('normalization','cdf','quantiles','moments','kl','offgrid_loglike',
             'warning_free','finite_mass_reference','finite_physical_response_evidence')
    other_gates = isinstance(controls,dict) and all(controls.get(n) is True for n in named)
    b = backend_probability_margin if evidence else 0.
    r = representation_probability_margin if evidence else 0.
    candidate = [max(0.,core[0]-b-r),min(1.,core[1]+b+r)]
    error = ambiguity+mass_error+b+r
    gates = {'ambiguity_mass':ambiguity <= .001,'quadrature':mass_error <= .00025,
             'finite_backend_margin':evidence and b <= .00025,
             'representation_difference':evidence and r <= .0005,
             'total_operational_error':evidence and error <= .002,
             'other_original_gates':other_gates}
    passed = all(gates.values())
    return {'status':'RESOLVED_OPERATIONAL' if passed else 'UNRESOLVED',
            'interval':candidate if passed else [0.,1.], 'candidate_interval':candidate,
            'core_interval':core,'classification_counts':{k:kinds.count(k) for k in ('inside','outside','ambiguous')},
            'ambiguity_mass_upper':ambiguity,'mass_quadrature_operational_error':mass_error,
            'total_operational_error':error if evidence else None,'gates':gates,
            'rigorous_floatingpoint_certificate':False,'uniform_physical_certificate':False}


def refine(cells,level,denominator_lower,*,support,make_cell,maximum_splits,
           maximum_depth,ambiguity_goal=.001,checkpoint=lambda:None):
    """Deterministic largest upper-mass first; two child calls per split.

    make_cell is an explicit callback owning ALL logL/CPU reservations. Inputs
    are left,right,depth. A failed child never replaces its parent; no incomplete
    coverage is returned. Exception callers must preserve their cache and ledger.
    """
    cells = list(cells); coverage(cells,support)
    if (type(maximum_splits) is not int or maximum_splits < 0 or type(maximum_depth) is not int
            or maximum_depth < 0 or not math.isfinite(denominator_lower) or denominator_lower <= 0
            or not math.isfinite(ambiguity_goal) or not 0 <= ambiguity_goal <= 1):
        raise ValueError('explicit nonnegative refinement limits and positive denominator required')
    splits = 0
    while splits < maximum_splits:
        checkpoint()
        indices = [i for i,c in enumerate(cells) if classification(c,level) == 'ambiguous']
        mass = math.fsum(cells[i].mass.upper for i in indices)/denominator_lower
        if mass <= ambiguity_goal: break
        eligible = [i for i in indices if cells[i].depth < maximum_depth]
        if not eligible: break
        i = max(eligible,key=lambda j:(cells[j].mass.upper,-cells[j].left))
        c = cells[i]; mid = c.left+(c.right-c.left)/2
        if mid == c.left or mid == c.right: break
        left = make_cell(c.left,mid,c.depth+1)
        right = make_cell(mid,c.right,c.depth+1)
        coverage([left,right],(c.left,c.right))
        if left.mass.scale_identity != c.mass.scale_identity: raise ValueError('child scale changed')
        cells[i:i+1] = [left,right]; splits += 1
    coverage(cells,support)
    return cells,{'splits':splits,'complete_support':True,'remaining_ambiguous_mass_upper':
        math.fsum(c.mass.upper for c in cells if classification(c,level)=='ambiguous')/denominator_lower}
