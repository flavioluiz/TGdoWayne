# Candidato D1: separar densidade e evento em C09

**Candidato revisável, somente código puro e TOYs.** Não executa o nominal14, não altera seus resultados e não conclui C09. Os 13 PITs de logL não resolvidos do v4 continuam [0,1]. Nenhuma ORF, likelihood física, tabela, banco, realização Monte Carlo ou array NPZ real foi avaliado nesta preparação.

O programa expõe apenas `preflight` e `toys`. A autorização do ROOT para preparar o candidato não é uma autorização para gastar o orçamento físico prospectivo. A interface de likelihood é um callback explícito; nenhum módulo importa `inference`, `pta` ou carrega arquivos científicos.

```sh
.venv/bin/python tmp/c09_event_repair_v1/run_candidate.py preflight
VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  .venv/bin/python tmp/c09_event_repair_v1/run_candidate.py toys \
  --output /tmp/d1_nova_validacao.json
```

O arquivo de saída precisa ser novo. O runner confere os hashes do preflight dos TOYs antes de importar os testes. `spec.json` vincula o protocolo anterior e conserva orçamento, critérios, histórico e pendências físicas. O preflight dos TOYs é distinto do orçamento prospectivo D1.

## Interfaces e sequência de integração

| Arquivo | Responsabilidade |
|---|---|
| `d1/measure.py` | Prioris normalizadas, coordenadas, Jacobiano em alpha, quadratura independente na CDF da priori e mapa canônico dos extremos. |
| `d1/grid.py` | L0 nos nós originais, L1 com pontos médios em x=−beta e sondas congeladas mantidas fora dos arrays de ajuste. |
| `d1/polynomial.py` | Coeficientes em potências ascendentes da fração local; subdivisão sem refit, controles de Bernstein e momentos de grau até seis. |
| `d1/envelope.py` | Perturbações matriciais branqueadas por Cholesky; eta≥1 ou referência não SPD deixa intervalo ilimitado, sem jitter ou clipping de autovalores. |
| `d1/cells.py` | Roteamento dos sete modelos e callback de uma célula, conservando a coordenada realmente avaliada após o roundtrip float64 x→u→x. |
| `d1/cache.py` | Identidade por hashes, cache apenas de valores calculados e cobrança global/por ID anterior ao callback. Falhas e interrupções preservam reservas pareadas. |
| `d1/partition.py` | Cobertura integral do suporte, igualdade incluída em ell≤nível, refinamento determinístico e intervalos quando as massas celulares já são referências. |
| `d1/referenced_event.py` | Massa superior para selecionar células e referência final dos conjuntos contíguos inside/ambiguous, com erros separados de N, A e Z. |

A tabela congelada utiliza o atributo histórico `.alpha` para **x=−beta**, enquanto a densidade usa alpha=asin(u). Os coeficientes da tabela são na variável local `t=(x−x_i)/(x_{i+1}−x_i)`, e não em x global. O candidato não ajusta outro spline.

A integração futura deve proceder assim:

1. Validar os SHA do dado, modelo, tabela e fontes; carregar o factory v4 e os coeficientes já congelados. Reusar somente as Γ realmente disponíveis. Abrir a execução com um ledger cumulativo e controles externos de CPU/RSS/saída, ainda ausentes deste candidato.
2. Construir a grade L0/L1 por ID e um `CanonicalCoordinates(grid['coarse_x'], grid['coarse_u'])`. Esse mapa preserva o corte exato da priori e os u originais dos nós: a transformação inversa em float64 não precisa reproduzir o mesmo corte. Não incluir sondas de validação no ajuste. A função rejeita nós colapsados em x ou u.
3. Instanciar `ChargedCache` com callback da mesma likelihood normalizada. Reavaliar os valores históricos não armazenados é trabalho novo, cobrado. Duplicatas dentro de um lote são coalescidas; são contadas separadamente dos verdadeiros hits de cache.
4. Fornecer à fábrica um callback de **um segmento** de C, derivado linearmente dos coeficientes de Γ e do espectro/ruído fixos. Não criar um banco grau6 para todos os segmentos. `A0_CN` recebe q e a fórmula CN; `A_G` soma K blocos normais; todo `B_*`, inclusive `B_CN`, usa um bloco normal dos momentos comprimidos. A compressão usa w na média e w² na covariância; fixed substitui apenas a covariância após compressão, diagonal mantém a média variável.
5. Os centros das células originais pertencem a L1. Refinar apenas células ambíguas pela maior massa superior, desempate pela esquerda, com no máximo 32 níveis e duas novas avaliações centrais por divisão. O limite efetivo de divisões depende da reserva que sobrar depois do limiar e das referências. Não atravessar nós do polinômio salvo.
6. Integrar a densidade em alpha com Jacobiano; manter a referência independente em v=F_prior(u). A massa de seleção pode ser majorada pela medida exata da priori da célula vezes `exp(envelope−shift)`, limitada por um Z superior de referência na mesma escala. Esta escolha não requer uma quadratura por célula.
7. Unir regiões adjacentes definitivamente dentro e ambíguas. O callback `reference_mass(union_of_intervals)` retorna uma referência N±E_N ou A±E_A; Z±E_Z permanece separado. Ele reserva todos os pontos novos no mesmo cache/ledger. Não renomear uma CDF pontual de PCHIP como intervalo validado. As referências devem ser compatíveis com as envoltórias celulares e com a massa total; um evento que cobre todo o suporte não pode receber P=0,5 por um callback inconsistente.
8. Conferir os controles originais de normalização, CDF, brackets, momentos, KL, forma off-grid e warnings, além da referência de massa e da evidência física finita. Só então compor o intervalo operacional de PIT. A falta de evidência, inclusive backend `None`, mantém `[0,1]`.

## O que o intervalo significa

Com os conjuntos classificados, a regra usa

`P_lo = N_lo / Z_hi`, `P_hi = (N_hi + A_hi) / Z_lo`, para `Z_lo>0`,

intersectando apenas com o domínio matemático [0,1]. N/A/Z devem usar a mesma escala `exp(ell−shift)`. Erros independentes do numerador, da massa ambígua e do denominador são mantidos, sem supor cancelamento. A soma conservadora dos comprimentos desses três intervalos, dividida por Z_lo, é usada no subgate de quadratura. A massa ambígua é posterior, não largura geométrica da célula.

A condição de contagem positiva de raízes foi substituída prospectivamente por cobertura total e massa ambígua. Eventos integral/vazio e platôs podem ser classificados sem raízes; tangências e células não resolvidas conservam a massa ambígua. O nível ell(u_true) também é um intervalo, e a comparação usa `cell.upper ≤ level.lower` para dentro e `cell.lower > level.upper` para fora.

As desigualdades CN e normal e a envoltória convexa de Bernstein são matemáticas em aritmética exata para o polinômio salvo. A implementação usa float64 usual, sem arredondamento dirigido. `roundoff_allowance` é explícito e ainda requer validação operacional antes do uso real. Tampouco uma verificação física finita produz um certificado uniforme de toda a ORF. Os dois campos de certificado ficam `False`.

A tolerância 0,00025 do backend é um **teto**, não evidência de erro nessa escala. Não inserir esse número como se tivesse sido medido nem converter automaticamente uma discrepância esparsa de logL em probabilidade. A comparação entre representações também precisa de valores efetivamente observados e domínio registrado.

## Orçamento prospectivo preservado

D1 continua proposto com até **350.000 LL novas**, **25.000 por ID** e **270 s CPU adicionais**, zero quadratura ORF/céu e zero geração. O histórico permanece em 210.588 LL e 296,087524 s CPU: limites candidatos cumulativos de 560.588 LL e 566,087524 s CPU, dentro dos hard caps anteriores de 1 M/600 s. RSS permanece 1.610.612.736 B, arrays estimados 1.400.000.000 B, saída da continuação 20 MiB e BLAS1. O pacote não transforma folga até esses hard caps em autorização.

A grade fixa reserva no máximo 20.202 valores por ID. Os 4.798 restantes atendem **juntos** limiar, raízes/subdivisões e referências de massa. O teto algébrico 2.399 divisões não é uma autorização para gastar toda essa reserva em refinamento e depois fazer referências adicionais. A integração futura deve reduzir o número de divisões conforme os valores já reservados. O custo de whitening/traços das envoltórias ainda não foi medido no nominal14; ele entra em CPU, mesmo quando a pontuação central já está em cache. Não afirmar que a projeção de 552,154413 s foi medida.

A proposta trabalha por ID, com allowance adicional de 64 MiB sobre a estimativa histórica de construção de 1.067.845.256 B. Isso é preflight de arrays/temporários, não garantia de RSS. Persistência, supervisão cumulativa de CPU/RSS, controle de bytes e retomada física ainda precisam de wrapper revisado. O CLI deliberadamente não possui comando de execução real.

## Validação e históricos

`toy_validation_attempt5.json`: **26 TOYs passaram**, com avisos tratados como erro. Foram verificadas as prioris e medidas alpha/CDF-priori, extremos/cutoffs, grade e separação das sondas, Bernstein/subdivisão, traços independentes dos momentos, envelopes CN e normais contra determinante/solve diretos, covariância quase singular, todos os sete roteamentos, eventos simples/duplos/platôs/sem raízes, massa ambígua concentrada, oscilações cuja integral converge antes da forma, controle de cache/recursos/interrupção e consistência N/A/Z.

A primeira tentativa teve uma fixture incorreta: uma reta SPD com eta<1 foi usada para exigir rejeição eta≥1. O teste foi corrigido para uma curva quadrática SPD de grande variação; o log/resultado/fontes anteriores foram preservados. A revisão independente também reproduziu deriva de cutoff, reserva interrompida entre ledgers e `KeyboardInterrupt` mascarado, além de um callback de massa inconsistente. As correções e os testes respectivos não apagam esses contraexemplos.

`history/attempt1_sources` conserva todas as fontes iniciais. `history/attempt3_sources` conserva as fontes anteriores às correções de endpoints/reservas. `history/attempt4_sources` conserva o consumidor agregado antes do guard de referência inconsistente. Os preflights de cada tentativa e resultados estão vinculados por SHA. Tentativa2 compartilha fontes com o snapshot3 exceto os dois metadados preservados em `history/attempt2_sources` e os arquivos novos da tentativa3 que não integravam sua closure.

A aprovação desses TOYs não aprova nenhuma posterior real. D1 ainda terá de resolver, ou registrar como não resolvidos, os mesmos 14 casos. Comparações pareadas de robustez D2 e calibração representativa D3 permanecem etapas futuras com orçamento próprio.
