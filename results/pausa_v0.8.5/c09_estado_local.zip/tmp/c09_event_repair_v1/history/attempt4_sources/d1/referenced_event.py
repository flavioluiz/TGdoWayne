"""Final numerator references on merged regions, avoiding one GK per table cell.

Cell masses guide refinement via upper bounds. Final N/A/Z have separate error
intervals from independent density integration; no PCHIP point is renamed a bound.
"""
import math
from .measure import x_to_u,CanonicalCoordinates
from .partition import MassRange,coverage,classification


NAMED_CONTROLS = ('normalization','cdf','quantiles','moments','kl','offgrid_loglike',
                  'warning_free','finite_mass_reference','finite_physical_response_evidence')


def selection_mass(envelope,prior,low_u,high_u,*,log_shift,denominator_upper,scale_identity):
    """Saved-table envelope × EXACT prior measure (up to recorded FP allowance).

    denominator_upper is a separately validated total mass upper endpoint in the
    same exp(ell-log_shift) scale; it caps otherwise infinite cell upper bounds.
    Ordinary arithmetic and numerical Z intervals remain operational evidence.
    """
    if (not math.isfinite(log_shift) or not math.isfinite(denominator_upper)
            or denominator_upper <= 0 or not prior.lower <= low_u <= high_u <= 1):
        raise ValueError('valid prior cell, shift and positive independent Z upper required')
    # Stable prior masses, avoiding subtraction of nearly equal CDF values.
    if prior.kind == 'uniform_u': width = high_u-low_u
    elif prior.kind == 'uniform_u_squared': width = (high_u-low_u)*(high_u+low_u)
    else: width = math.log1p((high_u-low_u)/low_u)/math.log(1/prior.lower)
    if width == 0: return MassRange(0,0,scale_identity)
    logwidth = math.log(width)
    cap = math.log(denominator_upper)
    lo = logwidth+envelope.lower-log_shift
    hi = logwidth+envelope.upper-log_shift
    if lo > cap: raise ArithmeticError('cell lower bound exceeds reference total mass upper')
    lower = 0. if lo == -math.inf else math.exp(lo)
    upper = denominator_upper if hi >= cap else math.exp(hi)
    return MassRange(lower,upper,scale_identity)


def merged_regions(cells,level,*,support,canonical_coordinates):
    if not isinstance(canonical_coordinates,CanonicalCoordinates): raise TypeError('canonical endpoint map required')
    coverage(cells,support)
    out = {'inside':[],'ambiguous':[],'outside':[]}
    for cell in cells:
        kind = classification(cell,level)
        entries = out[kind]
        if entries and entries[-1][1] == cell.left:
            entries[-1] = (entries[-1][0],cell.right)
        else:
            entries.append((cell.left,cell.right))
    return {kind:tuple((canonical_coordinates(a),canonical_coordinates(b)) for a,b in regions)
            for kind,regions in out.items()}


def referenced_probability_interval(cells,level,denominator,*,support,reference_mass,
                                    backend_probability_margin,representation_probability_margin,controls,canonical_coordinates):
    """reference_mass takes a UNION of disjoint u intervals, returning one N±E.

    It must reserve each callback logL through the same central ledger. This
    routine does not evaluate logL or assume the callback's error is certified.
    """
    if not math.isfinite(level.lower) or not math.isfinite(level.upper): raise ValueError('finite threshold interval required')
    regions = merged_regions(cells,level,support=support,canonical_coordinates=canonical_coordinates)
    if denominator.lower <= 0 or denominator.scale_identity != cells[0].mass.scale_identity:
        raise ValueError('positive reference denominator in the cell scale required')
    masses = {}
    for kind in ('inside','ambiguous'):
        intervals = regions[kind]
        masses[kind] = reference_mass(intervals) if intervals else MassRange(0,0,denominator.scale_identity)
        if not isinstance(masses[kind],MassRange) or masses[kind].scale_identity != denominator.scale_identity:
            raise ValueError('reference numerator has wrong type/scale')
    N,A,Z = masses['inside'],masses['ambiguous'],denominator
    if N.lower+A.lower > Z.upper: raise ArithmeticError('disjoint numerator lower exceeds total mass upper')
    core = [N.lower/Z.upper,min(1.,(N.upper+A.upper)/Z.lower)]
    ambiguity = min(1.,A.upper/Z.lower)
    quadrature_error = ((N.upper-N.lower)+(A.upper-A.lower)+(Z.upper-Z.lower))/Z.lower
    evidence = all(v is not None and math.isfinite(v) and v >= 0
                   for v in (backend_probability_margin,representation_probability_margin))
    b = backend_probability_margin if evidence else 0.
    r = representation_probability_margin if evidence else 0.
    candidate = [max(0.,core[0]-b-r),min(1.,core[1]+b+r)]
    total = ambiguity+quadrature_error+b+r
    gates = {'ambiguity_mass':ambiguity<=.001,'quadrature':quadrature_error<=.00025,
             'finite_backend_margin':evidence and b<=.00025,'representation_difference':evidence and r<=.0005,
             'total_operational_error':evidence and total<=.002,
             'other_original_gates':isinstance(controls,dict) and all(controls.get(k) is True for k in NAMED_CONTROLS)}
    passed = all(gates.values())
    return {'status':'RESOLVED_OPERATIONAL' if passed else 'UNRESOLVED',
            'interval':candidate if passed else [0.,1.], 'candidate_interval':candidate,
            'core_interval':core,'ambiguous_mass_upper':ambiguity,
            'quadrature_operational_error':quadrature_error,
            'total_operational_error':total if evidence else None,'gates':gates,
            'regions_u':{k:[list(x) for x in v] for k,v in regions.items()},
            'references':{'inside':N.__dict__,'ambiguous':A.__dict__,'denominator':Z.__dict__},
            'rigorous_floatingpoint_certificate':False,'uniform_physical_certificate':False}
