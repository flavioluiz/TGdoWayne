#!/usr/bin/env python3
"""Only metadata preflight and synthetic tests are executable in this candidate."""
import argparse
import hashlib
import json
from pathlib import Path
import resource
import sys
import time
import unittest
import warnings

HERE=Path(__file__).resolve().parent


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=('preflight','toys'))
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    pre=json.loads((HERE/'spec.json').read_text())
    if args.command=='preflight':
        print(json.dumps(pre,indent=2,ensure_ascii=False)); return 0
    if args.output is None or args.output.exists():
        p.error('TOYs require a new --output path; no overwrite')
    plan=HERE/'toy_preflight.json'
    toy=json.loads(plan.read_text())
    for item in toy['sources']:
        if sha(HERE/item['path']) != item['sha256']: raise ValueError('source changed after TOY preflight')
    # No physical modules, data, NPZ or tables are imported by this runner.
    warnings.simplefilter('error')
    before=time.process_time()
    suite=unittest.defaultTestLoader.discover(str(HERE/'tests'),pattern='test_*.py')
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    elapsed=time.process_time()-before
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    rss_bytes=int(rss if sys.platform=='darwin' else rss*1024)
    report={'schema':'C09_D1_SYNTHETIC_VALIDATION_v1','passed':result.wasSuccessful(),
            'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
            'CPU_seconds':elapsed,'RSS_peak_bytes':rss_bytes,
            'toy_preflight_sha256':sha(plan),'budget_pass':elapsed<=toy['maximum_CPU_seconds'] and rss_bytes<=toy['maximum_RSS_bytes'],
            'physical_ORF':0,'physical_logL':0,'physical_bank':0,'new_MC':0,'real_NPZ_arrays_read':0,
            'physical_execution_authorized':False,'C09_complete':False}
    with args.output.open('x') as stream: json.dump(report,stream,indent=2);stream.write('\n')
    return 0 if report['passed'] and report['budget_pass'] else 1

if __name__=='__main__': raise SystemExit(main())
