"""Exact-arithmetic perturbation inequalities, evaluated in ordinary float64.

These are enclosures of the SAVED polynomial table under the stated algebraic
assumptions. No directed rounding or uniform physical-response certificate is
provided. `roundoff_allowance` must be operationally validated by the caller.
"""
from dataclasses import dataclass
import math
import numpy as np
from .polynomial import coefficients, evaluate, bernstein


@dataclass(frozen=True)
class LogRange:
    lower: float
    upper: float
    reason: str = 'saved_table_cell_envelope'
    maximum_eta: float = 0.

    def __post_init__(self):
        if np.isnan([self.lower,self.upper]).any() or self.lower > self.upper:
            raise ValueError('ordered logL range required')


def _matrix(a):
    a = coefficients(a)
    if a.ndim != 4 or a.shape[-2] != a.shape[-1]:
        raise ValueError('(degree+1,blocks,dimension,dimension) required')
    if not np.allclose(a,a.swapaxes(-1,-2).conj(),atol=1e-12,rtol=1e-12):
        raise ValueError('Hermitian matrix polynomial required')
    return a


def _whiten_matrix(L,a):
    first = np.linalg.solve(L,a)
    return np.linalg.solve(L,first.swapaxes(-1,-2).conj()).swapaxes(-1,-2).conj()


def _reference(a):
    center = evaluate(a,.5)
    L = np.linalg.cholesky(center)
    controls = bernstein(a)-center[None]
    relative = _whiten_matrix(L,controls)
    eta = np.max(np.linalg.norm(relative,axis=(-2,-1)),axis=0)
    return L,eta


def _finish(reference,radius,eta,roundoff_allowance):
    if not np.isfinite(reference) or not np.isfinite(roundoff_allowance) or roundoff_allowance < 0:
        raise ValueError('finite center logL and explicit nonnegative allowance required')
    if not np.isfinite(radius):
        return LogRange(-math.inf,math.inf,'eta_or_whitening_unresolved',float(np.max(eta,initial=math.inf)))
    radius += roundoff_allowance
    return LogRange(float(reference-radius),float(reference+radius),maximum_eta=float(np.max(eta,initial=0)))


def cn_envelope(c,q,reference_loglike,*,roundoff_allowance):
    """For A0_CN only. Center logL supplied by the charged cache, never re-scored."""
    c = _matrix(c); q = np.asarray(q)
    if q.shape != (c.shape[1],c.shape[-1]) or not np.isfinite(q).all(): raise ValueError('q shape')
    try:
        L,eta = _reference(c)
        z = np.linalg.solve(L,q[...,None])[...,0]
        chi = np.sum(abs(z)**2,axis=-1)
    except np.linalg.LinAlgError:
        return _finish(reference_loglike,math.inf,np.array([math.inf]),roundoff_allowance)
    if not np.isfinite(eta).all() or np.any(eta >= 1):
        return _finish(reference_loglike,math.inf,eta,roundoff_allowance)
    radius = np.sum(-c.shape[-1]*np.log1p(-eta)+chi*eta/(1-eta))
    return _finish(reference_loglike,float(radius),eta,roundoff_allowance)


def normal_envelope(mu,sigma,y,reference_loglike,*,roundoff_allowance):
    """A_G: K blocks; all B_* including B_CN: one compressed normal block."""
    mu,sigma = coefficients(mu),_matrix(sigma)
    y = np.asarray(y,float)
    if (mu.ndim != 3 or mu.dtype.kind == 'c' or sigma.dtype.kind == 'c'
            or mu.shape[1:] != sigma.shape[1:3] or y.shape != mu.shape[1:]
            or not np.isfinite(y).all()): raise ValueError('real compatible mean/covariance/observation required')
    try:
        L,eta = _reference(sigma)
        center = evaluate(mu,.5)
        r = np.linalg.norm(np.linalg.solve(L,(y-center)[...,None])[...,0],axis=-1)
        delta = bernstein(mu)-center[None]
        a = np.max(np.linalg.norm(np.linalg.solve(L,delta[...,None])[...,0],axis=-1),axis=0)
    except np.linalg.LinAlgError:
        return _finish(reference_loglike,math.inf,np.array([math.inf]),roundoff_allowance)
    if not np.isfinite(eta).all() or np.any(eta >= 1):
        return _finish(reference_loglike,math.inf,eta,roundoff_allowance)
    radius = .5*np.sum(-sigma.shape[-1]*np.log1p(-eta)+(eta*r*r+2*r*a+a*a)/(1-eta))
    return _finish(reference_loglike,float(radius),eta,roundoff_allowance)
