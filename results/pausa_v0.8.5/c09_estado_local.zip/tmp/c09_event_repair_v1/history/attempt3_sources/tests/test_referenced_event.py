import math
import unittest
import numpy as np
from d1.envelope import LogRange
from d1.measure import Prior
from d1.partition import Cell,MassRange
from d1.referenced_event import selection_mass,merged_regions,referenced_probability_interval,NAMED_CONTROLS

class ReferencedEvents(unittest.TestCase):
    def test_full_prior_mass_and_log_cutoff(self):
        for p in (Prior('uniform_u'),Prior('uniform_u_squared'),Prior('log_uniform_u')):
            m=selection_mass(LogRange(4,4),p,p.lower,1,log_shift=4,denominator_upper=1,scale_identity='s')
            self.assertEqual(m.lower,1);self.assertEqual(m.upper,1)
        m=selection_mass(LogRange(-math.inf,math.inf),Prior('uniform_u'),.4,.5,
                         log_shift=0,denominator_upper=2,scale_identity='s')
        self.assertEqual((m.lower,m.upper),(0,2))

    def test_contiguous_regions_merge_and_error_terms_remain_separate(self):
        cells=[Cell(-1,-.75,LogRange(-2,-1),MassRange(.25,.25,'s')),
               Cell(-.75,-.5,LogRange(-2,-1),MassRange(.25,.25,'s')),
               Cell(-.5,-.49,LogRange(-1,1),MassRange(.0002,.0002,'s')),
               Cell(-.49,0,LogRange(1,2),MassRange(.4998,.4998,'s'))]
        regions=merged_regions(cells,LogRange(0,0),support=(-1,0))
        self.assertEqual(len(regions['inside']),1)
        calls=[]
        def ref(intervals):
            calls.append(intervals)
            return MassRange(.49999,.50001,'s') if intervals[0][0]==0 else MassRange(.00019,.00021,'s')
        out=referenced_probability_interval(cells,LogRange(0,0),MassRange(.99999,1.00001,'s'),
                support=(-1,0),reference_mass=ref,backend_probability_margin=0,representation_probability_margin=0,
                controls=dict.fromkeys(NAMED_CONTROLS,True))
        self.assertEqual(len(calls),2)
        self.assertEqual(out['status'],'RESOLVED_OPERATIONAL')
        self.assertAlmostEqual(out['core_interval'][0],.49999/1.00001)
        self.assertAlmostEqual(out['core_interval'][1],(.50001+.00021)/.99999)
        self.assertAlmostEqual(out['quadrature_operational_error'],.00006/.99999)

    def test_empty_event_no_reference_callback_and_unknown_backend_kept(self):
        cells=[Cell(-1,0,LogRange(2,2),MassRange(1,1,'s'))]
        def forbidden(x):raise AssertionError('empty event has no numerator evaluations')
        out=referenced_probability_interval(cells,LogRange(0,0),MassRange(1,1,'s'),support=(-1,0),reference_mass=forbidden,
                backend_probability_margin=None,representation_probability_margin=0,controls=dict.fromkeys(NAMED_CONTROLS,True))
        self.assertEqual(out['interval'],[0,1]);self.assertEqual(out['core_interval'],[0,0])

if __name__=='__main__':unittest.main()
