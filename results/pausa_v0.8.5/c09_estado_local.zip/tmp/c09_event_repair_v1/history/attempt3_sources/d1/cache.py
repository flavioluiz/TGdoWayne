"""Identity-scoped exact float64 cache. Reservations survive failed evaluations."""
import hashlib
import json
import time
import numpy as np


class BudgetExceeded(RuntimeError): pass


class Ledger:
    def __init__(self, *, maximum_values, maximum_cpu_seconds, historical_values=0,
                 cumulative_maximum_values=1000000):
        if any(type(v) is not int or v < 0 for v in (maximum_values,historical_values,cumulative_maximum_values)):
            raise ValueError('integer nonnegative counts required')
        if not np.isfinite(maximum_cpu_seconds) or maximum_cpu_seconds <= 0:
            raise ValueError('positive explicit CPU cap required')
        self.limit,self.cpu_limit = maximum_values,float(maximum_cpu_seconds)
        self.history,self.cumulative_limit = historical_values,cumulative_maximum_values
        if self.history+self.limit > self.cumulative_limit: raise ValueError('prospective cumulative budget exceeds cap')
        self.charged = 0; self.calls = 0; self.records = []; self.start = time.process_time()

    def checkpoint(self):
        if time.process_time()-self.start > self.cpu_limit: raise BudgetExceeded('local CPU cap exceeded')

    def reserve(self,n):
        if type(n) is not int or n < 1: raise ValueError('positive reservation required')
        self.checkpoint()
        if self.charged+n > self.limit: raise BudgetExceeded('value cap before callback')
        self.charged += n; self.calls += 1
        self.records.append({'reserved_values':n,'status':'RESERVED_BEFORE_CALL'})
        return len(self.records)-1


class ChargedCache:
    def __init__(self,callback,identity,global_ledger,target_ledger):
        keys = ('target_id','data_sha256','model_sha256','table_sha256','sources_sha256')
        if not isinstance(identity,dict) or any(k not in identity for k in keys): raise ValueError('full cache identity required')
        for k in keys[1:]:
            v = identity[k]
            if not isinstance(v,str) or len(v) != 64 or any(c not in '0123456789abcdef' for c in v):
                raise ValueError('canonical SHA256 identity required')
        self.identity = json.loads(json.dumps(identity,sort_keys=True))
        self.identity_sha256 = hashlib.sha256(json.dumps(self.identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        self.callback,self.global_ledger,self.target_ledger = callback,global_ledger,target_ledger
        if global_ledger is target_ledger: raise ValueError('distinct global and per-target ledgers required')
        self.values = {}; self.hits = 0; self.coalesced_same_batch = 0

    @staticmethod
    def key(u):
        u = np.float64(u)
        if not np.isfinite(u) or not 0 <= u <= 1: raise ValueError('u outside [0,1]')
        if u == 0: u = np.float64(0)  # one mathematical endpoint, canonical +0 bytes.
        return u.tobytes().hex()

    def __call__(self,u):
        u = np.asarray(u,float)
        if u.ndim != 1: raise ValueError('vector of u required')
        keys = [self.key(x) for x in u]
        missing = dict((k,float(x)) for k,x in zip(keys,u) if k not in self.values)
        cached = sum(k in self.values for k in keys)
        self.hits += cached
        self.coalesced_same_batch += len(keys)-cached-len(missing)
        if missing:
            n = len(missing)
            # Preflight both ledgers before charging either; reservations never refunded.
            for ledger in (self.global_ledger,self.target_ledger):
                ledger.checkpoint()
                if ledger.charged+n > ledger.limit: raise BudgetExceeded('global/per-target cap before callback')
            g = self.global_ledger.reserve(n); t = self.target_ledger.reserve(n)
            try:
                y = np.asarray(self.callback(np.array(list(missing.values()))),float)
                if y.shape != (n,) or not np.isfinite(y).all(): raise ValueError('finite normalized logL vector required')
                self.global_ledger.checkpoint(); self.target_ledger.checkpoint()
                self.values.update(zip(missing,y.tolist()))
                status = 'COMPLETE'
            except Exception:
                status = 'FAILED_CHARGED'
                raise
            finally:
                self.global_ledger.records[g]['status'] = status
                self.target_ledger.records[t]['status'] = status
        return np.array([self.values[k] for k in keys])
