"""Same finite polynomial convolution using paired coefficients and small BLAS RHS.

No interpolation/sampling/approximation is added. Reference is frozen d1.polynomial.
"""
import numpy as np
from d1.polynomial import coefficients


def quadratic_moment_coefficients(c,H):
    c,H=coefficients(c),np.asarray(H)
    if c.ndim!=4 or c.shape[-1]!=c.shape[-2] or H.ndim!=3 or H.shape[-2:]!=c.shape[-2:]:
        raise ValueError('covariance polynomial and Hermitian forms required')
    for a in (c,H):
        if not np.isfinite(a).all() or not np.allclose(a,a.swapaxes(-1,-2).conj(),atol=1e-12,rtol=1e-12):
            raise ValueError('finite Hermitian coefficients/forms required')
    mu=np.einsum('aij,rkji->rka',H,c)
    hc=H[None,None]@c[:,:,None]
    n,k,d,p,_=hc.shape
    a=hc.reshape(n,k,d,p*p)
    b=hc.swapaxes(-1,-2).reshape(n,k,d,p*p).swapaxes(-1,-2)
    cov=np.zeros((2*n-1,k,d,d),complex)
    for i in range(n):
        for j in range(i,n):
            term=a[i]@b[j]
            cov[i+j]+=term if i==j else term+term.swapaxes(-1,-2)
    for v in (mu,cov):
        if np.max(abs(v.imag),initial=0)>1e-10*max(1.,float(np.max(abs(v.real),initial=0))):
            raise ArithmeticError('quadratic trace should be real')
    return mu.real,cov.real
