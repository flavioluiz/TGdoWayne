"""Exact event integration for the finite piecewise-cubic SURROGATE only."""
import math
import numpy as np
from d1.measure import x_to_u


def probability(event,cdf,level,*,canonical_coordinates):
    if not math.isfinite(level):raise ValueError('finite level required')
    roots=event.solve(level,discontinuity=False,extrapolate=False)
    roots=roots[np.isfinite(roots)&(roots>=event.x[0])&(roots<=event.x[-1])]
    edges=np.unique(np.r_[event.x,roots])
    mids=edges[:-1]+.5*np.diff(edges)
    inside=np.asarray(event(mids)<=level)
    regions=[]
    for a,b,yes in zip(edges[:-1],edges[1:],inside):
        if yes:
            if regions and regions[-1][1]==a:regions[-1]=(regions[-1][0],float(b))
            else:regions.append((float(a),float(b)))
    mass=math.fsum(cdf(canonical_coordinates(b))-cdf(canonical_coordinates(a)) for a,b in regions)
    if not math.isfinite(mass) or mass < -1e-12 or mass > 1+1e-12:raise ArithmeticError('surrogate event mass inconsistent')
    return {'probability':min(1.,max(0.,mass)),'regions_x':regions,'finite_roots_count':len(roots),
            'scope':'PIECEWISE_SURROGATE_ONLY_NOT_PHYSICAL_TOPOLOGY','constant_pieces_supported':True}
