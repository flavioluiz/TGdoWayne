Continuação D1b prospectiva: somente cinco caches arquivados

Este pacote prepara execução separada dos IDs **[0,4,6,10,11]**, sem executar física. O D1 original e todos os seus arquivos permanecem intactos. `preflight.json` tem execução desabilitada por padrão, modo e schema D1b próprios; nenhuma autorização ROOT para D1b foi criada. O supervisor rejeita autorizações D1 antigas, saída existente e reservas para os nove IDs inativos.

ROOT revisou D1 em `tmp/c09_ROOT/D1_result_review_v1.json`: 325.629 valores novos foram armazenados e cobrados; nove alvos fecharam o evento da tabela, enquanto os cinco selecionados atingiram25.000 valores em `DirectUnionMass`. Os intervalos físicos seguem pendentes em todos os casos, porque falta uma margem probabilística de backend aprovada. Este pacote mantém `backend_probability_margin_by_target=None`; não converte discrepâncias esparsas de logL em erro de probabilidade e não altera flags ou tolerâncias.

| Recurso | Histórico herdado | Novo limite proposto | Cumulativo proposto / teto anterior |
|---|---:|---:|---:|
| LL | 536.217 | 50.000 misses | 586.217 /1.000.000 |
| LL por ID ativo | 42.936–46.430 | 10.000 misses | máximo56.430 /60.000 |
| CPU | 449,022608 s | 120 s | 569,022608 /600 s |
| ORF harmônica | 214.577.271.056 produtos | 0 | mesmo valor /250 G |
| Céu | 74.530.432 pontos | 0 | mesmo valor /80 M |
| Saída | 9.181.315 B | 8.388.608 B (8 MiB) | 17.569.923 /20.971.520 B |
| RSS | medição operacional por processo | mesma soma conservadora | 1.610.612.736 B |
| Arrays | construtor v4 preservado | mesmo limite estimado | 1.400.000.000 B |

CPU histórica inclui o recibo externo ROOT D1 (`D1_external_end_v1.json`), com imports e exit dos processos filhos medidos:152,935084 s novos, além de296,087524 s anteriores. Preserva-se a exclusão documentada da serialização/exit do último recibo ROOT depois da amostra; não é fabricada uma remedição. O novo supervisor herda449,022608 s e cobra startup, preflight, worker e encerramento pela mesma política. ROOT deverá medir externamente também o encerramento deste supervisor antes de qualquer continuação. O limite120 s é máximo, não previsão de tempo ou promessa de resolução.

Os bytes históricos são2.543.953 anteriores +6.637.362 de D1. Por isso o teto novo é8 MiB; não caberiam12 MiB adicionais sob20 MiB cumulativos. Payload do worker, recibos e log têm reservas separadas; o wrapper não amplia teto em falha. O status `ALL5_RECORDED_NOT_C09_COMPLETE` significa persistência dos cinco resultados, não PASS numérico.

Cada ID selecionado tem recibo de25.000 scores armazenados,25.000 cobrados, nenhuma reserva falha e SHA próprio. Os125.000 valores são candidatos verificáveis a reuso; não são crédito de custo histórico. O preparador leu JSON e hashes de arquivos, sem decodificar NPZ real. Somente o worker autorizado poderá carregar os arrays e confirmar nomes, tipo float64, forma, finitude, ordem, unicidade, zero canônico, suporte e número exato. Tamanho ZIP e tamanho descomprimido são checados antes de NumPy. SHA do arquivo e do recibo são verificados antes e depois do carregamento.

A ponte de identidade preserva duas proveniências: o cache antigo possui o hash do conjunto completo de bindings D1, e o cache novo possui o hash do conjunto D1b. Não se exige nem se inventa igualdade desses dois hashes. Exige-se igualdade de ID, hash do dado, hash canônico da mesma linha/modelo e hash da tabela; o digest antigo é recomputado a partir do preflight D1 original. Toda a closure antiga permanece vinculada e é revalidada. Os cinco helpers numéricos locais são cópias byte a byte; kernels, integrador, PCHIP, medidas e álgebra de células continuam com os hashes antigos. O delta científico não muda a função de likelihood; altera preload, contadores, seleção e limite de subdivisão. Essa compatibilidade de código é revisável em `delta.patch`, não inferida só da semelhança de nomes.

O cache novo começa com contador novo zero e apenas os valores efetivamente carregados. Cada miss é reservado no guard canônico antes da callback; os ledgers puros continuam espelhos, sem serem somados ao canônico. Um lote interrompido permanece cobrado e seus valores não se tornam hits. Lotes anteriores completos são preservados. A persistência nova distingue `preloaded_values`, `new_completed_values`, `shadow_reserved_values` e `canonical_reserved_for_target`. Portanto um cache de35.000 entradas não é interpretado como35.000 LL novas; também não se descontam25.000 do contador histórico.

A partição é **reconstruída**, não restaurada de uma árvore inexistente para esses cinco alvos. A grade L0/L1, scouts, validação, coordenada x=−beta, priors, centros, limiar e critérios são os mesmos. A regra maior massa ambígua primeiro é preservada, com profundidade máxima32 e até2.399 subdivisões **totais**. O número efetivo é limitado pela cota de10.000 misses restantes e pela reserva de2.048 para referências. A nova folga pode produzir mais células do que D1; isso muda as uniões referenciadas e é declarado. Se mudarem os nós GK dessas uniões, somente os pontos realmente presentes no cache ganham reuso. Não há promessa de que a cota baste. Os limites continuam aplicados antes de qualquer novo valor.

São preservados sem mudanças `DirectUnionMass` (GK21 no CDF da priori, união de intervalos), denominador histórico e controles da mesma função, discrepância L0/L1, envelopes matriciais, soma de erros e gates. As referências históricas de normalização são reutilizadas sob a mesma condição de igualdade das summaries GL. A tabela v4 por canal mantém spline, condições de contorno e fallback global; não há ORF nova nem ajuste de spline. Um worker fresco sequencial processa os cinco IDs com uma tabela. A seleção não gera observações, verdades, PHI, Γ ou banco posterior.

O cache float64 máximo tem560.000 B por alvo (35.000 pares). As cinco saídas de cache somam no máximo2.800.000 B numéricos antes de compressão; as cinco matrizes compactas de células têm no máximo3.005.520 B. Reserva-se estimativamente16 MiB de objetos Python por cache e32 MiB para possível sobreposição breve entre dois alvos, além dos arrays pequenos de exportação. Esses valores não são um bound de RSS: o construtor mantém seu guard numérico e o supervisor verifica a soma de máximos RSS do próprio processo e do worker. O pico histórico D1 foi802.390.016 B nessa soma, mas não é garantia de pico futuro. Não se mantém uma tabela adicional por alvo.

Doze TOYs novos passaram na tentativa3, com0,542591 s CPU total amostrado e117.342.208 B de soma conservadora de picos RSS. Eles cobrem arquivos/identidades malformados, reserva sem valores, somente misses únicos, interrupção de lote, guard de IDs inativos, autorização D1 antiga rejeitada e recibo ausente sem crédito falso. Um engine sintético aquecido a partir do cache v1 produz células/flags/intervalos idênticos com zero novas callbacks; a diferença legítima de `scale_identity` acompanha o novo hash de fontes e foi verificada separadamente. Não repetimos a suíte matemática completa anterior.

A tentativa1 está preservada em `history/attempt1`: um único assert esperava igualdade também do hash de proveniência na escala. O cache e os números estavam iguais; o teste foi corrigido para exigir que o sufixo numérico fosse igual e o prefixo identificasse corretamente cada fonte. Nenhuma fórmula científica mudou para fazer o teste passar. A revisão estática independente de introducao_c02 confirmou a contagem e encontrou leitura integral antes do guard de tamanho; o fechamento anterior foi preservado em `history/before_bounded_read_guard`. O SHA agora usa blocos de64 KiB, e arquivo/JSON recebem teto antes da leitura. Um TOY adicional prova rejeição antes do primeiro hash. As três tentativas juntas consumiram1,607166 s CPU amostrado; o custo de pequenos comandos de edição/hash/preflight não está incluído nessa soma. Nenhum ORF, LL física, draw ou NPZ real foi avaliado nesses testes.

Comandos prospectivos, sem autorização embutida:

```sh
python3 -B tmp/c09_D1b_candidate_v1/supervisor.py preflight --plan tmp/c09_D1b_candidate_v1/preflight.json
# Somente depois de revisão e de um novo JSON ROOT explicitamente aprovado:
.venv/bin/python -B tmp/c09_D1b_candidate_v1/supervisor.py execute --plan tmp/c09_D1b_candidate_v1/preflight.json --authorization CAMINHO_ROOT_D1B --output NOVA_SAIDA_D1B
```

O teste/preflight executado aqui não autoriza o segundo comando. Se o processo terminar sem recibo exato, preservam-se50.000 de reserva superior global e10.000 por ID ativo; os nove IDs inativos têm reserva zero. Nenhum retry automático é implementado. O marco C09 e os gates físicos permanecem pendentes, independentemente de eventual resolução operacional dos cinco eventos da tabela.
