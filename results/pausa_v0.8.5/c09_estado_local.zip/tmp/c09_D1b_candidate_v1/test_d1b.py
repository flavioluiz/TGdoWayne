"""New D1b cache/continuation guards only. Tiny TOY values, never physical I/O."""
import copy
import importlib.util
import io
import json
from pathlib import Path
import resource
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
resource.setrlimit(resource.RLIMIT_CPU,(25,26))
sys.path[:0]=[str(HERE),str(ROOT/'tmp/c09_event_repair_v1'),
               str(ROOT/'tmp/c09_integrator'),str(ROOT/'tmp/c09_contour')]
import numpy as np
import supervisor as s
from cache_reuse import load_saved_values,preload_saved_values,canonical_sha,digest
from d1.cache import ChargedCache,Ledger,BudgetExceeded
from batched_cache import BatchedCache

CASES=[]


def identity(source='a'):
    return {'target_id':0,'data_sha256':'b'*64,'model_sha256':'c'*64,
            'table_sha256':'d'*64,'sources_sha256':source*64}


def cache(callback,current,cap=20):
    return ChargedCache(callback,current,Ledger(maximum_values=cap,maximum_cpu_seconds=20),
                        Ledger(maximum_values=cap,maximum_cpu_seconds=20))


class ReuseTests(unittest.TestCase):
    def fixture(self,u=None,ell=None):
        temp=tempfile.TemporaryDirectory(prefix='TOY_cache_',dir=HERE);self.addCleanup(temp.cleanup)
        base=Path(temp.name);u=np.array([0.,.5,1.]) if u is None else u
        ell=np.array([-1.,-2.,-3.]) if ell is None else ell
        old,current=identity('a'),identity('e')
        np.savez_compressed(base/'scores.npz',u=u,log_likelihood=ell)
        record={'identity':old,'identity_sha256':canonical_sha(old),'stored_values':len(u),
                'shadow_reserved_values':len(u),'canonical_reserved_for_target':len(u),'shadow_failed_reservations':[]}
        (base/'identity.json').write_text(json.dumps(record))
        binding={'cache_path':'scores.npz','cache_sha256':digest(base/'scores.npz'),
                 'identity_path':'identity.json','identity_sha256':digest(base/'identity.json'),
                 'expected_identity':old,'legacy_sources_sha256':old['sources_sha256'],
                 'expected_stored_values':len(u)}
        return base,binding,current

    def load(self,b,binding,current):
        return load_saved_values(b,binding,current,prior_lower=0.,checkpoint=lambda:None)

    def test_reuse_exact_values_new_sources_and_only_unique_misses(self):
        b,bind,new=self.fixture();v,r=self.load(b,bind,new);calls=[]
        c=cache(lambda u:(calls.append(u.copy()) or 10+u),new)
        preload_saved_values(c,v,r)
        ans=c(np.array([0.,.25,.5,.25,1.]))
        np.testing.assert_array_equal(ans,[-1.,10.25,-2.,10.25,-3.])
        self.assertEqual(c.target_ledger.charged,1);self.assertEqual(c.global_ledger.charged,1)
        self.assertEqual(len(calls),1);self.assertEqual(c.hits,3)
        self.assertNotEqual(r['legacy_identity']['sources_sha256'],r['current_identity']['sources_sha256'])
        self.assertEqual(r['current_stage_LL_charged_for_import'],0)

    def test_oversized_cache_and_identity_rejected_before_hash_or_full_read(self):
        for filename,maximum in (('scores.npz',1024**2),('identity.json',16384)):
            b,bind,new=self.fixture()
            with (b/filename).open('wb') as f:f.seek(maximum);f.write(b'x')
            with mock.patch('cache_reuse.digest',side_effect=AssertionError('must reject before hash')):
                with self.assertRaises(ValueError):self.load(b,bind,new)

    def test_no_credit_from_malformed_counts_or_failed_reservations(self):
        b,bind,new=self.fixture();record=json.loads((b/'identity.json').read_text())
        for change in ({'stored_values':4},{'shadow_reserved_values':4},
                       {'shadow_failed_reservations':[{'reserved_values':1,'status':'FAILED_CHARGED'}]}):
            (b/'identity.json').write_text(json.dumps({**record,**change}));binding=dict(bind,identity_sha256=digest(b/'identity.json'))
            with self.assertRaises(ValueError):self.load(b,binding,new)

    def test_identity_file_and_source_mismatch_rejected(self):
        b,bind,new=self.fixture()
        for k in ('data_sha256','model_sha256','table_sha256'):
            with self.assertRaises(ValueError):self.load(b,bind,{**new,k:'f'*64})
        with self.assertRaises(ValueError):self.load(b,bind,{**new,'target_id':4})
        with self.assertRaises(ValueError):self.load(b,{**bind,'legacy_sources_sha256':'f'*64},new)
        with self.assertRaises(ValueError):self.load(b,{**bind,'cache_sha256':'0'*64},new)

    def test_float_shape_duplicate_nonfinite_and_noncanonical_zero_rejected(self):
        variants=[(np.array([0.,0.,1.]),None),(np.array([-0.,.5,1.]),None),
                  (np.array([0.,.5,1.],dtype=np.float32),None),
                  (None,np.array([-1.,np.nan,-3.])),(None,np.array([-1.,-2.]))]
        for u,ell in variants:
            b,bind,new=self.fixture(u,ell)
            with self.assertRaises(ValueError):self.load(b,bind,new)

    def test_interruption_keeps_completed_batch_and_failed_charge_without_false_hit(self):
        b,bind,new=self.fixture();v,r=self.load(b,bind,new);calls=[]
        def callback(u):
            calls.append(u.copy())
            if len(calls)==2:raise KeyboardInterrupt('TOY interrupted second batch')
            return u+100
        c=cache(callback,new);preload_saved_values(c,v,r)
        batched=BatchedCache(c,batch=2,checkpoint=lambda:None)
        with self.assertRaises(KeyboardInterrupt):batched(np.array([.1,.2,.3,.4]))
        self.assertEqual(c.target_ledger.charged,4);self.assertEqual(len(c.values),5)
        self.assertEqual(c.target_ledger.records[-1]['status'],'FAILED_CHARGED')
        self.assertNotIn(c.key(.3),c.values)
        self.assertEqual(float(c(np.array([.3]))[0]),100.3)
        self.assertEqual(c.target_ledger.charged,5)  # explicit TOY retry pays again.
        self.assertEqual(float(c(np.array([0.]))[0]),-1.)

    def test_new_miss_cap_does_not_charge_preloaded_values(self):
        b,bind,new=self.fixture();v,r=self.load(b,bind,new)
        c=cache(lambda u:u,new,cap=1);preload_saved_values(c,v,r)
        c(np.array([0.,.25,.5,1.]))
        with self.assertRaises(BudgetExceeded):c(np.array([.75]))
        self.assertEqual(c.target_ledger.charged,1);self.assertNotIn(c.key(.75),c.values)

    def test_warm_engine_has_identical_interval_flags_cells_and_zero_new_callbacks(self):
        # Borrow only synthetic fixture construction, not its old test suite.
        fp=ROOT/'tmp/c09_event_repair_runtime_v1/tests/test_runtime_toy.py'
        spec=importlib.util.spec_from_file_location('d1b_toy_fixture',fp);f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
        ep=ROOT/'tmp/c09_event_repair_runtime_v1/engine.py'
        spec=importlib.util.spec_from_file_location('legacy_engine',ep);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
        spec=importlib.util.spec_from_file_location('new_d1b_engine',HERE/'engine.py')
        current=importlib.util.module_from_spec(spec);spec.loader.exec_module(current)
        target_engine=current.target_engine
        row,config,runtime,table,kernel,hist,oldid=f.fixture('A0_CN','uniform_u')
        oldg=f.ToyGuard();a,c,acells=old.target_engine(row=row,config=config,runtime_config=runtime,table=table,
            kernel=kernel,historical=hist,identity=oldid,guard=oldg,output=None)
        runtime['continuation']={'new_misses_per_target':10000,'new_CPU_seconds':120.}
        new={**oldid,'sources_sha256':'e'*64}
        r={'current_identity':new,'current_identity_sha256':canonical_sha(new),
           'stored_values_imported':len(c.values),'current_stage_LL_charged_for_import':0}
        newg=f.ToyGuard()
        b,warm,bcells=target_engine(row=row,config=config,runtime_config=runtime,table=table,
            kernel=kernel,historical=hist,identity=new,guard=newg,output=None,
            preloaded_values=dict(c.values),preload_receipt=r)
        self.assertEqual(newg.values,0);self.assertEqual(warm.target_ledger.charged,0)
        np.testing.assert_array_equal(acells,bcells)
        self.assertEqual(a['flags'],b['flags'])
        # The scale has identical numeric shift but names its producing source
        # closure. Preserve that correct provenance difference in both outputs.
        adjusted=copy.deepcopy(b['logL_PIT'])
        for kind in ('inside','ambiguous','denominator'):
            previous=a['logL_PIT']['references'][kind]['scale_identity']
            current=adjusted['references'][kind]['scale_identity']
            self.assertEqual(previous.split(':')[1:],current.split(':')[1:])
            self.assertEqual(previous.split(':')[0],oldid['sources_sha256'])
            self.assertEqual(current.split(':')[0],new['sources_sha256'])
            adjusted['references'][kind]['scale_identity']=previous
        self.assertEqual(a['logL_PIT'],adjusted)
        self.assertEqual(b['logL_PIT']['interval'],[0.,1.])


class NewSupervisorTests(unittest.TestCase):
    def fixture(self,mode):
        temp=tempfile.TemporaryDirectory(prefix='TOY_supervisor_',dir=HERE);self.addCleanup(temp.cleanup)
        base=Path(temp.name);out=base/'output'
        limits=dict(s.CAPS,new_cpu_seconds=10.,new_likelihood_values=10,new_likelihood_per_target=2,
                    new_output_bytes=256*1024,rss_bytes=128*1024**2)
        sources=(HERE/'supervisor.py',HERE/'toy_worker.py')
        plan={'schema':'C09_D1B_SUPERVISOR_PLAN_v1','mode':'TOY','scope':s.SCOPE,
              'execution_enabled_by_default':False,'repository':str(ROOT),'limits':limits,
              'bindings':{str(p.relative_to(ROOT)):s.sha(p) for p in sources},
              'worker':str((HERE/'toy_worker.py').relative_to(ROOT)),'worker_parameters':{'toy_mode':mode},
              'history':{'cpu_seconds':0.,'likelihood_values':0,'likelihood_by_target':{k:0 for k in s.HISTORY_BY_ID},'output_bytes':0}}
        pp=base/'plan.json';s.write_new(pp,plan)
        ap=base/'authorization.json';s.write_new(ap,{'schema':'C09_D1B_EXECUTION_AUTHORIZATION_v1',
            'authority':'SYNTHETIC_TEST_ONLY','approved':True,'execution_allowed':True,'mode':'TOY',
            'scope':s.SCOPE,'plan_sha256':s.sha(pp),'output':str(out),'automatic_retry':False})
        return pp,ap,out

    def run_case(self,mode):
        pp,ap,out=self.fixture(mode)
        p=subprocess.run([sys.executable,'-B',str(HERE/'supervisor.py'),'execute','--plan',str(pp),
                          '--authorization',str(ap),'--output',str(out)],capture_output=True,text=True)
        self.assertTrue((out/'execution_end.json').exists(),p.stderr)
        end=json.loads((out/'execution_end.json').read_text());self.assertTrue(end['worker']['child_reaped'])
        self.assertGreater(end['resources']['new_child_CPU_seconds_including_startup_exit'],0)
        self.assertEqual(sum(end['resources']['stage_reserved_by_target'].values()),10)
        self.assertTrue(all(n==0 for k,n in end['resources']['stage_reserved_by_target'].items() if int(k) not in s.ACTIVE_TARGETS))
        CASES.append({'mode':mode,'returncode':p.returncode,'status':end['status'],
                      'child_CPU_seconds':end['worker']['child_CPU_seconds'],
                      'child_peak_RSS_bytes':end['worker']['child_peak_RSS_bytes']})
        return pp,ap,out,end

    def test_active_reservations_no_overwrite_and_new_auth_schema(self):
        pp,ap,out,end=self.run_case('success');self.assertEqual(end['status'],'CONTROLLER_COMPLETED')
        self.assertEqual(end['resources']['observed_worker_LL']['stage_likelihood_values'],1)
        h=s.sha(out/'execution_end.json')
        with self.assertRaises(ValueError):s.execute(pp,ap,out)
        self.assertEqual(h,s.sha(out/'execution_end.json'))
        auth=json.loads(ap.read_text());auth['schema']='C09_D1_EXECUTION_AUTHORIZATION_v1'
        ap.write_text(json.dumps(auth))
        plan=s.read(pp)
        with self.assertRaises(ValueError):s.validate_authorization(ap,plan,s.sha(pp),out)

    def test_inactive_target_cannot_consume_any_new_ll(self):
        _,_,_,end=self.run_case('inactive_target')
        self.assertNotEqual(end['status'],'CONTROLLER_COMPLETED')
        self.assertEqual(end['resources']['observed_worker_LL']['stage_likelihood_values'],0)

    def test_missing_receipt_preserves_only_five_target_upper_reservations(self):
        _,_,_,end=self.run_case('crash')
        self.assertFalse(end['exact_worker_LL_receipt_available'])
        self.assertIsNone(end['resources']['observed_worker_LL'])
        self.assertEqual(end['resources']['stage_reserved_upper_values'],10)

    def test_new_history_and_hard_cumulative_guards(self):
        pp,_,_=self.fixture('success');p=s.read(pp)
        p.update(mode='D1b',active_targets=list(s.ACTIVE_TARGETS),limits=dict(s.CAPS),
          history=dict(cpu_seconds=449.022608,likelihood_values=536217,likelihood_by_target=s.HISTORY_BY_ID,
                       output_bytes=9181315,real_products=214577271056,sky_points=74530432))
        pp.write_text(json.dumps(p));s.validate_plan(pp)
        self.assertEqual(sum(s.HISTORY_BY_ID.values())+s.CAPS['new_likelihood_values'],586217)
        self.assertEqual(449.022608+s.CAPS['new_cpu_seconds'],569.022608)
        for change in ({'active_targets':[0,4,6,10]}, {'limits':dict(s.CAPS,new_likelihood_per_target=10001)},
                       {'history':dict(p['history'],likelihood_values=210588)}):
            pp.write_text(json.dumps({**p,**change}))
            with self.assertRaises(ValueError):s.validate_plan(pp)


if __name__=='__main__':
    output=Path(sys.argv[1]);start=time.perf_counter()
    if output.exists():raise FileExistsError(output)
    result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromTestCase(ReuseTests),
        unittest.defaultTestLoader.loadTestsFromTestCase(NewSupervisorTests)]))
    own=s.cpu();children=s.cpu(resource.RUSAGE_CHILDREN);rss=s.rss();peakchild=s.rss(resource.RUSAGE_CHILDREN)
    record={'passed':result.wasSuccessful(),'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
            'own_CPU_seconds':own,'children_CPU_seconds':children,'total_sampled_CPU_seconds':own+children,
            'wall_seconds':time.perf_counter()-start,'own_peak_RSS_bytes':rss,'child_peak_RSS_bytes':peakchild,
            'conservative_sum_peak_RSS_bytes':rss+peakchild,'within_TOY_caps':own+children<=30 and rss+peakchild<=128*1024**2,
            'subprocess_cases':CASES,'physical_LL':0,'ORF':0,'draws':0,'real_NPZ_reads':0,
            'scope':'New cache/historical guard deltas; no repetition of full old numeric/supervisor suites.'}
    output.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:record[k] for k in ('passed','tests','total_sampled_CPU_seconds','conservative_sum_peak_RSS_bytes','within_TOY_caps')}))
    raise SystemExit(0 if record['passed'] and record['within_TOY_caps'] else 1)
