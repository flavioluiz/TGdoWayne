"""Freeze D1b metadata, hashes and arithmetic. No NumPy or physical imports."""
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
from supervisor import CAPS,HISTORY_BY_ID,ACTIVE_TARGETS,SCOPE,saved_bytes,sha


def read(path):return json.loads((ROOT/path).read_text())
def canonical_sha(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(name,value):
    with (HERE/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')


def main():
    oldplanpath='tmp/c09_event_repair_runtime_v1/preflight.json'
    old=read(oldplanpath)
    endpath='tmp/c09_D1_execution_v1/execution_end.json'
    externalpath='tmp/c09_ROOT/D1_external_end_v1.json'
    reviewpath='tmp/c09_ROOT/D1_result_review_v1.json'
    end,external,review=map(read,(endpath,externalpath,reviewpath))
    assert external['supervisor_end_sha256']==sha(ROOT/endpath)
    assert external['plan_sha256']==sha(ROOT/oldplanpath)
    assert external['cumulative_CPU_seconds']==449.022608
    counts=end['resources']['observed_worker_LL']['cumulative_likelihood_by_target']
    assert counts==HISTORY_BY_ID and sum(counts.values())==536217
    assert review['status']=='D1_COMPACT_PRODUCTS_INDEPENDENTLY_RECONSTRUCTED'
    assert review['failed_ids']==list(ACTIVE_TARGETS)
    old_sources=canonical_sha(old['bindings'])
    records={x['path']:x for x in review['files']}
    runtime=read('tmp/c09_event_repair_runtime_v1/runtime_config.json')
    runtime.update(schema='C09_D1B_RUNTIME_CONFIG_v1',active_targets=list(ACTIVE_TARGETS),
       scope='FIVE_SAVED_NOMINAL14_TARGETS_D1B_NEW_CACHE_MISSES_ONLY_NOT_SBC',
       continuation={'new_misses_per_target':10000,'new_CPU_seconds':120.,'new_misses_global':50000},
       cache_bindings={})
    runtime['algorithm']['no_history_LL_cache_credit']=False
    runtime['algorithm']['reference_budget']='At most2399 total splits in deterministic largest-mass rule, limited by new10000 misses minus observed new charges and2048 reserved for references. Cached old centers do not use new LL.'
    runtime['cache_reuse_policy']='Only125000 stored scores across five SHA-bound archives. All prior CPU/LL retained; no credit for unsaved values. Separate old/new source identities.'
    runtime['partition_policy']='Rebuild from original cells and cached controls under same rule; new miss allowance may produce more cells, at most2399 total splits, not2399 on top of old tree.'
    input_paths=[oldplanpath,endpath,externalpath,reviewpath,'tmp/c09_ROOT/review_D1_v1.py',
                 'tmp/c09_D1_execution_v1/execution_identity.json','tmp/c09_D1_execution_v1/worker/worker_end.json',
                 'tmp/c09_D1_execution_v1/worker/result.json','tmp/c09_ROOT/D1_authorization_v1.json']
    for target in ACTIVE_TARGETS:
        prefix=f'tmp/c09_D1_execution_v1/worker/target_{target:02d}'
        cp,ip,rp=prefix+'_cache.npz',prefix+'_cache_identity.json',prefix+'.json'
        for path in (cp,ip,rp):
            assert sha(ROOT/path)==records[path]['sha256']
        identity=read(ip);failure=read(rp)
        assert failure['target']==target and failure['status']=='UNRESOLVED_NO_AUTOMATIC_RETRY'
        assert 'DirectUnionMass' in failure['traceback'] or 'mass_reference.py' in failure['traceback']
        assert identity['stored_values']==identity['shadow_reserved_values']==identity['canonical_reserved_for_target']==25000
        assert identity['shadow_failed_reservations']==[]
        assert identity['identity_sha256']==canonical_sha(identity['identity'])
        assert identity['identity']['sources_sha256']==old_sources
        row=read(runtime['nominal_config'])['rows'][target]
        assert row['id']==target and identity['identity']['model_sha256']==canonical_sha(row)
        runtime['cache_bindings'][str(target)]={
            'cache_path':cp,'cache_sha256':records[cp]['sha256'],
            'identity_path':ip,'identity_sha256':records[ip]['sha256'],
            'failure_report_path':rp,'failure_report_sha256':records[rp]['sha256'],
            'expected_identity':identity['identity'],'legacy_sources_sha256':old_sources,
            'expected_stored_values':25000}
        input_paths.extend((cp,ip,rp))
    unchanged=('batched_cache.py','cells_runtime.py','polynomial_fast.py','mass_reference.py','surrogate_event.py')
    equivalence=[]
    for name in unchanged:
        original='tmp/c09_event_repair_runtime_v1/'+name
        clone=str((HERE/name).relative_to(ROOT))
        assert sha(ROOT/original)==sha(ROOT/clone)==old['bindings'][original]
        equivalence.append({'original':original,'clone':clone,'sha256':sha(ROOT/clone)})
    runtime['source_compatibility']={'original_plan_path':oldplanpath,'original_plan_sha256':sha(ROOT/oldplanpath),
        'original_sources_identity_sha256':old_sources,'unchanged_cloned_numeric_sources':equivalence,
        'other_original_numeric_sources':'Entire original plan binding set retained and checked before/after execution.',
        'changed_orchestration':'engine preload/new cap; worker five targets and provenance/persistence; supervisor new historical guards; no interval/moment/likelihood formula changes.'}
    write('runtime_config.json',runtime)
    plan=json.loads(json.dumps(old))
    plan.update(schema='C09_D1B_SUPERVISOR_PLAN_v1',mode='D1b',scope=SCOPE,
        worker=str((HERE/'worker.py').relative_to(ROOT)),
        worker_parameters={'runtime_config':str((HERE/'runtime_config.json').relative_to(ROOT))},
        active_targets=list(ACTIVE_TARGETS),limits=dict(CAPS))
    size=saved_bytes(ROOT/'tmp/c09_D1_execution_v1')
    assert size==6637362
    plan['history'].update(cpu_seconds=449.022608,likelihood_values=536217,
        likelihood_by_target=counts,output_bytes=old['history']['output_bytes']+size,
        output_directories=old['history']['output_directories']+['tmp/c09_D1_execution_v1'],
        D1_external_end_path=externalpath,D1_external_end_sha256=sha(ROOT/externalpath),
        D1_result_review_path=reviewpath,D1_result_review_sha256=sha(ROOT/reviewpath),
        previous_receipt_scope='449.022608 includes reaped D1 supervisor/worker and ROOT launcher sample; retain documented final ROOT receipt serialization/exit exclusion.')
    assert plan['history']['output_bytes']==9181315
    for path in input_paths:plan['bindings'][path]=sha(ROOT/path)
    for path in sorted(HERE.glob('*.py')):plan['bindings'][str(path.relative_to(ROOT))]=sha(path)
    plan['bindings'][str((HERE/'runtime_config.json').relative_to(ROOT))]=sha(HERE/'runtime_config.json')
    write('preflight.json',plan)
    arithmetic={
        'schema':'C09_D1B_ARITHMETIC_ONLY_v1','execution_authorized':False,'active_targets':list(ACTIVE_TARGETS),
        'historical_LL':536217,'historical_CPU_seconds':449.022608,
        'preloaded_scores_proven_by_ROOT_receipts':125000,'preloaded_array_values_decoded_in_preparation':0,
        'new_global_misses_cap':50000,'new_per_active_target_misses_cap':10000,
        'new_cumulative_LL_max':586217,'new_CPU_cap_seconds':120.,'cumulative_CPU_proposal_seconds':569.022608,
        'hard_cumulative_LL':1000000,'hard_cumulative_CPU_seconds':600.,'hard_per_target_LL':60000,
        'reserved_by_target':{str(i):(10000 if i in ACTIVE_TARGETS else 0) for i in range(14)},
        'cumulative_by_target_max':{k:n+(10000 if int(k) in ACTIVE_TARGETS else 0) for k,n in counts.items()},
        'historical_output_bytes':9181315,'new_output_cap_bytes':8*1024**2,
        'cumulative_output_proposal_bytes':9181315+8*1024**2,'hard_cumulative_output_bytes':20*1024**2,
        'rss_cap_bytes':1610612736,'estimated_numeric_cap_bytes':1400000000,
        'cache_float_payload_max_bytes_per_target':35000*16,
        'cache_python_dict_allowance_bytes_per_target':16*1024**2,
        'cache_simultaneous_two_target_allowance_bytes':32*1024**2,
        'maximum_cell_numeric_bytes_all_five':5*(8335+2399)*7*8,
        'maximum_cache_numeric_bytes_all_five':5*35000*16,
        'setup_and_envelopes_CPU_must_be_measured_not_credited':True,
        'no_predicted_automatic_success':True,'physical_probability_backend_margin':None,
        'new_ORF':0,'new_sky':0,'new_draws':0,'historical_ORF':214577271056,'historical_sky':74530432}
    write('arithmetic.json',arithmetic)
    print(json.dumps({'status':'METADATA_CANDIDATE_FROZEN_NOT_AUTHORIZED',
                      'preflight_sha256':sha(HERE/'preflight.json'),'bindings':len(plan['bindings']),
                      'historic_output_bytes':plan['history']['output_bytes'],'new_LL_executed':0}))


if __name__=='__main__':main()
