"""Keep completed small callback batches in the frozen cache before the next one."""
import numpy as np

class BatchedCache:
    def __init__(self,cache,*,batch,checkpoint):
        if type(batch)is not int or batch<1:raise ValueError('positive explicit cache batch required')
        self.cache,self.batch,self.checkpoint=cache,batch,checkpoint
    def __getattr__(self,name):return getattr(self.cache,name)
    def __call__(self,u):
        u=np.asarray(u,float)
        if u.ndim!=1:raise ValueError('vector input required')
        values=np.empty(len(u))
        for first in range(0,len(u),self.batch):
            self.checkpoint()
            values[first:first+self.batch]=self.cache(u[first:first+self.batch])
        return values
