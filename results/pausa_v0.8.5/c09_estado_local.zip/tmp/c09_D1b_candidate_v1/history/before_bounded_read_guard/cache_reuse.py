"""Strict reuse of archived exact float64 scores, never credit for reservations.

Import does no I/O. Real cache loading is called only by an authorized worker.
The previous source identity is retained as provenance; it is not rewritten as
if the new orchestration had produced the historical values.
"""
import hashlib
import json
from pathlib import Path
import zipfile
import numpy as np
from d1.cache import ChargedCache


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_saved_values(repository,binding,current_identity,*,prior_lower,checkpoint):
    """Validate bounded archive and exact identities before returning a seed dict.

    binding is part of the disabled-default ROOT-reviewed runtime config. Its
    legacy source digest is computed from the full original D1 plan bindings.
    The new plan separately freezes unchanged numerical dependency hashes.
    """
    checkpoint()
    root=Path(repository)
    archive=root/binding['cache_path'];identity_path=root/binding['identity_path']
    if digest(archive)!=binding['cache_sha256'] or digest(identity_path)!=binding['identity_sha256']:
        raise ValueError('legacy cache file/receipt changed')
    record=json.loads(identity_path.read_text())
    old=record['identity']
    if record['identity_sha256']!=canonical_sha(old):raise ValueError('legacy identity digest mismatch')
    if old!=binding['expected_identity']:raise ValueError('legacy identity differs from frozen selection')
    if old['sources_sha256']!=binding['legacy_sources_sha256']:raise ValueError('legacy source closure mismatch')
    for key in ('target_id','data_sha256','model_sha256','table_sha256'):
        if old[key]!=current_identity[key]:raise ValueError('cached likelihood function identity differs: '+key)
    if not isinstance(current_identity.get('sources_sha256'),str) or len(current_identity['sources_sha256'])!=64:
        raise ValueError('new source closure identity required')
    count=binding['expected_stored_values']
    if type(count)is not int or not 1<=count<=25000:raise ValueError('bounded legacy count required')
    if (record['stored_values']!=count or record['canonical_reserved_for_target']!=count
            or record['shadow_reserved_values']!=count or record['shadow_failed_reservations']):
        raise ValueError('this D1b selection requires proven stored equals charged, with no failed reservation')
    if archive.stat().st_size>1024**2:raise ValueError('legacy cache compressed size exceeds preflight')
    with zipfile.ZipFile(archive) as z:
        info=z.infolist()
        if len(info)!=2 or {i.filename for i in info}!={'u.npy','log_likelihood.npy'}:
            raise ValueError('exact two regular cache arrays required')
        if any(i.file_size>count*8+4096 or i.is_dir() for i in info):
            raise ValueError('legacy array header/payload exceeds expected bounded count')
    with np.load(archive,allow_pickle=False) as f:
        if set(f.files)!={'u','log_likelihood'}:raise ValueError('legacy cache array members differ')
        u=f['u'];ell=f['log_likelihood']
    if any(a.dtype!=np.dtype('float64') or a.shape!=(count,) or not np.isfinite(a).all() for a in (u,ell)):
        raise ValueError('legacy cache float64 shape/finitude mismatch')
    if np.any(u<prior_lower) or np.any(u>1) or np.any(np.diff(u)<=0) or np.any((u==0)&np.signbit(u)):
        raise ValueError('legacy coordinates must be ordered unique canonical prior support values')
    values={ChargedCache.key(x):float(y) for x,y in zip(u,ell)}
    if len(values)!=count:raise ValueError('duplicate legacy float64 keys')
    if digest(archive)!=binding['cache_sha256'] or digest(identity_path)!=binding['identity_sha256']:
        raise ValueError('legacy cache changed during load')
    checkpoint()
    receipt={'legacy_cache_path':binding['cache_path'],'legacy_cache_sha256':binding['cache_sha256'],
             'legacy_identity_file_sha256':binding['identity_sha256'],
             'legacy_identity':old,'legacy_identity_sha256':record['identity_sha256'],
             'current_identity':current_identity,'current_identity_sha256':canonical_sha(current_identity),
             'stored_values_imported':count,'current_stage_LL_charged_for_import':0,
             'historic_costs_retained':True,
             'compatibility':'Same target, datum, row and table; unchanged numerical likelihood sources bound by both plans; new reviewed cache/limit orchestration.'}
    return values,receipt


def preload_saved_values(cache,values,receipt):
    """Install an already validated seed without mutating either new ledger."""
    if cache.values or cache.global_ledger.charged or cache.target_ledger.charged:
        raise ValueError('preload only into a fresh uncharged cache')
    if not isinstance(values,dict) or not isinstance(receipt,dict):raise ValueError('explicit validated preload required')
    if receipt.get('current_identity')!=cache.identity or receipt.get('current_identity_sha256')!=cache.identity_sha256:
        raise ValueError('new cache identity differs from preload bridge')
    if receipt.get('stored_values_imported')!=len(values) or receipt.get('current_stage_LL_charged_for_import')!=0:
        raise ValueError('preload count/charge provenance mismatch')
    for k,v in values.items():
        if not isinstance(k,str) or len(k)!=16:raise ValueError('float64 byte key required')
        x=np.frombuffer(bytes.fromhex(k),dtype=np.float64)[0]
        if ChargedCache.key(x)!=k or not np.isfinite(v):raise ValueError('invalid canonical cached value')
    cache.values.update(values)
