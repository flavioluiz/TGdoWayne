"""Controlled direct mass integrals in v=F_prior(u), through one charged callback.

Historical total mass and CDF controls may be reused only for the identical
function after their source/data/table bindings and GL summaries are checked.
Error intervals below are numerical quadrature estimates, not global proofs.
"""
import math
import warnings
import numpy as np
from scipy.integrate import quad
from d1.partition import MassRange


class DirectUnionMass:
    def __init__(self,log_likelihood,prior,*,log_shift,scale_identity,epsabs,epsrel,limit,checkpoint):
        if (not math.isfinite(log_shift) or not 0<epsabs<1 or not 0<epsrel<1
                or type(limit) is not int or limit<1 or not scale_identity): raise ValueError('explicit reference settings required')
        self.log_likelihood,self.prior=log_likelihood,prior
        self.shift,self.identity=float(log_shift),scale_identity
        self.epsabs,self.epsrel,self.limit=epsabs,epsrel,limit
        self.checkpoint=checkpoint;self.calls=[];self.warning_messages=[]

    def __call__(self,intervals):
        intervals=tuple((float(a),float(b)) for a,b in intervals)
        if not intervals:return MassRange(0,0,self.identity)
        if (any(not self.prior.lower<=a<b<=1 for a,b in intervals)
                or any(a[1]>b[0] for a,b in zip(intervals[:-1],intervals[1:]))):
            raise ValueError('ordered disjoint nonempty prior intervals required')
        value=0.;error=0.;values_before=0
        def integrand(v):
            self.checkpoint()
            u=float(self.prior.ppf(v))
            ell=float(self.log_likelihood(np.array([u]))[0])-self.shift
            if not math.isfinite(ell) or ell>650:raise ArithmeticError('invalid/excessive scaled reference exponent')
            return math.exp(ell)
        for a,b in intervals:
            self.checkpoint()
            va,vb=float(self.prior.cdf(a)),float(self.prior.cdf(b))
            if not va<vb:raise ArithmeticError('nonempty physical interval collapsed in prior CDF')
            with warnings.catch_warnings(record=True) as observed:
                warnings.simplefilter('always')
                answer=quad(integrand,va,vb,epsabs=self.epsabs/len(intervals),epsrel=self.epsrel,
                        limit=self.limit,full_output=1)
                val,err,info=answer[:3]
                success=len(answer)==3
            messages=[str(w.message) for w in observed]
            self.warning_messages.extend(messages)
            record={'low_u':a,'high_u':b,'scaled_mass':float(val),'scaled_error_estimate':float(err),
                    'quad_success':success,'quad_neval':int(info['neval']),'warnings':messages}
            self.calls.append(record)
            if not success or messages:raise ArithmeticError('independent mass quadrature unresolved/warned')
            if not math.isfinite(float(val)) or not math.isfinite(float(err)) or err<0 or val<0:
                raise ArithmeticError('invalid reference mass/error')
            value+=float(val);error+=float(err)
        self.checkpoint()
        return MassRange(max(0.,value-error),value+error,self.identity)


def historical_denominator(report,*,shift,scale_identity):
    logz=float(report['reference_logZ']);relative=float(report['reference_relative_error_estimate'])
    if not math.isfinite(logz) or not math.isfinite(relative) or not 0<=relative<1 or report['reference_warnings']:
        raise ValueError('historical denominator not valid/warning-free')
    if not math.isfinite(shift) or not -700<logz-shift<650:raise ArithmeticError('historical Z scaling out of domain')
    z=math.exp(logz-shift)
    return MassRange(z*(1-relative),z*(1+relative),scale_identity)
