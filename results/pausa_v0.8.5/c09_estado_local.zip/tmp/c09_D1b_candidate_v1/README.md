Este é o candidato separado D1b solicitado por ROOT. Leia `PREFLIGHT.md`, `preflight.json`, `arithmetic.json`, `delta.patch` e `manifest.json`.

Os cinco IDs são0,4,6,10,11. O pacote reaproveita apenas scores arquivados com identidade validada, com limite novo50.000/10.000 LL,120 s CPU e8 MiB. Os tetos históricos600 s/1 M/60 mil por ID/20 MiB/RSS1,5 GiB permanecem. Todas as fontes v1 estão preservadas. `backend_probability_margin_by_target` continuaNone.

`supervisor.py` usa schemas D1b e exige novo JSON ROOT, preflight SHA e destino inexistente. Não foi criado arquivo de autorização real. `prepare.py` produz apenas metadados/hash e recusa sobrescrever saídas. `cache_reuse.py` é chamado com arrays reais somente pelo worker depois dos guards; nenhum array real foi aberto nesta preparação.

`toy_results_attempt3.json`:12 PASS, somente TOYs de reuso, contadores, persistência e equivalência do engine aquecido. O histórico do assert de proveniência incorreto está em `history/attempt1`. `toy_worker.py` só pertence ao modo sintético. Os helpers batched_cache/cells_runtime/polynomial_fast/mass_reference/surrogate_event são cópias byte exatas da versão D1.

O revisor deve confirmar especialmente a ponte antigo/novo hash de fontes, a contagem de caches combinados versus LL novas e a reconstrução prospectiva da partição. Os cinco eventos físicos não ganham aprovação por fechar o evento da tabela.
