"""Callback adapter for one fixed-nuisance model; no files or PTA imports.

The external integrator provides scaled mass intervals. The caller provides the
already frozen response coefficients converted to C coefficients, NOT samples
of C to refit. Creation/evaluation requires explicit callbacks; import is inert.
"""
import numpy as np
from d1.measure import x_to_u,u_to_x,CanonicalCoordinates
from d1.polynomial import restrict,compress_coefficients
from polynomial_fast import quadratic_moment_coefficients
from d1.envelope import cn_envelope,normal_envelope
from d1.partition import Cell

MODELS = ('A0_CN','A_G','B_CN_full_variable','B_G_full_variable',
          'B_G_diagonal_variable','B_G_full_fixed','B_G_diagonal_fixed')


class SavedPolynomialCells:
    def __init__(self,x_edges,covariance_coefficients,*,model,H,observation,weights,
                 center_loglike,mass_interval,roundoff_allowance,canonical_coordinates,fixed_covariance=None):
        edges = np.asarray(x_edges,float)
        # Coefficients are a callable to avoid duplicating the full table or a degree-six bank.
        if (edges.ndim != 1 or len(edges)<2 or edges[0]<-1 or edges[-1]>0
                or not np.isfinite(edges).all() or np.any(np.diff(edges)<=0)):
            raise ValueError('strict saved x edges required')
        if model not in MODELS or not callable(covariance_coefficients): raise ValueError('model/provider required')
        if not np.isfinite(roundoff_allowance) or roundoff_allowance < 0: raise ValueError('explicit allowance')
        if model.endswith('_fixed') != (fixed_covariance is not None): raise ValueError('only fixed models require anchor covariance')
        if not isinstance(canonical_coordinates,CanonicalCoordinates): raise TypeError('canonical table/cutoff endpoint map required')
        self.canonical = canonical_coordinates
        self.edges = edges.copy(); self.provider = covariance_coefficients
        self.model,self.H,self.observation = model,np.asarray(H),np.asarray(observation)
        self.weights,self.center_loglike,self.mass_interval = np.asarray(weights),center_loglike,mass_interval
        self.allowance,self.fixed = roundoff_allowance,fixed_covariance
        self.envelope_calls = 0

    def __call__(self,left,right,depth=0):
        mid = left+(right-left)/2
        i = int(np.searchsorted(self.edges,mid,side='right')-1)
        if i<0 or i>=len(self.edges)-1 or not self.edges[i] <= left < right <= self.edges[i+1]:
            raise ValueError('a cell may not cross any saved polynomial knot')
        width = self.edges[i+1]-self.edges[i]
        c = restrict(self.provider(i),(left-self.edges[i])/width,(right-self.edges[i])/width)
        center_u = float(x_to_u(mid))
        evaluated_x = float(u_to_x(center_u))
        if not left <= evaluated_x <= right:
            raise ArithmeticError('center roundtrip leaves cell at float64 resolution')
        reference_t = (evaluated_x-left)/(right-left)
        ell = float(self.center_loglike(np.array([center_u]))[0])
        if self.model == 'A0_CN':
            envelope = cn_envelope(c,self.observation,ell,roundoff_allowance=self.allowance,reference_t=reference_t)
        else:
            mu,sigma = quadratic_moment_coefficients(c,self.H)
            if self.model != 'A_G':
                mu,sigma = compress_coefficients(mu,sigma,self.weights,fixed_covariance=self.fixed,
                                                  diagonal='_diagonal_' in self.model)
            envelope = normal_envelope(mu,sigma,self.observation,ell,roundoff_allowance=self.allowance,reference_t=reference_t)
        self.envelope_calls += 1  # whitening/trace CPU measured separately; no hidden normalized logL score.
        mass = self.mass_interval(self.canonical(left),self.canonical(right))
        return Cell(left,right,envelope,mass,depth)
