# Revisão matemática independente D1

Escopo: leitura do protocolo/config D1 e das implementações congeladas de
kernel, spline, momentos, prior e likelihood. Nenhuma ORF, likelihood PTA,
matriz/dado NPZ real, banco, draw ou teste numérico foi executado. O executor
`tmp/c09_event_repair_v1` ainda não existia na primeira leitura; este parecer
avalia o contrato matemático e os requisitos para sua implementação, sem
aprovação de execução ou de resultado científico.

As duas fórmulas propostas de perturbação estão corretas em aritmética exata.
Não encontrei impedimento matemático à classificação completa por células
da tabela salva. Ela permite resolver eventos integrais/vazios sem exigir
raízes e preserva tangências/platôs ambíguos quando a envoltória não resolve.
O possível custo de avaliar as envoltórias ainda requer medida/guard próprio;
o custo empírico por likelihood do piloto não mede esse novo trabalho.

## Requisitos materiais antes do lançamento

1. **Rotear o envelope pelo kernel efetivo.** Somente `A0_CN` usa a CN
   complexa própria de q, sem fator 1/2. `B_CN_full_variable` usa a normal
   dos momentos comprimidos de `x_physical`, apesar de conter CN no nome.
   `A_G` soma K blocos normais independentes. Nos modelos B, primeiro
   `mu_B=sum(w_k mu_k)` e `Sigma_B=sum(w_k**2 Sigma_k)`, depois as operações
   fixed/diagonal congeladas. A média continua variável em fixed. Aplicar
   a fórmula CN ao nome B_CN, ou comprimir covariâncias com w em vez de w²,
   produziria um envelope da função errada.

2. **Manter coordenadas e polinômios locais distintos.** No objeto v4 com
   coordinate_name='beta', o campo `.alpha` contém x=-beta, não asin(u).
   `.coeff[j,i]` multiplica a fração local t**i, t=(x-x_j)/(x_{j+1}-x_j).
   Os coeficientes não são potências de x nem de alpha. C é cúbica em t;
   mu tem grau <=3 e Sigma <=6. A covariância deve conter todos os produtos
   ordenados i+j=l; a simplificação dos termos cruzados exige justificar
   sua simetria. Restringir controles a uma subcélula por transformação
   polinomial/de Casteljau; não reutilizar os controles da célula errada.

3. **Classificar contra o nível com sua própria incerteza.** Seja [L,U] a
   envoltória celular e [Tlo,Thi] a do nível ell(u_true), com as margens
   declaradas. O evento ell<=ell_true está inteiro dentro se U<=Tlo,
   inteiro fora se L>Thi, e ambíguo nos demais casos. Tratar a igualdade
   como fora perde platôs de massa positiva. Margens para a curva não
   substituem a margem do nível. Provar cobertura por folhas da árvore
   sobre todo o suporte, sem intervalos faltantes/duplicados; não inferir
   cobertura pela concordância de duas listas de raízes.

4. **Não converter automaticamente erro de logL em margem de PIT.** A
   subcota backend de 0,00025 está em probabilidade; não decorre de um
   maximo finito de delta logL em 16 massas. Deve haver controle operacional
   de PIT/massa correspondente, ou esse subgate permanece pendente. Caso
   se disponha de uma margem de logL delta no domínio declarado, ela entra
   na classificação pelo deslocamento do nível e da curva e pela massa
   da banda de evento, além do efeito nos pesos. Perto de um platô, uma
   perturbação arbitrariamente pequena da forma pode mudar muita massa.
   Não é um pedido de certificado físico uniforme; é uma exigência de
   unidades e de uma evidência operacional identificada. As envoltórias
   da tabela e a evidência finita da resposta física precisam de status
   separados, conforme o protocolo já prevê.

5. **Contabilizar massa ambígua com a medida posterior.** Largura em beta
   ou fração de células não representa massa posterior. Se N é a massa
   não normalizada definitivamente dentro, A a massa ambígua, Z o total,
   e EN, EA, EZ seus erros operacionais não negativos, exigir Z>EZ. Uma
   composição conservadora é

   `Plo=max(0,(N-EN)/(Z+EZ))`

   `Phi=min(1,(N+A+EN+EA)/(Z-EZ))`.

   Essa interseção com [0,1] usa o suporte conhecido da probabilidade;
   valores centrais inválidos/NaN, suporte incompleto ou denominador sem
   margem não devem ser mascarados por clipping. Se a implementação usar
   raio em torno de N/Z, a fórmula já corrigida
   `(EN+abs(N/Z)*EZ)/(Z-EZ)` continua necessária, separadamente para cada
   numerador. Erros de quadratura amostrados continuam operacionais.

## Derivação e condições

CN: escreva C=C*^(1/2)(I+E)C*^(1/2), ||E||2<=eta<1. Os autovalores de
I+E estão em [1-eta,1+eta], logo o módulo da alteração de logdet é no máximo
-P log(1-eta). Para z=C*^(-1/2)q, a alteração da forma quadrática é no
máximo ||z||² eta/(1-eta). A soma dá exatamente a expressão do protocolo.

Normal: z=Sigma*^(-1/2)(y-mu*), h=Sigma*^(-1/2)(mu-mu*). Expandindo
(z-h)^T(I+E)^(-1)(z-h)-z^Tz e usando ||h||<=a, o módulo é no máximo
(eta*r²+2*r*a+a²)/(1-eta). Somar o limite do logdet e multiplicar por 1/2
reproduz a fórmula proposta. Cholesky deve existir no centro; eta>=1,
não finitude ou falha de fatoração implica subdivisão/ambiguidade/falha,
sem reparo de autovalores.

Com C*=LL†, o whitening operacional correto dos controles é
`L^-1 (Ccontrol-C*) L^-†`; a norma Frobenius desses controles limita a
norma espectral de toda a combinação convexa de Bernstein. Analogamente
para Sigma e para o vetor de médias. Não se deve confundir essa congruência
com uma multiplicação unilateral por C*^-1. As afirmações acima são sobre
os polinômios e a likelihood da tabela salva em aritmética exata; arredondamento
e discrepância física mantêm os limites de escopo explícitos do protocolo.

## Medida, endpoints e custos

x=-sqrt((1-u)(1+u)) cresce de -1 a 0; alpha=asin(u) cresce de 0 a pi/2.
Assim x=-cos(alpha), du/dalpha=cos(alpha) e du/dx=-x/u. O último é singular
em u=0, confirmando a escolha de integrar densidade em alpha ou prior-CDF.
No prior-CDF v, p(u)du=dv; não inserir novamente o Jacobiano do prior.
Em alpha, incluir p(sin(alpha))*cos(alpha). Para o log-prior, cortar a
primeira célula no suporte u>=a=.001; o zero matemático não pertence ao
suporte. A rotina congelada log_alpha_density exclui alpha=pi/2: usar nós
interiores/limites analíticos para massa, sem passar os endpoints da grade
de evento diretamente a essa função.

As constantes de logL precisam ser tratadas no nível e na curva da mesma
forma. Um shift comum cancela na classificação e na massa normalizada.
O valor de referência no centro usado pelo envelope é uma likelihood:
usar o cache realmente existente ou reservar/cobrar sua avaliação. Isso
também se aplica aos centros novos de subdivisões; renomear a operação
como construção de envelope não cria crédito gratuito de LL.

A aritmética proposta fecha: 16.671+971+1.536+1.024=20.202 fixos/ID;
20.202*14=282.828, reserva 4.798*14=67.172, máximo 350.000 novos LL;
210.588+350.000=560.588. O maior total por ID é 21.430+25.000=46.430,
abaixo de 60.000. CPU prospectiva 296,087524+270=566,087524 s deixa
33,912476 s até 600, sem converter essa diferença em autorização. A
construção/caches/coeficientes de momentos deve ser orçada por célula/tile;
não há necessidade matemática de materializar grau6 para os 8.335
intervalos e 14 IDs simultaneamente. Nenhum desses valores é benchmark
medido do executor novo.

Recomendação: prosseguir à revisão do candidato de código/TOYs, exigindo
os cinco contratos acima. Não há recomendação para ampliar tetos nem
reabrir dados/ORF históricos nesta etapa.
