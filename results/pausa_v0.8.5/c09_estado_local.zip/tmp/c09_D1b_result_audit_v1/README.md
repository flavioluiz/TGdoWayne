Auditoria compacta D1b concluída, sem nova física.

Os125.000 valores históricos dos cinco caches estão presentes e bitwise idênticos (coordenadas e logL float64 comparadas como uint64). Existem8.099 valores novos armazenados e cobrados: ID0=1.025, ID4=350, ID6=161, ID10=5.311 e ID11=1.252. O arquivo combinado contém133.099 valores; o cumulativo científico é544.316 LL. Preload não reduziu a cobrança histórica e não foi cobrado novamente.

Os eventos da tabela dos IDs0,4,6,11 passaram. ID10 continua UNRESOLVED_TABLE: atingiu2.399 subdivisões, com massa ambígua0,015031591148719428 e erro operacional total0,015034636784667647; intervalo candidato[0,9801985454485089,0,9952362127992842], intervalo retido[0,1]. Não houve falha de persistência ou de callback nesta execução. Assim, `failed_ids=[]` no recibo significa ausência de TARGET_FAILURE, não aprovação de todos os eventos.

Combinando o histórico D1, há13/14 eventos da tabela resolvidos e ID10 pendente; a auditoria nova não reexecutou os outros nove. Todos os intervalos físicos D1b permanecem[0,1], pois backend_probability_margin=None. Os resultados históricos D1 e nominal14 não foram substituídos.

O auditor deriva do review_D1_v1.py ROOT já revisado. Além do delta de preload/contadores, recompôs classificação e uniões a partir das células; N/A e erros a partir dos registros de quadratura salvos; Z a partir do valor histórico e shift; razão, massa ambígua, discrepância de representações e gates da tabela. Conferiu151 bindings, manifesto candidato, autorizações e recibos finais, custos por ID, finitude/formato e invariância dos arquivos. Não carregou tabela ORF, dado físico, banco ou kernel, nem avaliou LL, quadratura ou novos draws. Somente os caches/células compactos arquivados foram decodificados após ROOT confirmar encerramento.

Custo desta auditoria:0,157106 s CPU desde início do processo incluindo imports;44.482.560 B RSS máximo. O custo científico externo herdado é35,399674 s adicionais/484,422282 s cumulativos. Saída D1b3.229.613 B, dentro dos8 MiB novos e20 MiB cumulativos. Auditoria de álgebra salva não é novo certificado físico uniforme nem autorização de continuação.
