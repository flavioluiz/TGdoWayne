"""Independent reconstruction of compact D1 records; no likelihood/ORF/draw."""
from pathlib import Path
import hashlib
import json
import math
import resource
import time
import numpy as np

resource.setrlimit(resource.RLIMIT_CPU,(25,26))

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CAMPAIGN = ROOT / 'tmp/c09_D1b_execution_v1'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def close(a, b):
    np.testing.assert_allclose(a, b, atol=3e-15, rtol=3e-13)


def main():
    start = time.process_time()
    end = read(CAMPAIGN / 'execution_end.json')
    external = read(ROOT / 'tmp/c09_ROOT/D1b_external_end_v1.json')
    assert external['status']=='ROOT_EXTERNAL_PROCESS_FINISHED' and external['returncode']==0
    assert end['status']=='CONTROLLER_COMPLETED' and end['within_resource_limits'] is True
    assert sha(CAMPAIGN / 'execution_end.json') == external['supervisor_end_sha256']
    assert end['worker']['child_reaped']
    plan_path = ROOT / 'tmp/c09_D1b_candidate_v1/preflight.json'
    plan = read(plan_path)
    assert sha(plan_path) == end['plan_sha256'] == external['plan_sha256']
    for path, digest in plan['bindings'].items():
        assert sha(ROOT / path) == digest, path
    runtime=read(ROOT/'tmp/c09_D1b_candidate_v1/runtime_config.json')
    assert runtime['backend_probability_margin_by_target'] is None
    assert plan['active_targets']==[0,4,6,10,11]
    config = read(ROOT / 'tmp/c09_nominal14_v4/config.json')
    assert end['exact_worker_LL_receipt_available']
    observed = end['resources']['observed_worker_LL']
    source_digest = hashlib.sha256(json.dumps(plan['bindings'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    items, total_stored, total_charged = [], 0, 0
    for row in config['rows']:
        target = row['id']
        if target not in plan['active_targets']:continue
        prefix = CAMPAIGN / 'worker' / f'target_{target:02d}'
        report_path = prefix.with_suffix('.json')
        if not report_path.exists():
            items.append(dict(target=target, status='NO_TARGET_REPORT_RETAINED', interval=[0, 1]))
            continue
        report = read(report_path)
        assert report['target'] == target and report['C09_complete'] is False
        identity_path = prefix.with_name(prefix.name + '_cache_identity.json')
        cache_path = prefix.with_name(prefix.name + '_cache.npz')
        cache_record = read(identity_path) if identity_path.exists() else None
        if cache_record:
            identity = cache_record['identity']
            assert identity['target_id'] == target and identity['sources_sha256'] == source_digest
            assert identity['data_sha256'] == plan['bindings']['tmp/c09_nominal14_backend_v4/gates/data.npz']
            assert identity['table_sha256'] == config['table_sha256']
            assert identity['model_sha256'] == hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
            assert cache_record['identity_sha256'] == hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
            with np.load(cache_path, allow_pickle=False) as data:
                assert set(data.files) == {'u', 'log_likelihood'}
                u, ell = data['u'], data['log_likelihood']
            assert u.ndim == 1 and ell.shape == u.shape and np.isfinite(u).all() and np.isfinite(ell).all()
            assert np.all(np.diff(u) > 0) and np.all((u >= 0) & (u <= 1))
            charged = cache_record['canonical_reserved_for_target']
            assert u.dtype==ell.dtype==np.dtype('float64')
            assert len(u)==cache_record['stored_values'] and 0<=charged<=10000
            bridge=cache_record['preload_receipt'];binding=runtime['cache_bindings'][str(target)]
            assert bridge['current_identity']==identity and bridge['current_identity_sha256']==cache_record['identity_sha256']
            assert bridge['legacy_identity']==binding['expected_identity']
            assert bridge['legacy_cache_path']==binding['cache_path'] and bridge['legacy_cache_sha256']==binding['cache_sha256']
            assert bridge['legacy_identity_file_sha256']==binding['identity_sha256']
            old_record=read(ROOT/binding['identity_path'])
            assert old_record['identity']==bridge['legacy_identity'] and old_record['identity_sha256']==bridge['legacy_identity_sha256']
            assert bridge['current_stage_LL_charged_for_import']==0 and bridge['historic_costs_retained'] is True
            with np.load(ROOT/binding['cache_path'],allow_pickle=False) as saved:
                assert set(saved.files)=={'u','log_likelihood'}
                old_u,old_ell=saved['u'],saved['log_likelihood']
            assert old_u.dtype==old_ell.dtype==np.dtype('float64')
            assert old_u.shape==old_ell.shape==(25000,) and np.isfinite(old_u).all() and np.isfinite(old_ell).all()
            indices=np.searchsorted(u,old_u)
            assert np.all(indices<len(u))
            assert np.array_equal(u[indices].view(np.uint64),old_u.view(np.uint64))
            assert np.array_equal(ell[indices].view(np.uint64),old_ell.view(np.uint64))
            assert cache_record['preloaded_values']==bridge['stored_values_imported']==25000
            assert cache_record['stored_values_include_historical'] is True
            assert len(u)-25000==cache_record['new_completed_values']<=charged
            shadow=cache_record['shadow_reserved_values']
            assert charged<=shadow<=10000
            failed=sum(r['reserved_values'] for r in cache_record['shadow_failed_reservations'])
            assert all(r['status']=='FAILED_CHARGED' for r in cache_record['shadow_failed_reservations'])
            assert shadow-cache_record['new_completed_values']==failed
            assert charged == observed['stage_likelihood_by_target'][str(target)]
            total_stored += len(u)
            total_charged += charged
        item = dict(target=target, status=report['status'], report_sha256=sha(report_path),
                    stored_values=cache_record['stored_values'] if cache_record else 0,
                    reserved_values=observed['stage_likelihood_by_target'][str(target)],
                    historical_values_bitwise_verified=25000 if cache_record else 0,
                    new_stored_values=cache_record['new_completed_values'] if cache_record else 0)
        if report['schema'] == 'C09_D1B_TARGET_FAILURE_v1':
            assert report['logL_PIT_interval'] == [0, 1]
            item['reason'] = report['reason']
        else:
            old_path = ROOT / f'tmp/c09_nominal14_pilot_v4/pilot/target_{target:02d}.json'
            old = read(old_path)
            event = report['logL_PIT']
            assert report['historical_report_sha256'] == sha(old_path)
            assert event['historical_status_unchanged'] == old['status']
            assert event['historical_logL_PIT_interval'] == old['logL_PIT_operational_interval']
            assert event['status'] == 'UNRESOLVED' and event['interval'] == [0, 1]
            with np.load(prefix.with_name(prefix.name + '_cells.npz'), allow_pickle=False) as data:
                assert set(data.files) == {'cells'}
                cells = data['cells']
            assert cells.ndim == 2 and cells.shape[1] == 7 and not np.isnan(cells).any()
            lower = .001 if row['prior'] == 'log_uniform_u' else 0.
            assert cells[0, 0] == -math.sqrt((1-lower)*(1+lower)) and cells[-1, 1] == 0
            assert np.array_equal(cells[:-1, 1], cells[1:, 0]) and np.all(cells[:, 1] > cells[:, 0])
            assert np.all(cells[:, 2] <= cells[:, 3]) and np.all(cells[:, 4] >= 0) and np.all(cells[:, 5] >= cells[:, 4])
            assert np.all((cells[:, 6] >= 0) & (cells[:, 6] <= 32) & (cells[:, 6] == np.floor(cells[:, 6])))
            ix = np.flatnonzero(u == row['fixed_truth_u'])
            assert len(ix) == 1
            threshold = ell[ix[0]]
            inside = cells[:, 3] <= threshold - 1e-9
            outside = cells[:, 2] > threshold + 1e-9
            ambiguous = ~(inside | outside)
            masks = {'inside': inside, 'ambiguous': ambiguous, 'outside': outside}
            for kind, mask in masks.items():
                groups = []
                for a, b in cells[mask, :2]:
                    if groups and groups[-1][1] == a:
                        groups[-1][1] = b
                    else:
                        groups.append([a, b])
                transformed = np.sqrt((1-np.asarray(groups))*(1+np.asarray(groups))) if groups else np.empty((0, 2))
                np.testing.assert_allclose(transformed, np.array(event['regions_u'][kind]).reshape(-1, 2), atol=1e-10, rtol=1e-13)
            refs = event['references']
            N, A, Z = [refs[k] for k in ('inside', 'ambiguous', 'denominator')]
            assert N['scale_identity'] == A['scale_identity'] == Z['scale_identity']
            for mass in (N,A,Z):
                assert math.isfinite(mass['lower']) and math.isfinite(mass['upper']) and 0<=mass['lower']<=mass['upper']
            assert Z['lower']>0
            assert Z['scale_identity'].startswith(source_digest+':'+str(target)+':')
            shift=float.fromhex(Z['scale_identity'].split(':')[-1])
            zpoint=math.exp(old['reference_logZ']-shift);ez=zpoint*old['reference_relative_error_estimate']
            close([Z['lower'],Z['upper']],[zpoint-ez,zpoint+ez])
            records=report['mass_references'];position=0
            for kind,mass in (('inside',N),('ambiguous',A)):
                group=records[position:position+len(event['regions_u'][kind])]
                position+=len(group)
                assert len(group)==len(event['regions_u'][kind])
                for part,ends in zip(group,event['regions_u'][kind]):
                    close([part['low_u'],part['high_u']],ends)
                    assert part['quad_success'] is True and part['warnings']==[] and type(part['quad_neval'])is int and part['quad_neval']>=0
                    assert math.isfinite(part['scaled_mass']) and math.isfinite(part['scaled_error_estimate'])
                    assert part['scaled_mass']>=0 and part['scaled_error_estimate']>=0
                value=math.fsum(p['scaled_mass'] for p in group);error=math.fsum(p['scaled_error_estimate'] for p in group)
                close([mass['lower'],mass['upper']],[max(0.,value-error),value+error])
                clo=math.fsum(cells[masks[kind],4]);chi=math.fsum(cells[masks[kind],5])
                assert mass['upper']>=clo and mass['lower']<=chi
            assert position==len(records)
            assert N['lower']+A['lower']+math.fsum(cells[outside,4])<=Z['upper']
            assert N['upper']+A['upper']+math.fsum(cells[outside,5])>=Z['lower']
            core = [N['lower']/Z['upper'], min(1., (N['upper']+A['upper'])/Z['lower'])]
            ambiguity = min(1., A['upper']/Z['lower'])
            quad = sum(x['upper']-x['lower'] for x in (N, A, Z))/Z['lower']
            rep = abs(report['surrogate_probabilities'][0]['probability']-report['surrogate_probabilities'][1]['probability'])
            close(core, event['core_interval'])
            close(ambiguity, event['ambiguous_mass_upper'])
            close(quad, event['quadrature_operational_error'])
            table = event['saved_table_result']
            table_total = ambiguity + quad + rep
            close(table_total, table['total_operational_error'])
            candidate = [max(0., core[0]-rep), min(1., core[1]+rep)]
            close(candidate, table['candidate_interval'])
            flags = {k: v for k, v in report['flags'].items() if k != 'finite_physical_response_evidence'}
            accepted = all(flags.values()) and ambiguity <= .001 and quad <= .00025 and rep <= .0005 and table_total <= .002
            assert (table['status'] == 'RESOLVED_TABLE_OPERATIONAL') == accepted
            close(table['interval'], candidate if accepted else [0, 1])
            assert report['envelope_control_violations'] == [] and not table['physical_probability_approval_inferred']
            item.update(table_status=table['status'], table_interval=table['interval'], table_error=table_total,
                        cells=len(cells), classification_counts={k: int(v.sum()) for k, v in masks.items()},
                        offgrid=report['offgrid_event_max_abs_logL'], same_function_delta=report['same_function_historical_max_abs_delta'])
        items.append(item)
    assert len(items)==5 and all(i['historical_values_bitwise_verified']==25000 for i in items)
    assert total_charged==observed['stage_likelihood_values']<=50000
    assert total_stored-125000==sum(i['new_stored_values'] for i in items)<=total_charged
    for key,n in observed['stage_likelihood_by_target'].items():
        assert 0<=n<=(10000 if int(key) in plan['active_targets'] else 0)
        assert observed['cumulative_likelihood_by_target'][key]==plan['history']['likelihood_by_target'][key]+n<=60000
    assert observed['cumulative_likelihood_values']==536217+total_charged<=1000000
    assert external['additional_CPU_seconds']<=120 and external['cumulative_CPU_seconds']<=600
    close(external['cumulative_CPU_seconds'],449.022608+external['additional_CPU_seconds'])
    assert end['resources']['stage_CPU_seconds']<=external['additional_CPU_seconds']
    assert end['resources']['sum_of_controller_and_child_peak_RSS_bytes']<=1610612736
    assert sha(ROOT/'tmp/c09_ROOT/D1b_authorization_v1.json')==end['authorization_sha256']==external['authorization_sha256']
    assert sha(CAMPAIGN/'worker/worker_end.json')==end['worker_end_sha256']
    manifest=read(ROOT/'tmp/c09_D1b_candidate_v1/manifest.json')
    for entry in manifest['files']:assert sha(ROOT/entry['path'])==entry['sha256']
    for path,digest in plan['bindings'].items():assert sha(ROOT/path)==digest
    files = [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
             for p in sorted(CAMPAIGN.rglob('*')) if p.is_file()]
    receipt = dict(status='D1B_COMPACT_PRODUCTS_INDEPENDENTLY_RECONSTRUCTED',
                   source_sha256=sha(Path(__file__)), physical_LL=0, ORF=0, draws=0,
                   table_resolved_ids=[i['target'] for i in items if i.get('table_status') == 'RESOLVED_TABLE_OPERATIONAL'],
                   failed_ids=[i['target'] for i in items if i['status'] == 'UNRESOLVED_NO_AUTOMATIC_RETRY'],
                   no_report_ids=[i['target'] for i in items if i['status'] == 'NO_TARGET_REPORT_RETAINED'],
                   every_physical_event_approval_pending=True, total_stored_values=total_stored,
                   total_reserved_values=observed['stage_likelihood_values'],total_historical_values_bitwise_verified=125000,
                   total_new_stored_values=total_stored-125000,cumulative_LL=observed['cumulative_likelihood_values'],
                   prototype_auditor_source_sha256=sha(ROOT/'tmp/c09_ROOT/review_D1_v1.py'),
                   plan_sha256=sha(plan_path),external_end_sha256=sha(ROOT/'tmp/c09_ROOT/D1b_external_end_v1.json'),
                   targets=items, files=files,
                   bytes=sum(f['bytes'] for f in files), external_resources=external,
                   CPU_seconds=time.process_time()-start, process_CPU_seconds_including_imports=time.process_time(),
                   RSS_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                   no_new_likelihood_or_covariance_evaluation=True, no_uniform_probability_certificate=True)
    out = HERE / 'result.json'
    assert receipt['bytes']<=8*1024**2 and plan['history']['output_bytes']+receipt['bytes']<=20*1024**2
    with out.open('x') as stream:
        json.dump(receipt, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({k: receipt[k] for k in ('status', 'table_resolved_ids', 'failed_ids', 'no_report_ids',
                     'total_stored_values', 'total_reserved_values', 'bytes', 'CPU_seconds', 'RSS_peak_bytes')}))


if __name__ == '__main__':
    main()
