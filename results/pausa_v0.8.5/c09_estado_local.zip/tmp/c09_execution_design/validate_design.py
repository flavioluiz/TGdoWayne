"""Independent small mathematical checks; no PTA posterior or data campaign."""
from pathlib import Path
import json,math,hashlib
import numpy as np
from scipy.integrate import quad
from scipy.special import exp1
from scipy.optimize import brentq
from scipy.stats import norm
OUT=Path(__file__).resolve().parent
cfg=json.loads((OUT/'config_prospectiva.json').read_text())
lam=2.3;eps=.001
priors=[('uniform_u',0,lambda u:1.,lambda u:u),('uniform_u_squared',0,lambda u:2*u,lambda u:u*u),('log_uniform_u',eps,lambda u:1/(u*math.log(1/eps)),lambda u:math.log(u/eps)/math.log(1/eps))]
expected_Z=[-math.expm1(-lam)/lam,2*(1-(1+lam)*math.exp(-lam))/lam**2,(exp1(lam*eps)-exp1(lam))/math.log(1/eps)]
prior_checks=[];nodes,weights=np.polynomial.legendre.leggauss(64)
for (name,lo,density,cdf),expected in zip(priors,expected_Z):
 direct=quad(lambda u:density(u)*math.exp(-lam*u),lo,1,epsabs=1e-13,epsrel=1e-13)[0]
 # Independent variable alpha and many fixed panels, including log-prior cutoff.
 edges=sorted(set([lo]+[x for x in cfg['quadrature']['u_panel_edges'] if x>lo]))
 transformed=0.
 for ul,uh in zip(edges[:-1],edges[1:]):
  al,ah=math.asin(ul),math.asin(uh);a=(al+ah)/2+(ah-al)/2*nodes;u=np.sin(a)
  values=np.array([density(float(x)) for x in u])*np.exp(-lam*u)*np.cos(a)
  transformed+=(ah-al)/2*np.dot(weights,values)
 normalization=quad(density,lo,1,epsabs=1e-13)[0]
 q90=brentq(lambda u:cdf(u)-.9,max(lo,1e-300) if lo else 0,1)
 prior_checks.append(dict(prior=name,normalization=normalization,analytic_Z=float(expected),direct_Z=direct,alpha_Z=transformed,maximum_error=max(abs(normalization-1),abs(direct-expected),abs(transformed-expected)),prior_q90=q90))
 assert prior_checks[-1]['maximum_error']<1e-12
# Same physical uniform-u prior in coordinates v=u²: singular endpoint is
# handled by independent adaptive integration, not by omitting the Jacobian.
z_v=quad(lambda v:math.exp(-lam*math.sqrt(v))/(2*math.sqrt(v)),0,1,epsabs=1e-12)[0]
assert abs(z_v-expected_Z[0])<1e-11
# Counterexample to inferring zero information from the90% upper quantile.
amplitude=.8
p=lambda u:1+amplitude*math.sin(20*math.pi*u)
f=lambda u:u+amplitude/(20*math.pi)*(1-math.cos(20*math.pi*u))
kl=quad(lambda u:p(u)*math.log(p(u)),0,1,epsabs=1e-12,limit=200)[0]
kl_exact=1-math.sqrt(1-amplitude**2)+math.log((1+math.sqrt(1-amplitude**2))/2)
q90=brentq(lambda u:f(u)-.9,0,1)
assert abs(q90-.9)<1e-12 and abs(kl-kl_exact)<1e-12 and kl>.17
# Full-vs-diagonal Fisher has either ordering depending on mean direction.
cov=np.array([[1,.8],[.8,1.]])
fisher=[]
for v in (np.array([1,1.]),np.array([1,-1.])):
 full=float(v@np.linalg.solve(cov,v));diagonal=float(v@v)
 fisher.append(dict(direction=v.tolist(),full=full,diagonal=diagonal))
assert fisher[0]['diagonal']>fisher[0]['full'] and fisher[1]['diagonal']<fisher[1]['full']
# Mixture is not the normal with the mean covariance, even with equal means.
mixture0=.5*norm.pdf(0,scale=1)+.5*norm.pdf(0,scale=3)
averaged0=norm.pdf(0,scale=math.sqrt(5))
assert abs(mixture0-averaged0)>.08
# Geometric domain uses cycles f L/c, not angular phase alone.
cycles=4*1.1*1000/4.5
assert cycles<1000 and math.isclose(cycles,cfg['distances']['maximum_frequency_distance_cycles'])
h=4.135667696e-15;T=4.5*365.25*86400;scale=h/T
result=dict(scope='MATHEMATICAL_DESIGN_CHECKS_ONLY_NO_PTA_POSTERIOR',status='PASS',prior_checks=prior_checks,uniform_u_in_v_same_measure_Z=z_v,quantile_information_counterexample=dict(q90=q90,KL_nats=kl,analytic_KL_nats=kl_exact),covariance_counterexamples=fisher,mixture_counterexample=dict(density_zero_mixture=mixture0,density_zero_averaged_normal=averaged0),geometry=dict(maximum_fL_cycles=cycles,maximum_phase=2*math.pi*cycles,C05_limit_cycles=1000),benchmark=dict(h_over_T_eV=scale,uniform_mass_prior_q90_eV_over_c2=.9*scale,published_ER_limit_eV_over_c2=2.58e-23,ER_to_uniform_prior_q90_ratio=2.58e-23/(.9*scale),source='arXiv:2607.14790v1 Eq.(13), PDFp5',interpretation='quantile proximity alone is not an information diagnostic'),costs=cfg['costs'],config_sha256=hashlib.sha256((OUT/'config_prospectiva.json').read_bytes()).hexdigest(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'validation.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:result[k] for k in ('scope','status','geometry','benchmark')},indent=2))
