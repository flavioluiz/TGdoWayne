# Parecer sobre a suficiência do desenho C09

O root autorizou explicitamente o recorte condicional e a incerteza global de distância com escalas{.9,1,1.1}. A configuração permanece com execução desabilitada; sua autorização científica depende dos controles e resultados, não deste parecer.

| Requisito do plano original | Produto previsto | Limite que deve aparecer no marco |
|---|---|---|
| Prioris emmassa, massa² e logmassa | Três medidas normalizadas,500 novas realizações por medida; ajuste pareado nos mesmos32 dados separado deSBC | Amplitude, índice e ruídos conhecidos; não robustez das marginais5D |
| Métricas de informação/suporte | KL, W1, distânciaCDF, odds, quantis, corteslog .0001/.001/.01, controle de Jacobiano | Cortes alternativos adicionais não ganham SBC por reponderação; não há modelo u>1 |
| Full/diag e fixa/variável | Fatorial2×2 no mesmoB10, mesma média, logdet, controles normais próprios | Variantes centrais erradas podem falhar calibração; direção do efeito é medida |
| Espectros e monopolo/dipolo | Subconjunto declarado de injeções, modelo correto/omisso, momentos completos | Contaminantes conhecidos no modelo correto; não inferência conjunta de suas amplitudes |
| Variabilidade de realizações | Bancos500 ou células64/128 com denominadores e erros | Células de64/128 têm poder limitado; não misturá-las com famíliasSBC |
| Incerteza de distância | Mistura marginalizada de três escalas globais e contraste nominal | Não representa doze incertezas astrométricas independentes; exige novos nósORF |
| Escala h/T MeerKAT | Priori e quantil analíticos, métrica de informação e contraste com fonteprimária | Não reanálise observacional; proximidade de um quantil não determinaKL |
| Estabilidade de métricas/evidências | Refinamento32/64 por painel, brackets e referência adaptativa independente | Não inferir precisão deZ/KL a partir de precisão de quantis; Bayesfactor tem escopo próprio |

A frase apropriada para o estado final, **depois de executar e verificar**, é: “robustez condicional no experimento tensorial periódico especificado, com nuisances conhecidos e uma hipótese de distância global marginalizada”. O estado “robustez geral das posteriores de cinco parâmetros” não seria sustentado por esse pacote. O plano original admite resultados condicionais quando a massa não é identificável; este recorte deve ser formalmente descrito, sem ocultar o trabalho que permaneceu fora.

A dependência C08 publicado e validado continua obrigatória. Se a nova integração, a mistura de distâncias ou as métricas não convergirem dentro do orçamento, o marco permanece parcial/inconclusivo nesse item; retirar uma célula a posteriori não satisfaz a lista original.

## Produtos preparados agora

- `config_prospectiva.json`: desenho e sementes próprias, prioris, células, famílias, limites computacionais, execuçãofalse.
- `PROTOCOLO.md`: matemática, contrastes, controles, meios de integração/validação, custos e interpretação.
- `build_design.py`: receita aritmética da configuração/contagens, sem dados físicos.
- `validate_design.py` e `validation.json`: pequenos controles independentes de normalização/Jacobiano, informação, fatorial e mistura; não uma campanha PTA.
- `zhao2026_directed.txt`: extração local auxiliar para leitura dirigida das páginas4–5; não copiar para o Git nem tratá-la como leitura integral/publicação do artigo.

## Verificações matemáticas já executadas

Os três Z para a likelihoodtoy exp(−2.3u) concordam com soluções analíticas/função especial e quadratura independente após a mudança α=arcsin(u), erro<10^-12. A mesma priori uniforme emu integrada emv=u² concorda, preservando seu Jacobiano. Um contraexemplo com quantil90=.9 tem KL=.176856nats; dois exemplos de Fisher mostram sentidos opostos após diagonalização. Uma mistura de normais não coincide com a normal de covariância média. O máximo fL/c das escalas propostas é977.7778 ciclos<1000.

Esses testes validam identidades úteis ao desenho. Não validam as ORFs nas distâncias novas, posteriores condicionais, SBC, limites, evidências físicas ou o cenário de MeerKAT.
