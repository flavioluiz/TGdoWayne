# C09 — robustez condicional com integração unidimensional

**Desenho prospectivo; execução desabilitada.** O plano depende de C08 publicado e validado e conserva C07, com cinco parâmetros livres, como referência independente. Não calcula nem aprova uma posterior C09. Este recorte condiciona amplitude, índice espectral e ruídos a valores conhecidos; a única variável contínua inferida é `u=f_g T`. O experimento de distâncias acrescenta uma variável discreta global, marginalizada exatamente. As conclusões não serão anunciadas como robustez das marginais de cinco parâmetros.

A proposta reduz custo pela fatoração em cada nó de massa reutilizada para todos os dados. Ela não substitui integração contínua por sorteio de verdades na grade nem aproveita SBC de uma priori diferente.

## Experimento e prioris

Conservar a geometria real do simulador C07: 12 direções de Fibonacci, T=4,5 anos, quatro canais k/T, distâncias nominais de 300–1.000 anos-luz, pesos1/4 e vetorB de dez componentes, incluindo partes imaginárias e autos. Usar os mesmos H e escalas de normalização fixas de C06/C07; não recalculá-las para cada cenário ou verdade. O ponto central conhecido é `(log10Agw,gammaGW,log10Ar,log10EFAC)=(-15,13/3,-15.5,0)`, com inclinação vermelha4. É uma escolha de projeto, não estimativa dos dados.

As três medidas próprias principais são:

| Priori | Densidade emu | CDF | Sorteio contínuo de U~Unif(0,1) | Quantil90 sem dados |
|---|---|---|---|---|
| uniforme em massa | 1 em[0,1] | u | u=U | .9 |
| uniforme em massa² | 2u em[0,1] | u² | u=√U | √.9 |
| log-uniforme | 1/[u log(1/ε)] em[ε,1], ε=.001 | log(u/ε)/log(1/ε) | u=ε^(1−U) | ε^.1 |

Cada priori terá **500 massas novas e novos dados**, com seeds separados de C07/C08. Os mesmos latentes podem parear famílias e variantes dentro da realização; independência entre as500 realizações permanece obrigatória. As verdades são contínuas e suas ORFs são diretamente calculadas e checadas. A inferência usa a tabela C07 validada, ou nós diretos no experimento de distâncias. Geração e integração não compartilham a mesma aproximação interpolada.

Aplicar as três prioris também aos **mesmos32 dados** selecionados por IDs antes de ler valores: esse é o contraste pareado de sensibilidade. Sua posterior não vira um teste SBC da nova medida quando o dado/verdade foi gerado sob outra priori. A variação adicional ε=.0001/.01 pertence a esse painel de sensibilidade; não anunciar SBC desses dois cortes. Não expandir o suporte acima de u=1 sem um modelo novo para canais não viajantes.

Uma troca de coordenada é um controle diferente: se v=u², a priori uniforme emu tem densidade1/(2√v) emv, e a priori uniforme emv equivale a2u emu. Se w=logu, a densidade da priori uniforme emu vira exp(w). Implementar a mesma medida física nas duas coordenadas deve reproduzir Z, CDFs e quantis; escolher uniformidade na nova coordenada muda a medida. A priori logarítmica não inclui massa zero e nenhuma priori contínua atribui probabilidade positiva ao ponto zero.

## Fatorial de covariância no mesmo espaçoB

Preservar a média física comprimida μ(u) e o mesmo vetor observadoB em todas as quatro variantes. Fixar o ponto-âncora `u*=.5` antes de gerar dados:

| Variante | Covariância da likelihood |
|---|---|
| full_variable | Σ(u) |
| diagonal_variable | diagΣ(u) |
| full_fixed | Σ(u*) |
| diagonal_fixed | diagΣ(u*) |

Todas incluem `−(10/2)log(2π)−(1/2)logdetΣ−(1/2)(B−μ)ᵀΣ⁻¹(B−μ)`, sem absorver o determinante variável numa constante. A covariância fixa usa os nuisances conhecidos do cenário, nunca a massa verdadeira ou uma estimativa obtida na própria realização. Relatar o efeito principal e a interação de diagonalização/congelamento nas **diferenças pareadas de quantis**, sem presumir seu sinal.

O fatorial é ajustado tanto às estatísticas CN físicas quanto ao controleG gerado com a covariância completa variável. Somente full_variable é a família correta nesse controleG; as outras três são misspecificações deliberadas. Três bancos adicionais de500 dadosG, gerados cada um de sua própria família diagonal/fixa, verificam a implementação das outras variantes sob priori uniforme emu. Uma falha no fatorial central não é automaticamente falha do integrador; uma falha nesses controles corretamente especificados exige investigação.

A0_CN e A_G por frequência são referências do núcleo de três prioris. A_G/B_G permite avaliar perda espectral na mesma família correta. A0_CN versus uma normal para estatísticas quadráticas continua misturando redução e aproximação probabilística. Não afirmar que essas diferenças fornecem uma decomposição aditiva única de informação angular, espectral e cinemática.

## Extensões representativas, sem produto cartesiano

Os cenários abaixo são um subconjunto declarado; não cruzar cada ruído, espectro, contaminante, distância e priori com todo o fatorial.

- **Ruído:** dois cenários adicionais com500 massas uniformes e dados novos cada: Ar=10^-14.7 com EFAC1; ou Ar=10^-15.5 com EFAC1.8. Os demais nuisances são centrais. Inferir A0_CN, B_CN/full_variable e B_G/full_variable. São controles representativos de calibração sob a priori uniforme, sem supor que espectros/ruídos sejam desconhecidos.
- **Espectro:** γ=3 e5.5, massas fixas u=.5/.995, 64 realizações por célula, com os três modelos acima. Medir distribuições condicionais de limites e incerteza binomial ponto a ponto; nenhuma exigência de uniformidade SBC ou cobertura Bayes universal em massa fixa.
- **Contaminantes:** monopolo e dipolo, separadamente, com potência relativaρ=.25 ou1 no pivô fixado, u=.5 e64 realizações por célula. Comparar modelo que inclui o componente conhecido com modelo que o omite, nos três modelos anteriores. Não ajustar amplitudes negativas de um processo de potência.
- **Fronteira:** u=0/.5/.995, 128 realizações por célula central. u=0 tem PIT estrutural zero para a priori contínua uniforme; limites superiores positivos incluem o ponto por construção. Intervalos centrais o excluem. Não usar KS de uniformidade nesses dados.
- **Distâncias:** 500 massas uniformes novas, escala global s_L∈{.9,1,1.1} com probabilidades{.25,.5,.25}, desconhecida na inferência e sorteada uma vez por realização para todos os pulsares. Comparar a mistura correta com a hipótese nominal s_L=1, em A0_CN/B_CN/B_G. Esse modelo representa incerteza **correlacionada global**, sem pretensão de substituir doze PDFs astrométricas independentes.

Os processos contaminantes entram na covariância Fourier como `P_M(f) 11ᵀ` e `P_D(f) P Pᵀ`, onde as linhas deP são as direções unitárias dos pulsares. Ambas são PSD e têm diagonal1; `P_M/D=ρ P_GW,piv (f/f_piv)^(-13/3)`, normalizado pela mesma escala fixa. Recalcular todos os momentos sinal–ruído–contaminante pelo traço, incluindo autos. Gerar os componentes por vetores latentes independentes (um complexo para monopolo, três para dipolo) é um controle independente da Cholesky da matriz total. Esses processos não são a mesma operação que adicionar coeficientes de sinal arbitrário somente à média de uma curva angular.

Na distância, a likelihood marginal é `Σ_s p_s L(d|u,s)`, avaliada por logsumexp. ParaG é uma mistura de normais; paraA0 é uma mistura deCN. Substituir por `N(Eμ,EΣ)` ou por uma única covariância média muda o modelo e é proibido no controle correto. Uma variável discreta conhecida apenas na geração não é fornecida ao integrador correto.

O maior valor de fL/c é `4×(1.1×1000)/4.5=977.777...` ciclos; a fase máxima é≈6143,56, inferior ao limiteC05 de1000 ciclos/2π×1000. Estar no domínio não certifica as ordens da quadratura: distâncias alteradas exigem ordens e convergência próprias. Usar a tabela antiga apenas ems=1, sem deslocar seus eixos ou extrapolar fases.

## Integração e controle numérico

Para cada likelihood e dado, calcular `Z=∫L(u)π(u)du`, numeradores deCDF, momentos e informação no contínuo. A coordenada inicial é α=arcsin(u), com `du=cosα dα`; os limites físicos de cada priori entram explicitamente. A paridade tensorial no limiar evita impor um comportamento singular artificial da resposta emβ=cosα. Para log-uniforme, preservar o limite inferior e o fator `cotα/log(1/ε)`.

Usar painéis fixos cujas bordas emu são `[0,.0001,.001,.01,.05,.25,.5,.75,.9,.99,1]`; os painéis fora do suporte de uma priori são omitidos, sem alterar o limite cinemático. Começar com Gauss–Legendre32/64 pontos por painel, sem usar verdades para posicionar nós. Subtrair o máximo da log-densidade para prevenir underflow, conservar normalização e avaliar a likelihood real em cada nó. Ampliar a ordem ou subdividir se os critérios falharem; registrar cada tentativa e orçamento, sem mudar seeds/dados.

As fatorações e momentos em cada nó são comuns aos500 dados de um cenário. Pré-calcular inversas por solves e determinantes apenas para avaliação vetorizada, confrontando com a referência Cholesky. Não montar um banco que replique matrizes por dado. Processar um cenário/variante de cada vez; tabelas de logL podem ser compartilhadas entre prioris, mas as integrais e seus suportes são próprios.

Critérios prospectivos para todos os produtos: ΔlogZ≤.001, ΔCDF≤.002 nos cortes/verdades, quantis com brackets de largura≤.001 emu (ambos os níveis devem confirmar os brackets), momentos de u com diferença≤.001, KL emnats e W1 com diferença≤.001. A informação e evidência têm critérios próprios; não herdar aprovação dos quantis. Registrar flags por quantidade e conservar todos os IDs. Critérios são diferenças entre aproximações, não garantias matemáticas de erro absoluto.

Uma referência independente por quadratura adaptativa (Gauss–Kronrod emu ou emCDF da priori) deve conferir pelo menos16 alvos selecionados antes do piloto, incluindo cada priori, massa de limiar, ruído e mistura de distâncias. Depois, avaliar novos pontos físicos contra ORFs diretas e ampliar apenas onde a precisão numérica falhar. As ORFs novas de distância podem ser calculadas **diretamente nos nós de integração**, sem construir outra tabela de8336 nós; o objeto integrado é a densidade1D e a comparação32→64→referência controla essa aproximação. Não alegar que uma grade esparsa interpolaria a ORF com a precisão da tabelaC07.

O PIT de logL exige cuidado independente: `∫π(u)L(u) 1{logL(u)≤logL(u_true)}du/Z` pode ter vários intervalos. Localizar e refinar todas as travessias detectadas, integrar os subintervalos e confrontar refinamento das subdivisões. Uma única região em torno do modo não é garantida. Indicador constante não ganha errozero automaticamente: se uma região não puder ser resolvida, guardar envelope[0,1]. Não usar uma grade discreta de posteriors para gerar ou ranquear as verdades.

## Calibração, métricas e evidências

Cada banco com massas da própria priori e família correta admite SBC. No desenho há18 grupos corretos com500 dados: nove do núcleo (A0/A_G/B_G para três prioris), três controles próprios do fatorial, quatro de ruído (A0/B_G), dois da mistura de distâncias (A0/B_G). Uma família prospectiva de126 testes reúne, por grupo, doisKS (PITu e PITlogL), quatro coberturas unilaterais (.05/.5/.9/.95) e uma central(.05–.95), com Holmα=.05. Estes testes são específicosC09 e não reabrem as famíliasC07. Grupos aproximados ou contaminados/omitidos permanecem descritivos com tamanho e incerteza; não são obrigados a produzir uniformidade para aprovar o cálculo.

Os envelopes numéricos das CDFs usam .002 após os checks; diferenças não resolvidas usam[0,1]. Não existe MCSE de posterior estimada por ESS nesse integrador determinístico. A variabilidade entre realizações permanece MonteCarlo: reportar erros padrão e intervalos binomiais/bootstraps pareados, com denominadores completos e sem misturar células fixas com SBC. As amostras de64/128 têm poder limitado, declarado em cada figura.

Medir por dado: quantis/limites, média/variância, `KL(posterior||prior)=E_post logL−logZ`, distânciaCDF máxima, Wasserstein1 emu e mudança de odds para uma região predefinida u≤.2 (quando sua probabilidade a priori é positiva). O KL é invariante a mudança bijetiva de coordenada se ambas as medidas forem transformadas corretamente; a entropia diferencial isolada não é. O contraste A_G/B_G pode usar informação média sobre dados da mesma priori, com erro de realização. A forma angular e a cinemática exigem interpretação explícita; sem mudar suporte/canais não se mede sensibilidade a um modo evanescente.

Fatores deBayes massa livre/massa zero, se apresentados, são `Z_cont/L(u=0)` dentro do mesmo espaço de dados e da mesma família, com nuisances conhecidos e prioris normalizadas. Massa zero é hipótese separada; não aplicar Savage–Dickey à priori2u no ponto de densidadezero nem ao corte logarítmico. SBC de posteriores não valida frequência de Bayesfactors. Confrontar a integração deZ independentemente e não anunciar falsos positivos de seleção de modelos sem protocolo próprio.

## Escala h/T e benchmark MeerKAT

Como `m_g c²=h f_g=h u/T`, para T=4,5anos julianos `h/T≈2.91225×10^-23 eV`, e o quantil90 da priori uniforme é≈2.62103×10^-23 eV/c². Isso é uma escala de suporte, não um limite inferido por dados.

Zhao–Wangv1 usam f_ref=1/T, corte cinemático e likelihood angular diagonal na seçãoIII (PDFp4), e relatam no conjuntoER limite90 de2.58×10^-23 eV/c² na Eq.(13), PDFp5. A proximidade desse número ao quantil da priori motiva uma auditoria; isoladamente não demonstra falta de informação. Não reproduzimos a geometria ou os produtos observacionaisMeerKAT. [Fonte primária congelada](https://arxiv.org/pdf/2607.14790v1), SHA e leitura dirigida registrados no catálogo local.

Um controle matemático explicita a limitação: com priori uniforme e posterior `p(u)=1+.8 sin(20πu)`, o quantil90 é exatamente .9, mas KL≈.176856nats>0. Calcular distribuição completa/métricas evita inferir informação apenas de um quantil. Variações deT não são obtidas por mera conversão de unidades: alteram frequências, PSD e fasesfL, além do suporte em massa. O presenteC09 revisita a escala sem alegar uma campanha observacional ou outra duração.

## Recursos e execução em etapas

`config_prospectiva.json` congela as contagens sem lançar produção. São25.956 posteriors1D (28.956 componentes de likelihood equivalentes quando se conta a mistura de distância); não uma nova campanha25.956×5D. O primeiro par32/64 por dez painéis custa até27.797.760 avaliações de likelihood por dado/nó, com fatorações reutilizadas. Essa conta é conservadora para prioris de suporte menor; não inclui refinamentos, logo o teto proposto é120milhões, seguido de recusa antes de excedê-lo.

A geração central precisa1.500 ORFs em massas contínuas. As extensões reutilizam os mesmos u uniformes quando apropriado com novos latentes, preservando independência porID; novas massas de fronteira/espectro são poucas. Distâncias podem exigir até1.000 ORFs na geração e1.920 nós diretos no primeiro par de regras, mais uma reserva de1.152 para a referência independente; o orçamento prospectivo é8.000 novos nós,60trilhões de multiplicações reais,1GiB de arrays e1.5GiB de margemRSS. Um cálculo de fase/ordens específico de cada distância deve refazer o preflight. As contagens são limites, não tempos medidos nem aprovação das ordens.

Primeiro implementar e testar matemática1D/prioris/fatorial, depois um piloto16 sem uso emSBC. Medir tempo completo por cenário, I/O e integração independente; só então autorizar os bancos500. Não concorrer com C07 nem construir tabelas densas extras sem necessidade. Se os primeiros níveis falharem, refinar sob teto; se o teto impedir a precisão, registrar o produto pendente. Não remover células nem afrouxar critérios para fechar o marco.

## Suficiência para o marco

O recorte atende à comparação de medidas, ao fatorial completo, a cenários representativos de ruído/contaminação, à variabilidade entre realizações e a uma hipótese explícita de incerteza global de distância, **se os cálculos/calibrações previstos forem executados e validados**. A restrição condicional deve constar do plano, README, capítulo e notas do release. A autorização do root para esse recorte não é um resultado científico.

Permanecem fora: sensibilidade das posteriores5D às novas prioris, inferência conjunta de amplitudes de contaminantes, doze PDFs de distância independentes, ajustes de temporização/janelas e uma reanálise observacionalMeerKAT. Se forem mantidos como requisitos literais do C09, este desenho não os conclui. A conclusão publicável é sobre mecanismos e limites no experimento condicional especificado, em conjunto com a base5D C07/C08; não um limite universal de massa nem uma extensão já validada para dados reais.
