"""Two focused synthetic guard checks; no physical data or kernel imports."""
from pathlib import Path
import hashlib,json,math,resource,sys,time
from types import SimpleNamespace
from unittest.mock import patch
resource.setrlimit(resource.RLIMIT_CPU,(15,16))
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'tmp/c09_D2_components_v1'))
import numpy as np
from priors import PriorMeasure
from posterior_table import PosteriorTable,wasserstein_to_prior,wasserstein_between
import functional_reference as fr

u=np.linspace(0,1,17);prior=PriorMeasure('uniform_u',0,1)
t=PosteriorTable(u,u,prior);flat=PosteriorTable(u,np.zeros_like(u),prior)
assert wasserstein_to_prior(t)>0.05 and wasserstein_between(t,flat)>0.05
rejects=0
for bad in (-1,0,True,1.5):
    for fn,args in ((wasserstein_to_prior,(t,)),(wasserstein_between,(t,flat))):
        try:fn(*args,tile_cells=bad)
        except ValueError:rejects+=1
        else:raise AssertionError('invalid tile returned W1')
assert rejects==8

def synthetic_quad(*args,**kwargs):
    return np.array([1.,.4,.2,-.5,.3]),.01,SimpleNamespace(success=True,neval=21)
with patch.object(fr,'quad_vec',synthetic_quad):
    r=fr.integrate_reference_bundle(lambda u:np.zeros_like(u),[prior],[[.3]],shift=0)['results'][0]
assert r['denominator']==2 and r['denominator_error_estimate']==.02
expected=(-math.log1p(-.01)) + (.02+abs(-1/2)*.02)/(2-.02)
assert r['kl_error_estimate']==expected
assert r['kl_error_estimate']>r['normalized_moment_errors'][2]
np.testing.assert_allclose(r['cdf_intervals'][0],[(.6-.02)/(2+.02),(.6+.02)/(2-.02)],rtol=0,atol=1e-16)

sources=[]
for name in ('priors.py','batch_likelihood.py','factorial.py','functional_reference.py','posterior_table.py'):
    path=ROOT/'tmp/c09_D2_components_v1'/name
    sources.append({'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
result={'status':'TWO_FOCUSED_SYNTHETIC_GUARD_CHECKS_PASS','checks':2,'invalid_tile_rejections':rejects,
        'KL_ratio_plus_logZ_error_verified':True,'CDF_separate_numerator_denominator_errors_verified':True,
        'sources':sources,'CPU_seconds_including_imports':time.process_time(),
        'RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'physical_LL':0,'ORF':0,'draws':0,'real_array_reads':0,
        'original_thirteen_tests_not_repeated':True}
with (HERE/'checks.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({k:result[k] for k in ('status','checks','CPU_seconds_including_imports','RSS_bytes')}))
