# Revisão independente — densidade PCHIP e contorno C09

Foram lidos os três arquivos e preservados seus bytes em `review_sources/`.
Não houve alteração da implementação. O resultado sustenta a integração dos
**dois interpolantes** nos casos testados, não a topologia ou precisão de uma
likelihood física entre os nós.

A densidade nodal retira corretamente os pesos Gauss–Legendre, mantendo a
medida de priori e o jacobiano cos(α), α=asin(u). Os três tratamentos de priori
e os limites de densidade nas bordas são coerentes para likelihood finita.
A interpolação positiva não deve ser confundida com interpolar massas de
quadratura. A primitiva fornece integrais exatas do polinômio interpolado em
aritmética exata; os diagnósticos de arredondamento não são um certificado
global de erro físico.

O segundo PCHIP interpola logL, separadamente. Em cada peça, os extremos da
derivada quadrática são examinados corretamente. A monotonicidade permite
classificar a peça toda ou encontrar um único cruzamento interior em coordenada
local. A integração da densidade nos intervalos selecionados tem os sinais
corretos; igualdades isoladas têm massa zero, e patamares são átomos explícitos.
Não foi encontrada discrepância nas probabilidades.

Passaram **17 controles adicionais em 0,0699 s CPU**, incluindo duas orientações
lineares com densidade não uniforme, dois patamares, um contato tangente e 30
eventos aleatórios confrontados com as raízes do PPoly completo e suas partições.
O maior desvio dessa comparação foi **5,55×10⁻¹⁶**. A referência por raízes usa
o mesmo interpolante definido, de forma independente da divisão manual das
peças; não constitui uma referência da likelihood física.

## Limitação diagnóstica

O campo `roots_alpha` lista cruzamentos estritos interiores, incluindo os que
caem exatamente em nós com sinais opostos dos dois lados. Ele não lista todas
as raízes isoladas. Para nós `[0,.25,.5,.75,1]`, níveis `[1,1,0,1,1]` e limiar
zero, há uma raiz tangente em .5, mas a lista fica vazia. A probabilidade zero
é correta. Recomenda-se nomear o campo como cruzamentos ou registrar contatos
tangentes separadamente. Extremos do suporte e bordas de patamares também
precisam de semântica explícita se futuramente forem contados como raízes.

A resolução dos dois interpolantes continua exigindo comparação com avaliações
diretas e controles de massa/contorno. A derivada monotônica do PCHIP não prova
a monotonicidade da função física. Nenhum teste PTA ou novo valor de likelihood
física foi calculado nesta revisão.
