from pathlib import Path
from types import SimpleNamespace
import hashlib,json,sys,time
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'review_sources'))
from contour import LogLikelihoodContour


def make(x,levels,density):
    spline=PchipInterpolator(x,density)
    return LogLikelihoodContour(SimpleNamespace(alpha_nodes=np.array(x,float),
        log_likelihood_nodes=np.array(levels,float),spline=spline,
        mass=float(spline.integrate(x[0],x[-1])),roundoff_mass_diagnostic=0.))


def main():
    start=time.process_time();checks=[]
    def check(name,actual,expected,tol=2e-12):
        actual=float(actual);expected=float(expected);error=abs(actual-expected)
        checks.append(dict(name=name,actual=actual,expected=expected,error=error,passed=bool(error<=tol)))
    # Both interpolants are exactly linear here; the reference is elementary.
    x=np.array([0.,.1,.4,.7,1.]);density=1+2*x
    for direction in [1,-1]:
        c=make(x,direction*x,density)
        for t in [0,.1,.2,.4,.61,1]:
            expected=(t+t*t)/2
            if direction<0:expected=1-expected
            check(f'linear alpha direction{direction} t{t}',c.cdf(direction*t)['probability'],expected)
    # Piecewise constant event regions carry atoms of the interpolated event.
    x=np.array([0.,.2,.4,.6,.8,1.]);levels=np.array([0.,0.,1.,1.,0.,0.])
    c=make(x,levels,np.ones(len(x)))
    value=c.cdf(0)
    check('two plateaus total mass',value['probability'],.4)
    check('two plateau atom mass',value['plateau_probability'],.4)
    check('maximum event all support',c.cdf(1)['probability'],1.)
    # Independently find PPoly roots, integrate its sign partition by density primitive.
    rng=np.random.default_rng(910110703);maximum=0.
    for _ in range(30):
        x=np.r_[0,np.sort(rng.uniform(.01,.99,8)),1.]
        levels=rng.normal(size=len(x));density=np.exp(rng.uniform(-2,2,len(x)))
        c=make(x,levels,density);threshold=float(rng.uniform(levels.min(),levels.max()))
        shifted=PchipInterpolator(x,levels);shifted.c[-1]-=threshold
        roots=shifted.roots(extrapolate=False)
        cuts=np.unique(np.r_[x[0],roots[np.isfinite(roots)&(roots>x[0])&(roots<x[-1])],x[-1]])
        selected=[(a,b) for a,b in zip(cuts[:-1],cuts[1:]) if shifted((a+b)/2)<=0]
        expected=sum(c.density.spline.integrate(a,b) for a,b in selected)/c.density.mass
        maximum=max(maximum,abs(expected-c.cdf(threshold)['probability']))
    check('30 independent PPoly root partitions',maximum,0.,2e-11)
    # A nodal tangency has zero probability but is still an algebraic root.
    c=make([0,.25,.5,.75,1],[1,1,0,1,1],[1,1,1,1,1])
    tangency=c.cdf(0)
    check('nodal tangency probability',tangency['probability'],0.)
    finding=dict(kind='diagnostic_scope_only',name='roots_alpha lists strict crossings, not all isolated roots',
        expected_tangent_alpha=.5,returned_roots=tangency['roots_alpha'],
        probability_correct=True,missing_tangent=.5 not in tangency['roots_alpha'])
    report=dict(status='PROBABILITY_CHECKS_PASS_DIAGNOSTIC_NAMING_LIMITATION',cpu_seconds=time.process_time()-start,
        seed=910110703,checks=checks,passed=sum(v['passed'] for v in checks),finding=finding,
        physical_likelihood_values=0,
        source_sha256=hashlib.sha256((HERE/'review_sources/contour.py').read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (HERE/'independent_results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['status','cpu_seconds','passed']}))
    if not all(v['passed'] for v in checks):raise SystemExit(1)


if __name__=='__main__':main()
