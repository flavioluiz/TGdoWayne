"""Independent deterministic guard fixtures only: no PTA imports or real data."""
import time
START=time.perf_counter()
import hashlib
import json
from pathlib import Path
import resource
import sys
import warnings
resource.setrlimit(resource.RLIMIT_CPU,(15,16))
warnings.simplefilter('error')
ROOT=Path(__file__).resolve().parents[2]
CANDIDATE=ROOT/'tmp/c09_event_repair_v1'
sys.path.insert(0,str(CANDIDATE))
import numpy as np
from d1.measure import Prior,u_to_x,x_to_u,quadrature_rule
from d1.cells import SavedPolynomialCells
from d1.partition import MassRange
from d1.cache import Ledger,ChargedCache,BudgetExceeded


def hashes():
    names=['d1/'+n+'.py' for n in ('measure','grid','polynomial','envelope','partition','cache','cells','referenced_event')]
    names += ['d1/__init__.py','run_candidate.py','spec.json','tests/test_d1.py','toy_preflight.json','toy_validation_attempt2.json']
    return {n:hashlib.sha256((CANDIDATE/n).read_bytes()).hexdigest() for n in names}


def cache(callback):
    identity=dict(target_id=0,**{k:'a'*64 for k in ('data_sha256','model_sha256','table_sha256','sources_sha256')})
    return ChargedCache(callback,identity,Ledger(maximum_values=5,maximum_cpu_seconds=10),
                        Ledger(maximum_values=5,maximum_cpu_seconds=10))


before=hashes()
prior=Prior('log_uniform_u',.01)
left=float(u_to_x(prior.lower)); back=float(x_to_u(left))
observed=[]
def mass(a,b):
    observed.append([a,b])
    quadrature_rule(prior,np.array([a,b]),4,coordinate='prior_cdf')
    value=float(prior.cdf(b)-prior.cdf(a))
    return MassRange(value,value,'TOY_PRIOR')
cells=SavedPolynomialCells(np.array([-1.,0.]),lambda i:np.ones((1,1,1,1)),
    model='A0_CN',H=np.ones((1,1,1)),observation=np.zeros((1,1)),weights=np.ones(1),
    center_loglike=lambda u:np.zeros_like(u),mass_interval=mass,roundoff_allowance=0)
error=None
try: cells(left,float(u_to_x(.1)))
except ValueError as e: error=str(e)
assert back<prior.lower and error=='strict panel edges within prior support required'
cutoff=dict(confirmed=True,cutoff=prior.lower,x_boundary=left,inverse_u=back,
            error=error,mass_provider_arguments=observed,
            nominal_cutoff=.001,nominal_inverse_u=float(x_to_u(u_to_x(.001))),
            nominal_scope='Above the nominal cutoff by 8.09e-14 here; not a nominal provider rejection')

calls=[]
c=cache(lambda u:calls.append(len(u)) or np.zeros_like(u))
count=[0]
def target_expiry():
    count[0]+=1
    if count[0]==2: raise BudgetExceeded('TOY target expiry after global reserve')
c.target_ledger.checkpoint=target_expiry
error=None
try: c(np.array([.5]))
except BudgetExceeded as e: error=str(e)
assert not calls and c.global_ledger.charged==1 and c.target_ledger.charged==0
assert c.global_ledger.records==[dict(reserved_values=1,status='RESERVED_BEFORE_CALL')]
reserve=dict(confirmed=True,callback_calls=len(calls),error=error,
             global_charged=c.global_ledger.charged,target_charged=c.target_ledger.charged,
             global_records=c.global_ledger.records,target_records=c.target_ledger.records)

def interrupt(u): raise KeyboardInterrupt('TOY cancellation')
c=cache(interrupt); error=None
try: c(np.array([.5]))
except BaseException as e: error=dict(type=type(e).__name__,message=str(e))
assert error['type']=='UnboundLocalError'
assert c.global_ledger.records[0]['status']=='RESERVED_BEFORE_CALL'
cancellation=dict(confirmed=True,raised=error,global_records=c.global_ledger.records,
                  target_records=c.target_ledger.records,cache_entries=len(c.values))

assert hashes()==before,'Candidate changed during independent fixtures'
usage=resource.getrusage(resource.RUSAGE_SELF)
peak=int(usage.ru_maxrss if sys.platform=='darwin' else usage.ru_maxrss*1024)
cpu=usage.ru_utime+usage.ru_stime
assert cpu<=15 and peak<=128*1024**2
report=dict(schema='C09_D1_ADDITIONAL_GUARD_REVIEW_v1',status='THREE_CANDIDATE_EDGE_CASES_REPRODUCED',
    cutoff_endpoint=cutoff,reservation_atomicity=reserve,cancellation_cleanup=cancellation,
    sources_sha256=before,source_unchanged=True,CPU_seconds=cpu,wall_seconds=time.perf_counter()-START,
    RSS_peak_bytes=peak,CPU_cap_seconds=15,RSS_validation_cap_bytes=128*1024**2,
    physical_ORF=0,physical_logL=0,real_NPZ_arrays_read=0,draws=0,banks=0,
    existing_18_TOYs_repeated=False)
out=Path(__file__).with_name('guard_results.json')
with out.open('x') as f:json.dump(report,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
print(json.dumps(report,sort_keys=True))
