"""Check the new structural mass guard only; no existing TOY suite is rerun."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(15,16))
import hashlib,json,sys,time
from pathlib import Path
START=time.perf_counter()
ROOT=Path(__file__).resolve().parents[2]
CANDIDATE=ROOT/'tmp/c09_event_repair_v1'
def hashes():
    return {str(p.relative_to(CANDIDATE)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((CANDIDATE/'d1').glob('*.py'))}
before=hashes()
sys.path.insert(0,str(CANDIDATE))
from d1.measure import CanonicalCoordinates
from d1.envelope import LogRange
from d1.partition import Cell,MassRange
from d1.referenced_event import referenced_probability_interval,NAMED_CONTROLS
mapping=CanonicalCoordinates([-1.,0.],[0.,1.])
controls=dict.fromkeys(NAMED_CONTROLS,True)
cells=[Cell(-1,0,LogRange(-1,-1),MassRange(1,1,'TOY'))]
def output(reference):
    return referenced_probability_interval(cells,LogRange(0,0),MassRange(1,1,'TOY'),
        support=(-1,0),reference_mass=reference,backend_probability_margin=0,
        representation_probability_margin=0,controls=controls,canonical_coordinates=mapping)
failure=None
try:output(lambda intervals:MassRange(.5,.5,'TOY'))
except ArithmeticError as error:failure=str(error)
assert failure is not None,'Inconsistent full-support numerator must be rejected'
valid=output(lambda intervals:MassRange(1,1,'TOY'))
assert valid['status']=='RESOLVED_OPERATIONAL' and valid['interval']==[1.,1.]
assert hashes()==before,'Candidate changed during final guard check'
usage=resource.getrusage(resource.RUSAGE_SELF)
cpu=usage.ru_utime+usage.ru_stime
peak=int(usage.ru_maxrss if sys.platform=='darwin' else usage.ru_maxrss*1024)
assert cpu<15 and peak<128*1024**2
report=dict(schema='C09_D1_FINAL_REFERENCE_GUARD_REVIEW_v1',status='NEW_GUARD_REJECTS_INCONSISTENCY_RETAINS_VALID_FULL_EVENT',
    sources_sha256=before,inconsistent_reference_error=failure,valid_interval=valid['interval'],
    CPU_seconds=cpu,RSS_peak_bytes=peak,wall_seconds=time.perf_counter()-START,
    existing_suite_repeated=False,physical_LL=0,ORF=0,banks=0,draws=0,NPZ_arrays_read=0)
with Path(__file__).with_name('final_reference_guard.json').open('x') as f:
    json.dump(report,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
print(json.dumps(report,sort_keys=True))
