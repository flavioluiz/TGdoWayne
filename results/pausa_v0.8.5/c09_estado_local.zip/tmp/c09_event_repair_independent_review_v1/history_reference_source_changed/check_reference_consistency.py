"""One inconsistent-provider TOY; no real likelihood, ORF, NPZ or draws."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(15,16))
import hashlib,json,sys,time
from pathlib import Path
START=time.perf_counter()
ROOT=Path(__file__).resolve().parents[2]
candidate=ROOT/'tmp/c09_event_repair_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected='22608f9688b118d26eb8bcda87a812cde8023a59206bb05a1b20b67f11206d20'
assert sha(candidate/'d1/referenced_event.py')==expected,'Candidate already changed; do not repeat old fixture'
sys.path.insert(0,str(candidate))
from d1.envelope import LogRange
from d1.partition import Cell,MassRange
from d1.referenced_event import referenced_probability_interval,NAMED_CONTROLS
calls=[]
def wrong_reference(intervals):
    calls.append(intervals)
    return MassRange(.5,.5,'TOY')
cells=[Cell(-1,0,LogRange(-1,-1),MassRange(1,1,'TOY'))]
result=referenced_probability_interval(cells,LogRange(0,0),MassRange(1,1,'TOY'),
    support=(-1,0),reference_mass=wrong_reference,backend_probability_margin=0,
    representation_probability_margin=0,controls=dict.fromkeys(NAMED_CONTROLS,True))
assert result['status']=='RESOLVED_OPERATIONAL' and result['interval']==[.5,.5]
assert result['regions_u']['inside']==[[0.,1.]]
assert sha(candidate/'d1/referenced_event.py')==expected
usage=resource.getrusage(resource.RUSAGE_SELF)
cpu=usage.ru_utime+usage.ru_stime
peak=int(usage.ru_maxrss if sys.platform=='darwin' else usage.ru_maxrss*1024)
assert cpu<15 and peak<128*1024**2
report=dict(schema='C09_D1_REFERENCE_CONSISTENCY_TOY_v1',status='INCONSISTENT_REFERENCE_ACCEPTED_REPRODUCED',
    tested_source_sha256=expected,mathematically_required_saved_table_event_probability=1.,
    deliberately_inconsistent_reference=True,observed=result,reference_calls=calls,
    CPU_seconds=cpu,RSS_peak_bytes=peak,wall_seconds=time.perf_counter()-START,
    physical_LL=0,ORF=0,banks=0,draws=0,NPZ_arrays_read=0)
with Path(__file__).with_name('reference_consistency.json').open('x') as f:
    json.dump(report,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
print(json.dumps(report,sort_keys=True))
