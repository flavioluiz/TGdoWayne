# Revisão independente do candidato D1, tentativa5

**Conclusão:** os quatro achados materiais identificados nesta revisão foram
corrigidos pelo autor. Não encontrei bloqueador adicional no núcleo puro
revisado. Isso não aprova execução física: o mass provider independente,
evidência operacional de backend, allowance de arredondamento, fechamento
de fontes/inputs e supervisor cumulativo CPU/RSS/saída continuam pendentes,
como declarado no candidato. Não há certificado uniforme implícito.

Li os oito módulos funcionais de `d1`, o runner, spec, README e os três
arquivos de teste. Conferi os 14 vínculos do preflight da tentativa5 e seu
recibo de **26 TOYs PASS**. Não repeti essa suíte. Nenhuma fonte candidata
foi alterada por esta revisão; nenhum array NPZ real, ORF, likelihood PTA,
banco ou draw foi acessado/executado.

## Achados reproduzidos e correções

| Achado nas versões anteriores | Efeito reproduzido | Correção conferida |
| --- | --- | --- |
| Fronteiras reconstruídas por x→u sem preservar u original | O cutoff .01 virava .009999999999998854 e o provider estrito rejeitava a primeira célula. No nominal .001, o valor virava .001000000000080939, perdendo uma faixa de ≈8,09e−14, sem rejeição neste ambiente. | `CanonicalCoordinates` explícito no factory e nas regiões agregadas preserva nós/cutoff originais. |
| Checkpoint entre reserva global e reserva do alvo | Com expiração determinística injetada, global charged=1/RESERVED, alvo charged=0 e callback não chamado. | Precheck de ambos; cobrança conjunta sem checkpoint intermediário; expiração subsequente deixa ambas FAILED_CHARGED. |
| `status` não inicializado antes do callback | KeyboardInterrupt era mascarado por UnboundLocalError; ambas reservas ficavam RESERVED. | Inicialização FAILED_CHARGED e finally preservam a exceção original e fecham ambos registros. |
| Referência final incompatível com a massa conhecida do conjunto | Evento integral, massas celulares e Z=[1,1], provider N=[.5,.5]: consumidor antigo aceitava RESOLVED [.5,.5]. | N/A precisam intersectar as respectivas somas celulares; N+A+outside precisa intersectar Z nos dois sentidos. O provider inconsistente é rejeitado; o evento válido continua [1,1]. |

Os três primeiros contraexemplos constam de `guard_results.json`. O quarto
foi reproduzido em `reference_consistency.json` usando o snapshot preservado
`history/attempt3_sources`, pois a fonte viva já havia recebido a correção
anterior de endpoints. O teste final `final_reference_guard.json` confirmou
na tentativa5 tanto a rejeição quanto a preservação do caso válido.

A primeira fixture independente assumiu o sinal errado da deriva de .001;
ela parou nessa asserção e foi preservada em `history_attempt1`. A descrição
acima distingue explicitamente o caso nominal .001 e o cutoff .01. Uma
tentativa posterior parou no guard SHA antes de importar a fonte que o
autor já modificava; está preservada em `history_reference_source_changed`.
Não são falhas científicas observadas em dados reais.

## Matemática e contratos que conferem

- Somente A0_CN usa a CN de q. B_CN passa pela normal dos momentos de
  x_physical; A_G conserva K blocos, B_* usa um bloco comprimido, com w
  na média e w² na covariância. Fixed e diagonal são aplicados depois da
  compressão, conservando a média variável.
- O polinômio é restrito na fração local, sem respline. Todos os produtos
  ordenados geram a covariância até grau6; a conversão para Bernstein e
  o whitening congruente por Cholesky estão corretos. O centro de referência
  usa o x efetivamente obtido de u e sua fração correspondente, em vez de
  presumir t=.5 depois do roundtrip de ponto flutuante.
- A classificação inclui igualdade no evento ell<=nível, compara dois
  intervalos e exige cobertura integral sem buracos/sobreposição. Eta>=1
  ou fatoração inválida não provoca reparo de matriz. O refinamento preserva
  o pai se um filho falhar e exige escala comum das massas.
- Os quocientes usam N_lo/Z_hi e (N_hi+A_hi)/Z_lo com Z_lo>0. Erros de
  numerador, ambiguidade e denominador permanecem separados. Agregar
  regiões contíguas evita uma referência GK por célula; a massa de seleção
  usa medida da priori vezes envoltória de likelihood na escala declarada.
- Evidência ausente mantém [0,1]. Os tetos de margem não são preenchidos
  automaticamente como erros medidos. PCHIP pontual não se torna bound,
  e a envoltória da tabela não se torna erro uniforme da resposta física.

As contagens prospectivas continuam 20.202 fixos+4.798 adicionais por ID,
350.000 LL novas/560.588 cumulativas e máximo46.430 por ID. O teto de
2.399 splits só seria atingível se toda a reserva adicional estivesse
disponível; limiares e referências compartilham essa mesma reserva.
Os 270 s adicionais e os 64 MiB de trabalho por alvo são propostas, não
medidas do nominal14. O próprio ledger local não substitui a supervisão
externa/herança de CPU, RSS e saída que ainda falta ao executor físico.

Os scripts independentes concluídos consumiram respectivamente 0,131274,
0,137986 e 0,134224 s CPU, com máximo60.112.896 B RSS. Cada script teve
RLIMIT_CPU15 s e verificou RSS<=128 MiB. Essa soma de 0,403484 s refere-se
aos três processos concluídos com recibo; as duas interrupções precoces
descritas acima não produziram amostra RUSAGE final. A revisão não repetiu
os testes de integrais/likelihood sintéticas já existentes.

Fonte final `referenced_event.py`:
`35bed84619a2cc1e66727ca6f0d9661caa825ab04261a8d39a33cb058454beb7`.
`review.json` registra os demais SHA e o alcance desta conclusão. Um futuro
executor físico deve ser revisado separadamente; seus resultados ainda
não existem e os 13 PITs históricos não resolvidos permanecem preservados.
