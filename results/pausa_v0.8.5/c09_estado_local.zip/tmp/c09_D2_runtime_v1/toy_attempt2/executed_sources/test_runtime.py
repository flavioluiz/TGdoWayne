"""Only synthetic matrices/functions; no PTA data/ORF/physical likelihood IO."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'tmp/c09_D2_components_v1'))
import math
import unittest
import numpy as np
from scipy.stats import multivariate_normal
from budget import Budget,LimitReached
from cache import CacheSet
from kernel_group import KernelGroup
from engine import analyze_curve


def row(name,data,analysis,cap=10000):
    return dict(curve_id=name,data_id=data,analysis=analysis,additional_likelihood_cap=cap,
                eta_physical_coordinates=[0.,0.,0.,0.],analysis_contaminant_ratio=0.,
                observation_field='q'if analysis=='A0_CN'else('x_gaussian'if'_G'in analysis else'x_physical'),
                fixed_truth_u=.5)


class RuntimeTests(unittest.TestCase):
    def test_budget_aliases_history_and_failed_reservation(self):
        rows=[row('one',7,'A_G',3),row('two',7,'B_G_full_variable',4)]
        b=Budget(rows,additional_cap=7,historical_values=544316,checkpoint=lambda:None)
        i=b.reserve(['one','two'],2,reason='grid');b.complete(i,success=True)
        i=b.reserve(['one'],1,reason='backend_check');b.complete(i,success=False)
        with self.assertRaises(LimitReached):b.reserve(['one'],1,reason='functional_reference')
        self.assertEqual(b.report()['cumulative_values'],544321)
        self.assertEqual(b.by_data[7],5)
        with self.assertRaises(ValueError):b.reserve(['new_alias'],1,reason='grid')
        with self.assertRaises(ValueError):b.reserve(['two'],1,reason='unrecorded')

    def test_cache_preserves_completed_batches_and_charges_failures(self):
        rows=[row('a',2,'A0_CN',10),row('b',3,'A0_CN',10)]
        b=Budget(rows,additional_cap=20,historical_values=0,checkpoint=lambda:None)
        def provider(u,ids,reason):
            i=b.reserve(ids,len(u),reason=reason)
            if np.any(u>.8):b.complete(i,success=False);raise ArithmeticError('synthetic failure')
            b.complete(i,success=True);return {name:u*u for name in ids}
        c=CacheSet(['a','b'],provider=provider,batch=2,checkpoint=lambda:None)
        with self.assertRaises(ArithmeticError):c.evaluate(np.array([0.,.2,.4,1.]),['a','b'],reason='grid')
        self.assertEqual(b.charged,8);self.assertEqual(len(c.values['a']),2)
        np.testing.assert_array_equal(c.evaluate([.2,-0.],['a'],reason='grid')['a'],np.array([.2,0.])**2)
        self.assertEqual(b.charged,8)

    def test_shared_kernel_full_factorial_against_scipy(self):
        rng=np.random.default_rng(909121201);K=P=D=3;N=4
        h=np.eye(P)[:,None,:]*np.eye(P)[None,:,:]  # H_j=e_j e_j^T
        def covariance(g):return g+np.eye(P)[None,None]
        def moments(c):
            mean=np.einsum('dij,nkji->nkd',h,c).real
            s=np.empty((len(c),K,D,D))
            for n in range(len(c)):
                for k in range(K):
                    for i in range(D):
                        for j in range(D):s[n,k,i,j]=np.trace(h[i]@c[n,k]@h[j]@c[n,k]).real
            return mean,s
        names=['B_CN_full_variable','B_CN_diagonal_variable','B_CN_full_fixed','B_CN_diagonal_fixed','B_G_full_variable']
        rows=[row(str(i),i,name)for i,name in enumerate(names)]
        rows += [row('cn6',6,'A0_CN'),row('cn7',7,'A0_CN')]
        data={key:rng.normal(size=(14,K,D))for key in('x_physical','x_gaussian')}
        data['q']=rng.normal(size=(14,K,P))+1j*rng.normal(size=(14,K,P))
        a=rng.normal(size=(N,K,P,P))+1j*rng.normal(size=(N,K,P,P));g=a@a.swapaxes(-1,-2).conj()
        anchor=g[1];w=np.array([.2,.3,.5]);budget=Budget(rows,additional_cap=70000,historical_values=0,checkpoint=lambda:None)
        group=KernelGroup(rows,data,covariance=covariance,moments=moments,weights=w,anchor_gamma=anchor,budget=budget)
        values=group.evaluate_gamma(g,[r['curve_id']for r in rows],reason='grid')
        self.assertEqual(budget.charged,N*len(rows))
        self.assertLess(group.factorizations,N*(K*2+5))
        m,s=moments(covariance(g));ma,sa=moments(covariance(anchor[None]))
        anchor_b=sum(w[k]**2*sa[0,k]for k in range(K))
        for r in rows[:5]:
            y=sum(w[k]*data[r['observation_field']][r['data_id'],k]for k in range(K))
            for n in range(N):
                mu=sum(w[k]*m[n,k]for k in range(K))
                sigma=anchor_b if r['analysis'].endswith('_fixed')else sum(w[k]**2*s[n,k]for k in range(K))
                if'_diagonal_'in r['analysis']:sigma=np.diag(np.diag(sigma))
                expected=multivariate_normal.logpdf(y,mean=mu,cov=sigma)
                self.assertAlmostEqual(values[r['curve_id']][n],expected,places=11)

    def test_functional_engine_ten_priors_and_no_backend_promotion(self):
        r=row('constant',2,'A0_CN',15000);budget=Budget([r],additional_cap=15000,historical_values=0,checkpoint=lambda:None)
        def provider(u,ids,reason):
            i=budget.reserve(ids,len(u),reason=reason);budget.complete(i,success=True)
            return {name:np.full(len(u),-17.)for name in ids}
        cache=CacheSet(['constant'],provider=provider,batch=32,checkpoint=lambda:None)
        specs=[]
        for b in(1.,.8):
            for name in('uniform_u','uniform_u_squared'):
                specs.append(dict(id=f'{name}_{b}',kind=name,lower=0.,upper=b))
            for a in(1e-4,1e-3,.01):specs.append(dict(id=f'log_{a}_{b}',kind='log_uniform_u',lower=a,upper=b))
        base=np.unique(np.r_[0.,np.geomspace(1e-4,.1,25),np.linspace(.1,1,33),.8])
        fine=np.unique(np.r_[base,(base[:-1]+base[1:])/2]);frozen=[]
        panels=[]
        result=analyze_curve(r,specs,base,fine,cache,freeze_cuts=frozen.append,finite_backend_evidence=None,save_reference_panel=panels.append)
        self.assertEqual(len(frozen),1);self.assertEqual(len(result['results']),10)
        self.assertEqual(len(panels),len(result['reference_panels']))
        self.assertEqual(sum(x['integration_record']['neval']for x in panels),result['reference_queries'])
        for item in result['results']:
            self.assertTrue(item['table_gates']['normalization'])
            self.assertTrue(item['table_gates']['CDF'])
            self.assertTrue(item['table_gates']['quantiles'])
            self.assertFalse(item['mass_PIT_usable_within_finite_scope'])
            self.assertEqual(item['functional_status']['W1_direct_functional'],'UNRESOLVED')
            self.assertAlmostEqual(item['summary']['logZ'],-17.,places=9)
        print('SYNTHETIC_SHARED_REFERENCE_COST',{'queries':result['reference_queries'],
               'panels':len(result['reference_panels']),'charged':budget.charged},flush=True)


if __name__=='__main__':unittest.main()
