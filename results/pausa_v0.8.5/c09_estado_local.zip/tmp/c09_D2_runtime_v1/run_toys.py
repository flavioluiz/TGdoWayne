"""Bounded synthetic tests; no physical runner/imports are reachable here."""
from pathlib import Path
import hashlib,json,os,resource,subprocess,sys,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]

def main():
    if len(sys.argv)!=2:raise SystemExit('usage: run_toys.py NEW_OUTPUT_DIRECTORY')
    out=HERE/sys.argv[1];out.mkdir(exist_ok=False)
    paths=list(HERE.glob('*.py'))+list((ROOT/'tmp/c09_D2_components_v1').glob('*.py'))
    sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
    preflight=dict(schema='C09_D2_RUNTIME_TOYS_v1',CPU_cap=60,RSS_cap=536870912,wall_cap=90,threads=1,
                   synthetic_seed=909121201,source_sha256=sources,PTA_LL=0,ORF=0,PTA_NPZ_decoded=0)
    (out/'preflight.json').write_text(json.dumps(preflight,indent=2)+'\n')
    env=dict(os.environ,VECLIB_MAXIMUM_THREADS='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic()
    def limits():resource.setrlimit(resource.RLIMIT_CPU,(60,62))
    with(out/'test.log').open('x')as log:
        process=subprocess.Popen([sys.executable,str(HERE/'test_runtime.py'),'-v'],cwd=HERE,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
        try:code=process.wait(timeout=90)
        except subprocess.TimeoutExpired:process.kill();process.wait();code=-999
    after=resource.getrusage(resource.RUSAGE_CHILDREN);cpu=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
    unchanged=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in sources.items())
    result=dict(status='PASS'if code==0 and cpu<=60 and after.ru_maxrss<=536870912 and unchanged else'FAILED',
                exit_code=code,CPU_seconds=cpu,RSS_bytes=after.ru_maxrss,wall_seconds=time.monotonic()-start,
                sources_unchanged=unchanged,PTA_LL=0,ORF=0,PTA_NPZ_decoded=0,
                preflight_sha256=hashlib.sha256((out/'preflight.json').read_bytes()).hexdigest(),
                log_sha256=hashlib.sha256((out/'test.log').read_bytes()).hexdigest())
    (out/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
