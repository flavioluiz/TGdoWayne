"""Guarded physical inputs and explicit D1-to-D2 semantic cache bridges."""
import hashlib,json
from pathlib import Path
import numpy as np
from supervisor import sha,require,read


def checked_npz(path,guard,expected_shapes):
    relative=str(Path(path).relative_to(guard.repository));expected=guard.plan['bindings'][relative]
    guard.checkpoint();require(sha(path)==expected,'binary hash differs before decoding')
    with np.load(path,allow_pickle=False)as f:
        require(set(f.files)==set(expected_shapes),'unexpected NPZ members')
        values={k:f[k]for k in expected_shapes}
    for k,shape in expected_shapes.items():
        require(values[k].shape==shape and values[k].dtype.kind in'fcui'and np.isfinite(values[k]).all(),'NPZ shape/dtype/finitude differs '+k)
    require(sha(path)==expected,'binary changed while decoding');guard.checkpoint();return values


def preload_histories(runtime,nominal,cache,provider,guard):
    bridge_records={}
    old_plan=read(guard.repository/runtime['historical_D1_plan'])
    old_sources=hashlib.sha256(json.dumps(old_plan['bindings'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    for entry in runtime['historical_cache_inputs']:
        guard.checkpoint();name=entry['curve_id'];target=entry['data_id']
        identity_path=guard.repository/entry['identity_path']
        require(sha(identity_path)==guard.plan['bindings'][entry['identity_path']],'historical identity bytes differ')
        record=read(identity_path);old=record['identity'];old_row=nominal['rows'][target]
        modelsha=hashlib.sha256(json.dumps(old_row,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        expected=dict(target_id=target,data_sha256=guard.plan['bindings'][runtime['data_file']],
                      model_sha256=modelsha,table_sha256=nominal['table_sha256'],sources_sha256=old_sources)
        require(old==expected,'historical cache has different data/model/table/source identity')
        require(record['identity_sha256']==hashlib.sha256(json.dumps(old,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'historical identity hash malformed')
        n=record['stored_values'];require(type(n)is int and 0<n<=25000,'reviewed D1 cache shape differs')
        arrays=checked_npz(guard.repository/entry['cache_path'],guard,{'u':(n,),'log_likelihood':(n,)})
        u,ell=arrays['u'],arrays['log_likelihood']
        require(u.dtype==np.float64 and ell.dtype==np.float64 and np.all(np.diff(u)>0)and u[0]>=0 and u[-1]<=1,'canonical historical float64 grid required')
        index=np.unique(np.rint(np.linspace(0,n-1,32)).astype(int))
        # Charged fresh checks are kept separately. Do not insert them into the
        # legacy cache and demand bit equality across different summation orders.
        new=provider(u[index],[name],reason='cache_bridge_check')[name]
        delta=float(np.max(abs(new-ell[index])))
        bridge=dict(canonical_curve_id=name,source_cache_sha256=guard.plan['bindings'][entry['cache_path']],
                    source_identity_sha256=guard.plan['bindings'][entry['identity_path']],
                    original_function_identity=old,same_data_model_table_units=True,
                    same_function_code_review_binding=read(guard.request['authorization_path'])['ROOT_code_review_sha256'],
                    direct_check_completed=True,direct_check_max_abs_delta=delta,
                    comparison_u=u[index].tolist(),old_logL=ell[index].tolist(),new_logL=new.tolist(),
                    charged_new_checks=len(index),new_checks_not_inserted_as_historical_values=True)
        guard.write_json('cache_bridges/'+name+'.json',bridge)
        cache.import_records(name,u,ell,bridge=bridge);bridge_records[name]=bridge
    return bridge_records
