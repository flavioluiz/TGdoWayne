"""Small completed batches survive failures; only real verified values are hits."""
import numpy as np


def key(u):
    u=np.float64(u)
    if not np.isfinite(u)or not 0<=u<=1:raise ValueError('finite u in[0,1] required')
    if u==0:u=np.float64(0)
    return u.tobytes().hex()


class CacheSet:
    def __init__(self,curve_ids,*,provider,batch=32,checkpoint):
        if type(batch)is not int or batch<1 or len(set(curve_ids))!=len(curve_ids):raise ValueError('positive batch and unique registered IDs required')
        self.values={k:{}for k in curve_ids};self.provider=provider;self.batch=batch;self.checkpoint=checkpoint
        self.hits={k:0 for k in curve_ids};self.imported={k:0 for k in curve_ids};self.bridges={}

    def import_records(self,curve_id,u,ell,*,bridge):
        # IO/hash/model checks and direct equivalent-kernel checks occur in the
        # guarded loader. This pure method accepts only its explicit receipt.
        required=('canonical_curve_id','source_cache_sha256','source_identity_sha256','same_data_model_table_units',
                  'same_function_code_review_binding','direct_check_completed','direct_check_max_abs_delta')
        if (curve_id not in self.values or not isinstance(bridge,dict)or any(k not in bridge for k in required)
            or bridge['canonical_curve_id']!=curve_id or bridge['same_data_model_table_units']is not True
            or bridge['direct_check_completed']is not True or not bridge['same_function_code_review_binding']):
            raise ValueError('complete approved semantic bridge required before importing hits')
        for field in ('source_cache_sha256','source_identity_sha256'):
            v=bridge[field]
            if not isinstance(v,str)or len(v)!=64 or any(x not in'0123456789abcdef'for x in v):raise ValueError('exact input SHA required')
        delta=bridge['direct_check_max_abs_delta']
        if not np.isfinite(delta)or not 0<=delta<=1e-10:raise ValueError('same-function direct checks failed')
        u=np.asarray(u,float);ell=np.asarray(ell,float)
        if u.ndim!=1 or ell.shape!=u.shape or not np.isfinite(ell).all()or np.any(np.diff(u)<=0):
            raise ValueError('strict decoded u and finite same-shape actual values required')
        imported={key(x):float(y)for x,y in zip(u,ell)}
        existing=self.values[curve_id]
        for k,v in imported.items():
            if k in existing and np.float64(existing[k]).tobytes()!=np.float64(v).tobytes():
                raise ValueError('cache collision: do not overwrite values from another arithmetic recipe')
        existing.update(imported);self.imported[curve_id]+=len(imported);self.bridges[curve_id]=dict(bridge)

    def evaluate(self,u,curve_ids,*,reason):
        u=np.asarray(u,float)
        if u.ndim!=1 or not curve_ids or len(set(curve_ids))!=len(curve_ids)or any(c not in self.values for c in curve_ids):
            raise ValueError('mass vector and registered distinct curves required')
        keys=[key(x)for x in u];result={c:np.empty(len(u))for c in curve_ids}
        for start in range(0,len(u),self.batch):
            self.checkpoint();part=u[start:start+self.batch];partkeys=keys[start:start+self.batch]
            groups={}
            for c in curve_ids:
                missing=tuple(dict.fromkeys(k for k in partkeys if k not in self.values[c]))
                self.hits[c]+=sum(k in self.values[c]for k in partkeys)
                if missing:groups.setdefault(missing,[]).append(c)
            for missing,curves in groups.items():
                points=np.array([np.frombuffer(bytes.fromhex(k),dtype=np.float64)[0]for k in missing])
                values=self.provider(points,curves,reason=reason)
                if set(values)!=set(curves):raise ValueError('provider returned wrong curve identities')
                for c in curves:
                    y=np.asarray(values[c],float)
                    if y.shape!=(len(points),)or not np.isfinite(y).all():raise ValueError('invalid normalized likelihood values')
                for c in curves:self.values[c].update(zip(missing,np.asarray(values[c],float).tolist()))
            for c in curve_ids:result[c][start:start+len(part)]=[self.values[c][k]for k in partkeys]
        return result

    def single(self,curve_id,*,reason):return lambda u:self.evaluate(u,[curve_id],reason=reason)[curve_id]
