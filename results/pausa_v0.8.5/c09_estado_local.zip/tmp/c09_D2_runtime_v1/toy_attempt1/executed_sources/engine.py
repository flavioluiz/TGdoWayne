"""D2 function-specific analysis, independent of event-root reconstruction.

Caller supplies already charged/scoped cache and response-domain evidence.
This module never opens data, builds a response bank or authorizes work.
"""
import math
import numpy as np
from priors import PriorMeasure
from posterior_table import PosteriorTable,wasserstein_to_prior
from functional_reference import integrate_reference_bundle,conservative_quantile_gate


def analyze_curve(curve,prior_specs,coarse_u,fine_u,cache,*,freeze_cuts,finite_backend_evidence,compute_table_W1=False):
    if type(compute_table_W1)is not bool:raise ValueError('explicit W1 table phase Boolean required')
    name=curve['curve_id'];direct=cache.single(name,reason='functional_reference')
    coarse_ell=cache.evaluate(coarse_u,[name],reason='grid')[name]
    fine_ell=cache.evaluate(fine_u,[name],reason='grid')[name]
    priors=[PriorMeasure(p['kind'],p['lower'],p['upper'])for p in prior_specs]
    tables=[];cuts=[];brackets=[];cut_plan=[]
    probabilities=(.05,.5,.9,.95)
    for spec,p in zip(prior_specs,priors):
        low=PosteriorTable(coarse_u,coarse_ell,p,order=16)
        high=PosteriorTable(fine_u,fine_ell,p,order=16)
        fine=PosteriorTable(fine_u,fine_ell,p,order=32)
        tables.append((low,high,fine))
        cand=[fine.candidate_quantile_bracket(q)for q in probabilities]
        fixed=np.r_[p.lower,p.upper,p.ppf(probabilities)]
        extras=[.2]if p.lower<=.2<=p.upper else[]
        truth=curve['fixed_truth_u'];inside=p.contains_truth(truth)
        if inside:extras.append(truth)
        c=np.unique(np.r_[fixed,extras,np.array(cand).ravel()]);cuts.append(c);brackets.append(cand)
        cut_plan.append(dict(prior_id=spec['id'],support=[p.lower,p.upper],cuts=c.tolist(),
                             quantile_probabilities=list(probabilities),brackets=cand,
                             truth_in_support=inside,threshold_source='fine_table_before_reference'))
    # Required callback persists immutable endpoints BEFORE any direct reference
    # evaluation, even though the table construction may already use this cache.
    freeze_cuts(dict(schema='C09_D2_FIXED_FUNCTIONAL_CUTS_v1',curve_id=name,priors=cut_plan))
    reference=integrate_reference_bundle(direct,priors,cuts,shift=float(np.max(fine_ell)))
    evidence_ok=(isinstance(finite_backend_evidence,dict) and
                 finite_backend_evidence.get('accepted_finite_domain')is True and
                 finite_backend_evidence.get('new_curve_checks_passed')is True and
                 finite_backend_evidence.get('curve_id')==name and
                 bool(finite_backend_evidence.get('source_and_input_binding')))
    results=[]
    for spec,p,table_tuple,cut,cand,ref in zip(prior_specs,priors,tables,cuts,brackets,reference['results']):
        low,high,fine=table_tuple
        c0,c1,c2=low.cdf(cut),high.cdf(cut),fine.cdf(cut)
        cref=np.asarray(ref['cdf']);intervals=np.asarray(ref['cdf_intervals'])
        repr_error=np.maximum(abs(c0-c2),abs(c1-c2))
        ref_error=np.maximum(abs(cref-intervals[:,0]),abs(intervals[:,1]-cref))
        cdf_delta=np.maximum(repr_error,abs(c2-cref)+ref_error)
        logz_delta=max(abs(low.logZ-fine.logZ),abs(high.logZ-fine.logZ),
                       abs(fine.logZ-ref['logZ'])+ref['logZ_error_estimate'])
        moment_deltas=[]
        for j,key in enumerate(('mean','second')):
            value=getattr(fine,key)
            moment_deltas.append(max(abs(getattr(low,key)-value),abs(getattr(high,key)-value),
                                     abs(value-ref[key])+ref['normalized_moment_errors'][j]))
        kl_delta=max(abs(low.kl_to_prior-fine.kl_to_prior),abs(high.kl_to_prior-fine.kl_to_prior),
                     abs(fine.kl_to_prior-ref['kl_to_prior'])+ref['kl_error_estimate'])
        qrecords=[]
        for q,(lo,hi)in zip(probabilities,cand):
            il,ih=np.searchsorted(cut,[lo,hi])
            if cut[il]!=lo or cut[ih]!=hi:raise ArithmeticError('frozen endpoints lost')
            # Representation uncertainty is operational and separately visible;
            # it is not obtained from finite max-delta-logL backend tests.
            low_interval=(max(0.,intervals[il,0]-repr_error[il]),min(1.,intervals[il,1]+repr_error[il]))
            high_interval=(max(0.,intervals[ih,0]-repr_error[ih]),min(1.,intervals[ih,1]+repr_error[ih]))
            crossing=all(float(t.cdf(lo))<=q<=float(t.cdf(hi))for t in table_tuple)
            passed=crossing and conservative_quantile_gate(q,lo,hi,low_interval,high_interval)
            qrecords.append(dict(probability=q,lower=lo,upper=hi,width=hi-lo,
                                 reference_low_interval=intervals[il].tolist(),reference_high_interval=intervals[ih].tolist(),
                                 operational_low_interval=low_interval,operational_high_interval=high_interval,
                                 table_gate=bool(passed)))
        w24=wdelta=None
        if compute_table_W1:
            # The physical driver defers this optional work until all primary
            # functionals are saved. Failure here cannot erase their receipts.
            wlow=wasserstein_to_prior(low,order=12);w12=wasserstein_to_prior(fine,order=12)
            w24=wasserstein_to_prior(fine,order=24);wdelta=max(abs(wlow-w24),abs(w12-w24))
        flags=dict(normalization=logz_delta<=.001,CDF=bool(np.max(cdf_delta)<=.002),
                   quantiles=all(x['table_gate']for x in qrecords),moments=max(moment_deltas)<=.001,
                   KL=bool(kl_delta<=.001 and fine.kl_to_prior>=-1e-8),
                   W1_table_integral=bool(wdelta is not None and wdelta<=.001),
                   W1_direct_functional=False)
        status={k:('PASS_FINITE_DOMAIN_OPERATIONAL'if val and flags['normalization']and evidence_ok else
                   ('PASS_TABLE_ONLY'if val and flags['normalization']else'UNRESOLVED'))for k,val in flags.items()}
        truth=curve['fixed_truth_u'];in_support=p.contains_truth(truth)
        pit=None
        if in_support:
            j=int(np.searchsorted(cut,truth))
            if cut[j]!=truth:raise ArithmeticError('truth cut lost from frozen reference plan')
            pit=[max(0.,float(intervals[j,0]-repr_error[j])),min(1.,float(intervals[j,1]+repr_error[j]))]
            if not flags['normalization']or not flags['CDF']:pit=[0.,1.]
        results.append(dict(prior_id=spec['id'],prior=dict(kind=p.kind,lower=p.lower,upper=p.upper),
                            summary=fine.summary(),prior_moments=p.moments(),quantiles=qrecords,
                            delta_logZ=logz_delta,delta_CDF=cdf_delta.tolist(),delta_moments=moment_deltas,
                            delta_KL=kl_delta,W1_to_prior=w24,W1_table_delta=wdelta,
                            W1_direct_reference_status='UNRESOLVED_NOT_IMPLEMENTED_WITHIN_THIS_DRIVER',
                            table_gates=flags,functional_status=status,reference=ref,
                            mass_PIT_operational_interval=pit,truth_outside_support=not in_support,
                            mass_PIT_scope='saved-response functional errors with finite backend evidence explicitly separate; not a uniform physical bound',
                            mass_PIT_usable_within_finite_scope=bool(in_support and evidence_ok and flags['normalization']and flags['CDF']),
                            engineering_not_SBC=True))
    return dict(schema='C09_D2_FUNCTIONAL_RESULT_v1',curve_id=name,data_id=curve['data_id'],
                analysis=curve['analysis'],results=results,reference_queries=reference['callback_queries'],
                reference_panels=reference['panels'],finite_backend_evidence=finite_backend_evidence,
                physical_uniform_probability_bound=None,logL_event_status='NOT_EVALUATED_HISTORICAL_STATES_PRESERVED',
                C09_complete=False)
