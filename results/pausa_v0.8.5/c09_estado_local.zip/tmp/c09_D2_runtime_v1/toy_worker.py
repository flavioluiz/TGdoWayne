"""Supervisor lifecycle control with stdlib arithmetic only, no numerical imports."""
import argparse,os
from supervisor import WorkerGuard,read

def main():
    p=argparse.ArgumentParser();p.add_argument('--request',required=True);p.add_argument('--request-sha256',required=True);a=p.parse_args()
    guard=WorkerGuard.from_request(a.request,a.request_sha256)
    config=read(guard.repository/guard.parameters['runtime_config']);mode=config['toy_mode']
    index=guard.budget.reserve(['one','two'],3,reason='functional_reference')
    guard.write_json('partial/reference_panel_0000.json',dict(status='COMPLETED_PANEL',mass=.25))
    if mode=='crash':os._exit(9)
    guard.budget.complete(index,success=True)
    caught=None
    try:guard.budget.reserve(['one'],3,reason='functional_reference')
    except RuntimeError as exc:caught=str(exc)
    guard.write_json('cached_values.json',dict(stored=6,charged=guard.budget.charged,quota_failure=caught))
    guard.finish('COMPLETED',dict(mode=mode,quota_was_preserved=caught is not None,C09_complete=False))

if __name__=='__main__':main()
