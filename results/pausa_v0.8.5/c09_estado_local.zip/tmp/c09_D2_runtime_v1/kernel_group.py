"""Same-covariance groups, reused factorizations and explicit B_CN variants.

Scientific covariance/moment functions are injected. This module imports no
data and generates no random values. The physical worker will bind the frozen
FixedNuisanceCovariance and quadratic_moments implementations.
"""
import numpy as np
from batch_likelihood import cn_logpdf,normal_logpdf
from factorial import compressed_moments,factorial_moments,compress_observations


class KernelGroup:
    def __init__(self,rows,data,*,covariance,moments,weights,anchor_gamma,budget):
        if not rows:raise ValueError('nonempty registered group required')
        self.rows={r['curve_id']:dict(r)for r in rows};self.budget=budget
        if len(self.rows)!=len(rows):raise ValueError('distinct canonical curves required')
        same={(tuple(r['eta_physical_coordinates']),r['analysis_contaminant_ratio'])for r in rows}
        if len(same)!=1:raise ValueError('a group must share nuisances and contaminant covariance')
        self.covariance,self.moments=covariance,moments;self.weights=np.asarray(weights,float).copy()
        self.data={k:np.asarray(v).copy()for k,v in data.items()}
        allowed={'A0_CN','A_G'}|{f'B_{source}_{shape}_{kind}'for source in('CN','G')for shape in('full','diagonal')for kind in('fixed','variable')}
        if any(r['analysis']not in allowed for r in rows):raise ValueError('unsupported conditional analysis')
        for values in self.data.values():
            if not np.isfinite(values).all():raise ValueError('finite observations required')
            values.flags.writeable=False
        # Computing an anchor covariance is matrix work, not a likelihood value.
        # Any likelihood evaluated at the anchor is charged by evaluate().
        _,s=self.moments(self.covariance(np.asarray(anchor_gamma)[None]))
        _,compressed=compressed_moments(np.zeros(s.shape[:-1]),s,self.weights)
        self.anchor=compressed[0];self.factorizations=0

    @staticmethod
    def _operation(name):
        if name in('A0_CN','A_G'):return name
        return 'B_'+name.split('_')[-2]+'_'+name.split('_')[-1]

    def evaluate_gamma(self,gamma,curve_ids,*,reason):
        gamma=np.asarray(gamma)
        if gamma.ndim!=4 or len(gamma)<1 or any(k not in self.rows for k in curve_ids):
            raise ValueError('batch of Gamma and curves from this group required')
        reservation=self.budget.reserve(curve_ids,len(gamma),reason=reason);success=False
        try:
            c=self.covariance(gamma)
            operations={}
            for name in curve_ids:operations.setdefault(self._operation(self.rows[name]['analysis']),[]).append(name)
            m=s=None
            if any(name!='A0_CN'for name in operations):m,s=self.moments(c)
            out={}
            for operation,names in operations.items():
                rows=[self.rows[k]for k in names]
                if operation=='A0_CN':
                    y=np.stack([self.data['q'][r['data_id']]for r in rows])
                    values,work=cn_logpdf(c,y,reserve=lambda work:None)
                else:
                    y=np.stack([self.data[r['observation_field']][r['data_id']]for r in rows])
                    if operation=='A_G':mu,cov=m,s
                    else:
                        mu,cov=factorial_moments(m,s,self.weights,diagonal='diagonal'in operation,
                                                fixed=operation.endswith('_fixed'),anchor_covariance=self.anchor)
                        y=compress_observations(y,self.weights)
                    values,work=normal_logpdf(mu,cov,y,reserve=lambda work:None)
                if work.normalized_log_likelihood_values!=len(gamma)*len(names):raise ArithmeticError('kernel value count mismatch')
                self.factorizations+=work.covariance_factorizations
                for j,name in enumerate(names):out[name]=values[:,j]
            self.budget.checkpoint();success=True
            return out
        finally:self.budget.complete(reservation,success=success)
