"""New-curve gates against saved harmonic responses and independent SciPy LL."""
import math
import numpy as np
from scipy.stats import multivariate_normal


def _direct_moments(c,h):
    k,p,_=c.shape;d=len(h);m=np.empty((k,d));s=np.empty((k,d,d))
    for f in range(k):
        for i in range(d):
            m[f,i]=np.trace(h[i]@c[f]).real
            for j in range(d):s[f,i,j]=np.trace(h[i]@c[f]@h[j]@c[f]).real
    return m,s


def scipy_loglike(group,row,gamma,h,anchor_gamma):
    c=group.covariance(gamma[None])[0];name=row['analysis'];index=row['data_id'];w=group.weights
    if name=='A0_CN':
        total=0.
        for f,C in enumerate(c):
            y=group.data['q'][index,f];real=.5*np.block([[C.real,-C.imag],[C.imag,C.real]])
            total+=multivariate_normal.logpdf(np.r_[y.real,y.imag],mean=np.zeros(2*len(y)),cov=real)
        return float(total)
    m,s=_direct_moments(c,h);y=group.data[row['observation_field']][index]
    if name=='A_G':return float(sum(multivariate_normal.logpdf(y[f],mean=m[f],cov=s[f])for f in range(len(c))))
    mu=sum(w[f]*m[f]for f in range(len(c)));sigma=sum(w[f]**2*s[f]for f in range(len(c)))
    if name.endswith('_fixed'):
        _,anchor=_direct_moments(group.covariance(anchor_gamma[None])[0],h)
        sigma=sum(w[f]**2*anchor[f]for f in range(len(c)))
    if'_diagonal_'in name:sigma=np.diag(np.diag(sigma))
    observed=sum(w[f]*y[f]for f in range(len(c)))
    return float(multivariate_normal.logpdf(observed,mean=mu,cov=sigma))


def check_new_functions(groups,curve_to_group,table,oracle,rows,h,anchor_gamma,guard,*,source_binding):
    u=oracle['u'];gamma=oracle['Gamma'];table_gamma=table(u)
    table_values={};oracle_values={};reports={}
    for group in groups:
        ids=list(group.rows)
        table_values.update(group.evaluate_gamma(table_gamma,ids,reason='backend_check'))
        oracle_values.update(group.evaluate_gamma(gamma,ids,reason='backend_check'))
    selected=(0,len(u)//2,len(u)-1)
    for row in rows:
        name=row['curve_id'];group=groups[curve_to_group[name]];references=[]
        for index in selected:
            reservation=guard.budget.reserve([name],1,reason='scipy_reference');success=False
            try:
                value=scipy_loglike(group,row,table_gamma[index],h,anchor_gamma)
                if not math.isfinite(value):raise ArithmeticError('nonfinite independent SciPy logL')
                success=True
            finally:guard.budget.complete(reservation,success=success)
            references.append(dict(u=float(u[index]),kernel_logL=float(table_values[name][index]),
                                   scipy_logL=value,absolute_difference=abs(value-table_values[name][index])))
        delta=float(np.max(abs(table_values[name]-oracle_values[name])))
        scipy_error=float(max(r['absolute_difference']for r in references))
        passed=delta<=.001 and scipy_error<=1e-8
        report=dict(schema='C09_D2_NEW_FUNCTION_BACKEND_GATE_v1',curve_id=name,
                    accepted_finite_domain=passed,new_curve_checks_passed=passed,
                    source_and_input_binding=source_binding,saved_harmonic_control_count=len(u),
                    masses=u.tolist(),table_logL=table_values[name].tolist(),harmonic_logL=oracle_values[name].tolist(),
                    maximum_absolute_logL_difference=delta,criterion=.001,scipy_references=references,
                    scipy_criterion=1e-8,scipy_maximum_absolute_difference=scipy_error,
                    prior_density_not_part_of_likelihood=True,uniform_probability_bound=None,
                    interpretation='finite saved-response checks of this new normalized curve; not a uniform physical certificate')
        guard.write_json('backend_checks/'+name+'.json',report);reports[name]=report
    return reports
