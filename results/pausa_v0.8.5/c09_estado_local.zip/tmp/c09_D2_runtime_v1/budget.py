"""Canonical D2 value accounting; additional caps and historical costs coexist."""
import math


class LimitReached(RuntimeError):pass


class Budget:
    def __init__(self,curves,*,additional_cap,historical_values,checkpoint):
        if type(additional_cap)is not int or additional_cap<1 or type(historical_values)is not int or historical_values<0:
            raise ValueError('exact positive additional cap and nonnegative history required')
        self.rows={r['curve_id']:dict(r)for r in curves}
        if len(self.rows)!=len(curves):raise ValueError('duplicate canonical curve identity')
        for r in curves:
            if type(r['additional_likelihood_cap'])is not int or r['additional_likelihood_cap']<1 or type(r['data_id'])is not int:
                raise ValueError('exact per-curve cap and data ID required')
        self.cap=additional_cap;self.history=historical_values;self.checkpoint=checkpoint
        self.by_curve={k:0 for k in self.rows};self.by_data={r['data_id']:0 for r in curves}
        self.by_reason={};self.records=[];self.charged=0
        self.data_caps={d:sum(r['additional_likelihood_cap']for r in curves if r['data_id']==d)for d in self.by_data}
        if sum(r['additional_likelihood_cap']for r in curves)>self.cap:
            raise ValueError('planned per-curve reserves exceed shared cap')

    def reserve(self,curve_ids,n,*,reason):
        if (type(n)is not int or n<1 or not curve_ids or len(set(curve_ids))!=len(curve_ids)
            or any(k not in self.rows for k in curve_ids) or reason not in
            {'grid','functional_reference','anchor_check','backend_check','scipy_reference','cache_bridge_check'}):
            raise ValueError('registered distinct curves and explicit reason required')
        self.checkpoint();new=self.charged+n*len(curve_ids)
        per_curve=dict(self.by_curve);per_data=dict(self.by_data)
        for k in curve_ids:per_curve[k]+=n;per_data[self.rows[k]['data_id']]+=n
        if (new>self.cap or any(per_curve[k]>self.rows[k]['additional_likelihood_cap']for k in curve_ids)
            or any(per_data[d]>self.data_caps[d]for d in per_data)):
            raise LimitReached('D2 global/curve/data reserve exhausted before likelihood')
        self.charged=new;self.by_curve=per_curve;self.by_data=per_data
        self.by_reason[reason]=self.by_reason.get(reason,0)+n*len(curve_ids)
        self.records.append(dict(curves=list(curve_ids),points=n,values=n*len(curve_ids),reason=reason,status='RESERVED'))
        return len(self.records)-1

    def complete(self,index,*,success):
        if type(index)is not int or not 0<=index<len(self.records) or type(success)is not bool or self.records[index]['status']!='RESERVED':
            raise ValueError('unfinished existing reservation required')
        self.records[index]['status']='COMPLETE'if success else'FAILED_CHARGED'

    def report(self):
        return dict(additional_charged_values=self.charged,historical_values=self.history,
                    cumulative_values=self.history+self.charged,additional_cap=self.cap,
                    by_curve=dict(self.by_curve),by_data=dict(self.by_data),by_reason=dict(self.by_reason),
                    failed_reserved_values=sum(r['values']for r in self.records if r['status']!='COMPLETE'),
                    history_not_refunded=True,per_curve_caps={k:r['additional_likelihood_cap']for k,r in self.rows.items()})
