"""CDF of a separate PCHIP log-likelihood under a positive PCHIP density.

This exactly partitions the monotone cubic pieces of the event surrogate.
No statement about all crossings of an unknown physical likelihood is made.
"""
import math
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq


class LogLikelihoodContour:
    def __init__(self,density):
        self.density=density
        self.nodes=np.array(density.alpha_nodes,copy=True)
        self.levels=np.array(density.log_likelihood_nodes,copy=True)
        if not np.isfinite(self.nodes).all() or not np.isfinite(self.levels).all():
            raise ValueError('Contour interpolant requires finite original log likelihoods')
        self.event=PchipInterpolator(self.nodes,self.levels,extrapolate=False)
        if not np.isfinite(self.event.c).all(): raise ArithmeticError('Nonfinite event coefficients')
        # Check the shape-preserving monotonicity property on each entire cubic.
        worst=0.
        for i,(left,right) in enumerate(zip(self.nodes[:-1],self.nodes[1:])):
            width=right-left; c=self.event.c[:,i]
            points=[0.,width]
            if c[0]!=0:
                root=-c[1]/(3*c[0])
                if 0<root<width: points.append(root)
            derivative=np.array([3*c[0]*x*x+2*c[1]*x+c[2] for x in points])
            delta=self.levels[i+1]-self.levels[i]
            scale=max(float(np.max(abs(derivative))),abs(delta)/width,np.finfo(float).tiny)
            allowance=256*np.finfo(float).eps*scale
            bad=max(0.,float(-np.min(derivative))) if delta>0 else (max(0.,float(np.max(derivative))) if delta<0 else float(np.max(abs(derivative))))
            if bad>allowance: raise ArithmeticError('Event piece is not monotone to recorded roundoff')
            worst=max(worst,bad/scale)
        self.maximum_relative_monotonicity_roundoff=worst

    def cdf(self,log_threshold):
        level=float(log_threshold)
        if not math.isfinite(level): raise ValueError('Finite contour threshold required')
        intervals=[];roots=[];plateau_mass=0.;numerator=0.
        # A crossing exactly on a shared node is handled by the neighboring
        # full/empty pieces, but must still appear in the contour diagnostics.
        for i in range(1,len(self.nodes)-1):
            if self.levels[i]==level and ((self.levels[i-1]<level<self.levels[i+1]) or (self.levels[i+1]<level<self.levels[i-1])):
                roots.append(float(self.nodes[i]))
        for i,(left,right) in enumerate(zip(self.nodes[:-1],self.nodes[1:])):
            y0,y1=self.levels[i:i+2]
            if y0==level and y1==level:
                mass=float(self.density.spline.integrate(left,right))
                numerator+=mass; plateau_mass+=mass; intervals.append([float(left),float(right)])
                continue
            if max(y0,y1)<=level:
                lo,hi=left,right
            elif min(y0,y1)>=level:
                continue  # isolated equality has zero mass under continuous density
            else:
                width=right-left
                c=self.event.c[:,i]
                # Local polynomial avoids an unnecessary alpha subtraction inside PPoly.
                def at(t):
                    x=width*t
                    return ((c[0]*x+c[1])*x+c[2])*x+c[3]-level
                t=brentq(at,0.,1.,xtol=1e-14,rtol=1e-14)
                root=left+width*t; roots.append(float(root))
                lo,hi=(left,root) if y0<y1 else (root,right)
            mass=float(self.density.spline.integrate(lo,hi))
            numerator+=mass; intervals.append([float(lo),float(hi)])
        value=numerator/self.density.mass
        allowance=self.density.roundoff_mass_diagnostic+512*np.finfo(float).eps*len(self.nodes)
        if not math.isfinite(value) or value < -allowance or value>1+allowance:
            raise ArithmeticError('Event probability outside roundoff allowance')
        return {'probability':float(value),'plateau_probability':float(plateau_mass/self.density.mass),
                'roots_alpha':sorted(set(roots)),'selected_intervals_alpha':intervals,
                'roundoff_mass_diagnostic':float(allowance),'new_likelihood_values':0,
                'scope':'INTERPOLATED_DENSITY_AND_EVENT_ONLY_NO_PHYSICAL_TOPOLOGY_CERTIFICATE',
                'physical_numerical_status':'NOT_EVALUATED','continuous_uniform_PIT_requires_tie_assessment':bool(plateau_mass>0)}
