# Contorno PCHIP de logL — candidato C09

O componente mantém duas aproximações distintas: uma PCHIP positiva da densidade
posterior em alpha=asin(u) e outra PCHIP dos valores originais de logL nos mesmos
nós. A densidade não recebe os pesos GL como se fossem valores de função.
O evento logL≤logL_true é integrado por antiderivadas da densidade, após resolver
os cruzamentos das peças monótonas do interpolante de logL. Não há avaliações
novas da likelihood para os cortes; os valores das bordas já avaliados ao
construir a densidade são preservados em `pchip_density.py`.

A propriedade de monotonicidade da PCHIP é conferida em cada polinômio com
seus extremos de derivada e margem explícita de arredondamento. Raízes internas
usam coordenada local[0,1], e cruzamentos exatamente sobre um nó compartilhado
aparecem no diagnóstico. A falha inicial de contagem desse último caso está
preservada em `tests_v1.log`; as probabilidades daquele caso não estavam erradas.
`tests_v2.log` registra seis testes ROOT aprovados em0,370s, com três prioris,
integrais diretas, dois cruzamentos, 14 meias-ondas, escala logarítmica e átomos.

`roots_alpha` é a lista de cruzamentos estritos do nível, não um inventário de
raízes com multiplicidade: tangências nodais isoladas podem não aparecer. Elas
têm massa zero para a densidade contínua e não mudam a CDF. Intervalos inteiros
no nível são tratados separadamente: sua massa está em `plateau_probability`.
Uma massa de platô não deve ser submetida a uma hipótese uniforme contínua
sem tratamento de empates. `selected_intervals_alpha` registra a integração
realizada, inclusive as peças que contribuem integralmente.

O status físico é sempre NOT_EVALUATED: completar as raízes do polinômio não
completa as raízes da função física desconhecida. A concordância coarse/fine
sozinha também pode perder um pico estreito, como demonstrado na v2 anterior.
O piloto C09 deve confrontar densidade, contorno, CDF e quantis com avaliações
físicas independentes, incluindo limites de fase e massa perto do limiar.
Nenhuma ORF, posterior PTA ou campanha SBC foi executada por este componente.

A revisão independente em `../c09_contour_review/` encontrou apenas a limitação
nominal de raízes/tangências acima e verificou controles adicionais; seu
manifesto vincula a versão efetivamente revista. As versões anteriores em
`../c09_integrator/` e `../c09_integrator_v2/` continuam preservadas.
