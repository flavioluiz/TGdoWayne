import math,sys,unittest
from pathlib import Path
import numpy as np
from scipy.integrate import quad
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'c09_integrator'))
from integrator import Posterior1D,MassPrior,EvaluationBudget
from pchip_density import PositivePchipCDF
from contour import LogLikelihoodContour


class ContourTests(unittest.TestCase):
    def make(self,function,prior='uniform_u',order=64):
        budget=EvaluationBudget(maximum_values=30000)
        direct=Posterior1D(function,MassPrior(prior),order=order,budget=budget)
        density=PositivePchipCDF(direct)
        return direct,density,LogLikelihoodContour(density),budget

    def test_monotone_three_prior_measures(self):
        for prior in ['uniform_u','uniform_u_squared','log_uniform_u']:
            direct,density,contour,budget=self.make(lambda u:7*u-1000,prior)
            before=budget.values
            for u in [.02,.13,.51,.9,.995]:
                actual=contour.cdf(7*u-1000)
                self.assertLess(abs(actual['probability']-density.cdf(u)),2e-5)
                self.assertEqual(actual['new_likelihood_values'],0)
                self.assertEqual(actual['physical_numerical_status'],'NOT_EVALUATED')
            self.assertEqual(budget.values,before)

    def test_flat_event_atom_is_reported(self):
        direct,density,contour,budget=self.make(lambda u:np.zeros_like(u))
        result=contour.cdf(0)
        self.assertAlmostEqual(result['probability'],1,places=12)
        self.assertAlmostEqual(result['plateau_probability'],1,places=12)
        self.assertTrue(result['continuous_uniform_PIT_requires_tie_assessment'])
        self.assertEqual(contour.cdf(-1)['probability'],0.)

    def test_two_crossings_against_direct_integral(self):
        f=lambda u:-50*(u-.5)**2
        direct,density,contour,budget=self.make(f)
        total=quad(lambda u:math.exp(float(f(u))),0,1,epsabs=1e-12)[0]
        for radius in [.03,.2,.4]:
            threshold=-50*radius**2
            oracle=(quad(lambda u:math.exp(float(f(u))),0,.5-radius,epsabs=1e-12)[0]+quad(lambda u:math.exp(float(f(u))),.5+radius,1,epsabs=1e-12)[0])/total
            actual=contour.cdf(threshold)
            self.assertEqual(len(actual['roots_alpha']),2)
            self.assertLess(abs(actual['probability']-oracle),2e-5)

    def test_oscillatory_multiple_crossings(self):
        f=lambda u:2*np.sin(14*np.pi*u)
        direct,density,contour,budget=self.make(f)
        total=sum(quad(lambda u:math.exp(float(f(u))),i/14,(i+1)/14,epsabs=1e-12)[0] for i in range(14))
        numerator=sum(quad(lambda u:math.exp(float(f(u))),i/14,(i+1)/14,epsabs=1e-12)[0] for i in range(1,14,2))
        result=contour.cdf(0)
        self.assertGreaterEqual(len(result['roots_alpha']),12)
        self.assertLess(abs(result['probability']-numerator/total),.0002)

    def test_log_scale_and_level_range(self):
        _,_,a,_=self.make(lambda u:-3*u)
        _,_,b,_=self.make(lambda u:600-3*u)
        for level in [-2.5,-1.5,-.2]: self.assertAlmostEqual(a.cdf(level)['probability'],b.cdf(600+level)['probability'],places=11)
        self.assertEqual(a.cdf(-4)['probability'],0.)
        self.assertAlmostEqual(a.cdf(1)['probability'],1.,places=12)

    def test_nonfinite_guards(self):
        _,density,contour,_=self.make(lambda u:-u)
        with self.assertRaises(ValueError): contour.cdf(float('nan'))
        density.log_likelihood_nodes[3]=-math.inf
        with self.assertRaises(ValueError): LogLikelihoodContour(density)

if __name__=='__main__':unittest.main(verbosity=2)
