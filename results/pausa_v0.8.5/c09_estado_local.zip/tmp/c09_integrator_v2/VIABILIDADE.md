# C09 v2 candidata — antiderivada PCHIP da densidade

**Parecer:** viável como acelerador prospectivo de CDF/quantis, sujeito a gates próprios. A v1 direta permanece congelada em `tmp/c09_integrator/`. Esta avaliação não altera tolerâncias, orçamento, dados ou arquivos ROOT; não calcula PTA/ORF. O custo total de uma produção física ainda não foi medido.

## Construção ensaiada

`PositivePchipCDF(direct)` recebe um objeto `Posterior1D` v1. Usa os mesmos nós GL emα, acrescenta bordas de painéis e avalia a likelihood somente nessas bordas. Interpola **L(u)π(u)cosα escalada**, removendo o peso de quadratura: interpolar as massas GL seria incorreto. A escala logarítmica comum evita underflow da normalização inteira.

As bordas usam limites analíticos da medida para likelihood finita: densidade emα zero no extremo u=1; zero também emu=0 para priori2u; L(0) para priori uniforme; valor finito com ε explícito para a log-uniforme. Uma likelihood singular na borda exigiria outra análise, não estes limites.

PCHIP preserva a não negatividade matemática entre amostras não negativas. O candidato verifica coeficientes finitos e o mínimo do polinômio em todos os nós/extremos estacionários; rejeita negatividade superior à margem de arredondamento de64eps na escala da densidade e não usa clipping. A exigência intermediária de sinal estritamente não negativo em cada avaliação flutuante rejeitou mínimos entre−4,2×10⁻²⁵ e−5,4×10⁻²¹ nos extremos; esse teste de aritmética foi corrigido, sem alterar os limites científicos. Os mínimos e a margem convertida em massa são registrados, e a margem entra no gate da CDF. Isso continua sendo diagnóstico numérico, não prova intervalar de erro. Sob caudas subnormais, SciPy emitiu um aviso de overflow na média harmônica de inclinações. A segunda execução captura e registra o aviso por caso, conserva o teste de finitude e de positividade e não o confunde com aprovação global.

Sua antiderivada é um polinômio por partes de grau4, avaliado sem novas logL. A CDF é normalizada pela **integral do próprio interpolante**. Dividi-la por Z_GL imporia CDF(1)≠1; portanto logZ_PCHIP versus logZ_GL é um gate explícito. Os quantis resolvem a antiderivada barata com Brent; não exigem integrais parciais de logL a cada passo.

## Evidência sintética

`assessment.json` contém12 casos: três prioris × likelihood constante, exponencial, mistura de dois modos e camada estreita no limiar. Todos passaram os gates ensaiados. Máximos observados na primeira execução:

- |CDF_PCHIP64−CDF_direta64|=7,10×10⁻⁶ nos cortes selecionados;
- |logZ_PCHIP64−logZ_GL64|=1,36×10⁻⁶;
- quantis dentro dos brackets/tolerâncias diretos e refinamento32→64 aceito;
- custo de construção960→982 avaliações para as duas prioris com suporte[0,1], ou768→786 para a log-uniforme. CDFs e quantis posteriores não acrescentam avaliações de logL.

A v1 usou5.116–5.212 avaliações por curva para o mesmo tipo de pacote de produtos direto; o potencial ganho de **contagem de logL** é cerca de5–6 vezes. Isso não é um ganho medido de tempo PTA: fatorações compartilhadas, raízes, controles, armazenamento e validação continuam tendo custo. Ainda assim, elimina a razão estrutural mais imediata para extrapolar o teto120M a partir das bissecções de quantis.

O ensaio também preserva um contraexemplo: `L(u)=1+1000 exp[-((u−.41234)/1e−5)²]`. GL32/64 e os dois PCHIP praticamente concordam entre si, mas perdem um pico estreito. O valor analítico e uma Gauss–Kronrod com pontos independentes na região concordam em logZ≈.01756929, enquanto o interpolante dá≈0. A comparação dos níveis **sozinha** aceitaria erradamente esse caso; o oráculo o marca `UNRESOLVED_ORACLE_FAILURE`. Não há certificação global por malha finita.

## Gates antes de adotar

1. Preservar GL32/64 para Z, momentos e KL, e conferir **também** Z de cada interpolante; CDF/quantis da v2 têm flags separados.
2. Nos16 pilotos físicos pré-selecionados, confrontar CDFs e brackets PCHIP com integrais parciais diretas v1 e quadratura adaptativa em outra coordenada. Cobrir todas as prioris, limiar, ruídos e mistura de distâncias. Não aprovar por concordância apenas entre representações que usam os mesmos nós.
3. O refinamento32→64 deve passar e pontos físicos de controle fora dos nós precisam testar a forma da densidade e da logL. A estrutura de fase da ORF fornece informação adicional para escolher refinamentos; não derivar resolução apenas do aspecto suave dos pontos observados.
4. Preservar os limites C09: .001logZ/momentos/KL, .002CDF/PIT e bracket≤.001emu. Quando um gate falhar, refinar painéis/ordens sob teto ou registrarUNRESOLVED; não trocar o conjunto de dados ou descartar IDs.
5. Medir contagem e tempo do pacote completo em engenharia, incluindo todos os controles de contorno. Guardar Z_GL, Z_PCHIP, diferenças, normas e identidade das fontes.

## PITlogL operacional em uma versão posterior

Esta pequena avaliação **não implementa ainda** a substituição do contrato de topologia da v1. Uma rota candidata é construir separadamente um interpolante de logL, obter todas as raízes de cada segmento cúbico para o nível da verdade e usar a antiderivada da densidade nos intervalos selecionados. A integral de densidade e a função cujo nível define o evento seriam duas aproximações distintas, ambas a validar. Raízes completas do polinômio não provam raízes completas da likelihood física.

Conforme a orientação atual do ROOT, uma validação operacional finita pode ser suficiente: refinamento de contornos, oráculos independentes, confronto das raízes/regiões físicas e estabilidade dos numeradores, com status como `OPERATIONALLY_RESOLVED_ON_VALIDATED_DOMAIN` e margem numérica explícita. Não precisa alegar uma prova matemática global de monotonicidade da likelihood física. Ausência de controles suficientes, travessias incompatíveis ou regiões sem resolução mantém envelope[0,1]. Tangências, platôs e regiões extremamente estreitas exigem controles próprios.

Não é adequado apenas mudar o nome do status da v1 ou aceitar um booleano “validado”. A evolução do protocolo e as evidências operacionais devem ser congeladas antes do piloto que as utiliza. Esta proposta cabe em C09 condicional; não inclui C10, posterior5D ou reanálise observacional.

## Reproduzir somente o ensaio leve

```sh
VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=tmp/c09_integrator .venv/bin/python tmp/c09_integrator_v2/assess.py
```

O processo tem teto adicional de30sCPU, não inicia simulações e não importa o projeto PTA. Resultados e hashes ficam nesta pasta temporária.
