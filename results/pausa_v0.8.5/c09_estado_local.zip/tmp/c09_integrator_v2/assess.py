from pathlib import Path
import resource,time,json,hashlib,math
resource.setrlimit(resource.RLIMIT_CPU,(25,30))
started=time.process_time()
import numpy as np
from scipy.integrate import quad
from integrator import MassPrior, Posterior1D, EvaluationBudget
from pchip_candidate import PositivePchipCDF
cases=[]
functions={
 'flat': lambda u:np.zeros_like(u),
 'exponential':lambda u:7*u-1000,
 'bimodal':lambda u:np.logaddexp(-.5*((u-.13)/.035)**2,math.log(.45)-.5*((u-.82)/.07)**2),
 'threshold':lambda u:-2000*(1-u),
}
for kind in ('uniform_u','uniform_u_squared','log_uniform_u'):
 for name,f in functions.items():
  prior=MassPrior(kind);budget=EvaluationBudget(maximum_values=20000)
  a,b=[Posterior1D(f,prior,order=n,budget=budget) for n in (32,64)]
  initial=budget.values
  pa,pb=PositivePchipCDF(a),PositivePchipCDF(b)
  construction=budget.values
  cuts=[x for x in (.001,.013,.13,.231,.5,.631,.82,.95,.995,.999) if x>prior.lower]
  dc=[abs(pb.cdf(x)-b.cdf(x)) for x in cuts]
  refin=[abs(pa.cdf(x)-pb.cdf(x)) for x in cuts]
  qs=[]
  for prob in (.05,.5,.9,.95):
   q=pb.ppf(prob);qa=pa.ppf(prob)
   bracket=b.quantile_bracket(prob)
   outside=max(bracket['low']-q,q-bracket['high'],0.)
   qs.append({'probability':prob,'pchip_fine':q,'pchip_coarse':qa,'direct_bracket':bracket,'distance_outside_direct_bracket':outside,'passed':outside<=.0005 and abs(q-qa)<=.001})
  delta_z=abs(pb.logz-b.logz)
  cases.append({'prior':kind,'shape':name,'initial_values':initial,'construction_values':construction,'values_with_direct_validation':budget.values,'pchip_logz_vs_GL64':delta_z,'pchip_logz_32_vs_64':abs(pa.logz-pb.logz),'maximum_cdf_vs_direct':max(dc),'maximum_cdf_32_vs_64':max(refin),'minimum_density':pb.minimum_scaled_density,'roundoff_mass_diagnostic':pb.roundoff_mass_diagnostic,'construction_warnings':pa.construction_warnings+pb.construction_warnings,'quantiles':qs,'candidate_passed':delta_z<=.001 and max(dc)+pb.roundoff_mass_diagnostic<=.002 and max(refin)<=.002 and all(x['passed'] for x in qs)})
# Aliasing counterexample with exact analytic Z: levels alone cannot prove completeness.
centre=.41234;width=1e-5;amp=1000.
f=lambda u:np.log1p(amp*np.exp(-((u-centre)/width)**2))
prior=MassPrior('uniform_u');a,b=[Posterior1D(f,prior,order=n) for n in (32,64)];pa,pb=PositivePchipCDF(a),PositivePchipCDF(b)
z=1+amp*width*math.sqrt(math.pi)*.5*(math.erf((1-centre)/width)+math.erf(centre/width))
# Independent integration resolves the known narrow feature with its own breakpoints.
zquad=quad(lambda u:1+amp*math.exp(-((u-centre)/width)**2),0,1,points=[centre-8*width,centre,centre+8*width],epsabs=1e-11,epsrel=1e-11,limit=100)[0]
miss={'name':'analytic_hidden_spike','GL32':a.logz,'GL64':b.logz,'PCHIP32':pa.logz,'PCHIP64':pb.logz,'analytic_logz':math.log(z),'quad_logz':math.log(zquad),'error_PCHIP64':abs(pb.logz-math.log(z)),'levels_alone_misleading':abs(pa.logz-pb.logz)<.001 and abs(pb.logz-math.log(z))>.001,'status':'UNRESOLVED_ORACLE_FAILURE'}
assert miss['levels_alone_misleading']
assert abs(math.log(zquad)-math.log(z))<1e-10
p=Path(__file__).resolve().parent
out={'status':'PROSPECTIVE_SYNTHETIC_ASSESSMENT_ONLY','physical_calls':0,'process_cpu_seconds':time.process_time()-started,'additional_CPU_hard_cap_seconds':30,'cases':cases,'counterexample':miss,'sources':{x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in ('pchip_candidate.py','assess.py')},'reference_integrator_sha256':hashlib.sha256((p.parent/'c09_integrator/integrator.py').read_bytes()).hexdigest()}
(p/'assessment.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'cpu_seconds':out['process_cpu_seconds'],'passing_synthetic_cases':sum(x['candidate_passed'] for x in cases),'cases':len(cases),'max_CDF_difference':max(x['maximum_cdf_vs_direct'] for x in cases),'max_delta_logz':max(x['pchip_logz_vs_GL64'] for x in cases),'calls_with_pchip_only':sorted(set((x['initial_values'],x['construction_values']) for x in cases)),'counterexample':miss},indent=2))
