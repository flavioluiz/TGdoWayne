"""Prospective CDF accelerator only; does not certify physical contours."""
import math
import warnings
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq


class PositivePchipCDF:
    def __init__(self, direct):
        self.direct = direct
        alpha, logmeasure, _ = direct._rule(direct.prior.lower, 1.)
        # Remove GL weights: this interpolates a density, not quadrature masses.
        logdensity = direct._ell + direct.prior.log_alpha_density(alpha)
        edge_u = direct.edges.copy()
        edge_alpha = np.arcsin(edge_u)
        edge_ll = direct.evaluate(edge_u)
        edge_logdensity = np.full_like(edge_u,-np.inf)
        for i,(u,a,ell) in enumerate(zip(edge_u,edge_alpha,edge_ll)):
            if u == 1 or (u == 0 and direct.prior.kind == 'uniform_u_squared'):
                continue  # regular finite-likelihood endpoint density limit is zero
            logprior = 0.
            if direct.prior.kind == 'uniform_u_squared': logprior = math.log(2*u)
            if direct.prior.kind == 'log_uniform_u': logprior = -math.log(u)-math.log(-math.log(direct.prior.cutoff))
            edge_logdensity[i] = ell+logprior+math.log(math.cos(a))
        x = np.r_[alpha,edge_alpha]
        ld = np.r_[logdensity,edge_logdensity]
        indices = np.argsort(x)
        x,ld = x[indices],ld[indices]
        if np.any(np.diff(x) <= 0): raise ValueError('duplicate or unresolved interpolation nodes')
        shift = float(np.max(ld))
        y = np.exp(ld-shift)
        with warnings.catch_warnings(record=True) as observed:
            warnings.simplefilter('always', RuntimeWarning)
            self.spline = PchipInterpolator(x,y,extrapolate=False)
        self.construction_warnings = [str(w.message) for w in observed]
        self.primitive = self.spline.antiderivative()
        if not np.all(np.isfinite(self.spline.c)) or not np.all(np.isfinite(self.primitive.c)):
            raise ArithmeticError('nonfinite interpolant coefficients')
        self.low = float(edge_alpha[0]); self.high = math.pi/2
        self.base = float(self.primitive(self.low))
        self.mass = float(self.primitive(self.high)-self.base)
        if not np.isfinite(self.mass) or self.mass <= 0: raise ValueError('invalid interpolated mass')
        self.logz = shift+math.log(self.mass)
        # Every stationary point of this piecewise cubic, plus all endpoints.
        stationary = self.spline.derivative().roots(extrapolate=False)
        stationary = stationary[np.isfinite(stationary)&(stationary>=self.low)&(stationary<=self.high)]
        self.minimum_scaled_density = float(np.min(self.spline(np.r_[x,stationary])))
        self.roundoff_density_allowance = 64*np.finfo(float).eps*max(1.,float(np.max(y)))
        self.roundoff_mass_diagnostic = self.roundoff_density_allowance*(self.high-self.low)/self.mass
        if self.minimum_scaled_density < -self.roundoff_density_allowance:
            raise ArithmeticError('negative interpolated density beyond floating-point allowance')
        self.node_count = len(x)
        self.extra_edge_likelihood_values = len(edge_u)
        self.coordinate = 'alpha=asin(u)'

    def cdf(self, u):
        u = float(u)
        if not np.isfinite(u): raise ValueError('invalid CDF coordinate')
        if u <= self.direct.prior.lower: return 0.
        if u >= 1: return 1.
        return float((self.primitive(math.asin(u))-self.base)/self.mass)

    def ppf(self, probability):
        p = float(probability)
        if not np.isfinite(p) or not 0 <= p <= 1: raise ValueError('invalid probability')
        if p == 0:return self.direct.prior.lower
        if p == 1:return 1.
        # All evaluations here are of the analytic quartic antiderivative.
        return float(brentq(lambda u:self.cdf(u)-p,self.direct.prior.lower,1.,xtol=1e-13,rtol=1e-13))
