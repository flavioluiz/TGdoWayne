"""ROOT single D1b continuation, source reviewed before this launcher was written."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PACKAGE = ROOT / 'tmp/c09_D1b_candidate_v1'
PLAN = PACKAGE / 'preflight.json'
EXPECTED_PLAN = '18c917569519f87d261d75c14f7a252bfb6bbf5e20ae223a7d6ef4cd65f1684f'
OUTPUT = ROOT / 'tmp/c09_D1b_execution_v1'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024**2), b''): h.update(block)
    return h.hexdigest()

def write_new(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')

def cpu(who):
    r = resource.getrusage(who)
    return r.ru_utime + r.ru_stime

def rss(who):
    r = resource.getrusage(who).ru_maxrss
    return int(r if sys.platform == 'darwin' else 1024*r)

def main():
    start = time.perf_counter()
    assert sha(PLAN) == EXPECTED_PLAN and not OUTPUT.exists()
    assert sha(PACKAGE/'manifest.json') == '6a017f15b58d4edca240ed0fcc4bd5f6af1cf058b4d078af43480338b52be3d2'
    manifest = json.loads((PACKAGE/'manifest.json').read_text())
    for f in manifest['files']:
        p = ROOT/f['path']
        assert p.stat().st_size == f['bytes'] and sha(p) == f['sha256'], str(p)
    sys.path.insert(0, str(PACKAGE))
    from supervisor import validate_plan, SCOPE
    plan, digest = validate_plan(PLAN)
    assert digest == EXPECTED_PLAN and len(plan['bindings']) == 151
    runtime = json.loads((PACKAGE/'runtime_config.json').read_text())
    assert runtime['backend_probability_margin_by_target'] is None
    assert runtime['active_targets'] == [0,4,6,10,11]
    test = json.loads((PACKAGE/'toy_results_attempt3.json').read_text())
    assert test['passed'] and test['within_TOY_caps'] and test['tests'] == 12
    history_bytes = sum(p.stat().st_size for d in plan['history']['output_directories'] for p in (ROOT/d).rglob('*') if p.is_file())
    assert history_bytes == plan['history']['output_bytes'] == 9181315
    review = dict(status='ROOT_REVIEWED_ONE_D1B_EXECUTION', plan_sha256=digest,
                  bindings_verified=151, package_manifest_sha256=sha(PACKAGE/'manifest.json'),
                  launcher_sha256=sha(Path(__file__)), test_report_sha256=sha(PACKAGE/'toy_results_attempt3.json'),
                  source_review='ROOT read full engine/worker/cache_reuse/prepare and complete supervisor delta against previously reviewed v1; arithmetic, config delta and limits checked.',
                  decisions=['Five saved caches, same observation/kernel/table.125000 old values retain historical cost; only new misses charged.',
                             'New orchestration source identity is distinct and old identity retained. Five numerical helper copies are byte exact.',
                             'Partition rebuilt under same largest-ambiguous-mass rule, up to2399 total splits; may differ from the previous limited attempt.',
                             '120CPU/50000LL/10000perID/8MiB new;600CPU/1M/60000perID/20MiB historical hard caps retained.',
                             'Saved-table diagnostic only; physical probability margin remainsNone, no SBC or C09 completion inferred.',
                             'One execution, preserve failure, no automatic retry. No D2/D3 physical authorization.'],
                  limits=plan['limits'], inherited_output_bytes=history_bytes)
    review_path = HERE/'D1b_integrated_review_v1.json'
    write_new(review_path, review)
    auth = HERE/'D1b_authorization_v1.json'
    write_new(auth, dict(schema='C09_D1B_EXECUTION_AUTHORIZATION_v1', authority='ROOT', approved=True,
                        execution_allowed=True, mode='D1b', scope=SCOPE, plan_sha256=digest, output=str(OUTPUT),
                        automatic_retry=False, ROOT_review_sha256=sha(review_path), scientific_result_approval=False,
                        new_ORF=0,new_sky=0,new_draws=0))
    command = [sys.executable,'-B',str(PACKAGE/'supervisor.py'),'execute','--plan',str(PLAN),'--authorization',str(auth),'--output',str(OUTPUT)]
    env = dict(os.environ)
    env.update({k:'1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS')})
    env['PYTHONDONTWRITEBYTECODE']='1'
    print(json.dumps(dict(status='ROOT_D1B_AUTHORIZED_AND_STARTING',plan_sha256=digest,authorization_sha256=sha(auth),output=str(OUTPUT))),flush=True)
    before = cpu(resource.RUSAGE_CHILDREN)
    log_path = HERE/'D1b_external_execution_v1.log'
    with log_path.open('xb') as log:
        result = subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
    children = cpu(resource.RUSAGE_CHILDREN)-before
    end_path=OUTPUT/'execution_end.json'
    end=json.loads(end_path.read_text()) if end_path.exists() else None
    assert sha(PLAN)==EXPECTED_PLAN
    own=cpu(resource.RUSAGE_SELF);total=own+children
    receipt=dict(status='ROOT_EXTERNAL_PROCESS_FINISHED',returncode=result.returncode,plan_sha256=digest,
                 authorization_sha256=sha(auth),supervisor_end_sha256=sha(end_path) if end else None,
                 supervisor_status=end['status'] if end else None,ROOT_CPU_seconds=own,
                 supervisor_and_worker_CPU_seconds_including_exit=children,additional_CPU_seconds=total,
                 cumulative_CPU_seconds=449.022608+total,ROOT_peak_RSS_bytes=rss(resource.RUSAGE_SELF),
                 child_tree_peak_RSS_bytes=rss(resource.RUSAGE_CHILDREN),wall_seconds=time.perf_counter()-start,
                 log_sha256=sha(log_path),new_CPU_within_120=total<=120,cumulative_CPU_within_600=449.022608+total<=600,
                 no_automatic_retry=True,C09_complete=False,
                 scope='Fresh ROOT startup/preflight plus reaped supervisor/worker; receipt serialization and ROOT exit follow this final sample.')
    write_new(HERE/'D1b_external_end_v1.json',receipt)
    print(json.dumps(receipt),flush=True)
    return result.returncode

if __name__=='__main__':raise SystemExit(main())
