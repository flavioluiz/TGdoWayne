"""ROOT-only, single bounded D1 execution after complete source review."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PLAN = ROOT / 'tmp/c09_event_repair_runtime_v1/preflight.json'
EXPECTED_PLAN = '8176d19a8de558f93224f60200f2cf13af1fafdaba545e788967a8535b69f5b8'
OUTPUT = ROOT / 'tmp/c09_D1_execution_v1'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def cpu(who):
    r = resource.getrusage(who)
    return r.ru_utime + r.ru_stime


def rss(who):
    value = resource.getrusage(who).ru_maxrss
    return int(value if sys.platform == 'darwin' else value * 1024)


def main():
    start = time.perf_counter()
    assert sha(PLAN) == EXPECTED_PLAN
    sys.path.insert(0, str(ROOT / 'tmp/c09_d1_supervisor_v1'))
    from supervisor import validate_plan, SCOPE
    plan, digest = validate_plan(PLAN)
    assert digest == EXPECTED_PLAN and not OUTPUT.exists()
    runtime = json.loads((ROOT / plan['worker_parameters']['runtime_config']).read_text())
    assert runtime['backend_probability_margin_by_target'] is None
    assert runtime['algorithm']['envelope_roundoff_allowance_logL'] == 1e-9
    validation = ROOT / 'tmp/c09_event_repair_runtime_v1/toy_validation_attempt4.json'
    v = json.loads(validation.read_text())
    assert v['passed'] and v['budget_pass'] and v['tests'] == 5
    toys = ROOT / 'tmp/c09_event_repair_runtime_v1/toy_preflight.json'
    assert sha(toys) == v['preflight_sha256']
    for path, expected in json.loads(toys.read_text())['sources'].items():
        assert sha(ROOT / path) == expected, path
    historical_bytes = sum(p.stat().st_size for d in plan['history']['output_directories']
                           for p in (ROOT / d).rglob('*') if p.is_file())
    assert historical_bytes == plan['history']['output_bytes']
    review = dict(status='ROOT_REVIEWED_FOR_ONE_D1_EXECUTION', plan_sha256=digest,
                  bindings_verified=len(plan['bindings']), launcher_sha256=sha(Path(__file__)),
                  pure_component_review_sha256=sha(HERE / 'pure_component_review.json'),
                  supervisor_review_sha256=sha(HERE / 'supervisor_review.json'),
                  runtime_toy_report_sha256=sha(validation),
                  sources_read=['engine.py', 'worker.py', 'batched_cache.py', 'cells_runtime.py',
                                'polynomial_fast.py', 'mass_reference.py', 'surrogate_event.py',
                                'build_metadata.py', 'run_toys.py', 'runtime_config.json', 'preflight.json'],
                  review_scope='Complete runtime source, deltas, pure mathematical modules, supervisor and candidate configuration read by ROOT.',
                  decisions=['Same14 observations and fixed nuisances; no new ORF, sky, draws or refitted response.',
                             'Every likelihood miss charged before evaluation, completed batches retained on failure.',
                             'Independent mass references are operational quadrature estimates in the prior measure.',
                             '1e-9 roundoff allowance is a prospective operational choice checked against finite controls, not a directed-rounding proof.',
                             'Physical probability margin remains unset; physical logL-PIT interval stays [0,1]. Saved-table result is separately labeled.',
                             'All14 retained; no retry, automatic increase or replacement.270s can truncate the attempt; partial evidence remains.',
                             'This is one engineering continuation, not C09 completion, SBC or authorization of D2/D3.'],
                  limits=plan['limits'], inherited_output_bytes=historical_bytes)
    review_path = HERE / 'D1_integrated_review_v1.json'
    write_new(review_path, review)
    authorization = HERE / 'D1_authorization_v1.json'
    write_new(authorization, dict(schema='C09_D1_EXECUTION_AUTHORIZATION_v1', authority='ROOT',
              approved=True, execution_allowed=True, mode='D1', scope=SCOPE, plan_sha256=digest,
              output=str(OUTPUT), automatic_retry=False, ROOT_review_sha256=sha(review_path),
              scientific_result_approval=False, new_ORF=0, new_sky=0, new_draws=0))
    command = [sys.executable, '-B', str(ROOT / 'tmp/c09_d1_supervisor_v1/supervisor.py'),
               'execute', '--plan', str(PLAN), '--authorization', str(authorization), '--output', str(OUTPUT)]
    env = dict(os.environ)
    env.update({k: '1' for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')})
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    before = cpu(resource.RUSAGE_CHILDREN)
    print(json.dumps({'status': 'ROOT_D1_AUTHORIZED_AND_STARTING', 'plan_sha256': digest,
                      'authorization_sha256': sha(authorization), 'output': str(OUTPUT)}), flush=True)
    log_path = HERE / 'D1_external_execution_v1.log'
    with log_path.open('xb') as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, check=False)
    child_cpu = cpu(resource.RUSAGE_CHILDREN) - before
    end_path = OUTPUT / 'execution_end.json'
    end = json.loads(end_path.read_text()) if end_path.exists() else None
    assert sha(PLAN) == EXPECTED_PLAN
    own_cpu = cpu(resource.RUSAGE_SELF)
    total = own_cpu + child_cpu
    receipt = dict(status='ROOT_EXTERNAL_PROCESS_FINISHED', returncode=result.returncode,
                   plan_sha256=digest, authorization_sha256=sha(authorization),
                   supervisor_end_sha256=sha(end_path) if end is not None else None,
                   supervisor_status=end['status'] if end is not None else None,
                   ROOT_CPU_seconds=own_cpu, supervisor_and_worker_CPU_seconds_including_exit=child_cpu,
                   additional_CPU_seconds=total, cumulative_CPU_seconds=plan['history']['cpu_seconds']+total,
                   ROOT_peak_RSS_bytes=rss(resource.RUSAGE_SELF), child_tree_peak_RSS_bytes=rss(resource.RUSAGE_CHILDREN),
                   wall_seconds=time.perf_counter()-start, log_sha256=sha(log_path),
                   new_CPU_within_270=total <= 270, cumulative_CPU_within_600=plan['history']['cpu_seconds']+total <= 600,
                   no_automatic_retry=True, C09_complete=False,
                   scope='Fresh ROOT process startup/preflight plus reaped supervisor/worker; receipt serialization and ROOT exit follow this final sample.')
    write_new(HERE / 'D1_external_end_v1.json', receipt)
    print(json.dumps(receipt), flush=True)
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
