"""Metadata-only summary of the closed nominal14; no new numerical inference."""
from pathlib import Path
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CONFIG = ROOT / 'tmp/c09_nominal14_v4/config.json'
PILOT = ROOT / 'tmp/c09_nominal14_pilot_v4/pilot'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    config = json.loads(CONFIG.read_text())
    rows = []
    sources = [{'path': str(CONFIG.relative_to(ROOT)), 'sha256': sha(CONFIG)}]
    for c in config['rows']:
        path = PILOT / f"target_{c['id']:02d}.json"
        d = json.loads(path.read_text())
        assert d['target'] == c['id'] and d['analysis'] == c['analysis'] and d['prior'] == c['prior']
        q95 = next(q for q in d['quantile_brackets'] if q['probability'] == .95)
        prior95 = {'uniform_u': .95, 'uniform_u_squared': math.sqrt(.95),
                   'log_uniform_u': .001 ** .05}[c['prior']]
        rows.append(dict(target=c['id'], analysis=c['analysis'], prior=c['prior'], scenario=c['scenario'],
                         fixed_truth_u=c['fixed_truth_u'], reference_mean_u=d['reference_moments']['mean_u'],
                         reference_KL=d['reference_moments']['kl_posterior_to_prior'],
                         Q95_low=q95['low'], Q95_high=q95['high'], prior_Q95=prior95,
                         historical_mass_PIT_low=d['mass_PIT_operational_interval'][0],
                         historical_mass_PIT_high=d['mass_PIT_operational_interval'][1],
                         historical_logL_PIT_low=d['logL_PIT_operational_interval'][0],
                         historical_logL_PIT_high=d['logL_PIT_operational_interval'][1],
                         status=d['status'], scope='FIXED_TRUTH_ENGINEERING_NOT_PAIRED_NOT_SBC'))
        sources.append({'path': str(path.relative_to(ROOT)), 'sha256': sha(path)})
    out = HERE / 'historical_nominal14.csv'
    with out.open('x', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    receipt = dict(status='HISTORICAL_METADATA_TRANSCRIPTION_ONLY', rows=len(rows), sources=sources,
                   script_sha256=sha(Path(__file__)), csv_sha256=sha(out),
                   physical_LL=0, ORF=0, draws=0, reclassification=False,
                   note='Original operational intervals and partial status are retained, not independently revalidated here.')
    (HERE / 'historical_nominal14_receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({'rows': len(rows), 'csv_sha256': sha(out), 'physical_LL': 0}))


if __name__ == '__main__':
    main()
