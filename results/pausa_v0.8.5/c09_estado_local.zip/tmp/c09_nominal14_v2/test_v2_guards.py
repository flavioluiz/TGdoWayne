"""New v2 guards only, exact AST, stdlib TOY. No numerical/physical imports."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import math
import resource
import sys
import tempfile
import time
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SOURCE=HERE/'run_nominal14.py'
TREE=ast.parse(SOURCE.read_text())
NAMES={'_count','Budget','ratio_error_radius','scout_level_roots','inherited_backend_resources',
       'remaining_CPU_limits','experiment_and_table','finalize_execution','source_hashes'}
CODE=compile(ast.Module(body=[n for n in TREE.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in NAMES],type_ignores=[]),str(SOURCE),'exec')
CONFIG=json.loads((HERE/'config.json').read_text())
resource.setrlimit(resource.RLIMIT_CPU,(29,30))


class Clock:
 def __init__(self,value=0.):self.value=value
 def process_time(self):return self.value


class Tests(unittest.TestCase):
 def setUp(self):
  self.clock=Clock()
  self.env=dict(math=math,time=self.clock,rss=lambda:0,Path=Path,json=json,ROOT=ROOT,HERE=HERE)
  exec(CODE,self.env)
  self.Budget=self.env['Budget']

 def test_inherited_backend_counts_are_cumulative_and_stage_counts_separate(self):
  b=self.Budget(CONFIG['budgets'],previous_values=448,previous_by_target={str(i):32 for i in range(14)})
  b.likelihood(59968,0)
  self.assertEqual(b.by_target[0],60000)
  self.assertEqual(b.report()['stage_charged_likelihood_values'],59968)
  self.assertEqual(b.report()['charged_likelihood_values'],60416)
  with self.assertRaisesRegex(RuntimeError,'Likelihood ceiling'):b.likelihood(1,0)
  self.assertEqual(b.by_target[0],60000)

 def test_malformed_or_inconsistent_inherited_counts_rejected(self):
  for values,by in [(32,{'0':31}),(32,{'00':32}),(32,{0:16,'0':16}),
                    (True,{'0':True}),(32,{'0':-32}),(60001,{'0':60001})]:
   with self.subTest(values=values,by=by),self.assertRaises(ValueError):
    self.Budget(CONFIG['budgets'],previous_values=values,previous_by_target=by)

 def test_process_start_CPU_and_absolute_RLIMIT_balance(self):
  self.clock.value=100.
  b=self.Budget(CONFIG['budgets'],previous=20.25)
  self.assertEqual(b.report()['combined_CPU_seconds'],120.25)
  self.assertEqual(b.report()['lifecycle']['preflight_and_identity_CPU_seconds'],100.)
  self.assertEqual(self.env['remaining_CPU_limits'](b),(579,581))
  self.clock.value=578.1
  with self.assertRaisesRegex(RuntimeError,'Less than one second'):self.env['remaining_CPU_limits'](b)
  self.clock.value=580.
  with self.assertRaisesRegex(RuntimeError,'Combined CPU'):b.check()

 def test_soft_CPU_stop_cannot_resume_by_next_target(self):
  b=self.Budget(CONFIG['budgets']);b.stop_reason='OS process CPU soft ceiling reached'
  with self.assertRaisesRegex(RuntimeError,'soft ceiling'):b.likelihood(1,0)
  self.assertEqual(b.values,0)

 def end(self):
  return dict(schema='C09_NOMINAL14_EXECUTION_END_v2',source_unchanged=True,table_unchanged=True,
              config_unchanged=True,within_resource_limits=True,execution_completed=True,
              resources=dict(combined_CPU_seconds=123.5,charged_likelihood_values=448,
                             charged_likelihood_values_by_target={str(i):32 for i in range(14)}))

 def test_final_backend_lifecycle_is_used_and_failed_end_rejected(self):
  end=self.end();inherited=self.env['inherited_backend_resources'](end,CONFIG['budgets'])
  self.assertEqual(inherited['previous'],123.5)
  self.assertEqual(self.Budget(CONFIG['budgets'],**inherited).values,448)
  for field in ('source_unchanged','table_unchanged','config_unchanged','within_resource_limits','execution_completed'):
   bad=copy.deepcopy(end);bad[field]=False
   with self.subTest(field=field),self.assertRaises(ValueError):self.env['inherited_backend_resources'](bad,CONFIG['budgets'])
  for cpu in (math.nan,math.inf,-1,600):
   bad=copy.deepcopy(end);bad['resources']['combined_CPU_seconds']=cpu
   with self.subTest(cpu=cpu),self.assertRaises(ValueError):self.env['inherited_backend_resources'](bad,CONFIG['budgets'])
  self.assertNotIn("previous_report['resources']",SOURCE.read_text())
  self.assertIn('backend_execution_end_sha256',SOURCE.read_text())

 def test_numerator_error_changes_operational_PIT_gate_even_with_no_warnings(self):
  radius=self.env['ratio_error_radius'](.5e-6,1e-6,3e-9,1e-12)
  self.assertAlmostEqual(radius,.0030005030005030005)
  # Execute the actual new radius assignment and actual PIT boolean gate.
  pilot=next(n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name=='pilot')
  assignments=[n for n in ast.walk(pilot) if isinstance(n,ast.Assign)]
  ra=next(n for n in assignments if any(isinstance(t,ast.Name) and t.id=='event_radius' for t in n.targets))
  ga=next(n for n in assignments if any(isinstance(t,ast.Subscript) and isinstance(t.value,ast.Name) and t.value.id=='flags' and isinstance(t.slice,ast.Constant) and t.slice.value=='logL_PIT' for t in n.targets))
  env=dict(event_band_radius=0.,total_CDF_radius=2e-12/(1e-6-1e-12),spread=0.,gk_event_radius=radius,
           config=CONFIG,flags=dict(normalization=True,offgrid_form=True,reference_warning_free=True),
           physical_contours=[dict(roots_u=[.25,.75],topology_unknown_from_equalities=False)]*2,
           contour_values=[dict(plateau_probability=0.)]*2)
  exec(compile(ast.Module(body=[ra,ga],type_ignores=[]),str(SOURCE),'exec'),env)
  self.assertFalse(env['flags']['logL_PIT'])
  env['gk_event_radius']=0.
  exec(compile(ast.Module(body=[ra,ga],type_ignores=[]),str(SOURCE),'exec'),env)
  self.assertTrue(env['flags']['logL_PIT'])

 def test_ratio_error_inputs_and_scaling(self):
  fn=self.env['ratio_error_radius']
  self.assertEqual(fn(.5,1.,0.,0.),0.)
  self.assertAlmostEqual(fn(.5,1.,.001,.0001),fn(5.,10.,.01,.001))
  for args in [(.5,1.,-1.,0.),(.5,1.,0.,1.),(.5,0.,0.,0.),(.5,1.,math.inf,0.),(.5,1.,0.,math.nan)]:
   with self.subTest(args=args),self.assertRaises((ValueError,ArithmeticError)):fn(*args)

 def test_isolated_exact_crossing_and_underflow_safe_signs(self):
  fn=self.env['scout_level_roots']
  t=fn([0,.25,.5,.75,1],[-.1,0,.1,-.1,.1],0.,lambda a,b:(a+b)/2)
  self.assertEqual(t['roots_u'],[.25,.625,.875])
  self.assertEqual(t['isolated_exact_crossings_u'],[.25])
  self.assertFalse(t['topology_unknown_from_equalities'])
  tiny=fn([0,1],[-1e-300,1e-300],0.,lambda a,b:.5)
  self.assertEqual(tiny['roots_u'],[.5])

 def test_plateaus_and_tangencies_remain_unknown(self):
  fn=self.env['scout_level_roots']
  plateau=fn([0,.25,.5,.75,1],[-1,0,0,1,2],0.,lambda a,b:(a+b)/2)
  self.assertEqual(plateau['equal_level_intervals_u'],[[.25,.5]])
  self.assertTrue(plateau['topology_unknown_from_equalities'])
  tangent=fn([0,.5,1],[1,0,1],0.,lambda a,b:(a+b)/2)
  self.assertEqual(tangent['observed_tangency_nodes_u'],[.5])
  self.assertTrue(tangent['topology_unknown_from_equalities'])
  self.assertEqual(tangent['roots_u'],[])

 def test_source_closure_uses_v2_and_inference_init(self):
  self.env['digest']=lambda p:str(p)
  names=set(self.env['source_hashes'](CONFIG))
  self.assertIn('src/inference/__init__.py',names)
  self.assertIn('tmp/c09_nominal14_v2/run_nominal14.py',names)
  self.assertIn('tmp/c09_nominal14_v2/planning.py',names)
  self.assertIn('tmp/c09_nominal14_v2/kernels.py',names)
  self.assertNotIn('tmp/c09_nominal14_preflight/run_nominal14.py',names)

 def test_table_changed_during_load_is_rejected_without_real_loader(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);(root/'experiment.json').write_text('{}');table_path=root/'table.npz';table_path.write_bytes(b'TOY_A')
   digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
   c=dict(experiment_config='experiment.json',table_file='table.npz',table_sha256=digest(table_path))
   class NPZ:
    def __enter__(self):return dict(nodes=[0,1],matrices=['TOY'])
    def __exit__(self,*args):return False
   def load(*args,**kwargs):return NPZ()
   def construct(*args,**kwargs):
    table_path.write_bytes(b'TOY_B')
    return SimpleNamespace(fallback=[])
   model=ModuleType('inference.model');model.experiment=lambda c:dict(TOY=True)
   interpolation=ModuleType('inference.orf_interpolation');interpolation.EvenThresholdCubicORF=construct
   self.env.update(ROOT=root,np=SimpleNamespace(load=load),digest=digest)
   with patch.dict(sys.modules,{'inference.model':model,'inference.orf_interpolation':interpolation}):
    with self.assertRaisesRegex(RuntimeError,'changed by the end of loading'):
     self.env['experiment_and_table'](c,SimpleNamespace(check=lambda:None))

 def finalize_fixture(self,root,changed=False,late_cpu=False):
  config=copy.deepcopy(CONFIG);config['table_file']='TOY_table';tp=root/'TOY_table';tp.write_bytes(b'TOY')
  cp=root/'TOY_config';cp.write_text('TOY');out=root/'output';out.mkdir()
  raw_digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
  config['table_sha256']=raw_digest(tp);config_hash=raw_digest(cp)
  self.env['ROOT']=root
  self.clock.value=590. if late_cpu else 10.
  b=self.Budget(CONFIG['budgets'])
  self.clock.value=598. if late_cpu else 12.
  def source_hashes(c):self.clock.value+=2;return {'TOY':'same'}
  def digest(p):self.clock.value+=1;return raw_digest(p)
  self.env.update(source_hashes=source_hashes,digest=digest,
                  write_new=lambda p,v:p.write_text(json.dumps(v,allow_nan=False)))
  if changed:tp.write_bytes(b'CHANGED_TOY')
  return config,SimpleNamespace(config=cp,output=out),config_hash,{'TOY':'same'},b

 def test_final_checks_precede_process_CPU_sample(self):
  with tempfile.TemporaryDirectory() as td:
   values=self.finalize_fixture(Path(td))
   result=self.env['finalize_execution'](*values,True,600,602)
   self.assertEqual(result['resources']['process_CPU_seconds_this_stage'],16.)
   self.assertEqual(result['lifecycle']['final_source_table_output_checks_CPU_seconds'],4.)
   self.assertTrue(result['execution_completed'])
   self.assertIn('serialization',result['lifecycle']['final_sample_scope'])

 def test_final_table_change_and_late_CPU_excess_preserved_and_rejected(self):
  for changed,late in [(True,False),(False,True)]:
   with self.subTest(changed=changed,late=late),tempfile.TemporaryDirectory() as td:
    values=self.finalize_fixture(Path(td),changed=changed,late_cpu=late)
    with self.assertRaises(RuntimeError):self.env['finalize_execution'](*values,True,600,602)
    record=json.loads((values[1].output/'execution_end.json').read_text())
    self.assertFalse(record['execution_completed'])
    self.assertEqual(record['table_unchanged'],not changed)
    self.assertEqual(record['within_resource_limits'],not late)

 def test_frozen_science_nodes_seeds_kernels_and_limits_preserved(self):
  old=ROOT/'tmp/c09_nominal14_preflight'
  v1=json.loads((old/'config.json').read_text())
  self.assertEqual({k:v for k,v in v1.items() if k not in ('schema','dependencies')},
                   {k:v for k,v in CONFIG.items() if k not in ('schema','dependencies')})
  self.assertEqual((old/'kernels.py').read_bytes(),(HERE/'kernels.py').read_bytes())
  self.assertEqual(CONFIG['budgets']['CPU_seconds_combined'],600)
  self.assertEqual(CONFIG['budgets']['estimated_numeric_bytes'],1400000000)
  self.assertEqual(CONFIG['budgets']['RSS_bytes'],1610612736)
  self.assertFalse(any('approval' in p.name.lower() for p in HERE.iterdir()))


if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
 r=resource.getrusage(resource.RUSAGE_SELF);peak=r.ru_maxrss if sys.platform=='darwin' else r.ru_maxrss*1024
 assert r.ru_utime+r.ru_stime<30 and peak<64*1024**2
 record=dict(scope='NEW_V2_GUARDS_ONLY_EXACT_AST_STDLIB_TOY',tests=result.testsRun,passed=result.wasSuccessful(),
  CPU_seconds=r.ru_utime+r.ru_stime,RSS_peak_bytes=peak,CPU_cap_seconds=30,RSS_cap_bytes=64*1024**2,
  ORF_calls=0,PTA_logL_calls=0,physical_generations=0,physical_banks=0,posteriors=0,
  existing_six_kernel_adapter_tests_repeated=0,source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest())
 (HERE/'guard_validation.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
 sys.exit(0 if result.wasSuccessful() else 1)
