"""Nominal C09 metadata only. Imports define formulas but evaluate no ORF/logL."""
from pathlib import Path
import hashlib,json,math,sys,platform
from importlib.metadata import version
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from inference.model import experiment
from inference.orf_blas import estimate

DEPENDENCIES=[
 'configs/calibration/prior_predictive_500_v1.json','tmp/c09_execution_design/config_prospectiva.json',
 'results/C07/orf_interpolation/orf_table_manifest.json','results/C07/orf_interpolation/dense_local_validation.json',
 'src/inference/__init__.py','src/inference/model.py','src/inference/likelihood_reference.py','src/inference/orf_interpolation.py',
 'src/inference/orf_cubic_reference.py','src/inference/pointwise.py','src/inference/orf_blas.py',
 'src/pta/__init__.py','src/pta/simulation.py','src/pta/statistics.py','src/pta/orf.py',
 'src/pta/response.py','src/pta/_domain.py','src/pta/validation.py',
 'tmp/c09_integrator/integrator.py','tmp/c09_contour/pchip_density.py','tmp/c09_contour/contour.py']


def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()


def beta_nodes(panels,order=8):
 x,w=np.polynomial.legendre.leggauss(order)
 edges=np.linspace(0,1,panels+1)
 beta=((edges[:-1,None]+edges[1:,None])/2+(edges[1:,None]-edges[:-1,None])*x/2).ravel()
 return np.sort(np.sqrt((1-beta)*(1+beta)))


def alpha_nodes(kind,order,edges):
 low=.001 if kind=='log_uniform_u' else 0.
 e=np.r_[low,np.array(edges)[(np.array(edges)>low)&(np.array(edges)<1)],1.]
 x,_=np.polynomial.legendre.leggauss(order);result=[]
 for a,b in zip(e[:-1],e[1:]):
  h=math.atan2(b-a,math.sqrt((1-a)*(1+a))+math.sqrt((1-b)*(1+b)))
  result.extend(np.sin(math.asin(a)+h+h*x))
 return np.asarray(result)


def make_config():
 original=json.loads((ROOT/'tmp/c09_operational_pilot/pilot_candidate.json').read_text())
 design=json.loads((ROOT/'tmp/c09_execution_design/config_prospectiva.json').read_text())
 cfg=json.loads((ROOT/'configs/calibration/prior_predictive_500_v1.json').read_text());e=experiment(cfg)
 rows=original['pilot_rows'][:14]
 for row in rows:
  eta=[-15.,13/3,-15.5,0.]
  if row['scenario']=='strong_red':eta[2]= -14.7
  if row['scenario']=='strong_white':eta[3]=math.log10(1.8)
  if row['scenario']=='gamma3':eta[1]=3.
  row['eta_physical_coordinates']=eta
  row['generation_contaminant_ratio']=1. if row['scenario']=='monopole_rho1_omitted' else 0.
  row['analysis_contaminant_ratio']=0.
  row['normal_data_kind']='full_variable_moment_matched' if '_G' in row['analysis'] else 'not_used'
 sparse=[0.,.001,.05,.1,.2,.33,.5,.71,.8,.9,.93,.99,.995,.9999,1-1e-8,1.]
 phases=2*np.pi*e['f'][:,None]*e['distance_ly'][None,:]*(365.25*86400)
 resolutions=[]
 for k,y in enumerate(phases):
  l=int(y.max()+100);n=int(2*y.max()+220)
  resolutions.append({'channel':k+1,'maximum_phase':float(y.max()),'levels':[
   {'name':'H00','lmax':l,'nmu':n},{'name':'H01','lmax':l,'nmu':n+80},{'name':'H11','lmax':l+40,'nmu':n+80}]})
 edges=design['quadrature']['u_panel_edges']
 return {'schema':'C09_NOMINAL14_EXECUTABLE_PREFLIGHT_v2','execution_enabled_by_default':False,
 'scope':'NOMINAL14_ENGINEERING_ONLY_NOT_SBC','rows':rows,'distance_rows_excluded':[14,15],
 'experiment_config':'configs/calibration/prior_predictive_500_v1.json','parent_design':'tmp/c09_execution_design/config_prospectiva.json',
 'table_file':'results/C07/orf_interpolation/orf_table_pilot12x4.npz','table_sha256':'75632dfbdd9cce8b60b9f760a3177a76798a4adb7ac9ccc724092aeaf53ad70d',
 'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':version('scipy')},
 'seeds':{'generation':909112101,'offgrid_nodes_frozen_not_random':True,'scope':'SeedSequence([909112101,scenario_id,target_id]); one independently generated dataset per row'},
 'sparse_exact_mass_nodes':sparse,'anchor_mass':.5,'harmonic_resolutions':resolutions,
 'direct_sky_cases':[{'u':.5,'channel':1,'pair':[3,8]},{'u':.995,'channel':1,'pair':[0,11]}],
 'direct_sky_resolutions':[{'nmu':resolutions[0]['levels'][0]['nmu'],'nphi':2*resolutions[0]['levels'][0]['nmu']},{'nmu':resolutions[0]['levels'][1]['nmu'],'nphi':2*resolutions[0]['levels'][1]['nmu']}],
 'quadrature':{'orders':[32,64],'panel_edges_u':edges,'positive_density':'PCHIP in alpha; Jacobian and likelihood distinct from GL weights',
 'prior_names':['uniform_u','uniform_u_squared','log_uniform_u'],'quantile_probabilities':[.05,.5,.9,.95],
 'independent_prior_cdf_cuts':[.05,.5,.9,.95],'independent_fixed_mass_cut':.2,
 'reference_coordinate':'prior CDF v','reference_epsabs_scaled':1e-9,'reference_epsrel':1e-8,'reference_subinterval_limit':150,
 'scout_u_coarse':beta_nodes(64).tolist(),'scout_u_fine':beta_nodes(128).tolist(),
 'GL_mass_nodes':{name:{str(n):alpha_nodes(name,n,edges).tolist() for n in [32,64]} for name in ['uniform_u','uniform_u_squared','log_uniform_u']}},
 'gates':{'harmonic_nodes_abs':1e-8,'harmonic_ell_abs':1e-8,'direct_refinement_abs':1e-7,'harmonic_direct_abs':1e-7,'PSD_minimum':-1e-12,
 'table_sparse_abs_logL':.001,'density_event_sparse_abs_logL':.001,'delta_logZ':.001,'delta_CDF_PIT':.002,'quantile_bracket_u':.001,'delta_moments':.001,'delta_KL':.001},
 'budgets':{'CPU_seconds_combined':600,'RSS_bytes':1610612736,'estimated_numeric_bytes':1400000000,
 'batch_size_harmonic':4,'batch_size_likelihood':32,'new_full4channel_ORF_nodes':16,
 'real_multiplications':250000000000,'direct_sky_points':80000000,'likelihood_component_values':1000000,
 'likelihood_values_per_target':60000,'output_bytes':20*1024**2,'threads':1,'new_dense_tables':False},
 'execution_stages':['backend','pilot'],'no_automatic_refinement':True,'unresolved_probability_envelope':[0,1],
 'dependencies':DEPENDENCIES,'no_physics_executed_in_preflight':True}


def preflight(config):
 e=experiment(json.loads((ROOT/config['experiment_config']).read_text()))
 P=len(e['points']);K=len(e['f']);N=len(config['sparse_exact_mass_nodes']);B=config['budgets']['batch_size_harmonic']
 basis=[];mult=0;contract=0;recurrences=0;roots=0;transfer_points=0;recurrence_mult=0
 for item in config['harmonic_resolutions']:
  for level in item['levels']:
   l,n=level['lmax'],level['nmu'];r=estimate(l,n,P,B)
   basis.append(dict(channel=item['channel'],level=level['name'],**r))
   mult+=2*N*P*n*(l-1)
   contract+=6*N*P*P*(l-1) # four for complex product, two for real geometry weighting
   transfer_points+=N*P*n
   recurrence_mult+=4*n*(l-1)+6*P*P*(l-1)
   recurrences+=n*(l-1);roots+=n*n
 max_basis=max(x['estimated_memory_bytes'] for x in basis)
 table_nodes=8336;matrix_bytes=table_nodes*K*P*P*16;coeff_bytes=4*(table_nodes-1)*K*P*P*16
 # Conservative coexistence during existing scipy CubicSpline/Bernstein constructor.
 interpolation_numeric_peak=matrix_bytes+4*coeff_bytes+32*1024**2
 backend_peak=max_basis+N*K*P*P*16*3+32*1024**2
 resident_after_construction=matrix_bytes+coeff_bytes
 likelihood_scratch=128*config['budgets']['batch_size_likelihood']*K*10*P*P+32*1024**2
 numeric_peak=max(interpolation_numeric_peak,backend_peak,resident_after_construction+likelihood_scratch)
 direct_points=len(config['direct_sky_cases'])*sum(r['nmu']*r['nphi'] for r in config['direct_sky_resolutions'])
 direct_memory=24*16*max(r['nmu'] for r in config['direct_sky_resolutions'])*128+544*max(r['nmu'] for r in config['direct_sky_resolutions'])
 assert len(config['rows'])==14 and [x['id'] for x in config['rows']]==list(range(14))
 assert set(x['fixed_truth_u'] for x in config['rows']).issubset(config['sparse_exact_mass_nodes'])
 assert config['anchor_mass'] in config['sparse_exact_mass_nodes']
 limits=config['budgets']
 versions_ok=config['versions']=={'python':platform.python_version(),'numpy':np.__version__,'scipy':version('scipy')}
 checks={'versions':versions_ok,'multiplications':mult+contract+recurrence_mult+16*transfer_points<=limits['real_multiplications'],'direct_sky_points':direct_points<=limits['direct_sky_points'],
 'estimated_numeric_memory':numeric_peak<=limits['estimated_numeric_bytes'],'RSS_headroom':numeric_peak+128*1024**2<=limits['RSS_bytes'],
 'node_count':N<=limits['new_full4channel_ORF_nodes'],'maximum_phase':max(r['maximum_phase'] for r in config['harmonic_resolutions'])<=6284}
 return {'schema':'C09_NOMINAL14_PREFLIGHT_REPORT_v2','status':'READY_FOR_ROOT_REVIEW_NO_EXECUTION' if all(checks.values()) else 'RESOURCE_PREFLIGHT_FAILED',
 'budget_checks':checks,'new_ORFs_executed':0,'PTA_logL_executed':0,'geometry_shapes':{'points':list(e['points'].shape),'H':list(e['H'].shape)},
 'geometry_sha256':{k:hashlib.sha256(np.ascontiguousarray(e[k]).tobytes()).hexdigest() for k in ['points','distance_ly','sigma','red','f','scale','H','weights']},
 'basis_estimates':basis,'BLAS_real_multiplications':mult,'contraction_real_multiplications_proxy':contract,
 'real_multiplications_total_proxy':mult+contract+recurrence_mult+16*transfer_points,'recurrence_real_multiplications_proxy':recurrence_mult,'transfer_scalar_multiplications_proxy':16*transfer_points,'transfer_points':transfer_points,'basis_recurrence_elements':recurrences,'roots_legendre_quadratic_work_proxy':roots,
 'new_full4channel_ORF_nodes':N,'total_harmonic_matrices':N*K*3,'new_direct_sky_config_points':direct_points,
 'direct_two_tensor_mode_products':2*direct_points,'direct_memory_estimated_bytes':direct_memory,
 'table_original_matrix_bytes':matrix_bytes,'table_coefficient_bytes':coeff_bytes,'interpolator_constructor_estimated_numeric_peak':interpolation_numeric_peak,
 'backend_estimated_numeric_peak':backend_peak,'estimated_peak_numeric_bytes':numeric_peak,'RSS_headroom_bytes':limits['RSS_bytes']-numeric_peak,
 'maximum_likelihood_component_values':limits['likelihood_component_values'],'minimum_initial_GL_values':sum(len(config['quadrature']['GL_mass_nodes'][r['prior']][str(n)]) for r in config['rows'] for n in [32,64]),
 'maximum_offgrid_scout_values':14*(512+1024),'estimates_are_not_CPU_or_RSS_guarantees':True,
 'execution_disabled_without_exact_hash_ROOT_approval':True,'distance_two_cases_not_authorized_or_included':True}
