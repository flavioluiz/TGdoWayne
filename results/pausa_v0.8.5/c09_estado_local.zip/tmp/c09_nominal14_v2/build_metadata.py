"""Refresh v2 metadata by stdlib arithmetic/hashes only; no physics imports."""
from pathlib import Path
import hashlib
from importlib.metadata import version
import json
import platform
import resource
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
resource.setrlimit(resource.RLIMIT_CPU,(29,30))

def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()

def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')

old=ROOT/'tmp/c09_nominal14_preflight'
c=json.loads((HERE/'config.json').read_text());v1=json.loads((old/'config.json').read_text())
assert {k:v for k,v in c.items() if k not in ('schema','dependencies')}=={k:v for k,v in v1.items() if k not in ('schema','dependencies')}
assert c['dependencies']==v1['dependencies'][:4]+['src/inference/__init__.py']+v1['dependencies'][4:]
assert (HERE/'kernels.py').read_bytes()==(old/'kernels.py').read_bytes()
versions=dict(python=platform.python_version(),numpy=version('numpy'),scipy=version('scipy'))
assert c['versions']==versions
p=json.loads((old/'executable_preflight.json').read_text())
P,K,N,B=12,4,len(c['sparse_exact_mass_nodes']),c['budgets']['batch_size_harmonic']
blas=contract=recurrence=transfer=recurrence_elements=roots=0;basis=[]
for channel in c['harmonic_resolutions']:
 for level in channel['levels']:
  l,n=level['lmax'],level['nmu'];L=l-1
  blas+=2*N*P*n*L;contract+=6*N*P*P*L;recurrence+=4*n*L+6*P*P*L
  transfer+=N*P*n;recurrence_elements+=n*L;roots+=n*n
  memory=8*n*L+8*P*P*L+64*n+16*B*P*n+96*B*n+64*B*P*L+64*B*P*P
  basis.append(dict(channel=channel['channel'],level=level['name'],basis_bytes=8*n*L,geometry_bytes=8*P*P*L,
   estimated_memory_bytes=memory,real_multiplications_per_batch=2*B*P*n*L,recurrence_elements=n*L,batch_size=B))
assert basis==p['basis_estimates']
M=8336*K*P*P*16;C=4*8335*K*P*P*16
peak=M+4*C+32*1024**2
sky=len(c['direct_sky_cases'])*sum(r['nmu']*r['nphi'] for r in c['direct_sky_resolutions'])
checks=dict(BLAS_real_multiplications=blas,contraction_real_multiplications_proxy=contract,
 recurrence_real_multiplications_proxy=recurrence,transfer_scalar_multiplications_proxy=16*transfer,
 real_multiplications_total_proxy=blas+contract+recurrence+16*transfer,transfer_points=transfer,
 basis_recurrence_elements=recurrence_elements,roots_legendre_quadratic_work_proxy=roots,
 new_full4channel_ORF_nodes=N,total_harmonic_matrices=N*K*3,new_direct_sky_config_points=sky,
 direct_two_tensor_mode_products=2*sky,table_original_matrix_bytes=M,table_coefficient_bytes=C,
 interpolator_constructor_estimated_numeric_peak=peak,estimated_peak_numeric_bytes=peak,
 minimum_initial_GL_values=sum(len(c['quadrature']['GL_mass_nodes'][r['prior']][str(n)]) for r in c['rows'] for n in [32,64]),
 maximum_offgrid_scout_values=14*(len(c['quadrature']['scout_u_coarse'])+len(c['quadrature']['scout_u_fine'])))
assert all(p[k]==v for k,v in checks.items())
assert [r['id'] for r in c['rows']]==list(range(14))
assert set(r['fixed_truth_u'] for r in c['rows'])<=set(c['sparse_exact_mass_nodes'])
assert peak<=c['budgets']['estimated_numeric_bytes'] and peak+128*1024**2<=c['budgets']['RSS_bytes']
# Hash the frozen real file as bytes only; never deserialize its arrays.
sources=c['dependencies']+[str((HERE/name).relative_to(ROOT)) for name in ('planning.py','kernels.py','run_nominal14.py')]
hashes={name:digest(ROOT/name) for name in sources}
for name in c['dependencies']:
 if name in p['source_sha256']:assert hashes[name]==p['source_sha256'][name]
table_hash=digest(ROOT/c['table_file']);assert table_hash==c['table_sha256']
for key in ('source_sha256','config_sha256','table_file_sha256'):p.pop(key)
p.update(schema='C09_NOMINAL14_PREFLIGHT_REPORT_v2',
 metadata_generation='Independent stdlib arithmetic and streamed hashes; unchanged geometry hashes inherited from source/config-identical v1 preflight; no numerical imports or table array load',
 unchanged_physics_config_verified=True,unchanged_kernel_bytes_verified=True,
 lifecycle_contract=dict(CPU_from_process_start=True,backend_CPU_source='execution_end.json.resources',
  inherited_likelihood_counts=True,maximum_combined_per_target=60000,backend_cost_per_target=32,
  maximum_pilot_remaining_per_target=59968,maximum_combined_nominal14=840000,
  final_CPU_sample_after_source_table_checks=True,final_receipt_serialization_and_process_exit_not_measured=True),
 approval_schema='ROOT_C09_NOMINAL14_APPROVAL_v2',authorization_created=False)
write(HERE/'preflight.json',p)
p.update(config_sha256=digest(HERE/'config.json'),source_sha256=hashes,table_file_sha256=table_hash)
write(HERE/'executable_preflight.json',p)
review=ROOT/'tmp/c09_nominal14_ROOT_review/review.json'
assert digest(review)=='161b9852d8270144f376357863b483de88d91810705bddd697f2f8baf926dc5e'
review_record=json.loads(review.read_text())
for name,value in review_record['source_hashes'].items():assert digest(ROOT/name)==value
usage=resource.getrusage(resource.RUSAGE_SELF);rss=usage.ru_maxrss if sys.platform=='darwin' else usage.ru_maxrss*1024
assert usage.ru_utime+usage.ru_stime<30 and rss<64*1024**2
write(HERE/'metadata_validation.json',dict(scope='STDLIB_METADATA_ONLY_NO_PHYSICS',
 CPU_seconds=usage.ru_utime+usage.ru_stime,RSS_peak_bytes=rss,CPU_cap_seconds=30,RSS_cap_bytes=64*1024**2,
 versions=versions,checks_recomputed=checks,v1_review_and_sources_unchanged=True,
 numerical_imports=False,real_table_arrays_loaded=False,ORF_calls=0,PTA_logL_calls=0,physical_generations=0))
files=[p for p in HERE.iterdir() if p.is_file() and p.name not in ('manifest.json','build_metadata.log')]
manifest=dict(schema='C09_NOMINAL14_V2_CANDIDATE_MANIFEST_v1',status='CANDIDATE_FOR_ROOT_REVIEW_NO_AUTHORIZATION',
 scope='NEW_GUARDS_AND_METADATA_ONLY_NO_PHYSICAL_EXECUTION',
 source_hashes=hashes,config_sha256=digest(HERE/'config.json'),table_sha256=table_hash,
 v1_inventory_sha256={str(p.relative_to(ROOT)):digest(p) for p in old.iterdir() if p.is_file()},
 preserved_review_inventory_sha256={str(p.relative_to(ROOT)):digest(p) for p in review.parent.iterdir() if p.is_file()},
 files={p.name:digest(p) for p in files},
 actual_ORF_calls=0,actual_PTA_logL_calls=0,actual_physical_generations=0,actual_banks=0,actual_posteriors=0,
 authorization_created=False)
write(HERE/'manifest.json',manifest)
print(json.dumps({'status':manifest['status'],'source_sha256':hashes[str((HERE/'run_nominal14.py').relative_to(ROOT))],
 'config_sha256':manifest['config_sha256'],'CPU_seconds':usage.ru_utime+usage.ru_stime,'RSS_peak_bytes':rss},indent=2))
