# C09 nominal14 v2 — alterações para revisão ROOT

Candidato separado, **sem autorização e sem execução física**. Os bytes de `tmp/c09_nominal14_preflight/` e `tmp/c09_nominal14_ROOT_review/` estão preservados e inventariados no manifest. Os kernels são idênticos ao v1; os seis testes dos adaptadores não foram repetidos.

Foram mantidos os14 IDs, cenários, nuisances, dados a gerar, seeds, massas ORF, nós GL/scouts, prioris, âncora, ordens, critérios científicos e limites:600sCPU combinados,60mil logL/alvo,1M global,1,4GB numéricos e1,5GiB RSS. A configuração só muda a versão do schema e acrescenta `src/inference/__init__.py` ao fechamento de dependências.

## Mudanças implementadas

- O raio do PIT de logL inclui o maior raio GK de razão dos dois contornos: `(E_N + abs(N/Z)*E_Z)/(Z-E_Z)`, exigindo valores finitos, erros não negativos e Z>E_Z. O relatório guarda numerador/erros e cada componente do raio. O spread já presente permanece; o intervalo conserva sua construção conservadora. Tudo continua sendo estimativa operacional, não certificado uniforme.
- `Budget` herda total e contagens por alvo do backend, com validação de inteiros, soma e chaves JSON canônicas. O backend custa32/ID, deixando59968/ID para o piloto, no máximo840000 acumuladas nos14. O relatório separa estágio e acumulado. Nenhuma avaliação real foi feita para testar contadores.
- CPU usa `time.process_time()` absoluto, incluindo imports, preflight, hashes e identidade. O piloto herda `execution_end.json.resources`, não o resultado parcial. O novo fechamento confere fontes/configuração/tabela antes da última amostra e registra custos do início/preflight, execução e fechamento separadamente. A serialização do próprio receipt e a saída do processo ocorrem depois da amostra e são explicitamente declaradas fora dela; não se afirma medição após término do processo.
- RLIMIT usa `soft=floor(600−CPU_backend_final)` em CPU absoluta do processo atual e `hard=soft+2`. Recusa menos de1s de saldo; SIGXCPU marca parada persistente para impedir continuação no alvo seguinte. A margem dura é somente guarda operacional para preservar falha, não aumento do orçamento nem garantia subsegundo.
- Travessias isoladas exatamente num scout node entram como raízes. Intervalos de igualdade e tangências observadas mantêm topologia desconhecida e PIT não resolvido. Sinais são comparados sem multiplicação, evitando perder um cruzamento por underflow do produto. A grade continua sem certificado global de topologia.
- O hash da tabela é reconferido imediatamente após o construtor e no encerramento. Fonte/configuração/tabela alteradas ou excesso de recurso no fechamento produzem receipt não concluído e falha. O piloto rejeita esse receipt.
- As referências locais de fontes apontam para `tmp/c09_nominal14_v2/`; as bibliotecas matemáticas permanecem as mesmas. Autorizações v1 não servem ao runner v2.

Uma futura autorização ROOT deve usar `ROOT_C09_NOMINAL14_APPROVAL_v2`, vinculando configuração, fontes v2, tabela e estágio. Para o piloto, deve vincular também `backend_result_sha256` e `backend_execution_end_sha256`. Nenhum arquivo de autorização ou exemplo executável foi criado aqui.

## Verificação feita

`test_v2_guards.py` extrai por AST apenas funções novas/alteradas, usa biblioteca padrão e fixtures TOY. Os14 testes cobrem a herança de32/ID, erros de contagem, CPU desde início e saldo absoluto, parada persistente, receipt final, propagação GK no gate real com referência sem warnings, igualdades/tangências/platôs, fechamento de fontes v2, alteração da tabela na carga/final e excesso de CPU durante fechamento. Também verificam preservação da configuração científica e dos bytes do kernel. O teste de carga substitui inteiramente o loader e módulos científicos; nenhum NPZ real é deserializado.

A suíte passou em **0,365951sCPU**, com **36.749.312 bytes RSS**, abaixo de30s/64MiB. `guard_validation.json` e `test_v2_guards.log` registram resultados. Nenhuma ORF, logL PTA, geração física, banco ou posterior foi calculado.

`build_metadata.py` produz novos preflights/manifest por aritmética inteira, versões e hashes em streaming, sem importar NumPy/SciPy nem construir geometria ou tabela. As contagens coincidem com o v1. Os hashes de geometria são herdados explicitamente do preflight anterior, após verificar identidade da configuração física e fontes comuns. O hash do arquivo de tabela é reconferido como bytes; seus arrays não são carregados. Pico estimado preservado:1.339.424.768 bytes, sem garantia de RSS. Os recursos desse preparo ficam em `metadata_validation.json`.

Reprodução dos guards: `.venv/bin/python -B tmp/c09_nominal14_v2/test_v2_guards.py`. Atualização de metadados: `.venv/bin/python -B tmp/c09_nominal14_v2/build_metadata.py`. O runner permanece candidato à revisão; seu fluxo físico não foi testado end-to-end nem autorizado.
