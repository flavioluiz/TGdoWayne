"""Synthetic-only process wrapper. Default is metadata; never runs PTA code."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
CAPS=dict(cpu_seconds=60,rss_bytes=536870912,wall_seconds=90,
          blas_threads=1,PTA_LL=0,ORF=0,real_data_draws=0,PTA_files_decoded=0)

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,value):
    with p.open('x')as f:json.dump(value,f,indent=2);f.write('\n')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['preflight','toys'])
    parser.add_argument('--output',default='toy_attempt1');args=parser.parse_args()
    sources={p.name:digest(p)for p in sorted(HERE.glob('*.py'))}
    preflight=dict(schema='C09_D2_SYNTHETIC_ONLY_v1',caps=CAPS,sources=sources,
                   scientific_execution_enabled=False)
    if args.mode=='preflight':print(json.dumps(preflight,indent=2));return
    out=Path(args.output)
    if not out.is_absolute():out=HERE/out
    out.mkdir(parents=True,exist_ok=False)
    save(out/'preflight.json',preflight)
    env=dict(os.environ,VECLIB_MAXIMUM_THREADS='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
    def limits():resource.setrlimit(resource.RLIMIT_CPU,(CAPS['cpu_seconds'],CAPS['cpu_seconds']+2))
    with (out/'test.log').open('x')as log:
        process=subprocess.Popen([sys.executable,str(HERE/'test_components.py'),'-v'],cwd=HERE,
                                 stdout=log,stderr=subprocess.STDOUT,env=env,preexec_fn=limits)
        try:status=process.wait(timeout=CAPS['wall_seconds'])
        except subprocess.TimeoutExpired:
            process.kill();process.wait();status=-999
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    cpu=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
    rss=int(after.ru_maxrss if sys.platform=='darwin' else after.ru_maxrss*1024)
    unchanged=all(digest(HERE/p)==sha for p,sha in sources.items())
    result=dict(schema='C09_D2_SYNTHETIC_VALIDATION_v1',exit_code=status,
                status='PASS' if status==0 and cpu<=CAPS['cpu_seconds'] and rss<=CAPS['rss_bytes'] and unchanged else 'FAILED',
                child_CPU_seconds=cpu,child_peak_RSS_bytes=rss,wall_seconds=time.monotonic()-start,
                source_unchanged=unchanged,preflight_sha256=digest(out/'preflight.json'),
                log_sha256=digest(out/'test.log'),scientific_work={k:0 for k in ['PTA_LL','ORF','bank','real_draws','PTA_files_decoded']})
    save(out/'validation.json',result);print(json.dumps(result,indent=2))

if __name__=='__main__':main()
