"""Shared-factorization normalized likelihoods; synthetic-tested, no PTA input IO.

One covariance per parameter/frequency can serve many observations. The value
count remains parameter_points × observations × model_curves; a factorization
reuse is not a reduction of that scientific count.
"""
from dataclasses import dataclass
import math
import numpy as np

@dataclass(frozen=True)
class Work:
    parameter_points:int
    independent_blocks:int
    observations:int
    normalized_log_likelihood_values:int
    covariance_factorizations:int
    def __post_init__(self):
        fields=(self.parameter_points,self.independent_blocks,self.observations,
                self.normalized_log_likelihood_values,self.covariance_factorizations)
        if any(type(x)is not int or x<1 for x in fields):raise ValueError('positive exact work counts required')
        if (self.normalized_log_likelihood_values!=self.parameter_points*self.observations or
            self.covariance_factorizations!=self.parameter_points*self.independent_blocks):
            raise ValueError('work products must include every point, block and observation')


def _matrices(c,*,complex_allowed):
    c=np.asarray(c)
    if (c.ndim!=4 or c.shape[-1]!=c.shape[-2] or min(c.shape)<1
            or c.dtype.kind not in ('fc' if complex_allowed else 'f') or not np.isfinite(c).all()):
        raise ValueError('finite float/complex (points,blocks,dimension,dimension) matrices required')
    # Every block uses its own scale. An absolute tolerance would accept a
    # grossly asymmetric covariance after a harmless change of physical units.
    scale=np.max(abs(c),axis=(-1,-2))
    error=np.max(abs(c-c.swapaxes(-1,-2).conj()),axis=(-1,-2))
    tiny=np.finfo(c.real.dtype).tiny
    if np.any(error>1e-12*np.maximum(scale,tiny)):raise ValueError('Hermitian covariance required at its own scale')
    return c


def estimated_batch_numeric_bytes(points,blocks,dimension,observations,*,complex_cn):
    """Conservative array sum, not a guarantee on process RSS or LAPACK memory.

    Includes inputs, factor, validation buffers, RHS materialization, solution,
    quadratic temporary and outputs. Real kernels also include their mean.
    Caller must add response tables, cache, interpreter and allocator headroom.
    """
    if any(type(x)is not int or x<1 for x in (points,blocks,dimension,observations))or type(complex_cn)is not bool:
        raise ValueError('positive exact dimensions and Boolean kernel family required')
    n,k,d,b=points,blocks,dimension,observations;item=16 if complex_cn else 8
    matrices=n*k*d*d;rhs=n*k*d*b
    parts=dict(covariance=matrices*item,observation=b*k*d*item,
               factor=matrices*item,hermiticity_difference=matrices*item,
               hermiticity_absolute=matrices*8,rhs_materialized=rhs*item,
               whitened=rhs*item,quadratic_temporary=rhs*8,
               mean=0 if complex_cn else n*k*d*8,outputs=n*b*8+n*k*d*8)
    return dict(estimated_array_bytes=sum(parts.values()),parts=parts,
                scope='array_upper_scenario_not_RSS_guarantee')


def cn_logpdf(covariance,observations,*,reserve):
    c=_matrices(covariance,complex_allowed=True);q=np.asarray(observations)
    n,k,p,_=c.shape
    if q.ndim!=3 or q.shape[1:]!=(k,p) or len(q)<1 or q.dtype.kind not in 'fc' or not np.isfinite(q).all():raise ValueError('observations shape(N,K,P)')
    work=Work(n,k,len(q),n*len(q),n*k)
    reserve(work)  # The caller names every data/curve ID and charges BEFORE factorization/scoring.
    L=np.linalg.cholesky(c)
    rhs=np.broadcast_to(q.transpose(1,2,0)[None],(n,k,p,len(q)))
    whitened=np.linalg.solve(L,rhs)
    chi=np.sum(abs(whitened)**2,axis=(1,2))
    logdet=2*np.sum(np.log(np.diagonal(L,axis1=-2,axis2=-1).real),axis=(1,2))
    values=-k*p*math.log(math.pi)-logdet[:,None]-chi
    if not np.isfinite(values).all():raise ArithmeticError('nonfinite normalized complex logpdf')
    return values,work


def normal_logpdf(mean,covariance,observations,*,reserve):
    c=_matrices(covariance,complex_allowed=False);mu=np.asarray(mean);y=np.asarray(observations)
    n,k,d,_=c.shape
    if (mu.shape!=(n,k,d) or mu.dtype.kind!='f' or not np.isfinite(mu).all()
            or y.ndim!=3 or y.shape[1:]!=(k,d) or len(y)<1 or y.dtype.kind!='f' or not np.isfinite(y).all()):
        raise ValueError('real finite mean(points,K,D) and observations(N,K,D) required')
    work=Work(n,k,len(y),n*len(y),n*k);reserve(work)
    L=np.linalg.cholesky(c)
    rhs=y.transpose(1,2,0)[None]-mu[...,None]
    whitened=np.linalg.solve(L,rhs)
    chi=np.sum(whitened*whitened,axis=(1,2))
    logdet=2*np.sum(np.log(np.diagonal(L,axis1=-2,axis2=-1)),axis=(1,2))
    values=-.5*(k*d*math.log(2*math.pi)+logdet[:,None]+chi)
    if not np.isfinite(values).all():raise ArithmeticError('nonfinite normalized normal logpdf')
    return values,work


class NamedLedger:
    """Per (data,curve) counts plus per-data totals, with one shared global cap."""
    def __init__(self,*,global_cap,per_curve_cap,per_data_cap):
        if any(type(v)is not int or v<1 for v in (global_cap,per_curve_cap,per_data_cap)):raise ValueError('positive exact caps required')
        self.caps=(global_cap,per_curve_cap,per_data_cap);self.total=0;self.by_curve={};self.by_data={}
    def reserve(self,work,targets):
        if not isinstance(work,Work):raise ValueError('validated Work required')
        if any(not isinstance(t,tuple) or len(t)!=2 or any(not isinstance(x,str)or not x for x in t)for t in targets):raise ValueError('explicit stable string data/curve IDs required')
        if len(targets)!=work.observations or len(set(targets))!=len(targets):raise ValueError('one unique (data_id,curve_id) for each observation')
        next_curve=dict(self.by_curve);next_data=dict(self.by_data)
        for data,curve in targets:
            key=(data,curve);next_curve[key]=next_curve.get(key,0)+work.parameter_points
            next_data[data]=next_data.get(data,0)+work.parameter_points
        total=self.total+work.normalized_log_likelihood_values
        if total>self.caps[0] or max(next_curve.values())>self.caps[1] or max(next_data.values())>self.caps[2]:raise RuntimeError('global/curve/data budget before likelihood')
        self.total,self.by_curve,self.by_data=total,next_curve,next_data
