# D2: componentes prospectivos de robustez condicional

Este pacote prepara D2; não executa novas likelihoods PTA, respostas, bancos,
draws ou leituras de arrays científicos. A decisão ROOT
`tmp/c09_ROOT/DECISAO_AVANCO_FUNCIONAL.md` autoriza o desenho de gates próprios
por quantidade. O orçamento e a execução física de D2 continuam sujeitos a uma
configuração de execução separada e à revisão ROOT. C09 não está concluído.

O estado histórico é conservado: o nominal14 teve treze eventos logL não
resolvidos. D1 resolveu nove eventos da tabela e D1b resolveu quatro dos cinco
restantes; ID10 conservou massa ambígua após 2.399 subdivisões. Todos os
intervalos físicos de evento logL dessas etapas continuam [0,1], pois não foi
estabelecida uma margem probabilística do backend. Isso não reclassifica as
CDFs antigas nem impede novos controles específicos de CDF e métricas.

## Oito funções novas e observações compartilhadas

Os IDs identificam linhas do mesmo arquivo nominal14. Não serão geradas novas
observações. Linhas distintas do nominal14 foram simuladas com sementes
independentes; o pareamento deste desenho existe somente quando o ID do dado é
igual.

| Dado | Função nova | Controle mantido no mesmo dado |
|---|---|---|
| 7, `x_gaussian` | B_G completa/variável | B_G diagonal/variável histórica |
| 7, `x_gaussian` | B_G completa/fixa | Nova completa/variável |
| 7, `x_gaussian` | B_G diagonal/fixa | Diagonal/variável histórica |
| 6, `x_physical` | B_CN diagonal/variável | B_CN completa/variável histórica |
| 6, `x_physical` | B_CN completa/fixa | Completa/variável histórica |
| 6, `x_physical` | B_CN diagonal/fixa | Nova diagonal/variável |
| 13, `x_physical` | B_CN completa/variável, monopolo conhecido incluído | Mesma observação, monopolo omitido histórico |
| 7, `x_gaussian` | A_G, quatro blocos de frequência | Nova B_G completa/variável, compressão do mesmo Y |

A oitava função é um controle de compressão explicitamente acrescentado à
seleção e aceito por ROOT. As seis variantes B usam o determinante completo de
sua própria covariância, média sempre variável e âncora fixa u=0,5. Fixar é
substituir somente a covariância; diagonalizar é conservar somente sua diagonal.
O antigo `ConditionalKernel` não implementa as três variantes novas B_CN: seu
uso direto não satisfaria este desenho. `factorial.py` implementa a operação
comum às duas famílias; `normal_logpdf` aplica a densidade normal normalizada a
ambas. Aplicá-la ao B físico CN continua sendo aproximação distribucional.

O monopolo tem razão de potência conhecida ρ=1 e o espectro já especificado no
nominal14. Será incluído na covariância do sinal antes do cálculo dos momentos,
conservando dado, nuisances e massa. Nenhum ajuste de ρ está previsto.

São previstas cinco funções existentes para reutilização: A0 dos dados 2 e 3,
B_CN completa/variável do dado 6, B_G diagonal/variável do dado 7 e B_CN com
monopolo omitido do dado 13. Há, portanto, **13 funções de likelihood**, e não
oito funções incluindo todos os controles.

## Prioris, suporte e reponderação

Nos mesmos dados 2, 3 e 6 serão analisadas dez medidas: uniforme em u e
uniforme em u², ambas em [0,1] e [0,0,8]; e uniforme em log u com a=10⁻⁴,
10⁻³ ou 10⁻² e b=1 ou 0,8. As oito funções novas e os dois outros controles
recebem inicialmente a priori uniforme em [0,1]. São **40 análises de posterior
condicional**, compartilhando as treze funções quando apropriado.

`priors.py` usa explicitamente 0≤a<b≤1. Densidades, CDFs, inversas e momentos
são normalizados no suporte de cada análise; a transformação alpha=asin(u)
termina em asin(b). Não há chamada ao motor antigo supondo upper=1. Uma
representação em outra coordenada preserva a medida apenas incluindo o
Jacobiano; escolher uma densidade uniforme nessa coordenada é outra hipótese.

O cache armazena logL, que independe da priori. Sua reutilização exige igualdade
da função, dado, nuisances, resposta e unidades, além de SHA e valores float64
efetivamente presentes. A identidade de reponderação de Z só cobre regiões em
que a priori antiga tem suporte. O antigo ID3 usava a=0,001: análises com massa
abaixo desse corte requerem avaliações adicionais nessa região. Não se inventa
crédito de cache para esses valores. Tampouco se promove uma amostra gerada sob
uma priori a SBC de outra medida.

A verdade do dado 6 é u=0,995. Nas análises com b=0,8, a observação é mantida,
mas recebe `truth_outside_support`; não se apresenta F(u_true)=1 como PIT
matched de uma campanha de calibração.

## Integração e gates por quantidade

`PosteriorTable` interpola os logL fornecidos em alpha, usando PCHIP. Sua
integração positiva por célula inclui a medida correta, separa escalonamento
logarítmico e evita a extrapolação do suporte. Dois níveis de nós e GL16/32
avaliam erros de representação e quadratura. Esse componente, isoladamente,
integra a tabela fornecida: não aprova uma resposta física.

`integrate_reference_bundle` fornece referência direta para cada Z, numerador
de CDF, primeiro/segundo momento e expectativa de logL. Usa GK21 vetorial em
alpha; todos os cortes de suporte e indicadores são quebras explícitas. Uma
única avaliação da mesma logL pode multiplicar várias prioris, mas cada uma
mantém seus próprios numeradores e denominador. O erro em norma máxima de cada
painel não é dividido pelo número de componentes. São estimativas operacionais
de quadratura, sem arredondamento dirigido ou certificado uniforme.

Os cortes independentes são quantis prévios .05/.5/.9/.95, u=.2 quando interior,
verdade quando pertencente ao suporte e endpoints dos quatro brackets de
quantis. Estes serão escolhidos dos níveis tabulados antes de consultar a
referência direta e gravados com identidade. Cada candidato tem semilargura
.00049; exige concordância dos dois níveis e
`F_ref(lo)+r(lo) ≤ q ≤ F_ref(hi)-r(hi)`, com largura≤.001. Uma ausência de
crossing suficiente conserva UNRESOLVED; não extrapola nem troca a verdade.

Cada função relatada conserva seu gate: ΔlogZ≤.001, ΔCDF≤.002, brackets≤.001 em
u, Δmédia/segundo momento/KL/W1≤.001. Numerador e denominador são controlados
separadamente. O erro de KL soma o erro da expectativa de logL ao de logZ.
Warnings, valores não finitos ou fatorações inválidas impedem aprovação.

W1 possui funções próprias que integram |F1−F2| em du na união dos suportes;
GL12/24 controla essa integral da tabela. A validação direta do funcional W1
ainda precisa de consumidor/controle próprio no wrapper físico. Enquanto não
existir, seu gate físico fica UNRESOLVED, mesmo que os quantis tenham passado.
Isso é uma pendência do candidato, e não uma autorização para remover W1 do
roadmap. Não se usa uma grade finita de CDF como prova do supremo contínuo.

No futuro wrapper, controles contra as 16 respostas harmônicas já disponíveis
deverão avaliar **as novas funções**, não copiar o gate de uma likelihood
anterior. As novas avaliações e referências SciPy consomem o mesmo orçamento.
A combinação de gates funcionais e evidência física finita, aceita no domínio
declarado, permite resultados operacionais qualificados. Não se exige uma prova
uniforme global da ORF e não se converte o máximo observado de ΔlogL em bound
de probabilidade. Os componentes puros não emitem essa decisão de backend.
O evento logL e as limitações históricas permanecem separados.

## Comparações e alcance

Os contrastes têm direção operação nova menos controle anterior, no mesmo dado.
Os dois fatoriais permitirão medir efeito de diagonalizar, efeito de fixar e
interação entre operações. A comparação de compressão é B_G completa/variável
menos A_G no dado 7. A comparação do contaminante é incluído menos omitido no
dado 13. Prioris alternativas são contrastadas com uniforme em [0,1] no próprio
dado, sem misturar IDs2/3.

Quantis, larguras, momentos, KL(post||prior), W1 e logZ são produtos distintos.
Comparações de evidência de hipóteses são restritas ao mesmo espaço de
observações e unidades: logZ de A_G40 e B_G10 não define um fator de Bayes entre
as duas estatísticas. Posteriores próximas do quantil prévio não provam ausência
de informação. Não existe direção universal de ganho ao diagonalizar.

São experimentos condicionais de nuisances conhecidas, T=4,5 anos, doze pulsars
e quatro canais Fourier positivos idealizados; pesos de frequência .25. As
prioris/suportes em u correspondem à escala física m_gc²=u h/T. Não se alega
TOA irregular, reanálise MeerKAT ou validação das marginais 5D.

## Custos prospectivos, não autorização

O teto proposto de 200.000 novos valores inclui tudo: oito funções novas com
22.500 cada (180.000), mais 20.000 misses auxiliares das cinco funções antigas.
Estas reservam 5.000 para cada uma de2/3/6 e 2.500 para7/13. As reservas por
dado são: 5.000,5.000,72.500,92.500 e25.000, respectivamente. A soma é200.000.
Suportes, âncoras, controles de backend, SciPy, referências de numeradores e
tentativas que falhem usam essas mesmas reservas. Nenhuma troca de curva, dado,
priori ou nome de arquivo reinicia os contadores.

`batch_likelihood.py` fatora cada matriz por ponto/frequência uma vez e resolve
vários RHS. A contagem científica continua N_pontos×N_observações para cada
função. Um lote de32 pontos,4 frequências e32 observações de12 componentes CN
fatora128 matrizes, mas fornece1.024 likelihoods, não32. A estimativa de arrays
inclui entradas, fator, validação, RHS, solução, temporários quadráticos e
saídas; tabela, cache, interpretador e retenção do alocador pertencem ao RSS do
wrapper, que precisa de seu supervisor independente.

O cenário de CPU proposto é180 s, parede360 s, um worker/BLAS1, numérico1,4 GB,
RSS1,5 GiB e16 MiB de saída. Não foi medido em dados D2: a taxa histórica de D1
projeta aproximadamente94 s para200 mil valores e deixa cerca de86 s para
setup/integração. Essa projeção não é garantia e não amplia os caps D1/D1b.
O ledger da nova etapa deve carregar custos históricos separadamente, sem
reembolso, e obter aprovação ROOT própria. Nenhuma quadratura de céu, nova ORF,
tabela densa ou draw está incluído.

Antes de qualquer execução faltam o worker físico, importação validada dos
caches por identidade, ledger canônico com caps heterogêneos, supervisor,
controle próprio de W1 e aprovação das fontes/configuração/recursos exatos.
Falhas devem preservar valores cobrados e resultados parciais; não há retry ou
refinamento automático. A referência direta pode exceder sua reserva: nesse
caso o produto fica pendente, sem deslocar verba ou critério silenciosamente.

## Verificação realizada

`toy_attempt4/validation.json` registra13 testes sintéticos aprovados,
0,533938 s CPU e113.082.368 B RSS. O preflight de cada tentativa foi salvo antes
de testar; cap CPU60 s, RSS512 MiB verificado ao final e parede90 s. O runner é
somente sintético; não substitui o supervisor físico. Os dois primeiros ensaios
falhos e suas fontes exatas estão preservados. Eles identificaram slices do
último tile, precisão da PPF logarítmica estreita e resolução insuficiente de
referências TOY; não houve relaxamento de tolerâncias. A revisão apontou ainda
tile inválido em W1, erro de KL incompleto e tolerância absoluta de
Hermiticidade: corrigidos com controles negativos e reescala1e−30.

As referências independentes incluem integrais e quantis analíticos de priori,
posterior exponencial, W1 de densidade proporcional a u, quadratura SciPy direta
em u, e equivalência CN complexa com uma normal real de dimensão dobrada. Os
testes não validam os futuros resultados físicos nem o custo da campanha.

Depois deste candidato, D3 mantém18 grupos×500 e a família126/Holmα=.05,
incluindo slots de logL que continuarem pendentes; 120 milhões de likelihoods
permanece um teto prospectivo. D2 não autoriza essa campanha nem a redução de
grupos, critérios ou IDs não resolvidos.
