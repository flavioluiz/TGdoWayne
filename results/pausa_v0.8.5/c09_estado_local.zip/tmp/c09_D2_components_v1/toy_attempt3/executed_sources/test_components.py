"""Bounded synthetic checks. No PTA file, ORF, physical LL, bank or draw."""
import math
import unittest
import numpy as np
from scipy.integrate import quad
from scipy.stats import multivariate_normal
from priors import PriorMeasure,integration_rule
from posterior_table import PosteriorTable,wasserstein_to_prior,wasserstein_between
from functional_reference import integrate_reference_bundle,ratio_interval,conservative_quantile_gate
from batch_likelihood import cn_logpdf,normal_logpdf,NamedLedger,Work
from factorial import compressed_moments,factorial_moments,compress_observations


class MeasureTests(unittest.TestCase):
    def test_three_measures_all_supports_and_jacobians(self):
        for a,b in [(0.,1.),(0.,.8),(.1,.8),(.01,.0101)]:
            for kind in ('uniform_u','uniform_u_squared','log_uniform_u'):
                if a==0 and kind=='log_uniform_u':continue
                p=PriorMeasure(kind,a,b);v=np.linspace(0,1,31)
                np.testing.assert_allclose(p.cdf(p.ppf(v)),v,atol=3e-14,rtol=2e-13)
                analytic=p.moments()
                for coordinate in ('alpha','prior_cdf'):
                    # p(v) uniform for the uniform-u² prior, but its moment
                    # sqrt(v) has an endpoint derivative singularity. Explicit
                    # geometric u panels resolve that quadrature problem.
                    u,lw=integration_rule(p,96,coordinate=coordinate,panel_edges=(.001,.01,.1,.5,.8,.99))
                    w=np.exp(lw)
                    self.assertAlmostEqual(float(sum(w)),1.,places=11)
                    np.testing.assert_allclose([sum(w*u),sum(w*u*u)],[analytic['mean'],analytic['second']],atol=2e-11,rtol=2e-11)
                # An independent SciPy adaptive integral in u.
                z,err=quad(lambda u:math.exp(float(p.logpdf(u))),a,b,epsabs=1e-12,epsrel=1e-12)
                self.assertLess(abs(z-1),max(2e-11,10*err))

    def test_constant_likelihood_is_prior_on_truncated_support(self):
        u=np.linspace(0,1,41)
        for p in [PriorMeasure('uniform_u',0,.8),PriorMeasure('uniform_u_squared',.2,.8),PriorMeasure('log_uniform_u',1e-4,.8)]:
            # Add geometric knots to resolve log-prior measure near its cutoff.
            nodes=np.unique(np.r_[u,np.geomspace(p.lower or 1e-5,.8,70)])
            t=PosteriorTable(nodes,np.full(len(nodes),-31.25),p,order=32)
            self.assertAlmostEqual(t.logZ,-31.25,places=10)
            self.assertLess(abs(t.kl_to_prior),1e-10)
            cuts=np.linspace(p.lower,p.upper,31)
            np.testing.assert_allclose(t.cdf(cuts),p.cdf(cuts),atol=2e-11)
            for prob in (.05,.5,.95):
                lo,hi=t.candidate_quantile_bracket(prob)
                self.assertLessEqual(lo,float(p.ppf(prob)))
                self.assertGreaterEqual(hi,float(p.ppf(prob)))
            self.assertLess(wasserstein_to_prior(t,order=16),1e-10)

    def test_endpoint_and_invalid_supports(self):
        p=PriorMeasure('uniform_u',0,1)
        self.assertEqual(float(p.alpha_logpdf(math.pi/2)),-math.inf)
        p=PriorMeasure('uniform_u',0,.8)
        self.assertAlmostEqual(math.exp(float(p.alpha_logpdf(math.asin(.8)))),.6/.8)
        self.assertFalse(p.contains_truth(.995))
        for args in [('uniform_u',0,0),('log_uniform_u',0,1),('uniform_u',-.1,.8),('x',0,1),('uniform_u',True,1)]:
            with self.assertRaises(ValueError):PriorMeasure(*args)
        self.assertTrue(PriorMeasure('uniform_u',.1,.8).reweighting_support_is_covered_by(p))
        self.assertFalse(PriorMeasure('uniform_u',0,1).reweighting_support_is_covered_by(p))

    def test_support_change_is_not_coordinate_change(self):
        uniform=PriorMeasure('uniform_u',0,.8);square=PriorMeasure('uniform_u_squared',0,.8)
        self.assertAlmostEqual(float(uniform.ppf(.95)),.76)
        self.assertAlmostEqual(float(square.ppf(.95)),.8*math.sqrt(.95))
        # Same uniform-u measure in v=u² has Jacobian 1/(2 b sqrt(v)).
        z,_=quad(lambda v:1/(2*.8*math.sqrt(v)),0,.64,epsabs=1e-12)
        self.assertAlmostEqual(z,1.,places=12)


class FunctionalTests(unittest.TestCase):
    def test_exponential_posterior_both_representations(self):
        p=PriorMeasure('uniform_u',.1,.8);u=np.linspace(0,1,257)
        ell=3*u-8
        t=PosteriorTable(u,ell,p,order=16);fine=PosteriorTable(u,ell,p,order=32)
        cuts=[.1,.2,.5,.7,.8]
        ref=integrate_reference_bundle(lambda x:3*x-8,[p],[cuts],shift=-5.6)['results'][0]
        z=(math.exp(2.4)-math.exp(.3))/(3*.7)
        self.assertLess(abs(t.logZ-(-8+math.log(z))),2e-7)
        self.assertLess(abs(t.logZ-fine.logZ),1e-11)
        self.assertLess(abs(t.logZ-ref['logZ']),2e-7)
        analytic=(np.exp(3*np.array(cuts))-math.exp(.3))/(math.exp(2.4)-math.exp(.3))
        np.testing.assert_allclose(t.cdf(cuts),analytic,atol=2e-7)
        np.testing.assert_allclose(ref['cdf'],analytic,atol=2e-12)
        for prob in (.05,.5,.95):
            lo,hi=t.candidate_quantile_bracket(prob)
            qr=integrate_reference_bundle(lambda x:3*x-8,[p],[[lo,hi]],shift=-5.6)['results'][0]
            self.assertTrue(conservative_quantile_gate(prob,lo,hi,*qr['cdf_intervals']))

    def test_shared_prior_bundle_same_data_distinct_normalizers(self):
        priors=[PriorMeasure('uniform_u',0,.8),PriorMeasure('uniform_u_squared',0,1),PriorMeasure('log_uniform_u',.01,.8)]
        calls=[]
        def ll(u):calls.extend(u.tolist());return np.log1p(u)
        r=integrate_reference_bundle(ll,priors,[[.2,.5],[.2,.5],[.2,.5]],shift=math.log(2))
        self.assertEqual(r['callback_queries'],len(calls))
        self.assertEqual(r['callback_queries'],sum(x['neval'] for x in r['panels']))
        self.assertIsNone(r['physical_probability_certificate'])
        for p,item in zip(priors,r['results']):
            expected=1+p.moments()['mean']
            self.assertAlmostEqual(item['logZ'],math.log(expected),places=10)
            for cut,cdf in zip(item['cut_values'],item['cdf']):
                n,_=quad(lambda u:(1+u)*math.exp(float(p.logpdf(u))),p.lower,cut,epsabs=1e-11)
                self.assertAlmostEqual(cdf,n/expected,places=10)

    def test_w1_and_kl_have_independent_quantities(self):
        # Exact beta(2,1) posterior under uniform measure: L=2u; u>0.
        p=PriorMeasure('uniform_u',.001,1)
        nodes=np.unique(np.r_[np.geomspace(.001,.1,101),np.sin(np.linspace(math.asin(.1),math.pi/2,401))])
        t=PosteriorTable(nodes,np.log(2*nodes),p,order=24)
        zero=PosteriorTable(nodes,np.zeros(len(nodes)),p,order=24)
        w12=wasserstein_between(t,zero,order=12);w24=wasserstein_between(t,zero,order=24)
        expected,_=quad(lambda u:abs((u*u-p.lower**2)/(1-p.lower**2)-(u-p.lower)/(1-p.lower)),p.lower,1,epsabs=1e-12)
        self.assertLess(abs(w12-w24),1e-10)
        self.assertLess(abs(w24-expected),2e-7)
        self.assertGreater(t.kl_to_prior,.19)
        self.assertLess(abs(wasserstein_to_prior(t,order=24)-w24),1e-10)

    def test_reference_warnings_invalid_errors_and_non_crossing(self):
        with self.assertRaises(ArithmeticError):ratio_interval(.5,.01,.1,.2)
        self.assertFalse(conservative_quantile_gate(.5,.3,.3009,(.499,.501),(.5,.502)))
        with self.assertRaises(ArithmeticError):
            integrate_reference_bundle(lambda u:np.full(len(u),math.inf),[PriorMeasure('uniform_u',0,1)],[[.5]],shift=0)


class BatchTests(unittest.TestCase):
    def setUp(self):self.rng=np.random.default_rng(909120201)
    def test_cn_multiple_rhs_against_real_normal(self):
        n,k,p,b=5,4,3,8
        a=self.rng.normal(size=(n,k,p,p))+1j*self.rng.normal(size=(n,k,p,p))
        c=a@a.swapaxes(-1,-2).conj()+np.eye(p)
        q=self.rng.normal(size=(b,k,p))+1j*self.rng.normal(size=(b,k,p))
        ledger=NamedLedger(global_cap=n*b,per_curve_cap=n,per_data_cap=n)
        targets=[(f'd{i}','A0')for i in range(b)]
        values,work=cn_logpdf(c,q,reserve=lambda w:ledger.reserve(w,targets))
        self.assertEqual(work.covariance_factorizations,n*k)
        self.assertEqual(ledger.total,n*b)
        for i in range(n):
            for j in range(b):
                expected=0
                for f in range(k):
                    real=.5*np.block([[c[i,f].real,-c[i,f].imag],[c[i,f].imag,c[i,f].real]])
                    expected+=multivariate_normal.logpdf(np.r_[q[j,f].real,q[j,f].imag],cov=real)
                self.assertAlmostEqual(values[i,j],expected,places=11)

    def test_real_normal_full_determinant_and_replication(self):
        n,k,d,b=3,4,4,4
        a=self.rng.normal(size=(n,k,d,d));c=a@a.swapaxes(-1,-2)+np.eye(d)
        mu=self.rng.normal(size=(n,k,d));y=self.rng.normal(size=(b,k,d))
        calls=[];values,work=normal_logpdf(mu,c,y,reserve=calls.append)
        self.assertEqual(work.normalized_log_likelihood_values,n*b)
        for i in range(n):
            for j in range(b):
                expected=sum(multivariate_normal.logpdf(y[j,f],mean=mu[i,f],cov=c[i,f])for f in range(k))
                self.assertAlmostEqual(values[i,j],expected,places=11)
        one,_=normal_logpdf(mu,c,y[:1],reserve=lambda w:None)
        np.testing.assert_allclose(one[:,0],values[:,0],atol=1e-13)

    def test_budget_no_reset_on_curve_data_or_failure(self):
        ledger=NamedLedger(global_cap=12,per_curve_cap=6,per_data_cap=9)
        ledger.reserve(Work(3,4,2,6,12),[('d7','full'),('d7','diag')])
        self.assertEqual(ledger.by_data['d7'],6)
        ledger.reserve(Work(3,4,1,3,12),[('d7','full')])
        before=(ledger.total,dict(ledger.by_data),dict(ledger.by_curve))
        with self.assertRaises(RuntimeError):ledger.reserve(Work(1,4,1,1,4),[('d7','newname')])
        self.assertEqual(before,(ledger.total,ledger.by_data,ledger.by_curve))
        c=np.zeros((1,1,2,2),float)
        def reserve(w):ledger.reserve(w,[('d8','bad_spd')])
        with self.assertRaises(np.linalg.LinAlgError):normal_logpdf(np.zeros((1,1,2)),c,np.zeros((1,1,2)),reserve=reserve)
        self.assertEqual(ledger.total,10)  # failed work remains charged
        with self.assertRaises(ValueError):Work(4,4,2,4,16)

    def test_factorial_same_observation_mean_variable_and_weight_squared(self):
        n,k,d=3,4,2;w=np.array([.1,.2,.3,.4])
        mu=np.arange(n*k*d,dtype=float).reshape(n,k,d)/10
        a=self.rng.normal(size=(n,k,d,d));s=a@a.swapaxes(-1,-2)+np.eye(d)
        cm,cs=compressed_moments(mu,s,w)
        np.testing.assert_allclose(cm,sum(w[i]*mu[:,i]for i in range(k)))
        np.testing.assert_allclose(cs,sum(w[i]**2*s[:,i]for i in range(k)))
        anchor=cs[1]
        for fixed in (False,True):
            for diagonal in (False,True):
                m,c=factorial_moments(mu,s,w,diagonal=diagonal,fixed=fixed,anchor_covariance=anchor)
                np.testing.assert_array_equal(m[:,0],cm)
                self.assertFalse(np.array_equal(m[0],m[1]))
                for i in range(n):
                    expected=anchor if fixed else cs[i]
                    if diagonal:expected=np.diag(np.diag(expected))
                    np.testing.assert_array_equal(c[i,0],expected)
        y=self.rng.normal(size=(5,k,d))
        np.testing.assert_allclose(compress_observations(y,w)[:,0],sum(w[f]*y[:,f]for f in range(k)))


if __name__=='__main__':unittest.main()
