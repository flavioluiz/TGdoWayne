"""Freeze metadata snapshots after a concurrent editorial-draft change.

Preserves config v1 and its failed live-path check. No numerical imports/NPZ IO.
"""
import hashlib
import json
from pathlib import Path
import time
import resource

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,value):
    with p.open('x')as f:json.dump(value,f,indent=2);f.write('\n')

def main():
    start=time.process_time();old=HERE/'config_prospectiva.json';c=json.loads(old.read_text())
    snapshot=HERE/'frozen_metadata_v2';snapshot.mkdir(exist_ok=False)
    reloc={};current={};changes=[]
    for path,old_sha in c['metadata_source_sha256'].items():
        raw=(ROOT/path).read_bytes();digest=hashlib.sha256(raw).hexdigest()
        target=snapshot/digest
        if not target.exists():
            with target.open('xb')as f:f.write(raw)
        reloc[path]=str(target.relative_to(ROOT));current[path]=digest
        if digest!=old_sha:changes.append(dict(path=path,previous_sha256=old_sha,current_sha256=digest))
    c['schema']='C09_D2_COMPONENT_DESIGN_v2_METADATA_SNAPSHOT'
    c['previous_config_sha256']=sha(old)
    c['metadata_source_sha256']=current;c['frozen_metadata_source_paths']=reloc
    c['metadata_changes_before_freeze']=changes
    c['metadata_change_did_not_run_or_reinterpret_physics']=True
    path=HERE/'config_prospectiva_v2.json';save(path,c)
    rows=c['new_curves']+c['reused_functions']
    checks=dict(eight_new=len(c['new_curves'])==8,five_existing=len(c['reused_functions'])==5,
                forty_analyses=sum(len(r['prior_ids'])for r in rows)==40,
                unique_functions=len({r['curve_id']for r in rows})==13,
                allocation_200k=sum(r['additional_likelihood_cap']for r in rows)==200000,
                per_data_200k=sum(c['budget']['caps_by_data'].values())==200000,
                no_execution=c['physical_execution_enabled']is False,
                metadata_snapshot_hashes=all(sha(ROOT/reloc[p])==h for p,h in current.items()),
                attempt4_math_sources_unchanged=all(sha(HERE/p)==h for p,h in json.loads((HERE/'toy_attempt4/preflight.json').read_text())['sources'].items()),
                D3_18x500_126=(c['D3_preserved']['groups'],c['D3_preserved']['realizations_each'],c['D3_preserved']['test_family'])==(18,500,126))
    result=dict(schema='C09_D2_METADATA_SNAPSHOT_REVIEW_v2',status='PASS'if all(checks.values())else'FAILED',
                checks=checks,config_sha256=sha(path),sources_changed=changes,new_scientific_computation=0,
                CPU_seconds=time.process_time()-start,RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    save(HERE/'metadata_review_v2.json',result)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
