"""Full/diagonal × fixed/variable covariance on identical B observations."""
import numpy as np


def compressed_moments(mean,covariance,weights):
    mu=np.asarray(mean,float);s=np.asarray(covariance,float);w=np.asarray(weights,float)
    if (mu.ndim!=3 or s.shape!=mu.shape+(mu.shape[-1],) or w.shape!=(mu.shape[1],)
        or not all(np.isfinite(x).all() for x in (mu,s,w)) or min(mu.shape)<1):
        raise ValueError('mean(N,K,D), covariance(N,K,D,D), weights(K) required')
    if np.max(abs(s-s.swapaxes(-1,-2)),initial=0)>1e-12*np.max(abs(s),initial=0):
        raise ValueError('symmetric covariance required')
    return np.einsum('k,nkd->nd',w,mu),np.einsum('k,nkij->nij',w*w,s)


def factorial_moments(mean,covariance,weights,*,diagonal,fixed,anchor_covariance):
    if type(diagonal)is not bool or type(fixed)is not bool:raise ValueError('explicit Boolean factor levels required')
    mu,s=compressed_moments(mean,covariance,weights)
    anchor=np.asarray(anchor_covariance,float)
    if anchor.shape!=s.shape[1:] or not np.isfinite(anchor).all():raise ValueError('compressed anchor(D,D) required')
    if not np.allclose(anchor,anchor.T,rtol=1e-12,atol=0):raise ValueError('symmetric anchor required')
    np.linalg.cholesky(anchor)
    if fixed:s=np.broadcast_to(anchor,s.shape)
    if diagonal:s=np.eye(s.shape[-1])[None]*np.diagonal(s,axis1=-2,axis2=-1)[:,:,None]
    # Return a single independent block; the mean always retains u dependence.
    return mu[:,None],s[:,None]


def compress_observations(observations,weights):
    y=np.asarray(observations,float);w=np.asarray(weights,float)
    if y.ndim!=3 or w.shape!=(y.shape[1],) or not np.isfinite(y).all() or not np.isfinite(w).all():
        raise ValueError('finite observations(B,K,D) and weights(K) required')
    return np.einsum('k,bkd->bd',w,y)[:,None]
