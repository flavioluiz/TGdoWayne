"""Direct shared references for fixed cuts and proper priors; no PTA imports.

The callback returns normalized logL and must charge every uncached data/curve
value before work. Integration uses alpha=asin(u); each vector has its own
normalizer, moments and fixed-cut numerator. Priors share a likelihood call,
never a normalizer. quad_vec errors are operational estimates, not bounds.
"""
import math
import warnings
import numpy as np
from scipy.integrate import quad_vec
from priors import PriorMeasure


def ratio_interval(n,en,z,ez):
    if not np.isfinite([n,en,z,ez]).all() or en<0 or ez<0 or z<=ez or n<0 or n>z+en+ez:
        raise ArithmeticError('invalid numerator/denominator and their separate error estimates')
    return max(0.,(n-en)/(z+ez)),min(1.,(n+en)/(z-ez))


def conservative_quantile_gate(p,lo,hi,low_interval,high_interval,*,width=.001):
    if not (0<p<1 and 0<=lo<=hi<=1 and 0<width<=.001):raise ValueError('invalid quantile bracket')
    for pair in (low_interval,high_interval):
        if len(pair)!=2 or not np.isfinite(pair).all() or not 0<=pair[0]<=pair[1]<=1:
            raise ValueError('valid CDF intervals required')
    return bool(hi-lo<=width and low_interval[1]<=p<=high_interval[0])


def integrate_reference_bundle(loglike,priors,cuts,*,shift,epsabs=1e-9,epsrel=1e-8,limit=150):
    if (not callable(loglike) or not priors or len(priors)!=len(cuts) or
        any(not isinstance(p,PriorMeasure) for p in priors) or not math.isfinite(shift)):
        raise ValueError('callback, priors, per-prior fixed cuts and a finite fixed shift required')
    if not (0<epsabs<=1e-6 and 0<epsrel<=1e-6) or type(limit)is not int or not 1<=limit<=2000:
        raise ValueError('bounded prospective quadrature settings required')
    cutarrays=[];offset=[0]
    for c in cuts:
        c=np.asarray(c,float)
        if c.ndim!=1 or not np.isfinite(c).all() or np.any((c<0)|(c>1)):
            raise ValueError('finite fixed cuts in[0,1] required')
        cutarrays.append(c.copy());offset.append(offset[-1]+4+len(c))
    # Split at every support boundary and indicator cut. No adaptive selection
    # of cuts is made from the reference likelihood being integrated.
    edges=np.unique(np.concatenate([np.array([p.lower,p.upper]) for p in priors]+cutarrays))
    lower=min(p.lower for p in priors);upper=max(p.upper for p in priors)
    edges=edges[(edges>=lower)&(edges<=upper)]
    values=np.zeros(offset[-1]);errors=np.zeros(offset[-1]);queries=0;records=[]
    for left,right in zip(edges[:-1],edges[1:]):
        mid=(left+right)/2
        active=[i for i,p in enumerate(priors) if p.lower<=mid<=p.upper]
        if not active:continue
        al,ah=math.asin(left),math.asin(right)
        if not al<ah:raise ArithmeticError('collapsed reference panel')
        def integrand(alpha):
            nonlocal queries
            u=math.sin(alpha);raw=np.asarray(loglike(np.array([u])),float)
            queries+=1
            if raw.shape!=(1,) or not np.isfinite(raw).all():raise ArithmeticError('invalid direct reference logL')
            ell=float(raw[0])-shift
            if ell>700:raise ArithmeticError('fixed scaling insufficient; no silent shift/restart')
            out=np.zeros(offset[-1])
            for j in active:
                w=math.exp(ell+float(priors[j].alpha_logpdf(alpha)))
                start=offset[j]
                out[start:start+4]=w*np.array([1.,u,u*u,ell])
                out[start+4:offset[j+1]]=w*(mid<=cutarrays[j])
            return out
        with warnings.catch_warnings():
            warnings.simplefilter('error')
            val,error,info=quad_vec(integrand,al,ah,epsabs=epsabs,epsrel=epsrel,
                                    norm='max',limit=limit,workers=1,quadrature='gk21',full_output=True)
        if not info.success or not np.isfinite(val).all() or not math.isfinite(error):
            raise ArithmeticError('reference quadrature failed without a usable certificate')
        values+=val
        # max-norm error applies to every component of this panel. It is not
        # divided by vector dimension; inactive components receive zero error.
        for j in active:errors[offset[j]:offset[j+1]]+=error
        records.append(dict(lower=left,upper=right,neval=int(info.neval),estimated_max_error=float(error)))
    result=[]
    for j,p in enumerate(priors):
        val=values[offset[j]:offset[j+1]];err=errors[offset[j]:offset[j+1]]
        z=val[0];ez=err[0]
        if z<=ez:raise ArithmeticError('reference denominator not resolved')
        probabilities=val[4:]/z
        intervals=[ratio_interval(n,en,z,ez) for n,en in zip(val[4:],err[4:])]
        logz_error=-math.log1p(-ez/z)
        ratio_errors=[float((err[k]+abs(val[k]/z)*ez)/(z-ez)) for k in (1,2,3)]
        result.append(dict(prior=dict(kind=p.kind,lower=p.lower,upper=p.upper),
                           logZ=shift+math.log(z),logZ_error_estimate=-math.log1p(-ez/z),
                           mean=float(val[1]/z),second=float(val[2]/z),
                           kl_to_prior=float(val[3]/z-math.log(z)),
                           normalized_moment_errors=ratio_errors,
                           kl_error_estimate=ratio_errors[2]+logz_error,
                           cut_values=cutarrays[j].tolist(),cdf=probabilities.tolist(),
                           cdf_intervals=intervals,numerators=val[4:].tolist(),
                           numerator_error_estimates=err[4:].tolist(),
                           denominator=float(z),denominator_error_estimate=float(ez)))
    return dict(results=result,callback_queries=queries,panels=records,
                error_kind='operational_QUADPACK_max_norm_estimates_not_rigorous_bounds',
                uniform_physical_probability_certificate=None,
                backend_domain_evidence_not_assessed_by_component=True,
                logL_event_not_evaluated=True)
