"""Positive 1D posterior integration on an explicit support [a,b].

This integrates a supplied log-likelihood interpolant. It is a table result,
never evidence that the physical backend has a uniform probability bound.
No model, PTA data, likelihood callback or random generator is imported here.
"""
import math
import numpy as np
from scipy.interpolate import PchipInterpolator
from priors import PriorMeasure


class PosteriorTable:
    def __init__(self,u,log_likelihood,prior,*,order=16,tile_cells=256):
        u=np.asarray(u,float);ell=np.asarray(log_likelihood,float)
        if (u.ndim!=1 or len(u)<2 or ell.shape!=u.shape or
            not np.isfinite(u).all() or not np.isfinite(ell).all() or
            np.any(np.diff(u)<=0) or u[0]<0 or u[-1]>1):
            raise ValueError('strict finite u nodes and same-shape finite logL required')
        if not isinstance(prior,PriorMeasure) or prior.lower<u[0] or prior.upper>u[-1]:
            raise ValueError('prior support must lie inside supplied likelihood support')
        if type(order)is not int or not 4<=order<=128 or type(tile_cells)is not int or tile_cells<1:
            raise ValueError('explicit bounded GL order and positive tile size required')
        self.prior=prior;self.order=order
        alpha=np.arcsin(u)
        if np.any(np.diff(alpha)<=0):raise ValueError('transformed likelihood nodes collapsed')
        self.loglike=PchipInterpolator(alpha,ell,extrapolate=False)
        edges=np.unique(np.r_[prior.lower,u[(u>prior.lower)&(u<prior.upper)],prior.upper])
        self.u_edges=edges;self.edges=np.arcsin(edges)
        if np.any(np.diff(self.edges)<=0):raise ValueError('support/interpolation endpoints collapsed')
        self.shift=float(np.max(self.loglike(self.edges)))
        self.x,self.w=np.polynomial.legendre.leggauss(order)
        sums=[]
        for start in range(0,len(edges)-1,tile_cells):
            lo=self.edges[start:start+tile_cells];hi=self.edges[start+1:start+tile_cells+1]
            sums.append(self._integrals(lo,hi))
        self.cell_integrals=np.concatenate(sums)
        self.total=np.array([math.fsum(v) for v in self.cell_integrals.T])
        if not np.isfinite(self.total).all() or self.total[0]<=0:
            raise ArithmeticError('posterior normalization underflow or nonfinite integral')
        self.prefix=np.r_[0.,np.cumsum(self.cell_integrals[:,0])]
        self.prefix_summation_delta=float(abs(self.prefix[-1]-self.total[0])/self.total[0])
        # Pin only the accumulated endpoint, with its discrepancy retained above.
        self.prefix[-1]=self.total[0]
        self.logZ=self.shift+math.log(self.total[0])
        self.mean=self.total[1]/self.total[0]
        self.second=self.total[2]/self.total[0]
        self.kl_to_prior=self.total[3]/self.total[0]-math.log(self.total[0])

    def _integrals(self,lo,hi):
        lo=np.atleast_1d(lo);hi=np.atleast_1d(hi)
        half=(hi-lo)/2
        alpha=lo[:,None]+half[:,None]*(1+self.x)
        u=np.sin(alpha);ell=self.loglike(alpha)-self.shift
        density=np.exp(ell+self.prior.alpha_logpdf(alpha))
        weight=half[:,None]*self.w*density
        return np.stack([np.sum(weight,axis=1),np.sum(weight*u,axis=1),
                         np.sum(weight*u*u,axis=1),np.sum(weight*ell,axis=1)],axis=1)

    def cdf(self,u):
        u=np.asarray(u,float)
        if not np.isfinite(u).all():raise ValueError('finite CDF coordinates required')
        flat=u.ravel();out=np.empty_like(flat)
        left=flat<=self.prior.lower;right=flat>=self.prior.upper;inside=~(left|right)
        out[left]=0.;out[right]=1.
        alpha=np.arcsin(flat[inside]);idx=np.searchsorted(self.edges,alpha,side='right')-1
        values=self.prefix[idx]+self._integrals(self.edges[idx],alpha)[:,0]
        out[inside]=values/self.total[0]
        if np.any((out<0)|(out>1+1e-12)):raise ArithmeticError('invalid integrated CDF')
        return out.reshape(u.shape)

    def candidate_quantile_bracket(self,p,*,width=.001):
        if not np.isfinite([p,width]).all() or not 0<p<1 or not 0<width<=.001:
            raise ValueError('interior quantile and width in(0,.001] required')
        lo,hi=self.prior.lower,self.prior.upper
        for _ in range(64):
            if hi-lo<min(1e-9,width/1000):break
            mid=lo+(hi-lo)/2
            if float(self.cdf(mid))<p:lo=mid
            else:hi=mid
        center=(lo+hi)/2;half=.49*width
        return (max(self.prior.lower,center-half),min(self.prior.upper,center+half))

    def summary(self):
        return dict(logZ=self.logZ,mean=self.mean,second=self.second,
                    kl_to_prior=self.kl_to_prior,
                    prefix_summation_delta=self.prefix_summation_delta,
                    scope='supplied_log_likelihood_interpolant_only')


def wasserstein_to_prior(table,*,order=12,tile_cells=128):
    """Integral |F_post-F_prior| du, split at the table knots; table-only."""
    if not isinstance(table,PosteriorTable) or type(order)is not int or not 4<=order<=128:
        raise ValueError('PosteriorTable and bounded order required')
    x,w=np.polynomial.legendre.leggauss(order);parts=[]
    for start in range(0,len(table.u_edges)-1,tile_cells):
        lo=table.u_edges[start:start+tile_cells];hi=table.u_edges[start+1:start+tile_cells+1]
        half=(hi-lo)/2;u=lo[:,None]+half[:,None]*(1+x)
        parts.extend(np.sum(half[:,None]*w*abs(table.cdf(u)-table.prior.cdf(u)),axis=1))
    return float(math.fsum(parts))


def wasserstein_between(first,second,*,order=12,tile_cells=128):
    """Posterior-versus-posterior W1 on the union of supports, no extrapolation."""
    if not isinstance(first,PosteriorTable) or not isinstance(second,PosteriorTable):
        raise ValueError('two PosteriorTable inputs required')
    if type(order)is not int or not 4<=order<=128:raise ValueError('bounded GL order required')
    edges=np.unique(np.r_[first.u_edges,second.u_edges]);x,w=np.polynomial.legendre.leggauss(order)
    parts=[]
    for start in range(0,len(edges)-1,tile_cells):
        lo=edges[start:start+tile_cells];hi=edges[start+1:start+tile_cells+1]
        half=(hi-lo)/2;u=lo[:,None]+half[:,None]*(1+x)
        parts.extend(np.sum(half[:,None]*w*abs(first.cdf(u)-second.cdf(u)),axis=1))
    return float(math.fsum(parts))
