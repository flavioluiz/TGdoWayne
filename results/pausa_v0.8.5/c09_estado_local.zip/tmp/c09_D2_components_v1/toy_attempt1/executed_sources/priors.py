"""Proper measures on an explicit [a,b] subset of the propagating u domain."""
from dataclasses import dataclass
import math
import numpy as np

KINDS=('uniform_u','uniform_u_squared','log_uniform_u')

@dataclass(frozen=True)
class PriorMeasure:
    kind:str
    lower:float
    upper:float
    def __post_init__(self):
        if (self.kind not in KINDS or isinstance(self.lower,bool) or isinstance(self.upper,bool)
                or not np.isfinite([self.lower,self.upper]).all() or not 0<=self.lower<self.upper<=1):
            raise ValueError('proper kind and explicit0<=a<b<=1 required')
        if self.kind=='log_uniform_u' and self.lower==0:raise ValueError('log prior requires positive cutoff')
    def _finite(self,u):
        a=np.asarray(u,float)
        if not np.isfinite(a).all():raise ValueError('finite coordinates required')
        return a
    def cdf(self,u):
        u=np.clip(self._finite(u),self.lower,self.upper)
        a,b=self.lower,self.upper
        if self.kind=='uniform_u':return (u-a)/(b-a)
        if self.kind=='uniform_u_squared':return (u-a)*(u+a)/((b-a)*(b+a))
        return np.log1p((u-a)/a)/math.log1p((b-a)/a)
    def ppf(self,v):
        v=self._finite(v)
        if np.any((v<0)|(v>1)):raise ValueError('prior probability outside[0,1]')
        a,b=self.lower,self.upper
        if self.kind=='uniform_u':u=a+v*(b-a)
        elif self.kind=='uniform_u_squared':u=np.sqrt(a*a+v*(b-a)*(b+a))
        else:u=np.exp(math.log(a)+v*math.log1p((b-a)/a))
        return np.where(v==0,a,np.where(v==1,b,u))
    def logpdf(self,u):
        u=self._finite(u);inside=(u>=self.lower)&(u<=self.upper)
        a,b=self.lower,self.upper;safe=np.where(inside,u,1.)
        if self.kind=='uniform_u':values=np.full_like(u,-math.log(b-a))
        elif self.kind=='uniform_u_squared':
            values=np.full_like(u,-np.inf)
            positive=safe>0
            np.log(2*safe,out=values,where=positive)
            values-=math.log((b-a)*(b+a))
        else:values=-np.log(safe)-math.log(math.log1p((b-a)/a))
        return np.where(inside,values,-np.inf)
    def alpha_logpdf(self,alpha):
        alpha=self._finite(alpha)
        if np.any((alpha<math.asin(self.lower))|(alpha>math.asin(self.upper))):raise ValueError('alpha outside transformed support')
        # b<1 is a finite endpoint density, not forcibly zero.
        u=np.sin(alpha);u=np.where(alpha==math.asin(self.lower),self.lower,u)
        u=np.where(alpha==math.asin(self.upper),self.upper,u)
        cosine=np.cos(alpha)
        # cos(pi/2) is not exactly zero in binary arithmetic. The mathematical
        # transformed density has a zero endpoint at u=1 for all three priors.
        cosine=np.where((self.upper==1)&(alpha==math.pi/2),0.,cosine)
        logcos=np.full_like(alpha,-np.inf)
        np.log(cosine,out=logcos,where=cosine>0)
        return self.logpdf(u)+logcos
    def moments(self):
        a,b=self.lower,self.upper
        if self.kind=='uniform_u':return {'mean':(a+b)/2,'second':(a*a+a*b+b*b)/3}
        if self.kind=='uniform_u_squared':return {'mean':2*(a*a+a*b+b*b)/(3*(a+b)),'second':(a*a+b*b)/2}
        z=math.log1p((b-a)/a)
        return {'mean':(b-a)/z,'second':(b-a)*(b+a)/(2*z)}
    def contains_truth(self,u):return bool(np.isfinite(u) and self.lower<=u<=self.upper)
    def reweighting_support_is_covered_by(self,old):
        """Absolute continuity on intervals; an endpoint of zero old density has zero measure."""
        if not isinstance(old,PriorMeasure):raise ValueError('proper original measure required')
        return self.lower>=old.lower and self.upper<=old.upper


def integration_rule(prior,order,*,coordinate,panel_edges=()):
    if not isinstance(prior,PriorMeasure) or type(order)is not int or not 2<=order<=4096:
        raise ValueError('explicit proper prior and GL order required')
    extra=np.asarray(panel_edges,float)
    if extra.ndim!=1 or not np.isfinite(extra).all():raise ValueError('finite panel edges required')
    edges=np.unique(np.r_[prior.lower,extra[(extra>prior.lower)&(extra<prior.upper)],prior.upper])
    x,w=np.polynomial.legendre.leggauss(order);us=[];lws=[]
    for a,b in zip(edges[:-1],edges[1:]):
        if coordinate=='prior_cdf':
            lo,hi=prior.cdf(np.array([a,b]));half=(hi-lo)/2
            if half<=0:raise ArithmeticError('prior-CDF interval collapsed')
            us.append(prior.ppf(lo+half*(1+x)));lws.append(np.log(half*w))
        elif coordinate=='alpha':
            half=math.atan2(b-a,math.sqrt((1-a)*(1+a))+math.sqrt((1-b)*(1+b)))
            alpha=math.asin(a)+half*(1+x)
            if np.any((alpha<=math.asin(a))|(alpha>=math.asin(b))):raise ArithmeticError('interior alpha nodes collapsed')
            us.append(np.sin(alpha));lws.append(np.log(half*w)+prior.alpha_logpdf(alpha))
        else:raise ValueError('only alpha and prior_cdf measures are supported')
    return np.concatenate(us),np.concatenate(lws)
