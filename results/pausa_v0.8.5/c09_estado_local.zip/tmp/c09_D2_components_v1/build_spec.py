"""Metadata-only prospective D2 design; never opens a scientific NPZ."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    nominal_path=ROOT/'tmp/c09_nominal14_v4/config.json'
    nominal=json.loads(nominal_path.read_text())
    decision_path=ROOT/'tmp/c09_ROOT/DECISAO_AVANCO_FUNCIONAL.md'
    initial_plan=json.loads((ROOT/'tmp/c09_event_repair_runtime_v1/preflight.json').read_text())
    exp=json.loads((ROOT/nominal['experiment_config']).read_text())
    priors=[]
    for upper in (1.,.8):
        for kind in ('uniform_u','uniform_u_squared'):
            priors.append(dict(id=f'{kind}_a0_b{upper:g}',kind=kind,lower=0.,upper=upper))
        for lower in (1e-4,1e-3,1e-2):
            priors.append(dict(id=f'log_uniform_u_a{lower:g}_b{upper:g}',kind='log_uniform_u',lower=lower,upper=upper))
    uniform='uniform_u_a0_b1'
    def row(curve,data,analysis,*,new,rho=0.,cap,prior_ids=None):
        source=nominal['rows'][data]
        return dict(curve_id=curve,data_id=data,analysis=analysis,new_likelihood_function=new,
                    observation_field=('q' if analysis=='A0_CN' else ('x_gaussian' if '_G' in analysis else 'x_physical')),
                    eta_physical_coordinates=source['eta_physical_coordinates'],
                    generation_contaminant_ratio=source['generation_contaminant_ratio'],analysis_contaminant_ratio=rho,
                    fixed_truth_u=source['fixed_truth_u'],anchor_u=.5,additional_likelihood_cap=cap,
                    prior_ids=prior_ids or [uniform],existing_values_credit_before_validated_load=0)
    new=[]
    for name in ('full_variable','full_fixed','diagonal_fixed'):
        new.append(row('new_d7_BG_'+name,7,'B_G_'+name,new=True,cap=22500))
    for name in ('diagonal_variable','full_fixed','diagonal_fixed'):
        new.append(row('new_d6_BCN_'+name,6,'B_CN_'+name,new=True,cap=22500))
    new.append(row('new_d13_BCN_monopole_included',13,'B_CN_full_variable',new=True,rho=1.,cap=22500))
    new.append(row('new_d7_AG',7,'A_G',new=True,cap=22500))
    reused=[]
    for data,cap in [(2,5000),(3,5000),(6,5000),(7,2500),(13,2500)]:
        reused.append(row(f'baseline_d{data}',data,nominal['rows'][data]['analysis'],new=False,cap=cap,
                          prior_ids=[p['id']for p in priors]if data in(2,3,6)else[uniform]))
    curve_totals={}
    for r in new+reused:curve_totals[str(r['data_id'])]=curve_totals.get(str(r['data_id']),0)+r['additional_likelihood_cap']
    count=sum(len(r['prior_ids'])for r in new+reused)
    data_file='tmp/c09_nominal14_backend_v4/gates/data.npz'
    inputs={path:initial_plan['bindings'][path] for path in [data_file,nominal['table_file'],
            'tmp/c09_nominal14_backend_v4/gates/harmonic_nodes.npz']}
    metadata_paths=['tmp/c09_ROOT/DECISAO_AVANCO_FUNCIONAL.md','tmp/c09_ROOT/functional_gate_decision.json',
                    'tmp/c09_ROOT/fundamentos_robustez.tex','tmp/c09_scope_gate_review_v1/PARECER.md',
                    'tmp/c09_nominal14_v4/config.json','tmp/c09_nominal14_v4/channelwise_table.py',
                    'tmp/c09_nominal14_v2/kernels.py','tmp/c09_integrator/integrator.py',
                    'tmp/c09_event_repair_runtime_v1/preflight.json',nominal['experiment_config']]
    spec=dict(schema='C09_D2_COMPONENT_DESIGN_v1',status='PROSPECTIVE_COMPONENTS_ONLY_NOT_EXECUTABLE_PHYSICS',
              physical_execution_enabled=False,ROOT_decision_sha256=sha(decision_path),
              experiment={k:exp[k]for k in ['n_pulsars','duration_years','positive_channels','frequency_weights',
                                          'fixed_red_slope','distance_range_light_years','cadence_days','geometry_seeds']},
              units=dict(u='m_g*c^2*T/h',alpha='asin(u)',beta1='sqrt((1-u)*(1+u))',
                         log_likelihood='fully normalized in the same numerical data units as C06/C07',
                         no_TOA_claim=True,known_nuisance_conditional=True),
              priors=priors,new_curves=new,reused_functions=reused,total_likelihood_functions=13,
              total_posterior_analyses=count,existing_baselines_not_new_generated_data=True,
              selected_eight_accepted_by_ROOT=True,
              reference_plan=dict(density_coordinate='alpha, with all proper prior Jacobians and endpoints asin(a),asin(b)',
                  coarse_nodes='existing8336 response u nodes, restricted to support, all likelihood values checked/charged',
                  fine_nodes='coarse plus midpoint of each x=-beta1 cell; never more than16671 before added support edges',
                  prior_edges=[0.,1e-4,1e-3,.01,.8,1.],density_GL_orders=[16,32],
                  independent_direct='quad_vec GK21 in alpha, direct callback, separate per-prior normalizers/numerators; fixed cuts split every indicator',
                  callback_batch=32,quad_epsabs=1e-9,quad_epsrel=1e-8,quad_limit=150,quad_workers=1,
                  callback_sharing='same data/model logL value may multiply many prior densities; new values are never free',
                  fixed_cuts='prior quantiles[.05,.5,.9,.95],u=.2 if inside, truth if inside, endpoints of four quantile brackets',
                  quantile_probabilities=[.05,.5,.9,.95],candidate_bracket_half_width=.00049,
                  cuts_freeze='from the two table levels before direct reference evaluation; exact endpoints recorded per prior',
                  bracket_rule='Fref(lo)+rlo <= p <= Fref(hi)-rhi, width<=.001 and both table levels crossing',
                  W1='own integral |F1-F2| du on union support, GL12/24 table control; direct-functional validation or explicit UNRESOLVED, never inherit quantile flag',
                  logL_event='not evaluated by D2 components; preserve D1/D1b outcomes separately'),
              gates=dict(delta_logZ=.001,delta_CDF=.002,quantile_bracket_u=.001,
                         delta_mean=.001,delta_second=.001,delta_KL=.001,delta_W1=.001,
                         warning_free=True,finite_backend_domain_required=True,
                         uniform_physical_certificate_required=False,
                         finite_discrepancy_is_not_probability_bound=True,independent_gate_per_quantity=True),
              budget=dict(status='PROPOSED_NOT_AUTHORIZED',new_likelihood_values=200000,
                          allocation_new_functions=180000,allocation_existing_function_misses=20000,
                          caps_by_data=curve_totals,max_likelihood_values_per_new_curve=22500,
                          max_additional_per_existing_curve=5000,
                          source_identity_aliases_share_count=True,auxiliaries_anchors_oracle_references_count=True,
                          cache_credit_requires_verified_bytes_and_same_function=True,
                          global_and_per_data_history_never_reset=True,
                          proposed_stage_CPU_seconds=180,proposed_stage_wall_seconds=360,
                          CPU_estimate='candidate only: D1 rate152.935084/325629 gives93.93s at200k, plus86.07s setup/integration allowance; no D2 physical timing exists',
                          old_D1_caps_unchanged=True,old_D1_costs_reported_separately_not_refunded=True,
                          RSS_bytes=1610612736,estimated_numeric_bytes=1400000000,
                          output_bytes=16777216,BLAS_threads=1,workers=1,
                          ORF_products=0,direct_sky_points=0,new_draws=0,
                          fail='persist partial values/resources/status, no automatic restart/refinement/cap increase'),
              prior_reweighting=dict(same_data_required=True,
                  original_log_prior_d3_lower=.001,
                  expanded_support_d3='priors with mass below.001 require direct integration there; cannot obtain it solely by old-posterior reweighting',
                  true_outside_support='no matched-calibration PIT; retain observation and label support exclusion',
                  normalized_evidence='same underlying statistic only; AG versus BG evidence is not a Bayes factor'),
              frozen_input_sha256_copied_from_reviewed_metadata=inputs,
              binary_inputs_rehashed_or_decoded_during_preparation=False,
              metadata_source_sha256={p:sha(ROOT/p)for p in metadata_paths},
              missing_before_physical_authorization=['physical worker and identity-preserving cache import',
                  'canonical shared ledger and independent supervisor bound to complete source closure',
                  'new-kernel versus available16 harmonic controls and SciPy reference within200k',
                  'own direct-functional W1 control or explicit per-quantity UNRESOLVED',
                  'ROOT authorization of exact sources, resources and execution request'],
              D3_preserved=dict(groups=18,realizations_each=500,test_family=126,Holm_alpha=.05,
                                prospective_global_likelihood_cap=120000000,execution_authorized=False),
              C09_complete=False,physical_work_prepared_or_executed=dict(ORF=0,LL=0,bank=0,draw=0,NPZ_decoded=0))
    with (HERE/'config_prospectiva.json').open('x')as f:json.dump(spec,f,indent=2);f.write('\n')
    print(json.dumps(dict(path=str(HERE/'config_prospectiva.json'),sha256=sha(HERE/'config_prospectiva.json'),
                         new_functions=len(new),reused_functions=len(reused),analyses=count,new_LL_cap=200000)))

if __name__=='__main__':main()
