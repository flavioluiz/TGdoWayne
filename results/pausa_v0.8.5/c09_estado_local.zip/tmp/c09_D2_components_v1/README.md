# Candidato puro D2 — versão congelada

Leia `PROTOCOLO.md` e `FUNDAMENTACAO.md`. A configuração corrente é
`config_prospectiva_v2.json`; a v1 e sua falha de verificação de rascunho vivo
foram preservadas. A revisão v2 usa snapshots de metadados e não lê NPZ.
O rascunho editorial ROOT é referência de texto, não dependência científica de
um futuro executor; este deverá vincular a decisão funcional, fontes e dados
que determinam seus valores.

Componentes:

- `priors.py`: medidas próprias e regras de integração em [a,b].
- `posterior_table.py`: PCHIP de logL em alpha, integrais positivas, CDF,
  brackets candidatos e W1 das tabelas.
- `functional_reference.py`: referências diretas de numerador/denominador,
  momentos e KL, compartilhando logL entre prioris sem compartilhar Z.
- `batch_likelihood.py`: CN e normal com vários RHS, contagem antes da
  fatoração e estimativa explícita dos arrays.
- `factorial.py`: completa/diagonal × fixa/variável e compressão do mesmo dado.

`toy_attempt4` tem13 testes PASS; `metadata_review_v2.json` tem todos os checks
de inventário/caps/snapshots aprovados. A revisão independente está em
`tmp/c09_D2_independent_review_v1/review.json`, SHA-256
`909402ea2e9205d7336f51ea7ca2638fd5642926a01ff9dcad0ffe9147b9ee34`.
Ela não aprova um executor físico.

Nenhuma avaliação física foi executada. O próximo pacote, em diretório
separado, conterá o driver, cache por identidade, supervisão, validação das
novas funções contra as respostas já disponíveis e gates por quantidade. O
diretório presente deve permanecer congelado durante esse desenvolvimento.
