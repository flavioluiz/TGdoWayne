# Medidas e integrais verificáveis

Para 0≤a<b≤1, as medidas normalizadas são

\[
\pi_1(u)=\frac1{b-a},\quad
\pi_2(u)=\frac{2u}{b^2-a^2},\quad
\pi_{\log}(u)=\frac1{u\log(b/a)},\quad a>0\text{ no terceiro caso}.
\]

As integrais são restritas a[a,b]. Para alpha=asin(u), du=cos(alpha)dalpha,
portanto a densidade transformada é π(sin alpha)cos alpha e os limites são
[asin a,asin b]. Para b<1, a densidade no extremo direito em geral é finita e
não nula. Para b=1, seu limite é zero nas três medidas; o código não confunde
cos(pi/2)≈6×10⁻¹⁷ em float64 com esse limite matemático. A meia largura estável
de um painel alpha é atan2(b−a,sqrt(1−a²)+sqrt(1−b²)).

Se v=F_prior(u), então π(u)du=dv. Isso justifica a segunda regra de integração
disponível. Porém uma função suave em u pode adquirir uma derivada singular em
v: por exemplo E[u] da priori uniforme em u² envolve sqrt(v) em a=0. A mudança
de variável correta não garante convergência de uma regra GL sem painéis.

Z=∫Lπ, N(t)=∫[a,t]Lπ e F=N/Z. Para erros operacionais E_N,E_Z≥0 e Z>E_Z,
usam-se os intervalos [(N−E_N)/(Z+E_Z),(N+E_N)/(Z−E_Z)] intersectados com[0,1].
Esses intervalos propagam as estimativas; não tornam QUADPACK rigoroso. Os
brackets de quantil exigem crossing conservador dos dois endpoints, além da
largura em u. Se um corte está fora do suporte, sua CDF é estrutural0 ou1;
isso não constitui um PIT de calibração matched quando a verdade foi excluída.

Com escala fixa s em logL, z=∫exp(ell−s)π e logZ=s+log z. Primeiro/segundo
momento usam numeradores próprios. A informação relativa à priori satisfaz
KL=E_post[ell−s]−log z. Seu erro operacional inclui o da razão do numerador e
o de log z. Uma constante aditiva em ell altera logZ, mas não a posterior nem
KL. Prioris em suportes diferentes precisam de normalizações diferentes.

Para covariância complexa própria C e vetor q∈C^P,
ell_CN=−KP log pi−Σ_k logdet C_k−Σ_k q_k†C_k⁻¹q_k.
O equivalente real para [Re q,Im q] tem matriz
1/2[[Re C,−Im C],[Im C,Re C]]. Essa equivalência verifica sinal, fator2,
normalização e termo imaginário sem usar o kernel complexo como referência.

Para a normal de estatísticas reais,
ell_G=−1/2[KD log(2pi)+Σ_k logdetΣ_k+Σ_k(y_k−μ_k)^TΣ_k⁻¹(y_k−μ_k)].
Para frequências independentes e z=Σ_k w_k y_k,
μ_B=Σ_k w_k μ_k e Σ_B=Σ_k w_k²Σ_k. As quatro operações são Σ_B(u),
diagΣ_B(u),Σ_B(.5),diagΣ_B(.5), todas com a mesma μ_B(u). Este cálculo vale
para a densidade aproximada aplicada a B_CN e para B_G; sua interpretação
distribucional é diferente, mas a álgebra do fatorial é idêntica.

Cholesky usa apenas um triângulo. Por isso o guard exige Hermiticidade
relativa à escala de cada bloco antes de fatorar, inclusive após reescalar
covariâncias para1e−30. Não há reparo por clipping. Resolver vários RHS
reutiliza fatorações, sem eliminar valores de likelihood da contagem.

Para W1 em uma dimensão, integra-se |F1(u)−F2(u)|du na união dos suportes.
Uma CDF vale0 abaixo e1 acima de seu suporte, sem extrapolar a densidade.
O teste de quantis não controla essa integral. As funções de W1 deste pacote
integram as tabelas e têm refinamento próprio; a referência física funcional
permanece requisito separado do futuro wrapper.
