# Supervisor prospectivo D1

Fonte independente, stdlib, um controller e **um worker sem descendentes**.
Não fornece engine físico nem lê arrays numéricos. Nenhuma autorização D1
real foi criada e nenhuma LL, ORF, geração ou banco real foi executado.

CLI:

```
python3 -B supervisor.py preflight --plan /caminho/plano.json
python3 -B supervisor.py execute --plan /caminho/plano.json --authorization /caminho/ROOT.json --output /destino/novo
```

O segundo comando exige autorização explícita do ROOT vinculada ao SHA
integral do plano e ao destino novo. O plano vincula o supervisor, worker,
configuração e todos os demais inputs/fontes por caminho relativo e SHA.
Não há geração automática de autorização, retry ou overwrite. A validação
confere os vínculos antes do spawn, no worker e ao final do controller.

## Interface do worker

Antes de NumPy/imports físicos:

```python
guard = WorkerGuard.from_request(args.request, args.request_sha256)
config_path = guard.parameters['config_path']
# Só depois vêm os imports/carregamento autorizados do engine.
```

- `guard.request`: pedido do controller, com hashes e limites do subprocesso.
- `guard.plan`: plano inteiro, inclusive `bindings`, `history` e `limits`.
- `guard.parameters`: o dicionário `plan['worker_parameters']`; colocar nele
  `config_path` e referências específicas do engine. Seus bytes estão ligados
  pelo SHA do plano, e os arquivos referenciados devem constar de `bindings`.
- `guard.repository`: raiz dos caminhos relativos.
- `guard.output` e `guard.output_path`: pasta `output/worker`, criada nova.
- `guard.config`: limites; inclui `estimated_numeric_bytes` para o loader v4.
- `guard.checkpoint()` e alias `guard.check()`: CPU/RSS/payload local.
- `guard.reserve(n,target)`: cobra vetor de misses antes da avaliação. Os
  ledgers do cache podem espelhar esses limites, sem somá-los ao canônico.
- `guard.write_json(name,obj)` / `write_bytes(name,bytes)`: nomes relativos,
  arquivos novos e quota explícita; permanecem disponíveis para preservar
  parciais após falha de um checkpoint computacional. Não autorizam nova LL.
- `guard.report()`: contadores cobrados e amostra de CPU/RSS do worker.
- `guard.finish('COMPLETED'|'FAILED', result=summary)`: uma vez; escreve
  `worker_end.json`. Usar resumo pequeno: recibo inteiro <=16KiB. Produtos
  detalhados devem ser escritos separadamente por `guard.write_*`.

`COMPLETED` é estado de execução; produtos científicos UNRESOLVED podem
constar do resumo sem se transformarem em PASS. Falhas também conservam os
contadores de reservas efetivamente cobradas. Eles não afirmam que todos
os valores de um callback interrompido foram concluídos.

## Plano e autorização

Plano `C09_D1_SUPERVISOR_PLAN_v1`:

| Campo | Contrato |
| --- | --- |
| `mode` | `D1` real prospectivo ou `TOY`, este restrito ao toy_worker.py deste pacote |
| `scope` | `D1_SAME_NOMINAL14_NO_NEW_ORF_SKY_DRAWS` |
| `execution_enabled_by_default` | false |
| `repository` | caminho absoluto canônico do repositório |
| `bindings` | mapa caminho relativo→SHA256; inclui supervisor e worker |
| `worker` | caminho relativo do único worker |
| `worker_parameters` | dicionário específico do engine/config |
| `history` | cpu_seconds, likelihood_values, likelihood_by_target, output_bytes, real_products, sky_points |
| `limits` | cópia dos campos/valores públicos de `CAPS` |

Em D1, o histórico deve conter 210.588 LL e o vetor por ID congelado
`HISTORY_BY_ID`, 296,087524 s CPU (preserva a representação próxima acima
desse número até1e-9), 214.577.271.056 produtos e74.530.432 pontos de céu.
`output_bytes` precisa ser medido/vinculado pelo preparador do plano; o
supervisor não inventa o tamanho histórico nem descobre uma nova campanha.

Autorização `C09_D1_EXECUTION_AUTHORIZATION_v1` exige `authority='ROOT'`,
`approved=true`, `execution_allowed=true`, `mode='D1'`, o mesmo `scope`,
`plan_sha256`, `output` absoluto exato e `automatic_retry=false`. Não há
arquivo real com esses campos aprovado neste pacote. As autorizações dos
fixtures usam exclusivamente `authority='SYNTHETIC_TEST_ONLY'`, mode TOY.

## Contabilidade e limitações operacionais

Limites D1: novos350.000 LL/25.000 por ID e270 s CPU, total1 M/60.000 por
ID/600 s CPU; RSS1.610.612.736 B; estimativa numérica1.400.000.000 B;
novos12MiB e herdados+novos<=20MiB. Novos ORF/céu/draws são zero. Os
64KiB de metadados e64KiB de log saem dos12MiB: payload máximo padrão
12.451.840 B. Não se reduz nem amplia silenciosamente o teto publicado.

O controller reserva o teto do trabalho antes do spawn. O worker cobra
cada callback antes do cálculo. Se houver recibo final estruturalmente
válido e fontes intactas, o contador observado é preservado mesmo com
worker FAILED. Se o recibo faltar ou for inválido, o custo exato não é
declarado zero: mantém-se o teto reservado, que deve ser carregado como
limite conservador por qualquer continuação futura explicitamente revista.

CPU usa processo desde startup, incluindo imports/preflight; ao terminar
o worker, `RUSAGE_CHILDREN` inclui startup/exit. O hard RLIMIT_CPU é o piso
do orçamento restante; o soft é no máximo1 s anterior. O handler SIGXCPU
e checkpoints tentam permitir persistência, sem garantir recuperação antes
do hard limit. O controller amostra sua CPU depois dos hashes finais; a
escrita/saída do seu último recibo fica explicitamente após essa amostra.

O RSS externo vem de RUSAGE_CHILDREN após wait, somado conservadoramente
ao máximo do controller; o worker também confere RSS nos checkpoints.
Isso é um guard operacional, não um limite de RSS imposto pelo SO nem
prova do pico simultâneo. O cap de arrays é fornecido ao loader pelo
guard.config; o engine ainda deve orçar seus demais arrays/temporários.

Cada processo recebe RLIMIT_FSIZE; o worker limita seu payload e o
controller drena stdout/stderr para um log separado limitado. O monitor
mata apenas o PID do Popen próprio, nunca um grupo. `wait` e medição final
ocorrem em finally. Se a morte for negada, a condição é registrada, a pipe
é fechada ao sair do monitor e o hard CPU permanece ativo até o reap;
essa incerteza não produz `within_resource_limits=true`. Um worker que
possa ficar esperando indefinidamente sem consumir CPU exigiria watchdog
wall próprio; o contrato atual é do engine D1 computacional, sem filhos.

## Testes e revisão

`toy_results_final4.json`: 11 testes PASS, subprocessos sintéticos, incluindo
autorização/no-overwrite, reserva por ID, falha do callback, ausência e
malformação do recibo, CPU, FSIZE, log/RSS e alteração de input sintético.
Custo total do processo de testes e filhos:1,958777 s CPU; maior RSS29.114.368 B.
`toy_kill_denied.json`: injeção explícita de PermissionError em kill, reap
e custo final preservados;0,071094 s CPU/32.915.456 B. Os testes não leram
NPZ nem importaram PTA/inference/NumPy. ROOT identificou a fraqueza do
killpg na revisão; a fonte anterior e seus resultados estão preservados
em `history_before_ROOT_kill_fix`, e `ROOT_delta.patch` contém a correção.

Os históricos anteriores também preservam a fixture que inicialmente
esperava recibo ausente em todo SIGXCPU: o novo finalizador pode salvar
um recibo FAILED antes do hard limit. O teste foi corrigido para verificar
ambos os desfechos válidos e a cobrança preservada, sem apagar a falha.

O orçamento e o supervisor não validam o mass provider, o allowance de
arredondamento, a margem probabilística de backend ou os gates científicos.
O worker real, a closure integrada e uma autorização ROOT ainda são necessários.
