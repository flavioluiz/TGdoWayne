"""One bounded synthetic denial test; kill is mocked, child exits normally."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(10,11))
import json,os,sys,tempfile,time
from pathlib import Path
from unittest.mock import patch
import supervisor as s

HERE=Path(__file__).resolve().parent
start=time.perf_counter()
with tempfile.TemporaryDirectory(prefix='TOY_DENIAL_',dir=HERE) as name:
    root=Path(name);limits=dict(s.CAPS,new_cpu_seconds=10.,new_output_bytes=256*1024,log_cap_bytes=16384)
    # This exact child has no descendants and no scientific code/data.
    command=[sys.executable,'-B','-c','import os,time; os.write(1,b"x"*65536); time.sleep(.05)']
    with patch('subprocess.Popen.kill',side_effect=PermissionError('SYNTHETIC_DENIAL')):
        result=s._run_child(command,root,limits,128*1024,dict(os.environ),cpu_limit=3.)
    assert result['kill_denied'] and result['child_reaped']
    assert result['returncode']==0 and result['child_CPU_seconds']>0
    assert result['operational_monitor_failures']
    assert result['log_bytes']<=limits['log_cap_bytes']
report=dict(schema='C09_D1_SUPERVISOR_KILL_DENIAL_TOY_v1',passed=True,result=result,
    CPU_seconds=s.cpu()+s.cpu(resource.RUSAGE_CHILDREN),max_RSS_bytes=max(s.rss(),s.rss(resource.RUSAGE_CHILDREN)),
    wall_seconds=time.perf_counter()-start,supervisor_sha256=s.sha(HERE/'supervisor.py'),
    physical_LL=0,ORF=0,banks=0,real_NPZ_arrays_read=0,draws=0)
assert report['CPU_seconds']<10 and report['max_RSS_bytes']<128*1024**2
s.write_new(HERE/'toy_kill_denied.json',report)
print(json.dumps({k:v for k,v in report.items() if k!='result'},sort_keys=True))
