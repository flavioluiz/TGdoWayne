#!/usr/bin/env python3
"""Prospective D1 supervisor. Stdlib only; never supplies a physical worker."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import resource
import selectors
import signal
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
SCOPE = 'D1_SAME_NOMINAL14_NO_NEW_ORF_SKY_DRAWS'
HISTORY_BY_ID = dict(zip(map(str, range(14)), (21205,11308,10635,10645,18219,10252,17936,9038,9459,16011,21430,19023,18408,17019)))
CAPS = dict(new_cpu_seconds=270., cumulative_cpu_seconds=600., new_likelihood_values=350000,
            new_likelihood_per_target=25000, cumulative_likelihood_values=1000000,
            cumulative_likelihood_per_target=60000, rss_bytes=1610612736,
            estimated_numeric_bytes=1400000000, new_output_bytes=12*1024**2,
            cumulative_output_bytes=20*1024**2, control_reserve_bytes=65536, log_cap_bytes=65536)
THREADS = ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS')


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''): h.update(block)
    return h.hexdigest()


def read(path): return json.loads(Path(path).read_text())
def payload(value): return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def rss(who=resource.RUSAGE_SELF):
    value=resource.getrusage(who).ru_maxrss
    return int(value if sys.platform=='darwin' else value*1024)
def cpu(who=resource.RUSAGE_SELF):
    r=resource.getrusage(who); return r.ru_utime+r.ru_stime


def relative(name):
    require(isinstance(name,str) and '\\' not in name and '\x00' not in name,'unsafe relative path')
    p=PurePosixPath(name)
    require(str(p)==name and not p.is_absolute() and p.parts and all(x not in ('.','..') and ':' not in x for x in p.parts),'unsafe relative path')
    return p


def path_under(root,name):
    p=Path(root)
    for part in relative(name).parts:
        p=p/part; require(not p.is_symlink(),'symlink forbidden')
    return p


def saved_bytes(root):
    total=0
    for base,dirs,files in os.walk(root,followlinks=False):
        for name in dirs+files:
            p=Path(base)/name
            require(not p.is_symlink(),'output symlink forbidden')
            st=p.stat(); require(stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode),'special output forbidden')
            if stat.S_ISREG(st.st_mode): total+=st.st_size
    return total


def write_new(path,value,*,bytes_value=False):
    data=value if bytes_value else payload(value)
    require(isinstance(data,bytes),'bytes payload required')
    with Path(path).open('xb') as f:f.write(data)


def counts(value):
    require(isinstance(value,dict) and set(value)==set(HISTORY_BY_ID),'exactly target IDs 0..13 required')
    require(all(type(n) is int and n>=0 for n in value.values()),'nonnegative integer counts required')
    return dict(value)


def verify_bindings(plan):
    root=Path(plan['repository'])
    for name,digest in plan['bindings'].items():
        p=path_under(root,name)
        require(p.is_file() and len(digest)==64 and sha(p)==digest,'source/input binding changed: '+name)


def validate_plan(path):
    digest=sha(path); plan=read(path)
    require(plan.get('schema')=='C09_D1_SUPERVISOR_PLAN_v1' and plan.get('mode') in ('D1','TOY'),'plan schema/mode')
    require(plan.get('scope')==SCOPE and plan.get('execution_enabled_by_default') is False,'explicit disabled default/scope required')
    root=Path(plan['repository'])
    require(root.is_absolute() and root.resolve()==root,'canonical repository required')
    require(isinstance(plan['bindings'],dict) and plan['bindings'],'nonempty closed source/input bindings required')
    own=str(Path(__file__).resolve().relative_to(root))
    require(plan['bindings'].get(own)==sha(__file__),'supervisor must be in frozen closure')
    worker=path_under(root,plan['worker'])
    require(plan['bindings'].get(plan['worker'])==sha(worker),'worker must be in frozen closure')
    require(isinstance(plan.get('worker_parameters'),dict),'explicit worker parameters required')
    h=plan['history']; by=counts(h['likelihood_by_target'])
    require(type(h['likelihood_values']) is int and h['likelihood_values']==sum(by.values()),'inherited LL total differs')
    require(type(h['output_bytes']) is int and h['output_bytes']>=0,'inherited output bytes required')
    require(type(h['cpu_seconds']) in (int,float) and math.isfinite(h['cpu_seconds']) and h['cpu_seconds']>=0,'inherited CPU required')
    limits=plan['limits']; require(set(limits)==set(CAPS),'all resource caps required')
    for key,limit in limits.items():
        expected=CAPS[key]
        valid_type=type(limit) in (int,float) if isinstance(expected,float) else type(limit) is int
        require(valid_type and math.isfinite(limit) and limit>0,'invalid cap: '+key)
        require(limit<=expected,'cap exceeds D1 proposal: '+key)
    require(limits['control_reserve_bytes']>=16384 and limits['new_output_bytes']>limits['control_reserve_bytes']+limits['log_cap_bytes'],'insufficient receipt/payload budget')
    require(h['output_bytes']+limits['new_output_bytes']<=limits['cumulative_output_bytes'],'12MiB new must fit inherited20MiB')
    require(h['likelihood_values']+limits['new_likelihood_values']<=limits['cumulative_likelihood_values'],'cumulative LL reservation exceeds cap')
    require(all(n+limits['new_likelihood_per_target']<=limits['cumulative_likelihood_per_target'] for n in by.values()),'cumulative per-ID reservation exceeds cap')
    require(h['cpu_seconds']+limits['new_cpu_seconds']<=limits['cumulative_cpu_seconds'],'cumulative CPU proposal exceeds cap')
    require(limits['new_likelihood_values']<=14*limits['new_likelihood_per_target'],'global reservation exceeds per-ID sum')
    if plan['mode']=='D1':
        require(by==HISTORY_BY_ID and h['likelihood_values']==210588,'D1 inherited 210588/by-ID ledger differs')
        require(abs(h['cpu_seconds']-296.087524)<=1e-9 and h['cpu_seconds']>=296.087524,'D1 historical final CPU differs')
        require(limits==CAPS,'D1 caps must preserve the exact reviewed proposal')
        require(h.get('real_products')==214577271056 and h.get('sky_points')==74530432,'historical ORF/sky costs differ')
    else:
        require(worker.resolve()==HERE/'toy_worker.py','TOY mode restricted to bundled synthetic worker')
        require(h['cpu_seconds']==0 and h['likelihood_values']==0 and all(n==0 for n in by.values()),'TOY has synthetic zero history')
    verify_bindings(plan)
    require(sha(path)==digest,'plan changed during validation')
    return plan,digest


def validate_authorization(path,plan,plan_sha,out):
    digest=sha(path); a=read(path)
    expected='ROOT' if plan['mode']=='D1' else 'SYNTHETIC_TEST_ONLY'
    require(a.get('schema')=='C09_D1_EXECUTION_AUTHORIZATION_v1' and a.get('authority')==expected,'explicit authorization authority required')
    require(a.get('approved') is True and a.get('execution_allowed') is True,'explicit approval required')
    require(a.get('mode')==plan['mode'] and a.get('scope')==SCOPE and a.get('plan_sha256')==plan_sha,'stale/wrong authorization binding')
    require(a.get('output')==str(Path(out).resolve()) and a.get('automatic_retry') is False,'authorization output/no-retry differs')
    require(sha(path)==digest,'authorization changed during validation')
    return digest


class WorkerGuard:
    """Load before NumPy. Counts are the canonical mirror of callback reservations."""
    @classmethod
    def from_request(cls,path,expected_sha256):
        require(sha(path)==expected_sha256,'worker request hash differs')
        request=read(path); require(request.get('schema')=='C09_D1_WORKER_REQUEST_v1','worker request schema')
        plan,psha=validate_plan(request['plan_path'])
        require(psha==request['plan_sha256'],'worker plan differs')
        out=Path(request['output'])
        ah=validate_authorization(request['authorization_path'],plan,psha,out)
        require(ah==request['authorization_sha256'],'worker authorization differs')
        identity=read(out/'execution_identity.json')
        require(identity['request_sha256']==expected_sha256 and identity['plan_sha256']==psha and identity['authorization_sha256']==ah,'controller/worker identity differs')
        require(Path(path).resolve()==out/'worker_request.json','request outside authorized output')
        require(list(resource.getrlimit(resource.RLIMIT_CPU))==request['CPU_limits'],'controller pre-exec CPU limits required')
        require(all(os.environ.get(k)=='1' for k in THREADS),'BLAS1 required before numeric imports')
        require(sha(path)==expected_sha256,'request changed during validation')
        self=cls(); self.request=request; self.request_path=Path(path); self.request_sha256=expected_sha256
        self.plan=plan; self.parameters=plan['worker_parameters']; self.repository=Path(plan['repository'])
        self.config=dict(plan['limits'])  # legacy table loader needs estimated_numeric_bytes.
        self.campaign=out; self.output=out/'worker'; self.output_path=self.output; self.output.mkdir(exist_ok=False)
        self.new_by_target={k:0 for k in HISTORY_BY_ID}; self.finished=False; self.stop_reason=None
        def cpu_soft(signum,frame):
            self.stop_reason='OS worker CPU soft limit reached';raise RuntimeError(self.stop_reason)
        signal.signal(signal.SIGXCPU,cpu_soft)
        self.checkpoint()
        return self

    @property
    def new_values(self):return sum(self.new_by_target.values())

    def checkpoint(self):
        if self.stop_reason is not None:raise RuntimeError(self.stop_reason)
        limits=self.plan['limits']; own=cpu()
        if own>=self.request['CPU_limits'][0]:
            self.stop_reason='worker soft CPU allocation reached';raise RuntimeError(self.stop_reason)
        require(self.request['controller_CPU_at_launch']+own<=limits['new_cpu_seconds'],'new stage CPU cap reached')
        require(self.plan['history']['cpu_seconds']+self.request['controller_CPU_at_launch']+own<=limits['cumulative_cpu_seconds'],'cumulative CPU cap reached')
        if rss()+self.request['controller_peak_RSS_at_launch']>limits['rss_bytes']:raise MemoryError('controller plus worker RSS cap reached')
        require(saved_bytes(self.output)<=self.request['worker_payload_bytes'],'worker payload byte cap reached')

    def check(self):self.checkpoint()  # unchanged runtime_adapter.load_table callback API.

    def reserve(self,n,target):
        require(not self.finished and type(n) is int and n>=1 and type(target) is int and str(target) in self.new_by_target,'positive LL reservation/known target required')
        self.checkpoint(); limits=self.plan['limits']; key=str(target)
        require(self.new_values+n<=limits['new_likelihood_values'],'new global LL cap before callback')
        require(self.new_by_target[key]+n<=limits['new_likelihood_per_target'],'new per-ID LL cap before callback')
        updated=dict(self.new_by_target); updated[key]+=n
        self.new_by_target=updated  # one canonical assignment; total is derived, not separately mutated.

    def write_bytes(self,name,data):
        require(not self.finished and name!='worker_end.json','reserved receipt name or finished worker')
        require(isinstance(data,bytes),'bytes required')
        # Bounded persistence remains available after a compute checkpoint fails.
        # New LL still requires reserve/checkpoint; final CPU/RSS is checked externally.
        require(saved_bytes(self.output)+len(data)<=self.request['worker_payload_bytes'],'payload byte ceiling before write')
        p=path_under(self.output,name); p.parent.mkdir(parents=True,exist_ok=True)
        write_new(p,data,bytes_value=True)

    def write_json(self,name,value):self.write_bytes(name,payload(value))

    def report(self):
        history=self.plan['history']; by={k:history['likelihood_by_target'][k]+n for k,n in self.new_by_target.items()}
        return dict(stage_likelihood_values=self.new_values,stage_likelihood_by_target=dict(self.new_by_target),
                    cumulative_likelihood_values=sum(by.values()),cumulative_likelihood_by_target=by,
                    worker_CPU_seconds_at_sample=cpu(),worker_peak_RSS_bytes=rss())

    def finish(self,status,result=None):
        require(not self.finished and status in ('COMPLETED','FAILED'),'one explicit final worker lifecycle status required')
        problems=[]
        try:
            verify_bindings(self.plan)
            require(sha(self.request['plan_path'])==self.request['plan_sha256'],'plan changed at worker end')
            require(sha(self.request['authorization_path'])==self.request['authorization_sha256'],'authorization changed at worker end')
            require(sha(self.request_path)==self.request_sha256,'request changed at worker end')
            self.checkpoint()
        except BaseException as error:problems.append(type(error).__name__+': '+str(error))
        record=dict(schema='C09_D1_WORKER_END_v1',status='WORKER_COMPLETED' if status=='COMPLETED' and not problems else 'WORKER_FAILED',
                    request_sha256=self.request_sha256,plan_sha256=self.request['plan_sha256'],inputs_and_resources_valid=not problems,
                    problems=problems,resources=self.report(),result=result,
                    sample_scope='Worker sample only; supervisor measures full child startup/exit externally')
        data=payload(record)
        require(len(data)<=self.plan['limits']['control_reserve_bytes']//4,'worker receipt exceeds reserved metadata budget')
        write_new(self.output/'worker_end.json',data,bytes_value=True); self.finished=True
        return record


def _run_child(command,out,limits,payload_limit,env,*,cpu_limit):
    hard=math.floor(cpu_limit)
    require(hard>=1,'less than one CPU second remains before spawn')
    soft=max(1,hard-1)
    def preexec():
        resource.setrlimit(resource.RLIMIT_CPU,(soft,hard))
        resource.setrlimit(resource.RLIMIT_FSIZE,(payload_limit,payload_limit))
    before=cpu(resource.RUSAGE_CHILDREN); start=time.perf_counter()
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,
                             preexec_fn=preexec,start_new_session=True)
    selector=selectors.DefaultSelector();selector.register(process.stdout,selectors.EVENT_READ)
    problems=[]; log_bytes=0
    def stop(reason):
        problems.append(reason)
        if process.poll() is None:
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
    try:
        with (out/'worker.log').open('xb') as log:
            while selector.get_map():
                for key,_ in selector.select(timeout=.1):
                    block=os.read(key.fd,16384)
                    if not block:selector.unregister(key.fileobj);continue
                    if log_bytes+len(block)>limits['log_cap_bytes']:
                        stop('worker log exceeds reserved log cap');continue
                    log.write(block);log_bytes+=len(block)
                if saved_bytes(out/'worker')>payload_limit+limits['control_reserve_bytes']//4:
                    stop('worker output exceeds payload and receipt reservation')
                if cpu()>limits['new_cpu_seconds']:stop('controller CPU alone exceeds stage cap')
            code=process.wait()
    except BaseException as error:
        stop('controller interruption: '+type(error).__name__+': '+str(error));code=process.wait()
    finally:
        selector.close();process.stdout.close()
    return dict(returncode=code,child_CPU_seconds=cpu(resource.RUSAGE_CHILDREN)-before,
                child_peak_RSS_bytes=rss(resource.RUSAGE_CHILDREN),wall_seconds=time.perf_counter()-start,
                operational_monitor_failures=problems,CPU_limits=[soft,hard],log_bytes=log_bytes)


def execute(plan_path,authorization_path,output):
    plan_path=Path(plan_path).resolve(); authorization_path=Path(authorization_path).resolve()
    plan,plan_sha=validate_plan(plan_path); out=Path(output)
    require(not out.is_symlink(),'output symlink forbidden'); out=out.resolve()
    auth_sha=validate_authorization(authorization_path,plan,plan_sha,out)
    require(not out.exists() and out.parent.is_dir(),'new output under existing parent required')
    require(not plan_path.is_relative_to(out) and not authorization_path.is_relative_to(out),'output overlaps plan/authorization')
    for name in plan['bindings']:
        p=path_under(Path(plan['repository']),name).resolve()
        require(p!=out and not p.is_relative_to(out),'output overlaps frozen input')
    limits=plan['limits']; history=plan['history']; parent_cpu=cpu()
    remaining=min(limits['new_cpu_seconds']-parent_cpu,limits['cumulative_cpu_seconds']-history['cpu_seconds']-parent_cpu)
    require(math.floor(remaining)>=1 and rss()<limits['rss_bytes'],'no CPU/RSS room for fresh worker')
    worker_payload=min(limits['new_output_bytes'],limits['cumulative_output_bytes']-history['output_bytes'])-limits['control_reserve_bytes']-limits['log_cap_bytes']
    out.mkdir(exist_ok=False)
    request=dict(schema='C09_D1_WORKER_REQUEST_v1',plan_path=str(plan_path),plan_sha256=plan_sha,
                 authorization_path=str(authorization_path),authorization_sha256=auth_sha,output=str(out),
                 controller_CPU_at_launch=parent_cpu,controller_peak_RSS_at_launch=rss(),worker_payload_bytes=worker_payload,
                 CPU_limits=[max(1,math.floor(remaining)-1),math.floor(remaining)])
    req=out/'worker_request.json';write_new(req,request);request_sha=sha(req)
    reserved={k:limits['new_likelihood_per_target'] for k in HISTORY_BY_ID}
    # When global is smaller (TOY), per-ID limits overlap that single global ceiling.
    write_new(out/'execution_identity.json',dict(schema='C09_D1_EXECUTION_IDENTITY_v1',plan_sha256=plan_sha,
        authorization_sha256=auth_sha,request_sha256=request_sha,history=history,
        stage_reserved_upper_values=limits['new_likelihood_values'],stage_reserved_by_target=reserved,
        reservation_is_not_a_claim_of_completed_work=True,automatic_retry=False))
    command=[sys.executable,'-B',str(path_under(Path(plan['repository']),plan['worker'])),
             '--request',str(req),'--request-sha256',request_sha]
    env=dict(os.environ);env.update({k:'1' for k in THREADS});env['PYTHONDONTWRITEBYTECODE']='1'
    measured=None;observed=None;problems=[];receipt_valid=False;bindings_valid=True
    try:
        measured=_run_child(command,out,limits,worker_payload,env,cpu_limit=remaining)
        if measured['returncode']!=0:problems.append('worker nonzero exit')
        problems+=measured['operational_monitor_failures']
        end=out/'worker/worker_end.json'
        if end.exists():
            observed=read(end)
            require(observed.get('schema')=='C09_D1_WORKER_END_v1' and observed.get('request_sha256')==request_sha and observed.get('plan_sha256')==plan_sha,'worker end identity differs')
            r=observed['resources'];by=counts(r['stage_likelihood_by_target'])
            require(r['stage_likelihood_values']==sum(by.values())<=limits['new_likelihood_values'],'worker global LL receipt exceeds reservation')
            require(all(n<=limits['new_likelihood_per_target'] for n in by.values()),'worker per-ID LL receipt exceeds reservation')
            expected={k:history['likelihood_by_target'][k]+n for k,n in by.items()}
            require(r['cumulative_likelihood_by_target']==expected and r['cumulative_likelihood_values']==sum(expected.values()),'worker historical LL accounting differs')
            receipt_valid=True
            if observed.get('status')!='WORKER_COMPLETED' or observed.get('inputs_and_resources_valid') is not True:problems.append('worker did not complete validated lifecycle')
        else:problems.append('worker receipt absent; actual LL consumption unknown within reservation')
    except BaseException as error:problems.append(type(error).__name__+': '+str(error))
    try:
        verify_bindings(plan)
        require(sha(plan_path)==plan_sha and sha(authorization_path)==auth_sha and sha(req)==request_sha,'plan/auth/request changed at controller end')
    except BaseException as error:
        bindings_valid=False;problems.append('final input check: '+str(error))
    if measured is None:
        # Unexpected launcher failure cannot manufacture a final child measurement.
        problems.append('complete external child measurement unavailable')
    child_cpu=0. if measured is None else measured['child_CPU_seconds']
    child_peak=0 if measured is None else measured['child_peak_RSS_bytes']
    own_cpu=cpu(); stage_cpu=own_cpu+child_cpu; total_cpu=history['cpu_seconds']+stage_cpu
    peak_sum=rss()+child_peak; bytes_before=saved_bytes(out)
    within=(stage_cpu<=limits['new_cpu_seconds'] and total_cpu<=limits['cumulative_cpu_seconds'] and peak_sum<=limits['rss_bytes']
            and bytes_before<=limits['new_output_bytes'] and history['output_bytes']+bytes_before<=limits['cumulative_output_bytes'])
    if not within:problems.append('final resource cap failed')
    # Only a validated worker end provides exact observed counts. Otherwise keep upper reservation.
    validated=receipt_valid and bindings_valid
    resource_record=dict(historical_CPU_seconds=history['cpu_seconds'],controller_CPU_seconds=own_cpu,
        new_child_CPU_seconds_including_startup_exit=child_cpu if measured is not None else None,
        stage_CPU_seconds=stage_cpu if measured is not None else None,cumulative_CPU_seconds=total_cpu if measured is not None else None,
        controller_peak_RSS_bytes=rss(),child_peak_RSS_bytes=child_peak if measured is not None else None,
        sum_of_controller_and_child_peak_RSS_bytes=peak_sum if measured is not None else None,
        observed_worker_LL=observed['resources'] if validated else None,
        stage_reserved_upper_values=limits['new_likelihood_values'],stage_reserved_by_target=reserved,
        continuation_charge_policy='Use validated observed counts; if unavailable carry the whole upper reservation, never zero or automatic retry.',
        saved_bytes_before_final_receipt=bytes_before,inherited_output_bytes=history['output_bytes'],
        historical_real_products=history.get('real_products'),historical_sky_points=history.get('sky_points'),new_ORF=0,new_sky=0,new_draws=0)
    record=dict(schema='C09_D1_SUPERVISOR_END_v1',status='CONTROLLER_COMPLETED' if not problems else 'CONTROLLER_FAILED_NO_AUTOMATIC_RETRY',
        plan_sha256=plan_sha,authorization_sha256=auth_sha,request_sha256=request_sha,
        worker_end_sha256=sha(out/'worker/worker_end.json') if (out/'worker/worker_end.json').is_file() else None,
        problems=problems,within_resource_limits=within,resources=resource_record,worker=measured,
        exact_worker_LL_receipt_available=validated,no_scientific_approval=True,
        scope='Final source checks precede CPU sample; child imports/exit included by RUSAGE_CHILDREN. Controller receipt serialization/exit follow sample. RSS uses conservative sum of process peaks; not a hard OS RSS guarantee.')
    data=payload(record)
    require(saved_bytes(out)+len(data)<=limits['new_output_bytes'] and history['output_bytes']+saved_bytes(out)+len(data)<=limits['cumulative_output_bytes'],'final receipt output cap')
    write_new(out/'execution_end.json',data,bytes_value=True)
    return record


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=('preflight','execute'))
    p.add_argument('--plan',required=True,type=Path);p.add_argument('--authorization',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args()
    if a.command=='preflight':
        plan,h=validate_plan(a.plan);print(json.dumps(dict(status='PREFLIGHT_ONLY_NO_EXECUTION',plan_sha256=h,mode=plan['mode'],limits=plan['limits']),sort_keys=True));return 0
    require(a.authorization is not None and a.output is not None,'execute requires authorization and new output')
    result=execute(a.plan,a.authorization,a.output);print(json.dumps(result,sort_keys=True))
    return 0 if result['status']=='CONTROLLER_COMPLETED' else 1


if __name__=='__main__':raise SystemExit(main())
