"""Bounded synthetic subprocess tests; no numerical packages or scientific data."""
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys
import tempfile
import time
import unittest
resource.setrlimit(resource.RLIMIT_CPU,(30,31))
import supervisor as s

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
CASES=[]


class SupervisorTests(unittest.TestCase):
    def fixture(self,mode='success'):
        temporary=tempfile.TemporaryDirectory(prefix='TOY_',dir=HERE)
        self.addCleanup(temporary.cleanup);base=Path(temporary.name)
        inp=base/'input.txt';inp.write_text('synthetic input\n')
        limits=dict(s.CAPS,new_cpu_seconds=2. if mode=='cpu' else 10.,new_likelihood_values=28,
                    new_likelihood_per_target=2,new_output_bytes=256*1024,rss_bytes=128*1024**2)
        bindings={str(p.relative_to(ROOT)):s.sha(p) for p in (HERE/'supervisor.py',HERE/'toy_worker.py',inp)}
        plan=dict(schema='C09_D1_SUPERVISOR_PLAN_v1',mode='TOY',scope=s.SCOPE,
                  execution_enabled_by_default=False,repository=str(ROOT),bindings=bindings,
                  worker=str((HERE/'toy_worker.py').relative_to(ROOT)),worker_parameters=dict(toy_mode=mode,toy_input=str(inp)),
                  history=dict(cpu_seconds=0.,likelihood_values=0,likelihood_by_target={k:0 for k in s.HISTORY_BY_ID},output_bytes=0),limits=limits)
        pp=base/'plan.json';s.write_new(pp,plan);out=base/'output'
        auth=dict(schema='C09_D1_EXECUTION_AUTHORIZATION_v1',authority='SYNTHETIC_TEST_ONLY',approved=True,
                  execution_allowed=True,mode='TOY',scope=s.SCOPE,plan_sha256=s.sha(pp),output=str(out),automatic_retry=False)
        ap=base/'authorization.json';s.write_new(ap,auth)
        return base,pp,ap,out

    def run_case(self,mode):
        base,pp,ap,out=self.fixture(mode)
        r=subprocess.run([sys.executable,'-B',str(HERE/'supervisor.py'),'execute','--plan',str(pp),'--authorization',str(ap),'--output',str(out)],capture_output=True,text=True)
        end=json.loads((out/'execution_end.json').read_text())
        CASES.append(dict(mode=mode,exit_code=r.returncode,end=end,stdout_bytes=len(r.stdout),stderr=r.stderr))
        self.assertLessEqual(s.saved_bytes(out),256*1024)
        return r,end,out,pp,ap

    def test_01_success_and_no_overwrite(self):
        r,end,out,pp,ap=self.run_case('success')
        self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(end['status'],'CONTROLLER_COMPLETED')
        self.assertTrue(end['exact_worker_LL_receipt_available'])
        self.assertEqual(end['resources']['observed_worker_LL']['stage_likelihood_values'],1)
        self.assertGreaterEqual(end['resources']['new_child_CPU_seconds_including_startup_exit'],end['resources']['observed_worker_LL']['worker_CPU_seconds_at_sample'])
        digest=s.sha(out/'execution_end.json')
        second=subprocess.run([sys.executable,'-B',str(HERE/'supervisor.py'),'execute','--plan',str(pp),'--authorization',str(ap),'--output',str(out)],capture_output=True,text=True)
        self.assertNotEqual(second.returncode,0);self.assertEqual(s.sha(out/'execution_end.json'),digest)

    def test_02_explicit_authorization_and_stale_hash(self):
        base,pp,ap,out=self.fixture()
        auth=s.read(ap);auth['approved']=False;ap.write_text(json.dumps(auth))
        r=subprocess.run([sys.executable,'-B',str(HERE/'supervisor.py'),'execute','--plan',str(pp),'--authorization',str(ap),'--output',str(out)],capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0);self.assertFalse(out.exists())
        auth['approved']=True;auth['plan_sha256']='0'*64;ap.write_text(json.dumps(auth))
        r=subprocess.run([sys.executable,'-B',str(HERE/'supervisor.py'),'execute','--plan',str(pp),'--authorization',str(ap),'--output',str(out)],capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0);self.assertFalse(out.exists())

    def test_03_failure_retains_charged_counter(self):
        r,end,*_=self.run_case('callback_failure')
        self.assertNotEqual(r.returncode,0);self.assertTrue(end['exact_worker_LL_receipt_available'])
        self.assertEqual(end['resources']['observed_worker_LL']['stage_likelihood_values'],1)

    def test_04_per_target_reservation_precedes_callback(self):
        r,end,*_=self.run_case('limit')
        self.assertNotEqual(r.returncode,0)
        self.assertEqual(end['resources']['observed_worker_LL']['stage_likelihood_values'],0)

    def test_05_missing_receipt_preserves_upper_reservation(self):
        r,end,*_=self.run_case('crash')
        self.assertNotEqual(r.returncode,0);self.assertFalse(end['exact_worker_LL_receipt_available'])
        self.assertIsNone(end['resources']['observed_worker_LL'])
        self.assertEqual(end['resources']['stage_reserved_upper_values'],28)
        self.assertGreater(end['resources']['new_child_CPU_seconds_including_startup_exit'],0)

    def test_06_preexec_CPU_kill_still_has_external_final_cost(self):
        r,end,*_=self.run_case('cpu')
        self.assertNotEqual(r.returncode,0)
        # SIGXCPU may permit the new finalizer to save a charged receipt before
        # the hard limit. Both outcomes must preserve cost; neither is success.
        if end['exact_worker_LL_receipt_available']:
            self.assertEqual(end['resources']['observed_worker_LL']['stage_likelihood_values'],1)
        else:self.assertEqual(end['resources']['stage_reserved_upper_values'],28)
        self.assertGreater(end['resources']['new_child_CPU_seconds_including_startup_exit'],.5)
        self.assertLess(end['resources']['stage_CPU_seconds'],2)

    def test_07_payload_quota_and_FSIZE_failures_preserved(self):
        for mode in ('output','fsize'):
            r,end,*_=self.run_case(mode)
            self.assertNotEqual(r.returncode,0)
            self.assertEqual(end['status'],'CONTROLLER_FAILED_NO_AUTOMATIC_RETRY')

    def test_08_bounded_log_and_RSS_checkpoint(self):
        for mode in ('log','rss'):
            r,end,out,*_=self.run_case(mode)
            self.assertNotEqual(r.returncode,0)
            self.assertEqual(end['status'],'CONTROLLER_FAILED_NO_AUTOMATIC_RETRY')
            if mode=='rss':self.assertTrue((out/'worker/preserved_failure.json').exists())

    def test_09_final_input_rehash_detects_synthetic_mutation(self):
        r,end,*_=self.run_case('mutation')
        self.assertNotEqual(r.returncode,0);self.assertFalse(end['exact_worker_LL_receipt_available'])
        self.assertTrue(any('final input check' in p for p in end['problems']))

    def test_10_malformed_receipt_cannot_reset_to_zero_cost(self):
        r,end,*_=self.run_case('bad_receipt')
        self.assertNotEqual(r.returncode,0);self.assertFalse(end['exact_worker_LL_receipt_available'])
        self.assertIsNone(end['resources']['observed_worker_LL'])

    def test_11_real_D1_history_and_caps_metadata_only(self):
        _,pp,_,_=self.fixture()
        plan=s.read(pp);plan['mode']='D1';plan['limits']=dict(s.CAPS)
        plan['history']=dict(cpu_seconds=296.087524,likelihood_values=210588,likelihood_by_target=s.HISTORY_BY_ID,
                             output_bytes=0,real_products=214577271056,sky_points=74530432)
        pp.write_text(json.dumps(plan));s.validate_plan(pp)
        self.assertEqual(sum(s.HISTORY_BY_ID.values()),210588)
        plan['history']['likelihood_by_target']=dict(s.HISTORY_BY_ID);plan['history']['likelihood_by_target']['0']-=1
        pp.write_text(json.dumps(plan))
        with self.assertRaises(ValueError):s.validate_plan(pp)


if __name__=='__main__':
    started=time.perf_counter();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SupervisorTests))
    used=s.cpu()+s.cpu(resource.RUSAGE_CHILDREN);peak=max(s.rss(),s.rss(resource.RUSAGE_CHILDREN))
    report=dict(schema='C09_D1_SUPERVISOR_SYNTHETIC_TESTS_v1',tests=result.testsRun,passed=result.wasSuccessful(),
        failures=len(result.failures),errors=len(result.errors),CPU_seconds_controller_plus_children=used,
        max_process_RSS_bytes=peak,wall_seconds=time.perf_counter()-started,within_test_caps=used<=30 and peak<=128*1024**2,
        sources={p.name:s.sha(p) for p in (HERE/'supervisor.py',HERE/'toy_worker.py',Path(__file__))},cases=CASES,
        actual_LL=0,ORF=0,banks=0,draws=0,real_NPZ_arrays_read=0,real_D1_authorization_created=False)
    s.write_new(HERE/'toy_results_final3.json',report)
    raise SystemExit(0 if report['passed'] and report['within_test_caps'] else 1)
