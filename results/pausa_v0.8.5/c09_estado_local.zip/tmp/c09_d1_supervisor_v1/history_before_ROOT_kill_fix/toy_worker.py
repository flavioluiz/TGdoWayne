"""Synthetic subprocess fixtures only: no numerical or physical imports."""
import argparse
import json
import os
from pathlib import Path
import sys
from supervisor import WorkerGuard


def main():
    p=argparse.ArgumentParser();p.add_argument('--request',required=True);p.add_argument('--request-sha256',required=True)
    a=p.parse_args();g=WorkerGuard.from_request(a.request,a.request_sha256);mode=g.parameters['toy_mode']
    failed=False;message=None
    try:
        if mode=='success':
            assert g.output_path==g.output and g.config['estimated_numeric_bytes']==g.plan['limits']['estimated_numeric_bytes']
            g.check()
            g.reserve(1,0);g.write_json('TOY.json',dict(toy=True,actual_physical_LL=0))
        elif mode=='callback_failure':
            g.reserve(1,0);raise RuntimeError('TOY failure after synthetic reservation')
        elif mode=='limit':g.reserve(3,0)
        elif mode=='crash':
            g.reserve(1,0);os._exit(23)
        elif mode=='cpu':
            g.reserve(1,0)
            while True:pass
        elif mode=='output':g.write_bytes('too_large.bin',b'x'*(g.request['worker_payload_bytes']+1))
        elif mode=='fsize':
            with (g.output/'direct_TOY.bin').open('xb') as f:f.write(b'x'*(2*g.request['worker_payload_bytes']))
        elif mode=='log':
            os.write(1,b'x'*(g.plan['limits']['log_cap_bytes']*4))
        elif mode=='rss':
            g.request['controller_peak_RSS_at_launch']=g.plan['limits']['rss_bytes'];g.checkpoint()
        elif mode=='mutation':Path(g.parameters['toy_input']).write_text('mutated synthetic input\n')
        elif mode=='bad_receipt':pass
        else:raise ValueError('unknown TOY mode')
    except BaseException as error:
        failed=True;message=type(error).__name__+': '+str(error)
        if mode=='rss':g.write_json('preserved_failure.json',dict(synthetic=True,reason=message))
    end=g.finish('FAILED' if failed else 'COMPLETED',dict(toy=True,mode=mode,message=message,physical_calls=0))
    if mode=='bad_receipt':
        # Deliberately invalid local TOY receipt; never an actual scientific record.
        file=g.output/'worker_end.json';value=json.loads(file.read_text())
        value['resources']['stage_likelihood_by_target']['0']=-1
        file.write_text(json.dumps(value))
    return 1 if failed or end['status']!='WORKER_COMPLETED' else 0


if __name__=='__main__':raise SystemExit(main())
