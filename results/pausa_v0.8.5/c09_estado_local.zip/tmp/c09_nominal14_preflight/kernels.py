"""Conditional C09 scenario adapter; reference normalized CN/normal formulas."""
from numbers import Real
import numpy as np
from inference.model import covariance_batch
from inference.likelihood_reference import cn_logpdf,normal_logpdf
from pta.statistics import quadratic_moments,compress_independent_moments,compress_frequencies
from pta.simulation import paired_physical_and_gaussian,JULIAN_YEAR_SECONDS


class FixedNuisanceCovariance:
 def __init__(self,exp,eta,*,contaminant_ratio=0.):
  self.e={k:(np.array(v,copy=True) if isinstance(v,np.ndarray) else v) for k,v in exp.items()}
  self.K=len(self.e['f']);self.P=len(self.e['points']);self.D=len(self.e['H'])
  eta=np.asarray(eta,float)
  if eta.shape!=(4,) or not np.isfinite(eta).all():raise ValueError('Four finite known nuisances required')
  if isinstance(contaminant_ratio,bool) or not isinstance(contaminant_ratio,Real) or not np.isfinite(contaminant_ratio) or contaminant_ratio<0:raise ValueError('Nonnegative finite contaminant power required')
  empty=np.zeros((self.K,self.P,self.P),complex)
  noise,w=covariance_batch(eta[None],empty,self.e)
  self.noise=noise[0].copy();self.pg=w[0,:,0].copy()
  # C09 fixed monopolar spectrum, normalized at f_piv=1/year.
  # It equals rho*GW in the central slope13/3 case, never fitted from data.
  pm=contaminant_ratio*10**(2*eta[0])*JULIAN_YEAR_SECONDS**3/(12*np.pi*np.pi)*(self.e['f']*JULIAN_YEAR_SECONDS)**(-13/3)/self.e['scale']
  self.noise+=pm[:,None,None]*np.ones((self.P,self.P))
  if not np.isfinite(self.noise).all() or not np.isfinite(self.pg).all():raise ValueError('Spectral overflow')
  np.linalg.cholesky(self.noise)
  self.noise.flags.writeable=False;self.pg.flags.writeable=False

 def __call__(self,gamma):
  a=np.asarray(gamma,complex)
  if a.ndim!=4 or a.shape[1:]!=(self.K,self.P,self.P) or not np.isfinite(a).all():raise ValueError('Gamma must be finite (B,K,P,P)')
  if np.max(abs(a-a.swapaxes(-1,-2).conj()),initial=0)>1e-12:raise ValueError('Gamma must be Hermitian')
  if np.linalg.eigvalsh(a).min(initial=0)<-1e-12:raise ValueError('Gamma must be PSD without repair')
  return self.pg[None,:,None,None]*a+self.noise[None]


def generate_row(exp,row,gamma,seed):
 c=FixedNuisanceCovariance(exp,row['eta_physical_coordinates'],contaminant_ratio=row['generation_contaminant_ratio'])(gamma[None])[0]
 # Independent seed per engineering row; no numerical nodes or training use this RNG.
 rng=np.random.default_rng(np.random.SeedSequence([seed,row['id'],row['id']]))
 q,x,g=paired_physical_and_gaussian(c,exp['H'],1,rng)
 return {'q':q,'x_physical':x,'x_gaussian':g}


class ConditionalKernel:
 def __init__(self,exp,row,data,anchor_gamma):
  self.row=dict(row);self.e=exp;self.name=row['analysis']
  allowed={'A0_CN','A_G','B_CN_full_variable','B_G_full_variable','B_G_diagonal_variable','B_G_full_fixed','B_G_diagonal_fixed'}
  if self.name not in allowed:raise ValueError('Unsupported nominal14 analysis')
  self.covariance=FixedNuisanceCovariance(exp,row['eta_physical_coordinates'],contaminant_ratio=row['analysis_contaminant_ratio'])
  self.data={k:np.array(v,copy=True) for k,v in data.items()}
  K,P,D=self.covariance.K,self.covariance.P,self.covariance.D
  if self.data['q'].shape!=(1,K,P) or self.data['x_physical'].shape!=(1,K,D) or self.data['x_gaussian'].shape!=(1,K,D):raise ValueError('Exactly one complete engineering row required')
  if not all(np.isfinite(x).all() for x in self.data.values()):raise ValueError('Nonfinite data')
  for a in self.data.values():a.flags.writeable=False
  _,sc=quadratic_moments(self.covariance(np.asarray(anchor_gamma)[None]),exp['H'])
  _,self.anchor_cov=compress_independent_moments(np.zeros((1,K,D)),sc,exp['weights'])

 def moments(self,gamma):
  return quadratic_moments(self.covariance(gamma),self.e['H'])

 def __call__(self,gamma):
  if self.name=='A0_CN':return cn_logpdf(self.covariance(gamma),self.data['q'])[:,0]
  mu,cov=self.moments(gamma)
  key='x_gaussian' if '_G' in self.name else 'x_physical'
  observed=self.data[key]
  if self.name=='A_G':return normal_logpdf(mu,cov,observed)[:,0]
  mb,cb=compress_independent_moments(mu,cov,self.e['weights'])
  if self.name.endswith('_fixed'):cb=np.broadcast_to(self.anchor_cov,cb.shape)
  if '_diagonal_' in self.name:
   diagonal=np.diagonal(cb,axis1=-2,axis2=-1)
   cb=diagonal[:,:,None]*np.eye(cb.shape[-1])[None]
  y=compress_frequencies(observed,self.e['weights'])[:,None,:]
  return normal_logpdf(mb[:,None,:],cb[:,None],y)[:,0]
