"""Only new adapter/contracts; no duplicate ORF or full integrator suite."""
import json,math,tempfile,unittest,subprocess,sys
from pathlib import Path
import numpy as np
from scipy.stats import multivariate_normal
from planning import HERE,preflight,alpha_nodes
from kernels import FixedNuisanceCovariance,ConditionalKernel
from pta.statistics import quadratic_moments,compress_independent_moments,compress_frequencies,proper_complex_real_covariance
from pta.simulation import JULIAN_YEAR_SECONDS as Y


def toy():
 P=3;K=2
 h=np.array([np.diag([1.,0,0]),np.diag([0,1.,0]),[[0,.5j,0],[-.5j,0,0],[0,0,0]]],complex)
 e={'points':np.eye(3),'red':np.array([.7,1.,1.3]),'sigma':np.array([1.,1.2,1.4]),'f':np.array([1.,2.])/Y,'scale':np.ones(K)*Y**3/(12*np.pi*np.pi),'dt':Y**3/(24*np.pi*np.pi),'H':h,'weights':np.array([.3,.7])}
 g=np.array([[[1,.12+.2j,.05],[.12-.2j,1,-.1j],[.05,.1j,1]],[[1,-.2j,0],[.2j,1,.07],[0,.07,1]]])
 d={'q':np.array([[[.2+.3j,.5-.1j,-.2+.7j],[.4-.2j,-.5+.4j,.7+.1j]]]),'x_physical':np.array([[[.5,.8,.1],[.3,1.,-.2]]]),'x_gaussian':np.array([[[.1,.7,-.1],[.5,.9,.3]]])}
 return e,g,d


class CandidateTests(unittest.TestCase):
 def test_C09_covariance_factorial_against_scipy(self):
  e,g,d=toy();batch=np.stack([g,g*.8]);row={'eta_physical_coordinates':[0.,1.7,-.3,.1],'analysis_contaminant_ratio':0.}
  for name in ['A_G','B_CN_full_variable','B_G_full_variable','B_G_diagonal_variable','B_G_full_fixed','B_G_diagonal_fixed']:
   row['analysis']=name;k=ConditionalKernel(e,row,d,g);got=k(batch)
   c=k.covariance(batch);mu,sc=quadratic_moments(c,e['H']);y=d['x_gaussian' if '_G' in name else 'x_physical'][0]
   want=[]
   for i in range(len(batch)):
    if name=='A_G':want.append(sum(multivariate_normal.logpdf(y[j],mean=mu[i,j],cov=sc[i,j]) for j in range(2)));continue
    mb,cb=compress_independent_moments(mu[i],sc[i],e['weights'])
    if name.endswith('_fixed'):cb=k.anchor_cov[0]
    if '_diagonal_' in name:cb=np.diag(np.diag(cb))
    want.append(multivariate_normal.logpdf(compress_frequencies(y,e['weights']),mean=mb,cov=cb))
   np.testing.assert_allclose(got,want,atol=2e-12,rtol=0)

 def test_proper_CN_against_independent_real_representation(self):
  e,g,d=toy();row={'eta_physical_coordinates':[0.,1.7,-.3,.1],'analysis_contaminant_ratio':0.,'analysis':'A0_CN'}
  k=ConditionalKernel(e,row,d,g);actual=k(g[None])[0];c=k.covariance(g[None])[0]
  expected=0.
  for cov,q in zip(c,d['q'][0]):expected+=multivariate_normal.logpdf(np.r_[q.real,q.imag],mean=np.zeros(6),cov=proper_complex_real_covariance(cov))
  self.assertAlmostEqual(actual,expected,places=12)

 def test_fixed_covariance_keeps_variable_mean(self):
  e,g,d=toy();row={'eta_physical_coordinates':[0.,1.7,-.3,.1],'analysis_contaminant_ratio':0.,'analysis':'B_G_full_fixed'}
  k=ConditionalKernel(e,row,d,g);mu,cv=k.moments(np.stack([g,.5*g]));self.assertGreater(np.max(abs(mu[0]-mu[1])),.01)
  self.assertGreater(abs(k(np.stack([g,.5*g]))[0]-k(np.stack([g,.5*g]))[1]),.001)

 def test_contaminant_cross_moments_and_guards(self):
  e,g,d=toy();base=FixedNuisanceCovariance(e,[0.,13/3,-.3,.1]);extra=FixedNuisanceCovariance(e,[0.,13/3,-.3,.1],contaminant_ratio=1.)
  c0=base(g[None]);c1=extra(g[None]);delta=c1-c0
  self.assertTrue(np.all(np.linalg.eigvalsh(delta)>-1e-12))
  _,s0=quadratic_moments(c0,e['H']);_,sd=quadratic_moments(delta,e['H']);_,s1=quadratic_moments(c1,e['H'])
  self.assertGreater(np.max(abs(s1-s0-sd)),.1)
  for invalid in [np.full_like(g[None],np.nan),-np.eye(3)[None,None].repeat(2,axis=1)]:
   with self.assertRaises(ValueError):base(invalid)
  with self.assertRaises(ValueError):FixedNuisanceCovariance(e,[0,0,0,0],contaminant_ratio=True)

 def test_frozen_preflight_and_actual_GL_node_recipe(self):
  c=json.loads((HERE/'config.json').read_text());r=preflight(c)
  self.assertEqual(r['status'],'READY_FOR_ROOT_REVIEW_NO_EXECUTION')
  self.assertEqual(r['new_ORFs_executed'],0);self.assertEqual(r['PTA_logL_executed'],0)
  import sys
  sys.path.insert(0,str(HERE.parent/'c09_integrator'))
  from integrator import Posterior1D,MassPrior
  for name in c['quadrature']['prior_names']:
   for order in [32,64]:
    obj=Posterior1D(lambda u:np.zeros_like(u),MassPrior(name),order=order)
    np.testing.assert_array_equal(obj._u,c['quadrature']['GL_mass_nodes'][name][str(order)])

 def test_no_approval_or_overwrite_and_output_cap(self):
  import run_nominal14 as runner
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);runner.ACTIVE_OUTPUT_BUDGET=(root,30)
   runner.write_new(root/'a.json',{'ok':np.bool_(True)})
   self.assertIs(json.loads((root/'a.json').read_text())['ok'],True)
   with self.assertRaises(FileExistsError):runner.write_new(root/'a.json',{'a':1})
   with self.assertRaises(RuntimeError):runner.write_new(root/'b.json',{'long':'x'*100})
   self.assertFalse((root/'b.json').exists())
  runner.ACTIVE_OUTPUT_BUDGET=None
  denied=subprocess.run([sys.executable,str(HERE/'run_nominal14.py'),'--execute'],capture_output=True,text=True)
  self.assertNotEqual(denied.returncode,0);self.assertIn('--approval',denied.stderr)

if __name__=='__main__':unittest.main()
