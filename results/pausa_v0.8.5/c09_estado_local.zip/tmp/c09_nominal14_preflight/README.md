# C09 nominal14: candidato executável para revisão

**Nenhuma ORF, likelihood PTA ou realização física foi calculada.** O comando padrão executa apenas preflight, conferência de hashes, nós e estimativas. O piloto requer aprovação ROOT explícita, vinculada aos hashes exatos e ao estágio. As duas misturas de distância do desenho anterior (IDs14–15) permanecem excluídas e com orçamento pendente.

O pacote implementa um piloto de engenharia condicional em14 alvos da geometria C07:12 pulsares,4 frequências positivas,T4,5anos,L300–1000anos-luz, escala e estimadores Re/Im/autos originais. Nuisances são conhecidos em cada cenário. Os alvos têm massas fixas previamente declaradas e seeds novas; não constituem14 realizações SBC nem substituem uma análise5D. Resultados entre linhas diferentes não devem ser interpretados como contraste pareado científico do fatorial: cada linha testa seu kernel; os testes TOY comparam as variantes usando o mesmo vetor observado.

## Arquivos e estágios

- `config.json`:14 alvos, nuisances, massas, seeds, nós GL e sondas independentes enumerados, tolerâncias, resolução e limites. SHA no preflight executável.
- `planning.py`: geometria/nós/estimativas, sem avaliar ORFs ou logL. `preflight.json` é o resumo aritmético; `executable_preflight.json` acrescenta hashes de fontes/configuração/tabela.
- `kernels.py`: adaptador dos kernels normalizados de referência e dos momentos quadráticos já existentes. Não altera arquivos ROOT.
- `run_nominal14.py`: dois estágios físicos possíveis, ambos desabilitados sem `--execute` e aprovação válida.
- `test_candidate.py`, `light_validation_final.json`: seis testes leves dos adaptadores e do bloqueio operacional, descritos adiante.

O estágio **backend** calcula as ORFs harmônicas em16 massas, confronta resoluções, dois pares de céu, gera os14 dados de engenharia e compara as likelihoods dos cenários usando ORF exata versus tabela. São448 avaliações de logL nesse estágio (14×16×2), se todos os gates anteriores passarem. Logo, uma futura aprovação desse estágio deve abranger explicitamente essas gerações/logL, além das ORFs; não é uma aprovação de posteriores.

O estágio **pilot** só aceita um backend concluído com sucesso, com identidade, hashes dos dados/ORFs e fontes inalteradas. Usa esses dados congelados para integrais1D, CDFs, quatro brackets, média/segundo momento, KL e PIT de logL. Seu resultado retém flags separadas e todos os IDs; nenhum arquivo existente é sobrescrito. A aprovação do segundo estágio deve incluir o SHA do resultado do backend. Os600sCPU são combinados: o tempo registrado do backend é subtraído do disponível no piloto.

## Nós, resoluções e independência

As16 massas completas são[0,.001,.05,.1,.2,.33,.5,.71,.8,.9,.93,.99,.995,.9999,1−10⁻⁸,1]. Incluem todas as verdades necessárias e a âncora fixa u=.5. Usa-se **β_k(u)=√[(1−u/k)(1+u/k)]**, com fase real y_k de cada frequência. Usar β1 em todos os canais seria C_beta e não é o backend físico nominal.

| Canal | H00:(ell,n_mu) | H01:(ell,n_mu) | H11:(ell,n_mu) |
|---|---|---|---|
| 1 |1496,3012|1496,3092|1536,3092|
| 2 |2892,5805|2892,5885|2932,5885|
| 3 |4288,8597|4288,8677|4328,8677|
| 4 |5685,11390|5685,11470|5725,11470|

H00→H01 controla os nós, H01→H11 o corte harmônico, com corte comum a todos os pulsares/pares. Cada comparação exige diferença absoluta≤1e−8 e autovalor mínimo≥−1e−12, sem clipping. Há192 matrizes de frequência/resolução. A fase nominal máxima é≈5585rad; não se extrapola a geometria para as distâncias alteradas.

Céu independente: K1,u=.5,par(3,8) e K1,u=.995,par(0,11). As regras são3012×6024 e3092×6184, com refinamento direto e confronto harmônico, ambos≤1e−7. Esse controle cobre dois pares no primeiro canal. Os demais canais apoiam-se nos três níveis harmônicos novos e nos antecedentes independentes C05/C07; não se declara que cada entrada tenha sido novamente conferida por céu direto.

A tabela nominal é a C07 beta8336, SHA `75632dfbdd9cce8b60b9f760a3177a76798a4adb7ac9ccc724092aeaf53ad70d`. O interpolador mantém a condição de paridade no limiar e seus controles Bernstein. Qualquer fallback inesperado é recusado. Sua aprovação histórica é finita; os novos cenários são confrontados nas16 massas, com diferença de logL≤.001. A diferença matricial da tabela é registrada descritivamente, sem aplicar a ela o gate harmônico de1e−8 por associação indevida.

Na integração, GL32/64 usa os painéis originais emα=asin(u). Os nós calculados em runtime devem coincidir exatamente com os enumerados na configuração para cada priori. A exploração independente usa512 e1024 nós internos de regras compostas emβ, mais limites do suporte: eles são distintos da GL emα e não dependem das verdades ou dos resultados. Os16 nós ORF sparse e essas sondas têm papéis diferentes: as sondas avaliam a likelihood com a tabela; não disparam silenciosamente novas ORFs.

A referência integra em v=F_prior(u), por GK21 vetorial, com32 painéis uniformes nessa coordenada e cortes diagnósticos. Assim compartilha avaliações de Z, momentos e KL, sem repetir uma integral completa por corte. Insucesso reportado pelo integrador ou avisos preservados impedem aprovação. Quantis usam os extremos dos brackets; não se força F(no centro)=p. Cruzamentos do evento logL são refinados em duas grades independentes e integrados por GK; falta de cruzamentos, platôs suspeitos, divergência de topologia observada ou massa de faixa excessiva mantêm o PIT não resolvido.

O pico estreito de `../c09_operational_pilot/` continua sendo contraexemplo à certificação global: inclusive GK cega pode perdê-lo. Os envelopes aqui são operacionais, baseados em evidências finitas. O erro observado do backend entra separadamente em uma estimativa de perturbação da densidade e do limiar; o código não transforma máximos amostrados em limites uniformes. Se uma hipótese uniforme |ΔlogL|≤d fosse conhecida, ½expm1(2d) seria um limite conservador de variação total; aqui esse valor é explicitamente apenas um proxy com d observado nas sondas.

## Geração e kernels

Cada linha recebe uma nova seed `SeedSequence([909112101,id,id])`. A geração usa somente a ORF harmônica fina diretamente calculada na massa fixada, após seus gates. `paired_physical_and_gaussian` mantém o gerador C06/C07: coeficientes CN próprios e controle normal pareado com os mesmos dois primeiros momentos. As linhas gaussianas do fatorial são geradas sob a família completa variável; diagonalização/congelamento são misspecificações deliberadas na análise, não controles próprios dessas famílias.

O adaptador usa as fórmulas normalizadas de `likelihood_reference`, sem C++ ou reconstrução de um banco5D. C=SGamma+ruído diagonal, com nuisances conhecidos. Para o cenário monopolarρ=1, a geração acrescenta o processo PSD de posto1 com espectro13/3, normalizado no pivô1/ano; a análise indicada o omite. Os momentos são recalculados sobre a covariância total, preservando termos cruzados. Não se somam apenas variâncias de componentes.

Nos quatro tratamentos B, a média depende de u. A covariância pode ser completa/diagonal e variável/fixa em u*=.5, com os nuisances do cenário. A compressão usa w na média e w² nas covariâncias de frequências independentes; diagonalização ocorre no espaço B observado. O logdet está presente em todos os casos. A âncora jamais é escolhida pela verdade ou ajustada ao dado. O zero estrutural da CDF de massa em u0 é distinguido de um indicador de logL constante nos nós; este último não recebe aprovação artificial.

## Custos e controles operacionais

O preflight final estima:

- **145,28 bilhões de multiplicações reais por proxy (0,1453T)**, incluindo BLAS, contrações, recorrências e reserva de operações escalares do transfer; teto0,25T;
- 16.713.984 pontos de transfer harmônico; quadratura das raízes Legendre e funções transcendentais têm contagens/proxies separados, não uma promessa de FLOPs ou tempo;
- **74.530.432 pontos de céu/configuração**, com dois produtos de polarização tensorial por ponto; teto80M;
- 13.056 avaliações GL iniciais nos14 alvos, até21.504 sondas interiores emβ mais extremos; referências/contornos e diagnósticos são adicionais, sob teto1M logL,60mil por alvo;
- 563.396.800bytes para a maior base/buffers BLAS; interpolador C07 existente pode atingir1.339.424.768bytes de arrays estimados durante construção;
- **1,5GiB RSS** operacional, com estimativa numérica máxima1,4GB e folga estimada de271.187.968bytes entre o pico numérico e o teto RSS. As fases de bases e interpolador são seriais; não se mantém uma base grande ao construir a tabela cúbica.

Essas estimativas não garantem RSS ou600sCPU: o processo confere ambos entre blocos, e um limite de CPU do sistema serve de última guarda. A última guarda dura tem até2s para registrar a falha após o sinal suave. Orçamentos são debitados antes das avaliações; o relatório distingue proxies cobrados de tempos efetivos. Saídas têm teto20MiB e exigem arquivos novos. Somente um thread BLAS/OMP é aceito. Não há refino automático nem substituição de alvos reprovados.

O piloto prepara gates de Z/CDF/quantis/momentos/KL/PIT. **Não encerra todo o C09:** métricas W1/supCDF/odds, contrastes científicos pareados, controles próprios de covariância e os bancos500 permanecem trabalho posterior. As duas distâncias exigem orçamento e preflight separados. Falha do integrador1D não autoriza promover a camada aproximada, e sucesso numérico de um modelo misspecificado não implica uniformidade SBC.

## O que foi executado

Seis testes leves verificam: kernels A/B do fatorial contra SciPy no mesmo TOY; CN contra sua representação real independente; média variável com covariância fixa; termos cruzados do contaminante e guardas; identidade dos nós GL congelados; ausência de aprovação e teto/não sobrescrita das saídas. A execução final gastou2.026sCPU no processo de testes e1.482sCPU no subprocesso que confirmou a recusa de `--execute` sem aprovação. Preflight e leitura de hashes foram executados; o conjunto de preparos permaneceu abaixo do teto de30sCPU. Os registros intermediários estão preservados, mas `light_validation_final.json` vincula os bytes atuais dos quatro fontes locais.

Não foram duplicadas as suítes de ORF, geração estatística ou integrador; tampouco foi executado o fluxo físico end-to-end. A validação física e do desempenho real começa somente após revisão/autorização ROOT.
