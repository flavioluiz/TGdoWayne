# Comandos do candidato C09 nominal14

Somente metadados, sem física (operação executada nesta preparação):

```sh
VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  .venv/bin/python tmp/c09_nominal14_preflight/run_nominal14.py
```

Teste leve dos adaptadores com matrizes sintéticas:

```sh
VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  .venv/bin/python -m unittest discover \
  -s tmp/c09_nominal14_preflight -p test_candidate.py -v
```

`ROOT_APPROVAL_SCHEMA_EXAMPLE.json` não autoriza nada: contém `stages: []`. O ROOT pode criar um arquivo separado, após revisão, com o mesmo schema, hashes exatos de `executable_preflight.json`, tabela e estágio autorizado. O pacote não cria automaticamente uma autorização.

**Não executados nesta preparação.** Quando houver aprovação do ROOT para o backend e seu orçamento:

```sh
VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  .venv/bin/python tmp/c09_nominal14_preflight/run_nominal14.py \
  --execute --stage backend --approval CAMINHO_DA_APROVACAO_ROOT \
  --output NOVO_DIRETORIO_BACKEND
```

Depois de ler o backend concluído, uma autorização **separada** para o piloto deve vincular também seu `backend_result_sha256`:

```sh
VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  .venv/bin/python tmp/c09_nominal14_preflight/run_nominal14.py \
  --execute --stage pilot --approval CAMINHO_DA_APROVACAO_ROOT_PILOT \
  --backend DIRETORIO_BACKEND_APROVADO --output NOVO_DIRETORIO_PILOT
```

Os caminhos em maiúsculas são espaços reservados, não arquivos existentes. O runner recusa ausência de aprovação, identidade diferente, tabela alterada, backend reprovado, hash de dados/ORFs divergente, fontes alteradas no backend ou diretório de saída já existente. Seus relatórios são de engenharia nominal14; não são uma síntese SBC e não aprovam a etapa de distâncias.
