"""Candidate staged C09 runner; default is metadata-only preflight.

No physical operation is reached without --execute plus exact-hash ROOT approval.
"""
from pathlib import Path
import argparse,gc,hashlib,io,json,math,os,resource,signal,sys,time,traceback,warnings
import numpy as np
from planning import ROOT,HERE,digest,preflight


ACTIVE_OUTPUT_BUDGET=None

def write_bytes_new(path,payload):
 if ACTIVE_OUTPUT_BUDGET is not None:
  root,limit=ACTIVE_OUTPUT_BUDGET
  current=sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
  if current+len(payload)>limit:raise RuntimeError('Output byte ceiling reached before writing')
 with Path(path).open('xb') as stream:stream.write(payload)

def _json_scalar(value):
 if isinstance(value,np.generic):return value.item()
 raise TypeError('Unsupported JSON value: '+type(value).__name__)

def write_new(path,value):
 write_bytes_new(path,(json.dumps(value,indent=2,allow_nan=False,default=_json_scalar)+'\n').encode())

def save_npz_new(path,**arrays):
 stream=io.BytesIO();np.savez_compressed(stream,**arrays);write_bytes_new(path,stream.getvalue())


def rss():
 value=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 return int(value if sys.platform=='darwin' else value*1024)


class Budget:
 def __init__(self,config,previous=0.):
  self.config=config;self.start=time.process_time();self.previous=previous;self.values=0;self.by_target={};self.charged_products=0;self.sky=0
 def check(self):
  if self.previous+time.process_time()-self.start>self.config['CPU_seconds_combined']:raise RuntimeError('Combined CPU ceiling reached')
  if rss()>self.config['RSS_bytes']:raise MemoryError('Operational RSS ceiling reached')
 def likelihood(self,n,target):
  self.check()
  if self.values+n>self.config['likelihood_component_values'] or self.by_target.get(target,0)+n>self.config['likelihood_values_per_target']:raise RuntimeError('Likelihood ceiling reached before evaluation')
  self.values+=n;self.by_target[target]=self.by_target.get(target,0)+n
 def products(self,n):
  self.check()
  if self.charged_products+n>self.config['real_multiplications']:raise RuntimeError('ORF multiplication ceiling reached before evaluation')
  self.charged_products+=n
 def sky_points(self,n):
  self.check()
  if self.sky+n>self.config['direct_sky_points']:raise RuntimeError('Sky ceiling reached before evaluation')
  self.sky+=n
 def report(self):return {'process_CPU_seconds_this_stage':time.process_time()-self.start,'previous_stage_CPU_seconds':self.previous,'combined_CPU_seconds':self.previous+time.process_time()-self.start,'peak_RSS_bytes':rss(),'charged_likelihood_values':self.values,'charged_likelihood_values_by_target':self.by_target,'charged_ORF_multiplication_proxy':self.charged_products,'charged_sky_config_points':self.sky}


def source_hashes(config):
 sources=config['dependencies']+[str(p.relative_to(ROOT)) for p in [HERE/'planning.py',HERE/'kernels.py',HERE/'run_nominal14.py']]
 return {p:digest(ROOT/p) for p in sources}


def experiment_and_table(config,budget):
 from inference.model import experiment
 from inference.orf_interpolation import EvenThresholdCubicORF
 e=experiment(json.loads((ROOT/config['experiment_config']).read_text()))
 budget.check()
 with np.load(ROOT/config['table_file'],allow_pickle=False) as p:
  table=EvenThresholdCubicORF(p['nodes'],p['matrices'],coordinate='beta')
 budget.check()
 if len(table.fallback):raise RuntimeError('Unexpected ORF fallback compared with frozen8336 table')
 return e,table


def backend(config,out,budget):
 from inference.model import experiment
 from inference.orf_blas import RealHarmonicBasis,TableBudget
 from pta.orf import raw_direct_orf
 from kernels import generate_row,ConditionalKernel
 e=experiment(json.loads((ROOT/config['experiment_config']).read_text()))
 masses=np.array(config['sparse_exact_mass_nodes']);N=len(masses);K=len(e['f']);P=len(e['points']);B=config['budgets']['batch_size_harmonic']
 stages=np.empty((3,N,K,P,P),complex);costs=[]
 for k,item in enumerate(config['harmonic_resolutions']):
  phase=2*np.pi*e['f'][k]*e['distance_ly']*365.25*86400
  beta=np.sqrt((1-masses/(k+1))*(1+masses/(k+1)))
  for j,level in enumerate(item['levels']):
   budget.check();before=time.process_time()
   l,n=level['lmax'],level['nmu']
   budget.products(4*n*(l-1)+6*P*P*(l-1))
   basis=RealHarmonicBasis(e['points'],lmax=l,nmu=n,budget=TableBudget(700*1024**2,50000000000,4),planned_batch=B)
   for first in range(0,N,B):
    count=min(B,N-first)
    budget.products(2*count*P*n*(l-1)+6*count*P*P*(l-1)+16*count*P*n)
    stages[j,first:first+count,k]=basis.evaluate(beta[first:first+count],phase)
    budget.check()
   costs.append({'channel':k+1,**level,'CPU_seconds':time.process_time()-before})
   del basis;gc.collect()
  print(json.dumps({'channel_completed':k+1,'stage':'backend'}),flush=True)
 errors={'nodes':float(np.max(abs(stages[1]-stages[0]))),'ell':float(np.max(abs(stages[2]-stages[1])))}
 minimum=float(np.linalg.eigvalsh(stages).min());gamma=stages[2].copy()
 harmonic_pass=errors['nodes']<=config['gates']['harmonic_nodes_abs'] and errors['ell']<=config['gates']['harmonic_ell_abs'] and minimum>=config['gates']['PSD_minimum']
 save_npz_new(out/'harmonic_nodes.npz',u=masses,Gamma=gamma,errors_nodes=np.max(abs(stages[1]-stages[0]),axis=(-2,-1)),errors_ell=np.max(abs(stages[2]-stages[1]),axis=(-2,-1)))
 del stages;gc.collect()
 if not harmonic_pass:
  write_new(out/'backend_result.json',{'status':'HARMONIC_UNRESOLVED','errors':errors,'minimum_eigenvalue':minimum,'costs':costs,'resources':budget.report()})
  return False
 direct=[]
 for case in config['direct_sky_cases']:
  k=case['channel']-1;u=case['u'];a,b=case['pair'];phase=2*np.pi*e['f'][k]*e['distance_ly']*365.25*86400;values=[]
  for res in config['direct_sky_resolutions']:
   budget.sky_points(res['nmu']*res['nphi'])
   value=raw_direct_orf(math.sqrt((1-u/(k+1))*(1+u/(k+1))),float(e['points'][a]@e['points'][b]),phase[a],phase[b],nmu=res['nmu'],nphi=res['nphi'])
   values.append(value);budget.check()
  ref=gamma[np.flatnonzero(masses==u)[0],k,a,b]
  direct.append({**case,'coarse':[values[0].real,values[0].imag],'fine':[values[1].real,values[1].imag],'refinement_error':abs(values[1]-values[0]),'harmonic_error':abs(values[1]-ref)})
 direct_pass=all(x['refinement_error']<=config['gates']['direct_refinement_abs'] and x['harmonic_error']<=config['gates']['harmonic_direct_abs'] for x in direct)
 if not direct_pass:
  write_new(out/'backend_result.json',{'status':'DIRECT_SKY_UNRESOLVED','errors':errors,'direct':direct,'resources':budget.report()})
  return False
 # Draws are engineering fixtures under exact, checked truth matrices, not posterior samples.
 data=[]
 for row in config['rows']:
  truth_gamma=gamma[np.flatnonzero(masses==row['fixed_truth_u'])[0]]
  data.append(generate_row(e,row,truth_gamma,config['seeds']['generation']))
 save_npz_new(out/'data.npz',**{name:np.concatenate([d[name] for d in data]) for name in ['q','x_physical','x_gaussian']},truth_u=np.array([r['fixed_truth_u'] for r in config['rows']]),target=np.arange(14))
 _,table=experiment_and_table(config,budget);interpolated=table(masses)
 anchor=gamma[np.flatnonzero(masses==config['anchor_mass'])[0]];anchor_table=table(np.array([config['anchor_mass']]))[0]
 differences=[]
 for row,d in zip(config['rows'],data):
  exact_kernel=ConditionalKernel(e,row,d,anchor);table_kernel=ConditionalKernel(e,row,d,anchor_table)
  budget.likelihood(N*2,row['id'])
  lexact=exact_kernel(gamma);ltable=table_kernel(interpolated);budget.check()
  differences.append({'target':row['id'],'analysis':row['analysis'],'max_abs_logL_difference':float(np.max(abs(lexact-ltable))),'argmax_u':float(masses[np.argmax(abs(lexact-ltable))])})
 table_pass=all(x['max_abs_logL_difference']<=config['gates']['table_sparse_abs_logL'] for x in differences)
 write_new(out/'backend_result.json',{'status':'BACKEND_AND_GENERATION_PASS_ON_SPARSE_NOMINAL14_DOMAIN' if table_pass else 'NEW_SCENARIO_TABLE_LOG_LIKELIHOOD_UNRESOLVED',
 'scope':'SPARSE_PHYSICAL_BACKEND_AND_ENGINEERING_DATA_ONLY_NOT_POSTERIOR','harmonic_errors':errors,'minimum_eigenvalue':minimum,'direct':direct,'table_likelihood_checks':differences,
 'table_matrix_max_abs_difference_descriptive':float(np.max(abs(interpolated-gamma))),'costs':costs,'resources':budget.report(),
 'data_sha256':digest(out/'data.npz'),'harmonic_nodes_sha256':digest(out/'harmonic_nodes.npz'),'global_ORF_error_certificate':False})
 return table_pass


def pilot(config,out,budget,backend_dir):
 from kernels import ConditionalKernel
 sys.path[:0]=[str(ROOT/'tmp/c09_integrator'),str(ROOT/'tmp/c09_contour')]
 from integrator import Posterior1D,MassPrior,EvaluationBudget
 from pchip_density import PositivePchipCDF
 from contour import LogLikelihoodContour
 from scipy.integrate import quad_vec
 from scipy.optimize import brentq
 e,table=experiment_and_table(config,budget)
 backend_report=json.loads((backend_dir/'backend_result.json').read_text())
 backend_delta={r['target']:r['max_abs_logL_difference'] for r in backend_report['table_likelihood_checks']}
 with np.load(backend_dir/'data.npz',allow_pickle=False) as p:data={k:p[k].copy() for k in ['q','x_physical','x_gaussian']}
 anchor=table(np.array([config['anchor_mass']]))[0]
 reports=[]
 for row in config['rows']:
  target=row['id'];observed={k:v[target:target+1] for k,v in data.items()};kernel=ConditionalKernel(e,row,observed,anchor)
  prior=MassPrior(row['prior']);local_start=budget.values
  def ell(u):
   u=np.asarray(u,float)
   if u.ndim!=1 or not np.isfinite(u).all() or np.any((u<prior.lower)|(u>1)):raise ValueError('Mass outside one-dimensional prior')
   budget.likelihood(len(u),target);ans=np.empty(len(u));batch=config['budgets']['batch_size_likelihood']
   for i in range(0,len(u),batch):ans[i:i+batch]=kernel(table(u[i:i+batch]));budget.check()
   return ans
  def ell_scalar(u):return float(ell(np.array([u]))[0])
  try:
   direct=[];densities=[]
   for order in config['quadrature']['orders']:
    obj=Posterior1D(ell,prior,order=order,panel_edges=config['quadrature']['panel_edges_u'],budget=EvaluationBudget(maximum_values=config['budgets']['likelihood_values_per_target'],maximum_cpu_seconds=config['budgets']['CPU_seconds_combined']))
    if not np.array_equal(obj._u,np.array(config['quadrature']['GL_mass_nodes'][prior.kind][str(order)])):raise RuntimeError('Runtime GL nodes differ from frozen plan')
    direct.append(obj);densities.append(PositivePchipCDF(obj))
   scouts=[]
   for name in ['scout_u_coarse','scout_u_fine']:
    u=np.unique(np.r_[prior.lower,np.array(config['quadrature'][name])[np.array(config['quadrature'][name])>prior.lower],1.])
    scouts.append((u,ell(u)))
   shift=max(float(np.max(direct[-1]._ell)),float(np.max(scouts[-1][1])))
   observed_warnings=[]
   def vector_integrand(v):
    u=float(prior.ppf(v));lv=ell_scalar(u)-shift
    if lv>650:raise RuntimeError('Independent reference exceeds frozen exponential scale; preserve failure')
    weight=math.exp(lv)
    return weight*np.array([1.,u,u*u,lv])
   def integrate_v(a,b):
    if b<=a:return np.zeros(4),0.
    with warnings.catch_warnings(record=True) as ww:
     warnings.simplefilter('always')
     value,error,info=quad_vec(vector_integrand,a,b,epsabs=config['quadrature']['reference_epsabs_scaled'],epsrel=config['quadrature']['reference_epsrel'],limit=config['quadrature']['reference_subinterval_limit'],quadrature='gk21',full_output=True)
     if not info.success:observed_warnings.append('GK integration did not converge: '+str(info.message))
    observed_warnings.extend(str(w.message) for w in ww)
    if not np.isfinite(value).all() or not math.isfinite(error):raise RuntimeError('Nonfinite independent integral')
    return value,float(error)
   brackets=[]
   for probability in config['quadrature']['quantile_probabilities']:
    qa,qb=[density.ppf(probability) for density in densities]
    lo=max(prior.lower,min(qa,qb)-.00005);hi=min(1.,max(qa,qb)+.00005)
    brackets.append({'probability':probability,'low':lo,'high':hi,'width':hi-lo,'PCHIP_coarse':qa,'PCHIP_fine':qb})
   mass_cuts=[float(prior.ppf(v)) for v in config['quadrature']['independent_prior_cdf_cuts']]+[config['quadrature']['independent_fixed_mass_cut'],row['fixed_truth_u']]
   mass_cuts+=[x[key] for x in brackets for key in ['low','high']]
   mass_cuts=sorted(set(x for x in mass_cuts if prior.lower<=x<=1))
   # Independent uniform-prior-CDF partition, plus desired diagnostic cuts.
   boundaries=sorted(set(np.linspace(0,1,33).tolist()+[float(prior.cdf(u)) for u in mass_cuts]))
   integrals=[];errors=[]
   for left,right in zip(boundaries[:-1],boundaries[1:]):
    v,er=integrate_v(left,right);integrals.append(v);errors.append(er)
   cumulative=np.vstack([np.zeros(4),np.cumsum(integrals,axis=0)]);total=cumulative[-1];Z=total[0];error_total=sum(errors)
   if not Z>0 or not math.isfinite(Z) or error_total>=Z:raise RuntimeError('Reference denominator unresolved')
   reference_logz=shift+math.log(Z);cdf_reference={u:float(cumulative[boundaries.index(float(prior.cdf(u))),0]/Z) for u in mass_cuts}
   cdf_rows=[{'u':u,'PCHIP_coarse':densities[0].cdf(u),'PCHIP_fine':densities[1].cdf(u),'reference':cdf_reference[u]} for u in mass_cuts]
   error_radius=2*error_total/(Z-error_total)
   backend_density_proxy=.5*math.expm1(2*backend_delta[target])
   total_CDF_radius=error_radius+backend_density_proxy
   for b in brackets:
    b.update(reference_low=cdf_reference[b['low']],reference_high=cdf_reference[b['high']])
    b['reference_confirms']=b['reference_low']+total_CDF_radius<=b['probability']<=b['reference_high']-total_CDF_radius
   truth_level=ell_scalar(row['fixed_truth_u'])
   contour_values=[LogLikelihoodContour(d).cdf(truth_level) for d in densities]
   physical_contours=[]
   for ugrid,levels in scouts:
    f=levels-truth_level;roots=[];flat=bool(np.any((f[:-1]==0)&(f[1:]==0)))
    for a,b,fa,fb in zip(ugrid[:-1],ugrid[1:],f[:-1],f[1:]):
     if fa*fb<0:roots.append(float(brentq(lambda u:ell_scalar(u)-truth_level,a,b,xtol=1e-13,rtol=1e-13)))
    cuts=sorted(set([prior.lower,1.]+roots));numerator=0.;event_error=0.
    for a,b in zip(cuts[:-1],cuts[1:]):
     if ell_scalar((a+b)/2)<=truth_level:
      value,er=integrate_v(float(prior.cdf(a)),float(prior.cdf(b)));numerator+=value[0];event_error+=er
    physical_contours.append({'probability':numerator/Z,'roots_u':roots,'adjacent_equal_level_nodes':flat,'GK_numerator_error_scaled':event_error,'no_physical_global_topology_certificate':True})
   fine=densities[-1];event=LogLikelihoodContour(fine).event
   probe_u,probe_ell=scouts[-1]
   event_errors=abs(event(np.arcsin(probe_u))-probe_ell)
   finite_form_error=float(np.max(event_errors))
   delta_level=finite_form_error+2*backend_delta[target] # event and truth threshold; finite probes, NOT uniform bound
   cobj=LogLikelihoodContour(fine)
   band_low=cobj.cdf(truth_level-delta_level)['probability'];band_high=cobj.cdf(truth_level+delta_level)['probability']
   all_pit=[x['probability'] for x in contour_values+physical_contours]
   spread=max(all_pit)-min(all_pit)
   event_radius=max(abs(contour_values[-1]['probability']-band_low),abs(band_high-contour_values[-1]['probability']))+total_CDF_radius+spread
   summaries=[x.summary() for x in direct]
   ref_moments={'mean_u':total[1]/Z,'second_moment_u':total[2]/Z,'kl_posterior_to_prior':total[3]/Z-math.log(Z)}
   cdf_spread=max(max(abs(r['PCHIP_coarse']-r['PCHIP_fine']),abs(r['PCHIP_fine']-r['reference'])) for r in cdf_rows)
   flags={'normalization':max([abs(d.logz-reference_logz) for d in direct]+[abs(d.logz-reference_logz) for d in densities])<=config['gates']['delta_logZ'],
    'CDF':cdf_spread+total_CDF_radius<=config['gates']['delta_CDF_PIT'],
    'quantiles':all(b['width']<=config['gates']['quantile_bracket_u'] and b['reference_confirms'] for b in brackets),
    'moments':all(abs(summaries[-1][k]-ref_moments[k])<=config['gates']['delta_moments'] for k in ['mean_u','second_moment_u']),
    'KL':abs(summaries[-1]['kl_posterior_to_prior']-ref_moments['kl_posterior_to_prior'])<=config['gates']['delta_KL'],
    'offgrid_form':finite_form_error<=config['gates']['density_event_sparse_abs_logL'],
    'reference_warning_free':not observed_warnings}
   flags['logL_PIT']=bool(flags['normalization'] and flags['offgrid_form'] and flags['reference_warning_free'] and event_radius<=config['gates']['delta_CDF_PIT'] and len(physical_contours[0]['roots_u'])==len(physical_contours[1]['roots_u'])>0 and not any(x['adjacent_equal_level_nodes'] for x in physical_contours) and not any(x['plateau_probability']>0 for x in contour_values))
   mass_structural=row['fixed_truth_u']==0 and prior.lower==0
   mass_pit=fine.cdf(row['fixed_truth_u'])
   report={'target':target,'scenario':row['scenario'],'analysis':row['analysis'],'prior':prior.kind,'status':'OPERATIONALLY_RESOLVED_ON_TESTED_NOMINAL14_DOMAIN' if all(flags.values()) else 'PRODUCTS_PARTIALLY_UNRESOLVED',
    'scope':'FIXED_TRUTH_ENGINEERING_NOT_SBC','flags':flags,'GL_summaries':summaries,'PCHIP_logZ':[x.logz for x in densities],
    'reference_logZ':reference_logz,'reference_moments':ref_moments,'backend_max_observed_logL_error':backend_delta[target],'backend_density_TV_proxy_not_uniform_bound':backend_density_proxy,'reference_relative_error_estimate':error_total/Z,'reference_warnings':observed_warnings,
    'CDFs':cdf_rows,'quantile_brackets':brackets,'mass_PIT':mass_pit,'mass_PIT_structural_exact':mass_structural,
    'mass_PIT_operational_interval':[0.,0.] if mass_structural else ([max(0.,mass_pit-.002),min(1.,mass_pit+.002)] if flags['normalization'] and flags['CDF'] and flags['offgrid_form'] and flags['reference_warning_free'] else [0.,1.]),
    'logL_PIT_surrogates':contour_values,'logL_PIT_independent':physical_contours,'logL_PIT_radius_from_finite_checks_not_a_uniform_bound':event_radius,
    'logL_PIT_operational_interval':[max(0.,min(all_pit)-event_radius),min(1.,max(all_pit)+event_radius)] if flags['logL_PIT'] else [0.,1.],
    'observed_offgrid_logL_error':finite_form_error,'local_likelihood_evaluations':budget.values-local_start,'global_error_certificate':False}
  except (RuntimeError,MemoryError,ArithmeticError,ValueError) as exc:
   report={'target':target,'status':'UNRESOLVED_NUMERICAL_OR_RESOURCE_FAILURE','exception':type(exc).__name__,'reason':str(exc),'probability_interval':[0.,1.],'local_likelihood_evaluations':budget.values-local_start}
  write_new(out/f'target_{target:02d}.json',report);reports.append(report)
  print(json.dumps({'target':target,'status':report['status']}),flush=True)
  # Exhaustion preserves every remaining ID without attempting more work.
  if budget.previous+time.process_time()-budget.start>config['budgets']['CPU_seconds_combined'] or rss()>config['budgets']['RSS_bytes']:
   for pending in config['rows'][target+1:]:
    item={'target':pending['id'],'status':'UNRESOLVED_NOT_EXECUTED_RESOURCE_CEILING','probability_interval':[0,1]};write_new(out/f"target_{pending['id']:02d}.json",item);reports.append(item)
   break
 write_new(out/'pilot_result.json',{'status':'NOMINAL14_ENGINEERING_RECORDED_NOT_SBC','all_ids':[r['target'] for r in reports],'target_statuses':[r['status'] for r in reports],'resources':budget.report(),'distance2_cases_executed':False})


def main():
 global ACTIVE_OUTPUT_BUDGET
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--config',type=Path,default=HERE/'config.json');parser.add_argument('--execute',action='store_true');parser.add_argument('--stage',choices=['backend','pilot'],default='backend');parser.add_argument('--approval',type=Path);parser.add_argument('--backend',type=Path);parser.add_argument('--output',type=Path)
 args=parser.parse_args();config=json.loads(args.config.read_text());report=preflight(config);config_hash=digest(args.config);sources=source_hashes(config)
 report.update(config_sha256=config_hash,source_sha256=sources,table_file_sha256=digest(ROOT/config['table_file']))
 if report['table_file_sha256']!=config['table_sha256']:raise RuntimeError('Frozen table hash mismatch')
 if not args.execute:
  print(json.dumps(report,indent=2));return
 if args.approval is None or args.output is None:raise SystemExit('--execute requires explicit --approval and a NEW --output')
 approval=json.loads(args.approval.read_text())
 if approval.get('schema')!='ROOT_C09_NOMINAL14_APPROVAL_v1' or approval.get('config_sha256')!=config_hash or approval.get('source_sha256')!=sources or args.stage not in approval.get('stages',[]) or approval.get('table_sha256')!=config['table_sha256']:
  raise SystemExit('Exact config/source/table/stage ROOT approval is missing or stale')
 if report['status']!='READY_FOR_ROOT_REVIEW_NO_EXECUTION':raise SystemExit('Resource preflight failed')
 for variable in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:
  if os.environ.get(variable)!='1':raise SystemExit('Set '+variable+'=1 before process import/start')
 previous=0.
 if args.stage=='pilot':
  if args.backend is None:raise SystemExit('pilot requires --backend')
  previous_report=json.loads((args.backend/'backend_result.json').read_text());execution=json.loads((args.backend/'execution_identity.json').read_text())
  end=json.loads((args.backend/'execution_end.json').read_text())
  if end.get('source_unchanged') is not True:raise SystemExit('Backend sources changed during execution')
  if previous_report['status']!='BACKEND_AND_GENERATION_PASS_ON_SPARSE_NOMINAL14_DOMAIN':raise SystemExit('Backend stage did not pass')
  if execution['config_sha256']!=config_hash or execution['source_sha256']!=sources:raise SystemExit('Backend identity differs')
  for file,key in [('data.npz','data_sha256'),('harmonic_nodes.npz','harmonic_nodes_sha256')]:
   if digest(args.backend/file)!=previous_report[key]:raise SystemExit('Backend artifact hash differs')
  if approval.get('backend_result_sha256')!=digest(args.backend/'backend_result.json'):raise SystemExit('pilot approval must bind the passed backend result')
  previous=previous_report['resources']['combined_CPU_seconds']
 args.output.mkdir(parents=True,exist_ok=False)
 ACTIVE_OUTPUT_BUDGET=(args.output,config['budgets']['output_bytes'])
 write_new(args.output/'execution_identity.json',{'stage':args.stage,'config_sha256':config_hash,'source_sha256':sources,'approval_sha256':digest(args.approval),'table_sha256':config['table_sha256'],'no_SBC_claim':True})
 budget=Budget(config['budgets'],previous)
 remaining=config['budgets']['CPU_seconds_combined']-previous
 if remaining<=0:raise RuntimeError('No remaining combined CPU allocation')
 # Soft signal allows a failure record; hard ceiling is a final two-second guard.
 def cpu_limit(signum,frame):raise RuntimeError('OS process CPU soft ceiling reached')
 signal.signal(signal.SIGXCPU,cpu_limit)
 soft=math.ceil(time.process_time()+remaining)
 resource.setrlimit(resource.RLIMIT_CPU,(soft,soft+2))
 try:
  budget.check()
  if args.stage=='backend':backend(config,args.output,budget)
  else:pilot(config,args.output,budget,args.backend)
 except Exception as exc:
  write_new(args.output/'execution_failure.json',{'status':'FAILED_PRESERVED','exception':type(exc).__name__,'reason':str(exc),'resources':budget.report(),'traceback':traceback.format_exc()})
  raise
 finally:
  write_new(args.output/'execution_end.json',{'resources':budget.report(),'source_unchanged':sources==source_hashes(config),'total_saved_bytes':sum(p.stat().st_size for p in args.output.rglob('*') if p.is_file())})

if __name__=='__main__':main()
