"""Conditional one-dimensional quadrature. No PTA imports and no random draws.

Numerical refinement is evidence, not a global error certificate for arbitrary
functions. A MonotonePartition is an explicit *external* mathematical contract;
finite probes below can reject it, but cannot establish its truth.
"""
from dataclasses import dataclass
from functools import lru_cache
import math
import time
import numpy as np
from scipy.optimize import brentq
from scipy.special import logsumexp

DEFAULT_EDGES = (0., .0001, .001, .01, .05, .25, .5, .75, .9, .99, 1.)


class BudgetExceeded(RuntimeError):
    pass


class NumericalUnresolved(ArithmeticError):
    pass


@dataclass
class EvaluationBudget:
    maximum_values: int = 200000
    maximum_cpu_seconds: float = 50.
    values: int = 0
    calls: int = 0

    def __post_init__(self):
        if isinstance(self.maximum_values, bool) or not isinstance(self.maximum_values, int) or self.maximum_values < 1:
            raise ValueError('maximum_values must be a positive integer')
        if not np.isfinite(self.maximum_cpu_seconds) or self.maximum_cpu_seconds <= 0:
            raise ValueError('CPU budget must be finite and positive')
        if self.values or self.calls:
            raise ValueError('a new budget must start at zero')
        self._start = time.process_time()

    def reserve(self, n):
        if self.values + n > self.maximum_values:
            raise BudgetExceeded('likelihood value budget exceeded before evaluation')
        self.check_cpu()
        self.values += n
        self.calls += 1

    def check_cpu(self):
        if time.process_time() - self._start > self.maximum_cpu_seconds:
            raise BudgetExceeded('process CPU budget exceeded')


@dataclass(frozen=True)
class MassPrior:
    kind: str
    cutoff: float = .001

    def __post_init__(self):
        if self.kind not in ('uniform_u', 'uniform_u_squared', 'log_uniform_u'):
            raise ValueError('unknown prior')
        if not np.isfinite(self.cutoff) or not 0 < self.cutoff < 1:
            raise ValueError('cutoff must lie strictly inside (0,1)')

    @property
    def lower(self):
        return self.cutoff if self.kind == 'log_uniform_u' else 0.

    def cdf(self, u):
        x = np.asarray(u, dtype=float)
        if not np.all(np.isfinite(x)):
            raise ValueError('nonfinite coordinate')
        x = np.clip(x, self.lower, 1.)
        if self.kind == 'uniform_u': return x
        if self.kind == 'uniform_u_squared': return x*x
        return (np.log(x)-np.log(self.cutoff))/(-np.log(self.cutoff))

    def ppf(self, v):
        v = np.asarray(v, dtype=float)
        if not np.all(np.isfinite(v)) or np.any((v < 0) | (v > 1)):
            raise ValueError('prior probability outside [0,1]')
        if self.kind == 'uniform_u': return v
        if self.kind == 'uniform_u_squared': return np.sqrt(v)
        return np.exp((1-v)*np.log(self.cutoff))

    def log_alpha_density(self, alpha):
        # Quadrature nodes are strictly interior, including the log-prior cutoff.
        a = np.asarray(alpha, dtype=float)
        u = np.sin(a)
        if not np.all(np.isfinite(a)) or np.any((a < math.asin(self.lower)-4*np.finfo(float).eps) | (a >= math.pi/2)):
            raise ValueError('alpha quadrature nodes outside transformed support')
        result = np.log(np.cos(a))
        if self.kind == 'uniform_u_squared': result = result + np.log(2*u)
        if self.kind == 'log_uniform_u': result = result - np.log(u) - np.log(-np.log(self.cutoff))
        return result


@lru_cache(maxsize=16)
def _legendre(order):
    x, w = np.polynomial.legendre.leggauss(order)
    x.setflags(write=False); w.setflags(write=False)
    return x, w


@dataclass(frozen=True)
class MonotonePartition:
    """External strict-monotonicity/constant partition in u, including endpoints.

    directions: +1/-1 continuous, strictly increasing/decreasing in each open interval;
    0 means *identically* constant on the complete interval. Flat threshold
    plateaus must be distinct direction-zero pieces. provenance must identify
    the analytic proof or certified derivative enclosure; a scan is not one.
    """
    edges: tuple
    directions: tuple
    provenance: str

    def __post_init__(self):
        e = np.asarray(self.edges, dtype=float)
        if e.ndim != 1 or len(e) < 2 or not np.all(np.isfinite(e)) or np.any(np.diff(e) <= 0):
            raise ValueError('partition edges must be finite and increasing')
        if len(self.directions) != len(e)-1 or any(type(d) is not int or d not in (-1, 0, 1) for d in self.directions):
            raise ValueError('one integer monotonicity direction per interval')
        if not isinstance(self.provenance, str) or not self.provenance.strip():
            raise ValueError('external mathematical provenance is required')
        object.__setattr__(self, 'edges', tuple(float(x) for x in e))
        object.__setattr__(self, 'directions', tuple(self.directions))


class Posterior1D:
    def __init__(self, log_likelihood, prior, *, order, panel_edges=DEFAULT_EDGES, budget=None):
        if type(order) is not int or not 2 <= order <= 4096:
            raise ValueError('explicit integer quadrature order in [2,4096] required')
        if not isinstance(prior, MassPrior): raise TypeError('MassPrior required')
        edges = np.asarray(panel_edges, dtype=float)
        if edges.ndim != 1 or len(edges) < 2 or not np.all(np.isfinite(edges)) or edges[0] != 0 or edges[-1] != 1 or np.any(np.diff(edges) <= 0):
            raise ValueError('fixed panel edges must partition [0,1]')
        self.prior, self.order, self.log_likelihood = prior, order, log_likelihood
        self.budget = budget if budget is not None else EvaluationBudget()
        self.edges = np.r_[prior.lower, edges[(edges > prior.lower) & (edges < 1)], 1.]
        self.alpha_edges = np.arcsin(self.edges)
        alpha, logmeasure, panel = self._rule(prior.lower, 1.)
        u = np.sin(alpha)
        ell = self.evaluate(u)
        lw = ell + logmeasure
        self.logz = float(logsumexp(lw))
        if not np.isfinite(self.logz): raise ValueError('zero or invalid integrated likelihood')
        self._u, self._ell, self._weights = u, ell, np.exp(lw-self.logz)
        self._panel_logs = np.array([logsumexp(lw[panel == i]) for i in range(len(self.edges)-1)])
        self._cdf_cache = {float(prior.lower): 0., 1.: 1.}

    def evaluate(self, u):
        u = np.asarray(u, dtype=float)
        if u.ndim != 1 or not np.all(np.isfinite(u)) or np.any((u < self.prior.lower) | (u > 1)):
            raise ValueError('likelihood coordinates outside prior support')
        self.budget.reserve(u.size)
        y = np.asarray(self.log_likelihood(u), dtype=float)
        self.budget.check_cpu()
        if y.shape != u.shape or np.any(np.isnan(y)) or np.any(np.isposinf(y)):
            raise ValueError('log likelihood must return shape(n,) with finite values or -inf')
        return y

    def _rule(self, low, high):
        # Integrates partial panels in alpha; never sums an indicator on full nodes.
        x, w = _legendre(self.order)
        alpha, logweights, panels = [], [], []
        for i, (left, right) in enumerate(zip(self.edges[:-1], self.edges[1:])):
            a, b = max(low, left), min(high, right)
            if b <= a: continue
            # atan2 identity avoids subtracting nearly equal asin values.
            half = math.atan2(b-a, math.sqrt((1-a)*(1+a))+math.sqrt((1-b)*(1+b)))
            midpoint = math.asin(a)+half
            nodes = midpoint+half*x
            alpha.append(nodes)
            logweights.append(np.log(half*w)+self.prior.log_alpha_density(nodes))
            panels.append(np.full(self.order, i, dtype=int))
        if not alpha: return np.empty(0), np.empty(0), np.empty(0, dtype=int)
        return np.concatenate(alpha), np.concatenate(logweights), np.concatenate(panels)

    def interval_logmass(self, low, high):
        if not np.isfinite(low) or not np.isfinite(high) or low > high:
            raise ValueError('invalid integration interval')
        low, high = max(self.prior.lower, float(low)), min(1., float(high))
        if high <= low: return -math.inf
        a, w, _ = self._rule(low, high)
        return float(logsumexp(self.evaluate(np.sin(a))+w))

    def cdf(self, threshold):
        x = float(threshold)
        if not np.isfinite(x): raise ValueError('nonfinite CDF threshold')
        if x <= self.prior.lower: return 0.
        if x >= 1.: return 1.
        if x in self._cdf_cache: return self._cdf_cache[x]
        k = int(np.searchsorted(self.edges, x, side='right')-1)
        partial = self.interval_logmass(self.edges[k], x)
        numerator = float(logsumexp(np.r_[self._panel_logs[:k], partial]))
        answer = float(np.exp(numerator-self.logz))
        if answer < -1e-12 or answer > 1+1e-12:
            raise NumericalUnresolved('partial/full quadrature inconsistency; refine instead of clipping')
        answer = min(1., max(0., answer))  # only <=1e-12 roundoff
        self._cdf_cache[x] = answer
        return answer

    def quantile_bracket(self, probability, *, maximum_width=.00025):
        p = float(probability)
        if not np.isfinite(p) or not 0 <= p <= 1 or not np.isfinite(maximum_width) or not 0 < maximum_width <= 1:
            raise ValueError('invalid quantile probability or bracket width')
        low, high = self.prior.lower, 1.
        if p == 0: high = low
        elif p == 1: low = high
        else:
            while high-low > maximum_width:
                mid = .5*(low+high)
                if mid == low or mid == high: raise ArithmeticError('quantile width below floating-point resolution')
                if self.cdf(mid) < p: low = mid
                else: high = mid
        return {'probability':p, 'low':low, 'high':high, 'width':high-low,
                'cdf_low':self.cdf(low), 'cdf_high':self.cdf(high)}

    def summary(self):
        w, u = self._weights, self._u
        mean, second = float(w@u), float(w@(u*u))
        finite = np.isfinite(self._ell)
        elog = float(w[finite]@self._ell[finite])
        return {'logz':self.logz, 'mean_u':mean, 'second_moment_u':second,
                'variance_u':second-mean*mean, 'expected_log_likelihood':elog,
                'kl_posterior_to_prior':elog-self.logz, 'order':self.order,
                'panel_edges_u':self.edges.tolist(), 'guaranteed_absolute_error':False}

    def _root(self, low, high, threshold):
        root = float(brentq(lambda u: self.evaluate(np.array([u]))[0]-threshold,
                            low, high, xtol=1e-13, rtol=1e-13, maxiter=100))
        # Record a sign-checked bracket, not merely the optimizer tolerance.
        radius = 4e-12
        for _ in range(40):
            a,b=max(low,root-radius),min(high,root+radius)
            fa,fb=self.evaluate(np.array([a,b]))-threshold
            if (fa <= 0 <= fb) or (fb <= 0 <= fa):
                self._root_brackets.append((a,b))
                return root
            radius *= 2
        raise NumericalUnresolved('could not bracket a reported level-set root')

    def _segment_mass(self, intervals):
        if not intervals: return 0.
        lognum = logsumexp([self.interval_logmass(a,b) for a,b in intervals])
        value = float(np.exp(lognum-self.logz))
        if value > 1+1e-9: raise NumericalUnresolved('segmented quadrature exceeds denominator; refine')
        return min(1., value)

    def loglikelihood_pit(self, threshold, *, partition=None, scan_subdivisions=8):
        if not np.isfinite(threshold): raise ValueError('finite log likelihood threshold required')
        self._root_brackets = []
        if partition is None:
            if type(scan_subdivisions) is not int or not 1 <= scan_subdivisions <= 4096:
                raise ValueError('invalid scan subdivision count')
            scans = []
            for n in (scan_subdivisions, 2*scan_subdivisions):
                alpha = np.unique(np.concatenate([np.linspace(a,b,n+1) for a,b in zip(self.alpha_edges[:-1],self.alpha_edges[1:])]))
                u = np.sin(alpha); u[0]=self.prior.lower; u[-1]=1.
                values = self.evaluate(u)-threshold
                roots = [float(x) for x,v in zip(u,values) if v == 0]
                for a,b,fa,fb in zip(u[:-1],u[1:],values[:-1],values[1:]):
                    if (fa < 0 < fb) or (fb < 0 < fa): roots.append(self._root(a,b,threshold))
                edges = np.unique(np.r_[self.prior.lower, roots, 1.])
                mids = .5*(edges[:-1]+edges[1:]); below = self.evaluate(mids) <= threshold
                segments = [(float(a),float(b)) for a,b,yes in zip(edges[:-1],edges[1:],below) if yes]
                scans.append({'subdivisions_per_panel':n,'detected_roots':sorted(set(roots)),
                              'provisional_value':self._segment_mass(segments)})
            return {'status':'UNRESOLVED_CROSSING_COMPLETENESS', 'resolved':False,
                    'value':scans[-1]['provisional_value'], 'envelope':[0.,1.],
                    'scans':scans, 'reason':'finite scans cannot certify absent multiple/tangent crossings'}
        if not isinstance(partition, MonotonePartition): raise TypeError('MonotonePartition required')
        if partition.edges[0] != self.prior.lower or partition.edges[-1] != 1:
            raise ValueError('external partition must match complete prior support')
        intervals, roots = [], []
        for a,b,direction in zip(partition.edges[:-1],partition.edges[1:],partition.directions):
            values = self.evaluate(np.linspace(a,b,9))
            if direction == 0:
                valid = np.all(values == values[0])
            else:
                valid = (values[-1] > values[0] if direction == 1 else values[-1] < values[0])
                valid = valid and np.all(values[1:] >= values[:-1] if direction == 1 else values[1:] <= values[:-1])
            if not valid:
                return {'status':'UNRESOLVED_CONTRACT_CONTRADICTED','resolved':False,'value':None,'envelope':[0.,1.],
                        'reason':'finite probes contradict externally supplied monotonicity', 'provenance':partition.provenance}
            left, right = values[0], values[-1]
            if max(left,right) <= threshold: intervals.append((a,b))
            elif min(left,right) >= threshold:
                # Strict interval: equality only at one endpoint has zero mass.
                continue
            else:
                root = self._root(a,b,threshold); roots.append(root)
                intervals.append((a,root) if direction == 1 else (root,b))
        return {'status':'TOPOLOGY_ACCEPTED_UNDER_EXTERNAL_CONTRACT', 'resolved':False,
                'value':self._segment_mass(intervals), 'envelope':[0.,1.],
                'intervals_below_or_equal':intervals, 'roots':roots,
                'crossings_complete_under_external_contract':True,
                'provenance':partition.provenance,
                'root_brackets':self._root_brackets,
                'root_ambiguity_mass_sum':sum(float(np.exp(self.interval_logmass(a,b)-self.logz)) for a,b in self._root_brackets),
                'root_xtol_u':1e-13,'root_rtol':1e-13,
                'reason':'quadrature refinement still required; external mathematical contract not proved by probes'}


def compare_levels(coarse, fine, *, cdf_thresholds=(), probabilities=(.05,.5,.9,.95),
                   loglikelihood_threshold=None, partition=None):
    """Prospective C09 gates; agreement is not a global absolute-error bound."""
    if coarse.prior != fine.prior or not np.array_equal(coarse.edges,fine.edges) or fine.order <= coarse.order:
        raise ValueError('same prior/panels and increasing orders required')
    if coarse.log_likelihood is not fine.log_likelihood:
        raise ValueError('levels must use the same deterministic callable identity')
    a,b = coarse.summary(),fine.summary()
    differences = {k:abs(a[k]-b[k]) for k in ('logz','mean_u','second_moment_u','variance_u','kl_posterior_to_prior')}
    flags = {k:v <= .001 for k,v in differences.items()}
    cdfs=[]
    for x in cdf_thresholds:
        try:
            left,right=coarse.cdf(x),fine.cdf(x);delta=abs(left-right)
            cdfs.append({'threshold':float(x),'coarse':left,'fine':right,'difference':delta,'passed':delta <= .002})
        except NumericalUnresolved as error:
            cdfs.append({'threshold':float(x),'coarse':None,'fine':None,'difference':None,'passed':False,'reason':str(error)})
    quantiles=[]
    for p in probabilities:
        try:
            qa,qb=coarse.quantile_bracket(p),fine.quantile_bracket(p)
            low,high=min(qa['low'],qb['low']),max(qa['high'],qb['high'])
            checks=[coarse.cdf(low),coarse.cdf(high),fine.cdf(low),fine.cdf(high)]
            passed=high-low <= .001 and checks[0] <= p <= checks[1] and checks[2] <= p <= checks[3]
            quantiles.append({'probability':p,'low':low,'high':high,'width':high-low,'coarse':qa,'fine':qb,'joint_endpoint_cdfs':checks,'passed':bool(passed)})
        except NumericalUnresolved as error:
            quantiles.append({'probability':p,'passed':False,'reason':str(error)})
    pit=None
    if loglikelihood_threshold is not None:
        parts=[]
        for level in (coarse,fine):
            try:parts.append(level.loglikelihood_pit(loglikelihood_threshold,partition=partition))
            except NumericalUnresolved as error:
                parts.append({'status':'UNRESOLVED_SEGMENT_INTEGRATION','value':None,'resolved':False,'envelope':[0.,1.],'reason':str(error)})
        pa,pb=parts
        delta=abs(pa['value']-pb['value']) if pa['value'] is not None and pb['value'] is not None else None
        ambiguity=pa.get('root_ambiguity_mass_sum',0.)+pb.get('root_ambiguity_mass_sum',0.)
        resolved=bool(pa.get('crossings_complete_under_external_contract') and pb.get('crossings_complete_under_external_contract') and delta is not None and delta+ambiguity <= .002 and flags['logz'])
        pit={'coarse':pa,'fine':pb,'difference':delta,'resolved':resolved,
             'root_ambiguity_mass_sum_both_levels':ambiguity,
             'envelope':[max(0.,pb['value']-.002),min(1.,pb['value']+.002)] if resolved else [0.,1.],
             'status':'NUMERICALLY_RESOLVED_CONDITIONALLY' if resolved else 'UNRESOLVED'}
    return {'status':'REFINEMENT_REPORTED_NOT_GLOBAL_CERTIFICATE','differences':differences,'quantity_passed':flags,
            'cdfs':cdfs,'quantiles':quantiles,'loglikelihood_pit':pit,
            'all_requested_quantities_passed':bool(all(flags.values()) and all(x['passed'] for x in cdfs) and all(x['passed'] for x in quantiles) and (pit is None or pit['resolved'])),
            'guaranteed_absolute_error':False}
