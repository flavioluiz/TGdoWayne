# Núcleo determinístico 1D de C09 — apenas validação sintética

Implementação isolada em `tmp/c09_integrator`. Não importa módulos PTA, não executa ORFs ou likelihoods da campanha, não sorteia dados e não inicia C09. A tarefa C10 bidimensional permanece fora do escopo.

## Arquivos e uso

- `integrator.py`: `MassPrior`, `Posterior1D`, `MonotonePartition`, `EvaluationBudget`, `compare_levels`.
- `test_integrator.py`: 12 testes, incluindo referências analíticas e `scipy.integrate.quad` em outra coordenada.
- `run_validation.py`: execução limitada a 60 segundos de CPU por processo; resultado com hashes.
- `benchmark_synthetic.py`/`synthetic_products.json`: valores e contagens para três curvas sintéticas simples; nenhum throughput físico.
- `validation_attempt*.json`: histórico das verificações durante a implementação; não são campanhas científicas.

Exemplo:

```python
import numpy as np
from integrator import MassPrior, Posterior1D, EvaluationBudget, compare_levels

logL = lambda u: 7*u  # somente um exemplo sintético
prior = MassPrior("uniform_u")
budget = EvaluationBudget(maximum_values=20000, maximum_cpu_seconds=20)
a = Posterior1D(logL, prior, order=32, budget=budget)
b = Posterior1D(logL, prior, order=64, budget=budget)
report = compare_levels(a, b, cdf_thresholds=(.2, .5, .9))
```

A callback determinística recebe `u` de shape `(n,)` e devolve logL de mesma shape. Não recebe verdades nem altera prioris. `-inf` é admitido para likelihood zero; `NaN`, `+inf`, shape incorreta ou integral nula são erros explícitos. Recursos excedidos geram `BudgetExceeded`, antes da próxima avaliação; a callback em andamento não é preemptada pelo contador interno. O runner sintético tem também limite de CPU do sistema operacional. Compartilhar um orçamento entre níveis acumula todas as avaliações.

A integração posterior de vários dados deve reutilizar fatorações em um adaptador próprio. Esta primeira versão avalia uma curva por objeto e não afirma já otimizar os bancos físicos de 500 dados.

## Medidas, normalização e produtos

Prioris implementadas, com suporte explícito:

1. `uniform_u`: π(u)=1 em[0,1].
2. `uniform_u_squared`: π(u)=2u em[0,1].
3. `log_uniform_u`: π(u)=1/[u log(1/ε)] em[ε,1]; ε=.001 por padrão, com .0001/.01 também testados.

A integração usa α=asin(u), com densidades `cosα`, `2sinα cosα` e `cotα/log(1/ε)`. Os painéis físicos são exatamente os do protocolo:0,.0001,.001,.01,.05,.25,.5,.75,.9,.99,1, cortados pelo suporte. As ordens são argumentos obrigatórios; o ensaio prospectivo inicial é32/64. `logsumexp` mantém logZ mesmo para um deslocamento de logL igual a−10000.

`summary()` entrega logZ, média, segundo momento, variância de u e KL(posterior||prior)=ElogL−logZ. `cdf(x)` soma painéis completos e **reintegra a parte necessária do painel final**; não interpola CDFs nem soma indicadores nos nós completos. `quantile_bracket(p)` faz bissecção sobre essa CDF contínua e devolve os extremos e suas CDFs. A largura angular de intervalos muito pequenos usa uma identidade `atan2`, evitando subtrair dois `asin` quase iguais.

`compare_levels` conserva os limites do protocolo: diferenças de logZ/momentos/KL≤.001; CDF≤.002; bracket conjunto de quantil≤.001 emu, confirmado em ambos os níveis. Cada quantidade mantém seu próprio flag. Uma inconsistência numérica de integrais parciais vira falha explícita; não é mascarada por recorte de CDF para[0,1]. O recorte existente limita-se a arredondamentos da ordem de1e−12; valores maiores exigem refinamento.

Não estão implementados neste núcleo: W1 entre posteriores, máxima diferença de CDF no contínuo, efeito fatorial e síntese SBC. São consumidores futuros da CDF, com validações próprias. Nada no objeto declara um marco ou uma campanha aprovados.

## PIT de logL: travessias e limites

O evento é logL(u)≤c, com c fornecido explicitamente pelo diagnóstico. As regiões são integradas por subintervalos, nunca pelo indicador avaliado apenas nos nós GL. Brackets de raízes são refinados com Brent e checados por sinais; a massa posterior somada desses pequenos brackets entra no gate de refinamento. Platôs exatamente no nível c são incluídos, pois podem ter massa positiva.

Há duas situações distintas:

- **Sem partição externamente justificada:** duas varreduras refinadas por painel localizam mudanças de sinal e oferecem uma estimativa provisória. O status permanece `UNRESOLVED_CROSSING_COMPLETENESS` e o envelope é[0,1], mesmo que as varreduras concordem ou seus indicadores sejam constantes. Travessias múltiplas e tangências podem escapar a qualquer conjunto finito de sondagens.
- **Com `MonotonePartition`:** o chamador fornece suporte completo, pontos críticos e sentido estritamente monótono/constante em cada intervalo, junto da proveniência de uma prova analítica ou inclusão certificada da derivada. Sondagens podem **contradizer** essa declaração, mas não prová-la. A topologia é aceita somente *sob esse contrato externo*. A comparação32/64 ainda deve passar para obter `NUMERICALLY_RESOLVED_CONDITIONALLY` e o envelope prospectivo±.002. Soma da discrepância e das massas dos brackets de raízes deve caber em.002.

Uma string no campo de proveniência não constitui uma prova. O futuro driver físico terá de verificar a evidência antes de usar esse status. O núcleo não tenta provar monotonicidade de uma likelihood arbitrária. Mesmo sob partição válida, acordo GL32/64 é evidência de convergência e não um limite matemático universal do erro de integração; `guaranteed_absolute_error` permanece falso.

## Verificação executada

Os testes confrontam normalização e momentos das três prioris, CDFs/quantis analíticos de likelihood exponencial, mistura com dois modos contra Gauss–Kronrod na CDF da priori, camada estreita junto a u=1, mudanças u↔u²↔logu com Jacobianos, múltiplas travessias senoidais, tangência ao nível máximo, platô, oscilação sem certificado, contrato contraditório, suporte e orçamento. O exemplo senoidal tem PIT analítico `.5−.8/π`, além da referência adaptativa segmentada independente. Os PITs monótonos das três prioris são confrontados com suas próprias CDFs contínuas.

Dois problemas encontrados na primeira execução foram preservados no histórico. Uma regra GL4 deliberadamente insuficiente produziu CDF parcial acima da normalização; agora o relatório registra essa falha numérica por quantidade. A referência adaptativa de `exp[-2000(1−u)]` deixou escapar contribuição de uma cauda estreita: foi corrigida por pontos independentes adicionais e tolerância de integração mais estrita, mantendo o controle analítico Z=(1−exp(−2000))/2000. Não se afrouxou a tolerância do teste para aceitar esse resultado.

## Gates propostos antes do piloto físico

1. Reproduzir as12 verificações após eventual integração como módulo de `src/inference/`, sem alterar C05/C06 ou o núcleo publicado durante a campanha em andamento.
2. Congelar os16 IDs de engenharia do protocolo, cobrindo as três prioris, proximidade do limiar, ruídos e mistura de distâncias. Geração direta e inferência aproximada devem manter proveniências distintas.
3. Confrontar logL nos novos nós com a referência física, respeitando o domínio C05 e as ordens próprias das distâncias. Uma aprovação da integral não certifica a ORF interpolada.
4. Executar32/64 e referência independente por Gauss–Kronrod emu ou CDF da priori. Conferir logZ, CDFs, brackets dos quatro quantis, momentos e KL individualmente. Registrar cada refinamento e todos os IDs.
5. Para PITlogL, documentar como todos os componentes do conjunto de nível foram localizados. Uma varredura estável sozinha não permite retirar[0,1]. Se não houver evidência suficiente, o produto permanece pendente; não substituir o PIT de logL por teste em grade ou exigir uniformidade para “validar” o numerador.
6. Medir o custo completo, incluindo CDFs parciais, raízes, quantis e referência independente. Não contar apenas os nós que calculam Z. Conservar o teto prospectivo de120M e parar antes de excedê-lo, ou revisar explicitamente o orçamento antes de qualquer produção.

O benchmark sintético mediu960 avaliações iniciais em32/64 (768 na priori log) e5.116–5.212 avaliações totais por curva, com cinco cortes, quatro quantis e um PIT monótono. Uma extrapolação apenas ilustrativa de5.116×25.956 já supera132M, antes de curvas mais oscilatórias. Portanto a estimativa antiga baseada somente nas regras iniciais não aprova o orçamento completo. Antes do piloto, convém medir reuso de avaliações entre cortes e uma localização mais eficiente dos brackets, mantendo integrais parciais e tolerâncias. Esses números não são tempos de PTA nem resultado científico.
