import unittest
import math
import numpy as np
from scipy.integrate import quad
from integrator import (MassPrior, Posterior1D, MonotonePartition, EvaluationBudget,
                        BudgetExceeded, compare_levels)


def reference(logl, prior, shift=0., threshold=1., moment=0, points=()):
    # Independent adaptive Gauss-Kronrod in the prior CDF coordinate, not alpha.
    upper=float(prior.cdf(threshold))
    def f(v):
        u=float(prior.ppf(v))
        return math.exp(float(logl(np.array([u]))[0])-shift)*u**moment
    p=[float(prior.cdf(x)) for x in points if 0 < prior.cdf(x) < upper]
    return quad(f,0.,upper,epsabs=2e-11,epsrel=2e-11,points=p,limit=250)[0]


class IntegratorTests(unittest.TestCase):
    def test_all_prior_normalizations_moments_and_exact_cdfs(self):
        for kind in ('uniform_u','uniform_u_squared','log_uniform_u'):
            prior=MassPrior(kind)
            f=lambda u: np.full_like(u,-10000.)
            a,b=[Posterior1D(f,prior,order=n) for n in (32,64)]
            report=compare_levels(a,b,cdf_thresholds=(.0001,.001,.02,.3,.91),probabilities=(.05,.5,.9,.95))
            self.assertTrue(report['all_requested_quantities_passed'])
            self.assertAlmostEqual(b.logz,-10000.,places=10)
            for u in (0,.0001,.001,.01,.23,.95,1):
                self.assertAlmostEqual(b.cdf(u),float(prior.cdf(u)),delta=2e-11)
            for q in report['quantiles']:
                value=float(prior.ppf(q['probability']))
                self.assertLessEqual(q['low'],value+1e-13);self.assertGreaterEqual(q['high'],value-1e-13)
            if kind=='uniform_u': target=.5
            elif kind=='uniform_u_squared': target=2/3
            else: target=(1-prior.cutoff)/math.log(1/prior.cutoff)
            self.assertAlmostEqual(b.summary()['mean_u'],target,delta=2e-11)
            self.assertAlmostEqual(b.summary()['kl_posterior_to_prior'],0.,delta=2e-8)

    def test_exponential_analytic_normalization_and_continuous_quantiles(self):
        k=7.;f=lambda u:k*u
        p=Posterior1D(f,MassPrior('uniform_u'),order=64)
        exactlog=math.log(math.expm1(k)/k)
        self.assertAlmostEqual(p.logz,exactlog,delta=1e-12)
        for x in (.031234,.512345,.987654):
            self.assertAlmostEqual(p.cdf(x),math.expm1(k*x)/math.expm1(k),delta=1e-12)
        for prob in (.05,.5,.9,.95):
            b=p.quantile_bracket(prob,maximum_width=1e-7)
            q=math.log1p(prob*math.expm1(k))/k
            self.assertLessEqual(b['low'],q);self.assertGreaterEqual(b['high'],q)

    def test_quad_reference_multimodal_all_priors(self):
        def f(u):
            return np.logaddexp(-.5*((u-.13)/.035)**2,
                               math.log(.45)-.5*((u-.82)/.07)**2)
        for kind in ('uniform_u','uniform_u_squared','log_uniform_u'):
            prior=MassPrior(kind);a,b=[Posterior1D(f,prior,order=n) for n in (32,64)]
            z=reference(f,prior,points=(.13,.82))
            self.assertAlmostEqual(b.logz,math.log(z),delta=2e-9)
            for x in (.017,.13,.47,.82,.993):
                self.assertAlmostEqual(b.cdf(x),reference(f,prior,threshold=x,points=(.13,.82))/z,delta=2e-9)
            for k,key in ((1,'mean_u'),(2,'second_moment_u')):
                self.assertAlmostEqual(b.summary()[key],reference(f,prior,moment=k,points=(.13,.82))/z,delta=2e-9)
            self.assertTrue(compare_levels(a,b,cdf_thresholds=(.13,.82))['all_requested_quantities_passed'])

    def test_sharp_threshold_layer_reference_in_u(self):
        f=lambda u: -2000*(1-u)
        a,b=[Posterior1D(f,MassPrior('uniform_u'),order=n) for n in (32,64)]
        z=quad(lambda u:math.exp(-2000*(1-u)),0,1,points=(.9,.99,.999),epsabs=1e-17,epsrel=1e-13)[0]
        self.assertAlmostEqual(z,1/2000,delta=1e-15)
        self.assertAlmostEqual(b.logz,math.log(z),delta=1e-11)
        self.assertTrue(compare_levels(a,b,cdf_thresholds=(.99,.995,.999))['all_requested_quantities_passed'])
        self.assertAlmostEqual(b.cdf(.999),math.exp(-2),delta=2e-12)

    def test_multiple_crossings_analytic_pit_and_segmented_quad(self):
        amp=.8;f=lambda u:np.log1p(amp*np.sin(6*np.pi*u))
        edges=tuple(np.r_[0.,(np.arange(6)+.5)/6,1.])
        directions=tuple(1 if math.cos(6*math.pi*(a+b)/2)>0 else -1 for a,b in zip(edges[:-1],edges[1:]))
        part=MonotonePartition(edges,directions,'analytic: derivative sign is cos(6*pi*u); all six stationary points listed')
        a,b=[Posterior1D(f,MassPrior('uniform_u'),order=n) for n in (32,64)]
        r=compare_levels(a,b,probabilities=(),loglikelihood_threshold=0.,partition=part)
        self.assertTrue(r['loglikelihood_pit']['resolved'])
        actual=r['loglikelihood_pit']['fine']['value'];exact=.5-amp/math.pi
        self.assertAlmostEqual(actual,exact,delta=2e-12)
        independent=sum(quad(lambda u:1+amp*math.sin(6*math.pi*u),j/6,(j+1)/6,epsabs=1e-13)[0] for j in (1,3,5))
        self.assertAlmostEqual(actual,independent,delta=2e-12)

    def test_tangency_plateau_and_constant_require_contract(self):
        f=lambda u:-(u-.5)**2
        a,b=[Posterior1D(f,MassPrior('uniform_u'),order=n) for n in (32,64)]
        part=MonotonePartition((0.,.5,1.),(1,-1),'analytic derivative -2(u-.5)')
        r=compare_levels(a,b,probabilities=(),loglikelihood_threshold=0.,partition=part)
        self.assertTrue(r['loglikelihood_pit']['resolved']);self.assertAlmostEqual(r['loglikelihood_pit']['fine']['value'],1.)
        # Plateau equality contributes finite posterior mass, not just isolated roots.
        g=lambda u:np.where(u<=.4,0.,u-.4)
        part=MonotonePartition((0.,.4,1.),(0,1),'analytic piecewise constant/affine function')
        a,b=[Posterior1D(g,MassPrior('uniform_u'),order=n) for n in (32,64)]
        r=compare_levels(a,b,probabilities=(),loglikelihood_threshold=0.,partition=part)
        expected=.4/(.4+math.expm1(.6))
        self.assertAlmostEqual(r['loglikelihood_pit']['fine']['value'],expected,delta=3e-6)
        # A constant scan, even exactly zero, is not an external proof.
        h=lambda u:np.zeros_like(u)
        a,b=[Posterior1D(h,MassPrior('uniform_u'),order=n) for n in (32,64)]
        r=compare_levels(a,b,probabilities=(),loglikelihood_threshold=0.)
        self.assertFalse(r['loglikelihood_pit']['resolved']);self.assertEqual(r['loglikelihood_pit']['envelope'],[0.,1.])

    def test_unproven_oscillations_remain_unresolved(self):
        f=lambda u:np.log1p(.1*np.sin(300*np.pi*u))
        a,b=[Posterior1D(f,MassPrior('uniform_u'),order=n) for n in (32,64)]
        r=compare_levels(a,b,probabilities=(),loglikelihood_threshold=0.)
        self.assertFalse(r['loglikelihood_pit']['resolved'])
        self.assertEqual(r['loglikelihood_pit']['envelope'],[0.,1.])
        self.assertFalse(r['guaranteed_absolute_error'])

    def test_loglikelihood_pit_all_prior_supports(self):
        f=lambda u:3*u-1000.
        for kind in ('uniform_u','uniform_u_squared','log_uniform_u'):
            prior=MassPrior(kind)
            a,b=[Posterior1D(f,prior,order=n) for n in (32,64)]
            part=MonotonePartition((prior.lower,1.),(1,),'analytic derivative of logL equals3 on the support')
            r=compare_levels(a,b,probabilities=(),loglikelihood_threshold=3*.231-1000.,partition=part)
            self.assertTrue(r['loglikelihood_pit']['resolved'])
            self.assertAlmostEqual(r['loglikelihood_pit']['fine']['value'],b.cdf(.231),delta=2e-11)
            self.assertLess(r['loglikelihood_pit']['root_ambiguity_mass_sum_both_levels'],1e-8)

    def test_contradictory_contract_and_support_rejected(self):
        f=lambda u:-(u-.5)**2
        p=Posterior1D(f,MassPrior('uniform_u'),order=32)
        r=p.loglikelihood_pit(-.1,partition=MonotonePartition((0.,1.),(1,),'deliberately false analytic claim'))
        self.assertFalse(r['resolved']);self.assertEqual(r['status'],'UNRESOLVED_CONTRACT_CONTRADICTED')
        with self.assertRaises(ValueError):p.loglikelihood_pit(0.,partition=MonotonePartition((.001,1.),(1,),'wrong support'))
        with self.assertRaises(ValueError):MonotonePartition((0.,1.),(1,),'')

    def test_log_cutoff_transformations_and_support(self):
        f=lambda u: 2*u
        for eps in (.0001,.001,.01):
            prior=MassPrior('log_uniform_u',eps);p=Posterior1D(f,prior,order=64)
            # Independent w=log(u), whose uniform measure must retain normalization.
            z=quad(lambda w:math.exp(2*math.exp(w))/math.log(1/eps),math.log(eps),0,epsabs=1e-12)[0]
            self.assertAlmostEqual(p.logz,math.log(z),delta=2e-12)
            self.assertEqual(p.cdf(eps),0.)
        for kind in ('uniform_u','uniform_u_squared'):
            prior=MassPrior(kind);p=Posterior1D(f,prior,order=64)
            # Independent u² coordinate, with distinct transformed densities.
            z=quad(lambda v:math.exp(2*math.sqrt(v))*(.5/math.sqrt(v) if kind=='uniform_u' else 1.),0,1,epsabs=2e-11)[0]
            self.assertAlmostEqual(p.logz,math.log(z),delta=2e-10)

    def test_resource_contract_and_invalid_likelihoods(self):
        calls=[]
        f=lambda u:(calls.append(len(u)) or np.zeros_like(u))
        with self.assertRaises(BudgetExceeded):Posterior1D(f,MassPrior('uniform_u'),order=32,budget=EvaluationBudget(maximum_values=10))
        self.assertEqual(calls,[])
        for bad in (lambda u:np.nan*u,lambda u:np.full_like(u,np.inf),lambda u:np.zeros((len(u),1)),lambda u:np.full_like(u,-np.inf)):
            with self.assertRaises(ValueError):Posterior1D(bad,MassPrior('uniform_u'),order=32)
        for n in (True,1,2.5):
            with self.assertRaises(ValueError):Posterior1D(f,MassPrior('uniform_u'),order=n)
        with self.assertRaises(ValueError):MassPrior('log_uniform_u',0.)
        with self.assertRaises(ValueError):EvaluationBudget(maximum_values=True)

    def test_refinement_failure_is_retained(self):
        f=lambda u:-.5*((u-.371)/.006)**2
        a,b=[Posterior1D(f,MassPrior('uniform_u'),order=n) for n in (4,64)]
        r=compare_levels(a,b,cdf_thresholds=(.37,),probabilities=())
        self.assertFalse(r['all_requested_quantities_passed'])
        self.assertGreater(r['differences']['logz'],.001)

if __name__=='__main__':unittest.main()
