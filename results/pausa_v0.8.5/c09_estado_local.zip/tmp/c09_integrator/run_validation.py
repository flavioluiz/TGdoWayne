from pathlib import Path
import time,json,hashlib,resource,unittest
# Dedicated synthetic verification process; cap applies before loading SciPy.
resource.setrlimit(resource.RLIMIT_CPU,(55,60))
started=time.process_time()
import test_integrator
suite=unittest.defaultTestLoader.loadTestsFromModule(test_integrator)
r=unittest.TextTestRunner(verbosity=2).run(suite)
p=Path(__file__).resolve().parent
out={'status':'PASS' if r.wasSuccessful() else 'FAIL','tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'process_cpu_seconds':time.process_time()-started,'hard_cpu_cap_seconds':60,'physical_ORF_PTA_calls':0,'large_MC_runs':0,'scientific_certification':'none; synthetic validation only','sources':{x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in ('integrator.py','test_integrator.py','run_validation.py')}}
(p/'validation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
raise SystemExit(0 if r.wasSuccessful() else 1)
