from pathlib import Path
import json,math,time,resource,hashlib
resource.setrlimit(resource.RLIMIT_CPU,(55,60))
start=time.process_time()
import numpy as np
from scipy.integrate import quad
from integrator import MassPrior, Posterior1D, MonotonePartition, EvaluationBudget, compare_levels
rows=[]
for kind in ('uniform_u','uniform_u_squared','log_uniform_u'):
 prior=MassPrior(kind);budget=EvaluationBudget(maximum_values=100000)
 f=lambda u:7*u-1000.
 a,b=[Posterior1D(f,prior,order=n,budget=budget) for n in (32,64)]
 initial=budget.values
 part=MonotonePartition((prior.lower,1.),(1,),'analytic derivative equals7')
 report=compare_levels(a,b,cdf_thresholds=(.01,.2,.5,.9,.995),loglikelihood_threshold=7*.631-1000,partition=part)
 z=quad(lambda v:math.exp(7*float(prior.ppf(v))),0,1,epsabs=1e-9,epsrel=1e-11,limit=200)[0]
 rows.append({'prior':kind,'initial_values':initial,'total_values_with_products':budget.values,'calls':budget.calls,'logz_difference_from_independent_quad':abs(b.logz-(math.log(z)-1000.)),'report':report})
p=Path(__file__).resolve().parent
out={'status':'SYNTHETIC_REFERENCE_AND_CALL_COUNT_ONLY','cases':rows,'physical_calls':0,'process_cpu_seconds':time.process_time()-start,'sources':{x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in ('integrator.py','benchmark_synthetic.py')}}
(p/'synthetic_products.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'cpu_seconds':out['process_cpu_seconds'],'cases':[{k:r[k] for k in ('prior','initial_values','total_values_with_products','logz_difference_from_independent_quad')} for r in rows]},indent=2))
