"""Stdlib metadata and arithmetic only; no physical imports or execution."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(30,31))
import json,time
from pathlib import Path
from common import HERE,V2,ROOT,sha,read,write_new,preflight,rss

if __name__=='__main__':
 p=preflight()
 old=read(V2/'executable_preflight.json')
 p['arithmetic_detail']={
  'construction_formula_each_job':'4*nmu*(lmax-1)+6*12^2*(lmax-1)',
  'evaluation_formula_each_job':'2*16*12*nmu*(lmax-1)+6*16*12^2*(lmax-1)+16*16*12*nmu',
  'new_Gamma_matrices':192,'new_harmonic_workers':12,'new_gate_workers':1,
  'Gamma_matrices_per_worker':16,'Gamma_shape':[12,12],'Gamma_dtype':'complex128',
  'new_Gamma_numeric_bytes':192*12*12*16,
  'individual_plus_consolidated_Gamma_numeric_bytes':2*192*12*12*16,
  'sparse_truth_physical_rows':14,'matched_gaussian_control_rows':14,
  'backend_likelihood_values_per_target':32,'backend_likelihood_values':448,
  'pilot_remaining_likelihood_values_per_target':59968,'pilot_remaining_global_effective_maximum':839552,
  'backend_plus_pilot_global_effective_maximum':840000,
  'unchanged_global_likelihood_cap':1000000,'unchanged_target_cap':60000,
  'direct_sky_margin':80000000-p['new_sky_points'],
  'largest_basis_plus_32MiB_worker_allowance':p['maximum_fresh_basis_estimated_bytes']+32*1024**2,
  'fresh_gate_constructor_numeric_estimate':old['interpolator_constructor_estimated_numeric_peak'],
  'original_table_matrices_bytes':old['table_original_matrix_bytes'],
  'original_table_coefficients_bytes':old['table_coefficient_bytes'],
  'direct_quadrature_estimated_numeric_bytes':old['direct_memory_estimated_bytes'],
  'controller_planning_allowance_bytes':32*1024**2,
  'gate_numeric_plus_128MiB_worker_overhead_plus_32MiB_controller':old['interpolator_constructor_estimated_numeric_peak']+160*1024**2,
  'remaining_RSS_margin_in_that_estimate':1610612736-old['interpolator_constructor_estimated_numeric_peak']-160*1024**2,
  'RSS_scope':'Arithmetic estimate only; actual child RSS sampled by v2 Budget and sum(controller_peak,max_new_worker_peak) checked by controller; no OS hard memory guarantee',
  'CPU_scope_limit':'Every new child startup/exit measured by RUSAGE_CHILDREN; current controller CPU sampled through final hashes. Its final receipt serialization/exit and historical v2 receipt serialization/exit are not measured by those self samples.',
  'recomputation_scope':p['failure']['repeat_scope'],'automatic_retry':False,
 }
 tests=read(HERE/'toy_test_result.json')
 p['validation']={'tests':tests,'tests_source_sha256':sha(HERE/'test_guards_toy.py'),
  'three_guard_runs_CPU_seconds_self_plus_children':.554675+.109097+.58361+.112095+.568954+.100531,
  'reason_for_repeated_new_guard_runs':'Added request/pilot checks and failure-identity authorization binding; old six kernel/adaptor tests never repeated',
  'metadata_CPU_seconds_through_sample':time.process_time(),'metadata_peak_RSS_bytes':rss(),
  'scientific_calls_performed':{'ORF':0,'likelihood':0,'draws':0,'posterior':0},
  'scope':'Metadata streaming hashes and tiny identity-matrix fixtures only'}
 write_new(HERE/'preflight.json',p)
 manifest=dict(schema='C09_NOMINAL14_CANDIDATE_MANIFEST_v3',status='CANDIDATE_REQUIRES_NEW_ROOT_AUTHORIZATION',
  execution_enabled=False,automatic_retry=False,physical_work_executed=False,
  source_sha256=p['source_sha256'],config_sha256=p['config_sha256'],failed_v2=p['failure'],
  artifact_sha256={name:sha(HERE/name) for name in ('config.json','common.py','run_nominal14.py','worker.py',
   'test_guards_toy.py','toy_test_result.json','toy_test.log','build_metadata.py','PREFLIGHT.md','README.md','preflight.json')})
 write_new(HERE/'manifest.json',manifest)
 print(json.dumps({'preflight_sha256':sha(HERE/'preflight.json'),'manifest_sha256':sha(HERE/'manifest.json'),
  'source_count':len(p['source_sha256']),'CPU_seconds':time.process_time(),'RSS_peak_bytes':rss(),
  'execution_enabled':False},indent=2))
