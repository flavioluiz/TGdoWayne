# C09 nominal14 v3 — continuação técnica candidata

Candidato sem autorização e sem execução física. O backend v2 continua **FAILED** por RSS. Nenhum byte de v1/v2, de suas dependências científicas ou dos resultados anteriores foi alterado.

O controlador usa somente a biblioteca padrão. Executa sequencialmente 12 processos novos, um por frequência/resolução; cada processo constrói uma única base e avalia as mesmas 16 massas em lotes de 4. Cada Γ é salva individualmente ao receber o lote; o cache consolidado de 16 matrizes é salvo antes do término do worker. Arquivos parciais são marcados como tal e não habilitam retry nem reaproveitamento automático. Um 13º processo fresco lê e valida os 12 caches pequenos, sem construir base harmônica, e executa os gates, a geração nominal14 e os 448 valores de likelihood do v2.

A matemática dos gates é um trecho literal do runner v2. O piloto delega à função `pilot` v2 intacta, com o `Budget` v2 corrigido e a herança cumulativa de 32 valores por ID. A mudança é de isolamento, persistência, contabilidade e autorização; nenhum critério científico, nó, semente, ordem ou teto foi alterado.

`PREFLIGHT.md` explica as reservas, a memória e as limitações. `preflight.json` contém 12 jobs harmônicos explícitos + gates, hashes e aritmética. `manifest.json` vincula fontes e artefatos candidatos. `test_guards_toy.py` contém somente os novos guards e fixtures pequenas; não repete a suíte anterior de kernels/adaptadores.

A chamada sem `--execute` imprime exclusivamente preflight de metadados:

```sh
.venv/bin/python -B tmp/c09_nominal14_v3/run_nominal14.py
```

Qualquer futuro backend precisa de autorização ROOT v3 exata e diretório de saída novo. Qualquer futuro piloto precisa de autorização separada que vincule o backend **PASS revisado** e seu `execution_end.json` final. Este pacote não fornece nenhuma autorização e não executou ORF, likelihood, geração ou posterior.
