"""C09 v3 stdlib controller; no NumPy, ORF or likelihood in this process."""
from pathlib import Path
import argparse,json,math,os,resource,subprocess,sys,time,traceback
from common import (HERE,ROOT,sha,read,write_new,saved_bytes,rss,preflight,
                    validate_authorization,cpu_limits,source_hashes,validate_cache_report,validate_backend_for_pilot)


def initial_resources(plan):
 f=plan['failure']
 return dict(combined_CPU_seconds=f['CPU_seconds'],charged_ORF_multiplication_proxy=f['real_products'],
  charged_sky_config_points=0,charged_likelihood_values=0,charged_likelihood_values_by_target={})


class Ledger:
 def __init__(self,baseline,budgets):
  self.baseline=dict(baseline);self.budgets=budgets;self.child_CPU=0.;self.maximum_worker_RSS=0
  self.real=baseline['charged_ORF_multiplication_proxy'];self.sky=baseline['charged_sky_config_points']
  self.values=baseline['charged_likelihood_values'];self.by_target=dict(baseline['charged_likelihood_values_by_target'])
  self.reserved_values=self.values;self.reserved_by_target=dict(self.by_target)
 def cpu(self):return self.baseline['combined_CPU_seconds']+time.process_time()+self.child_CPU
 def reserve(self,job):
  b=self.budgets
  if self.real+job['real_products']>b['real_multiplications'] or self.sky+job['sky_points']>b['direct_sky_points']:
   raise RuntimeError('Cumulative real/sky reservation exceeds original cap')
  if self.reserved_values+job['likelihood_values']>b['likelihood_component_values']:raise RuntimeError('Cumulative likelihood reservation exceeds cap')
  for key,value in job['likelihood_by_target'].items():
   if self.reserved_by_target.get(str(key),0)+value>b['likelihood_values_per_target']:raise RuntimeError('Per-target reservation exceeds original cap')
  limits=cpu_limits(b['CPU_seconds_combined']-self.cpu())
  self.real+=job['real_products'];self.sky+=job['sky_points'];self.reserved_values+=job['likelihood_values']
  for key,value in job['likelihood_by_target'].items():self.reserved_by_target[str(key)]=self.reserved_by_target.get(str(key),0)+value
  return limits
 def report(self):
  return dict(combined_CPU_seconds=self.cpu(),baseline_CPU_seconds=self.baseline['combined_CPU_seconds'],
   controller_CPU_seconds=time.process_time(),new_child_CPU_seconds=self.child_CPU,
   charged_ORF_multiplication_proxy=self.real,charged_sky_config_points=self.sky,
   charged_likelihood_values=self.values,charged_likelihood_values_by_target=self.by_target,
   reserved_likelihood_values=self.reserved_values,reserved_likelihood_values_by_target=self.reserved_by_target,
   controller_RSS_peak_bytes=rss(),maximum_new_worker_RSS_peak_bytes=self.maximum_worker_RSS,
   sum_of_controller_and_maximum_worker_RSS_peaks_bytes=rss()+self.maximum_worker_RSS,
   CPU_scope='historical final sample + current controller CPU since exec + new child RUSAGE_CHILDREN deltas')


def run_child(cmd,logpath,limits,output_limit):
 soft,hard=limits
 def child_limits():
  resource.setrlimit(resource.RLIMIT_CPU,(soft,hard))
  resource.setrlimit(resource.RLIMIT_FSIZE,(output_limit,output_limit))
 before=resource.getrusage(resource.RUSAGE_CHILDREN)
 with logpath.open('x') as log:
  completed=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,preexec_fn=child_limits)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 cpu=(after.ru_utime-before.ru_utime)+(after.ru_stime-before.ru_stime)
 return completed.returncode,cpu


def execute(args,plan,authorization):
 c=read(HERE/'config.json');b=c['budgets']
 baseline=initial_resources(plan) if args.stage=='backend' else validate_backend_for_pilot(args.backend,authorization,plan)
 ledger=Ledger(baseline,b);out=args.output;out.mkdir(parents=True,exist_ok=False)
 identity=dict(schema='C09_CONTINUATION_IDENTITY_v3',stage=args.stage,config_sha256=plan['config_sha256'],
  source_sha256=plan['source_sha256'],authorization_sha256=sha(args.approval),failure_sha256=plan['failure']['failure_sha256'],
  failed_execution_end_sha256=plan['failure']['execution_end_sha256'],baseline=baseline,
  repetition_scope=plan['failure']['repeat_scope'],lost_v2_matrices_not_reused=True)
 write=lambda p,v:write_new(p,v,output_root=out,cap=b['output_bytes'])
 write(out/'execution_identity.json',identity)
 jobs=plan['jobs'] if args.stage=='backend' else [dict(name='pilot',kind='pilot',real_products=0,sky_points=0,
  likelihood_values=14*60000-baseline['charged_likelihood_values'],
  likelihood_by_target={str(i):60000-baseline['charged_likelihood_values_by_target'][str(i)] for i in range(14)})]
 records=[];success=False
 try:
  for job in jobs:
   if rss()>b['RSS_bytes']:raise MemoryError('Controller RSS cap exceeded')
   previous_values=ledger.values;previous_by_target=dict(ledger.by_target)
   limits=ledger.reserve(job)
   request=dict(schema='C09_FRESH_WORKER_REQUEST_v3',job=job,stage=args.stage,
    config_sha256=plan['config_sha256'],source_sha256=plan['source_sha256'],failure_sha256=plan['failure']['failure_sha256'],
    authorization_path=str(args.approval.resolve()),authorization_sha256=identity['authorization_sha256'],
    campaign=str(out.resolve()),previous_CPU_seconds=ledger.cpu(),previous_likelihood_values=previous_values,
    previous_likelihood_by_target=previous_by_target,
    backend_path=None if args.backend is None else str(args.backend.resolve()),CPU_limits=list(limits))
   req=out/(job['name']+'_request.json');write(req,request)
   write(out/(job['name']+'_reserved.json'),dict(job=job,resources=ledger.report(),reservation_is_not_completed_work=True))
   cmd=[sys.executable,'-B',str(HERE/'worker.py'),'--request',str(req.resolve()),'--request-sha256',sha(req)]
   code,child_CPU=run_child(cmd,out/(job['name']+'.log'),limits,b['output_bytes'])
   ledger.child_CPU+=child_CPU
   endpath=out/job['name']/'worker_end.json'
   observed=None
   if endpath.exists():
    observed=read(endpath)
    if observed.get('request_sha256')!=sha(req):raise ValueError('Worker end/request identity differs')
    rr=observed['resources']
    peak=rr['peak_RSS_bytes']
    if type(peak) is not int or peak<0:raise ValueError('Invalid worker RSS receipt')
    ledger.maximum_worker_RSS=max(ledger.maximum_worker_RSS,peak)
    values=rr['charged_likelihood_values'];by={str(k):v for k,v in rr['charged_likelihood_values_by_target'].items()}
    if (type(values) is not int or values<ledger.values or values>ledger.reserved_values
        or sum(by.values())!=values or any(type(v) is not int or v<0 or v>ledger.reserved_by_target.get(k,0) for k,v in by.items())):
     raise ValueError('Worker likelihood ledger exceeds reserved work')
    ledger.values,ledger.by_target=values,by
   records.append(dict(job=job['name'],returncode=code,child_CPU_seconds_including_startup_and_exit=child_CPU,
    worker_end_sha256=sha(endpath) if endpath.exists() else None,
    observed_likelihood_counter_available=observed is not None))
   write(out/(job['name']+'_measured.json'),dict(**records[-1],resources=ledger.report()))
   if code or observed is None or observed.get('status')!='WORKER_COMPLETED':raise RuntimeError('Worker stopped; preserve arrays/charges; no automatic retry: '+job['name'])
   if rss()+ledger.maximum_worker_RSS>b['RSS_bytes']:raise MemoryError('Conservative parent plus worker RSS peaks exceed original cap')
   if job['kind']=='harmonic':
    validate_cache_report(read(out/job['name']/'matrices.json'),job,identity,sha(out/job['name']/'matrices.npz'))
   if ledger.cpu()>b['CPU_seconds_combined']:raise RuntimeError('Combined CPU including child exit exceeded cap')
   if saved_bytes(out)>b['output_bytes']:raise RuntimeError('Output ceiling exceeded')
   print(json.dumps(dict(job=job['name'],completed=True,combined_CPU_seconds=ledger.cpu())),flush=True)
  if args.stage=='backend':
   result=read(out/'gates'/'backend_result.json')
   if result['status']!='BACKEND_AND_GENERATION_PASS_ON_SPARSE_NOMINAL14_DOMAIN':raise RuntimeError('Backend gate did not pass')
   result['gate_report_sha256']=sha(out/'gates'/'backend_result.json')
   write(out/'backend_result.json',result)
  else:
   result=read(out/'pilot'/'pilot_result.json');write(out/'pilot_result.json',result)
  success=True
 except Exception as exc:
  write(out/'execution_failure.json',dict(status='FAILED_NO_AUTOMATIC_RETRY',error=str(exc),resources=ledger.report(),workers=records))
  raise
 finally:
  unchanged=(source_hashes(c)==plan['source_sha256'] and sha(HERE/'config.json')==plan['config_sha256']
             and sha(ROOT/c['table_file'])==plan['table_sha256'])
  r=ledger.report();within=(r['combined_CPU_seconds']<=b['CPU_seconds_combined']
                          and r['sum_of_controller_and_maximum_worker_RSS_peaks_bytes']<=b['RSS_bytes'])
  write(out/'execution_end.json',dict(schema='C09_CONTINUATION_EXECUTION_END_v3',
   status='CONTROLLER_STAGE_COMPLETED' if success and unchanged and within else 'CONTROLLER_STAGE_FAILED',
   inputs_unchanged=unchanged,within_resource_limits=within,resources=r,workers=records,
   sample_scope='after final input hashes; controller final receipt serialization/exit follow this sample',
   historical_v2_final_sample_did_not_measure_its_receipt_serialization_or_exit=True))
  if not unchanged or not within:raise RuntimeError('Final controller input/resource checks failed')


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true')
 p.add_argument('--stage',choices=['backend','pilot'],default='backend');p.add_argument('--approval',type=Path)
 p.add_argument('--output',type=Path);p.add_argument('--backend',type=Path);a=p.parse_args()
 plan=preflight()
 if not a.execute:print(json.dumps(plan,indent=2));return
 if a.approval is None or a.output is None:raise SystemExit('Explicit v3 approval and new output required')
 auth=validate_authorization(a.approval,a.stage,plan)
 if a.stage=='pilot' and a.backend is None:raise SystemExit('Pilot needs a separately approved backend')
 for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
  if os.environ.get(key)!='1':raise SystemExit('Set '+key+'=1 before process startup')
 execute(a,plan,auth)

if __name__=='__main__':main()
