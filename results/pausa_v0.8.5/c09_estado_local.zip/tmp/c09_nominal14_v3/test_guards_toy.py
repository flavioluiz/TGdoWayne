"""New continuation guards only; zero ORF, likelihood, simulation or posterior calls."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(30,31))
import ast,copy,importlib.util,json,math,sys,tempfile,time,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import common
import run_nominal14 as controller
import worker
STDLIB_ONLY_AT_IMPORT='numpy' not in sys.modules and 'scipy' not in sys.modules
import numpy as np
CONFIG=common.read(HERE/'config.json')
JOBS=common.job_plan(CONFIG)
IDENTITY=dict(config_sha256='TOY_CONFIG',source_sha256={'TOY.py':'TOY_SOURCE'},
 authorization_sha256='TOY_AUTH',failure_sha256='TOY_FAILURE')

class ToyGuards(unittest.TestCase):
 def setUp(self):
  self.temporary=tempfile.TemporaryDirectory(prefix='TOY_ONLY_',dir=HERE)
  self.p=Path(self.temporary.name)
 def tearDown(self):self.temporary.cleanup()
 def toy_plan(self):
  return dict(config_sha256='TOY_CONFIG',source_sha256={'TOY.py':'TOY_SOURCE'},table_sha256='TOY_TABLE',
   failure=dict(failure_sha256='TOY_FAILURE',execution_end_sha256='TOY_END',execution_identity_sha256='TOY_IDENTITY',CPU_seconds=46.379645,
    real_products=69297757128,repeat_scope=common.REPEAT_SCOPE),unchanged_budgets=CONFIG['budgets'],
   jobs=JOBS,cumulative_real_products=214577271056,new_sky_points=74530432)
 def toy_authorization(self,plan):
  # Synthetic hashes can never authorize the physical candidate.
  return dict(schema=common.AUTH_SCHEMA,approved=True,execution_allowed=True,stages=['backend'],
   config_sha256=plan['config_sha256'],source_sha256=plan['source_sha256'],table_sha256=plan['table_sha256'],
   failure_sha256='TOY_FAILURE',failed_execution_end_sha256='TOY_END',failed_execution_identity_sha256='TOY_IDENTITY',repeat_scope=common.REPEAT_SCOPE,budgets=CONFIG['budgets'])
 def put(self,path,value):path.write_text(json.dumps(value,allow_nan=False));return path
 def cache(self,mutate=None):
  job=JOBS[0];base=self.p/job['name'];base.mkdir(exist_ok=True)
  u=np.array(CONFIG['sparse_exact_mass_nodes'],dtype=np.float64)
  g=np.broadcast_to(np.eye(12,dtype=np.complex128),(16,12,12)).copy()
  if mutate:u,g=mutate(u,g)
  np.savez(base/'matrices.npz',u=u,Gamma=g)
  record=dict(schema='C09_HARMONIC_JOB_RECEIPT_v3',status='HARMONIC_ARRAYS_SAVED',
   channel_index=job['channel_index'],level_index=job['level_index'],level=job['level'],
   arrays_sha256=common.sha(base/'matrices.npz'),real_products=job['real_products'],mass_count=16,**IDENTITY)
  self.put(base/'matrices.json',record)
  req=self.put(self.p/(job['name']+'_request.json'),{'scope':'TOY_ONLY'})
  self.put(base/'worker_end.json',dict(status='WORKER_COMPLETED',inputs_unchanged=True,request_sha256=common.sha(req)))
  return base,record
 def passed_backend(self):
  plan=self.toy_plan();base=self.p/'TOY_BACKEND';base.mkdir();gate=base/'gates';gate.mkdir()
  (gate/'data.npz').write_bytes(b'TOY_NOT_REAL_NPZ_DATA');(gate/'harmonic_nodes.npz').write_bytes(b'TOY_NOT_REAL_NPZ_ORF')
  gate_report=dict(status='BACKEND_AND_GENERATION_PASS_ON_SPARSE_NOMINAL14_DOMAIN',data_sha256=common.sha(gate/'data.npz'),harmonic_nodes_sha256=common.sha(gate/'harmonic_nodes.npz'))
  self.put(gate/'backend_result.json',gate_report)
  self.put(base/'backend_result.json',dict(gate_report_sha256=common.sha(gate/'backend_result.json'),**gate_report))
  self.put(base/'execution_identity.json',dict(stage='backend',**IDENTITY))
  r=dict(combined_CPU_seconds=100.,charged_ORF_multiplication_proxy=214577271056,charged_sky_config_points=74530432,
   charged_likelihood_values=448,charged_likelihood_values_by_target={str(i):32 for i in range(14)})
  self.put(base/'execution_end.json',dict(status='CONTROLLER_STAGE_COMPLETED',inputs_unchanged=True,within_resource_limits=True,resources=r))
  a=dict(backend_result_sha256=common.sha(base/'backend_result.json'),backend_execution_end_sha256=common.sha(base/'execution_end.json'))
  return base,plan,a,r
 def test_01_controller_and_worker_import_are_stdlib_only(self):
  self.assertTrue(STDLIB_ONLY_AT_IMPORT)
 def test_02_twelve_jobs_and_cumulative_arithmetic(self):
  self.assertEqual(len(JOBS),13);self.assertEqual(sum(j['matrix_count'] for j in JOBS),192)
  self.assertEqual(sum(j['real_products'] for j in JOBS),145279513928)
  self.assertEqual(69297757128+sum(j['real_products'] for j in JOBS),214577271056)
  self.assertEqual(JOBS[-1]['sky_points'],74530432);self.assertEqual(JOBS[-1]['likelihood_values'],448)
  self.assertEqual(JOBS[-1]['likelihood_by_target'],{str(i):32 for i in range(14)})
  self.assertEqual(max(j.get('basis_and_buffers_estimated_bytes',0) for j in JOBS),563396800)
 def test_03_authorization_binds_failure_repeat_caps_sources_and_stage(self):
  p=self.toy_plan();a=self.toy_authorization(p);path=self.put(self.p/'TOY_auth.json',a)
  self.assertEqual(common.validate_authorization(path,'backend',p),a)
  for key,new in [('failure_sha256','WRONG'),('failed_execution_end_sha256','WRONG'),('failed_execution_identity_sha256','WRONG'),('repeat_scope','RETRY'),
   ('budgets',{}),('source_sha256',{}),('approved',False),('execution_allowed',False)]:
   with self.subTest(key=key):
    self.put(path,{**a,key:new})
    with self.assertRaises(ValueError):common.validate_authorization(path,'backend',p)
  self.put(path,a)
  with self.assertRaises(ValueError):common.validate_authorization(path,'pilot',p)
 def test_04_ledger_includes_historical_controller_and_all_child_cpu(self):
  ledger=controller.Ledger(controller.initial_resources(self.toy_plan()),CONFIG['budgets'])
  ledger.child_CPU=3.5
  with patch.object(controller.time,'process_time',return_value=2.):
   self.assertAlmostEqual(ledger.cpu(),51.879645)
   limits=ledger.reserve(JOBS[0]);self.assertEqual(limits,(548,549))
  self.assertEqual(ledger.real,69297757128+JOBS[0]['real_products'])
  self.assertEqual(ledger.values,0)
 def test_05_reserve_rejects_before_mutation(self):
  baseline=controller.initial_resources(self.toy_plan());ledger=controller.Ledger(baseline,CONFIG['budgets'])
  bad={**JOBS[0],'real_products':250000000000}
  with self.assertRaises(RuntimeError):ledger.reserve(bad)
  self.assertEqual(ledger.real,69297757128)
  ledger.reserved_by_target={'0':60000}
  bad=dict(name='TOY',real_products=0,sky_points=0,likelihood_values=1,likelihood_by_target={'0':1})
  with self.assertRaises(RuntimeError):ledger.reserve(bad)
  self.assertEqual(ledger.reserved_values,0)
 def test_06_cpu_rounding_and_invalid_remainders(self):
  self.assertEqual(common.cpu_limits(5.99),(5,6))
  for x in (0.,.99,-1.,float('nan'),float('inf')):
   with self.subTest(x=x),self.assertRaises((ValueError,RuntimeError)):common.cpu_limits(x)
 def test_07_actual_fresh_TOY_child_preexec_and_startup_exit_cpu(self):
  code="import json,resource,time; t=time.process_time();\nwhile time.process_time()-t<0.025: pass\nprint(json.dumps({'limits':resource.getrlimit(resource.RLIMIT_CPU),'cpu':time.process_time()}))"
  status,cpu=controller.run_child([sys.executable,'-B','-c',code],self.p/'TOY_child.log',(5,6),1024**2)
  child=json.loads((self.p/'TOY_child.log').read_text())
  self.assertEqual(status,0);self.assertEqual(child['limits'],[5,6]);self.assertGreaterEqual(cpu,child['cpu']*.98)
  self.assertGreater(cpu,.025)
 def test_08_valid_tiny_cache_and_identity_mutations(self):
  base,record=self.cache();self.assertEqual(worker.load_cache(np,self.p,JOBS[0],IDENTITY,CONFIG).shape,(16,12,12))
  for key,new in [('channel_index',2),('level_index',2),('level',{}),('real_products',0),('authorization_sha256','WRONG'),('arrays_sha256','WRONG')]:
   with self.subTest(key=key):
    self.put(base/'matrices.json',{**record,key:new})
    with self.assertRaises(ValueError):worker.load_cache(np,self.p,JOBS[0],IDENTITY,CONFIG)
 def test_09_cache_numeric_and_bitexact_mass_rejections(self):
  def negative_zero(u,g):u[0]=-0.;return u,g
  def nonfinite(u,g):g[0,0,0]=np.nan;return u,g
  def nonhermitian(u,g):g[0,0,1]=1j;return u,g
  def negative(u,g):g[0,0,0]=-1.;return u,g
  for mutation in (negative_zero,nonfinite,nonhermitian,negative,lambda u,g:(u,g.astype(np.complex64)),lambda u,g:(u,g[:15])):
   with self.subTest(mutation=mutation):
    self.cache(mutation)
    with self.assertRaises(ValueError):worker.load_cache(np,self.p,JOBS[0],IDENTITY,CONFIG)
 def test_10_each_TOY_matrix_is_persisted_before_later_failure(self):
  class ToyWriter:
   @staticmethod
   def save_npz_new(path,**kw):
    with path.open('xb') as f:np.savez(f,**kw)
   @staticmethod
   def write_new(path,value):common.write_new(path,value)
  u=np.array(CONFIG['sparse_exact_mass_nodes']);g=np.broadcast_to(np.eye(12,dtype=complex),(4,12,12)).copy()
  g[2,0,0]=np.nan
  with self.assertRaises(ValueError):worker.archive_batch(np,ToyWriter,self.p,u,g,0,IDENTITY,JOBS[0])
  self.assertTrue((self.p/'Gamma_000.npz').exists());self.assertTrue((self.p/'Gamma_001.json').exists())
  self.assertFalse((self.p/'Gamma_002.npz').exists());self.assertFalse((self.p/'matrices.npz').exists())
  self.assertEqual(common.read(self.p/'Gamma_000.json')['status'],'SAVED_PARTIAL_ONLY_NOT_GATE_PASS')
 def test_11_pilot_inherits_448_32_each_and_final_lifecycle(self):
  base,plan,a,r=self.passed_backend();self.assertEqual(common.validate_backend_for_pilot(base,a,plan),r)
  ledger=controller.Ledger(r,CONFIG['budgets']);job=dict(real_products=0,sky_points=0,likelihood_values=839552,
   likelihood_by_target={str(i):59968 for i in range(14)})
  ledger.reserve(job);self.assertEqual(ledger.reserved_values,840000);self.assertTrue(all(x==60000 for x in ledger.reserved_by_target.values()))
  for field in ('backend_execution_end_sha256','backend_result_sha256'):
   with self.assertRaises(ValueError):common.validate_backend_for_pilot(base,{**a,field:'WRONG'},plan)
  (base/'gates'/'data.npz').write_bytes(b'MODIFIED_TOY')
  with self.assertRaises(ValueError):common.validate_backend_for_pilot(base,a,plan)
 def test_12_missing_worker_receipt_stops_once_preserves_charge(self):
  plan=self.toy_plan();plan['jobs']=JOBS[:2]
  cfg={**CONFIG,'table_file':'TOY_table.bin'};self.put(self.p/'config.json',cfg);(self.p/'TOY_table.bin').write_bytes(b'TOY_TABLE')
  plan['config_sha256']=common.sha(self.p/'config.json');plan['table_sha256']=common.sha(self.p/'TOY_table.bin')
  auth=self.put(self.p/'TOY_denied_auth.json',dict(schema='TOY_ONLY',approved=False))
  args=SimpleNamespace(stage='backend',backend=None,output=self.p/'TOY_run',approval=auth)
  with patch.object(controller,'HERE',self.p),patch.object(controller,'ROOT',self.p),patch.object(controller,'source_hashes',return_value=plan['source_sha256']),patch.object(controller,'run_child',return_value=(1,.01)) as fake:
   with self.assertRaisesRegex(RuntimeError,'no automatic retry'):controller.execute(args,plan,{})
   self.assertEqual(fake.call_count,1)
  end=common.read(args.output/'execution_end.json')
  self.assertEqual(end['status'],'CONTROLLER_STAGE_FAILED')
  self.assertEqual(end['resources']['charged_ORF_multiplication_proxy'],69297757128+JOBS[0]['real_products'])
  self.assertEqual(end['resources']['charged_likelihood_values'],0)
  self.assertTrue((args.output/'execution_failure.json').exists());self.assertFalse(list(args.output.glob('**/*.npz')))
 def test_13_gate_tail_is_v2_and_pilot_is_delegated_unchanged(self):
  old=(common.V2/'run_nominal14.py').read_text();new=(HERE/'worker.py').read_text()
  a=old[old.index(" errors={'nodes':"):old.index('\n\ndef pilot(')].rstrip()
  b=new[new.index(" errors={'nodes':"):new.index('\n\ndef main(')].rstrip()
  self.assertEqual(a,b)
  self.assertIn("else:core.pilot(config,out,budget,Path(request['backend_path'])/'gates')",new)
  tree=ast.parse(new);gate=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='gates')
  self.assertNotIn('RealHarmonicBasis',ast.unparse(gate))
 def test_14_conservative_peak_sum_keeps_parent_scope_explicit(self):
  ledger=controller.Ledger(controller.initial_resources(self.toy_plan()),CONFIG['budgets']);ledger.maximum_worker_RSS=500
  with patch.object(controller,'rss',return_value=100):self.assertEqual(ledger.report()['sum_of_controller_and_maximum_worker_RSS_peaks_bytes'],600)
 def test_15_table_and_config_are_rehashed_in_final_worker(self):
  code=(HERE/'worker.py').read_text();tail=code[code.index(' finally:'):]
  self.assertIn("sha(ROOT/config['table_file'])==plan['table_sha256']",tail)
  self.assertIn("sha(HERE/'config.json')==plan['config_sha256']",tail)
 def test_16_worker_request_guards_before_scientific_imports(self):
  plan=self.toy_plan();auth=self.toy_authorization(plan);authpath=self.put(self.p/'TOY_auth.json',auth)
  identity={**IDENTITY,'authorization_sha256':common.sha(authpath)}
  self.put(self.p/'execution_identity.json',identity)
  job=JOBS[0]
  request=dict(schema='C09_FRESH_WORKER_REQUEST_v3',job=job,stage='backend',campaign=str(self.p),
   authorization_path=str(authpath),previous_CPU_seconds=50.,previous_likelihood_values=0,
   previous_likelihood_by_target={},**identity)
  path=self.put(self.p/(job['name']+'_request.json'),request)
  self.assertEqual(worker.validate_request(path,common.sha(path),plan)[0],request)
  for key,value in [('previous_likelihood_values',1),('previous_CPU_seconds',0.),('source_sha256',{}),
                    ('job',{**job,'channel_index':3})]:
   with self.subTest(key=key):
    self.put(path,{**request,key:value})
    with self.assertRaises(ValueError):worker.validate_request(path,common.sha(path),plan)
  self.put(path,request)
  with self.assertRaises(ValueError):worker.validate_request(path,'WRONG_REQUEST_HASH',plan)
 def test_17_pilot_worker_cannot_reset_backend_counts(self):
  backend,plan,bindings,r=self.passed_backend();auth={**self.toy_authorization(plan),**bindings,'stages':['pilot']}
  authpath=self.put(self.p/'TOY_pilot_auth.json',auth)
  campaign=self.p/'TOY_pilot';campaign.mkdir()
  identity={**IDENTITY,'authorization_sha256':common.sha(authpath)}
  self.put(campaign/'execution_identity.json',identity)
  request=dict(schema='C09_FRESH_WORKER_REQUEST_v3',job=dict(name='pilot',kind='pilot'),stage='pilot',
   campaign=str(campaign),backend_path=str(backend),authorization_path=str(authpath),
   previous_CPU_seconds=101.,previous_likelihood_values=448,previous_likelihood_by_target=r['charged_likelihood_values_by_target'],**identity)
  path=self.put(campaign/'pilot_request.json',request)
  self.assertEqual(worker.validate_request(path,common.sha(path),plan)[0]['previous_likelihood_values'],448)
  self.put(path,{**request,'previous_likelihood_values':0,'previous_likelihood_by_target':{}})
  with self.assertRaises(ValueError):worker.validate_request(path,common.sha(path),plan)

if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ToyGuards))
 children=resource.getrusage(resource.RUSAGE_CHILDREN)
 report=dict(schema='C09_V3_TOY_GUARDS_REPORT',scope='NEW_CONTINUATION_GUARDS_ONLY_NO_PHYSICS',
  tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),physical_ORF=0,physical_likelihood=0,physical_draws=0,
  CPU_seconds_self=time.process_time(),CPU_seconds_children=children.ru_utime+children.ru_stime,
  peak_RSS_bytes=common.rss(),limits=dict(CPU_seconds=30,RSS_bytes=128*1024**2),
  memory_scope='Measured test process peak; actual TOY child uses only stdlib and negligible arrays',
  previous_six_kernel_adapter_tests_repeated=False)
 report['within_limits']=report['CPU_seconds_self']+report['CPU_seconds_children']<=30 and report['peak_RSS_bytes']<=128*1024**2
 (HERE/'toy_test_result.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 print(json.dumps(report));sys.exit(0 if result.wasSuccessful() and report['within_limits'] else 1)
