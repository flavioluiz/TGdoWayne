# Preflight C09 nominal14 v3 — candidato sem execução autorizada

## Estado preservado e alcance

O v2 falhou após os canais 1–3 e a construção da base coarse do canal 4, antes do primeiro lote desse canal. RSS medido: **1.931.083.776 B**, acima de 1,5 GiB. Não há cache Γ arquivado em `tmp/c09_nominal14_backend_v2`; não se cria cache fictício. O registro final cobra **69.297.757.128 produtos reais** e **46,379645 s CPU**; os contadores de céu, likelihood e draws são zero. O v3 mantém esse resultado FAILED, sua identidade e seu custo.

Vínculos históricos:

- Falha SHA256: `62c29fa973714c23f584261c0a40fca22e25888bbe709894a7cfefdc1fbb0911`.
- Execution end SHA256: `63902c8b68f26d6c2de9013f3560e58e1251ad8d7664d9affdd07716d31582ff`.
- Identidade SHA256: `0bff5f8624b87810ce043d5f6eb962672775e486618463891c7e496d9301ac80`.
- Aprovação histórica v2 SHA256: `d1c2bdf0c06e99d6ebaf10450fbca13387b77e6c52d09db9a20aaaf1d11f0780`; ela não autoriza v3.

A configuração v3 é igual à configuração executada v2 em todos os campos, exceto `schema`; o preflight verifica essa igualdade e o hash do config executado. Closure inclui `src/inference/__init__.py`, todos os 24 arquivos de fontes v2 executadas, config/preflight v2 e três fontes v3: **29 vínculos de leitura**, além do hash próprio do config v3. A tabela C07 é somente lida e revalidada por SHA, sem edição ou respline diferente.

## Processos, persistência e gates

Os 12 jobs são sequenciais; cada par `(frequência, resolução)` usa um processo Python novo e uma única base. A ordem dos níveis permanece H00, H01, H11:

| Canal | H00 `(lmax,nmu)` | H01 | H11 |
|---|---|---|---|
| 1 | (1496,3012) | (1496,3092) | (1536,3092) |
| 2 | (2892,5805) | (2892,5885) | (2932,5885) |
| 3 | (4288,8597) | (4288,8677) | (4328,8677) |
| 4 | (5685,11390) | (5685,11470) | (5725,11470) |

Massas: `[0,.001,.05,.1,.2,.33,.5,.71,.8,.9,.93,.99,.995,.9999,1-1e-8,1]`. Cada Γ tem forma 12×12 complex128. São 16 matrizes por job, **192 matrizes novas**, sem alteração de βk, fases, normalização, semente ou regra harmônica. A avaliação permanece em lotes de 4 para manter a operação BLAS v2. Assim que um lote retorna, cada matriz é validada e salva em `Gamma_NNN.npz` + recibo; antes do próximo lote. Um processo interrompido durante a operação BLAS não pode salvar uma matriz que não retornou. Os 16 valores são também consolidados em `matrices.npz` ao final do job.

O controlador verifica recibo, hash, canal, nível, custo, fontes, autorização e falha ancestral antes do próximo filho. O processo de gates confere adicionalmente membros NPZ, dtype/shape, bytes exatos das 16 massas (inclusive zero com sinal), finitude, Hermiticidade e PSD de cada cache. Arrays parciais nunca são aceitos como job concluído. Não há retomada/retry automático; nova falha exige decisão e identidade próprias.

Só depois dos 12 jobs concluídos começa um processo novo de gates, sem construir bases. Ele recebe cerca de 432 KiB de Γ brutas consolidadas e executa o trecho numérico literal do backend v2: harmônico/PSD, céu direto esparso, 14 dados físicos + 14 controles Gaussianos correspondentes, carregamento da tabela C07 e 448 valores de likelihood. A tabela é rehashada imediatamente após carregar e ao final. Não existe `backend_result` PASS de v3 neste pacote.

Só um futuro backend PASS revisado permite pedir autorização para o piloto. Seu cálculo usa `core.pilot` v2 intacto, incluindo GK com erro do numerador na razão, topologia de igualdades e contadores corrigidos. A autorização do piloto exige hashes de `backend_result.json` e `execution_end.json` final; controller e worker verificam a herança de 448 valores, **32 por ID**. Nunca usam o CPU parcial de `backend_result.resources`.

## Aritmética e tetos inalterados

Para cada job, com `N=16`, `P=12`, `L=lmax−1`, os custos são `4*nmu*L+6*P²*L` de construção e `2*N*P*nmu*L+6*N*P²*L+16*N*P*nmu` de avaliação. São proxies explícitos dos mesmos produtos reais v2; CPU contabiliza também imports, raízes, E/S e todos os demais trabalhos.

| Quantidade | Valor |
|---|---:|
| v2 perdido, já cobrado | 69.297.757.128 reais |
| Recomputação integral necessária v3 | 145.279.513.928 reais |
| Cumulativo reservado | **214.577.271.056 reais** |
| Margem ao teto 250 G | 35.422.728.944 reais |
| Céu novo e cumulativo | 74.530.432 pontos |
| Margem ao teto 80 M | 5.469.568 pontos |
| Backend likelihood | 448 = 14×16×2 |
| Backend por ID | 32 |
| Piloto restante por ID | 59.968 |
| Piloto máximo efetivo restante | 839.552 |
| Backend + piloto máximo efetivo | 840.000, sob teto global 1 M |
| CPU histórico conhecido | 46,379645 s |
| CPU restante nominal ao teto 600 s | 553,620355 s, antes do novo controller/filhos |

O controlador reserva o job inteiro **antes** de iniciar o filho. Falha conserva a reserva; não apresenta uma reserva como operação concluída. Se o filho morrer sem recibo, o número observado de likelihood fica indisponível e a reserva é preservada separadamente. O fluxo para e não repete. A sequência completa usa a mesma reserva total acima.

O CPU cumulativo é `46,379645 + time.process_time(controller desde startup) + ΣΔRUSAGE_CHILDREN`, com tempo de usuário+sistema, imports e exit de todos os novos filhos. Antes de cada filho, `preexec_fn` estabelece `RLIMIT_CPU=(floor(restante), floor(restante)+1)` e `RLIMIT_FSIZE=20MiB`; o worker confere o limite antes dos imports científicos. Após a saída, o controlador cobra o CPU final medido por `RUSAGE_CHILDREN`, revalida limites e só então avança. Não se reinicia contador no processo novo.

Limite preciso do relato: o registro v2 de 46,379645 s não mede sua própria serialização final/exit; o v3 não inventa esse valor. O novo `execution_end` mede o controller até os hashes finais, mas sua própria serialização/exit ocorre depois. Os exits dos filhos são medidos integralmente pelo controller. Uma medição externa do encerramento do controller pode complementar esses custos; os recibos explicitam esse alcance e não proclamam exatidão do lifecycle ainda não observado.

## Memória

Tetos preservados: **1.610.612.736 B (1,5 GiB) RSS**, estimativa numérica 1.400.000.000 B, saída total 20 MiB, um thread BLAS, lotes harmônicos 4 e likelihood 32. Nenhum teto foi ampliado.

A maior estimativa de base + buffers é **563.396.800 B**; com reserva adicional de 32 MiB no worker, 596.951.232 B. Cada processo descarta seu espaço de endereçamento ao terminar; não há acumulação das 12 bases no controlador, que não importa NumPy/SciPy.

O gate conserva a estimativa v2 do construtor C07: **1.339.424.768 B**, a partir de matrizes 76.824.576 B, coeficientes 307.261.440 B e temporários previstos. Céu direto em blocos: 153.660.032 B estimados, sem bases harmônicas. Somando 128 MiB de margem do worker e 32 MiB do controller ao pico previsto do construtor: **1.507.196.928 B**, com **103.415.808 B** de margem ao teto.

Isso é aritmética, **não uma garantia RSS medida do construtor fresco**. O allocator pode reter temporários dos gates anteriores; bibliotecas/sistema podem aumentar o pico. O `Budget` v2 guarda RSS do worker nas mesmas fronteiras e o controller exige adicionalmente `pico_RSS_controller + máximo_pico_RSS_worker <= 1,5GiB`, uma soma conservadora de picos potencialmente não simultâneos. Não existe limite OS duro de memória nem monitor contínuo; uma alocação pode ultrapassar antes do próximo guard, como no v2. Uma nova falha permanecerá falha; não autoriza aumento automático.

As Γ brutas dos 12 jobs ocupam 442.368 B; salvando matrizes individuais e consolidadas, 884.736 B antes de compressão/cabeçalhos. A cópia dos níveis finos e os pequenos recibos/dados ficam sob o limite de saída, verificado antes de cada arquivo e ao término do filho. `RLIMIT_FSIZE` limita um arquivo, enquanto a verificação explícita cobre o diretório inteiro.

## Contrato de autorização prospectivo

O schema exigido é `ROOT_C09_NOMINAL14_CONTINUATION_APPROVAL_v3`. Sem arquivo fornecido por ROOT, `approved=true`, `execution_allowed=true` e estágio aprovado, nada físico é alcançado. Devem coincidir exatamente `config_sha256`, mapa `source_sha256`, `table_sha256`, `failure_sha256`, `failed_execution_end_sha256`, `failed_execution_identity_sha256`, `budgets` e:

`repeat_scope = RECOMPUTE_ALL_12_HARMONIC_JOBS_AFTER_UNARCHIVED_V2_RSS_FAILURE`.

O piloto ainda exige os dois hashes do backend concluído/revisado descritos acima. A saída tem que ser nova; identidades, requests, reservas e resultados usam escrita exclusiva. Este preflight tem `execution_enabled=false`, não contém autorização e não é aprovação científica.

## Verificação realizada

**17 testes novos TOY passaram**, somente stdlib e matrizes identidade 12×12, incluindo filho real TOY de ~0,025 s para `preexec`/`RUSAGE_CHILDREN`. Última execução: 0,568954 s CPU própria + 0,100531 s dos filhos; RSS 49.283.072 B. Três execuções justificadas pelos guards adicionados somaram 2,028962 s CPU de teste. Limites deste trabalho: 30 s CPU / 128 MiB. Nenhuma ORF, likelihood, geração ou posterior físico foi executado. Os seis testes prévios de kernel/adaptador intactos não foram repetidos.

Os testes cobrem autorizações/hash/repetição, 12 jobs e aritmética cumulativa, reserva antes de trabalho, herança 32/ID, limites CPU de filho, cache bitexact e rejeições, persistência parcial antes de falha, stop sem retry, bindings de request e piloto, soma conservadora de memória e rehash final. A igualdade literal do trecho de gates e delegação ao piloto v2 foram verificadas por texto/AST. Isso não valida o novo backend físico nem demonstra convergência de posterior.
