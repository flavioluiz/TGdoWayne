"""One fresh C09 v3 worker. Physics requires a source-bound controller request."""
from pathlib import Path
import argparse,json,math,os,resource,sys,time,traceback
from common import (HERE,ROOT,V2,sha,read,write_new,preflight,source_hashes,
                    validate_authorization,validate_cache_report,validate_backend_for_pilot)


def validate_request(path,expected_hash,plan):
 if sha(path)!=expected_hash:raise ValueError('Worker request hash differs')
 r=read(path);campaign=Path(r['campaign']);identity=read(campaign/'execution_identity.json')
 a=validate_authorization(Path(r['authorization_path']),r['stage'],plan)
 if (r.get('schema')!='C09_FRESH_WORKER_REQUEST_v3' or r['authorization_sha256']!=sha(r['authorization_path'])
     or r['config_sha256']!=plan['config_sha256'] or r['source_sha256']!=plan['source_sha256']
     or r['failure_sha256']!=plan['failure']['failure_sha256']
     or any(identity.get(k)!=r[k] for k in ('config_sha256','source_sha256','authorization_sha256','failure_sha256'))):
  raise ValueError('Worker request/source/authorization/campaign identity differs')
 job=r['job']
 if job['kind'] in ('harmonic','gates'):
  expected=next((x for x in plan['jobs'] if x['name']==job['name']),None)
  if r['stage']!='backend' or job!=expected:raise ValueError('Unknown or changed backend job')
 elif job['kind']!='pilot' or r['stage']!='pilot' or job['name']!='pilot':raise ValueError('Unknown worker kind')
 previous=r['previous_CPU_seconds']
 if isinstance(previous,bool) or not isinstance(previous,(float,int)) or not math.isfinite(previous) or not plan['failure']['CPU_seconds']<=previous<600:
  raise ValueError('Worker cumulative CPU baseline differs')
 if r['stage']=='pilot':
  inherited=validate_backend_for_pilot(Path(r['backend_path']),a,plan)
  if (r['previous_likelihood_values']!=inherited['charged_likelihood_values']
      or r['previous_likelihood_by_target']!=inherited['charged_likelihood_values_by_target']
      or previous<inherited['combined_CPU_seconds']):raise ValueError('Worker must inherit passed final backend ledger')
 elif r['previous_likelihood_values']!=0 or r['previous_likelihood_by_target']!={}:raise ValueError('Unexpected backend likelihood baseline')
 if path.resolve()!=campaign.resolve()/(job['name']+'_request.json'):raise ValueError('Request is outside its campaign job')
 return r,identity


def load_cache(np,campaign,job,identity,config):
 base=campaign/job['name'];record=read(base/'matrices.json');path=base/'matrices.npz'
 validate_cache_report(record,job,identity,sha(path))
 end=read(base/'worker_end.json')
 if end.get('status')!='WORKER_COMPLETED' or end.get('inputs_unchanged') is not True:raise ValueError('Harmonic worker did not finish unchanged')
 if end['request_sha256']!=sha(campaign/(job['name']+'_request.json')):raise ValueError('Cache worker request changed')
 with np.load(path,allow_pickle=False) as f:
  if set(f.files)!={'u','Gamma'}:raise ValueError('Unexpected harmonic cache members')
  u,g=f['u'],f['Gamma']
 expected=np.array(config['sparse_exact_mass_nodes'],dtype=np.float64)
 if (u.dtype!=np.dtype('float64') or u.shape!=expected.shape or u.tobytes()!=expected.tobytes()
     or g.dtype!=np.dtype('complex128') or g.shape!=(16,12,12) or not np.isfinite(g).all()
     or np.max(abs(g-g.swapaxes(-1,-2).conj()))>1e-12 or np.linalg.eigvalsh(g).min()<-1e-12):
  raise ValueError('Cache mass bytes/shape/dtype/finitude/Hermitian/PSD differ')
 return g


def archive_batch(np,core,out,masses,gamma,first,identity,job):
 """Persist each computed TOY or physical matrix; partial files imply no gate PASS."""
 for offset,matrix in enumerate(gamma):
  index=first+offset;name=f'Gamma_{index:03d}.npz'
  if (matrix.shape!=(12,12) or not np.isfinite(matrix).all()
      or np.max(abs(matrix-matrix.T.conj()))>1e-12 or np.linalg.eigvalsh(matrix).min()<-1e-12):
   raise ValueError('Individual harmonic matrix failed finite/Hermitian/PSD guard')
  core.save_npz_new(out/name,u=masses[index:index+1],Gamma=matrix)
  core.write_new(out/f'Gamma_{index:03d}.json',dict(schema='C09_PARTIAL_HARMONIC_MATRIX_v3',
   status='SAVED_PARTIAL_ONLY_NOT_GATE_PASS',mass_index=index,arrays_sha256=sha(out/name),
   channel_index=job['channel_index'],level_index=job['level_index'],level=job['level'],
   **{key:identity[key] for key in ('config_sha256','source_sha256','authorization_sha256','failure_sha256')}))


def harmonic(np,core,config,out,budget,job,identity):
 from inference.model import experiment
 from inference.orf_blas import RealHarmonicBasis,TableBudget
 e=experiment(read(ROOT/config['experiment_config']));masses=np.array(config['sparse_exact_mass_nodes'])
 k=job['channel_index'];level=job['level'];P=len(e['points']);B=config['budgets']['batch_size_harmonic']
 l,n=level['lmax'],level['nmu'];phase=2*np.pi*e['f'][k]*e['distance_ly']*365.25*86400
 beta=np.sqrt((1-masses/(k+1))*(1+masses/(k+1)))
 budget.products(4*n*(l-1)+6*P*P*(l-1))
 basis=RealHarmonicBasis(e['points'],lmax=l,nmu=n,budget=TableBudget(700*1024**2,50000000000,4),planned_batch=B)
 budget.check();gamma=np.empty((len(masses),P,P),complex)
 for first in range(0,len(masses),B):
  count=min(B,len(masses)-first)
  budget.products(2*count*P*n*(l-1)+6*count*P*P*(l-1)+16*count*P*n)
  gamma[first:first+count]=basis.evaluate(beta[first:first+count],phase)
  archive_batch(np,core,out,masses,gamma[first:first+count],first,identity,job)
  budget.check()
 if (not np.isfinite(gamma).all() or np.max(abs(gamma-gamma.swapaxes(-1,-2).conj()))>1e-12
     or np.linalg.eigvalsh(gamma).min()<-1e-12):raise ValueError('Harmonic output failed finite/Hermitian/PSD guard')
 # Archive before this process exits; no future worker can depend on RAM here.
 core.save_npz_new(out/'matrices.npz',u=masses,Gamma=gamma)
 record=dict(schema='C09_HARMONIC_JOB_RECEIPT_v3',status='HARMONIC_ARRAYS_SAVED',
  channel_index=k,level_index=job['level_index'],level=level,mass_count=len(masses),
  arrays_sha256=sha(out/'matrices.npz'),real_products=budget.charged_products,
  **{name:identity[name] for name in ('config_sha256','source_sha256','authorization_sha256','failure_sha256')})
 if record['real_products']!=job['real_products']:raise ValueError('Single-worker product ledger differs from preflight')
 core.write_new(out/'matrices.json',record)


def gates(np,core,config,out,budget,campaign,plan,identity):
 import gc
 from inference.model import experiment
 from pta.orf import raw_direct_orf
 from kernels import generate_row,ConditionalKernel
 save_npz_new=core.save_npz_new;write_new=core.write_new;digest=sha;experiment_and_table=core.experiment_and_table
 e=experiment(read(ROOT/config['experiment_config']));masses=np.array(config['sparse_exact_mass_nodes'])
 N=len(masses);K=len(e['f']);P=len(e['points']);stages=np.empty((3,N,K,P,P),complex);costs=[]
 for job in plan['jobs']:
  if job['kind']=='harmonic':
   stages[job['level_index'],:,job['channel_index']]=load_cache(np,campaign,job,identity,config)
   costs.append(dict(channel=job['channel_index']+1,**job['level'],worker=job['name'],separate_process=True))
 # The following numerical gate/generation/table checks are unchanged v2 math.
 errors={'nodes':float(np.max(abs(stages[1]-stages[0]))),'ell':float(np.max(abs(stages[2]-stages[1])))}
 minimum=float(np.linalg.eigvalsh(stages).min());gamma=stages[2].copy()
 harmonic_pass=errors['nodes']<=config['gates']['harmonic_nodes_abs'] and errors['ell']<=config['gates']['harmonic_ell_abs'] and minimum>=config['gates']['PSD_minimum']
 save_npz_new(out/'harmonic_nodes.npz',u=masses,Gamma=gamma,errors_nodes=np.max(abs(stages[1]-stages[0]),axis=(-2,-1)),errors_ell=np.max(abs(stages[2]-stages[1]),axis=(-2,-1)))
 del stages;gc.collect()
 if not harmonic_pass:
  write_new(out/'backend_result.json',{'status':'HARMONIC_UNRESOLVED','errors':errors,'minimum_eigenvalue':minimum,'costs':costs,'resources':budget.report()})
  return False
 direct=[]
 for case in config['direct_sky_cases']:
  k=case['channel']-1;u=case['u'];a,b=case['pair'];phase=2*np.pi*e['f'][k]*e['distance_ly']*365.25*86400;values=[]
  for res in config['direct_sky_resolutions']:
   budget.sky_points(res['nmu']*res['nphi'])
   value=raw_direct_orf(math.sqrt((1-u/(k+1))*(1+u/(k+1))),float(e['points'][a]@e['points'][b]),phase[a],phase[b],nmu=res['nmu'],nphi=res['nphi'])
   values.append(value);budget.check()
  ref=gamma[np.flatnonzero(masses==u)[0],k,a,b]
  direct.append({**case,'coarse':[values[0].real,values[0].imag],'fine':[values[1].real,values[1].imag],'refinement_error':abs(values[1]-values[0]),'harmonic_error':abs(values[1]-ref)})
 direct_pass=all(x['refinement_error']<=config['gates']['direct_refinement_abs'] and x['harmonic_error']<=config['gates']['harmonic_direct_abs'] for x in direct)
 if not direct_pass:
  write_new(out/'backend_result.json',{'status':'DIRECT_SKY_UNRESOLVED','errors':errors,'direct':direct,'resources':budget.report()})
  return False
 # Draws are engineering fixtures under exact, checked truth matrices, not posterior samples.
 data=[]
 for row in config['rows']:
  truth_gamma=gamma[np.flatnonzero(masses==row['fixed_truth_u'])[0]]
  data.append(generate_row(e,row,truth_gamma,config['seeds']['generation']))
 save_npz_new(out/'data.npz',**{name:np.concatenate([d[name] for d in data]) for name in ['q','x_physical','x_gaussian']},truth_u=np.array([r['fixed_truth_u'] for r in config['rows']]),target=np.arange(14))
 _,table=experiment_and_table(config,budget);interpolated=table(masses)
 anchor=gamma[np.flatnonzero(masses==config['anchor_mass'])[0]];anchor_table=table(np.array([config['anchor_mass']]))[0]
 differences=[]
 for row,d in zip(config['rows'],data):
  exact_kernel=ConditionalKernel(e,row,d,anchor);table_kernel=ConditionalKernel(e,row,d,anchor_table)
  budget.likelihood(N*2,row['id'])
  lexact=exact_kernel(gamma);ltable=table_kernel(interpolated);budget.check()
  differences.append({'target':row['id'],'analysis':row['analysis'],'max_abs_logL_difference':float(np.max(abs(lexact-ltable))),'argmax_u':float(masses[np.argmax(abs(lexact-ltable))])})
 table_pass=all(x['max_abs_logL_difference']<=config['gates']['table_sparse_abs_logL'] for x in differences)
 write_new(out/'backend_result.json',{'status':'BACKEND_AND_GENERATION_PASS_ON_SPARSE_NOMINAL14_DOMAIN' if table_pass else 'NEW_SCENARIO_TABLE_LOG_LIKELIHOOD_UNRESOLVED',
 'scope':'SPARSE_PHYSICAL_BACKEND_AND_ENGINEERING_DATA_ONLY_NOT_POSTERIOR','harmonic_errors':errors,'minimum_eigenvalue':minimum,'direct':direct,'table_likelihood_checks':differences,
 'table_matrix_max_abs_difference_descriptive':float(np.max(abs(interpolated-gamma))),'costs':costs,'resources':budget.report(),
 'data_sha256':digest(out/'data.npz'),'harmonic_nodes_sha256':digest(out/'harmonic_nodes.npz'),'global_ORF_error_certificate':False})
 return table_pass


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--request',type=Path,required=True)
 parser.add_argument('--request-sha256',required=True);args=parser.parse_args();plan=preflight()
 request,identity=validate_request(args.request,args.request_sha256,plan)
 if list(resource.getrlimit(resource.RLIMIT_CPU))!=request['CPU_limits']:raise RuntimeError('Worker requires the controller pre-exec CPU limit')
 for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
  if os.environ.get(key)!='1':raise RuntimeError('Single-thread environment required before scientific imports')
 config=read(HERE/'config.json');campaign=Path(request['campaign']);out=campaign/request['job']['name'];out.mkdir(exist_ok=False)
 # All heavy imports occur only after authorization/request validation.
 sys.path.insert(0,str(V2));sys.path.insert(0,str(ROOT/'src'))
 import numpy as np
 import run_nominal14 as core
 core.ACTIVE_OUTPUT_BUDGET=(campaign,config['budgets']['output_bytes'])
 budget=core.Budget(config['budgets'],previous=request['previous_CPU_seconds'],
  previous_values=request['previous_likelihood_values'],previous_by_target=request['previous_likelihood_by_target'])
 complete=False
 try:
  budget.check()
  kind=request['job']['kind']
  if kind=='harmonic':harmonic(np,core,config,out,budget,request['job'],identity)
  elif kind=='gates':
   if not gates(np,core,config,out,budget,campaign,plan,identity):raise RuntimeError('Finite backend gate unresolved')
  else:core.pilot(config,out,budget,Path(request['backend_path'])/'gates')
  budget.check();complete=True
 except Exception as exc:
  core.write_new(out/'worker_failure.json',dict(status='FAILED_NO_AUTOMATIC_RETRY',error=str(exc),traceback=traceback.format_exc(),resources=budget.report()))
  raise
 finally:
  unchanged=(source_hashes(config)==plan['source_sha256'] and sha(HERE/'config.json')==plan['config_sha256']
             and sha(ROOT/config['table_file'])==plan['table_sha256'])
  resources=budget.report()
  within=resources['combined_CPU_seconds']<=600 and resources['peak_RSS_bytes']<=config['budgets']['RSS_bytes']
  core.write_new(out/'worker_end.json',dict(schema='C09_FRESH_WORKER_END_v3',
   status='WORKER_COMPLETED' if complete and unchanged and within else 'WORKER_FAILED',
   request_sha256=args.request_sha256,inputs_unchanged=unchanged,resources=resources,
   CPU_final_child_exit_measured_by_controller=True))
  if not unchanged or not within:raise RuntimeError('Final worker input/resource guard failed')

if __name__=='__main__':main()
