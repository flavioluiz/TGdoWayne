"""Small stdlib-only C09 v3 contracts. No numerical imports or physical work."""
from pathlib import Path
import hashlib,json,math,os,platform,resource,sys,time
from importlib.metadata import version
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
V2=ROOT/'tmp/c09_nominal14_v2';FAILED=ROOT/'tmp/c09_nominal14_backend_v2'
AUTH_SCHEMA='ROOT_C09_NOMINAL14_CONTINUATION_APPROVAL_v3'
REPEAT_SCOPE='RECOMPUTE_ALL_12_HARMONIC_JOBS_AFTER_UNARCHIVED_V2_RSS_FAILURE'

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()

def read(path):return json.loads(Path(path).read_text())
def saved_bytes(root):return sum(p.stat().st_size for p in Path(root).rglob('*') if p.is_file())
def write_new(path,value,*,output_root=None,cap=None):
 payload=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
 if output_root is not None and saved_bytes(output_root)+len(payload)>cap:raise RuntimeError('Output ceiling exceeded before writing')
 with Path(path).open('xb') as f:f.write(payload)

def rss():
 r=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 return int(r if sys.platform=='darwin' else r*1024)

def integer(x,name):
 if type(x) is not int or x<0:raise ValueError('Nonnegative integer required: '+name)
 return x

def source_hashes(config):
 names=set(config['dependencies'])
 names.update(str((V2/name).relative_to(ROOT)) for name in ('run_nominal14.py','planning.py','kernels.py'))
 names.update(str((V2/name).relative_to(ROOT)) for name in ('config.json','executable_preflight.json'))
 names.update(str((HERE/name).relative_to(ROOT)) for name in ('common.py','run_nominal14.py','worker.py'))
 return {name:sha(ROOT/name) for name in sorted(names)}

def failure_record():
 failure=read(FAILED/'execution_failure.json');end=read(FAILED/'execution_end.json');identity=read(FAILED/'execution_identity.json')
 r=end['resources']
 if (failure.get('exception')!='MemoryError' or failure.get('reason')!='Operational RSS ceiling reached'
     or end.get('execution_completed') is not False or end.get('source_unchanged') is not True
     or end.get('table_unchanged') is not True or end.get('config_unchanged') is not True
     or r['charged_ORF_multiplication_proxy']!=69297757128 or r['combined_CPU_seconds']!=46.379645
     or r['charged_likelihood_values']!=0 or r['charged_sky_config_points']!=0):
  raise ValueError('Expected frozen failed v2 continuation basis differs')
 if list(FAILED.glob('*.npz')):raise ValueError('Unexpected v2 arrays: do not invent or silently reuse a cache')
 return dict(failure_sha256=sha(FAILED/'execution_failure.json'),execution_end_sha256=sha(FAILED/'execution_end.json'),
  execution_identity_sha256=sha(FAILED/'execution_identity.json'),CPU_seconds=r['combined_CPU_seconds'],
  real_products=r['charged_ORF_multiplication_proxy'],sky_points=0,likelihood_values=0,
  likelihood_by_target={},RSS_peak_bytes=r['peak_RSS_bytes'],archived_Gamma_available=False,
  original_approval_sha256=identity['approval_sha256'],repeat_scope=REPEAT_SCOPE)

def job_plan(config):
 N=len(config['sparse_exact_mass_nodes']);P=12;B=config['budgets']['batch_size_harmonic'];jobs=[]
 for k,item in enumerate(config['harmonic_resolutions']):
  for j,level in enumerate(item['levels']):
   l,n=level['lmax'],level['nmu'];L=l-1
   construction=4*n*L+6*P*P*L
   evaluation=2*N*P*n*L+6*N*P*P*L+16*N*P*n
   memory=8*n*L+8*P*P*L+64*n+16*B*P*n+96*B*n+64*B*P*L+64*B*P*P
   jobs.append(dict(name=f'harmonic_{k}_{j}',kind='harmonic',channel_index=k,level_index=j,
    level=level,real_products=construction+evaluation,construction_real=construction,evaluation_real=evaluation,
    sky_points=0,likelihood_values=0,likelihood_by_target={},matrix_count=N,
    basis_and_buffers_estimated_bytes=memory))
 sky=len(config['direct_sky_cases'])*sum(r['nmu']*r['nphi'] for r in config['direct_sky_resolutions'])
 jobs.append(dict(name='gates',kind='gates',real_products=0,sky_points=sky,likelihood_values=14*N*2,
  likelihood_by_target={str(i):2*N for i in range(14)},matrix_count=0))
 return jobs

def preflight():
 c=read(HERE/'config.json');old=read(V2/'config.json')
 if c['versions']!={'python':platform.python_version(),'numpy':version('numpy'),'scipy':version('scipy')}:raise ValueError('Frozen numerical versions differ')
 if {k:v for k,v in c.items() if k!='schema'}!={k:v for k,v in old.items() if k!='schema'}:raise ValueError('Scientific configuration changed')
 failed=failure_record();jobs=job_plan(c);new=sum(j['real_products'] for j in jobs)
 expected=read(V2/'executable_preflight.json')
 if sha(V2/'config.json')!=read(FAILED/'execution_identity.json')['config_sha256']:raise ValueError('Executed v2 config changed')
 if new!=145279513928:raise ValueError('Full recomputation arithmetic differs')
 if (expected['interpolator_constructor_estimated_numeric_peak']>c['budgets']['estimated_numeric_bytes']
     or failed['real_products']+new>c['budgets']['real_multiplications']
     or jobs[-1]['sky_points']>c['budgets']['direct_sky_points']):raise ValueError('Prospective arithmetic exceeds original caps')
 h=source_hashes(c)
 if sha(ROOT/c['table_file'])!=c['table_sha256']:raise ValueError('Frozen C07 table hash differs')
 for name,digest in read(FAILED/'execution_identity.json')['source_sha256'].items():
  if sha(ROOT/name)!=digest:raise ValueError('Frozen executed v2 source changed: '+name)
 return dict(schema='C09_NOMINAL14_FRESH_PROCESS_PREFLIGHT_v3',status='CANDIDATE_NO_EXECUTION_AUTHORIZATION',
  config_sha256=sha(HERE/'config.json'),source_sha256=h,table_sha256=c['table_sha256'],failure=failed,jobs=jobs,
  new_real_products=new,cumulative_real_products=failed['real_products']+new,
  cumulative_real_margin=c['budgets']['real_multiplications']-failed['real_products']-new,
  new_sky_points=jobs[-1]['sky_points'],new_likelihood_values=jobs[-1]['likelihood_values'],
  known_CPU_seconds_already_spent=failed['CPU_seconds'],remaining_reported_CPU_seconds=600-failed['CPU_seconds'],
  CPU_scope='failed v2 final sample + all current controller process CPU + child RUSAGE_CHILDREN deltas including startup/exit',
  maximum_fresh_basis_estimated_bytes=max(j.get('basis_and_buffers_estimated_bytes',0) for j in jobs),
  fresh_gate_interpolator_estimate_bytes=expected['interpolator_constructor_estimated_numeric_peak'],
  controller_numeric_imports=False,one_basis_per_process=True,cache_written_after_each_job=True,
  individual_matrix_files_written_after_each_batch=True,physical_matrix_evaluations_new=192,
  unchanged_budgets=c['budgets'],execution_enabled=False,automatic_retry=False,
  resource_warning='Fresh processes address lifetime accumulation; no measured guarantee for fresh table constructor RSS.')

def validate_authorization(path,stage,plan):
 a=read(path)
 if (a.get('schema')!=AUTH_SCHEMA or a.get('approved') is not True or a.get('execution_allowed') is not True
     or stage not in a.get('stages',[]) or a.get('config_sha256')!=plan['config_sha256']
     or a.get('source_sha256')!=plan['source_sha256'] or a.get('table_sha256')!=plan['table_sha256']
     or a.get('failure_sha256')!=plan['failure']['failure_sha256']
     or a.get('failed_execution_end_sha256')!=plan['failure']['execution_end_sha256']
     or a.get('failed_execution_identity_sha256')!=plan['failure']['execution_identity_sha256']
     or a.get('repeat_scope')!=REPEAT_SCOPE or a.get('budgets')!=plan['unchanged_budgets']):
  raise ValueError('Exact v3 continuation/failure/repetition/budget authorization required')
 return a

def cpu_limits(remaining):
 if not math.isfinite(remaining):raise ValueError('Finite CPU remainder required')
 seconds=math.floor(remaining)
 if seconds<1:raise RuntimeError('Less than one second remains in combined CPU budget')
 return seconds,seconds+1

def validate_cache_report(record,job,identity,arrays_sha256):
 expected=dict(schema='C09_HARMONIC_JOB_RECEIPT_v3',status='HARMONIC_ARRAYS_SAVED',
  channel_index=job['channel_index'],level_index=job['level_index'],level=job['level'],
  config_sha256=identity['config_sha256'],source_sha256=identity['source_sha256'],
  authorization_sha256=identity['authorization_sha256'],failure_sha256=identity['failure_sha256'],
  arrays_sha256=arrays_sha256,real_products=job['real_products'],mass_count=16)
 if any(record.get(k)!=v for k,v in expected.items()):raise ValueError('Harmonic cache identity/cost/hash differs')
 return record


def validate_backend_for_pilot(path,authorization,plan):
 path=Path(path)
 end=read(path/'execution_end.json');result=read(path/'backend_result.json');identity=read(path/'execution_identity.json')
 if (end.get('status')!='CONTROLLER_STAGE_COMPLETED' or end.get('inputs_unchanged') is not True
     or end.get('within_resource_limits') is not True or result.get('status')!='BACKEND_AND_GENERATION_PASS_ON_SPARSE_NOMINAL14_DOMAIN'
     or identity.get('stage')!='backend' or identity.get('config_sha256')!=plan['config_sha256']
     or identity.get('source_sha256')!=plan['source_sha256'] or identity.get('failure_sha256')!=plan['failure']['failure_sha256']
     or authorization.get('backend_result_sha256')!=sha(path/'backend_result.json')
     or authorization.get('backend_execution_end_sha256')!=sha(path/'execution_end.json')):
  raise ValueError('Pilot requires separately approved passed backend and final measured lifecycle')
 gate=path/'gates'
 if result['gate_report_sha256']!=sha(gate/'backend_result.json'):raise ValueError('Passed gate report changed')
 for name,key in [('data.npz','data_sha256'),('harmonic_nodes.npz','harmonic_nodes_sha256')]:
  if sha(gate/name)!=result[key]:raise ValueError('Passed backend array changed')
 r=end['resources'];cpu=r['combined_CPU_seconds']
 if r['charged_likelihood_values']!=448 or r['charged_likelihood_values_by_target']!={str(i):32 for i in range(14)}:
  raise ValueError('Expected backend per-target likelihood ledger differs')
 if (r['charged_ORF_multiplication_proxy']!=plan['cumulative_real_products']
     or r['charged_sky_config_points']!=plan['new_sky_points']):raise ValueError('Backend cumulative real/sky ledger differs')
 if isinstance(cpu,bool) or not isinstance(cpu,(int,float)) or not math.isfinite(cpu) or not plan['failure']['CPU_seconds']<=cpu<600:
  raise ValueError('No finite remaining CPU for pilot')
 return r
