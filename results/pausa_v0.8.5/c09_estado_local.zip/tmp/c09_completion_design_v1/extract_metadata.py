"""Read JSON/source metadata only. No NPZ, ORF, likelihood or random draws."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
config=read(ROOT/'tmp/c09_nominal14_v4/config.json')
review=read(ROOT/'tmp/c09_nominal14_pilot_v4/ROOT_review.json')
resources=review['resources'];rows=[];inputs=[]
for row in config['rows']:
    path=ROOT/f'tmp/c09_nominal14_pilot_v4/pilot/target_{row["id"]:02d}.json'
    d=read(path);inputs.append(path)
    rows.append(dict(target=row['id'],analysis=row['analysis'],prior=row['prior'],truth_u=row['fixed_truth_u'],scenario=row['scenario'],
        flags=d['flags'],offgrid_logL_error=d['observed_offgrid_logL_error'],
        event_radius=d['logL_PIT_radius_from_finite_checks_not_a_uniform_bound'],radius_components=d['logL_PIT_radius_components'],
        detected_roots=[len(x['roots_u']) for x in d['logL_PIT_independent']],
        logL_PIT=d['logL_PIT_operational_interval'],mass_PIT=d['mass_PIT_operational_interval'],
        charged_LL_including_backend=resources['charged_likelihood_values_by_target'][str(row['id'])],
        remaining_historical_per_target_LL=60000-resources['charged_likelihood_values_by_target'][str(row['id'])],
        source=str(path.relative_to(ROOT)),sha256=sha(path)))
for name in ['implementation_plan/commits/C09_prioris_covariancias.md','tmp/c09_execution_design/config_prospectiva.json',
    'tmp/c09_nominal14_v4/config.json','tmp/c09_nominal14_v4/PREFLIGHT.md','tmp/c09_nominal14_v4/manifest.json',
    'tmp/c09_nominal14_v4/historical_evidence.json','tmp/c09_nominal14_v4/ROOT_pilot_review.json',
    'tmp/c09_nominal14_pilot_v4/ROOT_review.json','tmp/c09_nominal14_pilot_v4/execution_end.json',
    'tmp/c09_nominal14_v2/run_nominal14.py','tmp/c09_nominal14_v2/kernels.py',
    'tmp/c09_integrator/integrator.py','tmp/c09_contour/pchip_density.py','tmp/c09_contour/contour.py',
    'tmp/c09_nominal14_v4/runtime_adapter.py','tmp/c09_nominal14_v4/channelwise_table.py']:
    inputs.append(ROOT/name)
rate=resources['new_child_CPU_seconds']/(resources['charged_likelihood_values']-448)
result=dict(schema='C09_COMPLETION_METADATA_REVIEW_v1',scope='Existing results and source review; zero numerical scientific evaluations',
    inputs={str(p.relative_to(ROOT)):sha(p) for p in inputs},rows=rows,
    historical_resources=resources,proposed_stage1_new_LL_cap=350000,proposed_stage1_new_LL_per_id_cap=25000,
    proposed_cumulative_LL_cap_at_this_stage=resources['charged_likelihood_values']+350000,
    historical_LL_per_id_cap=60000,historical_CPU_cap=600,
    measured_pilot_CPU_per_LL_including_pilot_setup=rate,
    projected_total_CPU_350k_plus_25s_setup=resources['combined_CPU_seconds']+350000*rate+25,
    CPU_projection_is_not_measurement_or_authorization=True,
    all_14_results_retained=True,existing_allpass_ids=review['all_flags_pass_ids'],
    existing_root_pass_counts=review['flag_pass_counts'],new_ORF=0,new_LL=0,new_MC=0,new_bank=0)
with (HERE/'metadata_review.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(dict(rows=len(rows),inputs=len(inputs),prior_allpass=review['all_flags_pass_ids'],projected_CPU=result['projected_total_CPU_350k_plus_25s_setup'])))
