# Continuação finita de C09: fechar o integrador antes da robustez

**Proposta, sem autorização ou execução física.** Recomendo primeiro uma continuação do mesmo nominal14, dirigida ao evento de log-likelihood; depois, comparações pareadas e validação em lote. Os 14 casos condicionais não bastam para declarar concluído o C09 inteiro. Em particular, não substituem as calibrações representativas, a variabilidade entre realizações e a análise de distâncias previstas no roadmap.

Esta preparação leu código e JSON, sem abrir arrays NPZ, montar tabelas/bancos, avaliar ORF/likelihood ou gerar números aleatórios. `metadata_review.json` vincula 30 arquivos por SHA e conserva os resultados dos 14 IDs. A configuração prospectiva mantém execução desabilitada e requer nova aprovação ROOT.

## Diagnóstico que determina o próximo passo

O relatório `tmp/c09_nominal14_pilot_v4/ROOT_review.json` registra 14/14 aprovados em normalização, CDF, brackets de quantis, momentos, KL e ausência de warnings; apenas quatro passaram a forma off-grid, e somente o ID7 passou todos os critérios. Os outros 13 intervalos de PIT de logL permanecem [0,1]. Esses estados são históricos e não serão substituídos.

O código constrói dois PCHIPs de logL a partir dos nós GL32/64 utilizados para integrar a **densidade**. Nós adequados à integral não necessariamente resolvem oscilações pequenas da **função de evento**. O erro de forma varia de 0,000407 a 0,105718; a contribuição dominante ao raio de PIT é geralmente a banda do evento, não o erro Gauss–Kronrod do numerador/denominador, que está próximo de 10⁻⁹. Por exemplo:

| ID | Erro off-grid de logL | Raio devido ao evento | Cruzamentos nas duas buscas |
|---:|---:|---:|---:|
| 0 | 0,105718 | 0,225225 | 0 / 0 |
| 1 | 0,070894 | 0,025630 | 21 / 33 |
| 6 | 0,000407 | 0,009540 | 22 / 28 |
| 10 | 0,008169 | 0,076414 | 46 / 56 |
| 11 | 0,000597 | 0,068845 | 43 / 49 |

Os IDs6/11 mostram por que apenas atingir erro de forma ≤0,001 não resolve um PIT: muita massa posterior pode estar próxima do nível de logL. O ID0 evidencia outra limitação de implementação: `len(roots)>0` reprova também um evento legitimamente vazio ou integral. Não proponho aprovar esse caso por inspeção de uma curva. Proponho cobrir todo o suporte por células classificadas e contabilizar a massa das células ainda ambíguas.

Há uma separação científica adicional: `generate_row` usa seed independente por ID. Logo, os casos de prioris e de covariância nominal14 não constituem, entre si, comparações pareadas. O fato de os IDs7/8/9 compartilharem nuisance e massa verdadeira não permite atribuir sua diferença apenas à aproximação de covariância.

## D1 — reparo do mesmo nominal14 sob os tetos existentes

### Contrato imutável

Manter os 14 dados v3/v4, nuisances conhecidas, priors originais, modelos, âncora u=0,5, pesos, espectros, tabela C07 de 8.336 nós, interpolação por canal v4 e todos os critérios. Conservar H00/H01/H11 e os 16 Γ exatos por canal já calculados. Revalidar seus SHA/identidade/formato; não repetir quadraturas ou geração. A aceitação histórica dos dois testes de céu por fluxo de controle continua explicitamente sem máximos numéricos salvos.

Reuso de Γ não é reuso gratuito de likelihood. As funções do piloto não salvaram uma nuvem completa de valores de logL nos nós. Cada reavaliação, inclusive em uma massa anteriormente visitada, deverá ser cobrada. As integrais/erros/quantis de referência que efetivamente estão nos JSON podem ser usados como controles históricos da **mesma** função, com seus SHA e alcance declarados. Não inventar valores de logL ausentes.

### Representação e malha

Usar `x=−beta_1=−sqrt((1−u)(1+u))` para a função de evento, alinhado aos segmentos da tabela. O refinamento local existente perto de beta=0 permanece; nenhum novo spline da ORF é ajustado.

1. Nível L0: nós originais da tabela (no máximo 8.336).
2. Nível L1: união com o ponto médio de cada célula em x (no máximo 16.671 nós). Essa grade é definida antes de novas avaliações, independentemente do sucesso de qualquer ID.
3. Para densidade e extremos, manter também a união dos nós GL32/64 e arestas originais: até 971 pontos adicionais. A densidade continua integrada em alpha=asin(u), incluindo o Jacobiano, ou em v=F_prior(u) na referência independente. **Não** ajustar a densidade diretamente em beta: `|du/dbeta|=beta/u` é singular em u=0.
4. Reexecutar os scouts originais coarse/fine como controles congelados e acrescentar 1.024 sondas determinísticas em beta com deslocamento fixo 0,37 de célula. Elas são validação, não treino do interpolante L1. Se qualquer sonda for usada para ajustar a representação, sua independência termina; será necessário outro conjunto previamente congelado dentro da reserva, sem reutilizar a mesma sonda como aprovação.
5. Cache somente de valores realmente calculados nesta continuação, com chave dos bytes float64 de u, ID, hash do dado/modelo/tabela e nível. Toda ausência gera reserva antes da avaliação. Preservar propostas de malha, valores e tentativas; falha não autoriza refino além do teto.

A contagem conservadora dos passos fixos é 16.671 + 971 + 1.536 + 1.024 = **20.202 valores por ID**. Até 4.798 valores adicionais por ID ficam reservados para limiares, subdivisões ambíguas, raízes e referências de numerador. Duplicatas podem reduzir custo observado, nunca justificar crédito presumido antes de verificar a chave.

### Evento sem pressupor completude de cruzamentos

O estimador alvo continua `P_post[ell(u) ≤ ell(u_true)]`. Para cada célula, produzir intervalo de valores de logL e classificar o evento como inteiro dentro, inteiro fora ou ambíguo. Subdividir apenas células ambíguas dentro de uma regra e reserva congeladas. Integrar a massa das regiões definitivamente dentro; adicionar toda a massa possível das regiões ambíguas ao extremo superior. Uma árvore finita cobre o suporte mesmo quando há muitas raízes, tangências, platôs ou nenhuma raiz.

Uma implementação útil pode derivar os intervalos dos próprios polinômios matriciais da ORF salva. Com nuisance fixa, C(x) é cúbica em cada célula; médias quadráticas são cúbicas e suas covariâncias têm grau até seis. O fatorial fixo/variável e diagonal/completo preserva essa estrutura. Os controles de Bernstein restringem o polinômio inteiro a sua envoltória convexa; não são apenas uma busca por sinais nos extremos.

Para um bloco CN, tome C* positiva no centro, `chi*=q†C*⁻¹q` e `eta ≥ sup ||C*⁻¹/²(C(x)−C*)C*⁻¹/²||₂ < 1`. Então, em aritmética exata,

`|ell(x)−ell*| ≤ −P log(1−eta) + chi* eta/(1−eta)`.

Para um bloco normal, com covariância Sigma*, `r=||Sigma*⁻¹/²(y−mu*)||`, `a ≥ sup ||Sigma*⁻¹/²(mu(x)−mu*)||` e perturbação relativa de covariância eta<1,

`|ell(x)−ell*| ≤ 0,5[−D log(1−eta) + (eta r²+2ra+a²)/(1−eta)]`.

Somar limites dos blocos independentes. Pode-se majorar a norma espectral dos controles pela Frobenius. Quando eta≥1, subdividir ou manter a célula ambígua; não reparar autovalores. Os limites matemáticos valem para a função da **tabela salva**. Sua implementação em ponto flutuante precisa de margem/validação própria; sem aritmética intervalar dirigida, não chamá-la de certificado rigoroso de arredondamento. Tampouco transferir essa envoltória para a resposta física contínua como um erro uniforme provado.

Os PCHIPs separados de densidade/evento continuam úteis como aceleradores e como comparação L0/L1, mas não devem ser a única justificativa para declarar ausentes cruzamentos físicos. A API deve distinguir `surrogate_piecewise_partition`, `saved_table_cell_envelope` e `finite_physical_response_evidence`.

O novo guard de completude não exige uma raiz interior: exige cobertura de todo o suporte e massa ambígua pequena. Isso deve ser revisto/aprovado antes da execução como substituição tecnicamente mais forte da condição de contagem, sem afrouxar tolerâncias. A saída histórica ID0 continua falha v4 mesmo se a nova envoltória vier a resolver um evento integral.

### Gates preservados e decomposição de erro

Manter |delta logZ|≤0,001; |delta CDF/PIT|≤0,002; largura de bracket de u≤0,001; deltas de momentos/KL≤0,001; erro off-grid do evento≤0,001; warning-free; finitude/PSD; limites de recursos. Nenhum ID é excluído. Para logL-PIT, a soma operacional deve incluir erro de massa/normalização, massa ambígua, discrepância L0/L1/referência e margem de backend no domínio declarado.

Alocação inicial prospectiva dentro de 0,002: até 0,001 para massa ambígua, 0,00025 para referência de massa, 0,00025 para backend operacional e 0,0005 para discrepâncias entre representações. A alocação é mais restritiva que apenas manter o total; não é um bound físico universal. O numerador Gauss–Kronrod segue separado do denominador, com a mesma fórmula de erro da razão. Manter [0,1] se a classificação/precisão não fechar ou se a referência falhar.

Validar primeiro em TOYs determinísticos, após autorização: evento integral e vazio sem raízes; raiz simples e dupla; platô; oscilações cuja integral converge antes da forma; densidade log-prior perto do corte; u=0/u=1; covariância quase singular; logL deslocada por constante; limite exatamente acima/abaixo do nível. As duas fórmulas matriciais devem ser confrontadas com avaliações independentes em matrizes pequenas e casos de rejeição. Não exigir prova global da ORF a partir de testes finitos.

### Orçamento, sem ampliação automática

| Recurso | Já consumido no histórico revisado | Proposta adicional D1 | Cumulativo previsto/teto preservado |
|---|---:|---:|---:|
| Produtos harmônicos | 214.577.271.056 | 0 | mesmo valor; teto250 G |
| Pontos de céu | 74.530.432 | 0 | mesmo valor; teto80 M |
| Likelihood | 210.588 | ≤350.000 | ≤560.588; teto global1 M |
| Likelihood por ID | 9.038–21.430 | ≤25.000 | máximo46.430; teto60.000 |
| CPU final amostrado | 296,087524 s | limite proposto270 s | ≤566,087524 s antes da margem final; teto600 s |
| RSS | máximo novo histórico790.528.000 B, soma conservadora | mesmo guard | 1.610.612.736 B |
| Arrays estimados | modelo de construção v4 | cache/intervalos estimados separadamente | 1.400.000.000 B |
| Novos arquivos | — | ≤12 MiB | dentro do teto de saída20 MiB da continuação |

A razão empírica do piloto é 0,0006601911 s CPU/valor, incluindo seu setup. Para 350 mil valores, mais 25 s adicionais de preparação, o total projetado é **552,154413 s**. É uma estimativa; o novo tratamento de células pode custar mais CPU. Usar worker fresco, BLAS1, contador central, teto cumulativo herdado e medição externa de exit. Preferir processar os 14 IDs juntos sequencialmente com uma tabela em memória; não repetir o construtor por ID. Se qualquer teto se aproximar, preservar os resultados e retornar `UNRESOLVED`, sem gastar a diferença até1 M como autorização implícita.

## D2 — robustez pareada, depois de D1 aprovado

Este estágio ainda precisa de preflight próprio, incluindo CPU e LL por curva. Não cabe chamá-lo de continuação gratuita do piloto. Uma configuração de seleção deve ser congelada antes de suas novas avaliações.

- **Priori e suporte:** aplicar `1`, `2u` e `1/[u log(b/a)]` às mesmas curvas A0 dos dados IDs2/3, além de exemplos B sobre o mesmo dado. Comparar cortes logarítmicos 10⁻⁴/10⁻³/10⁻² e suporte superior b=0,8/1. Normalizar cada prior e incluir os Jacobianos. Reutilizar avaliações armazenadas de likelihood é válido; integração/refinamento e qualquer massa ainda ausente têm custo. Verdade fora do suporte não produz PIT válido para calibração.
- **Covariância:** usar exatamente a observação Gaussiana do ID7 para o fatorial full/diagonal × fixed/variable, âncora u=0,5. Média sempre variável; log-determinante completo. Aplicar também o fatorial ao mesmo dado físico comprimido ID6, com rótulo de aproximação à distribuição quadrática. Isso mede diferenças de análise, sem confundi-las com draws distintos.
- **Espectros/contaminantes:** aproveitar IDs10/11/12/13 como casos condicionais identificados; no monopolo ID13, confrontar inclusão conhecida de rho=1 e omissão sobre o mesmo dado. Uma comparação de noise assumido não vira experimento de mudança da geração. Não há dado dipolar neste nominal14; esse item permanece futuro até geração declarada.
- **Informação:** registrar prior e posterior, quatro quantis, largura, média, variância, KL(post||prior), alteração de logZ e normalização de cada medida. Comparar posterior/prior no mesmo eixo físico. Para `u=m_g c² T/h`, um quantil próximo de `h/(c²T)` pode resultar do suporte u≤1; proximidade entre limites não prova ausência de informação. A referência de priori Q95 é0,95 para uniform_u, sqrt(0,95) para uniform_u_squared e a^0,05 para log_uniform_u com b=1.

O piloto D2 pode começar com **oito novas curvas condicionais**, teto indicativo25 mil valores por curva (≤200 mil LL) e integração de múltiplas prioris sobre os mesmos valores. Esse teto é proposta de uma nova etapa, não ampliação já aprovada dos600 s/60 mil por ID de D1. Os IDs/dados e seus múltiplos modelos devem ter contadores por componente e por dado; renomear uma curva não pode zerar custo histórico.

## D3 — integração e campanha que realmente fecham o roadmap

Não reduzir silenciosamente o desenho anterior `tmp/c09_execution_design/config_prospectiva.json`: ele contém **18 grupos matched-SBC de500**, cenários fixos e limite candidato120 M de valores/60 T de produtos, ainda não autorizados por esta proposta. O nominal14 não substitui esses grupos, e baixar o tamanho apenas para terminar rápido reduziria o poder da validação.

Antes de solicitar execução desse desenho, tornar o kernel condicional eficiente por **lote de observações com a mesma nuisance conhecida**: uma Γ/C/fatoração por massa/cenário e múltiplos RHS para os dados. A contagem científica continua `massas × observações × componentes`; o reuso de fatoração reduz CPU, não os valores de LL cobrados. Comparar esse kernel com `ConditionalKernel` congelado em dados já existentes; medir lote1/8/32 sob preflight separado. Medir também bytes de cache e custo total da grade, não só uma chamada escalar. Nenhum orçamento de campanha deve depender de extrapolação não medida.

Manter como gates de publicação C09:

1. Motor1D, formas de evento, CDFs e evidências validados nos casos representativos, com todos os casos não resolvidos preservados e efeito deles nas conclusões.
2. Comparações de prioris e do fatorial feitas sobre o mesmo dado; separar medida, suporte e geração. Não afirmar que diagonalizar é sempre conservador.
3. Calibração representativa com verdades contínuas geradas da **própria priori analisada**, controles probabilísticos correspondentes e erros numéricos nos PITs. O planejamento anterior126 testes/Holm e envelopes0,002/[0,1] não é trocado por uma aprovação visual. Testes com nuisance fixada avaliam esse experimento condicional, não prioris alternativas em cinco dimensões.
4. Variabilidade entre realizações e cenários de ruído/espectro/monopolo/dipolo com denominadores e seeds prospectivos. As matrizes exatas v4 nos16 u podem atender gerações em verdades fixas correspondentes, mas não novas verdades contínuas fora dos nós. Estas exigem Γ próprias ou outra regra gerativa explicitamente validada; não há crédito de um “cache exato” inexistente.
5. Distâncias: os fatores globais0,9/1/1,1 do desenho anterior ficam dentro da cota conservadora fL/c≤977,778 para T4,5yr/canal4. Entretanto só escala1 pode usar a tabela nominal. As outras duas requerem novo backend e orçamento de construção/validação. Para o modelo de escala latente, integrar `sum_j p_j L_j` por logsumexp, não substituir a mistura por momentos. Se ROOT preferir um mapa de momentos como primeira etapa, identificá-lo como tal e manter a inferência de distância pendente.
6. Interpretação de h/T e limites condicionais no experimento12p/4f idealizado. Nenhuma análise de TOAs irregulares, reanálise observacional MeerKAT, universalidade de limite de massa ou extensão a canais evanescentes.

Se o desenho completo exceder recursos práticos após o benchmark, uma revisão explícita do roadmap poderá escolher um subconjunto científico defendível e novo poder estatístico. Esse é um ato prospectivo de escopo que ROOT deve revisar, e não uma declaração de que o nominal14 cumpriu itens ainda não executados.

## Integração proposta

Em arquivos novos C09, manter separadas as funções puras `event_partition`, `matrix_loglike_envelope`, `prior_measure`, `conditional_batch_kernel` e o controlador com ledger. Referenciar interfaces C07/C08 como bibliotecas intactas. Propor `configs/robustness/`, `scripts/campanha_robustez.py`, `results/C09/` e `08_robustez.tex` somente quando fontes/testes/preflight estiverem revisados. O novo PDF cumulativo deve distinguir implementação validada, piloto condicional e campanhas de robustez efetivamente executadas.

Não há artigo finalizado por este desenho. A contribuição mensurável proposta é separar sensibilidade ao prior/suporte, compressão/covariância e erro do evento de densidade no limite dispersivo, com uma implementação1D que não confunde convergência da integral com resolução da forma oscilatória.
