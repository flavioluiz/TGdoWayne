"""Read-only sources; stdlib arithmetic and exact Budget AST, no physics imports."""
from pathlib import Path
import ast
import hashlib
import json
import math
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(29,30))
source=ROOT/'tmp/c09_nominal14_preflight/run_nominal14.py'
config=json.loads((source.parent/'config.json').read_text())
preflight=json.loads((source.parent/'executable_preflight.json').read_text())
P,K,N,B=12,4,len(config['sparse_exact_mass_nodes']),config['budgets']['batch_size_harmonic']
blas=contract=recurrence=transfer=recurrences=roots=0
basis=[]
for item in config['harmonic_resolutions']:
 for level in item['levels']:
  l,n=level['lmax'],level['nmu'];L=l-1
  blas+=2*N*P*n*L
  contract+=6*N*P*P*L
  recurrence+=4*n*L+6*P*P*L
  transfer+=N*P*n
  recurrences+=n*L;roots+=n*n
  mem=8*n*L+8*P*P*L+64*n+16*B*P*n+96*B*n+64*B*P*L+64*B*P*P
  basis.append(mem)
proxy=blas+contract+recurrence+16*transfer
sky=len(config['direct_sky_cases'])*sum(r['nmu']*r['nphi'] for r in config['direct_sky_resolutions'])
M=8336*K*P*P*16;C=4*8335*K*P*P*16
construct=M+4*C+32*1024**2
backend_peak=max(basis)+N*K*P*P*16*3+32*1024**2
scratch=128*config['budgets']['batch_size_likelihood']*K*10*P*P+32*1024**2
numeric=max(construct,backend_peak,M+C+scratch)
gl=sum(len(config['quadrature']['GL_mass_nodes'][r['prior']][str(n)]) for r in config['rows'] for n in [32,64])
scout_interior=14*(len(config['quadrature']['scout_u_coarse'])+len(config['quadrature']['scout_u_fine']))
counts=dict(BLAS_real_multiplications=blas,contraction_real_multiplications_proxy=contract,
 recurrence_real_multiplications_proxy=recurrence,transfer_scalar_multiplications_proxy=16*transfer,
 real_multiplications_total_proxy=proxy,transfer_points=transfer,basis_recurrence_elements=recurrences,
 roots_legendre_quadratic_work_proxy=roots,new_full4channel_ORF_nodes=N,total_harmonic_matrices=N*K*3,
 new_direct_sky_config_points=sky,direct_two_tensor_mode_products=2*sky,
 table_original_matrix_bytes=M,table_coefficient_bytes=C,
 interpolator_constructor_estimated_numeric_peak=construct,backend_estimated_numeric_peak=backend_peak,
 estimated_peak_numeric_bytes=numeric,RSS_headroom_bytes=config['budgets']['RSS_bytes']-numeric,
 minimum_initial_GL_values=gl,maximum_offgrid_scout_values=scout_interior)
assert all(preflight[k]==v for k,v in counts.items())
assert [r['id'] for r in config['rows']]==list(range(14))
assert set(r['fixed_truth_u'] for r in config['rows'])<=set(config['sparse_exact_mass_nodes'])
assert len(set(config['sparse_exact_mass_nodes']))==16
assert config['anchor_mass'] in config['sparse_exact_mass_nodes']
# Execute only the exact Budget class against a fake clock/RSS; no logL function.
tree=ast.parse(source.read_text())
node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Budget')
class Clock:
 @staticmethod
 def process_time():return 0.
env=dict(time=Clock,rss=lambda:0)
exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),env)
Budget=env['Budget']
back=Budget(config['budgets']);back.likelihood(2*N,0)
pilot=Budget(config['budgets'],previous=0.);pilot.likelihood(config['budgets']['likelihood_values_per_target'],0)
combined_target=back.by_target[0]+pilot.by_target[0]
assert combined_target==60032 and combined_target>config['budgets']['likelihood_values_per_target']
# Counterexample to *error propagation formula*, not a simulated posterior.
# A separately integrated event can have a different estimated absolute error.
Z,E_Z,P_hat,E_event=1e-6,1e-12,.5,3e-9
existing=2*E_Z/(Z-E_Z) # zero backend proxy, band and inter-method spread
needed=(E_event+abs(P_hat)*E_Z)/(Z-E_Z)
assert existing<config['gates']['delta_CDF_PIT']<needed
# New read-only probe: physically scanned equality at a grid node is omitted
# because only strictly opposite endpoint signs reach brentq. The PCHIP helper
# already handles this case. Demonstrate sign topology without running kernels.
x=[0.,.25,.5,.75,1.]
y=[-.1,0.,.1,-.1,.1]
strict=[(x[i],x[i+1]) for i in range(len(x)-1) if y[i]*y[i+1]<0]
exact=[x[i] for i in range(1,len(x)-1) if y[i]==0 and y[i-1]*y[i+1]<0]
assert strict==[(.5,.75),(.75,1.)] and exact==[.25]
files=[source,source.parent/'planning.py',source.parent/'kernels.py',source.parent/'config.json',
 source.parent/'executable_preflight.json',source.parent/'README.md',source.parent/'test_candidate.py',
 ROOT/'tmp/c09_integrator/integrator.py',ROOT/'tmp/c09_contour/pchip_density.py',ROOT/'tmp/c09_contour/contour.py',
 ROOT/'src/inference/orf_interpolation.py',ROOT/'src/inference/orf_cubic_reference.py',ROOT/'src/inference/pointwise.py',
 ROOT/'src/inference/orf_blas.py',ROOT/'src/inference/likelihood_reference.py',ROOT/'src/inference/model.py',
 ROOT/'src/inference/__init__.py',ROOT/'src/pta/statistics.py',ROOT/'src/pta/simulation.py',Path(__file__)]
hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
usage=resource.getrusage(resource.RUSAGE_SELF)
peak=usage.ru_maxrss if sys.platform=='darwin' else usage.ru_maxrss*1024
cpu=usage.ru_utime+usage.ru_stime
assert cpu<30 and peak<64*1024**2
result=dict(scope='READ_ONLY_PLUS_STDLIB_ARITHMETIC_AND_BUDGET_TOY',status='CHECKS_COMPLETED',
 counts=counts,maximum_basis_estimate_bytes=max(basis),source_preflight_count_matches=True,
 budget_counter_probe=dict(backend_reserved=back.values,pilot_reserved=pilot.values,
  same_target_combined=combined_target,declared_per_target_cap=config['budgets']['likelihood_values_per_target'],
  max_nominal14_combined=14*combined_target,declared_total_cap=config['budgets']['likelihood_component_values'],
  actual_likelihood_evaluations=0),
 event_error_propagation_probe=dict(scope='ARITHMETIC_ONLY_NOT_A_PHYSICAL_OR_TOY_POSTERIOR',
  Z_scaled=Z,denominator_error=E_Z,event_probability=P_hat,event_numerator_error=E_event,
  current_radius_zero_band_spread_backend=existing,ratio_error_estimate=needed,
  declared_gate=config['gates']['delta_CDF_PIT']),
 exact_grid_crossing_probe=dict(scope='SIGN_TOPOLOGY_ONLY',strict_sign_brackets=strict,
  omitted_isolated_equality_crossings=exact),
 resources=dict(CPU_seconds=cpu,RSS_peak_bytes=peak,CPU_cap_seconds=30,RSS_cap_bytes=64*1024**2),
 physical_ORFs=0,PTA_logL=0,physical_generations=0,existing_six_tests_repeated=0,hashes=hashes)
(HERE/'arithmetic.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':result['status'],'CPU_seconds':cpu,'RSS_peak_bytes':peak,'combined_target':combined_target,'proxy':proxy,'numeric_peak':numeric},indent=2))
