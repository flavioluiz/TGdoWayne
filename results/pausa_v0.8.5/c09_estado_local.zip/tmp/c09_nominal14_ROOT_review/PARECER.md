# C09 nominal14 — revisão independente do candidato

**Corrigir a propagação do erro do numerador do PIT e os contadores acumulados antes de congelar a execução.** A leitura não encontrou um novo erro na covariância dos kernels, normalização CN/normal ou mudança de medida das três prioris. As contagens e estimativas aritméticas do preflight foram reproduzidas. Este parecer não autoriza execução nem aprova resultados científicos ainda inexistentes.

Foram lidos `run_nominal14.py`, `planning.py`, `kernels.py`, `config.json`, os helpers de integração/PCHIP/contorno e as bibliotecas relevantes. Nenhuma fonte do candidato foi alterada. O programa de verificação usa biblioteca padrão, aritmética e a classe `Budget` extraída por AST contra relógio/RSS fictícios: **0,170557 s CPU, 25.018.368 bytes de RSS**, dentro de 30 s/64 MiB. Zero ORFs, logL PTA, geração física e repetição dos seis testes existentes. `arithmetic.json` guarda fórmulas, probes, contagens e hashes.

## Correções concretas

1. **Erro do numerador do evento não entra no gate de PIT de logL.** Em `run_nominal14.py:224`, `event_error` soma os erros GK das integrais selecionadas e é registrado em `GK_numerator_error_scaled` na linha225. O raio da linha235 e o gate da linha246 não o usam. O erro da partição empregada para Z não limita automaticamente o erro de integrais feitas novamente em outros intervalos. `info.success` e ausência de warnings não tornam esse erro zero.

   Para cada contorno, com valores estimados N/Z, erro de numerador E_N e erro de denominador E_Z, acrescentar um raio operacional de razão

   `r_GK = (E_N + abs(N/Z) * E_Z) / (Z - E_Z)`, com `Z > E_Z`.

   Propagar esse termo conservadoramente ao gate/intervalo de PIT, mantendo separadas as contribuições de backend, faixa do evento, diferenças entre métodos e erros de quadratura. O intervalo atual `[min(all_pit)-event_radius, max(all_pit)+event_radius]` já usa um raio que inclui o spread; isso é conservador, mas não substitui E_N. O raio proposto continua baseado em estimativas GK, não é certificado uniforme.

   Prova aritmética isolada: Z=1e−6, E_Z=1e−12, N/Z=.5 e E_N=3e−9. Com os demais termos nulos, o raio atual é aproximadamente2,000002e−6 e passa .002; o raio de razão é aproximadamente .003000503 e excede .002. Não se afirma que esse caso tenha ocorrido numa posterior física; ele demonstra a lacuna na propagação do erro reportado.

2. **O teto de 60 mil avaliações por alvo reinicia no piloto.** `Budget.__init__` (`run_nominal14.py:38`) zera `values` e `by_target`. O backend reserva 16×2=32 por ID; `main` leva ao piloto apenas CPU anterior, e cria um `Budget` novo na linha300. O probe da classe exata aceitou32 no backend e60000 no piloto para o mesmo ID: **60032 acumuladas**. Herde contagens totais e por alvo do backend, normalizando as chaves JSON, e reporte estágio versus acumulado separadamente. O máximo nominal14 daí é840448, ainda abaixo do teto global1M; a violação concreta é do teto por alvo e da rastreabilidade acumulada. Nenhuma likelihood foi avaliada neste probe.

## Guards adicionais observados

3. **Travessia exatamente num nó da sondagem é omitida pelo scanner físico.** `run_nominal14.py:219–220` refina somente `fa*fb<0`. Uma igualdade isolada com sinais opostos nos vizinhos deve ser incluída como raiz observada; platôs devem continuar separados. O helper `LogLikelihoodContour` já faz essa distinção. Probe de sinais nos nós `[0,.25,.5,.75,1]`: `[-.1,0,.1,-.1,.1]`. O scanner mantém os dois brackets finais, mas omite a travessia em .25. Isso não prova falso PASS no desenho nominal — comparações independentes podem detectar a diferença —, porém a enumeração atual pode perder uma travessia efetivamente observada. Recomendo incluir essas igualdades isoladas ou declarar o caso não resolvido.

4. **Hash da tabela tem uma janela entre verificação e uso.** O arquivo é verificado em `main:274–275`; `experiment_and_table:67–68` pode carregá-lo mais tarde, após o backend, sem reconferir seu hash. O fechamento final da linha316 cobre `source_hashes`, que não inclui o NPZ. Verificar o hash imediatamente antes/depois da carga e no encerramento, ou garantir uma cópia imutável vinculada, evita que a identidade anunciada corresponda a bytes diferentes dos utilizados. Não foi observada alteração da tabela: trata-se de lacuna de guard, não de resultado físico comprometido.

As duas questões previamente encontradas pelo ROOT também foram confirmadas: `src/inference/__init__.py` não está em `DEPENDENCIES` (`planning.py:12–19`), embora seja importado; e o contador CPU começa após imports/preflight/identidade, enquanto o piloto herda `backend_result.resources` em vez do registro final. Mesmo `execution_end.resources` atual é calculado antes da conferência final de fontes e da serialização. O congelamento deve usar tempo desde início do processo e um fechamento final explícito, com saldo entre estágios. RLIMIT atual ainda usa arredondamento para cima e hard=soft+2: deve ser descrito como guarda operacional, sem promessa de término subsegundo no teto exato.

## Coerência científica do recorte lido

A parametrização nominal usa β_k(u)=sqrt[(1−u/k)(1+u/k)] com a fase de cada canal; não confunde B com C_beta. O monopolo é PSD de posto1 com espectro13/3 e a amplitude relativa no pivô fixado; momentos são calculados sobre C total, incluindo termos cruzados. Os kernels B mantêm média variável, diagonalizam no espaço comprimido e usam a covariância ancorada em u=.5 quando fixa; todos preservam logdet e normalização. Geração G é controle normal completo variável, de modo que diagonalização/fixação são misspecificações deliberadas.

A transformação α=asin(u) preserva o Jacobiano cosα e as três prioris normalizadas. A identidade atan2 usada para a meia largura do painel corresponde a metade de asin(b)−asin(a). PCHIP interpola densidade em α sem pesos GL; o evento interpola separadamente logL. Integração de referência em v=F_prior(u) incorpora a priori pela mudança de medida, e KL=`total[3]/Z−log(Z)` cancela corretamente o shift de logL.

O escopo finito está explicitado: máximos sparse de erro de logL não são limites uniformes; scouts não certificam toda a topologia física; comparação GK/PCHIP/GL pode falhar conjuntamente para regiões não resolvidas. Não se deve transformar o proxy .5*expm1(2d_observado) em certificado global. O texto do candidato já mantém essa distinção e não chama o nominal14 de SBC nem de inferência5D. Os resultados entre linhas são independentes, portanto não são contrastes pareados do fatorial.

## Contagens e memória reproduzidas

| Quantidade | Valor |
|---|---:|
| IDs nominais |14, exatamente0–13|
| Massas ORF completas novas |16|
| Matrizes por canal/resolução |192|
| BLAS real |142.888.689.408|
| Proxy real total |145.279.513.928|
| Pontos de transfer harmônico |16.713.984|
| Pontos de céu/configuração |74.530.432|
| Produtos dos dois modos tensoriais diretos |149.060.864|
| GL iniciais |13.056|
| Sondas interiores máximas |21.504, mais extremos|
| Maior base/buffers estimados |563.396.800 B|
| Matrizes8336 |76.824.576 B|
| Coeficientes cúbicos |307.261.440 B|
| Pico do construtor estimado |1.339.424.768 B|
| Folga aritmética até1,5 GiB RSS |271.187.968 B|

As fórmulas do preflight e os débitos do backend concordam. O custo real é explicitamente proxy: não inclui todos os custos transcendentais ou raízes como multiplicações exatas; estes têm campos separados. Não se mantém uma base harmônica grande ao construir o interpolador. A estimativa `M+4C+32MiB` é compatível com a coexistência dos arrays locais do spline/Bernstein examinados; não encontrei por leitura uma alocação determinística omitida que por si exceda esse envelope. Não foi feita medição de memória real do construtor ou do backend. RSS inclui imports, allocator e bibliotecas, e seu guard é posterior à alocação: os números não são garantia de RSS.

## Resultado da revisão

Ajustar itens1–2 e os dois pontos já detectados pelo ROOT antes do congelamento. Recomendo incorporar também os guards3–4. Preservar os limites e o status não resolvido quando um produto falhar. A revisão não reexecutou física, não alterou tolerâncias e não autoriza backend ou piloto. `review.json` vincula este parecer aos bytes lidos e diferencia achados, limites e verificações realizadas.
