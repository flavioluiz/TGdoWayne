"""Read only C09 text/JSON metadata; no scientific imports, arrays or execution.

Recompose historical Boolean gates from saved scalars, not new validation of
their estimates or a reclassification of any historical interval.
"""
import csv
import hashlib
import json
import math
from pathlib import Path
import resource
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCES = [
    'implementation_plan/commits/C09_prioris_covariancias.md',
    'docs/contrato_comparacoes.md',
    'tmp/c09_execution_design/PROTOCOLO.md',
    'tmp/c09_execution_design/DECISAO_ESCOPO.md',
    'tmp/c09_execution_design/config_prospectiva.json',
    'tmp/c09_completion_design_v1/PROTOCOLO.md',
    'tmp/c09_completion_design_v1/config_prospectiva.json',
    'tmp/c09_nominal14_v2/run_nominal14.py',
    'tmp/c09_nominal14_v4/config.json',
    'tmp/c09_nominal14_v4/runtime_adapter.py',
    'tmp/c09_nominal14_v4/worker.py',
    'tmp/c09_nominal14_pilot_v4/ROOT_review.json',
    'tmp/c09_ROOT/pure_component_review.json',
    'tmp/c09_ROOT/historical_nominal14.csv',
    'tmp/c09_ROOT/historical_nominal14_receipt.json',
    'tmp/c09_ROOT/summarize_historical_pilot.py',
    'tmp/c09_event_repair_v1/manifest.json',
    'tmp/c09_event_repair_v1/README.md',
    'tmp/c09_event_repair_independent_review_v1/review.json',
]
SOURCES += [f'tmp/c09_event_repair_v1/d1/{s}.py' for s in
            ('measure','grid','polynomial','envelope','partition','cache','cells','referenced_event')]
SOURCES += [f'tmp/c09_nominal14_pilot_v4/pilot/target_{i:02d}.json' for i in range(14)]


def read(path):
    return json.loads((ROOT/path).read_text(), parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))


def sha(path):
    assert Path(path).suffix in ('.py','.json','.csv','.md')
    return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()


def write(name, value):
    with (OUT/name).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')


def main():
    receipt = read('tmp/c09_ROOT/historical_nominal14_receipt.json')
    for s in receipt['sources']:
        assert sha(s['path']) == s['sha256']
    assert sha('tmp/c09_ROOT/historical_nominal14.csv') == receipt['csv_sha256']
    assert sha('tmp/c09_ROOT/summarize_historical_pilot.py') == receipt['script_sha256']
    config = read('tmp/c09_nominal14_v4/config.json')
    gates = config['gates']
    rows = [read(f'tmp/c09_nominal14_pilot_v4/pilot/target_{i:02d}.json') for i in range(14)]
    csv_rows = list(csv.DictReader((ROOT/'tmp/c09_ROOT/historical_nominal14.csv').open()))
    assert len(csv_rows) == len(rows) == 14
    compact = []
    for d, c in zip(rows,csv_rows):
        assert d['target'] == int(c['target'])
        for kind in ('mass','logL'):
            assert d[f'{kind}_PIT_operational_interval'] == [float(c[f'historical_{kind}_PIT_{edge}']) for edge in ('low','high')]
        referr = d['reference_relative_error_estimate']
        assert 0 <= referr < 1
        radius = 2*referr/(1-referr) + d['backend_density_TV_proxy_not_uniform_bound']
        cdf_spread = max(max(abs(r['PCHIP_coarse']-r['PCHIP_fine']),abs(r['PCHIP_fine']-r['reference'])) for r in d['CDFs'])
        norm_spread = max(abs(z-d['reference_logZ']) for z in d['PCHIP_logZ']+[s['logz'] for s in d['GL_summaries']])
        q_ok = all(q['width'] <= gates['quantile_bracket_u'] and q['reference_low']+radius <= q['probability'] <= q['reference_high']-radius for q in d['quantile_brackets'])
        derived = {
            'normalization': norm_spread <= gates['delta_logZ'],
            'CDF': cdf_spread+radius <= gates['delta_CDF_PIT'],
            'quantiles': q_ok,
            'moments': all(abs(d['GL_summaries'][-1][k]-d['reference_moments'][k]) <= gates['delta_moments'] for k in ('mean_u','second_moment_u')),
            'KL': abs(d['GL_summaries'][-1]['kl_posterior_to_prior']-d['reference_moments']['kl_posterior_to_prior']) <= gates['delta_KL'],
            'offgrid_form': d['observed_offgrid_logL_error'] <= gates['density_event_sparse_abs_logL'],
            'reference_warning_free': not d['reference_warnings'],
        }
        assert all(d['flags'][k] == v for k,v in derived.items())
        assert all(math.isfinite(v) for r in d['CDFs'] for v in r.values())
        assert all(math.isfinite(v) for q in d['quantile_brackets'] for v in q.values())
        compact.append({
            'target':d['target'], 'analysis':d['analysis'], 'prior':d['prior'],
            'historical_status':d['status'], 'historical_flags':d['flags'],
            'historical_mass_interval':d['mass_PIT_operational_interval'],
            'historical_logL_interval':d['logL_PIT_operational_interval'],
            'cdf_rows':len(d['CDFs']), 'quantile_brackets':len(d['quantile_brackets']),
            'cdf_finite_spread':cdf_spread, 'historical_cdf_proxy_radius':radius,
            'historical_cdf_score':cdf_spread+radius, 'logZ_finite_spread':norm_spread,
            'max_quantile_width':max(q['width'] for q in d['quantile_brackets']),
            'scalar_gate_recomposition_matches':True,
        })
    root_review = read('tmp/c09_nominal14_pilot_v4/ROOT_review.json')
    counts = {k:sum(d['flags'][k] for d in rows) for k in rows[0]['flags']}
    assert counts == root_review['flag_pass_counts']
    mass_unresolved = [d['target'] for d in rows if d['mass_PIT_operational_interval'] == [0.,1.]]
    structural = [d['target'] for d in rows if d['mass_PIT_structural_exact']]
    mass_narrow = [d['target'] for d in rows if d['target'] not in mass_unresolved+structural]
    log_unresolved = [d['target'] for d in rows if d['logL_PIT_operational_interval'] == [0.,1.]]
    assert mass_unresolved == [1,2,3,4,5,9,10,12,13]
    assert structural == [0] and mass_narrow == [6,7,8,11] and len(log_unresolved) == 13
    bindings = [{'path':p,'sha256':sha(p),'bytes':(ROOT/p).stat().st_size} for p in SOURCES]
    write('sources.json', {'schema':'C09_SCOPE_REVIEW_TEXT_SOURCES_v1','files':bindings,
                          'files_count':len(bindings),'bytes':sum(s['bytes'] for s in bindings),
                          'only_text_metadata_read':True,'real_arrays_read':False})
    write('metadata_review.json', {
        'status':'HISTORICAL_SCALAR_GATES_RECOMPOSED_NO_RECLASSIFICATION',
        'transcription_receipt_bindings_verified':True,'historical_rows':14,
        'flag_pass_counts':counts,'mass_unresolved_ids':mass_unresolved,
        'mass_structural_zero_ids':structural,'mass_narrow_ids':mass_narrow,
        'logL_unresolved_ids':log_unresolved,
        'total_saved_cdf_rows':sum(x['cdf_rows'] for x in compact),
        'total_saved_quantile_brackets':sum(x['quantile_brackets'] for x in compact),
        'max_saved_cdf_score':max(x['historical_cdf_score'] for x in compact),
        'max_saved_logZ_spread':max(x['logZ_finite_spread'] for x in compact),
        'max_saved_quantile_width':max(x['max_quantile_width'] for x in compact),
        'scientific_revalidation':False,'historical_reclassification':False,
        'SBC_campaign_or_claim':False,'uniform_physical_certificate':False,
        'proposed_counts':{'matched_groups':18,'realizations_per_group':500,'group_realization_pairs':9000,
                           'planned_tests_per_group':7,'planned_family_size':126,
                           'mass_and_coverage_tests':108,'logL_tests_pending_if_unresolved':18},
        'rows':compact,'physical_LL':0,'ORF':0,'draws':0,'real_array_reads':0,
        'resources':{'process_CPU_seconds_sampled':time.process_time(),
                     'process_maxRSS_native':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                     'scope':'This metadata script only; Darwin RSS bytes, not total review cost.'},
    })
    print(json.dumps({'rows':14,'cdf_rows':sum(x['cdf_rows'] for x in compact),
                      'quantile_brackets':sum(x['quantile_brackets'] for x in compact),
                      'sources':len(bindings),'physical_LL':0}))


if __name__ == '__main__':
    main()
