# Síntese SBC C09 por intervalos

Componente puro: recebe os18grupos registrados, cada um com500IDs e intervalos dePIT para massa e logL. Não importa dados PTA nem avalia likelihood, ORF ou draws. O consumidor deve validar a geração matched, identidade dos dados e evidência numérica antes de fornecer entradas.

A família fixa contém126testes:9grupos core,3covariâncias self,4ruídos e2misturas de distância;7testes por grupo. Mantém os18slots de logL mesmo quando todos os seus intervalos são[0,1]. Nesse caso o estado é UNRESOLVED, sem aprovação de calibração. Erros operacionais não viram certificados rigorosos. Holm permite dependência entre os grupos pareados.

Usa os helpers existentes src/inference/sbc_sensitivity.py e diagnostics.py pelos hashes devalidation.json. O alcance dos limites KS e contagens de cobertura é condicional à validade dos intervalos fornecidos. Nem não rejeição nem o campo resolved certificam o integrador, aprendizagem ou calibração global.

Três TOYs focados passaram: família íntegra com logL pendente; rejeição de grupos/IDs removidos ou duplicados e de intervalo estreito falsamente não resolvido; rejeição estatística robusta no exemplo enviesado mantendo uma realização não resolvida no denominador500.0,83197sCPU desdeimports,104.316.928B RSS. A suíte antiga não foi repetida.

Interfaces: synthesize(groups,registry), validate_registry(registry), validate_group(group,name). A lista registry fixa group_id/stratum/prior_id/generative_model/analysis_model/generation_binding e truth_design=continuous_prior_predictive, fixed_nuisance_known=True. Cada group contém IDs ordenados0..499, pit_intervals(500,2,2), resolved(500,2), interval_evidence_binding e definição do CDF de logL: continuous_statistic, randomized_atom_CDF ou not_evaluated. Esses rótulos não substituem revisão do produtor físico.
