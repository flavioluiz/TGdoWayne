"""C09 family of126 matched SBC tests from supplied operational PIT intervals.

No PTA data, random draw or likelihood is read/evaluated. A physical caller must
validate generation, group membership and numeric interval evidence separately.
These statistical conclusions are conditional on those intervals; an interval
must not be manufactured by substituting a tolerance for a measured error.
"""
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
from inference.sbc_sensitivity import ks_bounds,coverage_bounds,holm_sensitivity

N=500
FAMILY=126
PROBABILITIES=(.05,.5,.9,.95)
EXPECTED_STRATA={'core':9,'covariance_self':3,'noise':4,'distance_mixture':2}

def validate_registry(registry):
    if not isinstance(registry,list) or len(registry)!=18:
        raise ValueError('The complete18-group prospective registry is required')
    names=[];counts={s:0 for s in EXPECTED_STRATA}
    for item in registry:
        if not isinstance(item,dict) or item.get('stratum') not in counts:
            raise ValueError('Explicit valid matched stratum required')
        for key in ('group_id','prior_id','generative_model','analysis_model','generation_binding'):
            if not isinstance(item.get(key),str) or not item[key]:
                raise ValueError('Explicit nonempty group identity required: '+key)
        if item.get('truth_design')!='continuous_prior_predictive' or item.get('fixed_nuisance_known') is not True:
            raise ValueError('C09 matched registry is conditional on known nuisances and continuous-prior generation')
        names.append(item['group_id']);counts[item['stratum']]+=1
    if len(set(names))!=18 or counts!=EXPECTED_STRATA:
        raise ValueError('Repeated group or changed9/3/4/2 family allocation')
    return names

def validate_group(group,name):
    if not isinstance(group,dict) or group.get('group_id')!=name:
        raise ValueError('Supplied group must match the explicit registry')
    ids=np.asarray(group['datum_ids'])
    if ids.dtype.kind not in 'iu' or ids.shape!=(N,) or not np.array_equal(ids,np.arange(N)):
        raise ValueError('Exactly the500 registered IDs in order are required, without an intersection or filtering')
    intervals=np.asarray(group['pit_intervals'])
    resolved=np.asarray(group['resolved'])
    if intervals.dtype.kind!='f' or intervals.shape!=(N,2,2) or not np.isfinite(intervals).all():
        raise ValueError('Finite float intervals shape(500,mass/logL,lower/upper) required')
    if np.any(intervals[:,:,0]<0) or np.any(intervals[:,:,1]>1) or np.any(intervals[:,:,0]>intervals[:,:,1]):
        raise ValueError('PIT endpoints must be ordered in[0,1], without repair')
    if resolved.dtype.kind!='b' or resolved.shape!=(N,2):
        raise ValueError('Per-ID/function Boolean resolution mask required')
    if not np.array_equal(intervals[~resolved],np.broadcast_to([0.,1.],intervals[~resolved].shape)):
        raise ValueError('Every unresolved integral must remain[0,1]')
    kind=group.get('logL_null_definition')
    if kind not in ('continuous_statistic','randomized_atom_CDF','not_evaluated'):
        raise ValueError('Explicit continuous/randomized logL CDF definition, or not_evaluated, required')
    if kind=='not_evaluated' and np.any(resolved[:,1]):
        raise ValueError('An unevaluated logL event cannot be declared resolved')
    if not isinstance(group.get('interval_evidence_binding'),str) or not group['interval_evidence_binding']:
        raise ValueError('Numerical interval evidence provenance required')
    return intervals,resolved

def synthesize(groups,registry):
    names=validate_registry(registry)
    if not isinstance(groups,list) or len(groups)!=18:
        raise ValueError('All18 groups required; missing integrals belong to their original group')
    rows=[];summaries=[]
    for group,item,name in zip(groups,registry,names):
        intervals,resolved=validate_group(group,name)
        base={'group_id':name,'stratum':item['stratum'],'n':N,'family_size':FAMILY}
        for j,quantity in enumerate(('mass','logL')):
            bounds=ks_bounds(intervals[:,j,0],intervals[:,j,1])
            rows.append(dict(base,test='KS_'+quantity,quantity=quantity,
                             numerically_resolved_ids=int(resolved[:,j].sum()),
                             evaluation_status='NO_RESOLVED_INPUTS' if not resolved[:,j].any() else 'CONDITIONAL_ON_INPUT_INTERVALS',
                             sensitivity=bounds))
        for probability in PROBABILITIES:
            bounds,_,_=coverage_bounds(intervals[:,0,0],intervals[:,0,1],
                                       upper_probability=probability,alpha=.05,family_size=FAMILY)
            rows.append(dict(base,test=f'coverage_below_q{probability:.2f}',quantity='mass',
                             numerically_resolved_ids=int(resolved[:,0].sum()),
                             evaluation_status='NO_RESOLVED_INPUTS' if not resolved[:,0].any() else 'CONDITIONAL_ON_INPUT_INTERVALS',
                             sensitivity=bounds))
        bounds,_,_=coverage_bounds(intervals[:,0,0],intervals[:,0,1],
                                   lower_probability=.05,upper_probability=.95,alpha=.05,family_size=FAMILY)
        rows.append(dict(base,test='coverage_central90',quantity='mass',
                         numerically_resolved_ids=int(resolved[:,0].sum()),
                         evaluation_status='NO_RESOLVED_INPUTS' if not resolved[:,0].any() else 'CONDITIONAL_ON_INPUT_INTERVALS',
                         sensitivity=bounds))
        summaries.append(dict(group_id=name,resolved_mass=int(resolved[:,0].sum()),
                              resolved_logL=int(resolved[:,1].sum()),all500_retained=True,
                              interval_evidence_binding=group['interval_evidence_binding'],
                              logL_null_definition=group['logL_null_definition']))
    if len(rows)!=FAMILY:raise ArithmeticError('Registered family size changed')
    adjusted=holm_sensitivity([r['sensitivity']['pvalue_lower'] for r in rows],
                              [r['sensitivity']['pvalue_upper'] for r in rows],alpha=.05)
    for j,row in enumerate(rows):
        lo=float(adjusted['holm_lower'][j]);hi=float(adjusted['holm_upper'][j])
        if row['evaluation_status']=='NO_RESOLVED_INPUTS':decision='UNRESOLVED'
        elif hi<=.05:decision='REJECTION_FOR_ALL_ADMISSIBLE_INPUTS'
        elif lo>.05:decision='NONREJECTION_FOR_ALL_ADMISSIBLE_INPUTS'
        else:decision='NUMERICALLY_INDETERMINATE'
        row.update(holm_pvalue_interval=[lo,hi],decision=decision,
                   is_integrator_approval=False,is_posterior_learning_claim=False)
    return dict(schema='C09_MATCHED_INTERVAL_SBC_v1',scope='conditional_known_nuisance_prior_predictive',
                family_size=FAMILY,groups=18,independent_IDs_per_group=N,tests=rows,group_summary=summaries,
                all_registered_IDs_retained=True,approximate_models_not_in_this_family=True,
                multiple_test_dependence_allowed_by_Holm=True,
                supplied_intervals_have_operational_not_rigorous_error_status=True,
                registry_and_numerical_provenance_must_be_validated_by_caller=True,
                nonrejection_does_not_prove_learning_or_global_calibration=True,
                physical_work_performed=0)
