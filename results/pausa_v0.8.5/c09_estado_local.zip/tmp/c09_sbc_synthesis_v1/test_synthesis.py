"""Focused synthetic tests of the new18×500 layout; existing tests not rerun."""
import copy
import unittest
import numpy as np
from synthesis import synthesize,validate_registry,validate_group,EXPECTED_STRATA

def fixture():
    registry=[];groups=[]
    for stratum,n in EXPECTED_STRATA.items():
        for j in range(n):
            name=f'TOY_{stratum}_{j}'
            registry.append(dict(group_id=name,stratum=stratum,prior_id='TOY_U01',
                                 generative_model='TOY',analysis_model='TOY',generation_binding='SYNTHETIC_ONLY',
                                 truth_design='continuous_prior_predictive',fixed_nuisance_known=True))
            p=(np.arange(500)+.5)/500
            intervals=np.repeat(p[:,None,None],2,axis=1).repeat(2,axis=2)
            intervals[:,1]=[0.,1.]
            resolved=np.ones((500,2),bool);resolved[:,1]=False
            groups.append(dict(group_id=name,datum_ids=np.arange(500),pit_intervals=intervals,
                               resolved=resolved,logL_null_definition='not_evaluated',interval_evidence_binding='ANALYTICAL_TOY'))
    return groups,registry

class Tests(unittest.TestCase):
    def test_complete_family_preserves_unresolved_logl_slots(self):
        groups,registry=fixture();r=synthesize(groups,registry)
        self.assertEqual(len(r['tests']),126)
        pending=[x for x in r['tests'] if x['quantity']=='logL']
        self.assertEqual(len(pending),18)
        self.assertTrue(all(x['decision']=='UNRESOLVED' and x['holm_pvalue_interval']==[0.,1.] for x in pending))
        self.assertEqual(sum(x['n'] for x in r['tests']),126*500)
        self.assertTrue(all(x['is_integrator_approval'] is False for x in r['tests']))
    def test_no_filtered_groups_ids_or_narrow_unresolved(self):
        groups,registry=fixture()
        with self.assertRaises(ValueError):synthesize(groups[:-1],registry)
        bad=copy.deepcopy(registry);bad[0]['stratum']='noise'
        with self.assertRaises(ValueError):validate_registry(bad)
        bad=copy.deepcopy(groups[0]);bad['datum_ids']=np.arange(499)
        with self.assertRaises(ValueError):validate_group(bad,bad['group_id'])
        bad=copy.deepcopy(groups[0]);bad['datum_ids'][1]=0
        with self.assertRaises(ValueError):validate_group(bad,bad['group_id'])
        bad=copy.deepcopy(groups[0]);bad['pit_intervals'][0,1]=[.2,.3]
        with self.assertRaises(ValueError):validate_group(bad,bad['group_id'])
    def test_false_uniformity_rejected_without_removing_missing(self):
        groups,registry=fixture()
        groups[0]['pit_intervals'][:,0]=[.01,.01]
        groups[0]['pit_intervals'][0,0]=[0.,1.];groups[0]['resolved'][0,0]=False
        r=synthesize(groups,registry)
        row=r['tests'][0]
        self.assertEqual(row['n'],500)
        self.assertEqual(row['numerically_resolved_ids'],499)
        self.assertEqual(row['decision'],'REJECTION_FOR_ALL_ADMISSIBLE_INPUTS')

if __name__=='__main__':unittest.main(verbosity=2)
