# C10 — desenho para revisão, sem execução

O núcleo do artigo permanece tensorial. Este complemento testa uma população escalar fenomenológica de helicidade zero FP, com relação transversal/longitudinal vinculada, sem impor equipartição ou eficiência de excitação por fontes. A resposta derivada em `tmp/c10_scalar` é ponto de partida; a relação com Liang–Trodden e Bernardo–Ng deve permanecer explícita.

## Experimento de recuperação delimitado

Proposta ainda sujeita à revisão: usar a geometria/escala moderada do experimento C06 (10 pulsares,3 frequências,T15anos,L100–300anos-luz), que já tem controles de geração e momentos. Fixar inicialmente os parâmetros de espectro/ruído em seus valores geradores; inferir conjuntamente massa u e fração escalar de potência epsilon. Isso é um complemento condicional, não substitui a inferência5D tensorial com ruído livre. Declarar o que se perde por condicionar parâmetros.

A covariância de sinal deve ser definida e normalizada antes dos sorteios, por exemplo P_T[Gamma_TT(u)+epsilon Gamma_FP0(u)], epsilon em [0,1]; Gamma_FP0 usa sua normalização polarizacional própria, sem renormalizar artificialmente diagonais de ORF em cada massa. Epsilon é razão de potências definida por essa convenção, não uma fração de eventos de fontes. Ruído segue a mesma convenção de C06. A amplitude zero escalar recupera exatamente o contrato tensorial.

PreservarA0_CN/A_CN/B_CN e controles normais A_G/B_G; comparar C_beta/C_full nos mesmos dados selecionados. Uma posterior2D por integração adaptativa/grid refinado pode fornecer normalização e CDFs, com integrais limitadas nos cortes, sem fingir que evidência convergida certifica quantis. Antes de determinar malha/custo, calcular quão rapidamente ORFs e likelihoods variam no pequeno domínio C06.

## Recuperação e falso positivo

Definir hipótese pontual epsilon=0 e alternativa epsilon~Uniforme(0,1), com a mesma priori própria de u e mesmas nuisances condicionadas, no MESMO espaço de dados. Nenhum BF entre espaçosA0/A/B. Definir critério prospectivo, por exemplo BF_10>10, e medir a taxa de falso positivo em≥500 injeções tensoriais; não interpretá-lo como um nível frequentista universal. Recuperação em injeções mistas deve abranger epsilon pequeno e moderado e massas centrais/próximas do limiar, com cobertura condicional e incertezas binomiais explícitas. Uma priori contínua positiva não torna Q_05(epsilon)>0 evidência de detecção.

A calibração adicional com verdades da priori2D e pelo menos500dados pode ser barata após validar a integração, mas não está autorizada como concluída por este desenho. Planejar custos antes de executar. A0 correto e A_G/B_G corretos são controles; falha do normal aplicado às estatísticas físicas não deve ser atribuída à compressão.

## Degenerescências e alcance

Complementar a posterior(u,epsilon) com matriz de informação/escores locais para u,epsilon,amplitude tensorial,inclinação espectral e ruído. Isso quantifica degenerescências locais com parâmetros que foram condicionados na recuperação, sem se tornar uma posterior com esses parâmetros livres. Usar diferenças finitas refinadas, duas escalas e identidades de score/PSD. Se a degenerescência mostrar que o condicionamento muda materialmente a interpretação, reportar essa limitação e dimensionar um pequeno controle com nuisance livre antes de conclusões físicas.

No limite u→0, o modo escalar FP pode persistir; o modelo completo não é obrigado a tornar-se RG. Separar amplitude escalar zero, massa zero e resposta do observador. Não apresentar normalizações alternativas de outros modelos como a mesma teoria.

## Gate para execução

Este texto é rascunho de desenho: não fixa contagens definitivas, malha, sementes ou orçamento. Um protocolo executável revisado deve preceder dados/inferência C10. Incluir limites de erros ORF/logL/CDF e de memória/tempo, armazenamento reprodutível, referência independente e explícita distinção dos estudos de nuisance livre e condicional. Não concluir C10 apenas com a derivação da resposta; as injeções e o teste de falsos positivos permanecem necessários.
