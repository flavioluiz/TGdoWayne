"""Arithmetic-only C10 design audit: no data, ORF, likelihood or posterior draws."""
from pathlib import Path
import argparse
import hashlib
import json
import math


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    c = json.loads(args.config.read_text())
    if c['execution_enabled'] is not False:
        raise ValueError('This audit is only the disabled candidate design.')
    if c['populations']['null']['n'] < 500 or c['populations']['prior2D']['n'] < 500:
        raise ValueError('The two required500 populations cannot be reduced silently.')
    seeds = [c['pilot']['seed'], c['populations']['null']['seed_truth'],
        c['populations']['null']['seed_data'], c['populations']['prior2D']['seed_truth'],
        c['populations']['prior2D']['seed_data'], c['populations']['recovery']['seed_data'], c['toy']['seed']]
    if len(seeds) != len(set(seeds)):
        raise ValueError('Independent seed namespaces required.')
    for key, n in [('null_ids', 500), ('prior2D_ids', 500), ('recovery_ids', 192)]:
        ids = c['C_subset'][key]
        if len(ids) != 32 or len(set(ids)) != 32 or any(type(i) is not int or not 0 <= i < n for i in ids):
            raise ValueError('Exactly32 distinct preselected IDs in each C ensemble required.')
    ndata = sum(p['n'] for p in c['populations'].values())
    core = ndata*len(c['models'])
    extra = sum(len(c['C_subset'][k]) for k in ['null_ids', 'prior2D_ids', 'recovery_ids'])*len(c['C_models'])
    low = math.prod(c['mesh']['coarse'])
    high = math.prod(c['mesh']['fine'])
    main_cost = (core+extra)*(low+high)
    null_edge_cost = (core+extra)*(c['mesh']['coarse'][0]+c['mesh']['fine'][0])
    pilot_base = len(c['pilot']['data'])*len(c['pilot']['methods'])*(low+high)
    pilot_high = len(c['pilot']['independent_reference_ids'])*len(c['pilot']['methods'])*math.prod(c['pilot']['higher_reference_grid'])
    independent_reference = len(c['pilot']['independent_reference_ids'])*len(c['pilot']['methods'])*math.prod(
        c['pilot']['independent_product_quadrature_reference'])
    sky_grids = math.prod(c['gates']['direct_coarse'])+math.prod(c['gates']['direct_fine'])
    # Three physical + two extra C_beta phase configurations per mass; C_full
    # and C_beta's first channel coincide with physical first-channel responses.
    sky = len(c['gates']['orf_mass_probes'])*5*sky_grids
    A = 10**c['nuisance']['log10_AT']
    umin = c['prior']['u'][0]
    T = c['geometry']['T_years']
    channels = c['geometry']['K']
    variance = 2*A*A*c['prior']['epsilon_ratio'][1]/(3*umin**4)*sum(
        n**3*(n/T)**(3-c['nuisance']['gamma']) for n in channels)
    rms = math.sqrt(variance)
    if (main_cost+null_edge_cost > c['resources']['maximum_production_likelihood_equivalents'] or
            pilot_base+pilot_high+independent_reference > c['resources']['maximum_pilot_likelihood_equivalents'] or
            sky > c['resources']['maximum_ORF_sky_equivalents'] or rms > c['gates']['metric_component_rms_max']):
        raise ValueError('An arithmetic/RMS candidate budget fails; no experiment may proceed.')
    record = dict(status='ARITHMETIC_DESIGN_CHECK_PASS_NOT_KERNEL_OR_INFERENCE_APPROVAL',
        actual_likelihood_evaluations=0, actual_ORF_evaluations=0, actual_draws=0,
        data_count=ndata, core_posterior_targets=core, C_posterior_targets=extra,
        coarse_nodes=low, fine_nodes=high, joint_logL_equivalents=main_cost,
        conservative_null_edge_extra=null_edge_cost, main_upper_count=main_cost+null_edge_cost,
        pilot_count=pilot_base+pilot_high+independent_reference,
        direct_sky_configuration_points=sky,
        sky_unit='One common angular point for both TT modes plus FP0; not a floating-point operation count.',
        metric_max_inverse_chi=max(channels)**2/umin**2,
        metric_component_coefficient_max=2/math.sqrt(3)*max(channels)**2/umin**2,
        scalar_metric_component_rms_upper_bound=rms,
        C_recovery_counts_by_cell=[sum(i//32 == cell for i in c['C_subset']['recovery_ids']) for cell in range(6)],
        source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), args.config]},
        wallclock_feasibility='Unmeasured; requires independent kernel/quadrature pilot before production.')
    args.output.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
