# C10: protocolo delimitado para revisão antes de executar

11/09/2026. **Estado: desenho candidato, execução desabilitada.** A derivação
e os protótipos prévios continuam em `tmp/c10_scalar`; não existem resultados
de recuperação, falsos positivos, identificabilidade ou SBC escalar. O marco
depende de C09 e de seus gates próprios. Este documento não o aprova por antecipação.

## Parecer e correções necessárias

A rota condicional em dois parâmetros é viável como **projeto de implementação**:
uma mesma covariância em cada nó da malha pode ser reutilizada nos muitos dados.
A viabilidade de tempo e precisão ainda depende do piloto de integração. Não
é justificável transportar os controles de interpolação ou posterior de C07
para o novo kernel escalar sem verificações específicas.

Três ambiguidades do desenho original precisam ser removidas:

1. Em `Γ_T+ε Γ_0`, ε é a razão `S_0/S_T`, com S_T definido **por polarização TT**.
   Não é uma fração total. Na convenção de soma dos coeficientes canônicos,
   a fração correspondente é `ε/(2+ε)`; isso não é eficiência de fontes.
2. A geometria C06 tem `fL/c≤60` **ciclos**, portanto fase angular
   `y≤120π=376,9911184` rad. Dimensionar quadraturas para y≤60 seria errado.
3. `(u,ε,log10 A_T,γ,log10 A_r,log10 EFAC)` tem seis coordenadas.
   Adota-se Fisher6D, cujo custo adicional é pequeno. Fisher5D exigiria, por
   exemplo, manter EFAC fixo e deixar essa limitação explícita.

Há também um gargalo potencial: somar pesos de nós com `logL≤logL_true` não
produz automaticamente uma CDF de logL com erro0,002. O contorno descontínuo
precisa de integração própria. Evidência convergida não resolve essa questão,
nem certifica CDFs/quantis. Esse é um gate, não um detalhe a adiar para depois
dos500 experimentos.

## Experimento e validade física

Usar exatamente as direções, distâncias, erros TOA nominais, padrão vermelho,
normalização e matrizes H preservados na fixture C06, sem reconstruí-los pelo
gerador geométrico distinto de C07. São10 pulsares, T=15 anos, grade periódica
de392 pontos (`Δt=T/392`), frequências n/T para n=1,2,3; distâncias100–300 anos-luz.
São10 estatísticas quadráticas por canal (Re/Im de quatro bins e dois autos),
com pesos fixos1/3 na compressão. Todas as matrizes continuam complexas.

Fixar as nuisances nos valores de C06: log10 A_T=−14,9, γ=4,1,
log10 A_r=−15,3, inclinação vermelha4 e EFAC=1,1. Os dois setores de sinal
têm o mesmo índice espectral, uma hipótese fenomenológica restritiva;
ε constante em frequência não deriva de uma população de fontes.

Por frequência, antes da normalização fixa:

`C_n(u,ε)=P_T(f_n)[Γ_T,n(u)+ε Γ_0,n(u)] + N_n`.

As duas populações gaussianas são independentes. Γ_0 usa a polarização
canônica de norma2 e conserva a combinação breathing–longitudinal de posto1,
incluindo os dois termos cruzados complexos. Não se normalizam diagonais por
massa. ε=0 recupera exatamente a covariância TT na mesma massa e geometria.

As duas hipóteses de evidência recebem a mesma priori própria
`u~Uniforme[10⁻³,1]`. H0 fixa ε=0; H1 usa `ε~Uniforme[0,1]`, independente de u.
O corte inferior é físico/operacional e deve aparecer no artigo; não é a
priori de massa original[0,1] de C07. Massa zero tensorial permanece um
controle analítico separado, fora dessas campanhas. O limite formal de Q
quando u→0 não permite amostrar a métrica canônica escalar singular em u=0.

No domínio declarado, `χ_n=(u/n)²` e `1/χ≤9×10⁶`. Cada componente do tensor
canônico satisfaz `|E_μν|≤2/(√3χ)`, máximo1,0392305×10⁷.
Com Δf=1/T e `S_0=ε S_T=ε h_c,T²/(2f)`, um limite conservador para o RMS de
cada componente métrica escalar nesta banda é

`σ_H² ≤ [2 ε A_T²/(3 u_min⁴)] Σ_(n=1)^3 n³ (n/15)^(3−γ)`.

Em ε=1 e nas nuisances fixadas, resulta `σ_H≤1,630563×10⁻⁸`.
O critério prospectivo é RMS≤10⁻³, a reavaliar se amplitudes/espectros/cortes
forem modificados. É um critério RMS de perturbação pequena, não uma garantia
almost-sure para amplitudes gaussianas sem limite. Não se deduz desacoplamento,
screening ou limite RG de uma população escalar postulada.

## Análises e espaços de dados

O núcleo usa cinco análises em todos os dados: A0_CN, A_CN, B_CN, A_G, B_G.
A0 recebe os30 coeficientes complexos; A recebe30 estatísticas reais;
B recebe suas10 combinações fixas. A_G/B_G recebem o controle normal gerado
com os momentos físicos exatos. Momentos incluem dependência de ε e todos
os blocos de covariância. Não há likelihood diagonal substituta.

No subconjunto C, aplicar C_beta_CN, C_full_CN, C_beta_G, C_full_G ao mesmo
vetor B do respectivo experimento. Em ambos os setores de polarização,
C_beta congela β em f_ref=1/T mantendo as fases n/T; C_full congela também
as fases. No escalar, congelar β inclui o numerador Q e seu coeficiente χ,
não somente o denominador da resposta. P_T(f_n), ruído, escalas e a lista de observações permanecem iguais.
Assim C_full pode diferir de B mesmo em massa zero e não representa somente
o erro da aproximação dispersiva.

O BF10 é `Z(H1)/Z(H0)` **dentro de cada análise e espaço observado**.
Não comparar evidências A0–A–B; possuem dados/medidas distintos. Preservar as
constantes das likelihoods CN e normal, volumes das prioris e o vínculo da
mesma massa entre H0 e H1. O critério de declaração é BF10>10, fixado antes
das injeções. `Q05(ε)>0` não é detecção sob uma priori contínua positiva.

## Contagens e sementes prospectivas

| Ensemble | Verdade | Dados | Análises em todos os dados |
|---|---|---:|---|
| Nulo | ε=0; u da priori própria comum | 500 | Cinco análises principais |
| Priori2D | u e ε das prioris H1 | 500 | Cinco análises principais |
| Recuperação fixa | u∈{0,2;0,8;0,995}, ε∈{0,1;0,5};32 por célula | 192 | Cinco análises principais |

Total:1192 dados e5960 posteriors principais. Os500 nulos medem falso positivo
**marginalizado sobre a priori declarada de u**, não uma taxa uniforme para
cada massa. Os500 da priori2D são o SBC adicional; não misturá-los com os
nulos nem com as injeções fixas. As seis células de32 são um estudo grosseiro
de recuperação condicional, inclusive próximo do limiar.

O subconjunto C é fixado por IDs, sem consultar resultados: nulos0…31,
priori2D0…31 e cinco réplicas0…4 de cada célula de recuperação, mais a réplica5
das duas células u=0,995; total96 dados×4 variantes=384 posteriors.
Esse subconjunto mantém C na extensão, mas suas taxas por ensemble têm
denominador32 nos nulos/priori e apenas5 ou6 por célula fixa. Não atribuir a C
o denominador500. Não aplicar CP binomial a um agregado das32 injeções fixas
de verdades diferentes; sua média agregada pode ser apenas descritiva.

Sementes PCG64/SeedSequence em namespaces separados:
910100101 (piloto),910100201/202 (massa/dados nulos),910100301/302
(verdades/dados priori2D),910100401 (recuperação),910100501 (controles TOY).
Cada registro recebe `[master, ensemble_id, realization_id]`; a ordem dos
blocos não altera os sorteios. O controle G compartilha latentes somente
pelo mecanismo já validado de C06, sem prometer redução da variância pareada.

## Integração2D candidata e gates anteriores à produção

Para evitar uma nova campanha MCMC, implementar uma malha positiva aninhada:
u em nós Chebyshev–Lobatto no intervalo[10⁻³,1], ε em nós uniformes[0,1].
Níveis candidatos129×65 e257×129; uma referência de engenharia513×257 somente
nos quatro dados previamente selecionados. O agrupamento de nós em u perto
dos extremos resolve melhor a fase do primeiro canal junto ao limiar.
Uma malha uniforme em u não recebe a mesma expectativa de resolução.

Interpolar a **likelihood não negativa escalada**, bilinear por célula, sem
interpolar densidade logarítmica e chamar a integral resultante exata.
O escalonamento por um máximo finito evita overflow; qualquer omissão por
underflow/truncamento deve ser quantificada separadamente. Pesos e áreas são
positivos. Z, marginais e CDFs paramétricas da aproximação são integráveis
analiticamente por célula; quantis são invertidos monotonamente com brackets.
H0 usa a borda ε=0 com integral1D da mesma aproximação/priori u.

Para o diagnóstico dependente dos dados, integrar também a região
`logL(u,ε;mesmo_dado)≤logL(u_true,ε_true;mesmo_dado)`. O contorno bilinear
permite, dentro de uma célula, integrar primeiro na coordenada ε limitada
pelo limiar e depois em u, particionando nas interseções com bordas e em
mudanças de sinal do denominador. Validar essa integral separadamente com
quadratura adaptativa/contornos da **likelihood direta**, não apenas somando
indicadores dos nós. A diferença entre o estatístico interpolado e o direto
também entra na incerteza da CDF. Se essa implementação não passar, o gate
SBC continua pendente; não remover silenciosamente o diagnóstico de logL.

Piloto:16 dados independentes, com IDs e verdades congelados no JSON candidato;
todos os nove métodos. Quatro IDs recebem513×257 e referência independente.
São necessárias as seguintes verificações, antes dos1192 dados finais:

- ORFs TT e escalar: refinamento de nós e lmax separados, céu direto
  independente, autos/limiares/rotação, Hermiticidade e PSD. Resoluções de
  partida C06: lmax460/520, nμ900/1000; direto500×1000/600×1200.
  Não afirmar adequação por serem defaults. Preservar o controle original de
  tolerância absoluta10⁻⁵ e relativa10⁻³ onde definido; registrar zeros sem
  divisão por zero. Construção em céu global e corte harmônico comum na matriz.
- Massas de referência ORF `[0,001;0,1;0,6;0,9;0,99;0,995;0,9999;1]`,
  três canais, matrizes completas; testar ambos os setores e variantes C.
  Não cortar autovalores negativos para reparar o modelo. A interpolação em
  massa deve preservar PSD ou ser rejeitada; mistura convexa de matrizes é
  uma opção simples, sujeita ao teste de precisão.
- Na mesma covariância, kernels independentes CN/normal devem concordar a
  10⁻¹⁰ em logL nos pontos relevantes, registrando erros absolutos em caudas.
  Comparar também ε=0 exatamente com o gerador TT C06; não basta recuperar uma
  ORF real ou um autovalor positivo.
- Erro observado de interpolação ORF propagado para logL≤0,001 no domínio
  de parâmetros/dados auditado. Refinar controles fora da malha usada para
  construir a tabela, inclusive as vizinhanças de u=1 e ε=0. A aprovação de
  C07/table8336 não é herdada por este experimento.
- Separadamente: mudanças entre níveis ≤0,001 em cada logZ de H0/H1 e
  ≤0,002 em logBF; CDFs paramétricas e de logL≤0,002; brackets dos oito
  quantis com largura≤0,001 da largura da respectiva priori. A referência
  independente nos quatro dados verifica os mesmos objetos. Registrar erro
  de contorno e massa omitida (alvo≤10⁻⁸); convergência de Z não substitui
  estes controles. Os limites são diagnósticos observados, não certificados
  globais de erro sem uma prova adicional.
- Controle TOY conjugado/normalizável independente: posterior, BF de H0/H1,
  inversão de quantis e CDF de logL conhecidos por integração independente.
  O algoritmo que devolve a priori deve ser detectado pelo estatístico
  dependente dos dados. Não exigir que uma realização de KS nunca rejeite.

Os níveis finais são congelados após esse piloto independente, sem ler as
verdades finais para escolher duração/resolução. O candidato só é barato se
129×65/257×129 satisfizerem os gates. Falhar exige novo desenho e custo
explícitos, sem autorizar automaticamente513×257 em toda a campanha.

Na produção, os dois níveis são executados e comparados em **todos** os alvos,
com validação por finalidade. Falhas permanecem nos resultados. Para PITs
não resolvidos, usar[0,1]; nos resolvidos, faixas determinadas pelos controles
de integração e ORF, registradas como sensibilidade. Para BF próximos de10,
reportar declarações certas/possíveis induzidas pelo intervalo de logBF.
Não selecionar somente posteriors aprovados nem ajustar o limiar de detecção.
Esta rota usa integração determinística: o erro da posterior deve ter campos
próprios e não pode ser apresentado como MCSE0 do módulo IID de C07. Reusar
os utilitários de limites/KS/Holm sobre intervalos é possível; reusar o schema
de precisão MCMC/IID como se a nova integração tivesse passado não é.

## Inferência científica e identificabilidade

Nos500 priori2D, usar os PITs de u, ε e logL. Os grupos corretos
(A0_CN,A_G,B_G) e aproximados(A_CN,B_CN) são separados. Reutilizando a estrutura
de C07, são13 hipóteses por método: três KS e, para cada um dos dois parâmetros,
quatro coberturas unilaterais e uma central. Famílias Holm39 e26; seis
comparações pareadas de cobertura central nas três duplas já registradas.
Essas são famílias C10 novas, não93/62/15. O subconjunto C fica descritivo,
com intervalos/sensibilidade e sem acrescentar hipóteses retrospectivas.

Os500 nulos reportam contagem BF>10 e CP pontual95% por método, mais uma
faixa de contagens induzida pelo erro de logBF. O critério não equivale a
nível frequentista universal0,05. As seis células mistas reportam poder desse
critério, cobertura condicional de u/ε, quantis, erros e intervalos CP comN32;
não impõem cobertura Bayes nominal em cada verdade fixa. Comparações A–B e
B–C são pareadas nos mesmos dados; a inadequação normal de A_CN/B_CN não
deve ser atribuída exclusivamente à compressão.

Fisher6D nas seis células e em dois pontos de limite (`u=10⁻³` e1, ε=0,5).
Para A0 CN própria:

`I_ij=Σ_n Re tr(C_n⁻¹ C_,i C_n⁻¹ C_,j)`.

Não há fator1/2 da normal real. Para o experimento G:

`I_ij=μ_,iᵀΣ⁻¹μ_,j + 1/2 tr(Σ⁻¹Σ_,iΣ⁻¹Σ_,j)`.

Reportar matrizes em coordenadas/escalas declaradas, autovalores, posto
numérico estável, condicionamento, correlações e informação de Schur em
(u,ε) após projetar as quatro nuisances. Escalas coordenadas declaradas:
`[0,999;1;0,6;2,5;2,5;2log10(2)]`. Usar passos relativos10⁻³ e5×10⁻⁴,
e2,5×10⁻⁴ se os autovalores/posto não estabilizarem;
derivadas unilaterais nos limites físicos, sem entrar em canais evanescentes.
Validar com as derivadas analíticas em amplitude/ruído e norma relativa da
matriz≤10⁻³ entre refinamentos; não inverter direções singulares por clipping.
A/B normais aplicadas aos dados físicos são modelos aproximados: sua Fisher
de trabalho não é automaticamente informação do experimento físico.

Esses controles medem degenerescências **locais**. Uma posterior condicional
estreita não demonstra identificabilidade global com nuisances livres.
Correlação |r|>0,95, menor autovalor generalizado da informação de Schur em
relação à informação condicionada <0,1, ou
posto instável obrigam a destacar essa limitação. Se o artigo pretender uma
conclusão robusta a ruído/espectro/amplitude livres, o desenho atual é
insuficiente e precisa de um controle com nuisances livres e orçamento próprio.
Não se aprova essa conclusão por um Fisher bem condicionado apenas.

## Custo e decisão de escopo

O candidato possui6344 posteriors, cada um com8385+33153=41538 nós:
**263.517.072 avaliações logL equivalentes**. A borda H0 pode ser reutilizada;
contá-la conservadoramente de novo acrescenta2.448.784, total265.965.856.
O teto é300 milhões, incluindo verificações adicionais de produção; o piloto
tem teto separado15 milhões. O construtor ORF tem orçamento próprio, teto
70 milhões de pontos de céu comuns aos três modos e600s, ambos medidos/revistos antes
de produzir a tabela. Fisher é determinístico, no máximo oito pontos×seis
direções×três passos, separado de posterior6D.
As oito massas×cinco configurações de fase/β distintas×duas resoluções
diretas representam48,8 milhões desses pontos de céu. Esse número não é uma
contagem de operações de ponto flutuante ou de modos: cada ponto avalia as
duas respostas TT e a escalar. C_full coincide com a configuração do primeiro
canal e não gera uma configuração direta adicional.

Essas contagens são **orçamento aritmético**, não benchmark executado.
Reutilizar fatores de covariância por nó e processar dados/blocos evita
reconstruir ORFs para cada posterior. Blocos sugeridos: até128 dados e1024
nós, memória estimada≤2GiB, teto duro4GiB. Guardar os dados, sementes,
configurações, tabela, fontes e resumos; malhas de likelihood podem ser
temporárias, com arquivo suficiente para reconstrução e hashes antes de
qualquer retirada. Não criar um banco inteiro duplicado de C07.

O gate de tempo exige estimativa conservadora baseada no piloto≤3600s para
a campanha principal na máquina e número de threads declarados. Se os gates
de precisão ou custo não passarem, executar apenas o piloto/derivação e
declarar C10 parcial; não reduzir silenciosamente500 nulos/500 priori para
fabricar fechamento. O artigo tensorial permanece o núcleo. O resultado
legítimo pode ser baixa recuperação, ausência de sensibilidade, falso
positivo elevado de aproximações ou degenerescência documentada.
