# Bilinear C10 — v3 após revisão independente

Esta versão substitui como candidata o núcleo em `../c10_bilinear/`, que permanece
inalterado para a auditoria em `../c10_bilinear_review/`. A interpretação e as
limitações da interpolação positiva, do contorno e da probabilidade omitida
continuam descritas no README histórico. Nenhuma posterior PTA foi executada.

Foram corrigidos os quatro problemas identificados na revisão:

- A inversa à esquerda em p=1 termina no primeiro ponto onde a massa total foi
  acumulada, sem prolongar um patamar final de densidade zero.
- A inversão do quantil resolve a coordenada local [0,1]; a precisão de Brent
  não fica dependente da unidade física usada no eixo.
- Larguras, massas cumulativas e volume da priori nulos/não finitos são rejeitados
  explicitamente; entradas finitas não garantem intermediários finitos.
- A evidência da hipótese na borda usa o logL original e uma escala própria,
  preservando uma borda finita em logL=-1000 diante de interior em logL=0.
  Borda identicamente nula retorna logZ=-infinito. Este caso não equivale a
  omissão numérica de uma borda positiva.

Treze testes ROOT passaram em0,028s; os nove anteriores e quatro regressões
permanecem no mesmo runner. A revisão independente histórica verificou mais31
casos analíticos, transposição/reflexão e contornos por alturas ordenadas,
com diferença máxima4,44e-16, e documentou as quatro falhas contra a versão antiga.
Esses testes não certificam a interpolação da likelihood física nem eliminam
o piloto de ORFs, evidências e CDFs exigido em C10.

Os limites de omissão de intervalos ínfimos e a estimativa de erro GK são campos
separados. O underflow nos nós do interior continua sendo reportado, sem inferir
um bound uniforme de erro da superfície a partir de um conjunto finito de nós.
