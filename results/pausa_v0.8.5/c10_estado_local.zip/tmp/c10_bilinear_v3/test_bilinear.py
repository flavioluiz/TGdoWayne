import math
import unittest
import numpy as np
from scipy.integrate import quad
from bilinear import BilinearPosterior, LinearMarginal

class BilinearTests(unittest.TestCase):
    def test_uniform_and_prior_volume(self):
        b=BilinearPosterior([.001,.2,1],[0,.25,1],np.full((3,3),-24.))
        self.assertAlmostEqual(b.log_evidence,-24.,places=13)
        self.assertAlmostEqual(b.boundary_log_evidence(),-24.,places=13)
        for p in [.05,.5,.9,.95]:
            self.assertAlmostEqual(b.marginal_x.quantile(p),.001+.999*p,places=13)
        self.assertEqual(b.log_likelihood_cdf(-24).probability,1.)
        self.assertEqual(b.log_likelihood_cdf(-24.1).probability,0.)

    def test_exact_bilinear_polynomial_and_contour(self):
        x=np.array([0,.1,.7,1.]); y=np.array([0,.2,.8,1.])
        b=BilinearPosterior(x,y,np.log(1+x[:,None]+y[None,:]))
        self.assertAlmostEqual(b.log_evidence,math.log(2.),places=14)
        self.assertAlmostEqual(b.boundary_log_evidence(),math.log(1.5),places=14)
        self.assertAlmostEqual(b.marginal_x.moment(1),13/24,places=14)
        result=b.log_likelihood_cdf(math.log(2.))
        self.assertAlmostEqual(result.probability,5/12,places=13)
        self.assertGreater(result.crossing_cells,0)
        self.assertLess(result.quadrature_absolute_error_estimate,1e-11)

    def test_product_contour_independent_reduction(self):
        x=np.linspace(0,1,9); y=np.linspace(0,1,7)
        b=BilinearPosterior(x,y,np.log((1+x[:,None])*(1+y[None,:])))
        for t in [1.001,1.4,2.,3.5,3.999]:
            def inner(x):
                ymax=max(0,min(1,t/(1+x)-1))
                return (1+x)*(ymax+ymax*ymax/2)
            points=[r for r in [t/2-1,t-1] if 0<r<1]
            oracle=quad(inner,0,1,points=points,epsabs=1e-13,epsrel=1e-13)[0]/2.25
            self.assertAlmostEqual(b.log_likelihood_cdf(math.log(t)).probability,oracle,places=12)

    def test_saddle_contour_signed_y_slope(self):
        x=np.linspace(-1,1,8); y=np.linspace(-1,1,10)
        b=BilinearPosterior(x,y,np.log(2+x[:,None]*y[None,:]))
        # XY symmetry gives weighted integral below XY=0 = (2*2 - .5)/8.
        self.assertAlmostEqual(b.log_likelihood_cdf(math.log(2)).probability,7/16,places=13)
        ps=[b.log_likelihood_cdf(math.log(t)).probability for t in [1.01,1.2,1.8,2,2.2,2.8,2.99]]
        self.assertTrue(np.all(np.diff(ps)>0))

    def test_log_scale_and_affine_axes(self):
        x=np.linspace(0,1,12); y=np.linspace(0,1,8)
        logs=-x[:,None]-2*y[None,:]
        b=BilinearPosterior(x,y,logs); c=BilinearPosterior(3+2*x,-4+7*y,logs+600)
        self.assertAlmostEqual(c.log_evidence-b.log_evidence,600,places=12)
        self.assertAlmostEqual(c.log_likelihood_cdf(599).probability,b.log_likelihood_cdf(-1).probability,places=12)
        self.assertAlmostEqual(c.marginal_x.quantile(.9),3+2*b.marginal_x.quantile(.9),places=12)

    def test_refinement_against_direct_exponential(self):
        errors=[]
        for n in [9,17,33]:
            x=np.linspace(0,1,n); y=np.linspace(0,1,n)
            b=BilinearPosterior(x,y,-x[:,None]-2*y[None,:])
            Z=(1-math.exp(-1))*(1-math.exp(-2))/2
            q90=-math.log(1-.9*(1-math.exp(-1)))
            def inner(x):
                lo=max(0,(1-x)/2)
                return math.exp(-x)*(math.exp(-2*lo)-math.exp(-2))/2
            oracle=quad(inner,0,1,epsabs=1e-13,epsrel=1e-13)[0]/Z
            errors.append([abs(b.log_evidence-math.log(Z)),abs(b.marginal_x.quantile(.9)-q90),abs(b.log_likelihood_cdf(-1).probability-oracle)])
        self.assertTrue(np.all(np.array(errors)[1:]<np.array(errors)[:-1]))
        self.assertTrue(np.all(np.array(errors)[-1]<.001))

    def test_linear_marginal_plateau_and_moments(self):
        m=LinearMarginal([0,1,2,3],[1,0,0,1])
        self.assertAlmostEqual(m.cdf(1.5),.5)
        self.assertAlmostEqual(m.quantile(.5),1.)
        self.assertAlmostEqual(m.moment(0),1.)
        self.assertAlmostEqual(m.moment(1),1.5)

    def test_zero_nodes_and_underflow_report(self):
        b=BilinearPosterior([0,1],[0,1],[[0,-1000],[-math.inf,0]])
        self.assertEqual(b.finite_underflow_nodes,1)
        self.assertTrue(math.isfinite(b.log_evidence))

    def test_invalid_input(self):
        for axis in [[0,0],[1,0],[0,math.nan]]:
            with self.assertRaises(ValueError): BilinearPosterior(axis,[0,1],[[0,0],[0,0]])
        for logs in [[[math.inf,0],[0,0]],[[math.nan,0],[0,0]],np.full((2,2),-math.inf)]:
            with self.assertRaises(ValueError): BilinearPosterior([0,1],[0,1],logs)
        b=BilinearPosterior([0,1],[0,1],[[0,0],[0,0]])
        with self.assertRaises(ValueError): b.marginal_x.quantile(1.1)
        with self.assertRaises(ValueError): b.log_likelihood_cdf(math.nan)
        with self.assertRaises(ValueError): b.log_likelihood_cdf(-1,epsabs=0)

    def test_left_inverse_at_final_plateau(self):
        m=LinearMarginal([0,1,2],[1,0,0])
        self.assertEqual(m.quantile(1),1.)
        self.assertEqual(m.cdf(m.quantile(1)),1.)

    def test_quantile_in_tiny_physical_units(self):
        m=LinearMarginal([0,1e-20],[1,1])
        for p in [.05,.5,.9,.95]:
            self.assertAlmostEqual(m.quantile(p)/1e-20,p,places=13)
            self.assertAlmostEqual(m.cdf(m.quantile(p)),p,places=13)

    def test_overflow_in_mass_rejected(self):
        with self.assertRaises(ValueError): LinearMarginal([0,2,4],[1e308]*3)
        with self.assertRaises(ValueError): LinearMarginal([-1e308,1e308],[1,1])
        with self.assertRaises(ValueError): BilinearPosterior([0,1e-300],[0,1e-300],[[0,0],[0,0]])

    def test_boundary_has_independent_log_scale(self):
        b=BilinearPosterior([.001,.5,1],[0,1],[[-1000,0]]*3)
        self.assertAlmostEqual(b.boundary_log_evidence(),-1000,places=12)
        self.assertAlmostEqual(b.log_evidence,math.log(.5),places=12)
        self.assertEqual(BilinearPosterior([0,1],[0,1],[[-math.inf,0]]*2).boundary_log_evidence(),-math.inf)

if __name__=='__main__': unittest.main(verbosity=2)
