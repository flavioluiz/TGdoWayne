# Base harmônica real e BLAS para um modo escalar FP — C10

Pacote temporário de componente, sem alterações em `src/pta`, nas fontes C07
ou em qualquer arquivo versionado. A API `RealScalarHarmonicBasis` reutiliza
uma matriz **real de Legendre ordinário**, incluindo ℓ=0 e ℓ=1. O parâmetro
`lmax` é inclusivo; `lmax` e `nmu` são obrigatórios. A precisão de uma resolução
não é herdada dos defaults de outro backend.

## Normalização e vínculo físico

Com Fourier `exp(+iω(t−βΩ·x/c))`, y=2πfL/c e
`g(y,D)=(1−exp(−iyD))/D`, a resposta do único modo vinculado é

`R_a = [1+(2β²−3)μ_a²] g(y_a,1+βμ_a)/(2√3)`.

Ela já inclui o efeito dos observadores livres e os componentes temporais da
polarização canônica de norma de Lorentz 2. O sinal global que traduz ganho de
frequência em redshift de chegada cancela na ORF. A expressão não transplanta
uma razão de marés como amplitude populacional independente: o coeficiente
longitudinal permanece ligado ao breathing pela mesma helicidade zero.

Os coeficientes e a ORF implementados são

`c_{aℓ}=∫_{−1}¹ Pℓ(μ) [1+(2β²−3)μ²] g(y_a,1+βμ) dμ`,

`Γ_ab=Σ_{ℓ=0}^{lmax} (2ℓ+1) Pℓ(p_a·p_b) c_{aℓ} c*_{bℓ}/32`.

O fator 1/32 decorre da resposta 1/(2√3), da convenção de céu 3/(8π) e
da integral angular dos produtos de Legendre. Ele não é o fator da soma de
duas polarizações TT. Os testes independentes contra os dois componentes
escalares incluem seus **termos cruzados**. O parâmetro futuro ε multiplica a
potência desta única população; esta classe não escolhe ε nem uma priori.

Pelo teorema de adição, `(2ℓ+1)Pℓ(p_a·p_b)/32` é
`(π/8)Σ_m Yℓm(p_a)Y*ℓm(p_b)`. Portanto, em aritmética exata, cada contribuição
é uma matriz de Gram após multiplicar a linha a por `c_{aℓ}`. O truncamento
**comum a todos os pares** preserva semidefinitude positiva e cada incremento
de ℓ também é PSD. Isso não certifica a convergência da série nem elimina
erros de arredondamento; autovalores negativos não são recortados. Distâncias
diferentes podem dar Γ complexa, com Γ_ba=Γ_ab*.

O backend mede e registra eventual excesso de arredondamento do produto
escalar sobre [−1,1]; somente esse excesso é corrigido antes da recorrência.
Direções precisam já ser unitárias até 64 eps, e não são renormalizadas.
A média explícita de entradas conjugadas no resultado tem seu resíduo
anterior registrado e não é uma correção de SPD.

`y=None` significa apenas o termo terrestre para todos os pulsares. Em β=1
esse caso usa a resposta limite analítica `1−μ`, com c0=2, c1=−2/3. Em fases
finitas a transferência estável existente é usada também em β=1. Este ponto
é o **limite do observável**; a métrica canônica FP é singular e não se torna
uma amostra admissível do modelo métrico massivo apenas por essa avaliação.

## API e recursos

```python
from inference.scalar_blas import RealScalarHarmonicBasis, ScalarTableBudget

basis = RealScalarHarmonicBasis(
    points, lmax=64, nmu=128,
    budget=ScalarTableBudget(), planned_batch=4,
)
report = basis.preflight(4)
coefficients = basis.multipoles([0., .4, .95, 1.], phases)  # B,N,lmax+1
gamma = basis.evaluate([0., .4, .95, 1.], phases)          # B,N,N
```

Uma instância contém geometria e resolução fixas; as fases são um vetor
comum ao lote de β. A classe mantém um contador cumulativo de trabalho e
não foi desenhada para chamadas concorrentes na mesma instância. Cada chamada
de `multipoles` ou `evaluate` reserva trabalho separadamente antes do cálculo;
não é necessário chamar ambas para obter Γ. Falhas posteriores não devolvem
a reserva. Os limites padrão são 256 MiB estimados, 16 valores de β por lote
e menos de 0,1 trilhão de multiplicações reais estimadas por lote e no total.

O preflight discrimina a base, a geometria, buffers e produtos BLAS. A estimativa
inclui contração e temporários; é distinta de um limite de RSS, custo de
funções transcendentes ou garantia de tempo. Os testes registram também o RSS
máximo observado no processo. Nenhuma resolução é ampliada automaticamente.

## Controles executados e limites

Dez testes passaram, incluindo controles de orçamento cumulativo e entradas:

| Comparação | Maior diferença absoluta |
|---|---:|
| Todos os multipolos versus recorrência original | 6,68×10⁻¹⁶ |
| Matriz versus ORFs harmônicas calculadas por par | 1,67×10⁻¹⁶ |
| Integração independente do céu global | 2,69×10⁻¹⁴ |
| Rotação da geometria | 5,27×10⁻¹⁶ |
| Combinação vinculada dos componentes com termos cruzados | 2,99×10⁻¹⁴ |

Outros controles cobrem o limite β=0, β=1 observável, fase zero, coincidência,
fases distintas, matrizes PSD e incrementos PSD, lotes e ownership. O menor
autovalor observado foi −2,18×10⁻¹⁷, preservado como arredondamento, sem reparo.
Omitir os termos cruzados produz discrepância até 0,1807 na fixture testada.

A execução final consumiu **1,502 s de CPU**, incluindo imports; os dez testes
propriamente ditos levaram 0,264 s. Foram reservadas 2.919.716 multiplicações
reais estimadas pelo novo backend e usados 40.960 pontos angulares na referência
direta. O maior workspace declarado foi 325.376 bytes; o RSS máximo do processo
foi 92.160.000 bytes. Referências por recorrência também executam operações;
o contador de BLAS identifica explicitamente o novo backend e não é uma medida
de FLOPs totais do interpretador/SciPy.

Apenas fases válidas **y≤20 radianos** foram comparadas numericamente, com
β∈[0,1]. Os controles não sustentam a precisão em y=120π do desenho C10 nem
em fases maiores, e não aprovam nmu/lmax para uma tabela completa. O script
não constrói essa tabela, gera dados PTA ou avalia likelihoods/posteriors.

Uma falha de relatório após um teste que esgotava deliberadamente o orçamento
ficou preservada em `results/runner_accounting_failure.json`. Os dez testes
numéricos já passavam; o relatório foi corrigido para ler o pico registrado,
sem pedir um novo preflight. Os critérios e as fórmulas não foram relaxados.

## Reprodução e integração

Da raiz do repositório:

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 .venv/bin/python \
  tmp/c10_scalar_blas/scripts/validar_base_escalar.py \
  --reference-file tmp/c10_scalar/scalar_fp.py \
  --pta-source-root src \
  --output tmp/c10_scalar_blas/results/validation.json
```

O único módulo candidato a integração é `src/inference/scalar_blas.py` deste
pacote. O teste usa o protótipo escalar anterior como uma das referências e
também seu céu global independente; o caminho dessa referência é explícito na
CLI. Nenhum código externo de autores foi copiado. Dependências numéricas são
NumPy/SciPy existentes; a referência antiga também usa mpmath. Manifesto e
JSON registram hashes de fontes e resultados. Qualquer portagem deve reexecutar
esses controles e conservar os limites acima antes do piloto físico posterior.
