import importlib.util
import os
from pathlib import Path
import unittest

import numpy as np

from scalar_blas import RealScalarHarmonicBasis, ScalarTableBudget, estimate

spec=importlib.util.spec_from_file_location('scalar_reference_for_blas',os.environ['C10_SCALAR_REFERENCE'])
reference=importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)

METRICS={}
BASES=[]
SKY_POINTS=0


def geometry():
    points=np.array([[0.,0.,1.],[0.,0.,1.],[0.,0.,-1.],[1.,2.,3.],[-2.,1.,.3]])
    points/=np.linalg.norm(points,axis=1)[:,None]
    return points


def basis(points=None,**kwargs):
    item=RealScalarHarmonicBasis(geometry() if points is None else points,**kwargs)
    BASES.append(item)
    return item


class ScalarBlasTests(unittest.TestCase):
    def test_01_all_multipoles_match_original_recurrence(self):
        b=basis(lmax=48,nmu=96,planned_batch=4)
        betas=[0,.2,.91,1];phases=[0,.2,2,12.3,20]
        result=b.multipoles(betas,phases);maximum=0.
        for i,beta in enumerate(betas):
            for j,y in enumerate(phases):
                expected=reference.raw_multipoles(beta,y,lmax=48,nmu=96)
                maximum=max(maximum,float(np.max(abs(result[i,j]-expected))))
        self.assertLess(maximum,5e-13)
        METRICS['maximum_multipole_difference']=maximum

    def test_02_full_matrix_matches_pairwise_harmonics(self):
        points=geometry();b=basis(points,lmax=64,nmu=96,planned_batch=3)
        betas=[0,.87,1];phases=[2,3,11,19,20]
        actual=b.evaluate(betas,phases);maximum=0.
        for k,beta in enumerate(betas):
            for i in range(len(points)):
                for j in range(len(points)):
                    expected=reference.raw_harmonic_orf(beta,float(np.clip(points[i]@points[j],-1,1)),phases[i],phases[j],lmax=64,nmu=96)[0]
                    maximum=max(maximum,float(abs(actual[k,i,j]-expected)))
        self.assertLess(maximum,5e-13)
        METRICS['maximum_pairwise_harmonic_difference']=maximum

    def test_03_independent_global_sky(self):
        global SKY_POINTS
        points=geometry();phases=[2,3,11,19,20]
        betas=[0,.4,.95,1]
        actual=basis(points,lmax=64,nmu=128,planned_batch=4).evaluate(betas,phases)
        maximum=0.
        for i,beta in enumerate(betas):
            expected=reference.raw_sky_gram(beta,points,phases,nmu=64,nphi=128)
            SKY_POINTS+=64*128
            maximum=max(maximum,float(np.max(abs(actual[i]-expected))))
        self.assertLess(maximum,2e-11)
        METRICS['maximum_independent_sky_difference']=maximum

    def test_04_analytic_threshold_and_observable_beta1(self):
        points=geometry();phases=np.array([2,3,11,19,20.]);cos=points@points.T
        b=basis(points,lmax=64,nmu=128,planned_batch=2)
        actual=b.evaluate([0,1],phases)
        g=1-np.exp(-1j*phases)
        expected=g[:,None]*g.conj()[None]*(3*cos*cos-1)/20
        np.testing.assert_allclose(actual[0],expected,rtol=0,atol=2e-13)
        for i,y in enumerate(phases):
            expected=reference.auto_reference(1,float(y),epsabs=1e-13,limit=100)[0]
            self.assertLess(abs(actual[1,i,i]-expected),2e-13)
        earth=b.evaluate([0,1],None)
        np.testing.assert_allclose(earth[0],(3*cos*cos-1)/20,rtol=0,atol=2e-13)
        np.testing.assert_allclose(earth[1],(3+cos)/24,rtol=0,atol=2e-13)
        for ell in [0,1]:
            small=basis(points,lmax=ell,nmu=8,planned_batch=1)
            coefficient=small.multipoles([1],None)
            self.assertTrue(np.all(coefficient[:,:,0]==2))
            if ell==1:self.assertTrue(np.all(coefficient[:,:,1]==-2/3))

    def test_05_common_truncation_psd_and_psd_increments(self):
        previous=np.zeros((5,5),complex);minimum=0.;increment_minimum=0.
        for ell in [0,1,2,8,32,64]:
            current=basis(lmax=ell,nmu=96,planned_batch=1).evaluate([.9],[2,3,11,19,20])[0]
            minimum=min(minimum,float(np.linalg.eigvalsh(current).min()))
            increment_minimum=min(increment_minimum,float(np.linalg.eigvalsh(current-previous).min()))
            previous=current
        self.assertGreaterEqual(minimum,-2e-13)
        self.assertGreaterEqual(increment_minimum,-2e-13)
        METRICS['minimum_eigenvalue_across_truncations']=minimum
        METRICS['minimum_eigenvalue_truncation_increment']=increment_minimum

    def test_06_rotation_coincidence_complex_phase_and_zero_phase(self):
        points=geometry();phases=[19,19.7,0,11,20]
        rotation,_=np.linalg.qr(np.array([[1.,2,-1],[3,.2,4],[-2,1,1]]))
        original=basis(points,lmax=64,nmu=96,planned_batch=2).evaluate([0,.9],phases)
        rotated=basis(points@rotation.T,lmax=64,nmu=96,planned_batch=2).evaluate([0,.9],phases)
        np.testing.assert_allclose(original,rotated,rtol=0,atol=5e-13)
        self.assertGreater(abs(original[1,0,1].imag),1e-4)
        self.assertTrue(np.all(original[:,:,2]==0))
        same=basis(points,lmax=64,nmu=96,planned_batch=1).evaluate([.9],[19,19,0,11,20])[0]
        np.testing.assert_allclose(same[0],same[1],rtol=0,atol=1e-14)
        METRICS['maximum_rotation_difference']=float(np.max(abs(original-rotated)))

    def test_07_owned_inputs_and_batch_equivalence(self):
        points=geometry();original=points.copy();betas=np.array([0,.5,1.]);phases=np.array([2,3,11,19,20.])
        b=basis(points,lmax=48,nmu=96,planned_batch=3)
        points[:]=0
        np.testing.assert_array_equal(b.points,original)
        batch=b.evaluate(betas,phases)
        single=np.concatenate([b.evaluate([value],phases) for value in betas])
        np.testing.assert_allclose(batch,single,rtol=0,atol=5e-13)
        np.testing.assert_array_equal(betas,[0,.5,1.])
        np.testing.assert_array_equal(phases,[2,3,11,19,20.])
        self.assertFalse(b.P.flags.writeable)
        self.assertFalse(b.geometry.flags.writeable)
        self.assertFalse(b.points.flags.writeable)

    def test_08_domain_and_budget_guards(self):
        for args in [dict(lmax=True,nmu=32),dict(lmax=-1,nmu=32),dict(lmax=2.5,nmu=32),dict(lmax=2,nmu=0)]:
            with self.assertRaises(ValueError):basis(**args)
        for points in [np.empty((0,3)),np.ones((1,3)),np.array([[True,False,False]]),np.array([[0,0,1j]]),np.array([[0,np.nan,1]])]:
            with self.assertRaises(ValueError):basis(points,lmax=2,nmu=32)
        with self.assertRaises(RuntimeError):basis(lmax=64,nmu=128,budget=ScalarTableBudget(maximum_estimated_memory_bytes=1))
        with self.assertRaises(RuntimeError):basis(lmax=64,nmu=128,budget=ScalarTableBudget(maximum_real_multiplications_per_batch=1))
        costs=estimate(8,32,5,1)
        with self.assertRaises(RuntimeError):
            basis(lmax=8,nmu=32,planned_batch=1,budget=ScalarTableBudget(
                maximum_total_real_multiplications=costs['real_multiplications_per_batch']))
        b=basis(lmax=np.int64(2),nmu=np.int64(32),planned_batch=1)
        for beta in [[],[True],[1j],['.5'],[np.nan],[-.1],[1.1],.5]:
            with self.assertRaises(ValueError):b.evaluate(beta,[1]*5)
        for y in [[1]*4,[-1]*5,[np.nan]*5,[True]*5,['1']*5]:
            with self.assertRaises(ValueError):b.evaluate([.5],y)
        before=b.work_reserved_real_multiplications
        with self.assertRaises(ValueError):b.evaluate([1],[1e308]*5)
        self.assertGreater(b.work_reserved_real_multiplications,before)
        with self.assertRaises(ValueError):ScalarTableBudget(maximum_batch_size=True)

    def test_09_linked_scalar_preserves_breathing_longitudinal_cross_terms(self):
        global SKY_POINTS
        points=geometry();phases=[2,3,11,19,20];beta=.8
        components=reference.raw_sky_gram(beta,points,phases,nmu=64,nphi=128,components=True)
        SKY_POINTS+=64*128
        coeff=np.array([1/np.sqrt(3),-np.sqrt(2/3)*(1-beta*beta)])
        expected=np.einsum('s,asbt,t->ab',coeff,components,coeff)
        actual=basis(points,lmax=64,nmu=128,planned_batch=1).evaluate([beta],phases)[0]
        np.testing.assert_allclose(actual,expected,rtol=0,atol=2e-11)
        omitted=coeff[0]**2*components[:,0,:,0]+coeff[1]**2*components[:,1,:,1]
        self.assertGreater(np.max(abs(expected-omitted)),.001)
        METRICS['maximum_linked_component_difference']=float(np.max(abs(actual-expected)))
        METRICS['maximum_discrepancy_if_cross_terms_omitted']=float(np.max(abs(expected-omitted)))

    def test_10_explicit_estimate_and_work_counters(self):
        b=basis(lmax=8,nmu=32,planned_batch=1)
        first=b.work_reserved_real_multiplications
        r=b.preflight(1)
        self.assertGreaterEqual(r['estimated_memory_bytes'],b.P.nbytes+b.geometry.nbytes)
        b.evaluate([.5],[2,3,11,19,20])
        self.assertEqual(b.work_reserved_real_multiplications,first+r['real_multiplications_per_batch'])
        self.assertEqual(b.completed_batches,1)
        self.assertLessEqual(b.last_evaluation_report['maximum_pre_symmetrization_hermitian_residual'],1e-13)
        costs=estimate(8,32,5,1)
        bounded=basis(lmax=8,nmu=32,planned_batch=1,budget=ScalarTableBudget(
            maximum_total_real_multiplications=costs['construction_real_multiplications_upper_estimate']+costs['real_multiplications_per_batch']))
        bounded.evaluate([.5],[2,3,11,19,20])
        with self.assertRaises(RuntimeError):bounded.evaluate([.5],[2,3,11,19,20])
        with self.assertRaises(ValueError):estimate(8,32,5,True)
