"""Small, bounded numerical checks; requires an explicit scalar reference file."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import time
import unittest

started=time.process_time()
parser=argparse.ArgumentParser()
parser.add_argument('--reference-file',type=Path,required=True)
parser.add_argument('--pta-source-root',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
base=Path(__file__).resolve().parents[1]
os.environ['C10_SCALAR_REFERENCE']=str(args.reference_file.resolve())
sys.path[:0]=[str(base/'src/inference'),str(args.pta_source_root.resolve())]
spec=importlib.util.spec_from_file_location('scalar_blas_checks',base/'tests/test_scalar_blas.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
result=unittest.TextTestRunner(verbosity=2).run(suite)
cpu=time.process_time()-started
work=sum(item.work_reserved_real_multiplications for item in module.BASES)
memory=max(item.maximum_estimated_memory_bytes_seen for item in module.BASES)
peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
peak_bytes=int(peak if sys.platform=='darwin' else peak*1024)
budget_pass=cpu<30 and work<100_000_000_000 and module.SKY_POINTS<10_000_000 and memory<=256*1024**2 and peak_bytes<=256*1024**2
files=[base/'src/inference/scalar_blas.py',base/'tests/test_scalar_blas.py',Path(__file__).resolve(),args.reference_file,
       args.pta_source_root/'pta/response.py',args.pta_source_root/'pta/_domain.py',args.pta_source_root/'pta/orf.py']
manifest=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in files]
report=dict(status='PASS_COMPONENT_ONLY_NOT_C10_PHYSICAL_APPROVAL' if result.wasSuccessful() and budget_pass else 'FAIL',
    tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),cpu_seconds=cpu,
    summed_work_real_multiplication_estimate=work,independent_sky_angular_points=module.SKY_POINTS,
    maximum_estimated_memory_bytes=memory,process_maximum_resident_bytes=peak_bytes,budget_pass=budget_pass,
    tested_maximum_phase_radians=20,tested_beta_minimum=0,tested_beta_maximum=1,
    scope='Raw scalar multipoles/ORFs only; no full table, PTA data, likelihood or inference',
    physical_likelihood_evaluations=0,metrics=module.METRICS,sources=manifest)
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:report[k] for k in ['status','tests_run','cpu_seconds','summed_work_real_multiplication_estimate','independent_sky_angular_points','process_maximum_resident_bytes']}))
raise SystemExit(0 if report['status'].startswith('PASS') else 1)
