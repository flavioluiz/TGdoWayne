"""Explicit-resolution BLAS construction of one linked FP helicity-zero ORF.

This is a raw harmonic quadrature, not a convergence certificate. The canonical
scalar polarization has Lorentz norm two, as does each real TT polarization.
beta=1 is only the continuous observable limit; its canonical FP metric is
singular. No new scalar population, independent longitudinal amplitude, or
inference is introduced by this implementation.
"""
from dataclasses import dataclass

import numpy as np
from scipy.special import roots_legendre

from pta._domain import positive_integer, real_array
from pta.response import transfer


@dataclass(frozen=True)
class ScalarTableBudget:
    maximum_estimated_memory_bytes: int = 256*1024**2
    maximum_real_multiplications_per_batch: int = 99_999_999_999
    maximum_total_real_multiplications: int = 99_999_999_999
    maximum_batch_size: int = 16

    def __post_init__(self):
        for name in self.__dataclass_fields__:
            object.__setattr__(self, name, positive_integer(getattr(self, name), name))


def estimate(lmax, nmu, npulsars, batch):
    """Conservative explicit-array/work estimate, not an RSS or time bound."""
    lmax=positive_integer(lmax, 'lmax', minimum=0)
    nmu=positive_integer(nmu, 'nmu')
    npulsars=positive_integer(npulsars, 'npulsars')
    batch=positive_integer(batch, 'batch')
    L=lmax+1; P=npulsars; B=batch; N=nmu
    fixed=8*N*L+8*P*P*L+24*P+128*N+64*P*P
    buffers=16*B*P*N+96*B*N+96*B*P*L+128*B*P*P
    blas=2*B*P*N*L
    contraction=8*B*P*P*L
    return dict(basis_bytes=8*N*L, geometry_bytes=8*P*P*L,
                estimated_memory_bytes=fixed+buffers,
                real_blas_multiplications=blas,
                contraction_real_multiplications_upper_estimate=contraction,
                real_multiplications_per_batch=blas+contraction,
                construction_real_multiplications_upper_estimate=8*N*L+10*P*P*L,
                transfer_values=B*P*N, batch_size=B,
                scope='RAW_RESOLUTION_WORK_ESTIMATE_NOT_RSS_OR_ACCURACY_CERTIFICATE')


class RealScalarHarmonicBasis:
    """Reuse real Legendre basis and geometry over a beta batch at fixed phases.

    ``multipoles`` returns c_l(beta,y_a), shape (B,N,lmax+1), where
    c_l = integral P_l(mu) [1+(2 beta²-3)mu²] g(y,1+beta mu) dmu.
    ``evaluate`` returns shape (B,N,N), with
    Gamma_ab=sum_l (2l+1) P_l(p_a.p_b) c_al c_bl* / 32.
    All pairs share every multipole. No pairwise cutoff, clipping of eigenvalues,
    jitter, or implicit choice of angular/harmonic resolution is performed.
    """
    def __init__(self, points, *, lmax, nmu, budget=ScalarTableBudget(), planned_batch=8):
        points=real_array(points, 'points')
        if points.ndim!=2 or points.shape[1]!=3 or len(points)==0:
            raise ValueError('Nonempty (N,3) unit directions required.')
        self.points=np.array(points, dtype=float, copy=True)
        norm_error=float(np.max(np.abs(np.sum(self.points*self.points, axis=1)-1)))
        if not np.isfinite(norm_error) or norm_error>64*np.finfo(float).eps:
            raise ValueError('Directions must already be unit length to floating-point roundoff.')
        self.lmax=positive_integer(lmax, 'lmax', minimum=0)
        self.nmu=positive_integer(nmu, 'nmu')
        if not isinstance(budget, ScalarTableBudget):
            raise ValueError('Explicit ScalarTableBudget required.')
        self.budget=budget
        self.work_reserved_real_multiplications=0
        self.completed_batches=0
        self.last_evaluation_report=None
        initial=self.preflight(planned_batch)
        self.maximum_estimated_memory_bytes_seen=initial['estimated_memory_bytes']
        construction=initial['construction_real_multiplications_upper_estimate']
        if construction+initial['real_multiplications_per_batch']>budget.maximum_total_real_multiplications:
            raise RuntimeError('Scalar basis construction and planned batch exceed total work budget.')
        self.work_reserved_real_multiplications=construction
        self.x,self.w=roots_legendre(self.nmu)
        self.P=np.empty((self.nmu,self.lmax+1), dtype=float, order='F')
        self.geometry=np.empty((len(points),len(points),self.lmax+1), dtype=float)
        cosine=self.points@self.points.T
        overshoot=np.maximum(np.abs(cosine)-1,0)
        if np.max(overshoot)>128*np.finfo(float).eps:
            raise ValueError('Direction cosine exceeds its mathematical range beyond roundoff.')
        # Only a measured floating-point overshoot of unit-vector dot products.
        self.geometry_roundoff_report=dict(input_norm_squared_max_error=norm_error,
            cosine_roundoff_clipped_count=int(np.count_nonzero(overshoot)),
            maximum_cosine_roundoff_correction=float(np.max(overshoot)))
        cosine=np.clip(cosine,-1,1)
        previous=np.zeros_like(self.x); current=np.ones_like(self.x)
        leg_previous=np.zeros_like(cosine); leg_current=np.ones_like(cosine)
        for ell in range(self.lmax+1):
            self.P[:,ell]=current
            self.geometry[:,:,ell]=(2*ell+1)*leg_current/32
            previous,current=current,((2*ell+1)*self.x*current-ell*previous)/(ell+1)
            leg_previous,leg_current=leg_current,((2*ell+1)*cosine*leg_current-ell*leg_previous)/(ell+1)
        for array in [self.points,self.x,self.w,self.P,self.geometry]:
            array.flags.writeable=False

    def preflight(self,batch):
        batch=positive_integer(batch,'batch')
        if batch>self.budget.maximum_batch_size:
            raise ValueError('Beta batch exceeds declared batch limit.')
        report=estimate(self.lmax,self.nmu,len(self.points),batch)
        if report['estimated_memory_bytes']>self.budget.maximum_estimated_memory_bytes:
            raise RuntimeError('Scalar basis/buffer estimate exceeds memory budget.')
        if report['real_multiplications_per_batch']>self.budget.maximum_real_multiplications_per_batch:
            raise RuntimeError('Scalar batch exceeds multiplication budget.')
        if self.work_reserved_real_multiplications+report['real_multiplications_per_batch']>self.budget.maximum_total_real_multiplications:
            raise RuntimeError('Scalar cumulative multiplication budget exceeded.')
        return report

    def _coefficients(self,betas,y):
        betas=real_array(betas,'betas',lower=0,upper=1)
        if betas.ndim!=1 or len(betas)==0:
            raise ValueError('A nonempty beta vector is required.')
        betas=np.array(betas,dtype=float,copy=True)
        if y is not None:
            y=real_array(y,'phases',lower=0)
            if y.shape!=(len(self.points),):
                raise ValueError('Exactly one finite nonnegative phase per pulsar is required.')
            y=np.array(y,dtype=float,copy=True)
        report=self.preflight(len(betas))
        self.last_evaluation_report=report
        self.maximum_estimated_memory_bytes_seen=max(self.maximum_estimated_memory_bytes_seen,report['estimated_memory_bytes'])
        # Charge before transfers/BLAS; numerical failures do not release work.
        self.work_reserved_real_multiplications+=report['real_multiplications_per_batch']
        B=len(betas); P=len(self.points)
        real=np.empty((B,P,self.nmu)); imag=np.empty_like(real)
        denominator=1+betas[:,None]*self.x
        weight=self.w*(1+(2*betas[:,None]**2-3)*self.x**2)
        for j in range(P):
            g=1/denominator if y is None else transfer(float(y[j]),denominator)
            weighted=weight*g
            real[:,j]=weighted.real; imag[:,j]=weighted.imag
        rc=real.reshape(B*P,self.nmu)@self.P
        ic=imag.reshape(B*P,self.nmu)@self.P
        coefficients=(rc+1j*ic).reshape(B,P,self.lmax+1)
        if y is None:
            # Analytic Earth-only continuous response: (1-mu²)/(1+mu)=1-mu.
            mask=betas==1
            coefficients[mask]=0
            coefficients[mask,:,0]=2
            if self.lmax>=1: coefficients[mask,:,1]=-2/3
        if not np.all(np.isfinite(coefficients)):
            raise ArithmeticError('Nonfinite raw scalar multipoles.')
        return coefficients

    def multipoles(self,betas,y):
        coefficients=self._coefficients(betas,y)
        self.completed_batches+=1
        return coefficients

    def evaluate(self,betas,y):
        coefficients=self._coefficients(betas,y)
        gram=np.einsum('bal,bcl,acl->bac',coefficients,coefficients.conj(),self.geometry,optimize=False)
        if not np.all(np.isfinite(gram)):
            raise ArithmeticError('Nonfinite raw scalar ORF.')
        residual=float(np.max(np.abs(gram-gram.swapaxes(-1,-2).conj())))
        self.last_evaluation_report=dict(self.last_evaluation_report,
            maximum_pre_symmetrization_hermitian_residual=residual)
        # Explicit average of algebraically conjugate entries, not an SPD repair.
        gram=(gram+gram.swapaxes(-1,-2).conj())/2
        self.completed_batches+=1
        return gram
