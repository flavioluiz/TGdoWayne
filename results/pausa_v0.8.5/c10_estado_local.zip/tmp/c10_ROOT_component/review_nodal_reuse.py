"""Reconstruct saved nodal diagnostics only. No ORF or density evaluations."""
from pathlib import Path
import hashlib
import json
import resource
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
    return h.hexdigest()

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(30,32))
    base=ROOT/'tmp/c10_orf_preflight'
    report_path=base/'results/table.json';report=json.loads(report_path.read_text())
    config_path=base/'configs/orf_candidate_v1.json';config=json.loads(config_path.read_text())
    assert report['status']=='COMPONENT_ORF_TABLE_FAIL'
    assert sha(config_path)==report['config_sha256']
    for path,digest in report['source_hashes'].items():assert sha(ROOT/path)==digest,path
    probes=json.loads((base/'results/probes.json').read_text())
    assert probes['status']=='COMPONENT_ORF_PROBES_PASS' and all(g['passed'] for g in probes['gates'].values())
    assert sha(base/'results/ROOT_approval_table_v1.json')==report['approval_file_sha256']
    auth=json.loads((base/'results/ROOT_approval_table_v1.json').read_text())
    assert sha(base/'results/probes.json')==auth['probes_json_sha256']
    assert config['unique_case_names']==['D1','D2','D3','CB2','CB3']
    assert config['output_mapping']=={'dispersive':[0,1,2],'C_beta':[0,3,4],'C_full':[0,0,0]}
    expected_resolutions=[(460,900),(460,1000),(520,1000)]
    assert [(r['lmax'],r['nmu']) for r in config['harmonic_resolutions']]==expected_resolutions
    archive=base/'results/table.npz'
    assert archive.stat().st_size<32*1024**2 and sha(archive)==report['arrays_sha256']
    with zipfile.ZipFile(archive) as z:assert sum(i.file_size for i in z.infolist())<26*1024**2
    with np.load(archive,allow_pickle=False) as z:
        assert set(z.files)=={'masses','gamma','grid129_indices','grid257_indices','grid513_indices'}
        u=z['masses'];g=z['gamma']
        for n,stride in [(129,4),(257,2),(513,1)]:assert np.array_equal(z[f'grid{n}_indices'],np.arange(0,513,stride))
    expected=.001+.999*(1-np.cos(np.pi*np.arange(513)/512))/2
    expected[0]=.001;expected[-1]=1.
    assert u.shape==(513,) and u.dtype==np.float64 and np.array_equal(u,expected)
    assert g.shape==(3,513,5,2,10,10) and g.dtype==np.complex128 and np.isfinite(g).all()
    mass_sha=hashlib.sha256(u.astype('<f8',copy=False).tobytes()).hexdigest()
    assert mass_sha=='b28b764c1470f1ab70a3f37d1029913288a032a993e9945d537acaaf91746ffa'
    checks={}
    for name,a,b in [('angular_nodes_only',g[0],g[1]),('harmonic_cutoff_only',g[1],g[2])]:
        difference=abs(a-b);den=config['atol']+config['rtol']*abs(b)
        passed=bool(np.all(difference<=den));assert passed and report['gates'][name]['passed']
        checks[name]=dict(passed=passed,maximum_absolute_error=float(np.max(difference)),maximum_tolerance_ratio=float(np.max(difference/den)))
        assert checks[name]['maximum_absolute_error']==report['gates'][name]['maximum_absolute_error']
    eigen=np.linalg.eigvalsh(g);scale=np.maximum(np.max(abs(eigen),axis=-1),np.finfo(float).tiny)
    minimum=float(np.min(eigen[...,0]/scale));anti=float(np.max(abs(g-g.swapaxes(-1,-2).conj())))
    assert minimum>=-config['psd_relative_roundoff_allowance'] and anti==0
    checks['PSD']=dict(passed=True,minimum_eigenvalue=float(eigen.min()),minimum_relative_eigenvalue=minimum,maximum_hermitian_residual=anti,no_clipping=True)
    for coarse,fine in [(129,257),(257,513)]:
        s=512//(fine-1);v=g[2,::s];x=u[::s];a=v[::2];t=x[::2]
        r=((x[1::2]-t[:-1])/(t[1:]-t[:-1])).reshape((-1,1,1,1,1))
        delta=abs((1-r)*a[:-1]+r*a[1:]-v[1::2]);tol=config['atol']+config['rtol']*abs(v[1::2])
        name=f'mass_linear_{coarse}_to_{fine}_new_nodes'
        assert not np.all(delta<=tol) and report['gates'][name]['passed'] is False
        checks[name]=dict(passed=False,maximum_absolute_error=float(np.max(delta)))
        assert checks[name]['maximum_absolute_error']==report['gates'][name]['maximum_absolute_error']
    assert sha(archive)==report['arrays_sha256']
    receipt=dict(approved=True,scope='NODAL_ORFS_ONLY',table_sha256=sha(archive),mass_payload_sha256=mass_sha,
                 geometry_fixture_sha256=report['source_hashes']['results/C06/massive/fixture.npz'],
                 original_table_report_sha256=sha(report_path),nodal_gates_pass=True,interpolation_approved=False,
                 historical_interpolation_status=report['status'],reconstructed_checks=checks,
                 case_order=config['unique_case_names'],output_mapping=config['output_mapping'],
                 harmonic_resolutions=config['harmonic_resolutions'],sector_order=['TT_sum_plus_cross','one_linked_FP_scalar'],
                 old_probe_report_sha256=sha(base/'results/probes.json'),source_bindings_verified=report['source_hashes'],
                 numerical_array_bytes=int(g.nbytes+u.nbytes),new_ORF=0,new_logL=0,new_draws=0,
                 CPU_seconds_including_imports=sum(resource.getrusage(resource.RUSAGE_SELF)[:2]),
                 peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024),
                 reviewer_source_sha256=sha(Path(__file__)),
                 scope_limit='Authorizes only reuse of these stored exact-node matrices under the bound conventions. No pilot, production, interpolation or uniform physical-probability approval.')
    assert receipt['peak_RSS_bytes']<256*1024**2
    with (HERE/'nodal_reuse_review_v1.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='source_bindings_verified'}))

if __name__=='__main__':main()
