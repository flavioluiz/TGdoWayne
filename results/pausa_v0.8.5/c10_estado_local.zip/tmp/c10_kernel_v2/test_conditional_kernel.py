import unittest
import numpy as np
from scipy.stats import multivariate_normal
from conditional_kernel import ConditionalLikelihood


def fixture():
    rng=np.random.default_rng(910110401); R,K,P,D=3,2,4,3
    z=rng.normal(size=(K,P,P))+1j*rng.normal(size=(K,P,P))
    c0=z@z.swapaxes(-1,-2).conj()+np.eye(P)[None]
    z=rng.normal(size=(K,P,P))+1j*rng.normal(size=(K,P,P))
    c1=.2*(z@z.swapaxes(-1,-2).conj())
    z=rng.normal(size=(D,P,P))+1j*rng.normal(size=(D,P,P)); H=(z+z.swapaxes(-1,-2).conj())/2
    q=rng.normal(size=(R,K,P))+1j*rng.normal(size=(R,K,P))
    x=rng.normal(size=(R,K,D)); g=rng.normal(size=(R,K,D)); w=np.array([.3,.7])
    return c0,c1,H,q,x,g,w


class KernelTests(unittest.TestCase):
    def make(self,budget=10000,memory=512*1024**2):
        c0,c1,H,q,x,g,w=fixture()
        return ConditionalLikelihood(q,x,g,H,w,maximum_logl_values=budget,maximum_workspace_bytes=memory),c0,c1

    def test_independent_real_CN_and_scipy_normal(self):
        engine,c0,c1=self.make(); eps=[0,.3,1]
        actual,_=engine.evaluate(c0,c1,eps)
        for e,epsilon in enumerate(eps):
            c=c0+epsilon*c1; mus=[]; sigmas=[]
            for k in range(engine.K):
                mu=np.array([np.trace(h@c[k]).real for h in engine.H])
                sigma=np.array([[np.trace(h@c[k]@j@c[k]).real for j in engine.H] for h in engine.H])
                mus.append(mu); sigmas.append(sigma)
            mb=sum(w*m for w,m in zip(engine.w,mus)); sb=sum(w*w*s for w,s in zip(engine.w,sigmas))
            for r in range(engine.R):
                expected_a0=0.
                for k in range(engine.K):
                    real_cov=.5*np.block([[c[k].real,-c[k].imag],[c[k].imag,c[k].real]])
                    vec=np.r_[engine.q[r,k].real,engine.q[r,k].imag]
                    expected_a0+=multivariate_normal.logpdf(vec,mean=np.zeros(2*engine.P),cov=real_cov)
                self.assertAlmostEqual(actual[e,0,r],expected_a0,places=11)
                for ia,ib,data in [(1,2,engine.physical),(3,4,engine.gaussian)]:
                    expected_a=sum(multivariate_normal.logpdf(data[r,k],mean=mus[k],cov=sigmas[k]) for k in range(engine.K))
                    expected_b=multivariate_normal.logpdf(np.einsum('kd,k->d',data[r],engine.w),mean=mb,cov=sb)
                    self.assertAlmostEqual(actual[e,ia,r],expected_a,places=11)
                    self.assertAlmostEqual(actual[e,ib,r],expected_b,places=11)
        self.assertEqual(engine.logl_values,45); self.assertEqual(engine.completed_logl_values,45)

    def test_polynomial_moments_cross_term(self):
        engine,c0,c1=self.make(); _,_,basis,_=engine.moments(c0,c1)
        m0,m1,s0,s1,s2=basis
        for epsilon in [0,.01,.5,1]:
            for k in range(engine.K):
                c=c0[k]+epsilon*c1[k]
                mu=np.array([np.trace(h@c).real for h in engine.H])
                sigma=np.array([[np.trace(h@c@j@c).real for j in engine.H] for h in engine.H])
                np.testing.assert_allclose(m0[k]+epsilon*m1[k],mu,rtol=1e-12,atol=1e-12)
                np.testing.assert_allclose(s0[k]+epsilon*s1[k]+epsilon**2*s2[k],sigma,rtol=1e-12,atol=1e-11)

    def test_epsilon_zero_and_batch_splitting(self):
        engine,c0,c1=self.make(); actual,_=engine.evaluate(c0,c1,[0,.2,.8,1])
        other,_,_=self.make(); separate=np.concatenate([other.evaluate(c0,c1,[x])[0] for x in [0,.2,.8,1]])
        np.testing.assert_allclose(actual,separate,rtol=1e-13,atol=1e-12)
        zero,_=engine.evaluate(c0,c1*0,[0])
        np.testing.assert_allclose(actual[0],zero[0],rtol=0,atol=0)

    def test_data_copied_and_read_inputs_preserved(self):
        c0,c1,H,q,x,g,w=fixture(); originals=[v.copy() for v in [c0,c1,H,q,x,g,w]]
        engine=ConditionalLikelihood(q,x,g,H,w,maximum_logl_values=1000)
        engine.evaluate(c0,c1,[.5])
        for a,b in zip([c0,c1,H,q,x,g,w],originals): np.testing.assert_array_equal(a,b)
        q[:]=0; self.assertFalse(np.array_equal(q,engine.q))

    def test_budgets_before_density_work_and_failure_reserved(self):
        engine,c0,c1=self.make(budget=15); engine.evaluate(c0,c1,[0])
        with self.assertRaises(RuntimeError): engine.evaluate(c0,c1,[1])
        self.assertEqual(engine.logl_values,15)
        tiny,_,_=self.make(memory=1)
        with self.assertRaises(RuntimeError): tiny.evaluate(c0,c1,[0])
        self.assertEqual(tiny.logl_values,0)
        c0,c1,H,q,x,g,w=fixture(); H[1]=H[0]
        bad=ConditionalLikelihood(q,x,g,H,w,maximum_logl_values=15)
        with self.assertRaises(np.linalg.LinAlgError): bad.evaluate(c0,c1,[.5])
        self.assertEqual(bad.logl_values,15); self.assertEqual(bad.completed_logl_values,0)

    def test_guards(self):
        engine,c0,c1=self.make()
        for eps in [[],[-.1],[1.1],[np.nan],[True]]:
            with self.assertRaises(ValueError): engine.evaluate(c0,c1,eps)
        with self.assertRaises(ValueError): engine.evaluate(c0,-c1,[.5])
        wrong=c0.copy(); wrong[0,0,1]+=.1
        with self.assertRaises(ValueError): engine.evaluate(wrong,c1,[.5])
        with self.assertRaises(np.linalg.LinAlgError): engine.evaluate(-c0,c1,[.5])

    def test_normal_covariance_memory_term(self):
        q=np.zeros((1,1,10),complex); x=np.zeros((1,1,100)); H=np.zeros((100,10,10),complex)
        engine=ConditionalLikelihood(q,x,x,H,[1],maximum_logl_values=10000,maximum_workspace_bytes=2*1024**2)
        with self.assertRaises(RuntimeError): engine.preflight(100)
        ample=ConditionalLikelihood(q,x,x,H,[1],maximum_logl_values=10000)
        p=ample.preflight(100)
        self.assertEqual(p['components_bytes']['normal_covariance_and_factors'],48_000_000)
        self.assertGreater(p['estimated_numeric_workspace_bytes'],80_000_000)

if __name__=='__main__': unittest.main(verbosity=2)
