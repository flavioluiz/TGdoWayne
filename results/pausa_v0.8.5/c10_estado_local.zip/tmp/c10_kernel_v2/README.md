# Kernel condicional de covariância — preparação C10

Componente genérico que recebe C0 e C1 e avalia C(epsilon)=C0+epsilon*C1, sem
construir ORF ou escolher uma população escalar. C0 é SPD e C1 PSD no domínio
epsilon em[0,1]; pequenas assimetrias são registradas e promediadas, sem jitter
ou corte de autovalores. Dados e estimadores são copiados. A compressão usa
pesos fixos, a média soma w e a covariância soma w² para os canais independentes.

A saída tem forma(E,5,R), com modelos A0_CN,A_CN,B_CN,A_G,B_G. As densidades
incluem logdet e constantes, CN própria com K*P log(pi) e normal real com
K*D log(2pi). A normal aplicada às estatísticas físicas permanece aproximação.
Uma C1 escalar correta, resposta/normalização TT e validade dos dados são
responsabilidade do experimento e de suas verificações, ainda não executadas.

Momentos são polinômios exatos em epsilon para essa covariância:
mu=mu0+epsilon*mu1 e Sigma=Sigma00+epsilon*(Sigma01+Sigma10)+epsilon²*Sigma11.
A soma cruzada foi confrontada com produtos de matrizes diretos. O algoritmo
reutiliza cada fator de covariância em todos os dados de um bloco.

O orçamento reserva o custo integral(E*5*R) antes de avaliar densidades; falhas
posteriores à reserva continuam consumindo a contagem conservadora. O contador
de valores concluídos é separado. Memória inclui dados próprios e termos
explícitos para fatores CN, soluções, HC, base de momentos, sigma e fatores
normais E*K*D², covariância comprimida e saídas. É uma estimativa de arrays e
scratch, não garantia de RSS ou ausência de buffers internos do BLAS.

A versão antiga em `../c10_kernel/` foi preservada. A revisão independente
`../c10_kernel_review/` identificou a ausência do termo E*K*D² na estimativa;
a v2 o acrescenta e rejeita o exemplo R=K=1,P=10,D=100,E=100 sob teto2MiB.
Não foi necessário alterar fórmulas de probabilidade. Sete testes ROOT passaram
em0,043s; a auditoria independente da v1 passou oito controles adicionais
(invariância unitária, jacobianos CN/normal, índices, C1 posto um/zero e cópias).

Os testes usam pequenas matrizes sintéticas, e comparam CN com a representação
normal real de dimensão2P e as outras densidades com SciPy/produtos diretos.
Não representam seis/seven experimentos PTA nem calibração escalar.
