"""Bounded covariance-level epsilon=0 comparison on the preserved C06 fixture."""
from pathlib import Path
import sys,json,hashlib,time
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
from conditional_kernel import ConditionalLikelihood
from inference.likelihood_reference import cn_logpdf,normal_logpdf
from pta.statistics import quadratic_moments,compress_independent_moments,compress_frequencies

out=Path(__file__).with_name('c06_zero_scalar_validation.json')
if out.exists(): raise FileExistsError('Do not overwrite the previous validation')
preflight={'scope':'C06_FIXED_COVARIANCES_EPSILON_ZERO_ONLY','maximum_logl_values':500,'planned_logl_values':3*32*5,'maximum_numeric_workspace_bytes':256*1024**2,'maximum_cpu_seconds':30,'ORF_evaluations':0,'scalar_ORF_not_validated_here':True}
Path(__file__).with_name('c06_zero_scalar_preflight.json').write_text(json.dumps(preflight,indent=2)+'\n')
start=time.process_time(); source=ROOT/'results/C06/massive/fixture.npz'
with np.load(source,allow_pickle=False) as p: f={k:p[k] for k in p.files}
engine=ConditionalLikelihood(f['fourier_normalized'],f['physical_A'],f['gaussian_A'],f['estimator_matrices'],f['frequency_weights'],maximum_logl_values=500,maximum_workspace_bytes=256*1024**2)
records=[]
for name in ['dispersive','C_full','C_beta']:
    C=f['C_normalized_'+name]
    actual,checks=engine.evaluate(C,np.zeros_like(C),[0.])
    mu,sigma=quadratic_moments(C,f['estimator_matrices'])
    muB,sigmaB=compress_independent_moments(mu,sigma,f['frequency_weights'])
    expected=np.stack([cn_logpdf(C[None],f['fourier_normalized'])[0],normal_logpdf(mu[None],sigma[None],f['physical_A'])[0],normal_logpdf(muB[None,None],sigmaB[None,None],f['physical_B'][:,None])[0],normal_logpdf(mu[None],sigma[None],f['gaussian_A'])[0],normal_logpdf(muB[None,None],sigmaB[None,None],f['gaussian_B'][:,None])[0]])
    error=float(np.max(abs(actual[0]-expected)))
    if error>1e-10: raise ArithmeticError('Fixed C06 covariance comparison failed')
    records.append({'covariance':name,'logl_values':160,'maximum_absolute_logl_difference':error,'input_checks':checks})
elapsed=time.process_time()-start
if elapsed>30: raise RuntimeError('CPU budget exceeded')
files=[source,Path(__file__),Path(__file__).with_name('conditional_kernel.py'),ROOT/'src/inference/likelihood_reference.py',ROOT/'src/pta/statistics.py']
report={'status':'PASS_FIXED_C06_COVARIANCE_EPSILON_ZERO_NOT_SCALAR_RECOVERY','CPU_seconds':elapsed,'logl_values':engine.completed_logl_values,'planned_and_reserved_logl_upper_bound':engine.logl_values,'ORF_evaluations':0,'preflight':preflight,'workspace_estimate':engine.last_preflight,'checks':records,'sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'limitations':['No scalar response or epsilon>0 physical covariance evaluated.','No posterior, BF calibration or simulated recovery performed.','C_full/C_beta are fixed C06 covariance inputs, not a new approximation validation.']}
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'CPU_seconds':elapsed,'logl_values':engine.logl_values,'max_error':max(r['maximum_absolute_logl_difference'] for r in records)}))
