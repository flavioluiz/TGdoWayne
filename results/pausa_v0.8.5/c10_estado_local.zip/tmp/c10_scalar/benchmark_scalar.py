"""Selected finite scalar benchmarks; each refinement is recorded independently."""
import hashlib
import json
from pathlib import Path
from time import perf_counter

import numpy as np
import scipy

import scalar_fp as scalar

ROOT=Path(__file__).resolve().parent


def record(value):
    return {'real':float(np.real(value)), 'imag':float(np.imag(value))}


def main():
    baseline=2*np.pi*1000.125
    medium=2*np.pi*100.125
    cases=[(0,27.1,28.1,np.pi/8), (1e-5,baseline,baseline+1,np.pi/8),
           (.01,medium,medium+1,np.pi/8), (.9,medium,medium+1,np.pi/8),
           (1,medium,medium+1,np.pi/8), (.9,baseline,baseline+1,np.pi/8),
           (1,baseline,baseline+1,np.pi/8),
           (.9,baseline,baseline+1,1e-5), (1,baseline,baseline+1,1e-5)]
    report={'status':'in_progress','atol':1e-5,'rtol':1e-3,'numpy':np.__version__,
            'scipy':scipy.__version__,'rows':[],
            'source_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                             for name in ['scalar_fp.py','test_scalar_fp.py','benchmark_scalar.py']}}
    started=perf_counter()
    for beta,ya,yb,angle in cases:
        t=perf_counter()
        peak=beta*max(ya,yb)
        coarse={'lmax':max(80,int(peak+100)), 'nmu_harmonic':max(200,int(2*peak+220)),
                'nmu_direct':max(120,int(1.2*peak+130)),
                'nphi_direct':max(240,int(2.4*peak*np.sin(angle)+240))}
        fine={key:value+{'lmax':50,'nmu_harmonic':100,'nmu_direct':100,'nphi_direct':200}[key]
              for key,value in coarse.items()}
        cosine=float(np.cos(angle))
        h0=scalar.raw_harmonic_orf(beta,cosine,ya,yb,lmax=coarse['lmax'],nmu=coarse['nmu_harmonic'])[0]
        hn=scalar.raw_harmonic_orf(beta,cosine,ya,yb,lmax=coarse['lmax'],nmu=fine['nmu_harmonic'])[0]
        hf=scalar.raw_harmonic_orf(beta,cosine,ya,yb,lmax=fine['lmax'],nmu=fine['nmu_harmonic'])[0]
        d0=scalar.raw_direct_orf(beta,cosine,ya,yb,nmu=coarse['nmu_direct'],nphi=coarse['nphi_direct'])
        df=scalar.raw_direct_orf(beta,cosine,ya,yb,nmu=fine['nmu_direct'],nphi=fine['nphi_direct'])
        auto=scalar.raw_harmonic_orf(beta,1,ya,ya,lmax=fine['lmax'],nmu=fine['nmu_harmonic'])[0]
        auto_ref,auto_est=scalar.auto_reference(beta,ya,epsabs=1e-12,limit=300)
        errors={'harmonic_nodes':abs(hn-h0),'harmonic_cutoff':abs(hf-hn),
                'direct_refinement':abs(df-d0),'cross_method':abs(df-hf),
                'auto_reference':abs(auto-auto_ref)}
        relative={key:float(value/(abs(auto_ref) if key=='auto_reference' else abs(hf)))
                  for key,value in errors.items()}
        passed=all(value<=1e-5 and relative[key]<=1e-3 for key,value in errors.items())
        row={'beta':beta,'ya':ya,'yb':yb,'angle_radians':angle,'status':'PASS' if passed else 'FAIL',
             'coarse':coarse,'fine':fine,'harmonic':record(hf),'direct':record(df),
             'earth_only':scalar.earth_analytic(beta,cosine),'auto_full':record(auto),
             'auto_reference':auto_ref,'auto_quadrature_error_estimate':auto_est,
             'auto_incoherent_limit':2*scalar.earth_analytic(beta,1),
             'absolute_errors':{key:float(value) for key,value in errors.items()},
             'relative_errors':relative,'seconds':perf_counter()-t}
        report['rows'].append(row)
        (ROOT/'benchmark_results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
        print(f"beta={beta:g}, y={ya:.3f}, angle={angle:g}: {row['status']}, maxerr={max(errors.values()):.3g}, {row['seconds']:.2f}s",flush=True)
    report['status']='PASS' if all(row['status']=='PASS' for row in report['rows']) else 'FAIL'
    report['seconds_total']=perf_counter()-started
    report['maximum_absolute_error']=max(error for row in report['rows'] for error in row['absolute_errors'].values())
    report['maximum_relative_error']=max(error for row in report['rows'] for error in row['relative_errors'].values())
    (ROOT/'benchmark_results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:value for key,value in report.items() if key not in ['rows','source_sha256']},indent=2))
    raise SystemExit(0 if report['status']=='PASS' else 1)


if __name__=='__main__':
    main()
