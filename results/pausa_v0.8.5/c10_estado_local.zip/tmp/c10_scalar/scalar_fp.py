"""C10 research prototype: one linked FP helicity-zero response.

Metric signature (+---), H covariant, Fourier exp(+i*omega*(t-beta*Omega.x)).
The canonical real polarization has Lorentz norm 2, like each real TT tensor.
Raw integrals require explicit resolutions; no inference or universal error claim.
beta=1 is only a continuous response limit: its canonical metric is singular.
"""
from functools import lru_cache
from pathlib import Path
import sys

import mpmath as mp
import numpy as np
from scipy.integrate import quad
from scipy.special import eval_legendre, roots_legendre

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'src'))
from pta._domain import beta_value, cosine_value, phase, positive_integer, response_arguments
from pta.orf import gr_auto_exact
from pta.response import transfer


def metric_polarization(beta, omega):
    """H^(0)/h_0 with H:H=2; cannot evaluate the singular canonical beta=1 limit."""
    beta = beta_value(beta)
    omega = _directions(np.asarray(omega)[None, :])[0]
    if beta == 1:
        raise ValueError('Canonical FP helicity-zero metric is singular at beta=1.')
    delta = (1-beta)*(1+beta)
    h = np.zeros((4, 4))
    h[0, 0] = -2*beta*beta/delta
    h[0, 1:] = h[1:, 0] = 2*beta*omega/delta
    h[1:, 1:] = np.eye(3)-np.outer(omega, omega)-2*np.outer(omega, omega)/delta
    return h/np.sqrt(3)


def _directions(vectors):
    values = np.asarray(vectors)
    if values.dtype.kind not in 'iuf' or values.ndim != 2 or values.shape[1] != 3:
        raise ValueError('Directions must be a finite real (N,3) array.')
    if not np.all(np.isfinite(values)) or not np.allclose(np.sum(values*values, axis=1), 1,
                                                        rtol=0, atol=1e-12):
        raise ValueError('Every direction must be finite and unit length.')
    return values.astype(float)


@lru_cache(maxsize=16)
def _nodes(n):
    x, w = roots_legendre(positive_integer(n, 'nmu'))
    x.flags.writeable = w.flags.writeable = False
    return x, w


def _independent_transfer(y, denominator):
    """expm1 route independent of the sinc expression used by the harmonic method."""
    numerator = -np.expm1(-1j*y*denominator)
    return np.divide(numerator, denominator,
        out=np.full_like(numerator, 1j*y), where=denominator != 0)


def raw_sky_gram(beta, directions, phases, *, nmu, nphi, components=False):
    """One global quadrature sky, explicit Q_ij matrices and independently formed phases.

    components=True returns shape (N,2,N,2), basis b=P and l=sqrt(2)*Omega*Omega.
    Both basis tensors have Euclidean norm 2. These are components of one mode,
    not two independently excited scalar populations.
    phases=None denotes Earth-only for every pulsar.
    """
    beta, directions = beta_value(beta), _directions(directions)
    nmu, nphi = positive_integer(nmu, 'nmu'), positive_integer(nphi, 'nphi')
    if phases is not None:
        if len(phases) != len(directions):
            raise ValueError('One phase is required for every direction.')
        phases = np.array([phase(value) for value in phases])
    x, wx = _nodes(nmu)
    n = len(directions)
    result = np.zeros((n, 2, n, 2) if components else (n, n), dtype=complex)
    delta = (1-beta)*(1+beta)
    for start in range(0, nphi, 64):
        phi = 2*np.pi*(np.arange(start, min(start+64, nphi))+.25)/nphi
        xx, pp = np.meshgrid(x, phi, indexing='ij')
        rr = np.sqrt(1-xx*xx)
        omega = np.stack([rr*np.cos(pp), rr*np.sin(pp), xx], axis=-1)
        oo = omega[..., :, None]*omega[..., None, :]
        projector = np.eye(3)-oo
        mu = np.einsum('...i,ai->...a', omega, directions)
        denom = 1+beta*mu
        factor = 1/denom if phases is None else _independent_transfer(phases, denom)
        weight = np.broadcast_to(wx[:, None], xx.shape)*(2*np.pi/nphi)*(3/(8*np.pi))
        if components:
            basis = np.stack([projector, np.sqrt(2)*oo], axis=-3)
            contracted = np.einsum('ai,...sij,aj->...as', directions, basis, directions)
            responses = .5*contracted*factor[..., :, None]
            result += np.einsum('xyas,xybt,xy->asbt', responses, responses.conj(), weight)
        else:
            q = (projector-2*delta*oo)/np.sqrt(3)
            contracted = np.einsum('ai,...ij,aj->...a', directions, q, directions)
            responses = .5*contracted*factor
            result += np.einsum('xya,xyb,xy->ab', responses, responses.conj(), weight)
    return result


def raw_direct_orf(beta, cosine, ya=None, yb=None, *, nmu, nphi):
    beta, cosine, ya, yb = response_arguments(beta, cosine, ya, yb)
    pulsars = np.array([[0., 0., 1.], [np.sqrt(1-cosine*cosine), 0., cosine]])
    phases = None if ya is None else [ya, yb]
    return complex(raw_sky_gram(beta, pulsars, phases, nmu=nmu, nphi=nphi)[0, 1])


def raw_multipoles(beta, y, *, lmax, nmu):
    beta = beta_value(beta)
    y = None if y is None else phase(y)
    lmax = positive_integer(lmax, 'lmax', minimum=0)
    nmu = positive_integer(nmu, 'nmu')
    if y is None and beta == 1:
        result = np.zeros(lmax+1, dtype=complex)
        result[0] = 2
        if lmax >= 1:
            result[1] = -2/3
        return result
    x, wx = _nodes(nmu)
    polynomial = 1+(2*beta*beta-3)*x*x
    g = 1/(1+beta*x) if y is None else transfer(y, 1+beta*x)
    weighted = wx*polynomial*g
    values = []
    previous, current = np.zeros_like(x), np.ones_like(x)
    for ell in range(lmax+1):
        values.append(np.dot(weighted, current))
        following = ((2*ell+1)*x*current-ell*previous)/(ell+1)
        previous, current = current, following
    return np.asarray(values)


def raw_harmonic_orf(beta, cosine, ya=None, yb=None, *, lmax, nmu):
    beta, cosine, ya, yb = response_arguments(beta, cosine, ya, yb)
    ca = raw_multipoles(beta, ya, lmax=lmax, nmu=nmu)
    cb = ca if ya == yb else raw_multipoles(beta, yb, lmax=lmax, nmu=nmu)
    ell = np.arange(len(ca))
    terms = (2*ell+1)*ca*cb.conj()*eval_legendre(ell, cosine)/32
    return complex(np.sum(terms)), terms


def earth_analytic(beta, cosine):
    """Independent sky-moment/Feynman-parameter expression, not Liang Eq.(46)."""
    beta, cosine = beta_value(beta), cosine_value(cosine)
    if beta == 0:
        return (3*cosine*cosine-1)/20
    if beta == 1:
        return (3+cosine)/24
    precision = max(80, int(-8*np.log10(beta))+30)
    with mp.workdps(precision):
        b, d = mp.mpf(str(beta)), mp.mpf(str(cosine))
        u, v, w = 2*b-3/b, 3/(b*b)-2, 3-3/(b*b)
        L = mp.atanh(b)/b
        aa, cc = 1-b*b*(1+d)/2, b*b*(1-d)/2
        J = 1/(1-b*b) if d == 1 else mp.atanh(mp.sqrt(cc/aa))/mp.sqrt(aa*cc)
        return float((u*u*d/3+v*v+2*v*w*L+2*u*w*d*(1-L)/b+w*w*J)/8)


def auto_reference(beta, y, *, epsabs, limit):
    beta, y = beta_value(beta), phase(y)
    if not np.isfinite(epsabs) or epsabs <= 0:
        raise ValueError('epsabs must be positive and finite.')
    limit = positive_integer(limit, 'limit')
    if beta == 1:
        return gr_auto_exact(y)/3, 0.
    if beta == 0:
        return .4*np.sin(y/2)**2, 0.
    if y < .1:
        f = lambda x: abs((1+(2*beta*beta-3)*x*x)*transfer(y,1+beta*x))**2
        value, error = quad(f, -1, 1, epsabs=epsabs, limit=limit)
        return value/16, error/16
    weight = lambda x: ((1+(2*beta*beta-3)*x*x)/(1+beta*x))**2
    co, ce = quad(weight, -1, 1, weight='cos', wvar=y*beta, epsabs=epsabs, limit=limit)
    si, se = quad(weight, -1, 1, weight='sin', wvar=y*beta, epsabs=epsabs, limit=limit)
    value = 2*earth_analytic(beta,1)-(np.cos(y)*co-np.sin(y)*si)/8
    return value, (abs(np.cos(y))*ce+abs(np.sin(y))*se)/8


def liang45_literal(beta, cosine, *, nmu, nphi):
    """Literal printed Eq.(45), including sin(xi), for discrepancy auditing only.

    beta_S=3/(4*pi); never used as an oracle or production scalar response.
    """
    beta, cosine = beta_value(beta), cosine_value(cosine)
    nmu, nphi = positive_integer(nmu, 'nmu'), positive_integer(nphi, 'nphi')
    x, wx = _nodes(nmu)
    x = x[:, None]
    cp = np.cos(2*np.pi*(np.arange(nphi)+.5)/nphi)
    st, sx = np.sqrt(1-x*x), np.sqrt(1-cosine*cosine)
    mu_b = x*cosine+st*sx*cp
    first = 2*(-1+beta*beta)*x*x+st*st
    second = 2*(-1+beta*beta)*x*x*cosine*cosine+cosine*cosine*st*st+sx*sx
    second = second+(-6*x*cosine*st*sx+beta*beta*2*x*st*sx)*cp
    second = second+(-sx*sx+x*x*sx*sx-2*st*st*sx*sx+2*beta*beta*st*st*sx*sx)*cp*cp
    integrand = first*second/((1+beta*x)*(1+beta*mu_b))
    return float(np.dot(wx,np.mean(integrand,axis=1))/16)
