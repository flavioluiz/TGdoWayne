# C10 — helicidade zero de Fierz–Pauli: derivação e protótipo

**Estado:** preparação teórica e numérica em `tmp/`. Não há inferência escalar, campanha de injeções, estudo de identificabilidade ou fechamento de C10. Nenhum arquivo versionado foi alterado. O plano exige essas etapas posteriores antes de considerar a extensão concluída.

## 1. Convenções e uma única amplitude física

Mantêm-se as convenções de C05: assinatura `(+---)`, perturbação covariante `g=η+H`, direção `Ω` de propagação, direção `p_a` da Terra para o pulsar, fase `exp[iω(t−β Ω·x)]` em `c=1`. Em SI, `β=ck/ω`, `y_a=ωL_a/c` e `χ=1−β²=(f_g/f)²`. A direção aparente da fonte é `−Ω`; `D_a=1+β μ_a`, com `μ_a=Ω·p_a`. O domínio de ondas viajantes é `0≤β<1` para FP massivo, com `β=0` representando o limiar. A resposta possui um limite formal `β→1`, cujo alcance físico é discutido adiante.

Considere dois vetores espaciais transversais ortonormais e o vetor longitudinal covariante

\[
 u_\mu=(\beta,-\hat\Omega)/\sqrt\chi,
 \qquad u_\mu u^\mu=-1,
 \qquad q^\mu u_\mu=0.
\]

Uma polarização real de helicidade zero, com **norma de Lorentz dois**, é

\[
 E^{(0)}_{\mu\nu}
 =\frac{e^1_\mu e^1_\nu+e^2_\mu e^2_\nu-2u_\mu u_\nu}{\sqrt3}.
\]

Essa escolha coloca o modo na mesma norma de cada tensor real `+` ou `×` de C05, para os quais `e_A:e_B=2δ_AB`. Escrevendo `H=h_0 E^(0)`, suas componentes são

\[
\begin{aligned}
 E^{(0)}_{00}&=-\frac{2\beta^2}{\sqrt3\chi},&
 E^{(0)}_{0i}&=\frac{2\beta\Omega_i}{\sqrt3\chi},\\
 E^{(0)}_{ij}&=\frac1{\sqrt3}
 \left(P_{ij}-\frac{2\Omega_i\Omega_j}{\chi}\right),&
 P_{ij}&=\delta_{ij}-\Omega_i\Omega_j.
\end{aligned}
\]

Satisfazem `q^μ E^(0)_μν=0`, `η^μν E^(0)_μν=0` e `E^(0)_μν E^(0)μν=2`. O teste simbólico verifica as três identidades. Para propagação em `z`, correspondem à parametrização C04 com `D=−2h_0/(√3χ)` e `B=h_0/√3`; há **uma** amplitude escalar `h_0`, não duas amplitudes físicas breathing e longitudinal.

## 2. Fóton e observadores: derivação do numerador observável

O fóton recebido em `t` passa por `x(s)=s p` e `t(s)=t−s`, com `0≤s≤L`. Sua fase no pulsar contém `exp(−iyD)`. Na assinatura adotada, a equação do momento covariante dá a contribuição fracionária

\[
 G_{\rm fóton}
 =\frac{\Delta H_{00}-2p^i\Delta H_{0i}
                    +p^ip^j\Delta H_{ij}}{2D},
 \qquad \Delta H=H_E-H_P.
\]

Ela não é a frequência local completa. A normalização da quatro-velocidade e a equação geodésica, com constantes homogêneas de movimento escolhidas nulas, fornecem

\[
 \delta u^0=-H_{00}/2,
 \qquad \delta u^i=H_{0i}+\beta\Omega_iH_{00}/2.
\]

Como a frequência medida é `u^μp_μ`, os extremos acrescentam

\[
 G_{\rm observadores}
 =p^i\Delta H_{0i}+(\beta\mu-1)\Delta H_{00}/2.
\]

Somar as duas expressões antes de especializar a polarização produz

\[
 \frac{\nu_E-\nu_P}{\nu_P}
 =\frac{p^ip^j\Delta Q_{ij}}{2D},\quad
 Q_{ij}=H_{ij}+\beta\Omega_iH_{0j}
             +\beta\Omega_jH_{0i}+\beta^2\Omega_i\Omega_jH_{00}.
\]

Para a helicidade zero,

\[
 \boxed{\frac{Q_{ij}}{h_0}=\frac{P_{ij}-2\chi\Omega_i\Omega_j}{\sqrt3}},
 \qquad
 p^ip^jQ_{ij}/h_0=\frac{1+(2\beta^2-3)\mu^2}{\sqrt3}.
\]

O teste deriva `Γ^a_00` diretamente das derivadas da métrica, integra as velocidades e simplifica a soma fóton/observadores exatamente. A curvatura calculada por `riemann` de C04 fornece independentemente `Q_ij=2R_0i0j/ω²`. Portanto, a aparição da combinação de marés resulta da derivação da frequência, incluindo os extremos; não é uma substituição assumida de razões de maré por amplitudes independentes.

Definindo `A_β(μ)=1+(2β²−3)μ²`, o núcleo geométrico positivo é

\[
 R_a^{(0)}=\frac{A_\beta(\mu_a)}{2\sqrt3}
             g(y_a,D_a),\qquad
 g(y,D)=\frac{1-e^{-iyD}}D
       =iy e^{-iyD/2}\operatorname{sinc}(yD/2).
\]

O redshift usual `z=(ν_P−ν_E)/ν_P` usa `−R^(0)h_0`; o residual de atraso é `r=∫z dt`. O sinal é o mesmo de C05. O cancelamento de um sinal global na ORF não autoriza esquecer o sinal ao gerar séries temporais. Componentes métricas temporais não foram descartadas; seus termos potencialmente grandes cancelam na combinação correta.

## 3. Relação geométrica e termos cruzados

Em uma base de deformações de norma dois,

\[
 e^b_{ij}=P_{ij},\qquad e^l_{ij}=\sqrt2\Omega_i\Omega_j,
 \qquad Q/h_0=u e^b+v e^l,
\]

com `u=1/√3` e `v=−√(2/3)χ`. A matriz de marés para `Ω=z` é

\[
 R_{0i0j}=\frac{\omega^2h_0}{2\sqrt3}
                    \operatorname{diag}(1,1,-2\chi).
\]

Consequentemente `p_l+χp_b=0` quando `p_b=R_0x0x+R_0y0y` e `p_l=R_0z0z`, como em C04. Contudo, a razão de amplitudes **na base normalizada** é `v/u=−√2χ`. Confundir esses dois quocientes perde fatores de normalização e o significado do vínculo.

Com a definição fixa `Γ_XY^(ab)=(3/8π)∫R_a^X R_b^{Y*}dΩ`, a ORF do único modo é

\[
 \Gamma_0^{ab}=|u|^2\Gamma_{bb}^{ab}+|v|^2\Gamma_{ll}^{ab}
                  +uv^*\Gamma_{bl}^{ab}+vu^*\Gamma_{lb}^{ab}.
\]

Não se troca a soma cruzada por `2 Re` para um par geral: `(Γ_bl^(ab))*=Γ_lb^(ba)`. Distâncias e fases diferentes podem deixar a soma cruzada e a ORF complexas. O teste encontra soma cruzada `−0,0730264+0,00301385 i` no exemplo declarado no JSON. No limiar, para contribuição terrestre e separação de 90°, a combinação física dá `−0,05`, enquanto eliminar os termos cruzados dá `+1/12`. A supressão indevida chega a inverter o sinal nesse exemplo determinístico.

A matriz espectral das duas componentes é proporcional a `(u,v)(u,v)†`, de posto um. Ajustar potências independentes para breathing e longitudinal muda o modelo. Se o setor TT e o escalar forem populações gaussianas independentes, essa é uma hipótese populacional explícita; não decorre da simples contagem de graus de liberdade.

## 4. Normalização de amplitude e potência relativa a TT

Usa-se a mesma convenção espectral por amplitude normalizada de C05:

\[
 \langle\tilde h_0(f,\Omega)\tilde h_0^*(f',\Omega')\rangle
 =\frac{S_0(|f|)}{8\pi}\delta(f-f')\delta^2(\Omega,\Omega').
\]

O espectro unilateral de resíduos de uma população TT mais uma população escalar independente é

\[
 S^r_{ab}(f)=\frac{S_T(f)\Gamma_T^{ab}(f)+S_0(f)\Gamma_0^{ab}(f)}
                         {6\pi^2f^2},\qquad
 h_{c,I}^2(f)=2fS_I(f).
\]

Aqui `S_T` é a potência **por polarização** em dois modos TT equipotentes, enquanto existe um único modo escalar. Assim, equipartição por grau de liberdade corresponde a `S_0=S_T`; igualar a soma das potências dos coeficientes dos dois setores corresponde a `S_0=2S_T`. Nenhuma dessas escolhas é imposta ao protótipo. Na parametrização futura, uma razão `ρ=S_0/S_T` deve ser definida com esse significado, acompanhada de uma hipótese sobre seus espectros.

O tensor canônico de Liang–Trodden tem norma um. A mudança de norma exige `E_0=±√2 ε_0` e `h_0^LT=±√2 h_0`, com sinais globais consistentes com a convenção de perturbação e redshift; portanto `S_0^LT=2S_0`. No cálculo de ORF, seu coeficiente fixo `β_S=3/(4π)` compensa a meia norma quadrática e reproduz nossa normalização `3/(8π)`. `β_S` não é a velocidade `β`.

Não se normaliza a diagonal da ORF a um para cada massa. Tampouco se impõe norma dois à matriz **observável** `Q/h_0`, cuja norma euclidiana é `(2+4χ²)/3`: fazê-lo redefiniria a amplitude e sua priori de modo dependente da massa. A amplitude escalar de população, a normalização do tensor e a eficiência de emissão da fonte são objetos diferentes. Não foi derivado espectro de fontes, densidade de energia, equipartição ou mecanismo de screening.

## 5. Confronto específico com as fontes primárias

A referência [Liang–Trodden, arXiv:2108.05344v3](https://arxiv.org/pdf/2108.05344v3) foi conferida nas Eqs.(1)–(4), (17)–(22), (45) e (47), incluindo inspeção visual da página PDF 18. A Eq.(22) confirma que a resposta com componentes temporais necessita dos observadores. A definição de `ξ` é a separação dos pulsares, com `p_a=z`, `p_b=(sinξ,0,cosξ)` e `μ_b=cosθ cosξ+sinθ sinξ cosφ`.

Há uma **discrepância algébrica na expansão impressa da Eq.(45)**. Seu primeiro fator é `A_β(cosθ)` e os termos constantes/quadráticos do segundo correspondem a `A_β(μ_b)`. O termo linear impresso contém `β² sin(2θ) sinξ cosφ`; o produto compacto exige `β² sin(2θ) sin(2ξ) cosφ`. Escrevendo `x=cosθ`, `d=cosξ`, a diferença entre os segundos fatores é

\[
 B_{\rm impresso}-A_\beta(\mu_b)
 =2\beta^2x\sqrt{1-x^2}\sqrt{1-d^2}(1-2d)\cos\varphi.
\]

Essa identidade é verificada simbolicamente. Numericamente, em `β=0,9` e `ξ=π/2`, a integral literal resulta em `0,03162078965`, enquanto a construção por `Q`, a série harmônica e uma expressão independente de momentos dão `0,02036600386`. A diferença é `0,01125478579`. O desvio desaparece em `β=0`, coincidência/antípodas e `cosξ=1/2`; por isso esses casos isolados não bastam como auditoria. Não se afirma que exista uma errata formal nem se atribui impacto inferencial a essa diferença. A Eq.(46) não foi usada como oráculo. A Eq.(47), no limiar, coincide com o resultado independente abaixo.

O capítulo C05 atual cita o tratamento preparatório de observadores e a normalização TT; não encontrei nele uma afirmação de reprodução da Eq.(45) que necessite de correção imediata.

[Bernardo–Ng, arXiv:2306.13593v4](https://arxiv.org/pdf/2306.13593v4), página PDF 2 e suplemento na página PDF 8, usam para o escalar de uma teoria escalar-tensorial uma combinação `ST+χ SL/√2` em base ortonormal. O setor FP aqui obtido usa `ST−√2χ SL` na mesma convenção de norma das bases. O sinal e a razão diferem: no limiar a primeira combinação é isotrópica, enquanto a de FP é sem traço e quadrupolar. O cancelamento dos multipolos superiores que eles derivam para seu escalar não pode ser transplantado para esta helicidade zero. Não foi copiado código de PTAfast nem de quaisquer autores.

## 6. Duas integrações independentes da ORF finita

Com a normalização definida,

\[
 \Gamma_0^{ab}=\frac1{32\pi}\int d\Omega\,
 A_\beta(\mu_a)A_\beta(\mu_b)
                  g(y_a,D_a)g^*(y_b,D_b).
\]

A primeira rota usa um único céu global, constrói explicitamente `P_ij`, `Ω_iΩ_j` e `Q_ij`, contrai com vetores de pulsares gerais e avalia a fase por `expm1`. Usa Gauss–Legendre e trapézios periódicos, em blocos de azimute. Não depende das coordenadas especiais de um par, permitindo verificar rotação global e positividade da matriz de Gram.

A segunda usa o polinômio compacto e a transferência `sinc` de C05. Define

\[
 c_\ell^{(0)}(\beta,y)=\int_{-1}^1
       A_\beta(x)g(y,1+\beta x)P_\ell(x)\,dx,
\]

e obtém, pela ortogonalidade e pelo teorema de adição,

\[
 \boxed{\Gamma_0^{ab}=\frac1{32}\sum_{\ell=0}^{\infty}(2\ell+1)
 c_\ell^{(0)}(\beta,y_a)c_\ell^{(0)*}(\beta,y_b)P_\ell(d)}.
\]

Ao contrário do setor TT, a soma começa em `ℓ=0`. O produto preserva as distâncias diferentes. Um corte comum produz uma matriz de Gram positiva semidefinida; um corte escolhido separadamente para cada par não possui automaticamente essa garantia. O protótipo exige resoluções explícitas e registra separadamente refinamentos dos nós, do corte harmônico e da quadratura direta.

Uma terceira referência terrestre vem de divisão polinomial. Para `0<β<1`, escreva

\[
 \frac{A_\beta(x)}{1+\beta x}=ux+v+\frac{w}{1+\beta x},
 \quad u=2\beta-3/\beta,\ v=3/\beta^2-2,\ w=3-3/\beta^2.
\]

Com `L=atanhβ/β`, `a=1−β²(1+d)/2`, `c=β²(1−d)/2`,

\[
 J=\left\langle\frac1{D_aD_b}\right\rangle_\Omega
 =\frac{\operatorname{atanh}\sqrt{c/a}}{\sqrt{ac}},
 \qquad J(d=1)=\frac1{1-\beta^2}.
\]

A expressão de `J` segue de `1/(D_aD_b)=∫_0^1dt/[tD_a+(1−t)D_b]^2` e da média angular, reduzindo-se a uma integral racional. Os momentos `⟨μ_aμ_b⟩=d/3`, `⟨1/D⟩=L` e `⟨μ_a/D_b⟩=d(1−L)/β` fornecem

\[
 \Gamma_0^{EE}=\frac18\left[\frac{u^2d}{3}+v^2+2vwL
                  +\frac{2uwd(1-L)}\beta+w^2J\right].
\]

O protótipo avalia essa forma com precisão arbitrária para controlar cancelamentos. Os extremos recebem expressões próprias; a integral e a série finitas permanecem as rotas principais quando os termos dos pulsares são necessários.

## 7. Limites e ordem de aproximações

No limiar, `A_0=−2P_2` e apenas `c_2=−4(1−e^(−iy))/5` sobrevive. Portanto,

\[
 \Gamma_0^{EE}(0,d)=\frac{P_2(d)}{10},\qquad
 \Gamma_0(0,d;y_a,y_b)=
 \frac{(1-e^{-iy_a})(1-e^{iy_b})P_2(d)}{10},
\]

e `Γ_aa=(2/5)sin²(y/2)`. Isso coincide com a Eq.(47) de Liang–Trodden após fixar `β_S=3/(4π)`. É metade da ORF TT no mesmo limiar, coerente com uma polarização canônica em lugar de duas.

Em `k=0` não existe uma direção privilegiada de propagação. O rótulo helicidade zero nesse extremo é entendido como limite de uma família com eixo escolhido, seguido da média de orientações postulada para a população. A proporcionalidade `Γ_0=Γ_T/2` mostra uma degenerescência algébrica exata entre as duas potências nesse extremo: a covariância depende de `S_T+S_0/2`. Esse fato não é um teste estatístico de identificabilidade em uma banda inteira.

Para `β→1`, o limite da **resposta** é breathing de amplitude `1/√3`:

\[
 \Gamma_0^{EE}(1,d)=\frac{3+d}{24},\qquad
 \Gamma_{0,aa}(1,y)=\frac13\left\{1-\frac3{2y^2}
             \left[1-\frac{\sin2y}{2y}\right]\right\}.
\]

A métrica canônica diverge como `h_0/χ`; o cálculo linear exige amplitudes suficientemente pequenas, em particular `|h_0|/χ≪1` nessa parametrização. O limite observável não prova que FP com fontes e amplitude fixa se reduza a RG. A função que constrói o tensor métrico rejeita `β=1`; as funções de resposta permitem esse extremo apenas como continuidade formal documentada.

Para fases pequenas,

\[
 \Gamma_0^{ab}\sim\frac{y_ay_b}{8}
 \left[\left(\frac{2\beta^2}{3}\right)^2
       +\frac15\left(\frac{4\beta^2-6}{3}\right)^2P_2(d)\right],
\]

e `Γ_aa/y²→(3β⁴−4β²+3)/30`. Para `y→∞` a `0<β<1` fixo, a auto tende a `2Γ_0^EE(β,1)`. No entanto, esse limite não é uniforme em `β`: em `β=0` a auto continua oscilando. A supressão dos termos dos pulsares depende de `βy` e de `β|y_a p_a−y_b p_b|`, não apenas de `fL/c` grande. Médias em distância e frequência precisam ser especificadas antes de substituir a resposta finita por uma contribuição incoerente.

## 8. Evidências, comandos e trabalho restante

`scalar_fp.py` contém o protótipo; `test_scalar_fp.py` executa nove testes, incluindo provas simbólicas, dois métodos finitos, referência terrestre independente, observadores, norma, vínculo, termos cruzados, rotação, positividade, coincidência e limites. Os nove passaram. A bateria pequena encontrou diferenças máximas de `1,02e-13` entre as integrações finitas, `1,41e-13` entre três rotas terrestres e `7,88e-15` sob rotação global. Esses números se referem aos pontos e resoluções declarados no código.

```sh
.venv/bin/python tmp/c10_scalar/test_scalar_fp.py
.venv/bin/python tmp/c10_scalar/benchmark_scalar.py
```

Os registros são `test_results.json` e `benchmark_results.json`. A campanha adicional de nove casos **passou**, incluindo fases até `2π·1000,125+1`, com refinamento separado e tolerâncias absoluta `1e-5` e relativa `1e-3`. Durou 68,03 s; os maiores erros absoluto e relativo entre os controles foram `1,776e-12` e `5,739e-12`. O maior caso individual custou 35,46 s. Esses tempos incluem construção de matrizes `Q` em um céu global e dependem do cache de nós aquecido na ordem da execução. O método foi escolhido também como validação independente; não constitui uma implementação otimizada para inferência. A precisão desse conjunto discreto não certifica a faixa contínua nem o custo de uma PTA inteira.

Para integrar C10 ainda faltam: API com orçamento e relatório equivalentes a C05; configuração de potência escalar e hipótese de fonte; injeções puramente TT e mistas; falsos positivos e recuperação; testes de degenerescências e de identificabilidade; subconjunto A0/A/B/C com covariância; avaliação do limite de validade linear; capítulo e release. Zerando `S_0`, o modelo misto recupera exatamente o setor tensorial. Fazer apenas `β→1` não elimina uma população escalar postulada. Nenhuma dessas etapas inferenciais foi executada nesta preparação.
