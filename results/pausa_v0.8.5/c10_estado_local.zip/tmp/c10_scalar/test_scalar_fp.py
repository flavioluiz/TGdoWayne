"""Symbolic physical derivation and independent finite-ORF tests for the C10 prototype."""
import json
from pathlib import Path
import unittest

import numpy as np
import sympy as s

import scalar_fp as target
from polarizacoes.foundations import riemann
from pta.orf import raw_harmonic_orf as tt_harmonic

METRICS = {}


def zero(value):
    if isinstance(value, s.MatrixBase):
        return all(s.simplify(item) == 0 for item in value)
    return s.simplify(value) == 0


class SymbolicScalar(unittest.TestCase):
    def setUp(self):
        self.b, self.mu = s.symbols('beta mu', real=True)
        b = self.b
        self.eta = s.diag(1, -1, -1, -1)
        self.q = s.Matrix([1, 0, 0, -b])
        self.h = s.Matrix([[-2*b*b, 0, 0, 2*b],
                           [0, 1-b*b, 0, 0], [0, 0, 1-b*b, 0],
                           [2*b, 0, 0, -2]])/(s.sqrt(3)*(1-b*b))

    def test_fp_constraints_canonical_norm_and_linked_curvature(self):
        b, h = self.b, self.h
        self.assertTrue(zero(h*self.eta*self.q))
        self.assertTrue(zero(s.trace(self.eta*h)))
        self.assertTrue(zero(s.trace(self.eta*h*self.eta*h)-2))
        r = riemann(h, self.q)
        e = s.Matrix(3,3,lambda i,j:r[0,i+1,0,j+1])
        expected = s.diag(1,1,-2*(1-b*b))/(2*s.sqrt(3))
        self.assertTrue(zero(e-expected))
        self.assertTrue(zero(e[2,2]+(1-b*b)*(e[0,0]+e[1,1])))
        METRICS['symbolic_polarization'] = str(h)
        METRICS['symbolic_tidal'] = str(expected)

    def test_timelike_geodesic_and_complete_frequency_gain(self):
        b, mu, h = self.b, self.mu, self.h
        # Compute Christoffel a00 from derivatives of the full metric, then integrate.
        gamma = s.Matrix([sum(self.eta[a,r]*s.I*(self.q[0]*h[0,r]-self.q[r]*h[0,0]/2)
                                      for r in range(4)) for a in range(4)])
        velocity = -gamma/s.I
        expected_velocity = s.Matrix([-h[0,0]/2,0,0,h[0,3]+b*h[0,0]/2])
        self.assertTrue(zero(velocity-expected_velocity))
        photon = (h[0,0]-2*mu*h[0,3]+(1-mu*mu)*h[1,1]+mu*mu*h[3,3])/(2*(1+b*mu))
        observers = -h[0,0]/2+mu*velocity[3]
        expected = (1+(2*b*b-3)*mu*mu)/(2*s.sqrt(3)*(1+b*mu))
        self.assertTrue(zero(photon+observers-expected))
        # Omitting the endpoints is detectably different even before forming an ORF.
        self.assertFalse(zero(photon-expected))
        METRICS['symbolic_receiving_gain'] = str(expected)

    def test_liang45_printed_cross_term_is_not_the_compact_product(self):
        b, x, d, cp = s.symbols('beta x d cosphi', real=True)
        st, sx = s.sqrt(1-x*x), s.sqrt(1-d*d)
        mu_b = x*d+st*sx*cp
        printed = 2*(b*b-1)*x*x*d*d+d*d*st*st+sx*sx
        printed += (-6*x*d*st*sx+2*b*b*x*st*sx)*cp
        printed += (-sx*sx+x*x*sx*sx-2*st*st*sx*sx+2*b*b*st*st*sx*sx)*cp*cp
        compact = 1+(2*b*b-3)*mu_b*mu_b
        difference = 2*b*b*x*st*sx*(1-2*d)*cp
        self.assertTrue(zero(printed-compact-difference))
        self.assertTrue(zero((printed-compact).subs(d,s.Rational(1,2))))
        self.assertTrue(zero((printed-compact).subs(b,0)))
        self.assertTrue(zero(printed-difference-compact))
        METRICS['liang45_literal_minus_compact_second_factor'] = str(difference)


class NumericalScalar(unittest.TestCase):
    def test_two_quadratures_finite_and_unequal_phases(self):
        maximum = 0.
        for b in [0,.2,.9,1]:
            for d in [-1,0,.99,1]:
                for ya,yb in [(2,3),(50,51)]:
                    direct = target.raw_direct_orf(b,d,ya,yb,nmu=160,nphi=320)
                    harmonic = target.raw_harmonic_orf(b,d,ya,yb,lmax=140,nmu=320)[0]
                    error = abs(direct-harmonic)
                    maximum = max(maximum,error)
                    self.assertLess(error,1e-10,(b,d,ya,yb))
        METRICS['max_finite_direct_harmonic'] = maximum

    def test_earth_three_routes_and_literal_discrepancy(self):
        maximum = 0.
        for b in [1e-8,.2,.9,.999,1]:
            for d in [-1,0,.5,1]:
                exact = target.earth_analytic(b,d)
                direct = target.raw_direct_orf(b,d,nmu=360,nphi=720)
                harmonic = target.raw_harmonic_orf(b,d,lmax=500,nmu=1200)[0]
                error = max(abs(direct-exact),abs(harmonic-exact))
                maximum = max(maximum,error)
                self.assertLess(error,1e-7,(b,d))
        literal = target.liang45_literal(.9,0,nmu=360,nphi=720)
        compact = target.earth_analytic(.9,0)
        self.assertGreater(abs(literal-compact),.01)
        self.assertLess(abs(target.liang45_literal(.9,.5,nmu=360,nphi=720)
                            -target.earth_analytic(.9,.5)),1e-10)
        METRICS['max_earth_three_routes'] = maximum
        METRICS['liang45_example'] = {'beta':.9,'cosine':0,'literal':literal,
            'compact':compact,'difference':literal-compact,'relative_to_compact':(literal-compact)/compact}

    def test_threshold_normalization_and_single_mode_cross_terms(self):
        y = 27.1
        for d in [-1,0,.5,1]:
            expected = (1-np.exp(-1j*y))*(1-np.exp(1j*(y+1)))*(3*d*d-1)/20
            calculated = target.raw_harmonic_orf(0,d,y,y+1,lmax=20,nmu=60)[0]
            self.assertLess(abs(calculated-expected),1e-12)
            tt = tt_harmonic(0,d,y,y+1,lmax=20,nmu=60)[0]
            self.assertLess(abs(calculated-tt/2),1e-12)
        pulsars=np.array([[0.,0.,1.],[1.,0.,0.]])
        blocks=target.raw_sky_gram(0,pulsars,None,nmu=80,nphi=160,components=True)
        coeff=np.array([1/np.sqrt(3),-np.sqrt(2/3)])
        full=np.einsum('s,asbt,t->ab',coeff,blocks,coeff)
        omitted=coeff[0]**2*blocks[0,0,1,0]+coeff[1]**2*blocks[0,1,1,1]
        self.assertLess(abs(full[0,1]+.05),1e-12)
        self.assertLess(abs(omitted-1/12),1e-12)
        METRICS['threshold_cross_term_example']={'linked':float(full[0,1].real),
            'cross_terms_omitted':float(omitted.real)}

    def test_linked_cross_terms_remain_complex_for_distinct_pulsars(self):
        pulsars=np.array([[0.,0.,1.],[.6,0.,.8]])
        beta=.8
        coeff=np.array([1/np.sqrt(3),-np.sqrt(2/3)*(1-beta*beta)])
        blocks=target.raw_sky_gram(beta,pulsars,[20,21.3],nmu=120,nphi=240,components=True)
        linked=np.einsum('s,asbt,t->ab',coeff,blocks,coeff)
        direct=target.raw_sky_gram(beta,pulsars,[20,21.3],nmu=120,nphi=240)
        self.assertLess(np.max(abs(linked-direct)),1e-12)
        cross=coeff[0]*coeff[1]*(blocks[0,0,1,1]+blocks[0,1,1,0])
        self.assertGreater(abs(cross.imag),1e-4)
        self.assertLess(abs(blocks[0,0,1,1].conjugate()-blocks[1,1,0,0]),1e-13)
        METRICS['complex_linked_cross_terms']={'real':float(cross.real),'imag':float(cross.imag)}

    def test_rotation_reciprocity_positive_matrix_and_coincidence(self):
        pulsars=np.array([[0,0,1],[1e-7,0,1],[0,0,-1],[1,2,3],[-2,1,.3]],float)
        pulsars/=np.linalg.norm(pulsars,axis=1)[:,None]
        phases=np.array([19,19.7,31,50,77])
        rotation,_=np.linalg.qr(np.array([[1,2,-1],[3,.2,4],[-2,1,1.]],float))
        maximum=0.
        for beta in [0,.9,1]:
            gram=target.raw_sky_gram(beta,pulsars,phases,nmu=120,nphi=240)
            rotated=target.raw_sky_gram(beta,pulsars@rotation.T,phases,nmu=120,nphi=240)
            maximum=max(maximum,float(np.max(abs(gram-rotated))))
            self.assertLess(np.max(abs(gram-rotated)),1e-11)
            self.assertLess(np.max(abs(gram-gram.T.conj())),1e-13)
            self.assertGreaterEqual(np.linalg.eigvalsh(gram).min(),-1e-13)
            self.assertGreater(abs(gram[0,1].imag),1e-4)
            coincident=target.raw_sky_gram(beta,np.array([[0,0,1],[0,0,1.]]),[20,20],nmu=120,nphi=240)
            self.assertLess(abs(coincident[0,0]-coincident[0,1]),1e-13)
        METRICS['max_global_rotation_error']=maximum

    def test_auto_reference_small_phase_and_beta1_observable_limit(self):
        maximum=0.
        for beta in [0,.2,.9,1]:
            for y in [1e-4,2,30,200]:
                reference,error=target.auto_reference(beta,y,epsabs=1e-13,limit=300)
                harmonic=target.raw_harmonic_orf(beta,1,y,y,lmax=300,nmu=650)[0]
                maximum=max(maximum,abs(reference-harmonic))
                self.assertLess(abs(reference-harmonic),max(1e-10,10*error))
            y=1e-4
            small=target.auto_reference(beta,y,epsabs=1e-18,limit=300)[0]/(y*y)
            self.assertLess(abs(small-(3*beta**4-4*beta*beta+3)/30),1e-8)
        with self.assertRaises(ValueError):
            target.metric_polarization(1,np.array([0.,0.,1.]))
        for d in [-1,0,1]:
            self.assertEqual(target.earth_analytic(1,d),(3+d)/24)
        METRICS['max_auto_reference_error']=maximum


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    data={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests_run':result.testsRun,
          'metrics':METRICS,'numpy':np.__version__,'sympy':s.__version__}
    Path(__file__).with_name('test_results.json').write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
