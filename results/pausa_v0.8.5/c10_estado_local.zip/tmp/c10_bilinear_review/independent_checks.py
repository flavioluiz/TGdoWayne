"""Independent synthetic audit of the archived C10 bilinear v2 implementation."""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import time
import warnings

import numpy as np
from scipy.integrate import quad

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "review_sources" / "bilinear.py"
spec = importlib.util.spec_from_file_location("bilinear_audited", SOURCE)
module = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = module
spec.loader.exec_module(module)
BilinearPosterior = module.BilinearPosterior
LinearMarginal = module.LinearMarginal


def log_values(value):
    with np.errstate(divide="ignore"):
        return np.log(value)


def one_cell_oracle(corners, threshold):
    """Integrate after sorting vertical endpoint heights, without signed q cases."""
    f00, f01 = corners[0]
    f10, f11 = corners[1]
    cuts = [0., 1.]
    for intercept, slope in [(f00-threshold, f10-f00),
                             (f01-threshold, f11-f01),
                             (f00-f01, f10-f00-f11+f01)]:
        if slope != 0:
            root = -intercept/slope
            if 0 < root < 1:
                cuts.append(root)

    def integrand(t):
        lo, hi = sorted(((1-t)*f00+t*f10, (1-t)*f01+t*f11))
        if threshold < lo:
            return 0.
        if threshold >= hi:
            return (lo+hi)/2
        return (threshold-lo)*(threshold+lo)/(2*(hi-lo))

    cuts = sorted(set(cuts))
    value = sum(quad(integrand, a, b, epsabs=1e-12, epsrel=1e-12)[0]
                for a, b in zip(cuts[:-1], cuts[1:]))
    return value / np.mean(corners)


def main():
    start = time.process_time()
    checks = []
    def record(name, actual, expected, tolerance):
        error = abs(float(actual)-float(expected))
        checks.append(dict(name=name, actual=float(actual), expected=float(expected),
                           absolute_error=error, tolerance=tolerance, passed=error <= tolerance))

    # L=x and L=xy contain genuinely zero nodes, including p=0 and q=0 slices.
    for kind in ["x", "xy"]:
        x = np.array([0., .17, .63, 1.])
        y = np.array([0., .11, .78, 1.])
        values = x[:, None]*np.ones_like(y) if kind == "x" else x[:, None]*y
        post = BilinearPosterior(x, y, log_values(values))
        record(kind+" evidence", post.log_evidence, math.log(.5 if kind == "x" else .25), 2e-14)
        for t in [.0001, .03, .25, .5, .9, .999999]:
            expected = t*t if kind == "x" else t*t*(1-2*math.log(t))
            result = post.log_likelihood_cdf(math.log(t))
            tolerance = max(2e-12, result.quadrature_absolute_error_estimate + result.small_interval_mass_bound)
            record(f"{kind} contour {t}", result.probability, expected, tolerance)
        for p in [.0001, .05, .5, .95]:
            record(f"{kind} qx {p}", post.marginal_x.quantile(p), math.sqrt(p), 2e-13)

    # Positive bilinear polynomial on a nonunit, nonzero-origin rectangle.
    x = np.array([-2., -.8, .1, 1.])
    y = np.array([3., 3.7, 4.6, 5.])
    values = 10+.2*x[:, None]+.3*y+.04*x[:, None]*y
    expected_joint = 10+.2*(-.5)+.3*4+.04*(-.5)*4
    expected_h0 = 10+.2*(-.5)+.3*3+.04*(-.5)*3
    expected_h1 = 10+.2*(-.5)+.3*5+.04*(-.5)*5
    post = BilinearPosterior(x, y, np.log(values))
    record("proper joint prior volume", post.log_evidence, math.log(expected_joint), 2e-14)
    record("lower boundary proper prior", post.boundary_log_evidence(0), math.log(expected_h0), 2e-14)
    record("upper boundary proper prior", post.boundary_log_evidence(-1), math.log(expected_h1), 2e-14)
    record("BF joint to lower boundary", post.log_evidence-post.boundary_log_evidence(),
           math.log(expected_joint/expected_h0), 2e-14)

    # A full constant patch carries an atom in the logL distribution.
    values = np.array([[1., 1.], [1., 1.], [3., 3.]])
    post = BilinearPosterior([0, 1, 2], [0, 1], np.log(values))
    record("logL atom right CDF", post.log_likelihood_cdf(0.).probability, 1/3, 2e-13)
    record("below logL atom", post.log_likelihood_cdf(-1e-10).probability, 0., 2e-13)

    # A different algebraic integrand, transposition and reflections check signs.
    rng = np.random.default_rng(910110701)
    max_oracle = max_transpose = max_reflection = 0.
    for i in range(24):
        corners = np.exp(rng.uniform(-6., 3., (2, 2)))
        t = float(rng.uniform(corners.min(), corners.max()))
        result = BilinearPosterior([0, 1], [0, 1], np.log(corners)).log_likelihood_cdf(math.log(t))
        oracle = one_cell_oracle(corners, t)
        transpose = BilinearPosterior([0, 1], [0, 1], np.log(corners.T)).log_likelihood_cdf(math.log(t)).probability
        reflection = BilinearPosterior([0, 1], [0, 1], np.log(corners[::-1])).log_likelihood_cdf(math.log(t)).probability
        max_oracle = max(max_oracle, abs(result.probability-oracle))
        max_transpose = max(max_transpose, abs(result.probability-transpose))
        max_reflection = max(max_reflection, abs(result.probability-reflection))
    record("24 endpoint-sorted oracle comparisons", max_oracle, 0., 2e-11)
    record("24 transpose comparisons", max_transpose, 0., 2e-11)
    record("24 reflected comparisons", max_reflection, 0., 2e-11)

    defects = []
    m = LinearMarginal([0., 1., 2.], [1., 0., 0.])
    defects.append(dict(id="F1", name="p=1 trailing plateau", observed=m.quantile(1), expected=1., reproduced=m.quantile(1)!=1.))
    m = LinearMarginal([0., 1e-20], [1., 1.])
    q = m.quantile(.5)
    defects.append(dict(id="F2", name="absolute coordinate stopping tolerance", observed=q, cdf=m.cdf(q), expected=5e-21, reproduced=m.cdf(q)!=.5))
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        m = LinearMarginal([0., 1.], [1e308, 1e308])
        defects.append(dict(id="F3", name="nonfinite total accepted", observed_total=str(m.total), cdf=m.cdf(.5),
                            expected="reject nonfinite intermediates", reproduced=not np.isfinite(m.total), warnings=[str(w.message) for w in caught]))
    post = BilinearPosterior([0, 1], [0, 1], [[-1000., 0.], [-1000., 0.]])
    try:
        observed = post.boundary_log_evidence()
    except ValueError as exc:
        observed = type(exc).__name__+": "+str(exc)
    defects.append(dict(id="F4", name="boundary needs its own likelihood scale", observed=observed, expected=-1000.,
                        reproduced=isinstance(observed, str)))

    report = dict(status="INDEPENDENT_SYNTHETIC_REVIEW_WITH_FOUR_FINDINGS_NOT_PHYSICAL_C10_APPROVAL",
                  scope="Archived bilinear v2 only; zero PTA likelihood or ORF evaluations",
                  seed=910110701, cpu_seconds=time.process_time()-start,
                  source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                  script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  analytic_checks_passed=sum(c["passed"] for c in checks), analytic_checks=len(checks),
                  checks=checks, defects=defects)
    (HERE/"independent_results.json").write_text(json.dumps(report, indent=2, allow_nan=False)+"\n")
    print(json.dumps({k:report[k] for k in ["status", "cpu_seconds", "analytic_checks_passed", "analytic_checks"]}))
    if not all(c["passed"] for c in checks):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
