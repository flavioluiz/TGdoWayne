# Revisão independente do núcleo bilinear C10

Revisão de leitura e controles sintéticos da versão cujo SHA256 é
`f3d0046f5b97fabf723c99b209158b3ad43575ce5b83f484e20f7187498410a3`.
Os quatro arquivos consultados foram preservados em `review_sources/`, com
inventário em `source_snapshot.json`. Nenhum arquivo do pacote original foi
alterado. O responsável foi informado das quatro questões abaixo e anunciou
correções prospectivas em v3; este parecer e os resultados permanecem sobre v2.

## Resultado matemático

A integral de uma célula bilinear é a área vezes a média dos quatro vértices.
Por isso, integrar a interpolação em uma coordenada produz exatamente uma
marginal linear por partes na outra. Dividir pela área total da priori produz
a evidência para uma priori uniforme própria; a borda requer somente o
comprimento da sua própria priori. O quociente das evidências comparáveis dá
BF10, sem reutilizar o volume bidimensional na hipótese da borda.

Em uma fatia vertical, os valores extremos da função afim determinam a parte
que satisfaz L≤t. A expressão assinada em `vertical` tem os sinais corretos
para ambos os sentidos da inclinação e para q=0. As três famílias de raízes
usadas para segmentar a quadratura correspondem às mudanças necessárias de
ramo. A omissão de um painel não negativo é limitada por sua área vezes o
máximo dos vértices; a soma normalizada desses limites é separada da estimativa
Gauss–Kronrod. Esta última continua sendo uma estimativa numérica, não um limite
rigoroso de todos os erros de ponto flutuante.

Passaram **31 controles adicionais**, em **0,0483 s de CPU**, incluindo:

- L=x e L=xy, com nós nulos, marginais analíticas e CDFs de logL t² e
  t²(1−2 log t), respectivamente;
- priori sobre retângulo não unitário de origem não nula, ambas as bordas e
  BF analítico;
- patamar bidimensional de L constante, cuja massa gera um átomo na CDF;
- 24 células aleatórias, semente 910110701, comparadas com uma expressão
  independente que ordena os valores das pontas da fatia e integra
  `(t−Lmin)(t+Lmin)/(2(Lmax−Lmin))` quando o corte é parcial;
- as mesmas 24 células transpostas e refletidas, verificando a orientação
  dos termos e o tratamento de inclinações negativas.

Detalhes, erros e tolerâncias estão em `independent_results.json`; o script
`independent_checks.py` reproduz os controles usando somente a cópia v2.

## Quatro problemas reproduzíveis

1. **Inversa esquerda em p=1.** `LinearMarginal([0,1,2],[1,0,0]).quantile(1)`
   devolve 2, embora F já seja 1 em x=1. Isso contradiz o contrato de inversa
   esquerda incluindo patamares. A convenção explícita p=0 no primeiro nó do
   domínio pode ser mantida; p=1 deve procurar o primeiro ponto que atinge a
   massa total.
2. **Tolerância do quantil depende das unidades.** Para a uniforme em
   [0,10⁻²⁰], `quantile(.5)` devolve 10⁻²⁰ e F(q)=1. O `xtol=10⁻¹⁴` absoluto
   já excede todo o intervalo. Resolver na coordenada local [0,1] e depois
   converter evita esse defeito; coordenadas enormes ainda estão limitadas
   pela representabilidade do resultado, o que não deve ser confundido com
   uma garantia absoluta de inversão.
3. **Intermediários infinitos são aceitos.** Com eixo [0,1] e valores
   [10³⁰⁸,10³⁰⁸], a soma dos vértices transborda e `total=inf` é aceito porque
   o único teste é `total>0`; `cdf(.5)` então devolve 0. Também uma diferença
   de extremos finitos pode transbordar. Áreas, prefixos, extensões, volumes
   e massas devem ser positivos/finitos quando requeridos. Isso é uma falha
   explícita preferível a um resultado probabilístico silenciosamente errado.
4. **A borda precisa de escala própria.** Para logs `[[-1000,0],[-1000,0]]`,
   H0 na primeira borda tem logZ=−1000, perfeitamente representável. Escalá-la
   pelo máximo global a zera e `boundary_log_evidence` lança `Zero mass
   marginal`. Preservar os logs nodais e calcular uma escala própria da borda
   resolve esse caso. Uma borda verdadeiramente toda −inf é outra situação e
   deve ter contrato explícito de evidência zero ou rejeição deliberada.

Os exemplos 2–3 não mostram falha no intervalo físico atual u/ε; mostram que
a API genérica e sua alegação de invariância de coordenadas eram mais amplas
que a implementação. O exemplo 4 pode afetar comparação de hipóteses com
evidências muito diferentes e precisa ser resolvido antes de interpretar BF.

## Limite da aprovação

Nenhuma ORF, dado PTA, likelihood física, posterior física ou campanha foi
avaliada nesta auditoria. Os 31 controles sustentam o núcleo de integração da
**aproximação bilinear** nos casos testados, com as quatro pendências acima.
Não estabelecem precisão da interpolação da likelihood física, convergência
global do contorno, SBC ou falsos positivos. Os nove testes próprios do autor
e a falha histórica da sela permanecem registros separados.
