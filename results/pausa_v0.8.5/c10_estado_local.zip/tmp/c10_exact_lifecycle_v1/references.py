"""Independent SciPy laws/direct traces and positive nodal posterior summaries."""
import math
import numpy as np
from scipy.stats import multivariate_normal
from scipy.special import logsumexp
from bilinear_reference import BilinearPosterior


def product_log_evidence(log_grid,log_boundary,u_weights,epsilon_weights):
    """Positive independent product rule with already normalized frozen weights."""
    a=np.asarray(log_grid);b=np.asarray(log_boundary);w=np.asarray(u_weights);v=np.asarray(epsilon_weights)
    if a.shape!=(len(w),len(v)) or b.shape!=w.shape or any(not np.isfinite(x).all() for x in (a,b,w,v)) or np.any(w<=0) or np.any(v<=0):raise ValueError('Finite product values and positive weights required')
    if abs(float(w.sum())-1)>1e-13 or abs(float(v.sum())-1)>1e-13:raise ValueError('Prior weights must already integrate one')
    return float(logsumexp(a+np.log(w)[:,None]+np.log(v)[None])),float(logsumexp(b+np.log(w)))


def independent_values(C0,C1,epsilon,engine,models):
    C=C0+epsilon*C1;H=engine.H;mu=[];sigma=[]
    for c in C:
        mu.append(np.array([np.trace(h@c).real for h in H]))
        sigma.append(np.array([[np.trace(h@c@j@c).real for j in H] for h in H]))
    mu=np.array(mu);sigma=np.array(sigma)
    mb=np.einsum('kd,k->d',mu,engine.w);sb=np.einsum('kij,k->ij',sigma,engine.w**2)
    result=[]
    for name in models:
        vals=[]
        for r in range(engine.R):
            if name=='A0_CN':
                value=0.
                for k,c in enumerate(C):
                    v=np.r_[engine.q[r,k].real,engine.q[r,k].imag]
                    real=.5*np.block([[c.real,-c.imag],[c.imag,c.real]])
                    value+=multivariate_normal.logpdf(v,mean=np.zeros(len(v)),cov=real)
            else:
                data=engine.gaussian if name.endswith('_G') else engine.physical
                if name.startswith('B_'):
                    v=np.einsum('kd,k->d',data[r],engine.w)
                    value=multivariate_normal.logpdf(v,mean=mb,cov=sb)
                else:value=sum(multivariate_normal.logpdf(data[r,k],mean=mu[k],cov=sigma[k]) for k in range(engine.K))
            vals.append(value)
        result.append(vals)
    out=np.array(result)
    if not np.isfinite(out).all():raise ArithmeticError('Independent SciPy law is nonfinite')
    return out


def summary(mass,epsilon,logs,truth,truth_logl):
    posterior=BilinearPosterior(mass,epsilon,logs)
    point_quantiles=[[m.quantile(p) for p in (.05,.5,.9,.95)] for m in (posterior.marginal_x,posterior.marginal_y)]
    event=posterior.log_likelihood_cdf(float(truth_logl))
    # Only omitted underflow of this interpolant's finite nodal values. No
    # unsampled physical mass or quadrature error is silently bounded by it.
    log_omit=math.log(np.nextafter(0.,1.))-math.log(posterior.integral/posterior.volume)
    return {'logZ_H1':posterior.log_evidence,'logZ_H0':posterior.boundary_log_evidence(),
            'logBF':posterior.log_evidence-posterior.boundary_log_evidence(),
            'parameter_CDF':[posterior.marginal_x.cdf(truth[0]),posterior.marginal_y.cdf(truth[1])],
            'quantiles':point_quantiles,'logL_CDF':event.probability,
            'contour_quadrature_error_estimate':event.quadrature_absolute_error_estimate,
            'contour_small_interval_mass_bound':event.small_interval_mass_bound,
            'finite_underflow_nodes':posterior.finite_underflow_nodes,
            'log_upper_bound_omitted_scaled_nodal_probability':log_omit,
            'underflow_scope':'Finite sampled nodal underflow only, not unsampled physical posterior mass',
            'scope':'Exact properties of positive bilinear interpolant plus numerical contour quadrature'}


def compare_summaries(a,b):
    qerror=np.abs(np.asarray(a['quantiles'])-np.asarray(b['quantiles']))/np.array([.999,1.])[:,None]
    return {'logZ_H0':abs(a['logZ_H0']-b['logZ_H0'])<=.001,
            'logZ_H1':abs(a['logZ_H1']-b['logZ_H1'])<=.001,
            'logBF':abs(a['logBF']-b['logBF'])<=.002,
            'parameter_CDF':bool(np.max(abs(np.array(a['parameter_CDF'])-b['parameter_CDF']))<=.002),
            'quantiles':bool(np.max(qerror)<=.001),
            'logL_CDF':abs(a['logL_CDF']-b['logL_CDF'])<=.002,
            'observed_max_quantile_prior_width_difference':float(np.max(qerror)),
            'errors_are_observed_refinement_differences_not_uniform_certificates':True}
