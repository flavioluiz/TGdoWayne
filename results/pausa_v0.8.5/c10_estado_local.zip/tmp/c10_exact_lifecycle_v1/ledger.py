"""Single-process, durable pre-charge ledger; unused capacity is not evaluated work."""
import hashlib
import json
import math
import os
from pathlib import Path
import time


def positive(value,name,zero=False):
    if type(value) is not int or value < (0 if zero else 1):
        raise ValueError(name+' must be an explicit integer')
    return value


class CapacityExceeded(RuntimeError): pass


class GlobalLedger:
    def __init__(self,path,*,identity,allocations,maximum_values,maximum_cpu_seconds):
        if not isinstance(identity,str) or not identity: raise ValueError('frozen identity required')
        self.path=Path(path); self.identity=identity
        self.cap=positive(maximum_values,'maximum_values')
        if not isinstance(allocations,dict) or not allocations: raise ValueError('stage allocations required')
        self.allocations={k:positive(v,k,zero=True) for k,v in allocations.items()}
        if any(not isinstance(k,str) or not k for k in self.allocations) or sum(self.allocations.values())>self.cap:
            raise ValueError('invalid or overallocated stages')
        if isinstance(maximum_cpu_seconds,bool) or not isinstance(maximum_cpu_seconds,(int,float)) or not math.isfinite(maximum_cpu_seconds) or maximum_cpu_seconds<=0:
            raise ValueError('explicit approved CPU guard required')
        self.started=time.process_time(); self.cpu_cap=float(maximum_cpu_seconds); self.pid=os.getpid()
        self.state={'schema':'C10_GLOBAL_PRECHARGE_LEDGER_v1','identity':identity,
                    'capacity':self.cap,'allocations':self.allocations,
                    'charged':dict.fromkeys(self.allocations,0),'completed':dict.fromkeys(self.allocations,0),
                    'batches_reserved':0,'failed_batch_reservations_retained':True}
        if self.path.exists(): raise FileExistsError('Previous ledger is preserved; no implicit retry/resume.')
        self.path.parent.mkdir(parents=True,exist_ok=True); self._write()

    def _write(self):
        temp=self.path.with_suffix(self.path.suffix+'.next')
        with temp.open('w') as out:
            json.dump(self.state,out,sort_keys=True,allow_nan=False);out.write('\n');out.flush();os.fsync(out.fileno())
        os.replace(temp,self.path)

    def checkpoint(self):
        if os.getpid()!=self.pid: raise RuntimeError('Ledger is single process, never fork-shared')
        if time.process_time()-self.started>self.cpu_cap: raise CapacityExceeded('CPU allowance exhausted')

    def reserve(self,stage,count):
        self.checkpoint(); count=positive(count,'count')
        if stage not in self.allocations: raise ValueError('unallocated stage')
        if self.state['charged'][stage]+count>self.allocations[stage] or sum(self.state['charged'].values())+count>self.cap:
            raise CapacityExceeded('Global/stage likelihood allowance exhausted')
        self.state['charged'][stage]+=count;self.state['batches_reserved']+=1
        self._write() # Before the caller performs any density evaluation.

    def complete(self,stage,count):
        count=positive(count,'count')
        if stage not in self.allocations or self.state['completed'][stage]+count>self.state['charged'][stage]:
            raise ValueError('Completion exceeds prior reservation')
        self.state['completed'][stage]+=count;self._write()

    def evaluate(self,stage,count,callback):
        self.reserve(stage,count)
        result=callback() # Exceptions retain the entire charge.
        self.complete(stage,count)
        return result


class ScalarCache:
    """One ID/model/mass/response identity. All uncached values precharged once."""
    def __init__(self,evaluate,ledger,stage,*,identity,maximum_values):
        if not callable(evaluate) or not isinstance(identity,str) or not identity: raise ValueError('evaluator and full cache identity required')
        self.function=evaluate;self.ledger=ledger;self.stage=stage;self.identity=identity
        self.maximum=positive(maximum_values,'maximum_values');self.charged=0;self.cache={}

    def __call__(self,points):
        import numpy as np
        p=np.asarray(points,float)
        if p.ndim!=1 or not np.isfinite(p).all() or np.any((p<0)|(p>1)): raise ValueError('epsilon points in[0,1] required')
        keys=[float(x).hex() for x in p]
        missing=list(dict.fromkeys(k for k in keys if k not in self.cache))
        if self.charged+len(missing)>self.maximum: raise CapacityExceeded('Per-slice allowance exhausted')
        if missing:
            x=np.array([float.fromhex(k) for k in missing])
            self.ledger.reserve(self.stage,len(x));self.charged+=len(x)
            values=np.asarray(self.function(x),float)
            if values.shape!=x.shape or not np.isfinite(values).all(): raise ArithmeticError('invalid scalar density output')
            for k,v in zip(missing,values):self.cache[k]=float(v)
            self.ledger.complete(self.stage,len(x))
        return np.array([self.cache[k] for k in keys])
