"""Shared-factor conditional likelihood for C(epsilon)=C0+epsilon*C1.

Pure covariance-level component, not an ORF or validated PTA experiment.
Returns only requested normalized densities, in the requested model order.
The default model order preserves the frozen v2 API. No physical runner is included.
The Gaussian laws applied to physical quadratic statistics remain approximations.
"""
import numpy as np

MODELS=('A0_CN','A_CN','B_CN','A_G','B_G')


def selected_models(models):
    """Validate an ordered, unique, nonempty list/tuple of supported names."""
    if not isinstance(models,(tuple,list)) or not models:
        raise ValueError('models must be a nonempty ordered list or tuple')
    if any(type(name) is not str or name not in MODELS for name in models):
        raise ValueError('Unknown or non-string model name')
    names=tuple(models)
    if len(set(names))!=len(names):
        raise ValueError('Repeated model names are not allowed')
    return names


def hermitian(value,name):
    raw=np.asarray(value)
    if raw.dtype.kind not in 'fiuc' or raw.ndim<2 or raw.shape[-2]!=raw.shape[-1]:
        raise ValueError(name+' must contain numeric square matrices')
    a=np.array(raw,dtype=np.complex128,copy=True)
    if not np.isfinite(a).all(): raise ValueError(name+' must be finite')
    scale=np.maximum(np.max(abs(a),axis=(-2,-1)),np.finfo(float).tiny)
    error=np.max(abs(a-a.swapaxes(-1,-2).conj()),axis=(-2,-1))/scale
    if np.any(error>64*np.finfo(float).eps): raise ValueError(name+' is not Hermitian to roundoff')
    # Accepted symmetrization is recorded; no SPD repair is performed.
    return (a+a.swapaxes(-1,-2).conj())/2,float(np.max(error))


def real_array(value,name):
    raw=np.asarray(value)
    if raw.dtype.kind not in 'fiu': raise ValueError(name+' must be real numeric')
    a=np.array(raw,dtype=float,copy=True)
    if not np.isfinite(a).all(): raise ValueError(name+' must be finite')
    return a


class ConditionalLikelihood:
    def __init__(self,q,x_physical,x_gaussian,H,weights,*,maximum_logl_values,maximum_workspace_bytes=512*1024**2):
        raw=np.asarray(q)
        if raw.dtype.kind not in 'fiuc' or raw.ndim!=3 or not np.isfinite(raw).all(): raise ValueError('q must be finite (R,K,P)')
        self.q=np.array(raw,dtype=np.complex128,copy=True)
        self.R,self.K,self.P=self.q.shape
        if min(self.R,self.K,self.P)<1: raise ValueError('Empty observation dimension')
        self.H,self.H_hermitian_relative_error=hermitian(H,'H')
        if self.H.ndim!=3 or self.H.shape[-1]!=self.P: raise ValueError('H shape differs from q')
        self.D=len(self.H)
        if self.D<1: raise ValueError('Empty statistic dimension')
        self.physical=real_array(x_physical,'x_physical'); self.gaussian=real_array(x_gaussian,'x_gaussian')
        if self.physical.shape!=(self.R,self.K,self.D) or self.gaussian.shape!=self.physical.shape: raise ValueError('Statistic arrays differ from experiment')
        self.w=real_array(weights,'weights')
        if self.w.shape!=(self.K,): raise ValueError('One fixed weight per channel required')
        self.x=np.concatenate((self.physical,self.gaussian),axis=0)
        self.z=np.einsum('rkd,k->rd',self.x,self.w)[:,None,:]
        if isinstance(maximum_logl_values,bool) or not isinstance(maximum_logl_values,int) or maximum_logl_values<1: raise ValueError('Positive integer logL budget required')
        if isinstance(maximum_workspace_bytes,bool) or not isinstance(maximum_workspace_bytes,int) or maximum_workspace_bytes<1: raise ValueError('Positive integer memory budget required')
        self.maximum_logl_values=maximum_logl_values; self.maximum_workspace_bytes=maximum_workspace_bytes
        self.logl_values=0; self.completed_logl_values=0; self.last_preflight=None

    def preflight(self,E,*,models=MODELS):
        names=selected_models(models)
        if isinstance(E,bool) or not isinstance(E,int) or E<1: raise ValueError('Positive batch size required')
        # Explicit owned data plus conservative simultaneous covariance,
        # solve/residual, moment-basis, and normal-factorization arrays.
        static=(16*self.R*self.K*self.P+32*self.R*self.K*self.D
                +16*self.R*self.D+16*self.D*self.P**2+8*self.K)
        components={
            'owned_observations_and_estimators':static,
            'CN_covariance_and_factors':64*E*self.K*self.P**2,
            'CN_solve_and_scratch':48*E*self.K*self.P*self.R,
            'normal_residual_solve_and_scratch':64*E*self.K*self.D*self.R,
            'quadratic_moment_products':64*self.K*self.D*self.P**2,
            'quadratic_covariance_basis':40*self.K*self.D**2,
            'normal_covariance_and_factors':48*E*self.K*self.D**2,
            'compressed_normal_covariance_and_factors':32*E*self.D**2,
            'means_and_density_outputs':32*E*self.K*self.D+56*E*self.R,
        }
        elements=sum(components.values())
        values=E*len(names)*self.R
        if elements>self.maximum_workspace_bytes: raise RuntimeError('Declared workspace estimate exceeded')
        if self.logl_values+values>self.maximum_logl_values: raise RuntimeError('Cumulative logL budget exceeded')
        return {'estimated_numeric_workspace_bytes':int(elements),'components_bytes':components,'logl_values_requested':values,'models':list(names),'workspace_policy':'CONSERVATIVE_FULL_V2_ESTIMATE','status':'ESTIMATE_NOT_RSS_CERTIFICATE'}

    @staticmethod
    def _normal(mu,cov,data):
        chol=np.linalg.cholesky(cov)
        rhs=data.transpose(1,2,0)[None]-mu[:,:,:,None]
        solved=np.linalg.solve(chol,rhs)
        logdet=2*np.log(np.diagonal(chol,axis1=-2,axis2=-1)).sum(axis=(-2,-1))
        return -.5*(np.sum(solved**2,axis=(1,2))+logdet[:,None]+data.shape[1]*data.shape[2]*np.log(2*np.pi))

    def moments(self,C0,C1):
        c0,e0=hermitian(C0,'C0'); c1,e1=hermitian(C1,'C1')
        if c0.shape!=(self.K,self.P,self.P) or c1.shape!=c0.shape: raise ValueError('Covariance shape differs from experiment')
        np.linalg.cholesky(c0)
        mineig=np.linalg.eigvalsh(c1).min(axis=-1)
        scale=np.maximum(np.max(abs(c1),axis=(-2,-1)),np.finfo(float).tiny)
        if np.any(mineig < -64*np.finfo(float).eps*scale): raise ValueError('C1 is not PSD to roundoff')
        hc0=np.einsum('dab,kbc->kdac',self.H,c0,optimize=True)
        hc1=np.einsum('dab,kbc->kdac',self.H,c1,optimize=True)
        mu0=np.einsum('kdaa->kd',hc0).real; mu1=np.einsum('kdaa->kd',hc1).real
        s00=np.einsum('kiab,kjba->kij',hc0,hc0,optimize=True).real
        s01=np.einsum('kiab,kjba->kij',hc0,hc1,optimize=True).real
        s11=np.einsum('kiab,kjba->kij',hc1,hc1,optimize=True).real
        return c0,c1,(mu0,mu1,s00,s01+s01.swapaxes(-1,-2),s11),{'C0_symmetrization_relative_error':e0,'C1_symmetrization_relative_error':e1,'C1_minimum_eigenvalue':mineig.tolist()}

    def _selected_normal(self,mu,cov,data,physical_name,gaussian_name,names,outputs):
        """Use R rows for one law or 2R for both; never evaluate a discarded law."""
        want_physical=physical_name in names
        want_gaussian=gaussian_name in names
        if want_physical and want_gaussian:
            values=self._normal(mu,cov,data)
            outputs[physical_name]=values[:,:self.R]
            outputs[gaussian_name]=values[:,self.R:]
        elif want_physical:
            outputs[physical_name]=self._normal(mu,cov,data[:self.R])
        elif want_gaussian:
            outputs[gaussian_name]=self._normal(mu,cov,data[self.R:])

    def evaluate(self,C0,C1,epsilon,*,models=MODELS):
        names=selected_models(models)
        eps=real_array(epsilon,'epsilon')
        if eps.ndim!=1 or np.any(eps<0) or np.any(eps>1): raise ValueError('epsilon must be a batch in [0,1]')
        self.last_preflight=self.preflight(len(eps),models=names)
        c0,c1,basis,checks=self.moments(C0,C1)
        # Reserve the entire requested batch before any density evaluation.
        # Failures after this point retain the charge, even with partial work.
        self.logl_values+=self.last_preflight['logl_values_requested']
        outputs={}
        if 'A0_CN' in names:
            cov=c0[None]+eps[:,None,None,None]*c1[None]
            chol=np.linalg.cholesky(cov)
            rhs=np.broadcast_to(self.q.transpose(1,2,0),(len(eps),self.K,self.P,self.R))
            solved=np.linalg.solve(chol,rhs)
            ld=2*np.log(np.diagonal(chol,axis1=-2,axis2=-1).real).sum(axis=(-2,-1))
            outputs['A0_CN']=-np.sum(abs(solved)**2,axis=(1,2))-ld[:,None]-self.K*self.P*np.log(np.pi)
            del rhs,solved,cov,chol
        if any(name!='A0_CN' for name in names):
            m0,m1,s0,s1,s2=basis
            mu=m0[None]+eps[:,None,None]*m1[None]
            sigma=s0[None]+eps[:,None,None,None]*s1[None]+eps[:,None,None,None]**2*s2[None]
            if 'A_CN' in names or 'A_G' in names:
                self._selected_normal(mu,sigma,self.x,'A_CN','A_G',names,outputs)
            if 'B_CN' in names or 'B_G' in names:
                mb=np.einsum('ekd,k->ed',mu,self.w)
                sb=np.einsum('ekij,k->eij',sigma,self.w**2)
                self._selected_normal(mb[:,None,:],sb[:,None,:,:],self.z,'B_CN','B_G',names,outputs)
        result=np.stack([outputs[name] for name in names],axis=1)
        if not np.isfinite(result).all(): raise ArithmeticError('Nonfinite normalized likelihood')
        self.completed_logl_values+=result.size
        return result,checks
