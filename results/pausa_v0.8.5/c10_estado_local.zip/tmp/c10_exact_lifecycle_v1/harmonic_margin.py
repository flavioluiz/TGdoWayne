"""Finite-numerical-level logL perturbation envelope uniform in epsilon.

No new densities. No claim of uniform physical ORF accuracy or directed rounding.
The observed coefficient differences, not nominal tolerances, set the radius.
"""
import math
import numpy as np
from vendor_d1.polynomial import bernstein,compress_coefficients
from vendor_d1.envelope import _whiten_matrix


def _anchor(poly):
    """Lower SPD anchor, with explicit correction for signed higher coefficients.

    Mathematically Σ1,Σ2 are PSD for proper CN quadratics with C0>0,C1>=0.
    Computed coefficients may have small signed roundoff. Bound their negative
    eigenvalues after whitening rather than clipping/changing any covariance.
    """
    L=np.linalg.cholesky(poly[0]);negative=np.zeros(poly.shape[1])
    for a in poly[1:]:
        white=_whiten_matrix(L,a)
        eig=np.linalg.eigvalsh((white+white.swapaxes(-1,-2).conj())/2)
        negative+=np.maximum(0.,-eig[...,0])
    if not np.isfinite(negative).all() or np.any(negative>=1):raise ArithmeticError('No positive lower anchor')
    # The anchor is a bound used only in the proof, never a modified model.
    return L*np.sqrt(1-negative)[:,None,None],negative


def polynomial_pair(engine,C0,C1,model):
    c0,c1,basis,_=engine.moments(C0,C1)
    if model=='A0_CN':return np.stack((c0,c1)),None,engine.q[0]
    m0,m1,s0,s1,s2=basis;mu=np.stack((m0,m1));sigma=np.stack((s0,s1,s2))
    y=(engine.gaussian if model.endswith('_G') else engine.physical)[0]
    if model.startswith('B_'):
        mu,sigma=compress_coefficients(mu,sigma,engine.w)
        y=np.einsum('kd,k->d',y,engine.w)[None]
    return sigma,mu,y


def uniform_loglike_difference(fine,other,*,normal,roundoff_allowance):
    if not isinstance(roundoff_allowance,(int,float)) or isinstance(roundoff_allowance,bool) or not math.isfinite(roundoff_allowance) or roundoff_allowance<0:raise ValueError('Finite explicit roundoff allowance required')
    a,mu,y=fine;b,other_mu,other_y=other
    if a.shape!=b.shape or not np.array_equal(y,other_y):raise ValueError('Same polynomial dimensions and observations required')
    try:
        L,negative=_anchor(a)
        eta=np.max(np.linalg.norm(_whiten_matrix(L,bernstein(b-a)),axis=(-2,-1)),axis=0)
        if not np.isfinite(eta).all() or np.any(eta>=1):raise ArithmeticError('Relative perturbation not below one')
        if normal:
            residual=np.linalg.norm(np.linalg.solve(L,(y-mu[0])[...,None])[...,0],axis=-1)
            # Degree1 mean, or a constant compressed mean where present.
            residual+=sum(np.linalg.norm(np.linalg.solve(L,c[...,None])[...,0],axis=-1) for c in mu[1:])
            mean_delta=np.max(np.linalg.norm(np.linalg.solve(L,bernstein(other_mu-mu)[...,None])[...,0],axis=-1),axis=0)
            radius=.5*np.sum(-a.shape[-1]*np.log1p(-eta)+(eta*residual**2+2*residual*mean_delta+mean_delta**2)/(1-eta))
        else:
            chi=np.sum(abs(np.linalg.solve(L,y[...,None])[...,0])**2,axis=-1)
            radius=np.sum(-a.shape[-1]*np.log1p(-eta)+chi*eta/(1-eta))
        radius=float(radius)+roundoff_allowance
        if not math.isfinite(radius):raise ArithmeticError('Nonfinite perturbation radius')
        return {'status':'FINITE_NUMERICAL_LEVEL_BOUND_ORDINARY_FLOAT','delta_loglike':radius,
                'maximum_eta':float(np.max(eta)),'anchor_negative_coefficient_correction':negative.tolist(),
                'physical_ORF_certificate':False,'directed_rounding_certificate':False,
                'density_evaluations':0,'scope':'all epsilon in[0,1] for these supplied polynomial numerical levels'}
    except (ArithmeticError,np.linalg.LinAlgError,FloatingPointError) as exc:
        return {'status':'UNRESOLVED','delta_loglike':None,'failure':str(exc),'density_evaluations':0}


def event_level(truth_loglike,delta_node,delta_truth):
    """Conservative event band: both numerical event function and truth level vary."""
    from vendor_d1.envelope import LogRange
    if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in (truth_loglike,delta_node,delta_truth)) or delta_node<0 or delta_truth<0:
        raise ValueError('Finite truth and nonnegative measured/derived deltas required')
    radius=delta_node+delta_truth
    return LogRange(truth_loglike-radius,truth_loglike+radius)
