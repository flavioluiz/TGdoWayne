# C10 — piloto condicional em nós exatos, candidato de lifecycle v1

O pacote fecha o percurso executável de um **piloto de 16 dados e nove análises**, sujeito aos recibos ROOT especificados. A preparação executou somente 11 TOYs sintéticos e medições curtas de álgebra. **Zero ORFs, verossimilhanças PTA, dados físicos sorteados ou bancos novos foram executados aqui.** C09 deve ser concluído e revisado antes da autorização deste piloto. As populações de 500/500/192, Fisher e aplicação física não estão autorizadas por este pacote.

`execution_spec.json` congela fontes, eixos, dependências, alocações e insumos. O modo padrão verifica apenas fontes/metadados:

```sh
.venv/bin/python tmp/c10_exact_lifecycle_v1/run.py \
  --spec tmp/c10_exact_lifecycle_v1/execution_spec.json
```

O futuro `--execute` exige `--approval`, `--nodal-receipt`, `--prerequisite` e uma pasta nova `--output`. O recibo nodal ROOT já existe em `tmp/c10_ROOT_component/nodal_reuse_review_v1.json` e está vinculado no spec; não substitui a autorização do piloto ou o pré-requisito C09. O recibo de reutilização deve aceitar **somente os nós** do arquivo histórico `COMPONENT_ORF_TABLE_FAIL`; esse estado e os dados da interpolação linear reprovada permanecem intactos. A função física consulta somente coordenadas `float.hex()` presentes na tabela: nenhuma interpolação de ORF é introduzida. O `flock` exclusivo é uma proteção adicional; ROOT deve também coordenar o recurso entre tarefas.

## Percurso e contratos

1. Validar SHA das fontes e versões NumPy 2.4.3/SciPy 1.17.1, os três recibos e o novo destino. Contar CPU desde o início do interpretador, incluindo importações.
2. Reutilizar os 513 nós de massa do arquivo histórico apenas após o recibo separado. Construir 583 nós adicionais em **três filhos sequenciais de uma thread**, H00=(460,900), H01=(460,1000), H11=(520,1000). Cada um calcula D1/D2/D3/Cβ2/Cβ3, TT e escalar FP; Cfull reaproveita D1. Validar finitude/PSD e refinamentos separados de quadratura e corte. O denominador físico usa βk(u)=sqrt((1−u/k)(1+u/k)), e as fases reais C06 chegam a 120π rad.
3. Gerar os 16 dados previamente fixados com a geometria C06 P10/K3/T15/L100–300 e seed `[910100101,0,id]`. As nove análises compartilham a mesma realização física ou o controle normal correspondente. Nuisances são conhecidos e fixos; isso não é SBC de seis parâmetros.
4. Cobrar verdades em três níveis H, leis SciPy/traços independentes, refinamentos H em controles já contados e ε=0 na fixture C06. Os 4.608 valores H existentes verificam adicionalmente os envelopes matriciais, sem novas densidades. Os erros encontrados definem controles finitos, sem converter tolerância de logL em erro de probabilidade.
5. Executar malha fina 257×129 em 16 dados e nove modelos, extraindo 129×65 dos mesmos valores. Nos quatro IDs fixados, construir 513×257 reutilizando estritamente identidade, nós, ε, modelo e ID. Avaliar produto independente GL384×GL96 e **bordas**, resultando em 386×98. A borda ε=0 permite a referência H0 sem extrapolação. H0 e H1 têm a mesma priori uniforme própria em u∈[.001,1].
6. Resumir os interpolantes positivos, comparando evidências H0/H1, BF, CDFs, quantis e evento de logL. Essas comparações observadas não são certificados uniformes da likelihood física. O produto GL também fornece Z e H0 diretamente com pesos congelados, sem mutação ou renormalização no laço.
7. Para quatro dados×nove modelos, integrar em ε com envelopes matriciais de células inteiras e GL16/32 em cada u das regras independentes GL192/384. Cada fatia tem 255 valores novos no máximo. Propagar eventos e pesos entre os três níveis numéricos e agregar N/A/Z **não normalizados** em u, conforme `PROVAS_E_LIMITES.md`.
8. Preservar todas as falhas e escrever resultados, ledger e CPU. `complete.json` significa que os componentes solicitados foram registrados; traz flags separadas para gates e **não autoriza campanha500**. Qualquer deficiência mantém `UNRESOLVED [0,1]` onde aplicável.

## Orçamento fechado para revisão

| Etapa | Máximo de valores logL |
|---|---:|
| Malhas finas selecionadas | 4.774.032 |
| Quatro referências aninhadas, descontando somente valores idênticos | 3.552.768 |
| Quatro produtos independentes, incluindo bordas | 1.361.808 |
| 20.736 referências em ε × 255 | 5.287.680 |
| Verdades nos três H | 432 |
| Kernel candidato e referências independentes | 9.216 |
| Dois níveis H adicionais nos controles | 4.608 |
| ε=0 na fixture C06 | 576 |
| **Total pré-alocado** | **14.991.120** |

Restam 8.880 valores sem alocação automática sob o teto original de 15 milhões. O delta prospectivo adiciona 34.704 valores às bordas e remove 20.736 da antiga reserva de contornos, reduzindo 256→255 por fatia. Reservas são persistidas **antes** de cada lote; erros não devolvem o crédito. Não há novas sementes, refino automático ou tentativa adicional.

ORFs: 17.490 novas matrizes de modo, proxy BLAS 162.540.400.000 e contrações 6.716.160.000; **zero céu novo**. Os 50.240.000 pontos históricos continuam sob70M. O orçamento ORF continua600s incluindo133.905984s históricos, portanto restam466.094016s. O pai mede cada processo fechado pelo delta `RUSAGE_CHILDREN`, inclusive importações/saída/falhas; o tempo interno do filho é preservado separadamente, sem determinar o crédito disponível.

Propõem-se **1800s de CPU agregada** para este piloto e **1GiB de arquivos**, ainda sujeitos à aprovação ROOT. A projeção sintética registrada é aproximadamente1480s incluindo ORF, margens H, construtores de eventos, resumos bilineares, fator de estresse8 e reserva de I/O. É uma estimativa operacional, não garantia de duração ou precisão. O novo ensaio sintético inteiro consumiu aproximadamente0,5s e121MB RSS; os números exatos e hashes estão em `validation.json`.

O envelope de arquivos, sem crédito de compressão, é680.333.344B. Inclui .npy dos filhos **e** arquivo combinado, todos os grids, caches ε/logL, até16KiB por relatório de fatia e64MiB para os demais metadados. O escritor rejeita relatórios de fatia maiores; a falha fica registrada. O limite refere-se a bytes de arquivos, não aos blocos/metadata adicionais do filesystem.

Cada filho ORF dispõe de512MiB RSS; bases TT/FP têm tetos explícitos somados256MiB e os buffers de saída/cálculo estão discriminados no spec. No pai, a guarda nodal inclui saída, reuso, workspace e arrays externos ainda residentes (incluindo fine/high na etapa produto) antes de alocar. Os demais estágios são sequenciais e abaixo do alvo estimado2GiB; o teto RSS permanece4GiB. As estimativas são controles de alocação, não certificados de RSS.

## Persistência e preservação

`nodal_runner.py` continua byte a byte igual à guarda v2 aceita. `persistent_grid.py` é a extensão mínima do seu laço: após a mesma guarda prévia, abre **o único arquivo de saída .npy**, inicializa entradas com NaN e faz flush após cada lote. Um `finally` registra contagem de valores completos, máscara implícita NaN, identidade, SHA e estado. Um arquivo parcial não é reutilizado nem aceito como completo. O TOY força falha no segundo produtor, confirma o primeiro bloco preservado e demonstra igualdade exata com a saída original no sucesso.

Os filhos ORF usam o mesmo padrão de arquivo mapeado/NaN/flush, preservando relatório em `finally`; se um sinal impedir esse bloco, o pai conserva arquivo/log e registra saída do subprocesso e hash, sem inventar sucesso. Verdades são igualmente armazenadas no arquivo mapeado à medida que ficam prontas. Os caches de fatia são salvos em `finally`, incluindo exceções e warnings; as reservas continuam no ledger. Não se duplicam arrays de grids no caminho bem-sucedido. Warnings viram exceções no executor e não permitem aprovação silenciosa.

## Limites e pendências concretas

Os TOYs validam álgebra e transporte de falhas, não o encadeamento em geometria física, custo real ou todas as topologias da posterior. H00/H01/H11 fornecem uma comparação entre **representações numéricas**; não se afirma um erro uniforme da ORF física exata. As probabilidades permanecem condicionais aos controles operacionais explicitados. Não se assume no máximo duas raízes. Falta de denominador próprio, limites não finitos, células ambíguas demais, conflito entre regras ou recurso esgotado não produzem uma CDF aprovada.

O recibo nodal-only ROOT está disponível e compatível com as guardas. A autorização ROOT do piloto e a conclusão/revisão C09 continuam pendentes. Nenhum teste ou fonte deste pacote altera os componentes anteriores, os históricos `FAIL`, as fontes C07/C08 ou seus resultados.
