"""Bounded synthetic-only verification and additional lifecycle cost estimate."""
import os,resource
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import hashlib,json,sys,time,unittest
from pathlib import Path
import numpy as np
import scipy
from test_integration import synthetic
from harmonic_margin import polynomial_pair,uniform_loglike_difference
from references import summary
from epsilon_event import PolynomialEvent
HERE=Path(__file__).resolve().parent
suite=unittest.defaultTestLoader.discover(str(HERE),pattern='test_*.py')
with (HERE/'test_output.txt').open('w') as out:result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
e,c0,c1=synthetic(P=10,K=3,D=10)
models=('A0_CN','A_CN','B_CN','A_G','B_G');rates={};construct={}
for model in models:
 t=time.process_time()
 for _ in range(20):
  fine=polynomial_pair(e,c0,c1,model)
  for j in (1,2):
   other=polynomial_pair(e,c0+j*1e-5*np.eye(10)[None],c1*(1+j*1e-5),model)
   uniform_loglike_difference(fine,other,normal=model!='A0_CN',roundoff_allowance=1e-10)
 rates[model]=(time.process_time()-t)/20
 t=time.process_time()
 for _ in range(20):PolynomialEvent(e,c0,c1,model,roundoff_allowance=1e-10)
 construct[model]=(time.process_time()-t)/20
summary_times={}
# Deterministic nonphysical smooth log function; no PTA response/data generation.
for n,m in ((129,65),(257,129),(513,257),(386,98)):
 x=np.linspace(.001,1,n);y=np.linspace(0,1,m)
 z=-20*(x[:,None]-.4)**2-10*(y[None]-.6)**2
 t=time.process_time();s=summary(x,y,z,[.4,.6],-.4)
 summary_times[f'{n}x{m}']=time.process_time()-t
base=json.loads((HERE.parent/'c10_exact_selected_preflight_v1/validation.json').read_text())['timing']
old_forecast=base['candidate_non_ORF_CPU_forecast_seconds']
# Main: 20736 slices x two H bounds plus 2304 pairs of existing control values.
# Constructor costs remain explicit, even though old envelope rate excluded them.
margin_est=23040*max(rates.values())
constructor_est=20736*max(construct.values())
summary_est=144*(summary_times['129x65']+summary_times['257x129'])+36*(summary_times['513x257']+summary_times['386x98'])
extra_est=8*(margin_est+constructor_est+summary_est)
report={'schema':'C10_LIFECYCLE_SYNTHETIC_VALIDATION_v1','status':'PASS' if result.wasSuccessful() else 'FAIL_PRESERVED','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
 'CPU_seconds_with_startup_imports':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
 'maximum_RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024),
 'numpy':np.__version__,'scipy':scipy.__version__,'seed':910100501,
 'physical_ORF_calls':0,'physical_log_likelihood_values':0,'physical_draws':0,'bank_constructed':False,
 'timing':{'scope':'Synthetic random covariance algebra and analytic log functions; not a physical performance guarantee',
 'three_polynomial_pairs_and_two_bounds_seconds':rates,'event_constructor_seconds':construct,'one_bilinear_summary_seconds':summary_times,
 'additional_margin_base_estimate_seconds':margin_est,'additional_constructor_base_estimate_seconds':constructor_est,'additional_summary_base_estimate_seconds':summary_est,
 'stress_factor':8,'previous_non_ORF_estimate_seconds':old_forecast,'new_non_ORF_estimate_seconds':old_forecast+extra_est,
 'new_ORF_heuristic_seconds':129.44490470175438,'combined_candidate_estimate_seconds':old_forecast+extra_est+129.44490470175438,
 'candidate_cap_seconds':1800,'no_automatic_budget_increase':True},
 'source_sha256':{str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.rglob('*.py')) if '__pycache__' not in p.parts}}
(HERE/'validation.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
