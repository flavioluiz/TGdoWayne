"""Authorized physical pilot lifecycle; never called by preparation or TOYs."""
import json
import math
from pathlib import Path
import subprocess
import sys
import time
import resource
import numpy as np
from scipy.special import roots_legendre,logsumexp
from physical import ROUTES,LABELS,sha,load_geometry,NodalCovariances,generate_pilot,engine_for
from selected_kernel import ConditionalLikelihood
from persistent_grid import run_grid_preserved as run_grid
from ledger import GlobalLedger,ScalarCache,CapacityExceeded
from epsilon_event import PolynomialEvent,reference_slice
from vendor_d1.envelope import LogRange
from harmonic_margin import polynomial_pair,uniform_loglike_difference,event_level
from aggregate import aggregate_slices,compare_u_rules
from references import independent_values,summary,compare_summaries,product_log_evidence
from report_io import json_report


def save(path,value):
    path=Path(path)
    payload=json.dumps(json_report(value),indent=2,allow_nan=False)+'\n'
    if path.parent.name=='event_slices' and len(payload.encode())>16*1024:raise CapacityExceeded('Per-slice report cap; no silent truncation')
    with path.open('x') as out:out.write(payload)


class OuterGuard:
    def __init__(self,spec,output,start_cpu):
        self.spec=spec;self.output=output;self.start=start_cpu
    def cpu(self):
        child=resource.getrusage(resource.RUSAGE_CHILDREN)
        return time.process_time()-self.start+child.ru_utime+child.ru_stime
    def check(self):
        if self.cpu()>self.spec['pilot_CPU_seconds']:raise CapacityExceeded('Aggregate startup/parent/children CPU cap')
        rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)
        if rss>self.spec['maximum_RSS_bytes']:raise CapacityExceeded('Parent RSS cap')
    def disk(self):
        size=sum(p.stat().st_size for p in self.output.rglob('*') if p.is_file())
        if size>self.spec['maximum_output_bytes']:raise CapacityExceeded('Uncompressed-independent output cap')
        return size


def execute(root,spec_path,spec,approval_path,nodal_receipt,output,start_cpu):
    if output.exists():raise FileExistsError('Preserve previous pilot; no implicit retry or resume')
    output.mkdir(parents=True)
    guard=OuterGuard(spec,output,start_cpu)
    try:
        axes=json.loads((root/spec['axes']['path']).read_text())
        protocol=json.loads((root/spec['protocol']['path']).read_text());c06=json.loads((root/'configs/experiments/c06_moments.json').read_text())
        geometry=load_geometry(root,spec)
        old=root/spec['nodal_table']['path']
        if sha(old)!=spec['nodal_table']['sha256']:raise ValueError('Nodal archive hash mismatch')
        with np.load(old,allow_pickle=False) as a:
            mass=a['masses'].copy();old_gamma=a['gamma'].copy()
        if not np.array_equal(mass,np.array(axes['master_mass_nodes'])) or old_gamma.shape!=(3,513,5,2,10,10):raise ValueError('Exact archived nodal component differs')
        new=np.array(axes['new_mass_nodes_requiring_explicit_harmonics']);children=[]
        for level,resolution in enumerate(spec['harmonic_resolutions']):
            guard.check();remaining_ORF=600-spec['historical_ORF_CPU_seconds']-sum(r['CPU_seconds'] for r in children)
            remaining=min(remaining_ORF,spec['pilot_CPU_seconds']-guard.cpu())
            if remaining<=0:raise CapacityExceeded('No ORF/aggregate CPU left')
            task={'authorized_child':True,'root':str(root),'spec':str(spec_path.relative_to(root)),
                  'spec_sha256':sha(spec_path),'approval_path':str(approval_path),'approval_sha256':sha(approval_path),
                  'masses':new.tolist(),'resolution':resolution,'CPU_seconds':remaining,
                  'output':str(output/f'new_gamma_H{level}.npy')}
            taskfile=output/f'orf_task_H{level}.json';taskfile.write_text(json.dumps(task,indent=2)+'\n')
            before=resource.getrusage(resource.RUSAGE_CHILDREN);child_status=None
            try:
                with (output/f'orf_H{level}.log').open('w') as log:
                    child_status=subprocess.run([sys.executable,str(Path(__file__).with_name('orf_child.py')),'--task',str(taskfile)],stdout=log,stderr=subprocess.STDOUT)
            finally:
                after=resource.getrusage(resource.RUSAGE_CHILDREN)
                external_CPU=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
                child_record={'CPU_seconds':external_CPU,'measurement':'RUSAGE_CHILDREN delta including process exit, imports and failure',
                              'returncode':None if child_status is None else child_status.returncode,
                              'allocated_remaining_seconds':remaining,'historical_plus_closed_children_CPU_seconds':spec['historical_ORF_CPU_seconds']+sum(r['CPU_seconds'] for r in children)+external_CPU}
                array=output/f'new_gamma_H{level}.npy'
                if array.exists():child_record.update(array_sha256=sha(array),array_preserved_without_success_inference=True)
                children.append(child_record);save(output/f'orf_H{level}_external_CPU.json',child_record)
            guard.check()
            if spec['historical_ORF_CPU_seconds']+sum(r['CPU_seconds'] for r in children)>600:raise CapacityExceeded('Inherited combined ORF CPU cap exceeded; external measurements preserved')
            if child_status.returncode:raise RuntimeError('Harmonic child failed; original log/output preserved')
            child_record['internal_final_report']=json.loads((output/f'new_gamma_H{level}.json').read_text())
        new_gamma=np.stack([np.load(output/f'new_gamma_H{level}.npy',allow_pickle=False) for level in range(3)])
        gamma=np.concatenate((old_gamma,new_gamma),axis=1);allmass=np.r_[mass,new];del old_gamma,new_gamma
        # Refine angular nodes/cutoff separately at every new mass. No linear ORF representation is constructed.
        for a,b in ((0,1),(1,2)):
            err=abs(gamma[a,513:]-gamma[b,513:]);tol=1e-5+1e-3*abs(gamma[b,513:])
            if np.any(err>tol):raise ArithmeticError('New nodal harmonic refinement gate failed')
        np.savez_compressed(output/'nodal_component.npz',masses=allmass,gamma=gamma)
        provider=NodalCovariances(allmass,gamma,geometry,protocol,c06)
        data=generate_pilot(provider,geometry,axes,output/'generation.npz');generation_sha=sha(output/'generation.npz')
        guard.check();guard.disk()
        ledger=GlobalLedger(output/'ledger.json',identity=sha(spec_path),allocations=spec['allocations'],maximum_values=15_000_000,maximum_cpu_seconds=max(.001,spec['pilot_CPU_seconds']-guard.cpu()))
        local_check=ledger.checkpoint
        ledger.checkpoint=lambda:(local_check(),guard.check())
        rows=axes['pilot_data'];truth=np.array([[r['u'],r['epsilon']] for r in rows]);truthLL=np.lib.format.open_memmap(output/'truth_logL.npy',mode='w+',dtype=np.float64,shape=(3,16,9));truthLL[:]=np.nan;truthLL.flush();label_order=sum((list(LABELS[r]) for r in ROUTES),[])
        columns={label:i for i,label in enumerate(label_order)}
        # Every diagnostic truth value is independently charged for its numerical level.
        for i,row in enumerate(rows):
            e=engine_for(data,geometry,[i])
            for level in range(3):
                for route,(models,_) in ROUTES.items():
                    c0,c1=provider(row['u'],route,level);n=len(models)
                    values=ledger.evaluate('truth_three_harmonic_levels',n,lambda:e.evaluate(c0,c1,[row['epsilon']],models=models)[0][0,:,0])
                    truthLL[level,i,[columns[x] for x in LABELS[route]]]=values
                    truthLL.flush()
        max_kernel=0.;max_Hcontrol=0.;margin_violations=0;margin_finite_checks=0;margin_unresolved=0
        # Independent direct traces and SciPy laws; no selected values are discarded.
        for j,mi in enumerate(axes['kernel_control_mass_indices']):
            u=mass[mi];epsilon=axes['kernel_control_epsilon'][j]
            for route,(models,_) in ROUTES.items():
                e=engine_for(data,geometry,range(16));c0,c1=provider(u,route,2);n=16*len(models)
                candidate=ledger.evaluate('independent_kernel_references',n,lambda:e.evaluate(c0,c1,[epsilon],models=models)[0][0])
                independent=ledger.evaluate('independent_kernel_references',n,lambda:independent_values(c0,c1,epsilon,e,models))
                max_kernel=max(max_kernel,float(np.max(abs(candidate-independent))))
                if j<16:
                    for level in (0,1):
                        a,b=provider(u,route,level)
                        other=ledger.evaluate('two_extra_ORF_levels_at_control_points',n,lambda:e.evaluate(a,b,[epsilon],models=models)[0][0])
                        max_Hcontrol=max(max_Hcontrol,float(np.max(abs(candidate-other))))
                        # Existing LL controls also check the whole-epsilon algebra;
                        # no additional density evaluations are charged or hidden.
                        for ri in range(16):
                            one=engine_for(data,geometry,[ri])
                            for mi,model in enumerate(models):
                                bound=uniform_loglike_difference(polynomial_pair(one,c0,c1,model),polynomial_pair(one,a,b,model),normal=model!='A0_CN',roundoff_allowance=spec['roundoff_logL_allowance'])
                                if bound['delta_loglike'] is None:margin_unresolved+=1
                                else:
                                    margin_finite_checks+=1
                                    margin_violations+=int(abs(candidate[mi,ri]-other[mi,ri])>bound['delta_loglike'])
        zero_error=zero_check(root,spec,geometry,ledger)
        controls_pass=max(max_kernel,zero_error)<=min(1e-10,spec['roundoff_logL_allowance']) and margin_violations==0
        save(output/'kernel_controls.json',{'same_covariance_max_abs_logL':max_kernel,'epsilon0_max_abs_logL':zero_error,
                                          'H_pointwise_max_abs_logL_diagnostic_only':max_Hcontrol,
                                          'uniform_epsilon_envelope_finite_controls':margin_finite_checks,
                                          'uniform_epsilon_envelope_unavailable_controls':margin_unresolved,
                                          'uniform_epsilon_envelope_violations':margin_violations,
                                          'roundoff_scope':'Finite SciPy and synthetic controls, not directed rounding or a physical uniform certificate',
                                          'passed':controls_pass,'pointwise_checks_not_probability_margins':True})
        if not controls_pass:raise ArithmeticError('Independent kernel gate failed; densities/data preserved')
        grid_results={};summaries={};references=axes['independent_reference_ids']
        fine_u=mass[::2];fine_e=np.array(axes['master_epsilon_nodes'])[::2]
        for route,(models,_) in ROUTES.items():
            guard.check();e=engine_for(data,geometry,range(16))
            identity={'nodal_component_sha256':sha(output/'nodal_component.npz'),'kernel_sha256':spec['selected_kernel_sha256'],
                      'generation_sha256':generation_sha,'fixed_nuisance_sha256':spec['protocol']['sha256'],
                      'response':route,'harmonic_level':'H11'}
            fine,receipt=run_grid(e,lambda u:provider(u,route,2),fine_u,fine_e,models=models,data_ids=range(16),identity=identity,ledger=ledger,stage='fine_grids',output_path=output/f'{route}_fine.npy',maximum_workspace_bytes=512*1024**2,additional_resident_bytes=gamma.nbytes)
            save(output/f'{route}_fine_receipt.json',receipt)
            refengine=engine_for(data,geometry,references)
            high,hreceipt=run_grid(refengine,lambda u:provider(u,route,2),mass,np.array(axes['master_epsilon_nodes']),models=models,data_ids=references,identity=identity,ledger=ledger,stage='four_nested_reference_grids',output_path=output/f'{route}_high.npy',reuse=fine,maximum_workspace_bytes=512*1024**2,additional_resident_bytes=gamma.nbytes)
            save(output/f'{route}_high_receipt.json',hreceipt)
            un=np.array(axes['u_reference']['384']['nodes']);en=np.array(axes['epsilon_product_reference']['nodes']);ew=np.array(axes['epsilon_product_reference']['prior_weights'])
            product,preceipt=run_grid(refengine,lambda u:provider(u,route,2),np.r_[.001,un,1.],np.r_[0.,en,1.],models=models,data_ids=references,identity=identity,ledger=ledger,stage='four_product_references',output_path=output/f'{route}_product.npy',maximum_workspace_bytes=512*1024**2,additional_resident_bytes=gamma.nbytes+fine.values.nbytes+high.values.nbytes)
            save(output/f'{route}_product_receipt.json',preceipt)
            for m,label in enumerate(LABELS[route]):
                col=columns[label]
                for i in range(16):
                    guard.check();s=summary(fine.mass,fine.epsilon,fine.values[:,:,m,i],truth[i],truthLL[2,i,col])
                    coarse=summary(fine.mass[::2],fine.epsilon[::2],fine.values[::2,::2,m,i],truth[i],truthLL[2,i,col])
                    row={'fine':s,'coarse':coarse,'grid_gates':compare_summaries(coarse,s)}
                    if i in references:
                        ri=references.index(i)
                        hi=summary(high.mass,high.epsilon,high.values[:,:,m,ri],truth[i],truthLL[2,i,col])
                        independent=summary(product.mass,product.epsilon,product.values[:,:,m,ri],truth[i],truthLL[2,i,col])
                        loggrid=product.values[1:-1,1:-1,m,ri]
                        uw=np.array(axes['u_reference']['384']['prior_weights'])
                        direct_Z,direct_H0=product_log_evidence(loggrid,product.values[1:-1,0,m,ri],uw,ew)
                        row.update(high=hi,independent_grid=independent,high_gates=compare_summaries(s,hi),independent_gates=compare_summaries(hi,independent),
                                   direct_product_logZ=direct_Z,direct_product_H0=direct_H0,
                                   direct_product_Z_gate=abs(direct_Z-hi['logZ_H1'])<=.001,
                                   direct_product_H0_gate=abs(direct_H0-hi['logZ_H0'])<=.001)
                    summaries[f'{label}:{i}']=row
            del fine,high,product
            guard.disk()
        save(output/'nodal_posterior_summaries.json',summaries)
        contour_results=event_references(provider,data,geometry,axes,truthLL,columns,summaries,ledger,guard,output,spec)
        from run import validate_sources
        validate_sources(root,spec)
        guard.check();guard.disk()
        all_grids=all(all(v is True for k,v in s['grid_gates'].items() if k not in ('observed_max_quantile_prior_width_difference','errors_are_observed_refinement_differences_not_uniform_certificates')) for s in summaries.values())
        save(output/'complete.json',{'status':'PILOT_ALL_REQUESTED_COMPONENTS_RECORDED_NOT_PRODUCTION_AUTHORIZATION',
             'aggregate_CPU_seconds':guard.cpu(),'global_logL_charged':sum(ledger.state['charged'].values()),
             'global_logL_completed':sum(ledger.state['completed'].values()),'contour_results':contour_results,
             'all_primary_grid_gates_pass':all_grids,
             'all_four_reference_event_gates_pass':all(r['status']=='RESOLVED_OPERATIONAL_FINITE_REFERENCE_ONLY' for r in contour_results.values()),
             'failed_interpolation_history_preserved':True,'source_sha256':spec['source_sha256'],
             'physical_global_error_certificate':False,'production500_authorized':False})
    except Exception as exc:
        save(output/'FAILED_PRESERVED.json',{'status':'FAILED_PRESERVED_NO_RETRY','error':type(exc).__name__+': '+str(exc),
             'aggregate_CPU_seconds':guard.cpu(),'output_bytes':sum(p.stat().st_size for p in output.rglob('*') if p.is_file()) if output.exists() else 0})
        raise


def zero_check(root,spec,geometry,ledger):
    with np.load(root/spec['physical_inputs']['C06_fixture']['path'],allow_pickle=False) as f:
        q=f['fourier_normalized'].copy();x=f['physical_A'].copy();g=f['gaussian_A'].copy()
        cov={r:f['C_normalized_'+('dispersive' if r=='D' else r)].copy() for r in ROUTES}
    e=ConditionalLikelihood(q,x,g,geometry['estimator_matrices'],geometry['frequency_weights'],maximum_logl_values=15_000_000)
    maximum=0.
    for route,(models,_) in ROUTES.items():
        C=cov[route];n=e.R*len(models)
        a=ledger.evaluate('epsilon_zero_C06_reference',n,lambda:e.evaluate(C,np.zeros_like(C),[0.],models=models)[0][0])
        b=ledger.evaluate('epsilon_zero_C06_reference',n,lambda:independent_values(C,np.zeros_like(C),0.,e,models))
        maximum=max(maximum,float(np.max(abs(a-b))))
    return maximum


def event_references(provider,data,geometry,axes,truthLL,columns,summaries,ledger,guard,output,spec):
    results={};slice_root=output/'event_slices';slice_root.mkdir()
    for i in axes['independent_reference_ids']:
        e=engine_for(data,geometry,[i])
        for route,(models,_) in ROUTES.items():
            for model,label in zip(models,LABELS[route]):
                col=columns[label];rules={};key=f'{label}:{i}'
                delta_truth=float(np.max(abs(truthLL[:2,i,col]-truthLL[2,i,col])))+spec['roundoff_logL_allowance']
                for order in ('192','384'):
                    nodes=axes['u_reference'][order]['nodes'];weights=axes['u_reference'][order]['prior_weights']
                    rows=[];deltas=[]
                    for j,u in enumerate(nodes):
                        guard.check();c0,c1=provider(u,route,2)
                        fine=polynomial_pair(e,c0,c1,model);bounds=[]
                        for level in (0,1):
                            a,b=provider(u,route,level);other=polynomial_pair(e,a,b,model)
                            bounds.append(uniform_loglike_difference(fine,other,normal=model!='A0_CN',roundoff_allowance=spec['roundoff_logL_allowance']))
                        valid=all(b.get('delta_loglike') is not None for b in bounds)
                        delta=max(b['delta_loglike'] for b in bounds) if valid else math.inf
                        identity=f'{sha(output/"generation.npz")}:{label}:{i}:{float(u).hex()}:H11'
                        cache=ScalarCache(lambda eps:e.evaluate(c0,c1,eps,models=(model,))[0][:,0,0],ledger,'epsilon_event_references',identity=identity,maximum_values=255)
                        name=f'{label}_d{i}_u{order}_{j}'
                        cache_failure=None
                        try:
                            event=PolynomialEvent(e,c0,c1,model,roundoff_allowance=spec['roundoff_logL_allowance'])
                            if valid:
                                # Both the event and its unnormalized measure change across H.
                                # Widening only the weights would miss shifted crossings.
                                level=event_level(float(truthLL[2,i,col]),delta,delta_truth)
                                row=reference_slice(event,cache,level,controls={'roundoff_allowance_validated':True,'same_node_covariance_reference_validated':True})
                            else:
                                # Preserve an unconstrained numerator and obtain its OWN Z if possible.
                                from epsilon_event import integrate_regions
                                try:
                                    shift=float(cache(np.array([.5]))[0]);den=integrate_regions(cache,[(0.,1.)],shift)
                                except (ArithmeticError,FloatingPointError,CapacityExceeded):shift=None;den=None
                                row={'status':'UNRESOLVED','interval':[0.,1.],'candidate_interval':[0.,1.],
                                     'failure_preserved':'Uniform numerical-level envelope unavailable',
                                     'log_shift':shift,'denominator':den,'numerator_references':{},
                                     'controls':{'roundoff_allowance_validated':True,'same_node_covariance_reference_validated':True}}
                        except Exception as exc:
                            cache_failure=type(exc).__name__+': '+str(exc)
                            raise
                        finally:
                            keys=list(cache.cache);eps=np.array([float.fromhex(k) for k in keys]);vals=np.array([cache.cache[k] for k in keys])
                            np.savez_compressed(slice_root/(name+'.npz'),epsilon=eps,log_likelihood=vals)
                            if cache_failure is not None:
                                save(slice_root/(name+'.json'),{'status':'UNRESOLVED_PARTIAL_CACHE_PRESERVED','failure':cache_failure,
                                     'identity':identity,'cached_values':len(keys),'charged_values':cache.charged,'interval':[0.,1.],
                                     'node_u':u,'denominator':None,'no_retry':True})
                        row.update(level_bounds=bounds,delta_logL_truth=delta_truth,delta_logL_node=None if not valid else delta,
                                   threshold_event_widened_by_node_and_truth=valid,node_u=u,conditional_slice_not_uniformly_averaged=True)
                        # Each report/cache is compact and immutable; all failures remain.
                        save(slice_root/(name+'.json'),row)
                        rows.append(row);deltas.append(delta)
                    global_controls={'same_node_reference':True,'roundoff':True,'harmonic_level_enclosure':all(math.isfinite(x) for x in deltas)}
                    rules[order]=aggregate_slices(rows,weights,deltas,controls=global_controls)
                    save(output/f'{label}_d{i}_u{order}_mass_reference.json',rules[order])
                    guard.disk()
                s=summaries[key]
                # These booleans derive from actually evaluated summaries, not nominal margins.
                original={'bilinear_comparison':bool(s.get('direct_product_Z_gate') and s.get('direct_product_H0_gate') and all(g.get(k) is True for g in (s['grid_gates'],s['high_gates'],s['independent_gates']) for k in ('logZ_H0','logZ_H1','logBF','logL_CDF'))),
                          'underflow':all(x.get('log_upper_bound_omitted_scaled_nodal_probability',math.inf)<math.log(1e-8) for x in (s['fine'],s['coarse'],s['high'],s['independent_grid'])),
                          'threshold_reference':True,
                          'parameter_CDF_quantiles':all(g.get('parameter_CDF') is True and g.get('quantiles') is True for g in (s['grid_gates'],s['high_gates'],s['independent_gates'])),
                          'warning_free':True}
                result=compare_u_rules(rules['192'],rules['384'],original_gates=original)
                # A real comparison against the bilinear logL event probability is mandatory.
                for name in ('fine','high','independent_grid'):
                    point=s[name]['logL_CDF'];interval=result.get('candidate_interval',[0.,1.])
                    if max(abs(point-interval[0]),abs(point-interval[1]))>.002:
                        result.update(status='UNRESOLVED',interval=[0.,1.],bilinear_event_comparison_failed=True)
                results[key]=result;save(output/f'{label}_d{i}_event_comparison.json',result)
    return results
