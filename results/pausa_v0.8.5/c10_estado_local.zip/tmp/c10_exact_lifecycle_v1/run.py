"""Metadata check by default; physical work requires exact ROOT receipts."""
import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import warnings
import importlib.metadata

# CPU is counted from process origin, including interpreter/import startup.
START_CPU=0.0
for variable in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[variable]='1'


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for b in iter(lambda:stream.read(1024**2),b''):h.update(b)
    return h.hexdigest()


def validate_sources(root,spec):
    for name,version in spec['dependencies'].items():
        if importlib.metadata.version(name)!=version:raise ValueError('Numerical dependency changed: '+name)
    for name,digest in spec['source_sha256'].items():
        p=(root/name).resolve()
        if not p.is_relative_to(root) or sha(p)!=digest:raise ValueError('Source closure changed: '+name)
    for field in ('axes','protocol'):
        if sha(root/spec[field]['path'])!=spec[field]['sha256']:raise ValueError('Frozen input changed: '+field)
    if sum(spec['allocations'].values())!=14_991_120 or sum(spec['allocations'].values())>15_000_000:raise ValueError('Allocation differs from prospective cap')


def authorization(root,spec_path,spec,approval_path,nodal_path,prerequisite_path):
    if any(p is None for p in (approval_path,nodal_path,prerequisite_path)):raise ValueError('Explicit ROOT pilot, nodal reuse and C09 prerequisite receipts required')
    a=json.loads(approval_path.read_text());n=json.loads(nodal_path.read_text());g=json.loads(prerequisite_path.read_text())
    if (a.get('approved') is not True or a.get('spec_sha256')!=sha(spec_path)
        or a.get('source_sha256')!=spec['source_sha256'] or 'pilot' not in a.get('stages',[])
        or a.get('pilot_CPU_seconds')!=spec['pilot_CPU_seconds'] or a.get('maximum_output_bytes')!=spec['maximum_output_bytes']
        or a.get('nodal_receipt_sha256')!=sha(nodal_path) or a.get('prerequisite_receipt_sha256')!=sha(prerequisite_path)):
        raise ValueError('ROOT review does not authorize these exact sources/caps/receipts')
    if (n.get('approved') is not True or n.get('scope')!='NODAL_ORFS_ONLY'
        or n.get('table_sha256')!=spec['nodal_table']['sha256']
        or n.get('mass_payload_sha256')!=spec['nodal_table']['mass_payload_sha256']
        or n.get('geometry_fixture_sha256')!=spec['physical_inputs']['C06_fixture']['sha256']
        or n.get('nodal_gates_pass') is not True or n.get('interpolation_approved') is not False
        or n.get('historical_interpolation_status')!='COMPONENT_ORF_TABLE_FAIL'
        or n.get('original_table_report_sha256')!=spec['nodal_table']['report_sha256']):
        raise ValueError('Separate nodal-only reuse identity is absent/incompatible')
    if g.get('approved') is not True or g.get('scope')!='C09_PREREQUISITE_FOR_C10':raise ValueError('C09 prerequisite is not reviewed for this stage')
    return a,n,g


@contextmanager
def lock(path):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a+b') as stream:
        fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:yield
        finally:fcntl.flock(stream,fcntl.LOCK_UN)


def main():
    p=argparse.ArgumentParser();p.add_argument('--spec',type=Path,required=True);p.add_argument('--root',type=Path,default=Path.cwd())
    p.add_argument('--execute',action='store_true');p.add_argument('--approval',type=Path);p.add_argument('--nodal-receipt',type=Path)
    p.add_argument('--prerequisite',type=Path);p.add_argument('--output',type=Path)
    args=p.parse_args();root=args.root.resolve();spec_path=args.spec.resolve();spec=json.loads(spec_path.read_text())
    if spec['schema']!='C10_EXACT_LIFECYCLE_CANDIDATE_v1':raise ValueError('Unknown lifecycle spec')
    validate_sources(root,spec)
    if not args.execute:
        print(json.dumps({'status':'SOURCE_METADATA_PASS_PHYSICAL_EXECUTION_NOT_REQUESTED','allocated_LL':sum(spec['allocations'].values()),'pending':spec['pending_ROOT_inputs'],'physical_calls':0},indent=2));return
    authorization(root,spec_path,spec,args.approval,args.nodal_receipt,args.prerequisite)
    if args.output is None:raise ValueError('New output directory required')
    output=args.output.resolve()
    if not output.is_relative_to(root/'tmp'):raise ValueError('Candidate outputs must remain under repository tmp')
    resource.setrlimit(resource.RLIMIT_CPU,(spec['pilot_CPU_seconds'],spec['pilot_CPU_seconds']))
    # Numeric and physical dependencies are imported only below all receipts.
    with lock(root/spec['resource_lock']):
        sys.path.insert(0,str(root/'src'))
        from lifecycle import execute
        with warnings.catch_warnings():
            warnings.simplefilter('error')
            execute(root,spec_path,spec,args.approval,args.nodal_receipt,output,START_CPU)
    validate_sources(root,spec)

if __name__=='__main__':main()
