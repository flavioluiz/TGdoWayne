"""Minimal persistence extension of immutable nodal guard v2, no formula changes.

Source function copied from nodal_runner.py; imports its guards/identity types.
Each batch is flushed to its sole .npy file, with NaN marking missing entries.
No retry/resume or success receipt is inferred from a partial array.
"""
import json
from pathlib import Path
import numpy as np
from nodal_runner import axis,axis_hash,allocation_preflight,ReuseSource
from selected_kernel import selected_models
from physical import sha as hash_file

def run_grid_preserved(engine,covariance_at_mass,masses,epsilons,*,models,data_ids,identity,
             ledger,stage,output_path,maximum_workspace_bytes,additional_resident_bytes,epsilon_batch=129,reuse=None):
    names=selected_models(models);u=axis(masses);e=axis(epsilons)
    if np.any((u<.001)|(u>1)) or np.any((e<0)|(e>1)):raise ValueError('Physical prior support differs')
    if type(epsilon_batch) is not int or epsilon_batch<1 or epsilon_batch>257:raise ValueError('Explicit batch <=257 required')
    ids=tuple(data_ids)
    if len(ids)!=engine.R or len(set(ids))!=len(ids):raise ValueError('Distinct data IDs matching engine.R required')
    required=('nodal_component_sha256','kernel_sha256','generation_sha256','fixed_nuisance_sha256','response','harmonic_level')
    if not isinstance(identity,dict) or any(not isinstance(identity.get(k),str) or not identity[k] for k in required):raise ValueError('Complete exact-node identity required')
    shape=(len(u),len(e),len(names),engine.R)
    old=None;axis_bytes=u.nbytes+e.nbytes
    if reuse is not None:
        if not isinstance(reuse,ReuseSource) or reuse.identity!=identity or tuple(reuse.models)!=names:raise ValueError('Reuse identity/models mismatch')
        old_u=axis(reuse.mass);old_e=axis(reuse.epsilon);old_ids=tuple(reuse.data_ids)
        if not isinstance(reuse.values,np.ndarray):raise ValueError('Reuse must be an existing ndarray; no hidden bulk conversion')
        old=reuse.values
        if old.dtype.kind!='f' or old.shape!=(len(old_u),len(old_e),len(names),len(old_ids)) or len(set(old_ids))!=len(old_ids):raise ValueError('Invalid cached grid')
        axis_bytes+=old_u.nbytes+old_e.nbytes
        if any(i not in old_ids for i in ids):raise ValueError('New data cannot inherit cached densities')
    memory=allocation_preflight(engine,shape,epsilon_batch=epsilon_batch,reuse_values=old,new_axis_bytes=axis_bytes,
          maximum_workspace_bytes=maximum_workspace_bytes,additional_resident_bytes=additional_resident_bytes)
    if old is not None and not np.isfinite(old).all():raise ValueError('Nonfinite cached grid')
    output_path=Path(output_path)
    if output_path.exists():raise FileExistsError('Preserve prior grid; no retry')
    output=np.lib.format.open_memmap(output_path,mode='w+',dtype=np.float64,shape=shape)
    output[:]=np.nan;output.flush()
    completed=False;failure=None
    try:
        reused=0
        if reuse is not None:
            columns=[old_ids.index(i) for i in ids]
            upos={float(x).hex():i for i,x in enumerate(u)};epos={float(x).hex():i for i,x in enumerate(e)}
            for i,x in enumerate(old_u):
                if float(x).hex() not in upos:continue
                for j,y in enumerate(old_e):
                    if float(y).hex() in epos:
                        output[upos[float(x).hex()],epos[float(y).hex()]]=old[i,j][:,columns]
                        reused+=len(names)*engine.R
        before=sum(ledger.state['charged'].values())
        for i,mass in enumerate(u):
            missing=np.flatnonzero(np.isnan(output[i,:,0,0]))
            if not len(missing):continue
            C0,C1=covariance_at_mass(float(mass))
            for start in range(0,len(missing),epsilon_batch):
                idx=missing[start:start+epsilon_batch];count=len(idx)*len(names)*engine.R
                def evaluate():return engine.evaluate(C0,C1,e[idx],models=names)[0]
                values=ledger.evaluate(stage,count,evaluate)
                if values.shape!=output[i,idx].shape or not np.isfinite(values).all():raise ArithmeticError('Selected output contract mismatch')
                output[i,idx]=values
                output.flush()
        if not np.isfinite(output).all():raise ArithmeticError('Grid coverage incomplete')
        report={'status':'NODAL_LOG_LIKELIHOODS_COMPLETE_NOT_POSTERIOR_APPROVAL',
                'mass_axis_sha256':axis_hash(u),'epsilon_axis_sha256':axis_hash(e),
                'data_ids':list(ids),'models':list(names),'identity':dict(identity),
                'values_reused_exact_identity':reused,'new_values_charged':sum(ledger.state['charged'].values())-before,
                'interpolated_ORF':False,'output_shape':list(output.shape),'allocation_preflight':memory}
        completed=True
        return ReuseSource(u,e,output,dict(identity),ids,names),report
    except Exception as exc:
        failure=type(exc).__name__+': '+str(exc)
        raise
    finally:
        output.flush()
        state={'schema':'C10_PERSISTENT_GRID_STATE_v1',
               'status':'COMPLETE' if completed else 'FAILED_PARTIAL_PRESERVED_NO_RETRY',
               'failure':failure,'path':str(output_path),'shape':list(shape),
               'complete_value_count':int(np.isfinite(output).sum()),'missing_values_are_NaN':True,
               'identity':identity,'models':list(names),'data_ids':list(ids),
               'mass_axis_sha256':axis_hash(u),'epsilon_axis_sha256':axis_hash(e),
               'sha256':hash_file(output_path),'allocation_preflight':memory}
        with output_path.with_suffix('.state.json').open('x') as stream:
            json.dump(state,stream,indent=2,allow_nan=False);stream.write('\n')
