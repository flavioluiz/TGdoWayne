"""Freeze metadata only. Does not read any physical array/table or construct a bank."""
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def binding(p):return {'path':str(p.relative_to(ROOT)),'sha256':sha(p)}
old=json.loads((ROOT/'tmp/c10_exact_selected_preflight_v1/preflight_ready.json').read_text())
validation=json.loads((HERE/'validation.json').read_text())
alloc=dict(old['resources']['likelihood_allocations']);alloc['four_product_references']=1_361_808;alloc['epsilon_event_references']=5_287_680
assert sum(alloc.values())==14_991_120
source_files=list(HERE.rglob('*.py'))
source_files += [ROOT/p for p in (
'src/inference/__init__.py','src/inference/orf_blas.py',
'src/pta/__init__.py','src/pta/_domain.py','src/pta/response.py','src/pta/orf.py','src/pta/validation.py','src/pta/statistics.py','src/pta/simulation.py',
'configs/experiments/c06_moments.json',
'tmp/c10_scalar_blas/src/inference/scalar_blas.py',
'tmp/c10_execution_design/c10_protocol_candidate_v1.json',
'tmp/c10_execution_design/PROTOCOLO_CANDIDATO_REVISADO.md',
'tmp/c10_orf_preflight/results/table.json','tmp/c10_orf_preflight/results/probes.json',
'tmp/c10_orf_preflight/results/ROOT_approval_table_v1.json','tmp/c10_orf_preflight/results/ROOT_approval_probes_v1.json',
'tmp/c10_nodal_guard_v2/manifest.json','tmp/c10_ROOT_component/nodal_guard_v2_review.json',
'tmp/c10_ROOT_component/nodal_reuse_review_v1.json','tmp/c10_ROOT_component/review_nodal_reuse.py',
'tmp/c10_selected_kernel_candidate/manifest.json',
'tmp/c10_exact_selected_preflight_v1/preflight_ready.json','tmp/c10_exact_selected_preflight_v1/validation.json',
'tmp/c10_bilinear_v3/validation.json')]
sources={str(p.relative_to(ROOT)):sha(p) for p in sorted(set(source_files)) if '__pycache__' not in p.parts}
# Count uncompressed values plus fixed report/header envelopes; no compression credit.
components={
'all_master_and_new_Gamma_archive':52_608_000,
'new_Gamma_children_npy_in_addition_to_archive':27_984_000+3*128,
'fine_grids':4_774_032*8,
'high_grids_including_reused_values':513*257*4*9*8,
'product_reference_grids_with_edges':386*98*4*9*8,
'slice_logL_and_epsilon_cache_values':20_736*255*2*8,
'slice_NPZ_container_header_allowance':20_736*1024,
'slice_JSON_cap_enforced_per_file':20_736*16*1024,
'other_sources_axes_generation_controls_reports_reserve':64*1024**2}
assert sum(components.values())<1024**3
spec={
'schema':'C10_EXACT_LIFECYCLE_CANDIDATE_v1','status':'SOURCE_AND_SYNTHETIC_PREPARATION_ONLY_PENDING_ROOT_PILOT_REVIEW',
'axes':binding(HERE/'axes.json'),'protocol':binding(ROOT/'tmp/c10_execution_design/c10_protocol_candidate_v1.json'),
'source_sha256':sources,'selected_kernel_sha256':sha(HERE/'selected_kernel.py'),
'dependencies':{'numpy':'2.4.3','scipy':'1.17.1'},
'allocations':alloc,'maximum_logL_values':15_000_000,'unallocated_no_automatic_reuse':8880,
'allocation_delta':{'previous_ready_sha256':sha(ROOT/'tmp/c10_exact_selected_preflight_v1/preflight_ready.json'),
'product_boundary_values_added':34704,'slice_cap_previous':256,'slice_cap_current':255,'slice_values_removed':20736,'net_added':13968},
'pilot_CPU_seconds':1800,'historical_ORF_CPU_seconds':133.905984,'combined_ORF_CPU_seconds':600,
'maximum_RSS_bytes':4*1024**3,'maximum_ORF_RSS_bytes':512*1024**2,'maximum_nodal_numeric_bytes':512*1024**2,'maximum_output_bytes':1024**3,
'roundoff_logL_allowance':1e-10,
'roundoff_scope':'Explicit ordinary-float allowance checked against existing independent SciPy controls and synthetic matrix-envelope tests; not directed rounding or physical global accuracy',
'harmonic_resolutions':old['resources']['ORF']['resolutions'],
'nodal_table':{'path':'tmp/c10_orf_preflight/results/table.npz','sha256':old['nodal_reuse']['table_sha256_from_preserved_metadata'],
'mass_payload_sha256':'b28b764c1470f1ab70a3f37d1029913288a032a993e9945d537acaaf91746ffa',
'report_path':'tmp/c10_orf_preflight/results/table.json','report_sha256':sha(ROOT/'tmp/c10_orf_preflight/results/table.json'),
'historical_status':'COMPONENT_ORF_TABLE_FAIL','reused_nodes_only':True,'linear_interpolation_forbidden':True,'payload_not_read_or_rehashed_during_preparation':True},
'physical_inputs':{'C06_fixture':{'path':'results/C06/massive/fixture.npz','sha256':'94a7a553fe52224525de30a78782afa45e64def0bd1c870f24121d563b1c8d0a','payload_not_read_during_preparation':True}},
'resource_lock':'tmp/c10_exact_lifecycle_resource.lock',
'counts':{'pilot_data':16,'reference_data':4,'scientific_models':9,'new_exact_mass_nodes':583,'new_ORF_mode_matrices':17490,'event_slices':20736,
'event_cache_values_per_slice':255,'existing_control_values_used_to_test_H_bounds':4608,
'main_uniform_epsilon_H_bounds':41472,'total_H_bounds_including_finite_controls':46080,
'fine_and_coarse_bilinear_summaries':288,'high_and_product_bilinear_summaries':72,
'new_sky_points':0,'historical_sky_points':50_240_000,'historical_sky_cap':70_000_000,
'new_BLAS_real_multiplication_proxy':162_540_400_000,'new_contraction_real_proxy':6_716_160_000,
'ORF_children_sequential':3,'threads_per_process':1,'Fisher_or_500_campaign_values':0},
'memory_phase_proof':{'ORF_child_output_bytes':27_984_000//3,'ORF_child_explicit_basis_caps_sum':256*1024**2,
'ORF_child_other_array_allowance':64*1024**2,'parent_ORF_loading_peak_numeric_upper_estimate':160*1024**2,
'parent_posterior_numeric_upper_estimate':256*1024**2,'known_external_arrays_passed_to_nodal_guard':'gamma; product adds still-live fine and high grids; reuse is counted by guard',
'one_slice_at_a_time':True,'retained_up_to_384_JSON_reports_bytes':384*16384,
'estimates_not_RSS_certificate':True,'target_RSS_bytes':2*1024**3,'measured_RSS_is_monitored':True},
'disk':{'uncompressed_component_envelopes_bytes':components,'sum_bytes':sum(components.values()),'compression_credit':0,
'cap_bytes':1024**3,'per_slice_JSON_rejected_above_bytes':16384,'failed_and_partial_outputs_preserved':True},
'CPU_forecast':validation['timing'],'synthetic_validation':binding(HERE/'validation.json'),
'operational_rules':{'epsilon_cell_root_count_assumption':None,'CDF_tolerance':.002,'ambiguity_goal':.001,'logZ_tolerance':.001,'logBF_tolerance':.002,'quantile_prior_width_tolerance':.001,
'event_shift':'delta_node plus delta_truth before classification','mass_shift':'exp(+/-delta_node) on unnormalized N/A/Z before du-weighted sums',
'u_rules':'192 and384 positive independent GL; common prior normalization; aggregate masses with each slice log shift',
'missing_own_Z':'entire two-dimensional result UNRESOLVED [0,1]',
'slice_failure':'retain full support via ambiguous mass or conservative [0,1]; no retry, reseed or hidden extra reference values',
'finite_H_convergence_not_physical_uniform_certificate':True,'warnings':'exceptions preserved with failed output',
'completion_status_not_production_approval':True},
'available_nodal_only_receipt':binding(ROOT/'tmp/c10_ROOT_component/nodal_reuse_review_v1.json'),
'pending_ROOT_inputs':['Exact-spec/source pilot authorization with proposed1800s CPU and1GiB disk caps',
'C09 prerequisite review receipt scoped to C10 pilot','Independent ROOT review of integrated lifecycle and finite controls'],
'physical_ORF_calls_executed_in_preparation':0,'physical_logL_values_executed_in_preparation':0,'physical_draws_executed_in_preparation':0,'bank_constructed':False,
'physical_global_error_certificate':False,'production500_authorized':False}
(HERE/'execution_spec.json').write_text(json.dumps(spec,indent=2,allow_nan=False)+'\n')
print(json.dumps({'source_bindings':len(sources),'spec_sha256':sha(HERE/'execution_spec.json'),'allocated_LL':sum(alloc.values()),'disk_estimate_bytes':sum(components.values()),'CPU_heuristic_seconds':validation['timing']['combined_candidate_estimate_seconds'],'physical_calls':0},indent=2))
