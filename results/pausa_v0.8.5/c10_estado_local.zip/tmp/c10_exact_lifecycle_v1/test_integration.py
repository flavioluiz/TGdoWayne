import math
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from selected_kernel import ConditionalLikelihood
from harmonic_margin import polynomial_pair,uniform_loglike_difference,event_level
from aggregate import aggregate_slices,compare_u_rules
from run import authorization
from references import product_log_evidence
from persistent_grid import run_grid_preserved
from nodal_runner import run_grid
from ledger import GlobalLedger


def synthetic(P=3,K=2,D=3):
    rng=np.random.default_rng(910100501);z=rng.normal(size=(K,P,P))+1j*rng.normal(size=(K,P,P))
    c0=z@z.swapaxes(-1,-2).conj()+np.eye(P);z=rng.normal(size=(K,P,P))+1j*rng.normal(size=(K,P,P));c1=.1*(z@z.swapaxes(-1,-2).conj())
    h=np.stack([np.diag(np.eye(P)[i]) for i in range(D)]).astype(complex)
    q=rng.normal(size=(1,K,P))+1j*rng.normal(size=(1,K,P));x=rng.normal(size=(1,K,D));g=rng.normal(size=(1,K,D))
    e=ConditionalLikelihood(q,x,g,h,np.ones(K)/K,maximum_logl_values=100000)
    return e,c0,c1


def row(Z,event,shift=0.,valid=True):
    c={'roundoff_allowance_validated':valid,'same_node_covariance_reference_validated':valid}
    return {'status':'SLICE_TEST','controls':c,'log_shift':shift,'denominator':{'lower':Z,'value':Z,'upper':Z},
            'numerator_references':{'inside':{'lower':Z*event,'upper':Z*event},'ambiguous':{'lower':0.,'upper':0.}}}
GOOD={'same_node_reference':True,'roundoff':True,'harmonic_level_enclosure':True}


class IntegrationTests(unittest.TestCase):
    def test_uniform_level_bound_all_selected_laws_dense_epsilon(self):
        e,c0,c1=synthetic();a=c0+1e-4*np.eye(3)[None];b=c1*1.0002
        for name in ('A0_CN','A_CN','B_CN','A_G','B_G'):
            bound=uniform_loglike_difference(polynomial_pair(e,c0,c1,name),polynomial_pair(e,a,b,name),normal=name!='A0_CN',roundoff_allowance=1e-12)
            self.assertIsNotNone(bound['delta_loglike'])
            eps=np.linspace(0.,1.,101);f=e.evaluate(c0,c1,eps,models=(name,))[0];g=e.evaluate(a,b,eps,models=(name,))[0]
            self.assertLessEqual(float(np.max(abs(f-g))),bound['delta_loglike'])
    def test_anchor_correction_does_not_modify_model(self):
        e,c0,c1=synthetic();c1=-.01*c0;old=c1.copy()
        f=polynomial_pair(e,c0,np.zeros_like(c1),'A0_CN');f=(np.stack((c0,c1)),None,f[2])
        other=(np.stack((c0+.001*np.eye(3),c1)),None,f[2])
        bound=uniform_loglike_difference(f,other,normal=False,roundoff_allowance=0.)
        self.assertGreater(max(bound['anchor_negative_coefficient_correction']),0)
        np.testing.assert_array_equal(c1,old)
    def test_mass_weighted_aggregation_not_uniform_conditional_mean(self):
        r=aggregate_slices([row(1.,0.),row(9.,1.)],[.5,.5],[0.,0.],controls=GOOD)
        np.testing.assert_allclose(r['candidate_interval'],[.9,.9],atol=2e-16)
        scaled=aggregate_slices([row(1.,0.),row(1.,1.,math.log(9.))],[.5,.5],[0.,0.],controls=GOOD)
        np.testing.assert_allclose(scaled['candidate_interval'],r['candidate_interval'],atol=2e-16)
    def test_unresolved_numerator_and_missing_own_denominator(self):
        unknown=row(9.,1.);unknown['numerator_references']={};unknown['failure_preserved']='TOY budget'
        r=aggregate_slices([row(1.,0.),unknown],[.5,.5],[0.,0.],controls=GOOD)
        np.testing.assert_allclose(r['candidate_interval'],[0.,.9],atol=2e-16)
        self.assertEqual(r['interval'],[0.,1.]);unknown['denominator']=None
        r=aggregate_slices([row(1.,0.),unknown],[.5,.5],[0.,0.],controls=GOOD)
        self.assertEqual(r['interval'],[0.,1.]);self.assertEqual(r['missing_denominator_nodes'],[1])
    def test_bad_denominator_and_unvalidated_slice_cannot_pass_global_flags(self):
        for den in ({'lower':math.inf,'value':1.,'upper':2.},{'lower':2.,'value':1.,'upper':3.},{'lower':1.,'value':4.,'upper':3.}):
            x=row(1.,.5);x['denominator']=den
            r=aggregate_slices([x],[1.],[0.],controls=GOOD);self.assertEqual(r['interval'],[0.,1.])
        r=aggregate_slices([row(1.,.5,valid=False)],[1.],[0.],controls=GOOD)
        self.assertFalse(r['finite_controls_pass']);self.assertEqual(r['interval'],[0.,1.])
    def test_exponential_weight_margin_and_u_rule_hull(self):
        r=aggregate_slices([row(1.,.5)],[1.],[.1],controls=GOOD)
        np.testing.assert_allclose(r['candidate_interval'],[.5*math.exp(-.2),.5*math.exp(.2)])
        f=aggregate_slices([row(1.,.5002)],[1.],[0.],controls=GOOD);c=aggregate_slices([row(1.,.5)],[1.],[0.],controls=GOOD)
        gates=dict.fromkeys(('bilinear_comparison','underflow','threshold_reference','parameter_CDF_quantiles','warning_free'),True)
        z=compare_u_rules(c,f,original_gates=gates)
        np.testing.assert_allclose(z['interval'],[.5,.5002])
    def test_event_margin_moves_classification_not_only_weights(self):
        level=event_level(.5,.1,.02)
        self.assertAlmostEqual(level.lower,.38);self.assertAlmostEqual(level.upper,.62)
        # At this reference u, ell_H=ell_fine+.1 while the truth offset is zero.
        # Fine ell=.45 is inside its own threshold but cannot be certainly inside H.
        level=event_level(.5,.1,0.)
        self.assertGreater(.45,level.lower)
        self.assertLessEqual(.45,level.upper)
        self.assertLessEqual(.3,level.lower)
        for d in (-1.,math.inf):
            with self.assertRaises(ValueError):event_level(.5,d,0.)

    def test_missing_authorization_before_numeric_physical_entry(self):
        with self.assertRaises(ValueError):authorization(Path('.'),Path('unused'),{},None,None,None)

    def test_product_evidence_weights_not_renormalized_in_repeated_summaries(self):
        u=np.array([.2,.8]);v=np.array([.1,.3,.6]);u0=u.copy();v0=v.copy()
        for _ in range(16):
            a,b=product_log_evidence(np.full((2,3),2.),np.full(2,3.),u,v)
            self.assertAlmostEqual(a,2.);self.assertAlmostEqual(b,3.)
        np.testing.assert_array_equal(u,u0);np.testing.assert_array_equal(v,v0)
        with self.assertRaises(ValueError):product_log_evidence(np.zeros((2,3)),np.zeros(2),u,v/2)

    def test_persistent_grid_matches_frozen_and_preserves_partial_values(self):
        e,c0,c1=synthetic();identity={k:'TOY' for k in ('nodal_component_sha256','kernel_sha256','generation_sha256','fixed_nuisance_sha256','response','harmonic_level')}
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)
            def ledger(name):return GlobalLedger(p/name,identity='TOY',allocations={'grid':20},maximum_values=20,maximum_cpu_seconds=5.)
            kw=dict(models=('A0_CN',),data_ids=[0],identity=identity,stage='grid',maximum_workspace_bytes=32*1024**2,additional_resident_bytes=0,epsilon_batch=2)
            reference,_=run_grid(e,lambda u:(c0,c1),[.001,.5],[0.,.5,1.],ledger=ledger('frozen.json'),**kw)
            saved,_=run_grid_preserved(e,lambda u:(c0,c1),[.001,.5],[0.,.5,1.],ledger=ledger('new.json'),output_path=p/'success.npy',**kw)
            np.testing.assert_array_equal(saved.values,reference.values)
            self.assertEqual(json.loads((p/'success.state.json').read_text())['status'],'COMPLETE')
            calls=[]
            def fail_second(u):
                calls.append(u)
                if len(calls)==2:raise RuntimeError('TOY producer failure')
                return c0,c1
            with self.assertRaises(RuntimeError):run_grid_preserved(e,fail_second,[.001,.5],[0.,.5,1.],ledger=ledger('partial.json'),output_path=p/'partial.npy',**kw)
            partial=np.load(p/'partial.npy');np.testing.assert_array_equal(partial[0],reference.values[0]);self.assertTrue(np.isnan(partial[1]).all())
            state=json.loads((p/'partial.state.json').read_text());self.assertEqual(state['complete_value_count'],3);self.assertEqual(state['status'],'FAILED_PARTIAL_PRESERVED_NO_RETRY')
            with self.assertRaises(FileExistsError):run_grid_preserved(e,lambda u:(c0,c1),[.001,.5],[0.,.5,1.],ledger=ledger('retry.json'),output_path=p/'partial.npy',**kw)

    def test_persistent_grid_cap_precedes_file_and_callbacks(self):
        e,c0,c1=synthetic();identity={k:'TOY' for k in ('nodal_component_sha256','kernel_sha256','generation_sha256','fixed_nuisance_sha256','response','harmonic_level')}
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);ledger=GlobalLedger(p/'ledger.json',identity='TOY',allocations={'grid':20},maximum_values=20,maximum_cpu_seconds=5.)
            with patch.object(e,'evaluate',side_effect=AssertionError('kernel called')),patch('numpy.lib.format.open_memmap',side_effect=AssertionError('allocated')):
                with self.assertRaises(RuntimeError):run_grid_preserved(e,lambda u:(_ for _ in ()).throw(AssertionError('producer called')),[.001,.5],[0.,.5],models=('A0_CN',),data_ids=[0],identity=identity,ledger=ledger,stage='grid',output_path=p/'bad.npy',maximum_workspace_bytes=1,additional_resident_bytes=0)
            self.assertFalse((p/'bad.npy').exists());self.assertEqual(ledger.state['charged']['grid'],0)

if __name__=='__main__':unittest.main(verbosity=2)
