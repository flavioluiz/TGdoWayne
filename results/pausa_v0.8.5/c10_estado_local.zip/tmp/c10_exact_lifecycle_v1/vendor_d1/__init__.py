"""Frozen algebraic sources from C09; no C09 execution or physical response imported."""
