"""Physical input construction, imported only after exact ROOT authorization."""
import hashlib
import json
from pathlib import Path
import numpy as np
from selected_kernel import ConditionalLikelihood

ROUTES={'D':(('A0_CN','A_CN','B_CN','A_G','B_G'),(0,1,2)),
        'C_beta':(('B_CN','B_G'),(0,3,4)),
        'C_full':(('B_CN','B_G'),(0,0,0))}
LABELS={'D':('A0_CN','A_CN','B_CN','A_G','B_G'),
        'C_beta':('C_beta_CN','C_beta_G'),'C_full':('C_full_CN','C_full_G')}


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024**2),b''):h.update(chunk)
    return h.hexdigest()


def load_geometry(root,spec):
    source=root/spec['physical_inputs']['C06_fixture']['path']
    if sha(source)!=spec['physical_inputs']['C06_fixture']['sha256']:raise ValueError('C06 fixture identity mismatch')
    with np.load(source,allow_pickle=False) as data:
        names=('directions','distances_m','frequencies_hz','fixed_scale_psd_seconds_cubed','estimator_matrices','frequency_weights')
        geometry={name:np.array(data[name],copy=True) for name in names}
    for value in geometry.values():
        if not np.isfinite(value).all():raise ValueError('Nonfinite geometry metadata')
    if geometry['directions'].shape!=(10,3) or geometry['estimator_matrices'].shape!=(10,10,10):raise ValueError('C06 P10/D10 geometry required')
    geometry['phases']=2*np.pi*geometry['frequencies_hz'][:,None]*geometry['distances_m'][None,:]/299792458.
    if np.max(geometry['phases'])>120*np.pi*(1+1e-13):raise ValueError('C06 phase envelope exceeded')
    return geometry


class NodalCovariances:
    def __init__(self,masses,gamma,geometry,protocol,c06_config):
        from pta.simulation import residual_power_spectrum
        self.mass=np.asarray(masses,float);self.gamma=np.asarray(gamma)
        if self.gamma.shape!=(3,len(self.mass),5,2,10,10) or self.gamma.dtype!=np.complex128 or not np.isfinite(self.gamma).all():raise ValueError('Complete exact nodal component required')
        self.index={float(u).hex():i for i,u in enumerate(self.mass)}
        if len(self.index)!=len(self.mass):raise ValueError('Duplicate nodal coordinates')
        g=geometry;f=g['frequencies_hz'];n=protocol['nuisance'];scale=g['fixed_scale_psd_seconds_cubed']
        self.signal=residual_power_spectrum(f,n['log10_AT'],n['gamma'])/scale
        red=residual_power_spectrum(f,n['log10_Ar'],n['red_gamma'])
        geo=c06_config['geometry'];sigma=np.array(geo['nominal_toa_sigma_nanoseconds'])*1e-9
        pattern=np.array(geo['red_amplitude_pattern']);dt=15*365.25*86400/392
        self.noise=(red[:,None]*pattern[None]**2+2*(n['EFAC']*sigma[None])**2*dt)/scale[:,None]
        self.geometry=geometry

    def __call__(self,u,response='D',level=2):
        if response not in ROUTES or type(level)is not int or not 0<=level<3:raise ValueError('Explicit response/level required')
        try:i=self.index[float(u).hex()]
        except KeyError:raise ValueError('No exact nodal ORF for requested mass; interpolation is forbidden')
        _,mapping=ROUTES[response];G=self.gamma[level,i,list(mapping)]
        c0=self.signal[:,None,None]*G[:,0];c1=self.signal[:,None,None]*G[:,1]
        idx=np.arange(10);c0[:,idx,idx]+=self.noise
        np.linalg.cholesky(c0)
        return c0,c1


def generate_pilot(provider,geometry,axes,output):
    from pta.simulation import paired_physical_and_gaussian
    rows=[]
    for record in axes['pilot_data']:
        c0,c1=provider(record['u'],'D',2)
        rng=np.random.default_rng(np.random.SeedSequence([axes['pilot_seed'],0,record['id']]))
        q,x,g=paired_physical_and_gaussian(c0+record['epsilon']*c1,geometry['estimator_matrices'],1,rng)
        rows.append((q[0],x[0],g[0]))
    q,x,g=(np.stack([row[i] for row in rows]) for i in range(3))
    np.savez_compressed(output,q=q,x=x,g=g,truth=np.array([[r['u'],r['epsilon']] for r in axes['pilot_data']]),ids=np.array([r['id'] for r in axes['pilot_data']]))
    return q,x,g


def engine_for(data,geometry,indices):
    q,x,g=data;idx=list(indices)
    return ConditionalLikelihood(q[idx],x[idx],g[idx],geometry['estimator_matrices'],geometry['frequency_weights'],
                                 maximum_logl_values=15_000_000,maximum_workspace_bytes=256*1024**2)
