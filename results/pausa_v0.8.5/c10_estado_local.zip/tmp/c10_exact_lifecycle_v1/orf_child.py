"""One fresh harmonic-resolution process; never invoked by preparation/tests."""
import argparse
import json
import math
import os
from pathlib import Path
import resource
import sys
import time
START=0.0


def main():
    p=argparse.ArgumentParser();p.add_argument('--task',type=Path,required=True);a=p.parse_args()
    task=json.loads(a.task.read_text());root=Path(task['root']);here=Path(__file__).resolve().parent
    if task.get('authorized_child') is not True:raise ValueError('Authorized parent task required')
    approval_file=Path(task['approval_path'])
    import hashlib
    if hashlib.sha256(approval_file.read_bytes()).hexdigest()!=task['approval_sha256']:raise ValueError('Parent approval binding mismatch')
    approval=json.loads(approval_file.read_text())
    if approval.get('approved') is not True or approval.get('spec_sha256')!=task['spec_sha256'] or 'pilot' not in approval.get('stages',[]):raise ValueError('ROOT pilot authorization required')
    for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
        if os.environ.get(name)!='1':raise ValueError('One BLAS thread required')
    resource.setrlimit(resource.RLIMIT_CPU,(max(1,math.ceil(task['CPU_seconds'])),max(1,math.ceil(task['CPU_seconds']))))
    sys.path[:0]=[str(root/'src'),str(here),str(root/'tmp/c10_scalar_blas/src/inference')]
    import numpy as np
    from inference.orf_blas import RealHarmonicBasis,TableBudget
    from scalar_blas import RealScalarHarmonicBasis,ScalarTableBudget
    from physical import load_geometry,sha
    spec=json.loads((root/task['spec']).read_text())
    if sha(root/task['spec'])!=task['spec_sha256']:raise ValueError('Child spec mismatch')
    for path,digest in spec['source_sha256'].items():
        if sha(root/path)!=digest:raise ValueError('Child source mismatch')
    axes=json.loads((root/spec['axes']['path']).read_text())
    if sha(root/spec['axes']['path'])!=spec['axes']['sha256'] or task['masses']!=axes['new_mass_nodes_requiring_explicit_harmonics'] or task['resolution'] not in spec['harmonic_resolutions']:raise ValueError('Child axes/resolution differs from approved spec')
    if not 0<task['CPU_seconds']<=600-spec['historical_ORF_CPU_seconds']:raise ValueError('Child exceeds inherited remaining ORF cap')
    if not Path(task['output']).resolve().is_relative_to(root/'tmp'):raise ValueError('Child output outside prospective temporary workspace')
    geometry=load_geometry(root,spec);u=np.array(task['masses']);r=task['resolution'];B=8
    shape=(len(u),5,2,10,10);estimated=math.prod(shape)*16+64*1024**2
    if estimated>512*1024**2:raise RuntimeError('Child arrays exceed ORF cap')
    tt=RealHarmonicBasis(geometry['directions'],lmax=r['lmax'],nmu=r['nmu'],budget=TableBudget(maximum_estimated_memory_bytes=128*1024**2),planned_batch=B)
    fp=RealScalarHarmonicBasis(geometry['directions'],lmax=r['lmax'],nmu=r['nmu'],budget=ScalarTableBudget(maximum_estimated_memory_bytes=128*1024**2),planned_batch=B)
    output=Path(task['output'])
    if output.exists():raise FileExistsError('Preserve earlier harmonic file; no retry')
    out=np.lib.format.open_memmap(output,mode='w+',dtype=np.complex128,shape=shape)
    out[:]=complex(float('nan'),float('nan'));out.flush();work=0;completed=False;failure=None
    try:
        for case,(k,phase_index) in enumerate(((1,0),(2,1),(3,2),(1,1),(1,2))):
            for start in range(0,len(u),B):
                stop=min(start+B,len(u));beta=np.sqrt((1-u[start:stop]/k)*(1+u[start:stop]/k))
                work+=2*(stop-start)*10*r['nmu']*(2*r['lmax'])
                out[start:stop,case,0]=tt.evaluate(beta,geometry['phases'][phase_index])
                out[start:stop,case,1]=fp.evaluate(beta,geometry['phases'][phase_index])
                out.flush()
                rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)
                if rss>512*1024**2 or time.process_time()-START>task['CPU_seconds']:raise RuntimeError('ORF CPU/RSS guard')
        eig=np.linalg.eigvalsh(out);scale=np.maximum(np.max(abs(eig),axis=-1),np.finfo(float).tiny)
        if not np.isfinite(out).all() or np.min(eig[...,0]/scale)<-1e-10:raise ArithmeticError('Nodal PSD/finitude failed')
        completed=True
    except Exception as exc:
        failure=type(exc).__name__+': '+str(exc)
        raise
    finally:
        out.flush()
        record={'status':'NEW_HARMONIC_NODES_COMPLETE_NOT_POSTERIOR_APPROVAL' if completed else 'FAILED_PARTIAL_HARMONIC_NODES_PRESERVED',
                'failure':failure,'missing_entries_are_NaN':True,'complete_entries':int(np.isfinite(out).sum()),
                'CPU_seconds_internal_before_exit':time.process_time()-START,
                'RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024),
                'shape':list(out.shape),'sha256':sha(output),'real_BLAS_proxy':work,'sky_points':0,'logL_values':0}
        output.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')

if __name__=='__main__':main()
