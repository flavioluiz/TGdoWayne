"""Whole-epsilon polynomial-cell classification, not root counting.

Exact-arithmetic inequalities from C09 are evaluated in ordinary float64.
GL16/32 differences are operational quadrature diagnostics, not rigorous bounds.
No ORF, C09 runtime, physical data or posterior bank is loaded by this module.
"""
from dataclasses import dataclass
import math
import numpy as np
from scipy.special import roots_legendre
from ledger import CapacityExceeded
from vendor_d1.polynomial import restrict,compress_coefficients
from vendor_d1.envelope import cn_envelope,normal_envelope,LogRange


@dataclass(frozen=True)
class EpsilonCell:
    left:float
    right:float
    enclosure:LogRange
    lower_mass:float
    upper_mass:float
    depth:int


def classified(cell,level):
    if cell.enclosure.upper<=level.lower:return 'inside'
    if cell.enclosure.lower>level.upper:return 'outside'
    return 'ambiguous'


def cover(cells):
    if not cells or cells[0].left!=0 or cells[-1].right!=1:raise ValueError('Incomplete epsilon support')
    for c in cells:
        if not 0<=c.left<c.right<=1 or not 0<=c.lower_mass<=c.upper_mass or not math.isfinite(c.upper_mass):raise ValueError('Invalid cell')
    if any(a.right!=b.left for a,b in zip(cells[:-1],cells[1:])):raise ValueError('Gap/overlap')


class PolynomialEvent:
    def __init__(self,engine,C0,C1,model,*,roundoff_allowance):
        if engine.R!=1:raise ValueError('Scalar event requires a one-observation engine; no hidden discarded logL')
        if model not in ('A0_CN','A_CN','B_CN','A_G','B_G'):raise ValueError('Unknown selected law')
        if isinstance(roundoff_allowance,bool) or not isinstance(roundoff_allowance,(int,float)) or not math.isfinite(roundoff_allowance) or roundoff_allowance<0:raise ValueError('Explicit finite logL allowance required')
        c0,c1,basis,_=engine.moments(C0,C1)
        self.c=np.stack((c0,c1));m0,m1,s0,s1,s2=basis
        self.mu=np.stack((m0,m1));self.sigma=np.stack((s0,s1,s2))
        self.model=model;self.roundoff=float(roundoff_allowance);self.q=engine.q[0].copy()
        data=engine.gaussian if model.endswith('_G') else engine.physical
        self.y=data[0].copy()
        if model.startswith('B_'):
            self.mu,self.sigma=compress_coefficients(self.mu,self.sigma,engine.w)
            self.y=np.einsum('kd,k->d',self.y,engine.w)[None]

    def envelope(self,left,right,center_logl):
        if self.model=='A0_CN':
            return cn_envelope(restrict(self.c,left,right),self.q,center_logl,
                               roundoff_allowance=self.roundoff)
        return normal_envelope(restrict(self.mu,left,right),restrict(self.sigma,left,right),
                               self.y,center_logl,roundoff_allowance=self.roundoff)


def merged(cells,kind,level):
    out=[]
    for c in cells:
        if classified(c,level)!=kind:continue
        if out and out[-1][1]==c.left:out[-1]=(out[-1][0],c.right)
        else:out.append((c.left,c.right))
    return out


def integrate_regions(cache,regions,shift):
    """Fixed positive GL16/32, charged before scoring; no adaptive hidden calls."""
    results=[]
    for order in (16,32):
        if not regions:results.append(0.);continue
        nodes,weights=roots_legendre(order)
        points=np.concatenate([a+(b-a)*(nodes+1)/2 for a,b in regions])
        allweights=np.concatenate([(b-a)*weights/2 for a,b in regions])
        logs=cache(points)
        with np.errstate(over='raise',invalid='raise'):
            values=np.exp(logs-shift)
        results.append(float(np.dot(allweights,values)))
    value=results[-1];error=abs(results[-1]-results[0])
    if not math.isfinite(value+error):raise ArithmeticError('Nonfinite reference mass')
    return dict(value=value,lower=max(0.,value-error),upper=value+error,
                GL16=results[0],GL32=results[1],observed_difference=error,
                rigorous_error_bound=False)


def reference_slice(event,cache,level,*,maximum_splits=16,maximum_depth=16,
                    ambiguity_goal=.001,controls=None):
    """Return operational N/A/Z and a complete partition, or retained UNRESOLVED.

    The cache has an independent per-slice 256-value ceiling and a global ledger.
    No limit on the number of true roots is assumed, even after successful splits.
    """
    if not isinstance(level,LogRange) or not math.isfinite(level.lower+level.upper):raise ValueError('Finite threshold interval required')
    for n in (maximum_splits,maximum_depth):
        if type(n) is not int or n<0:raise ValueError('Explicit nonnegative split/depth limit required')
    if not math.isfinite(ambiguity_goal) or not 0<=ambiguity_goal<=1:raise ValueError('Invalid ambiguity goal')
    cells=[];den=None;shift=None;references={};splits=0
    report={'status':'UNRESOLVED','interval':[0.,1.],'candidate_interval':[0.,1.],
            'rigorous_floatingpoint_certificate':False,'uniform_physical_certificate':False,
            'epsilon_topology_from_root_count':False,'controls':controls or {}}
    try:
        center=float(cache(np.array([.5]))[0]);shift=center
        den=integrate_regions(cache,[(0.,1.)],shift)
        if den['lower']<=0:raise ArithmeticError('Reference denominator not bounded away from zero')
        def cell(a,b,depth):
            value=float(cache(np.array([a+(b-a)/2]))[0]);enclosure=event.envelope(a,b,value)
            lo=math.log(b-a)+enclosure.lower-shift
            hi=math.log(b-a)+enclosure.upper-shift
            lower=0. if lo==-math.inf else math.exp(lo)
            upper=den['upper'] if hi>=math.log(den['upper']) else math.exp(hi)
            if lower>upper:raise ArithmeticError('Envelope incompatible with denominator reference')
            return EpsilonCell(a,b,enclosure,lower,upper,depth)
        cells=[cell(0.,1.,0)];cover(cells)
        while splits<maximum_splits:
            ambiguous=[i for i,c in enumerate(cells) if classified(c,level)=='ambiguous']
            upper=math.fsum(cells[i].upper_mass for i in ambiguous)/den['lower']
            if upper<=ambiguity_goal:break
            eligible=[i for i in ambiguous if cells[i].depth<maximum_depth]
            if not eligible:break
            i=max(eligible,key=lambda j:(cells[j].upper_mass,-cells[j].left))
            c=cells[i];mid=c.left+(c.right-c.left)/2
            if mid in (c.left,c.right):break
            left=cell(c.left,mid,c.depth+1);right=cell(mid,c.right,c.depth+1)
            cells[i:i+1]=[left,right];splits+=1;cover(cells)
        # Reference the merged unions. If resources stop here the parent cells,
        # cache, numerator envelopes and whole-support ambiguity remain visible.
        for kind in ('inside','ambiguous'):
            references[kind]=integrate_regions(cache,merged(cells,kind,level),shift)
            lo=math.fsum(c.lower_mass for c in cells if classified(c,level)==kind)
            hi=math.fsum(c.upper_mass for c in cells if classified(c,level)==kind)
            if references[kind]['upper']<lo or references[kind]['lower']>hi:
                raise ArithmeticError('GL numerator incompatible with polynomial envelopes')
        N,A=references['inside'],references['ambiguous']
        outside_lo=math.fsum(c.lower_mass for c in cells if classified(c,level)=='outside')
        outside_hi=math.fsum(c.upper_mass for c in cells if classified(c,level)=='outside')
        if N['lower']+A['lower']+outside_lo>den['upper'] or N['upper']+A['upper']+outside_hi<den['lower']:
            raise ArithmeticError('Reference partition incompatible with total')
        lower=N['lower']/den['upper'];upper=min(1.,(N['upper']+A['upper'])/den['lower'])
        if lower>upper:raise ArithmeticError('Invalid event reference interval')
        ambiguity=A['upper']/den['lower']
        qerror=((N['upper']-N['lower'])+(A['upper']-A['lower'])+(den['upper']-den['lower']))/den['lower']
        required=('roundoff_allowance_validated','same_node_covariance_reference_validated')
        gate_controls=isinstance(controls,dict) and all(controls.get(k) is True for k in required)
        report.update(candidate_interval=[lower,upper],ambiguous_mass_upper=min(1.,ambiguity),
                      quadrature_operational_error=qerror,
                      slice_gates={'ambiguity':ambiguity<=ambiguity_goal,
                                   'observed_total_width':upper-lower<=.002,
                                   'quadrature_difference':qerror<=.00025,
                                   'finite_controls':gate_controls})
        if all(report['slice_gates'].values()):
            report.update(status='SLICE_OPERATIONAL_CONTROLS_PASS_NOT_2D_CDF_APPROVAL',interval=[lower,upper])
    except (CapacityExceeded,ArithmeticError,FloatingPointError,OverflowError,np.linalg.LinAlgError) as exc:
        report['failure_preserved']=type(exc).__name__+': '+str(exc)
    if cells:
        cover(cells)
        report['partition']=[{'left':c.left,'right':c.right,'depth':c.depth,
             'classification':classified(c,level),'logL_lower':c.enclosure.lower,
             'logL_upper':c.enclosure.upper,'mass_lower':c.lower_mass,'mass_upper':c.upper_mass} for c in cells]
    report.update(complete_epsilon_support=bool(cells),splits=splits,charged_values=cache.charged,
                  log_shift=shift,denominator=den,numerator_references=references,
                  remaining_2D_gates=['u192/u384 integration difference','H00/H01/H11 propagation',
                                      'bilinear-versus-direct comparison','underflow and finite precision checks'])
    return report
