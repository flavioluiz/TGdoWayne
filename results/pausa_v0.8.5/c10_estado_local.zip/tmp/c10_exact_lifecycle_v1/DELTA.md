# Delta final e checklist para ROOT

Fontes anteriores continuam intactas. Copiados byte a byte: kernel seletivo, guarda nodal v2, ledger, referência de evento em ε, serializador, Bernstein/envelopes D1 e referência bilinear v3. `manifest.json` registra origens/hashes.

O pacote novo acrescenta lifecycle físico, um processo por resolução harmônica, geração C06 condicionada, referências SciPy, agregação N/A/Z2D e margens uniformes em ε **entre níveis numéricos**. A persistência utiliza uma extensão separada `persistent_grid.py`; a guarda v2 não foi editada. O caminho de sucesso conserva apenas um .npy por grid. Dados ausentes permanecem NaN; relatório incompleto não concede reuso.

Achados corrigidos durante revisão, antes do congelamento:

1. Pesos GL96 não são mais modificados dentro do laço de resumos: eixos/pesos congelados e helper puro testado.
2. O evento recebe δnode+δtruth antes da classificação; exp(±δnode) aplica-se também às massas.
3. O agregador exige denominador próprio finito/ordenado e controles por fatia, além dos globais.
4. CPU ORF é debitada pelo delta externo RUSAGE_CHILDREN após cada subprocesso, inclusive falhas/saída/importações; tempo interno permanece separado.
5. Grids, nós novos, verdades e caches preservam valores parciais em exceções. Guardas de alocação precedem arquivo/callback. O teste interrompe o segundo produtor e comprova o bloco anterior.
6. Warnings viram erros preservados; controles não podem declarar aprovação apesar de warning emitido. O grid produto inclui na guarda os arrays fine/high ainda residentes.

Checklist mínimo:

- Ler `execution_spec.json`, `lifecycle.py`, `persistent_grid.py`, `orf_child.py` e as provas.
- Verificar hashes do manifesto e da closure; `run.py` sem `--execute` já passou.
- Recibo nodal ROOT disponível: `tmp/c10_ROOT_component/nodal_reuse_review_v1.json`, compatível com as guardas, preserva `COMPONENT_ORF_TABLE_FAIL` e proíbe interpolação.
- Aguardar pré-requisito C09 e decisão sobre o piloto/caps1800s/1GiB. Não existe aprovação de piloto neste pacote.
- Só depois emitir autorização de SHA exato do spec/closure e hashes dos dois recibos. Executar em pasta nova sob tmp, uma tarefa física de cada vez.
- Em falha ou resultado inconclusivo, manter arquivos, máscaras, ledger e recursos; não usar saldo para novas avaliações, sementes ou retentativas.

Os11 TOYs são sintéticos. Não foi rodado o filho ORF, o produtor físico, qualquer posterior PTA ou o piloto16. O modo completo foi implementado e revisado por leitura, mas seu ensaio físico end-to-end permanece pendente.
