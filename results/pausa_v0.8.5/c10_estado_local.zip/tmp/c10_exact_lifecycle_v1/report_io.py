"""Strict JSON transport for legitimate unbounded logL enclosures.

Null is accompanied by a path and sign; an unbounded enclosure is never turned
into a finite range. NaN remains an error, not an implicit unresolved result.
"""
import json
import math
from numbers import Real


def json_report(report):
    nonfinite=[]
    def walk(value,path):
        if isinstance(value,dict):return {str(k):walk(v,path+[str(k)]) for k,v in value.items()}
        if isinstance(value,(tuple,list)):return [walk(v,path+[str(i)]) for i,v in enumerate(value)]
        if isinstance(value,bool) or value is None or isinstance(value,str):return value
        if isinstance(value,Real):
            if math.isnan(value):raise ValueError('NaN is not a valid report field: /'+'/'.join(path))
            if math.isinf(value):
                nonfinite.append({'path':'/'+'/'.join(path),'kind':'positive_infinity' if value>0 else 'negative_infinity'})
                return None
            return value.item() if hasattr(value,'item') else value
        raise TypeError('Unsupported report value at /'+'/'.join(path))
    result={'schema':'C10_OPERATIONAL_REPORT_JSON_v1','payload':walk(report,[]),
            'unbounded_fields':nonfinite,'unbounded_values_not_replaced_by_finite_limits':True}
    json.dumps(result,allow_nan=False)
    return result
