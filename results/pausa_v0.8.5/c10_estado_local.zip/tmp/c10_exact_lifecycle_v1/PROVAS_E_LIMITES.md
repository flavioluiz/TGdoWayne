# Envelopes entre níveis H e agregação do evento em duas dimensões

As identidades seguintes referem-se às matrizes numéricas fornecidas, sob SPD, em aritmética exata. A implementação usa ponto flutuante ordinário; testes sintéticos, controles SciPy e refinamento H são evidências finitas. Não há arredondamento dirigido nem certificado da ORF exata.

## 1. Polinômios exatos em ε

Para cada u nodal e canal k, C(ε)=C0+εC1, com C0 SPD e C1 PSD. O modelo escalar FP preserva a combinação vinculada de breathing/longitudinal, e ε multiplica a potência por polarização canônica; não se transplantam razões de maré como amplitudes livres. Para os estimadores Hermitianos Hi,

μi(ε)=tr(Hi C0)+ε tr(Hi C1),

Σij(ε)=tr(Hi C0 Hj C0)+ε tr(Hi C0 Hj C1+Hi C1 Hj C0)+ε²tr(Hi C1 Hj C1).

Trata-se de CN próprio, portanto não há fator2 extra na covariância. Em B, μB=Σk wk μk e ΣB=Σk wk² Σk. Para qualquer combinação Hermitiana H, o coeficiente linear tem forma quadrática2tr(H C0 H C1)=2||C0^(1/2) H C1^(1/2)||F²≥0; os demais coeficientes também são PSD.

## 2. Âncora inferior e perturbação uniforme em ε

Seja A(ε)=Σj Aj ε^j a covariância fina. Com L0L0*=A0, definem-se νj=max(0,−λmin(L0^-1 Aj L0^-*)) e ν=Σj≥1 νj. Se ν<1, então A(ε)≥(1−ν)A0=:LL* para todo ε∈[0,1]. Esta correção ajusta **somente a âncora da desigualdade**, sem editar Aj, inserir jitter ou fazer clipping nas covariâncias.

Escreva ΔA(ε)=Aoutro(ε)−Afino(ε) em Bernstein. Como os pesos Bernstein são não negativos e somam1,

η=maxj ||L^-1 ΔAj,B L^-*||F

limita a norma da perturbação relativa em todo o intervalo. Se η≥1 ou não houver âncora finita/SPD, a margem é `UNRESOLVED`. Para CN, definindo χ=||L^-1q||², a diferença de log-densidade por bloco é limitada por

δCN=−d log(1−η)+χη/(1−η).

Para a normal real, sejam r=||L^-1(y−μ0)||+Σj≥1||L^-1μj|| e a=maxj||L^-1Δμj,B||. Uma margem por bloco é

δG=½[−d log(1−η)+(ηr²+2ra+a²)/(1−η)].

Somam-se blocos de frequência e a tolerância explícita de roundoff em logL. A margem usa as **diferenças efetivas dos coeficientes**, não a tolerância nominal do teste ORF. Os controles existentes em4.608 valores de logL verificam esta desigualdade finita, sem novas avaliações. Esses controles não provam uniformidade do roundoff; o alcance operacional está expresso nos relatórios.

## 3. O evento muda juntamente com a medida

O evento é ℓH(u,ε)≤tH, onde tH é a logL do mesmo dado na verdade. Se |ℓH−ℓfino|≤δu e |tH−tfino|≤δt, então:

- certamente dentro quando ℓfino≤tfino−(δu+δt);
- certamente fora quando ℓfino>tfino+(δu+δt);
- o restante é ambíguo.

`event_level` amplia o nível por δu+δt **antes** de `reference_slice` classificar células inteiras. O envelope adicional de ℓfino dentro da célula é mantido. Multiplicar somente pesos por exp(±δu) não cobriria cruzamentos deslocados; a implementação faz ambas as operações.

## 4. N, A, Z não normalizados e integração em u

Em cada u, a referência usa um shift finito su e integra exp(ℓfino−su). Obtém intervalos para Nu (massa certamente dentro), Au (massa ambígua) e Zu (massa de todo ε∈[0,1]). O mesmo shift e a mesma medida são usados nos três. Quando uma subdivisão falha, o pai fica na partição; nunca se descarta a célula difícil. Se uma referência numeradora falha mas seu Z é válido, usam-se Nlow=0 e (N+A)high=Zhigh. Se o próprio Z estiver ausente/incompatível, toda a agregação correspondente permanece `[0,1]`.

Para cada regra positiva em u, com pesos wu normalizados pela priori comum, calculam-se em logsumexp:

Nlo=Σu wu exp(su−δu) Nu,lo,

NAhi=Σu wu exp(su+δu) (Nu+Au)hi,

Zlo=Σu wu exp(su−δu) Zu,lo; Zhi=Σu wu exp(su+δu) Zu,hi.

O intervalo é [Nlo/Zhi, min(1,NAhi/Zlo)]. Logo um u com Z nove vezes maior tem nove vezes mais peso posterior; não se faz média uniforme de P(evento|u). A desigualdade min(1,...) vem da inclusão do evento no suporte, não de correção de matriz ou posterior inválida.

GL192/384 fornecem dois resultados observados. Usa-se a envoltória dos intervalos e registra-se a mudança de logZ. Gates finitos também exigem referências de evidência/H0/BF, CDF/quantis, underflow dos **nós amostrados**, comparação do evento bilinear e ausência de warnings. Concordância entre regras não prova ausência de estrutura omitida em u; o rótulo final é `RESOLVED_OPERATIONAL_FINITE_REFERENCE_ONLY`, jamais certificado físico global.

## 5. Evidência sintética delimitada

Os11 TOYs verificam cinco leis com101 ε, uma âncora com coeficiente assinado, desigualdades/shift, eventos deslocados, massa posterior em u, suporte desconhecido, denominadores inválidos, controles por fatia, pesos GL inalterados e falhas de persistência/alocação. Os parâmetros aleatórios são apenas matrizes pequenas sintéticas de seed910100501; os benchmarks de tamanho P10/K3/D10 também são sintéticos. Todos os resultados estão separados das execuções físicas ainda inexistentes.
