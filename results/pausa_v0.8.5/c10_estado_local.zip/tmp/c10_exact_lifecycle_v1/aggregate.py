"""Integrate unnormalized N,A,Z with positive du weights and distinct log shifts."""
import math
import numpy as np
from scipy.special import logsumexp


def aggregate_slices(slices,weights,deltas,*,controls):
    w=np.asarray(weights,float);d=np.asarray(deltas,float)
    if w.shape!=(len(slices),) or d.shape!=w.shape or not np.isfinite(w).all() or np.any(w<=0):raise ValueError('Positive per-node du weights required')
    result={'status':'UNRESOLVED','interval':[0.,1.],'candidate_interval':[0.,1.],
            'normalization':'sum du-weighted unnormalized masses; not mean conditional CDF',
            'node_count':len(slices),'unknown_numerator_nodes':0,'missing_denominator_nodes':[],
            'slice_controls_pass':all(isinstance(row.get('controls'),dict) and all(row['controls'].get(k) is True for k in ('roundoff_allowance_validated','same_node_covariance_reference_validated')) for row in slices),
            'rigorous_floatingpoint_certificate':False,'uniform_physical_certificate':False}
    logs={'Nlow':[],'NAhigh':[],'Zlow':[],'Zhigh':[],'Zpoint':[]}
    for i,(row,weight,delta) in enumerate(zip(slices,w,d)):
        den=row.get('denominator');shift=row.get('log_shift')
        if (den is None or shift is None or not math.isfinite(shift) or not math.isfinite(delta) or delta<0
                or not all(math.isfinite(den.get(k,math.nan)) for k in ('lower','value','upper'))
                or not 0<den['lower']<=den['value']<=den['upper']):
            result['missing_denominator_nodes'].append(i);continue
        zlo,zhi=den['lower'],den['upper'];refs=row.get('numerator_references',{})
        if 'inside' in refs and 'ambiguous' in refs and 'failure_preserved' not in row:
            nl=refs['inside']['lower'];nah=refs['inside']['upper']+refs['ambiguous']['upper']
            if not 0<=nl<=nah:raise ValueError('Invalid numerator references')
            nah=min(nah,zhi) # Structural upper: event mass cannot exceed support.
        else:
            nl,nah=0.,zhi;result['unknown_numerator_nodes']+=1
        base=math.log(weight)+shift
        logs['Nlow'].append(-math.inf if nl==0 else base-delta+math.log(nl))
        logs['NAhigh'].append(-math.inf if nah==0 else base+delta+math.log(nah))
        logs['Zlow'].append(base-delta+math.log(zlo));logs['Zhigh'].append(base+delta+math.log(zhi))
        logs['Zpoint'].append(base+math.log(den['value']))
    if result['missing_denominator_nodes']:return result
    total={k:float(logsumexp(v)) for k,v in logs.items()}
    lo=0. if total['Nlow']==-math.inf else math.exp(total['Nlow']-total['Zhigh'])
    hi=1. if total['NAhigh']>=total['Zlow'] else math.exp(total['NAhigh']-total['Zlow'])
    if not 0<=lo<=hi<=1:raise ArithmeticError('Invalid integrated mass ratio')
    result.update(candidate_interval=[lo,hi],log_masses=total,
                  numerical_level_logweight_envelope=True,
                  finite_controls_pass=result['slice_controls_pass'] and isinstance(controls,dict) and all(controls.get(k) is True for k in ('same_node_reference','roundoff','harmonic_level_enclosure')))
    if result['finite_controls_pass'] and hi-lo<=.002:
        result.update(status='ONE_U_RULE_OPERATIONAL_NOT_FINAL_2D_APPROVAL',interval=[lo,hi])
    return result


def compare_u_rules(coarse,fine,*,original_gates):
    output={'status':'UNRESOLVED','interval':[0.,1.],'rules':[coarse,fine],
            'observed_difference_is_not_rigorous_error_bound':True}
    if 'log_masses' not in coarse or 'log_masses' not in fine:return output
    a,b=coarse['candidate_interval'],fine['candidate_interval']
    hull=[min(a[0],b[0]),max(a[1],b[1])]
    dz=abs(coarse['log_masses']['Zpoint']-fine['log_masses']['Zpoint'])
    output.update(candidate_interval=hull,observed_logZ_difference=dz,
                  gates={'both_rule_controls':coarse.get('finite_controls_pass') is True and fine.get('finite_controls_pass') is True,
                         'CDF_hull_width':hull[1]-hull[0]<=.002,'logZ_change':dz<=.001,
                         'other_original_gates':isinstance(original_gates,dict) and all(original_gates.get(k) is True for k in ('bilinear_comparison','underflow','threshold_reference','parameter_CDF_quantiles','warning_free'))})
    if all(output['gates'].values()):output.update(status='RESOLVED_OPERATIONAL_FINITE_REFERENCE_ONLY',interval=hull)
    return output
