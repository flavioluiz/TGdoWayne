# C10 nós exatos — metadados parciais, tarefa pausada

A prioridade foi transferida por ROOT para C09 v3. Este registro preserva as leituras já feitas e uma aritmética pequena; **não é preflight completo**, não propõe teto novo, não autoriza reuso e não contém executor. A tabela linear histórica de 513 nós continua **COMPONENT_ORF_TABLE_FAIL**. Nenhuma Γ foi carregada nem ORF/logL/draw/posterior calculado nesta tarefa.

Uma rota possível é usar somente Γ avaliadas harmonicamente nos nós físicos de massa da grade de likelihood. Os 513 nós já arquivados têm subconjuntos exatos para 129 (índices 0,4,…,512) e 257 (0,2,…,512). `partial_metadata.json` registra seus bytes float64 e os índices; somente `masses.npy` (4 KiB) foi lido do NPZ, além do streaming do hash do arquivo. Reutilizar os valores nodais exigiria identidade própria de componente e autorização ROOT; não transforma o FAIL da interpolação em PASS.

A medida é `du/0,999` em `[0,001,1]` e `dε` em `[0,1]`. Os nós Chebyshev–Lobatto não mudam essa medida para uma priori uniforme em ângulo, β ou índice. As áreas bilineares devem usar as larguras físicas de u e ε. A borda ε=0 é TT na mesma massa/geometria e deve usar a normalização H0 consistente; não é o limite escalar u=0, excluído da priori C10. O helper bilinear v3 explicita a escala própria da borda H0.

Com cinco respostas distintas D1/D2/D3/CB2/CB3, dois setores TT/FP0 e três níveis harmônicos, o arquivo contém 15.390 matrizes de modo (24.624.000 B) em 513 massas. Os mapas são D→[0,1,2], Cβ→[0,3,4] e Cfull→[0,0,0]. Remover a interpolação ORF não remove a interpolação bilinear da likelihood nem prova refinamento de Z/CDF/PIT/BF/quantis/contorno. Permanecem os gates independentes e a massa omitida/underflow; o sucesso nodal não os substitui.

Bloqueador aritmético identificado: o kernel v2 devolve sempre cinco modelos. Nove análises pedidas usam cinco do modelo D e duas de cada variante C; três chamadas intactas do kernel calculam 15 saídas. Mesmo com reuso ideal das grades aninhadas, 16 IDs em 257×129, quatro refinamentos 513×257 e quatro referências 384×96 representam **9.653.904** valores desejados, mas **16.089.840** calculados pela API atual, acima do teto do piloto de 15 M antes de verificações extras. Uma futura implementação seletiva validada ou outra decisão explícita de desenho é necessária; este registro não amplia o teto.

A referência independente de produto requer reservar até 384 massas adicionais; o eventual cruzamento exato dessas massas com o arquivo ainda não foi calculado. Verdades fora da malha, contornos diretos/adaptativos e verificações extras também precisam de reservas próprias. Não se aprovou contagem ORF/CPU total dessa rota. A tabela 513 apenas elimina um possível custo duplicado dos nós aninhados se o reuso nodal for revisado e autorizado.

O alvo é posterior **2D condicional** em `(u,ε)` com quatro nuisances fixadas. Liberá-las produz seis coordenadas; não é o alvo tensorial 5D de C07. Resultados condicionais não demonstram robustez com nuisances livres.

Os hashes das leituras e a aritmética reproduzível estão em `partial_metadata.json` e `partial_metadata.py`. `execution_enabled=false` e `limits_approved=false` permanecem explícitos. Nada do histórico C10 foi alterado.
