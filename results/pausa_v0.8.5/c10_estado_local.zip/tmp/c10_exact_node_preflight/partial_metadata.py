"""Paused C10 read-only metadata/arithmetic; no gamma load, numerical imports or physics."""
import resource
resource.setrlimit(resource.RLIMIT_CPU,(30,31))
import ast,hashlib,json,struct,sys,time,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
FILES=['tmp/c10_execution_design/PROTOCOLO_CANDIDATO_REVISADO.md','tmp/c10_execution_design/c10_protocol_candidate_v1.json',
 'tmp/c10_orf_preflight/README.md','tmp/c10_orf_preflight/TABLE_REVIEW.md','tmp/c10_orf_preflight/configs/orf_candidate_v1.json',
 'tmp/c10_orf_preflight/src/planning.py','tmp/c10_orf_preflight/results/table.json','tmp/c10_orf_preflight/results/table.npz',
 'tmp/c10_kernel_v2/README.md','tmp/c10_kernel_v2/conditional_kernel.py','tmp/c10_bilinear_v3/README.md','tmp/c10_bilinear_v3/bilinear.py']
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
if __name__=='__main__':
 table=ROOT/'tmp/c10_orf_preflight/results/table.npz'
 with zipfile.ZipFile(table) as z:payload=z.read('masses.npy')
 if payload[:8]!=b'\x93NUMPY\x01\x00':raise ValueError('Unexpected existing mass header')
 size=struct.unpack('<H',payload[8:10])[0];header=ast.literal_eval(payload[10:10+size].decode())
 if header!={'descr':'<f8','fortran_order':False,'shape':(513,)}:raise ValueError('Existing mass shape/dtype differs')
 raw=payload[10+size:];u=list(struct.unpack('<513d',raw))
 if not u[0]==.001 or not u[-1]==1. or any(a>=b for a,b in zip(u[:-1],u[1:])):raise ValueError('Existing nodal mass support/order differs')
 fine=257*129;reference=513*257;product=384*96
 desired=16*9*fine+4*9*(reference-fine)+4*9*product
 actual=16*15*fine+4*15*(reference-fine)+4*15*product
 report=dict(schema='C10_EXACT_NODE_PARTIAL_METADATA_PAUSED',execution_enabled=False,limits_approved=False,
  status='PAUSED_FOR_C09_V3_NOT_A_COMPLETE_PREFLIGHT',source_sha256={p:sha(ROOT/p) for p in FILES},
  historical_linear_table_status='COMPONENT_ORF_TABLE_FAIL',historical_linear_FAIL_preserved=True,
  candidate_nodal_reuse_authorized=False,ORF_gamma_payload_loaded=False,
  mass_measure='du/0.999 on [0.001,1]',epsilon_measure='d epsilon on [0,1]',
  historical_mass_axis_float64_payload_sha256=hashlib.sha256(raw).hexdigest(),master_mass_nodes=u,
  master_mass_formula='0.001+0.999*(1-cos(pi*j/512))/2; reuse archived bytes rather than reevaluate libm',
  mass_indices_129=list(range(0,513,4)),mass_indices_257=list(range(0,513,2)),mass_indices_513=list(range(513)),
  epsilon_master_nodes=[j/256 for j in range(257)],epsilon_stride_65=4,epsilon_stride_129=2,
  harmonic_levels=[dict(lmax=460,nmu=900),dict(lmax=460,nmu=1000),dict(lmax=520,nmu=1000)],
  unique_response_cases=['D1','D2','D3','CB2','CB3'],mapping=dict(D=[0,1,2],C_beta=[0,3,4],C_full=[0,0,0]),
  matrix_counts_if_evaluated_all_three_levels={str(n):3*n*5*2 for n in (129,257,513)},
  matrix_bytes_all_three_levels_513=3*513*5*2*10*10*16,
  extra_mass_nodes_reserved_for_independent_product_reference=384,
  independent_reference_mass_nonoverlap_not_computed=True,
  desired_nine_model_unique_grid_plus_product_values=desired,
  current_five_output_API_for_three_variants_values=actual,
  pilot_cap_unchanged=15000000,current_API_exceeds_cap_before_extra_checks=actual>15000000,
  other_unbudgeted_items=['off-grid truth masses','direct likelihood contour root/adaptive nodes','independent kernel checks','omitted/underflow likelihood mass'],
  warning='Removing ORF interpolation does not validate the 2D positive likelihood interpolation/integration or logL contour. Reuse would need a separate nodal component identity, not PASS of failed linear table.',
  parameter_scope='2D conditional on four fixed nuisances; full u,epsilon plus four nuisances is 6D, not C07 5D',
  CPU_seconds=time.process_time(),RSS_peak_bytes=int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss if sys.platform=='darwin' else resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024),
  physical_ORF_calls=0,physical_likelihood_calls=0,physical_draws=0,posterior_calls=0)
 report['source_sha256'][str((HERE/'partial_metadata.py').relative_to(ROOT))]=sha(HERE/'partial_metadata.py')
 if report['CPU_seconds']>30 or report['RSS_peak_bytes']>64*1024**2:raise RuntimeError('Metadata scope ceiling exceeded')
 with (HERE/'partial_metadata.json').open('x') as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
 print(json.dumps({k:report[k] for k in ('status','CPU_seconds','RSS_peak_bytes','desired_nine_model_unique_grid_plus_product_values','current_five_output_API_for_three_variants_values','historical_mass_axis_float64_payload_sha256')}))
