# Guarda local de memória — variante v2

A variante exige `maximum_workspace_bytes` e `additional_resident_bytes`. Antes de `np.full`, varredura de finitude do cache ou callback, soma saída float64, máscaras temporárias de finitude, cache já residente, eixos, workspace conservador do kernel v2, 8MiB de metadados e residência adicional declarada. O cache deve ser ndarray existente: não há conversão implícita de lista grande.

Três testes PASS (0,008s reportados pela suíte): teto insuficiente aciona zero chamadas ao produtor/kernel e zero alocações `np.full`; teto suficiente preserva os valores/reuso; workspace coincide com a fórmula congelada do kernel. Nenhuma física executada. O estimador continua distinto de RSS; o lifecycle externo deve contabilizar demais arrays, startup, filhos, I/O e CPU.

Comando: `OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m unittest discover -s tmp/c10_nodal_guard_v2 -p 'test_*.py' -v`.

v1 e kernel seletivo permanecem intactos; snapshots e delta presentes. A integração seguinte deve copiar a variante pelo SHA do manifesto.
