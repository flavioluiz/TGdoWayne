import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock,patch
import sys
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.append(str(HERE.parent/'c10_exact_selected_preflight_v1'))
from ledger import GlobalLedger
from selected_kernel import ConditionalLikelihood
from nodal_runner import run_grid,allocation_preflight

def make():
 q=np.ones((1,1,2),complex)*.1;x=np.zeros((1,1,2));H=np.array([[[1,0],[0,0]],[[0,0],[0,1]]],complex)
 e=ConditionalLikelihood(q,x,x,H,[1],maximum_logl_values=1000)
 return e,np.eye(2,dtype=complex)[None],.2*np.eye(2,dtype=complex)[None]

def identity():return dict.fromkeys(('nodal_component_sha256','kernel_sha256','generation_sha256','fixed_nuisance_sha256','response','harmonic_level'),'TOY')

class GuardTests(unittest.TestCase):
 def test_tiny_cap_before_allocation_producer_or_kernel(self):
  with tempfile.TemporaryDirectory() as d:
   e,c0,c1=make();producer=Mock(return_value=(c0,c1));e.evaluate=Mock(side_effect=AssertionError('density work'))
   l=GlobalLedger(Path(d)/'l.json',identity='TOY',allocations={'grid':100},maximum_values=100,maximum_cpu_seconds=10)
   with patch('nodal_runner.np.full',side_effect=AssertionError('large output allocation')):
    with self.assertRaises(RuntimeError):run_grid(e,producer,[.001,1],[0,1],models=('B_CN',),data_ids=(0,),identity=identity(),ledger=l,stage='grid',maximum_workspace_bytes=1,additional_resident_bytes=0)
   producer.assert_not_called();e.evaluate.assert_not_called();self.assertEqual(l.state['charged']['grid'],0)
 def test_sufficient_cap_preserves_values_and_includes_reuse(self):
  with tempfile.TemporaryDirectory() as d:
   e,c0,c1=make();l=GlobalLedger(Path(d)/'l.json',identity='TOY',allocations={'grid':100},maximum_values=100,maximum_cpu_seconds=10)
   kwargs=dict(models=('B_CN','B_G'),data_ids=(0,),identity=identity(),ledger=l,stage='grid',maximum_workspace_bytes=64*1024**2,additional_resident_bytes=1234)
   old,r=run_grid(e,lambda u:(c0,c1),[.001,1],[0,1],**kwargs)
   p=r['allocation_preflight'];self.assertEqual(p['components_bytes']['output_float64'],old.values.nbytes)
   self.assertEqual(p['components_bytes']['external_resident_arrays'],1234)
   new,r=run_grid(e,lambda u:(c0,c1),[.001,.5,1],[0,.5,1],reuse=old,**kwargs)
   np.testing.assert_array_equal(new.values[0,0],old.values[0,0])
   self.assertEqual(r['allocation_preflight']['components_bytes']['retained_reuse_values'],old.values.nbytes)
   producer=Mock(side_effect=AssertionError('producer work'))
   with patch('nodal_runner.np.full',side_effect=AssertionError('output allocation')):
    with self.assertRaises(RuntimeError):run_grid(e,producer,[.001,1],[0,1],reuse=old,**dict(kwargs,maximum_workspace_bytes=old.values.nbytes))
   producer.assert_not_called()
 def test_workspace_matches_frozen_kernel_formula(self):
  e,_,_=make();m=allocation_preflight(e,(2,2,2,1),epsilon_batch=2,reuse_values=None,new_axis_bytes=32,maximum_workspace_bytes=64*1024**2,additional_resident_bytes=0)
  self.assertEqual(m['components_bytes']['kernel_full_v2_workspace'],e.preflight(2)['estimated_numeric_workspace_bytes'])
  for value in (True,0,-1,1.5):
   with self.assertRaises(ValueError):allocation_preflight(e,(2,2,2,1),epsilon_batch=2,reuse_values=None,new_axis_bytes=32,maximum_workspace_bytes=value,additional_resident_bytes=0)

if __name__=='__main__':unittest.main(verbosity=2)
