# Integração bilinear positiva — preparação C10

Núcleo isolado, sem ORF, geração PTA ou posterior física. Importar `bilinear.py`
a partir desta pasta; os nove testes sintéticos passaram na ROOT em 0,025s.
O histórico `tests_v1.log` registra uma falha real no caso de sela, corrigida
antes de `tests_v2.log`; o critério de integração não foi relaxado.

A grade é estritamente crescente em duas coordenadas físicas, com priori
uniforme própria no retângulo. O logL nodal é escalado pelo seu máximo; a
interpolação é feita sobre L não negativa. A integral de cada célula é a média
dos quatro vértices multiplicada pela área. Evidência inclui o volume da priori.
As marginais são lineares por partes; CDFs são integrais parciais quadráticas
e quantis usam a inversa à esquerda, inclusive nos patamares. A borda y=0
produz a evidência H0 com sua própria priori uniforme em x. É possível computar
logBF10 apenas subtraindo as evidências das duas hipóteses no mesmo dado/modelo.

Para a CDF do próprio logL interpolado, uma célula usa L(x,y)=a+bx+cy+dxy.
Em x fixo, a condição L≤t é um intervalo de y (ou todo/vazio). O integral
ponderado por L nesse intervalo é analítico; a última integração em x usa
Gauss–Kronrod, após particionar em q(x)=0, p(x)=t e p(x)+q(x)=t.
Células inteiras são classificadas pelos mínimos/máximos dos vértices.
Não se somam indicadores somente nos nós. `quadrature_absolute_error_estimate`
é a estimativa numérica do integrador, não um certificado global.

Raízes quase coincidentes podem formar intervalos ínfimos nos quais q≈0 e a
razão que descreve o contorno fica mal condicionada. Esses intervalos só são
omitidos quando área×max(L) cabe na parcela alocada da tolerância absoluta;
`small_interval_mass_bound` registra separadamente seu limite de massa relativo,
e `bounded_small_intervals` conta as ocorrências. A soma desses limites também
é parte do erro do resultado; não está embutida nem ocultada na estimativa GK.
Sem tal limite, uma falha GK termina explicitamente com erro.

## Validação efetuada e limites

- Priori uniforme em retângulo de volume diferente de1 e invariância a escala
  logarítmica/transformação afim de coordenadas.
- Integral/momentos/CDF de logL de polinômio bilinear com solução analítica;
  caso produto comparado com integral1D derivada diretamente do domínio;
  caso de sela com derivada em y de sinais opostos.
- Refinamento9/17/33 em exponencial separável, contra Z, quantil e contorno da
  **função exponencial direta**, não somente contra outra malha da interpolação.
- Suportes, valores inválidos, nós nulos, underflow reportado e inversa em patamar.

Estes controles não estabelecem precisão para a posterior PTA C10. A resolução
em u/ε, a interpolação ORF e o contorno da likelihood física continuam exigindo
o piloto independente do protocolo. Mesmo a integral exata da aproximação
bilinear pode ser inadequada para o problema original. Nenhum MCSE fictício0,
SBC escalar, falso positivo ou identificabilidade foi calculado aqui.

`finite_underflow_nodes` identifica logs finitos que viraram zero após escala;
qualquer uso científico precisa delimitar sua omissão no domínio, ou falhar.
O núcleo não infere um bound global a partir de valores nos nós. Se a likelihood
é constante, o logL-PIT tem átomo; seu valor1 não é uma amostra uniforme contínua
para um teste SBC sem tratamento de empates. As funções assumem priori uniforme;
a parametrização e os volumes devem ser compatíveis com o protocolo C10.
