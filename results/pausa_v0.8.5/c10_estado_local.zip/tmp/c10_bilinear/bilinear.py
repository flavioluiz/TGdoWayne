"""Positive bilinear surrogate on a rectangle with a uniform proper prior.

All exactness statements concern the interpolated likelihood, not the original
likelihood sampled at its nodes. No PTA model or C07 source is imported.
"""
from dataclasses import dataclass
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq


def grid_axis(values):
    out=np.array(values,dtype=float,copy=True)
    if out.ndim!=1 or out.size<2 or not np.all(np.isfinite(out)) or np.any(np.diff(out)<=0):
        raise ValueError('Grid axis must be finite and strictly increasing')
    out.flags.writeable=False
    return out


@dataclass(frozen=True)
class ContourResult:
    probability: float
    quadrature_absolute_error_estimate: float
    crossing_cells: int
    function_evaluations: int
    small_interval_mass_bound: float=0.
    bounded_small_intervals: int=0
    scope: str='INTERPOLATED_LIKELIHOOD_ONLY_NOT_DIRECT_POSTERIOR_CERTIFICATE'


class LinearMarginal:
    def __init__(self,axis,values):
        self.axis=grid_axis(axis)
        self.values=np.array(values,dtype=float,copy=True)
        if self.values.shape!=self.axis.shape or not np.all(np.isfinite(self.values)) or np.any(self.values<0):
            raise ValueError('Invalid nonnegative marginal values')
        self.areas=np.diff(self.axis)*(self.values[:-1]+self.values[1:])/2
        self.prefix=np.r_[0.,np.cumsum(self.areas)]
        self.total=float(self.prefix[-1])
        if not self.total>0: raise ValueError('Zero mass marginal')
        self.values.flags.writeable=False

    def cdf(self,x):
        x=float(x)
        if not math.isfinite(x): raise ValueError('Finite CDF coordinate required')
        if x<=self.axis[0]: return 0.
        if x>=self.axis[-1]: return 1.
        i=int(np.searchsorted(self.axis,x,side='right')-1)
        dx=x-self.axis[i]; width=self.axis[i+1]-self.axis[i]
        mass=self.values[i]*dx+(self.values[i+1]-self.values[i])*dx*dx/(2*width)
        return float((self.prefix[i]+mass)/self.total)

    def quantile(self,p):
        p=float(p)
        if not math.isfinite(p) or not 0<=p<=1: raise ValueError('Probability outside [0,1]')
        if p==0: return float(self.axis[0])
        if p==1: return float(self.axis[-1])
        i=max(0,int(np.searchsorted(self.prefix,p*self.total,side='left')-1))
        return float(brentq(lambda x:self.cdf(x)-p,self.axis[i],self.axis[i+1],xtol=1e-14,rtol=1e-14))

    def moment(self,order):
        if isinstance(order,bool) or not isinstance(order,int) or order<0:
            raise ValueError('Nonnegative integer moment order required')
        # Exact polynomial integration of each linear segment in local t∈[0,1].
        total=0.
        for left,right,f0,f1 in zip(self.axis[:-1],self.axis[1:],self.values[:-1],self.values[1:]):
            width=right-left
            for k in range(order+1):
                coefficient=math.comb(order,k)*left**(order-k)*width**k
                total+=width*coefficient*(f0/(k+1)+(f1-f0)/(k+2))
        return float(total/self.total)


class BilinearPosterior:
    def __init__(self,x,y,log_likelihood):
        self.x=grid_axis(x); self.y=grid_axis(y)
        logs=np.array(log_likelihood,dtype=float,copy=True)
        if logs.shape!=(len(self.x),len(self.y)) or np.any(np.isnan(logs)) or np.any(np.isposinf(logs)):
            raise ValueError('Invalid log likelihood grid')
        finite=np.isfinite(logs)
        if not finite.any(): raise ValueError('No positive likelihood')
        self.log_scale=float(np.max(logs[finite]))
        self.scaled=np.exp(logs-self.log_scale)
        self.finite_underflow_nodes=int(np.sum(finite & (self.scaled==0)))
        self.volume=float((self.x[-1]-self.x[0])*(self.y[-1]-self.y[0]))
        self.marginal_x=LinearMarginal(self.x,np.sum(np.diff(self.y)[None,:]*(self.scaled[:,:-1]+self.scaled[:,1:])/2,axis=1))
        self.marginal_y=LinearMarginal(self.y,np.sum(np.diff(self.x)[:,None]*(self.scaled[:-1,:]+self.scaled[1:,:])/2,axis=0))
        self.integral=self.marginal_x.total
        self.log_evidence=self.log_scale+math.log(self.integral/self.volume)
        self.scaled.flags.writeable=False

    def boundary_log_evidence(self,y_index=0):
        if y_index not in (0,-1): raise ValueError('Only a boundary index is supported')
        marginal=LinearMarginal(self.x,self.scaled[:,y_index])
        return self.log_scale+math.log(marginal.total/(self.x[-1]-self.x[0]))

    def log_likelihood_cdf(self,log_threshold,epsabs=1e-11,epsrel=1e-11):
        if not math.isfinite(log_threshold): raise ValueError('Finite log threshold required')
        if not math.isfinite(epsabs) or epsabs<=0 or not math.isfinite(epsrel) or epsrel<=0:
            raise ValueError('Positive finite integration tolerances required')
        if log_threshold>=self.log_scale:
            return ContourResult(1.,0.,0,0)
        threshold=math.exp(log_threshold-self.log_scale)
        f00=self.scaled[:-1,:-1]; f10=self.scaled[1:,:-1]
        f01=self.scaled[:-1,1:]; f11=self.scaled[1:,1:]
        lower=np.minimum.reduce([f00,f10,f01,f11]); upper=np.maximum.reduce([f00,f10,f01,f11])
        areas=np.diff(self.x)[:,None]*np.diff(self.y)[None,:]
        full=upper<=threshold
        total=float(np.sum((f00+f10+f01+f11)[full]*areas[full]/4))
        crossing=(lower<=threshold)&(upper>threshold)
        indices=np.argwhere(crossing); error=0.; evaluations=0
        small_bound=0.; small_count=0
        absolute_budget=epsabs*self.integral/max(1,len(indices))
        for i,j in indices:
            a=float(f00[i,j]); b=float(f10[i,j]-f00[i,j])
            c=float(f01[i,j]-f00[i,j]); d=float(f11[i,j]-f10[i,j]-f01[i,j]+f00[i,j])
            cuts=[0.,1.]
            for constant,slope in ((c,d),(a-threshold,b),(a+c-threshold,b+d)):
                if slope!=0:
                    root=-constant/slope
                    if 0<root<1: cuts.append(root)
            cuts=sorted(set(cuts))
            def vertical(t):
                p=a+b*t; q=c+d*t
                if q==0: return p if p<=threshold else 0.
                height=(threshold-p)/q
                if q>0:
                    if height<=0: return 0.
                    if height>=1: return p+q/2
                    return height*(p+q*height/2)
                if height<=0: return p+q/2
                if height>=1: return 0.
                # Integrate from height to 1; form avoids subtraction of close integrals.
                width=1-height
                return width*(p+q*(1+height)/2)
            cell=0.; cell_error=0.
            for left,right in zip(cuts[:-1],cuts[1:]):
                segment_budget=absolute_budget/max(1,len(cuts)-1)
                interval_bound=float(areas[i,j]*upper[i,j]*(right-left))
                if interval_bound<=segment_budget:
                    # Coalescent contour roots can create sub-ulp-scale panels.
                    # Omit their mass with an explicit nonnegative upper bound.
                    small_bound+=interval_bound; small_count+=1
                    continue
                result=quad(vertical,left,right,epsabs=segment_budget/areas[i,j],epsrel=epsrel,limit=100,full_output=1)
                if len(result)!=3: raise ArithmeticError('Contour quadrature did not converge: '+str(result[3]))
                value,estimate,info=result; cell+=value; cell_error+=estimate; evaluations+=info['neval']
            total+=areas[i,j]*cell; error+=areas[i,j]*cell_error
        probability=total/self.integral
        if not math.isfinite(probability) or probability < -1e-13 or probability >1+1e-13:
            raise ArithmeticError('Contour probability outside range')
        # Preserve roundoff, not silently clipping an invalid probability.
        return ContourResult(float(probability),float(error/self.integral),int(len(indices)),int(evaluations),float(small_bound/self.integral),small_count)
