"""Shared-factor conditional likelihood for C(epsilon)=C0+epsilon*C1.

Pure covariance-level component, not an ORF or validated PTA experiment.
Outputs normalized densities of A0_CN,A_CN,B_CN,A_G,B_G, in that order.
The Gaussian laws applied to physical quadratic statistics remain approximations.
"""
import numpy as np

MODELS=('A0_CN','A_CN','B_CN','A_G','B_G')


def hermitian(value,name):
    raw=np.asarray(value)
    if raw.dtype.kind not in 'fiuc' or raw.ndim<2 or raw.shape[-2]!=raw.shape[-1]:
        raise ValueError(name+' must contain numeric square matrices')
    a=np.array(raw,dtype=np.complex128,copy=True)
    if not np.isfinite(a).all(): raise ValueError(name+' must be finite')
    scale=np.maximum(np.max(abs(a),axis=(-2,-1)),np.finfo(float).tiny)
    error=np.max(abs(a-a.swapaxes(-1,-2).conj()),axis=(-2,-1))/scale
    if np.any(error>64*np.finfo(float).eps): raise ValueError(name+' is not Hermitian to roundoff')
    # Accepted symmetrization is recorded; no SPD repair is performed.
    return (a+a.swapaxes(-1,-2).conj())/2,float(np.max(error))


def real_array(value,name):
    raw=np.asarray(value)
    if raw.dtype.kind not in 'fiu': raise ValueError(name+' must be real numeric')
    a=np.array(raw,dtype=float,copy=True)
    if not np.isfinite(a).all(): raise ValueError(name+' must be finite')
    return a


class ConditionalLikelihood:
    def __init__(self,q,x_physical,x_gaussian,H,weights,*,maximum_logl_values,maximum_workspace_bytes=512*1024**2):
        raw=np.asarray(q)
        if raw.dtype.kind not in 'fiuc' or raw.ndim!=3 or not np.isfinite(raw).all(): raise ValueError('q must be finite (R,K,P)')
        self.q=np.array(raw,dtype=np.complex128,copy=True)
        self.R,self.K,self.P=self.q.shape
        if min(self.R,self.K,self.P)<1: raise ValueError('Empty observation dimension')
        self.H,self.H_hermitian_relative_error=hermitian(H,'H')
        if self.H.ndim!=3 or self.H.shape[-1]!=self.P: raise ValueError('H shape differs from q')
        self.D=len(self.H)
        if self.D<1: raise ValueError('Empty statistic dimension')
        self.physical=real_array(x_physical,'x_physical'); self.gaussian=real_array(x_gaussian,'x_gaussian')
        if self.physical.shape!=(self.R,self.K,self.D) or self.gaussian.shape!=self.physical.shape: raise ValueError('Statistic arrays differ from experiment')
        self.w=real_array(weights,'weights')
        if self.w.shape!=(self.K,): raise ValueError('One fixed weight per channel required')
        self.x=np.concatenate((self.physical,self.gaussian),axis=0)
        self.z=np.einsum('rkd,k->rd',self.x,self.w)[:,None,:]
        if isinstance(maximum_logl_values,bool) or not isinstance(maximum_logl_values,int) or maximum_logl_values<1: raise ValueError('Positive integer logL budget required')
        if isinstance(maximum_workspace_bytes,bool) or not isinstance(maximum_workspace_bytes,int) or maximum_workspace_bytes<1: raise ValueError('Positive integer memory budget required')
        self.maximum_logl_values=maximum_logl_values; self.maximum_workspace_bytes=maximum_workspace_bytes
        self.logl_values=0; self.completed_logl_values=0; self.last_preflight=None

    def preflight(self,E):
        if isinstance(E,bool) or not isinstance(E,int) or E<1: raise ValueError('Positive batch size required')
        # Conservative simultaneous covariance, solve/residual, and normal arrays.
        elements=16*E*self.K*self.P**2*4+16*E*self.K*self.P*self.R*3+8*E*self.K*self.D*self.R*2*4+16*self.K*self.D*self.P**2*4+8*E*5*self.R
        values=E*5*self.R
        if elements>self.maximum_workspace_bytes: raise RuntimeError('Declared workspace estimate exceeded')
        if self.logl_values+values>self.maximum_logl_values: raise RuntimeError('Cumulative logL budget exceeded')
        return {'estimated_numeric_workspace_bytes':int(elements),'logl_values_requested':values,'status':'ESTIMATE_NOT_RSS_CERTIFICATE'}

    @staticmethod
    def _normal(mu,cov,data):
        chol=np.linalg.cholesky(cov)
        rhs=data.transpose(1,2,0)[None]-mu[:,:,:,None]
        solved=np.linalg.solve(chol,rhs)
        logdet=2*np.log(np.diagonal(chol,axis1=-2,axis2=-1)).sum(axis=(-2,-1))
        return -.5*(np.sum(solved**2,axis=(1,2))+logdet[:,None]+data.shape[1]*data.shape[2]*np.log(2*np.pi))

    def moments(self,C0,C1):
        c0,e0=hermitian(C0,'C0'); c1,e1=hermitian(C1,'C1')
        if c0.shape!=(self.K,self.P,self.P) or c1.shape!=c0.shape: raise ValueError('Covariance shape differs from experiment')
        np.linalg.cholesky(c0)
        mineig=np.linalg.eigvalsh(c1).min(axis=-1)
        scale=np.maximum(np.max(abs(c1),axis=(-2,-1)),np.finfo(float).tiny)
        if np.any(mineig < -64*np.finfo(float).eps*scale): raise ValueError('C1 is not PSD to roundoff')
        hc0=np.einsum('dab,kbc->kdac',self.H,c0,optimize=True)
        hc1=np.einsum('dab,kbc->kdac',self.H,c1,optimize=True)
        mu0=np.einsum('kdaa->kd',hc0).real; mu1=np.einsum('kdaa->kd',hc1).real
        s00=np.einsum('kiab,kjba->kij',hc0,hc0,optimize=True).real
        s01=np.einsum('kiab,kjba->kij',hc0,hc1,optimize=True).real
        s11=np.einsum('kiab,kjba->kij',hc1,hc1,optimize=True).real
        return c0,c1,(mu0,mu1,s00,s01+s01.swapaxes(-1,-2),s11),{'C0_symmetrization_relative_error':e0,'C1_symmetrization_relative_error':e1,'C1_minimum_eigenvalue':mineig.tolist()}

    def evaluate(self,C0,C1,epsilon):
        eps=real_array(epsilon,'epsilon')
        if eps.ndim!=1 or np.any(eps<0) or np.any(eps>1): raise ValueError('epsilon must be a batch in [0,1]')
        self.last_preflight=self.preflight(len(eps))
        c0,c1,basis,checks=self.moments(C0,C1)
        # Reserve a conservative entire-batch cost before any density evaluation;
        # later failures are not free budget and cannot be retried indefinitely.
        self.logl_values+=self.last_preflight['logl_values_requested']
        cov=c0[None]+eps[:,None,None,None]*c1[None]
        chol=np.linalg.cholesky(cov)
        rhs=np.broadcast_to(self.q.transpose(1,2,0),(len(eps),self.K,self.P,self.R))
        solved=np.linalg.solve(chol,rhs)
        ld=2*np.log(np.diagonal(chol,axis1=-2,axis2=-1).real).sum(axis=(-2,-1))
        a0=-np.sum(abs(solved)**2,axis=(1,2))-ld[:,None]-self.K*self.P*np.log(np.pi)
        del rhs,solved,cov,chol
        m0,m1,s0,s1,s2=basis
        mu=m0[None]+eps[:,None,None]*m1[None]
        sigma=s0[None]+eps[:,None,None,None]*s1[None]+eps[:,None,None,None]**2*s2[None]
        a=self._normal(mu,sigma,self.x)
        mb=np.einsum('ekd,k->ed',mu,self.w)
        sb=np.einsum('ekij,k->eij',sigma,self.w**2)
        b=self._normal(mb[:,None,:],sb[:,None,:,:],self.z)
        result=np.stack((a0,a[:,:self.R],b[:,:self.R],a[:,self.R:],b[:,self.R:]),axis=1)
        if not np.isfinite(result).all(): raise ArithmeticError('Nonfinite normalized likelihood')
        self.completed_logl_values+=result.size
        return result,checks
