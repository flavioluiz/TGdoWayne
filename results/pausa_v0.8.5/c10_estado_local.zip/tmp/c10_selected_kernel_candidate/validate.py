"""Run only small synthetic tests, with a 30 CPU-second cap including imports."""
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time
import unittest

ROOT=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[key]='1'
start=time.process_time()
import numpy as np
import scipy
import test_selected_kernel
suite=unittest.defaultTestLoader.discover(str(ROOT),pattern='test_*.py')
with (ROOT/'test_output.txt').open('w') as out:
    result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
report={
    'schema':'C10_SELECTED_KERNEL_SYNTHETIC_VALIDATION_v1',
    'status':'PASS' if result.wasSuccessful() else 'FAIL_PRESERVED',
    'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
    'cpu_seconds_with_numeric_imports':time.process_time()-start,
    'process_cpu_seconds_including_interpreter_startup':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
    'maximum_RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024),
    'limits':{'CPU_seconds':30,'BLAS_threads':1},
    'numpy_version':np.__version__,'scipy_version':scipy.__version__,
    'metrics':test_selected_kernel.METRICS,
    'physical_ORFs':0,'physical_log_likelihood_values':0,'physical_draws':0,
    'bank_construction':False,'campaign_execution':False,
    'source_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in sorted(ROOT.rglob('*.py')) if '__pycache__' not in p.parts},
}
(ROOT/'validation.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
sys.exit(0 if result.wasSuccessful() else 1)
