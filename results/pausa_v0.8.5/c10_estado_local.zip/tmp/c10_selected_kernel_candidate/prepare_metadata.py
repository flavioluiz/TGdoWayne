"""Pure metadata/arithmetic; does not import NumPy, the kernel or any PTA runner."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
BASE=REPO/'tmp/c10_kernel_v2/conditional_kernel.py'
PARTIAL=REPO/'tmp/c10_exact_node_preflight/partial_metadata.json'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
write=lambda name,obj:(HERE/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
expected='fe2b3244e6d38874e6baaced00d69e77385353ff4c282dca118f159a3b06de88'
assert sha(BASE)==expected==sha(HERE/'baseline_v2/conditional_kernel.py')
assert sha(REPO/'tmp/c10_kernel_v2/test_conditional_kernel.py')==sha(HERE/'test_baseline_v2.py')
partial=json.loads(PARTIAL.read_text())
assert partial['historical_linear_table_status']=='COMPONENT_ORF_TABLE_FAIL'
assert partial['candidate_nodal_reuse_authorized'] is False
old=BASE.read_text(); new=(HERE/'conditional_kernel.py').read_text()
(HERE/'kernel_delta.patch').write_text(''.join(difflib.unified_diff(
    old.splitlines(True),new.splitlines(True),
    fromfile='tmp/c10_kernel_v2/conditional_kernel.py',
    tofile='tmp/c10_selected_kernel_candidate/conditional_kernel.py')))
def functions(text):
    tree=ast.parse(text); result={}
    for node in tree.body:
        if isinstance(node,ast.FunctionDef): result[node.name]=ast.dump(node,include_attributes=False)
        elif isinstance(node,ast.ClassDef):
            for fn in node.body:
                if isinstance(fn,ast.FunctionDef): result[node.name+'.'+fn.name]=ast.dump(fn,include_attributes=False)
    return result
before=functions(old); after=functions(new)
unchanged=['hermitian','real_array','ConditionalLikelihood.__init__',
           'ConditionalLikelihood._normal','ConditionalLikelihood.moments']
assert all(before[k]==after[k] for k in unchanged)
terms=[
 {'name':'base_16_IDs_257x129','points_per_ID':257*129,'IDs':16,'unique_ID_parameter_points':16*257*129},
 {'name':'four_nested_refinements_513x257_minus_257x129','points_per_ID':513*257-257*129,'IDs':4,
  'unique_ID_parameter_points':4*(513*257-257*129)},
 {'name':'four_independent_product_references_384x96','points_per_ID':384*96,'IDs':4,
  'unique_ID_parameter_points':4*384*96},
]
points=sum(t['unique_ID_parameter_points'] for t in terms)
selected=9*points; legacy=15*points; cap=partial['pilot_cap_unchanged']
assert selected==partial['desired_nine_model_unique_grid_plus_product_values']==9_653_904
assert legacy==partial['current_five_output_API_for_three_variants_values']==16_089_840
config={
 'schema':'C10_SELECTED_KERNEL_CONFIG_CANDIDATE_v1',
 'status':'SYNTHETICALLY_TESTED_COMPONENT_NOT_PHYSICAL_PREFLIGHT',
 'execution_enabled':False,'physical_execution_authorized':False,'limits_approved':False,
 'api':{'class':'ConditionalLikelihood','method':'evaluate',
        'selection_keyword':'models','output_axes':['epsilon','requested_model_order','replica'],
        'default_backwards_compatible':['A0_CN','A_CN','B_CN','A_G','B_G'],
        'production_must_supply_explicit_models':True},
 'routes':[
  {'response':'D','kernel_models':['A0_CN','A_CN','B_CN','A_G','B_G'],
   'scientific_labels':['A0_CN','A_CN','B_CN','A_G','B_G'],'response_case_indices':[0,1,2]},
  {'response':'C_beta','kernel_models':['B_CN','B_G'],
   'scientific_labels':['C_beta_CN','C_beta_G'],'response_case_indices':[0,3,4]},
  {'response':'C_full','kernel_models':['B_CN','B_G'],
   'scientific_labels':['C_full_CN','C_full_G'],'response_case_indices':[0,0,0]},
 ],
 'budget_arithmetic':{'terms':terms,'unique_ID_parameter_points':points,
    'models_per_point_selected':9,'models_per_point_legacy':15,
    'selected_values':selected,'legacy_values':legacy,'removed_discarded_values':legacy-selected,
    'pilot_cap_unchanged':cap,'arithmetical_difference_to_cap_not_allocated':cap-selected,
    'all_costs_closed':False,'other_unbudgeted_items':partial['other_unbudgeted_items'],
    'scope':'Grid and product-reference points only; nested reuse is conditional, not authorized here.',
    'global_ledger_required':'A future runner must sum reserved charges over all instances, variants, levels, checks and failures.'},
 'kernel_accounting':{'requested_values':'E * len(models) * R',
    'reserved_before_density':True,'post_reservation_failure_retains_entire_batch_charge':True,
    'completed_values_only_after_finite_result':True,
    'memory_policy':'Unchanged conservative full-v2 component sum for every subset; estimate, not RSS certificate.',
    'unselected_density_evaluated':False,
    'moment_basis_and_covariance_checks_still_performed_for_all_requests':True},
 'scope':{'posterior_coordinates':['u','epsilon'],'fixed_nuisance_count':4,
    'physical_prior_u':[.001,1.],'physical_prior_epsilon':[0.,1.],
    'prior_measure':'du/0.999 times d epsilon; actual physical cell widths',
    'C1':'Physical linked scalar contribution at the selected response; no new amplitude convention introduced.',
    'epsilon_zero':'Tensor-only covariance at the same positive u, not FP metric at u=0.'},
 'historical_linear_table_status':partial['historical_linear_table_status'],
 'historical_linear_FAIL_preserved':True,'nodal_reuse_authorized':False,
 'integration_contour_ORF_CPU_and_RSS_gates_closed':False,
 'baseline_source':{'path':str(BASE.relative_to(REPO)),'sha256':sha(BASE)},
 'candidate_source':{'path':str((HERE/'conditional_kernel.py').relative_to(REPO)),
                     'sha256':sha(HERE/'conditional_kernel.py')},
 'partial_preflight':{'path':str(PARTIAL.relative_to(REPO)),'sha256':sha(PARTIAL)},
 'historical_table_hash_cited_from_partial_not_rehashed_or_loaded':
    partial['source_sha256']['tmp/c10_orf_preflight/results/table.npz'],
 'unchanged_function_AST':unchanged,
}
write('selection_config.json',config)
write('metadata_validation.json',{
 'schema':'C10_SELECTED_KERNEL_METADATA_CHECK_v1','status':'PASS_METADATA_ONLY',
 'source_and_test_snapshot_byte_exact':True,'unchanged_function_AST':unchanged,
 'selected_grid_values':selected,'legacy_grid_values':legacy,
 'physical_ORFs':0,'physical_log_likelihood_values':0,'physical_draws':0,
 'Gamma_loaded':False,'bank_constructed':False,
 'selection_config_sha256':sha(HERE/'selection_config.json'),
 'script_sha256':sha(Path(__file__)),
})
print(json.dumps({'selected_values':selected,'legacy_values':legacy,
                  'selection_config_sha256':sha(HERE/'selection_config.json')},indent=2))
