"""Synthetic covariance-level tests; no PTA inputs, ORFs or posterior campaign."""
import importlib.util
import itertools
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np
from conditional_kernel import ConditionalLikelihood, MODELS
from test_baseline_v2 import fixture

BASELINE=Path(__file__).parent/'baseline_v2'/'conditional_kernel.py'
spec=importlib.util.spec_from_file_location('frozen_c10_v2',BASELINE)
frozen=importlib.util.module_from_spec(spec); spec.loader.exec_module(frozen)
METRICS={'tested_ordered_selections':0,'maximum_absolute_selected_difference':0.,
         'all_five_default_bit_exact':False,'scope':'SYNTHETIC_COVARIANCE_ONLY'}


def make(cls=ConditionalLikelihood,budget=100000,memory=512*1024**2):
    c0,c1,H,q,x,g,w=fixture()
    return cls(q,x,g,H,w,maximum_logl_values=budget,
               maximum_workspace_bytes=memory),c0,c1


class SelectedKernelTests(unittest.TestCase):
    def test_all_nonempty_subsets_and_reverse_order(self):
        old,c0,c1=make(frozen.ConditionalLikelihood)
        eps=[0.,.25,.9,1.]; expected,checks=old.evaluate(c0,c1,eps)
        for size in range(1,6):
            for subset in itertools.combinations(MODELS,size):
                for names in (subset,subset[::-1]):
                    with self.subTest(models=names):
                        new,_,_=make()
                        got,newchecks=new.evaluate(c0,c1,eps,models=list(names))
                        ref=expected[:,[MODELS.index(n) for n in names],:]
                        np.testing.assert_allclose(got,ref,rtol=5e-14,atol=5e-13)
                        self.assertEqual(newchecks,checks)
                        self.assertEqual(got.shape,(4,len(names),3))
                        self.assertEqual(new.logl_values,12*len(names))
                        self.assertEqual(new.completed_logl_values,new.logl_values)
                        METRICS['tested_ordered_selections']+=1
                        METRICS['maximum_absolute_selected_difference']=max(
                            METRICS['maximum_absolute_selected_difference'],float(np.max(abs(got-ref))))

    def test_default_all_five_preserves_old_output_exactly(self):
        old,c0,c1=make(frozen.ConditionalLikelihood); new,_,_=make()
        expected,oldcheck=old.evaluate(c0,c1,[0.,.5,1.])
        got,newcheck=new.evaluate(c0,c1,[0.,.5,1.])
        np.testing.assert_array_equal(got,expected)
        self.assertEqual(oldcheck,newcheck)
        self.assertEqual(new.logl_values,old.logl_values)
        self.assertEqual(new.completed_logl_values,old.completed_logl_values)
        self.assertEqual(new.preflight(2)['components_bytes'],old.preflight(2)['components_bytes'])
        METRICS['all_five_default_bit_exact']=True

    def test_unrequested_density_paths_are_not_evaluated(self):
        new,c0,c1=make(); original=np.linalg.solve; shapes=[]
        def solve(a,b):
            shapes.append(a.shape)
            return original(a,b)
        with patch('numpy.linalg.solve',side_effect=solve):
            new.evaluate(c0,c1,[0.,.5],models=('B_CN','B_G'))
        self.assertEqual(shapes,[(2,1,new.D,new.D)])
        new,_,_=make(); shapes.clear()
        with patch.object(new,'_normal',side_effect=AssertionError('Unexpected Gaussian density')):
            with patch('numpy.linalg.solve',side_effect=solve):
                new.evaluate(c0,c1,[0.,.5],models=('A0_CN',))
        self.assertEqual(shapes,[(2,new.K,new.P,new.P)])

    def test_one_selected_law_only_uses_R_rows(self):
        for name in MODELS[1:]:
            new,c0,c1=make(); shapes=[]; original=new._normal
            def normal(mu,cov,data):
                shapes.append(data.shape)
                return original(mu,cov,data)
            with patch.object(new,'_normal',side_effect=normal):
                new.evaluate(c0,c1,[.5],models=(name,))
            self.assertEqual(shapes,[(new.R,1 if name.startswith('B') else new.K,new.D)])
            self.assertEqual(new.logl_values,new.R)

    def test_selected_budget_before_density_and_failure_charge(self):
        new,c0,c1=make(budget=12)
        new.evaluate(c0,c1,[0.,1.],models=('B_CN','B_G'))
        self.assertEqual(new.logl_values,12)
        with patch.object(new,'moments',side_effect=AssertionError('Work before budget guard')):
            with self.assertRaises(RuntimeError): new.evaluate(c0,c1,[0.],models=('B_CN',))
        self.assertEqual(new.completed_logl_values,12)
        old,_,_=make(frozen.ConditionalLikelihood,budget=12)
        with self.assertRaises(RuntimeError): old.evaluate(c0,c1,[0.,1.])
        new,_,_=make(budget=6)
        with patch.object(new,'_normal',side_effect=np.linalg.LinAlgError('Injected synthetic factor failure')):
            with self.assertRaises(np.linalg.LinAlgError): new.evaluate(c0,c1,[.5],models=('B_CN','B_G'))
        self.assertEqual(new.logl_values,6); self.assertEqual(new.completed_logl_values,0)

    def test_invalid_selection_rejected_before_work(self):
        invalid=[(),[],None,'B_CN',{'B_CN'},{'B_CN':True},np.array(['B_CN']),
                 ('B_CN','B_CN'),('missing',),(True,),(1,),(np.str_('B_CN'),)]
        for names in invalid:
            new,c0,c1=make()
            with patch.object(new,'moments',side_effect=AssertionError('Unexpected covariance work')):
                with self.assertRaises(ValueError): new.evaluate(c0,c1,[0.],models=names)
                with self.assertRaises(ValueError): new.preflight(1,models=names)
            self.assertEqual(new.logl_values,0)

    def test_conservative_memory_guard_retained_for_selection(self):
        new,c0,c1=make(memory=1)
        with self.assertRaises(RuntimeError): new.evaluate(c0,c1,[0.],models=('B_CN',))
        self.assertEqual(new.logl_values,0)
        new,_,_=make()
        p=new.preflight(4,models=('B_CN',)); full=new.preflight(4)
        self.assertEqual(p['estimated_numeric_workspace_bytes'],full['estimated_numeric_workspace_bytes'])
        self.assertEqual(p['components_bytes'],full['components_bytes'])
        self.assertEqual(p['logl_values_requested'],12)
        self.assertEqual(p['workspace_policy'],'CONSERVATIVE_FULL_V2_ESTIMATE')

    def test_zero_endpoint_and_splitting_for_C_routes(self):
        new,c0,c1=make(); names=('B_CN','B_G')
        joint,_=new.evaluate(c0,c1,[0.,.2,1.],models=names)
        split=np.concatenate([new.evaluate(c0,c1,[e],models=names)[0] for e in [0.,.2,1.]])
        np.testing.assert_allclose(joint,split,rtol=1e-13,atol=1e-12)
        zero,_=new.evaluate(c0,c1*0,[0.],models=names)
        np.testing.assert_array_equal(zero[0],joint[0])

    def test_three_routings_request_nine_densities_not_fifteen(self):
        engines=[make()[0] for _ in range(3)]
        old,c0,c1=make(frozen.ConditionalLikelihood); expected,_=old.evaluate(c0,c1,[.25,.75])
        routes=[MODELS,('B_CN','B_G'),('B_CN','B_G')]
        got=[engine.evaluate(c0,c1,[.25,.75],models=route)[0]
             for engine,route in zip(engines,routes)]
        np.testing.assert_array_equal(got[0],expected)
        for values in got[1:]: np.testing.assert_array_equal(values,expected[:,[2,4],:])
        self.assertEqual(sum(engine.logl_values for engine in engines),2*3*9)
        self.assertEqual(sum(engine.completed_logl_values for engine in engines),2*3*9)


if __name__=='__main__': unittest.main(verbosity=2)
