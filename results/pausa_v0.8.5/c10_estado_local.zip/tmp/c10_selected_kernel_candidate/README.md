# C10 — API seletiva de likelihood, candidata

Este pacote remove o cálculo das seis densidades descartadas na rota C10 de três variantes: cinco modelos em D e somente dois em cada uma de Cβ e Cfull. É um componente puro em covariâncias, testado com matrizes e observações sintéticas. Não contém executor físico, nova ORF, banco, dados PTA, campanha posterior ou autorização de execução. Os arquivos anteriores permanecem intactos; `baseline_v2/conditional_kernel.py` é uma cópia byte a byte do kernel v2.

## Contrato mínimo

```python
values, covariance_checks = engine.evaluate(C0, C1, epsilon,
                                            models=('B_CN', 'B_G'))
preflight = engine.preflight(len(epsilon), models=('B_CN', 'B_G'))
```

O retorno tem forma `(E, len(models), R)`, na ordem solicitada. `models` aceita lista/tupla não vazia, de strings Python conhecidas e sem repetições. São rejeitados nomes desconhecidos, duplicatas, strings isoladas, conjuntos, arrays e booleanos. O valor padrão conserva a API anterior e a ordem `A0_CN, A_CN, B_CN, A_G, B_G`; o futuro executor C10 deve passar a seleção explicitamente conforme `selection_config.json`.

| Resposta recebida em C0/C1 | `models` requerido | Rótulos científicos |
|---|---|---|
| D | A0_CN, A_CN, B_CN, A_G, B_G | mesmos nomes |
| Cβ | B_CN, B_G | C_beta_CN, C_beta_G |
| Cfull | B_CN, B_G | C_full_CN, C_full_G |

O kernel não escolhe uma resposta física nem converte D em Cβ/Cfull; os nomes C são rótulos do futuro chamador, que deve fornecer as covariâncias corretas. As fórmulas de densidade CN normalizada, normal real, momentos de estatísticas quadráticas e compressão com `w`/`w²` não mudaram. Não se calcularam primeiro cinco saídas para descartar três: ramos não pedidos não chamam a respectiva densidade. Pedir somente CN ou G dentro de A/B envia exatamente R observações ao solve normal; pedir ambas reutiliza a fatoração com 2R observações.

`hermitian`, `real_array`, construtor, `_normal` e `moments` têm AST idêntica ao v2. As verificações de C0/C1 e a base de momentos continuam sendo calculadas mesmo para A0 sozinho. Não se tentou otimizar toda álgebra auxiliar. Não foram acrescentados clipping, jitter, reparo SPD, nova convenção escalar ou mudança da aceitação de roundoff da versão anterior.

## Custo e falhas

Cada chamada reserva `E × len(models) × R` valores **antes de qualquer densidade**. Uma falha posterior conserva essa reserva inteira e não incrementa `completed_logl_values`. A seleção inválida ou o teto insuficiente interrompem antes do trabalho de covariância. A contabilidade é por instância, como no v2; o futuro executor precisa de ledger agregado entre variantes, instâncias, níveis, verificações e tentativas falhas. A API isolada não impõe o teto global da campanha.

A estimativa de memória preserva integralmente a soma conservadora do v2, inclusive para subconjuntos. Isso evita reivindicar uma redução de memória não medida; continua sendo estimativa numérica, não certificado de RSS nem orçamento completo de um executor.

A aritmética do registro parcial anterior é preservada:

- 16 IDs em 257×129;
- quatro refinamentos 513×257, com desconto dos pontos 257×129 aninhados **somente se seu reuso for autorizado**;
- quatro referências independentes 384×96.

São 1.072.656 pontos de ID/parâmetros: **9.653.904** densidades com a seleção (5+2+2), contra **16.089.840** na API antiga (5+5+5). A diferença removida é 6.435.936. O teto continua **15.000.000**. A diferença aritmética de 5.346.096 para esse teto não é uma alocação de trabalho adicional.

Ainda faltam reservas para verdades fora da malha, contornos diretos/adaptativos, referências extras de kernel e controle de massa omitida/underflow, além de gates globais de CPU/RSS/ORF. Reuso nodal exige identidade e autorização próprias. A tabela linear histórica de 513 nós continua **COMPONENT_ORF_TABLE_FAIL**. Não foi carregada, reavaliada ou promovida por este pacote. Remover a interpolação da ORF não valida a interpolação/integral da likelihood nem seu contorno logL.

O alvo do desenho continua 2D condicional em `(u, ε)`, com quatro nuisances fixadas, medidas `du/0,999` e `dε`, usando larguras físicas das células. A borda ε=0 é tensorial na mesma massa positiva. Não representa uma amostra da métrica FP escalar singular em u=0.

## Verificação reproduzível

Da raiz do repositório:

```sh
.venv/bin/python tmp/c10_selected_kernel_candidate/validate.py
.venv/bin/python tmp/c10_selected_kernel_candidate/prepare_metadata.py
```

A primeira execução registrada teve **16 testes PASS**, 0,474287 s de CPU total do processo e RSS máximo de 108.052.480 B, NumPy 2.4.3/SciPy 1.17.1, BLAS com uma thread. O runner limita CPU a 30 s. São sete testes v2 preservados e nove testes novos: 31 subconjuntos não vazios, cada um na ordem direta/inversa (62 verificações), igualdade padrão, seleção real de ramos/observações, ordem/guardas, reserva em falha, memória, ε=0, separação de batches e roteamento nove-versus-quinze.

A maior diferença observada dos 62 casos foi zero, e o caminho padrão de cinco saídas foi bit a bit igual no TOY. Isso descreve estes casos e este ambiente, sem impor igualdade bit a bit universal de BLAS. A suíte preservada compara independentemente as densidades contra SciPy e os momentos contra traços diretos. `test_output.txt` e `validation.json` registram o ensaio; `metadata_validation.json` verifica snapshots, funções intactas e contas sem importar o kernel. Nenhum teste leu dados ou respostas físicas.

`kernel_delta.patch` mostra o delta mínimo; `selection_config.json` registra seleções, hipóteses e bloqueios. `manifest.json` inventaria os artefatos e seus SHA-256, sem caches. O pacote é candidato para revisão ROOT, sem campanha autorizada ou validação física nova.
