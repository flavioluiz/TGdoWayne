"""Small synthetic source/contract tests and a dimension-matched timing probe."""
import os
import resource
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
import hashlib
import json
from pathlib import Path
import sys
import time
import unittest
import numpy as np
import scipy
from selected_kernel import ConditionalLikelihood,MODELS
from epsilon_event import PolynomialEvent

HERE=Path(__file__).resolve().parent
start=time.process_time()
suite=unittest.defaultTestLoader.discover(str(HERE),pattern='test_*.py')
with (HERE/'test_output.txt').open('w') as out:result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
# Synthetic dimensions match cost-relevant linear algebra only, not physical geometry.
rng=np.random.default_rng(910100501);R,K,P,D=16,3,10,10
z=rng.normal(size=(K,P,P))+1j*rng.normal(size=(K,P,P))
C0=z@z.swapaxes(-1,-2).conj()+3*np.eye(P)[None]
z=rng.normal(size=(K,P,P))+1j*rng.normal(size=(K,P,P))
C1=.1*(z@z.swapaxes(-1,-2).conj())
z=rng.normal(size=(D,P,P))+1j*rng.normal(size=(D,P,P));H=(z+z.swapaxes(-1,-2).conj())/2
q=rng.normal(size=(R,K,P))+1j*rng.normal(size=(R,K,P))
x=rng.normal(size=(R,K,D));g=rng.normal(size=(R,K,D));w=np.ones(K)/K
def make(r):return ConditionalLikelihood(q[:r],x[:r],g[:r],H,w,maximum_logl_values=10_000_000)
engine=make(R);eps=np.linspace(0.,1.,129)
t=time.process_time()
for _ in range(8):
 for names in (MODELS,('B_CN','B_G'),('B_CN','B_G')):engine.evaluate(C0,C1,eps,models=names)
bulk_cpu=time.process_time()-t;bulk_values=8*129*16*9
single=make(1);rates={};envelope_rates={}
for model in MODELS:
 t=time.process_time()
 for _ in range(16):single.evaluate(C0,C1,np.linspace(0.,1.,32),models=(model,))
 rates[model]=(time.process_time()-t)/(16*32)
 event=PolynomialEvent(single,C0,C1,model,roundoff_allowance=1e-10)
 center=single.evaluate(C0,C1,[.5],models=(model,))[0][0,0,0]
 t=time.process_time()
 for _ in range(32):event.envelope(.25,.75,center)
 envelope_rates[model]=(time.process_time()-t)/32
worst_scalar=max(rates.values());worst_envelope=max(envelope_rates.values())
# This is explicitly a heuristic stress factor, not a probabilistic/certified bound.
base_cpu=9_653_904*(bulk_cpu/bulk_values)+5_308_416*worst_scalar+20_736*33*worst_envelope
forecast=8*base_cpu+60.
report={'schema':'C10_EXACT_SELECTED_SYNTHETIC_VALIDATION_v1',
 'status':'PASS' if result.wasSuccessful() else 'FAIL_PRESERVED','tests_run':result.testsRun,
 'failures':len(result.failures),'errors':len(result.errors),
 'CPU_seconds_with_numeric_imports':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
 'maximum_RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024),
 'numpy':np.__version__,'scipy':scipy.__version__,'seed':910100501,
 'physical_ORF_calls':0,'physical_log_likelihood_values':0,'physical_draws':0,'bank_constructed':False,
 'timing':{'label':'SYNTHETIC_RANDOM_MATRICES_NOT_PTA_BENCHMARK','dimensions':[R,K,P,D],
   'bulk_CPU_seconds':bulk_cpu,'bulk_synthetic_values':bulk_values,
   'scalar_CPU_seconds_per_value':rates,'envelope_CPU_seconds_per_cell':envelope_rates,
   'forecast_selected_grid_scalar_and_envelope_seconds':base_cpu,
   'stress_factor':8,'fixed_control_IO_import_reserve_seconds':60,
   'candidate_non_ORF_CPU_forecast_seconds':forecast,
   'does_not_certify_CPU_or_accuracy':True},
 'source_sha256':{str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest()
  for p in sorted(HERE.rglob('*.py')) if '__pycache__' not in p.parts}}
(HERE/'validation.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:report[k] for k in ('status','tests_run','CPU_seconds_with_numeric_imports','maximum_RSS_bytes','timing')},indent=2))
sys.exit(0 if result.wasSuccessful() else 1)
