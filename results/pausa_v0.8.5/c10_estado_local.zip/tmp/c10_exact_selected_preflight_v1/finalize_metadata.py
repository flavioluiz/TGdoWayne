"""Preserve the first candidate and link the independently recorded synthetic timing."""
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=json.loads((HERE/'preflight_candidate.json').read_text())
validation=json.loads((HERE/'validation.json').read_text())
if validation['status']!='PASS':raise ValueError('Synthetic tests failed')
for p in sorted(HERE.rglob('*.py')):
 if '__pycache__' not in p.parts:spec['source_sha256'][str(p.relative_to(ROOT))]=sha(p)
cpu=spec['resources']['CPU_pilot']
cpu['synthetic_timing']={'path':str((HERE/'validation.json').relative_to(ROOT)),'sha256':sha(HERE/'validation.json')}
cpu['candidate_non_ORF_CPU_forecast_seconds']=validation['timing']['candidate_non_ORF_CPU_forecast_seconds']
cpu['candidate_total_new_CPU_forecast_seconds']=cpu['candidate_non_ORF_CPU_forecast_seconds']+spec['resources']['ORF']['forecast_new_CPU_seconds']
cpu['justification_status']='SYNTHETIC_FORECAST_RECORDED;1800s_NEW_OPERATIONAL_CAP_REQUIRES_ROOT_APPROVAL'
spec['remaining_blockers']=[x.replace('synthetic timing forecast and ROOT decision on proposed pilot CPU/disk caps','ROOT decision on proposed pilot CPU/disk caps (synthetic forecast recorded)') for x in spec['remaining_blockers']]
spec['predecessor_preflight_sha256']=sha(HERE/'preflight_candidate.json')
spec['preparation_scope']='Functional pure nodal-grid and epsilon-cell reference runners; no physical producer or monolithic pilot lifecycle claimed complete.'
with (HERE/'preflight_final.json').open('x') as out:json.dump(spec,out,indent=2,allow_nan=False);out.write('\n')
print(json.dumps({'spec_sha256':sha(HERE/'preflight_final.json'),'candidate_total_new_CPU_forecast_seconds':cpu['candidate_total_new_CPU_forecast_seconds']},indent=2))
