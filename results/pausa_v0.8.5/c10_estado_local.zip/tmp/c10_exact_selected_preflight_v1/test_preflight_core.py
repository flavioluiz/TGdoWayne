import importlib.util
import math
from pathlib import Path
import tempfile
import unittest
import numpy as np
from scipy.integrate import quad
from selected_kernel import ConditionalLikelihood
from ledger import GlobalLedger,ScalarCache,CapacityExceeded
from nodal_runner import run_grid
from epsilon_event import PolynomialEvent,reference_slice,cover,EpsilonCell
from vendor_d1.envelope import LogRange


def engine(R=1,budget=100000):
    # Small deterministic matrices, unrelated to C06/C07 geometry or data.
    H=np.array([[[1.,0],[0,0]],[[0,0],[0,1.]]],complex)
    q=np.tile(np.array([[[.2+.1j,-.1+.4j]]]),(R,1,1))
    x=np.tile(np.array([[[.3,-.1]]]),(R,1,1))
    g=np.tile(np.array([[[.1,.5]]]),(R,1,1))
    obj=ConditionalLikelihood(q,x,g,H,[1.],maximum_logl_values=budget)
    c0=np.array([[[1.2,.1j],[-.1j,.8]]]);c1=np.array([[[.4,.03],[.03,.2]]])
    return obj,c0,c1


class CoreTests(unittest.TestCase):
    def ledger(self,path,cap=100000):
        return GlobalLedger(path,identity='TOY',allocations={'grid':cap//2,'contour':cap-cap//2},maximum_values=cap,maximum_cpu_seconds=10.)

    def test_ledger_precharge_failure_and_stage_ceiling(self):
        with tempfile.TemporaryDirectory() as d:
            l=self.ledger(Path(d)/'ledger.json',10)
            def bad():raise ArithmeticError('TOY failure')
            with self.assertRaises(ArithmeticError):l.evaluate('grid',4,bad)
            self.assertEqual(l.state['charged']['grid'],4);self.assertEqual(l.state['completed']['grid'],0)
            with self.assertRaises(CapacityExceeded):l.reserve('grid',2)
            self.assertEqual(l.state['charged']['grid'],4)
            with self.assertRaises(FileExistsError):self.ledger(Path(d)/'ledger.json',10)

    def test_scalar_cache_deduplicates_and_bounds_actual_calls(self):
        with tempfile.TemporaryDirectory() as d:
            l=self.ledger(Path(d)/'ledger.json');calls=[]
            def f(e):calls.append(len(e));return -e
            c=ScalarCache(f,l,'contour',identity='TOY:u/model/data/source',maximum_values=3)
            np.testing.assert_array_equal(c([0.,.5,.5]),[0.,-.5,-.5])
            c([.5,1.]);self.assertEqual(calls,[2,1])
            with self.assertRaises(CapacityExceeded):c([.25])
            self.assertEqual(c.charged,3)

    def test_grid_nested_reuse_exact_identity(self):
        with tempfile.TemporaryDirectory() as d:
            l=self.ledger(Path(d)/'ledger.json');en,c0,c1=engine(2)
            identity=dict.fromkeys(('nodal_component_sha256','kernel_sha256','generation_sha256','fixed_nuisance_sha256','response','harmonic_level'),'TOY')
            old,rep=run_grid(en,lambda u:(c0,c1),[.001,1.],[0.,1.],models=('B_CN','B_G'),data_ids=(4,7),identity=identity,ledger=l,stage='grid')
            self.assertEqual(rep['new_values_charged'],16)
            en1,_,_=engine(1)
            new,rep=run_grid(en1,lambda u:(c0,c1),[.001,.5,1.],[0.,.5,1.],models=('B_CN','B_G'),data_ids=(7,),identity=identity,ledger=l,stage='grid',reuse=old)
            self.assertEqual(rep['values_reused_exact_identity'],8);self.assertEqual(rep['new_values_charged'],10)
            np.testing.assert_array_equal(new.values[0,0,:,0],old.values[0,0,:,1])
            wrong=dict(identity,harmonic_level='other')
            with self.assertRaises(ValueError):run_grid(en1,lambda u:(c0,c1),[.001,1.],[0.,1.],models=('B_CN','B_G'),data_ids=(7,),identity=wrong,ledger=l,stage='grid',reuse=old)

    def test_envelopes_cover_dense_CN_and_all_normal_laws(self):
        en,c0,c1=engine()
        for name in ('A0_CN','A_CN','B_CN','A_G','B_G'):
            event=PolynomialEvent(en,c0,c1,name,roundoff_allowance=1e-12)
            for a,b in [(0.,1.),(.1,.3),(.8,1.)]:
                center=en.evaluate(c0,c1,[(a+b)/2],models=(name,))[0][0,0,0]
                box=event.envelope(a,b,center)
                values=en.evaluate(c0,c1,np.linspace(a,b,33),models=(name,))[0][:,0,0]
                self.assertTrue(np.all(values>=box.lower));self.assertTrue(np.all(values<=box.upper))
        en2,_,_=engine(2)
        with self.assertRaises(ValueError):PolynomialEvent(en2,c0,c1,'A0_CN',roundoff_allowance=0.)

    def test_constant_event_includes_plateau_and_missing_controls_stays_unresolved(self):
        class Constant:
            def envelope(self,a,b,v):return LogRange(0.,0.)
        with tempfile.TemporaryDirectory() as d:
            l=self.ledger(Path(d)/'ledger.json')
            cache=ScalarCache(lambda x:np.zeros_like(x),l,'contour',identity='TOY:plateau',maximum_values=256)
            controls={'roundoff_allowance_validated':True,'same_node_covariance_reference_validated':True}
            result=reference_slice(Constant(),cache,LogRange(0.,0.),controls=controls)
            self.assertEqual(result['interval'],[1.,1.]);self.assertTrue(result['complete_epsilon_support'])
            result=reference_slice(Constant(),cache,LogRange(0.,0.),controls={})
            self.assertEqual(result['status'],'UNRESOLVED');self.assertEqual(result['interval'],[0.,1.])

    def test_multicrossing_polynomial_no_two_root_assumption(self):
        # Two bumps, four crossings; extrema provide exact-arithmetic cell bounds.
        poly=-40*np.polynomial.Polynomial.fromroots([.25,.25,.75,.75])
        class Bumps:
            def envelope(self,a,b,v):
                roots=poly.deriv().roots();pts=[a,b]+[float(r.real) for r in roots if abs(r.imag)<1e-12 and a<r.real<b]
                vals=poly(pts);return LogRange(float(min(vals))-1e-12,float(max(vals))+1e-12)
        with tempfile.TemporaryDirectory() as d:
            l=self.ledger(Path(d)/'ledger.json');cache=ScalarCache(poly,l,'contour',identity='TOY:four_crossings',maximum_values=256)
            result=reference_slice(Bumps(),cache,LogRange(-.02,-.02),maximum_splits=16)
            self.assertFalse(result['epsilon_topology_from_root_count'])
            self.assertTrue(result['complete_epsilon_support']);self.assertLessEqual(cache.charged,256)
            self.assertEqual(result['interval'],[0.,1.])
            kinds={c['classification'] for c in result['partition']}
            self.assertIn('ambiguous',kinds)

    def test_budget_stop_keeps_support_and_no_probability_precision_claim(self):
        class Wide:
            def envelope(self,a,b,v):return LogRange(-10.,10.)
        with tempfile.TemporaryDirectory() as d:
            l=self.ledger(Path(d)/'ledger.json');cache=ScalarCache(lambda x:np.zeros_like(x),l,'contour',identity='TOY:stop',maximum_values=51)
            result=reference_slice(Wide(),cache,LogRange(0.,0.))
            self.assertEqual(result['interval'],[0.,1.]);self.assertTrue(result['complete_epsilon_support'])
            self.assertIn('CapacityExceeded',result['failure_preserved'])
            self.assertLessEqual(cache.charged,51)

if __name__=='__main__':unittest.main(verbosity=2)
