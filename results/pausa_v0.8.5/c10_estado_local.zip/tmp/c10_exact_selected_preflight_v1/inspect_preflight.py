"""Metadata-only CLI for the prospective C10 kernel/ledger/event package.

There is deliberately no physical execution switch: the physical producer and
ROOT's nodal reuse/CPU approvals are not implemented by this inspection command.
The actual pure numerical runners are nodal_runner.run_grid and reference_slice.
"""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    p=argparse.ArgumentParser();p.add_argument('--spec',type=Path,required=True)
    p.add_argument('--root',type=Path,default=Path.cwd());p.add_argument('--output',type=Path)
    args=p.parse_args();root=args.root.resolve();spec=json.loads(args.spec.read_text())
    if spec['schema']!='C10_EXACT_SELECTED_PREFLIGHT_CANDIDATE_v1' or spec['execution_enabled'] is not False:
        raise ValueError('Only the non-executing candidate schema is accepted')
    if sum(spec['resources']['likelihood_allocations'].values())>15_000_000:
        raise ValueError('Inherited LL cap exceeded')
    sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
    for name,expected in spec['source_sha256'].items():
        path=(root/name).resolve()
        if not path.is_relative_to(root) or sha(path)!=expected:raise ValueError('Source binding mismatch: '+name)
    if sha(root/spec['axes']['path'])!=spec['axes']['sha256']:raise ValueError('Axes binding mismatch')
    result={'status':'METADATA_HASHES_AND_ALLOCATION_PASS_PHYSICAL_EXECUTION_BLOCKED',
            'spec_sha256':sha(args.spec),'verified_source_count':len(spec['source_sha256']),
            'allocated_LL':sum(spec['resources']['likelihood_allocations'].values()),
            'remaining_blockers':spec['remaining_blockers'],
            'physical_ORFs':0,'physical_LL':0,'draws':0,'bank_constructed':False}
    if args.output:
        with args.output.open('x') as out:json.dump(result,out,indent=2);out.write('\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
