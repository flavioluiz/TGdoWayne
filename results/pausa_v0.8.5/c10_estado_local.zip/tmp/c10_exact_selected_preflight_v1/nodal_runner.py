"""Actual selected-kernel grid loop over supplied exact-node covariances.

No ORF interpolation, source discovery, data generation or implicit physical I/O.
A future authorized lifecycle must provide the declared covariance component.
"""
from dataclasses import dataclass
import hashlib
import numpy as np
from selected_kernel import selected_models


def axis(values):
    raw=np.asarray(values)
    if raw.dtype.kind not in 'fi' or raw.ndim!=1 or len(raw)<1:raise ValueError('Numeric one-dimensional axis required')
    out=np.array(raw,dtype=np.float64,copy=True)
    if not np.isfinite(out).all() or np.any(np.diff(out)<=0):raise ValueError('Strict finite axis required')
    return out


def axis_hash(value):return hashlib.sha256(np.asarray(value,dtype='<f8').tobytes()).hexdigest()


@dataclass(frozen=True)
class ReuseSource:
    mass:np.ndarray
    epsilon:np.ndarray
    values:np.ndarray
    identity:dict
    data_ids:tuple
    models:tuple


def run_grid(engine,covariance_at_mass,masses,epsilons,*,models,data_ids,identity,
             ledger,stage,epsilon_batch=129,reuse=None):
    names=selected_models(models);u=axis(masses);e=axis(epsilons)
    if np.any((u<.001)|(u>1)) or np.any((e<0)|(e>1)):raise ValueError('Physical prior support differs')
    if type(epsilon_batch) is not int or epsilon_batch<1 or epsilon_batch>257:raise ValueError('Explicit batch <=257 required')
    ids=tuple(data_ids)
    if len(ids)!=engine.R or len(set(ids))!=len(ids):raise ValueError('Distinct data IDs matching engine.R required')
    required=('nodal_component_sha256','kernel_sha256','generation_sha256','fixed_nuisance_sha256','response','harmonic_level')
    if not isinstance(identity,dict) or any(not isinstance(identity.get(k),str) or not identity[k] for k in required):raise ValueError('Complete exact-node identity required')
    output=np.full((len(u),len(e),len(names),engine.R),np.nan)
    reused=0
    if reuse is not None:
        if not isinstance(reuse,ReuseSource) or reuse.identity!=identity or tuple(reuse.models)!=names:raise ValueError('Reuse identity/models mismatch')
        old_u=axis(reuse.mass);old_e=axis(reuse.epsilon);old_ids=tuple(reuse.data_ids)
        old=np.asarray(reuse.values)
        if old.dtype.kind!='f' or old.shape!=(len(old_u),len(old_e),len(names),len(old_ids)) or not np.isfinite(old).all() or len(set(old_ids))!=len(old_ids):raise ValueError('Invalid cached grid')
        if any(i not in old_ids for i in ids):raise ValueError('New data cannot inherit cached densities')
        columns=[old_ids.index(i) for i in ids]
        upos={float(x).hex():i for i,x in enumerate(u)};epos={float(x).hex():i for i,x in enumerate(e)}
        for i,x in enumerate(old_u):
            if float(x).hex() not in upos:continue
            for j,y in enumerate(old_e):
                if float(y).hex() in epos:
                    output[upos[float(x).hex()],epos[float(y).hex()]]=old[i,j][:,columns]
                    reused+=len(names)*engine.R
    before=sum(ledger.state['charged'].values())
    for i,mass in enumerate(u):
        missing=np.flatnonzero(np.isnan(output[i,:,0,0]))
        if not len(missing):continue
        C0,C1=covariance_at_mass(float(mass))
        for start in range(0,len(missing),epsilon_batch):
            idx=missing[start:start+epsilon_batch];count=len(idx)*len(names)*engine.R
            def evaluate():return engine.evaluate(C0,C1,e[idx],models=names)[0]
            values=ledger.evaluate(stage,count,evaluate)
            if values.shape!=output[i,idx].shape or not np.isfinite(values).all():raise ArithmeticError('Selected output contract mismatch')
            output[i,idx]=values
    if not np.isfinite(output).all():raise ArithmeticError('Grid coverage incomplete')
    report={'status':'NODAL_LOG_LIKELIHOODS_COMPLETE_NOT_POSTERIOR_APPROVAL',
            'mass_axis_sha256':axis_hash(u),'epsilon_axis_sha256':axis_hash(e),
            'data_ids':list(ids),'models':list(names),'identity':dict(identity),
            'values_reused_exact_identity':reused,'new_values_charged':sum(ledger.state['charged'].values())-before,
            'interpolated_ORF':False,'output_shape':list(output.shape)}
    return ReuseSource(u,e,output,dict(identity),ids,names),report
