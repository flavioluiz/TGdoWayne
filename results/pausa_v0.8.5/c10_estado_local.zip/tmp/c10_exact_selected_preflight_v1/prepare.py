"""Freeze nodes and full arithmetic only. No fixture/ORF/table payload is opened."""
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
from scipy.special import roots_legendre

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda name,v:(HERE/name).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
partial_path=ROOT/'tmp/c10_exact_node_preflight/partial_metadata.json'
partial=json.loads(partial_path.read_text())
protocol_path=ROOT/'tmp/c10_execution_design/c10_protocol_candidate_v1.json'
protocol=json.loads(protocol_path.read_text())
selected_path=ROOT/'tmp/c10_selected_kernel_candidate/conditional_kernel.py'
assert sha(selected_path)==sha(HERE/'selected_kernel.py')=='828aa8b98f8a2f909de79673ef1a8c9813d20346f0c6dac081a8ad46adddf6b8'
master=partial['master_mass_nodes'];epsilon=partial['epsilon_master_nodes']
raw=struct.pack('<513d',*master)
assert hashlib.sha256(raw).hexdigest()==partial['historical_mass_axis_float64_payload_sha256']
reference_u={}
for order in (192,384):
 nodes,weights=roots_legendre(order)
 reference_u[str(order)]={'nodes':(.001+.999*(nodes+1)/2).tolist(),
                         'prior_weights':(weights/2).tolist(),
                         'weight_measure':'du/0.999, not uniform angle/beta/node index'}
all_new={float(v).hex():float(v) for row in reference_u.values() for v in row['nodes']}
for row in protocol['pilot']['data']:all_new[float(row['u']).hex()]=row['u']
for u in master:all_new.pop(float(u).hex(),None)
new_masses=sorted(all_new.values())
control_indices=[j*512//31 for j in range(32)]
axes={'schema':'C10_EXACT_SELECTED_AXES_v1','master_mass_nodes':master,
      'master_mass_payload_sha256':hashlib.sha256(raw).hexdigest(),
      'mass_indices':{str(n):list(range(0,513,512//(n-1))) for n in (129,257,513)},
      'master_epsilon_nodes':epsilon,'epsilon_indices':{str(n):list(range(0,257,256//(n-1))) for n in (65,129,257)},
      'u_reference':reference_u,'new_mass_nodes_requiring_explicit_harmonics':new_masses,
      'kernel_control_mass_indices':control_indices,
      'kernel_control_epsilon':[j/31 for j in range(32)],
      'independent_reference_ids':protocol['pilot']['independent_reference_ids'],
      'pilot_data':protocol['pilot']['data'],'pilot_seed':protocol['pilot']['seed'],
      'source_partial_sha256':sha(partial_path),'source_protocol_sha256':sha(protocol_path)}
write('axes.json',axes)
allocations={
 'fine_grids':16*9*257*129,
 'four_nested_reference_grids':4*9*(513*257-257*129),
 'four_product_references':4*9*384*96,
 'epsilon_event_references':4*9*(192+384)*256,
 'truth_three_harmonic_levels':16*9*3,
 'independent_kernel_references':16*9*32*2,
 'two_extra_ORF_levels_at_control_points':16*9*16*2,
 'epsilon_zero_C06_reference':32*9*2,
}
assert sum(allocations.values())==14_977_152<15_000_000
P=10;K=3;D=10;R=16;E=129;B=8
levels=partial['harmonic_levels']
blas_per_case=sum(2*P*r['nmu']*(2*r['lmax']) for r in levels)
contract_per_case=sum(8*P*P*(2*r['lmax']) for r in levels)
new_cases=5*len(new_masses)
construction=sum(16*r['nmu']*(r['lmax']+1)+20*P*P*(r['lmax']+1) for r in levels)
old_cpu=133.905984;old_table_cpu=25.175916
orf_forecast=4*old_table_cpu*len(new_masses)/513+3*5.
static=(16*R*K*P+32*R*K*D+16*R*D+16*D*P**2+8*K)
kernel_memory=static+64*E*K*P**2+48*E*K*P*R+64*E*K*D*R+64*K*D*P**2+40*K*D**2+48*E*K*D**2+32*E*D**2+32*E*K*D+56*E*R
Gamma_bytes=3*(513+len(new_masses))*5*2*P*P*16
fine_logs=16*9*257*129*8;ref_logs=4*9*513*257*8;product_logs=4*9*384*96*8
slices=4*9*(192+384)
# Fixed rectangular compact upper bounds: all cached epsilon/logL values and
# all final cell records can be retained without compressibility assumptions.
cache_bytes=slices*256*2*8
cell_bytes=slices*17*8*8
refs_bytes=slices*24*8
outputs={'all_master_and_reference_Gamma':Gamma_bytes,'fine_grid_logL':fine_logs,
         'higher_grid_logL_including_nested_duplicate_output':ref_logs,'product_reference_logL':product_logs,
         'scalar_cache_epsilon_logL_upper':cache_bytes,'partition_cell_arrays_upper':cell_bytes,
         'N_A_Z_contour_summaries':refs_bytes,'other_checks_generation_axes':8*1024**2,
         'ledger_metadata_sources_reserve':32*1024**2}
source_paths=[partial_path,ROOT/'tmp/c10_exact_node_preflight/PARTIAL_READ_ONLY.md',protocol_path,
 ROOT/'tmp/c10_execution_design/PROTOCOLO_CANDIDATO_REVISADO.md',
 ROOT/'tmp/c10_selected_kernel_candidate/manifest.json',selected_path,
 ROOT/'tmp/c10_orf_preflight/results/table.json',ROOT/'tmp/c10_orf_preflight/results/probes.json',
 ROOT/'tmp/c10_orf_preflight/results/ROOT_approval_table_v1.json',
 ROOT/'tmp/c10_orf_preflight/results/ROOT_approval_probes_v1.json',
 ROOT/'tmp/c10_orf_preflight/configs/orf_candidate_v1.json',
 ROOT/'tmp/c10_orf_preflight/src/planning.py',ROOT/'tmp/c10_orf_preflight/scripts/run_orf_preflight.py',
 ROOT/'tmp/c10_bilinear_v3/bilinear.py',ROOT/'tmp/c10_bilinear_v3/validation.json',
 ROOT/'src/inference/orf_blas.py',ROOT/'tmp/c10_scalar_blas/src/inference/scalar_blas.py',
 ROOT/'src/pta/__init__.py',ROOT/'src/pta/_domain.py',ROOT/'src/pta/response.py',
 ROOT/'src/pta/simulation.py',ROOT/'src/pta/statistics.py',
 ROOT/'configs/experiments/c06_moments.json',ROOT/'tmp/c10_kernel_v2/c06_zero_scalar_validation.json',
 ROOT/'tmp/c09_event_repair_v1/d1/envelope.py',ROOT/'tmp/c09_event_repair_v1/d1/polynomial.py',
 ROOT/'tmp/c09_event_repair_v1/d1/referenced_event.py']
sources={str(p.relative_to(ROOT)):sha(p) for p in source_paths}
for p in sorted(HERE.rglob('*.py')):
 if '__pycache__' not in p.parts:sources[str(p.relative_to(ROOT))]=sha(p)
spec={'schema':'C10_EXACT_SELECTED_PREFLIGHT_CANDIDATE_v1','execution_enabled':False,
 'status':'PREPARATION_ONLY_PHYSICAL_LIFECYCLE_NOT_AUTHORIZED',
 'axes':{'path':str((HERE/'axes.json').relative_to(ROOT)),'sha256':sha(HERE/'axes.json')},
 'source_sha256':sources,
 'resources':{
  'likelihood_allocations':allocations,'maximum_pilot_likelihood_values':15_000_000,
  'allocated_likelihood_values':sum(allocations.values()),'unallocated_values':15_000_000-sum(allocations.values()),
  'global_charging':'Reserve each uncached density batch durably before scoring; failures retain charge; no reseed/retry credit.',
  'ORF':{'historical_combined_CPU_seconds':old_cpu,'combined_CPU_cap_unchanged':600,
    'new_CPU_remaining_under_inherited_combined_cap':600-old_cpu,
    'new_harmonic_mass_nodes':len(new_masses),'new_case_nodes':new_cases,'sectors':2,'resolutions':levels,
    'new_harmonic_mode_matrices':new_cases*2*3,'new_sky_points':0,
    'historical_sky_configuration_points':50_240_000,'historical_sky_cap_unchanged':70_000_000,
    'real_BLAS_multiplications':new_cases*blas_per_case,
    'real_contraction_multiplication_proxy':new_cases*contract_per_case,
    'construction_operation_proxy':construction,
    'fresh_processes':3,'threads_each':1,'maximum_ORF_RSS_bytes_unchanged':512*1024**2,
    'forecast_new_CPU_seconds':orf_forecast,
    'forecast_method':'4x historical table CPU scaled by mass count, plus5s/import per fresh process; heuristic, not cap certificate.',
    'no_node_reuse_credit_without_external_receipt':True},
  'memory':{'kernel_129epsilon_R16_conservative_numeric_bytes':kernel_memory,
      'Gamma_arrays_bytes':Gamma_bytes,'largest_route_grid_bytes':max(16*5*257*129*8,4*5*513*257*8),
      'retained_numeric_working_set_upper_estimate_bytes':Gamma_bytes+kernel_memory+max(16*5*257*129*8,4*5*513*257*8)+32*1024**2,
      'target_estimated_bytes_unchanged':2*1024**3,'hard_RSS_cap_unchanged':4*1024**3,
      'phase_rule':'Sequential harmonic children, generation, selected grids, per-target bilinear, and per-slice references; no simultaneous duplicate banks.',
      'not_RSS_certificate':True},
  'disk':{'components_uncompressed_upper_bytes':outputs,'uncompressed_total_estimate_bytes':sum(outputs.values()),
          'proposed_cap_bytes':1024**3,'new_cap_requires_ROOT_approval':True,'original_protocol_had_no_numeric_disk_cap':True,
          'no_data_or_response_payload_loaded_in_preparation':True},
  'CPU_pilot':{'candidate_operational_cap_seconds':1800,'approval_pending':True,
      'inherited_pilot_CPU_cap':None,'original_main_forecast_maximum_seconds_preserved':3600,
      'justification_status':'REQUIRES_SYNTHETIC_TIMING_AND_ROOT_REVIEW; no physical benchmark claimed',
      'aggregate_includes_imports_generation_ORF_children_all_checks_failures':True},
 },
 'nodal_reuse':{'historical_status_kept':'COMPONENT_ORF_TABLE_FAIL',
  'table_sha256_from_preserved_metadata':partial['source_sha256']['tmp/c10_orf_preflight/results/table.npz'],
  'table_payload_not_rehashed_or_read_now':True,'authorized':False,
  'needed_receipt_schema':'C10_NODAL_COMPONENT_REUSE_APPROVAL_v1',
  'receipt_fields':['table_sha256','mass_payload_sha256','source_sha256','C06_geometry_fixture_sha256',
                    'sector_normalizations','case_order','all_three_harmonic_resolutions','nodal_gates_only','ROOT_authorization'],
  'forbidden_credit':'No interpolated ORF; no logL reuse across harmonic level, geometry, generation, nuisance, kernel or response identities.',
  'allowed_grid_reuse_if_approved':'Exact float64 mass/epsilon nodes and data IDs with identical full component/kernel/generation/nuisance/response/harmonic identity.',
  'coarse_grid_must_be_derived_from_same_fine_nodal_values':True},
 'epsilon_reference':{'coordinate':'epsilon on [0,1]','method':'matrix-polynomial whole-cell envelopes plus positive GL16/32 N/A/Z references',
  'C_degree':1,'mu_degree':1,'Sigma_degree':2,'root_count_assumption':None,
  'max_new_scalar_logL_per_slice':256,'slices':slices,'maximum_splits':16,'maximum_depth':16,
  'ambiguous_mass_goal':.001,'CDF_original_tolerance':.002,'same_covariance_kernel_logL_tolerance':1e-10,
  'roundoff_allowance_is_not_probability_margin':True,
  'final_physical_probability_margin_from_tolerance_forbidden':True,
  'reference_u_orders':[192,384],'all_missing_or_exhausted_slices_retained':True,
  'unresolved_interval':[0.,1.],'floatingpoint_directed_rounding':False,
  'coarse_and_fine_reference_measures_are_independent_GL_rules_not_nested':True},
 'stage_order':['metadata/source/ROOT guards','reuse nodal receipt and new harmonics3sequential workers',
  'frozen16 engineering observations with seed910100101','selected fine grids with129/65 extracted subset',
  'four selected513/257 refinements with exact-grid reuse','384/96 independent positive product reference',
  'truth/kernel/ORF/epsilon0 controls','per-u epsilon event192/384 with global cache ledger',
  'bilinear Z/H0/BF/CDF/quantile/contour comparisons and full-failure-preserving report'],
 'remaining_blockers':['ROOT approval of this exact source/config/allocations',
  'separate nodal-component reuse receipt; failed interpolation cannot supply it implicitly',
  'closed physical input producer/ORF child lifecycle and source closure',
  'synthetic timing forecast and ROOT decision on proposed pilot CPU/disk caps',
  'actual same-node reference and roundoff validation before operational event flags',
  'u192/u384 and harmonic-level propagation of N/A/Z must be assessed, not converted from nominal logL tolerances',
  'physical pilot passes before any500/1192 posterior authorization'],
 'physical_ORF_calls':0,'physical_log_likelihood_values':0,'physical_draws':0,
 'bank_constructed':False,'campaign_executed':False}
write('preflight_candidate.json',spec)
print(json.dumps({'status':spec['status'],'allocated_LL':sum(allocations.values()),
 'new_ORF_mass_nodes':len(new_masses),'new_ORF_BLAS_proxy':new_cases*blas_per_case,
 'numeric_estimate':spec['resources']['memory']['retained_numeric_working_set_upper_estimate_bytes'],
 'disk_estimate':sum(outputs.values()),'spec_sha256':sha(HERE/'preflight_candidate.json')},indent=2))
