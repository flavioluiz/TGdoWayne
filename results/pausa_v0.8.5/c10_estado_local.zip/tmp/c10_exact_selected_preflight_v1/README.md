# C10 — piloto nodal seletivo, preparação v1

**Estado: componentes numéricos funcionais e preflight candidato; execução física bloqueada.** Nenhum dado PTA, Γ, likelihood física, sorteio físico ou banco foi carregado/gerado nesta preparação. A tabela linear histórica continua `COMPONENT_ORF_TABLE_FAIL`. O pacote não altera suas fontes, caches ou evidências.

O núcleo contém `nodal_runner.run_grid` (laço real da API seletiva sobre covariâncias fornecidas), `GlobalLedger`/`ScalarCache` (pré-cobrança persistida antes das densidades) e `epsilon_event.reference_slice` (contorno por envelopes matriciais de células inteiras). A inspeção CLI é somente metadados. **Ainda falta ligar esses componentes ao produtor físico e aos processos de ORF, realizar a agregação final 2D e fechar suas referências.** Não há um `--execute` que aparente concluir esse lifecycle antes dessas integrações.

## Entrada, reuso e ordem

A API seletiva foi copiada byte a byte, SHA `828aa8b98f8a2f909de79673ef1a8c9813d20346f0c6dac081a8ad46adddf6b8`. D pede cinco saídas; Cβ e Cfull pedem somente B_CN/B_G. O nome da variante pertence ao componente de covariância; não transforma automaticamente uma covariância D em C.

Os 513 nós de u vêm dos bytes float64 descritos no preflight anterior; não foram regenerados por cossenos nem lidas as matrizes arquivadas. Os níveis 129/257 são subconjuntos de índices. ε tem mestre uniforme257 e subconjuntos65/129. A medida continua `du/0,999 × dε`, não uniforme em índice, ângulo ou β. Os 16 IDs/verdades de engenharia, quatro IDs de referência e seed910100101 são os do protocolo anterior, sem escolha baseada em resultados.

Reuso de likelihood exige igualdade de componente nodal, kernel, geração, nuisances, resposta e resolução harmônica, além dos bytes dos dois nós e do ID de dado. O reuso permite extrair quatro dados da grade de16. Rejeita mudança de nível harmônico; a grade 129/65 é extraída dos mesmos valores finos, e a grade513/257 apenas reutiliza as interseções257/129. A autorização de reuso da **tabela nodal** exige recibo separado que identifique seus gates angulares/corte/PSD, fontes, geometria, normalizações e bytes. Seu status global de interpolação FAIL não é modificado nem interpretado como essa autorização.

Lifecycle proposto: conferir fontes/recibos; três processos harmônicos sequenciais; gerar16 observações da geometria C06 e nuisances congeladas; grades seletivas; quatro refinamentos; referência de produto384×96; controles; referências do evento em ε para GLu192/384; síntese de evidências, BF, CDFs e quantis. O produtor deve preservar os9 modelos, inclusive todos os alvos não resolvidos. Nenhuma etapa aqui autoriza as500 injeções nulas,500 priori2D ou1192 dados finais.

## Ledger global e alocações

| Item | Limite de valores logL |
|---|---:|
| 16 grades257×129, nove modelos | 4.774.032 |
| Quatro513×257, descontadas interseções autorizadas | 3.552.768 |
| Quatro referências384×96, nove modelos | 1.327.104 |
| Evento em ε:36 alvos ×(192+384) u ×256 | 5.308.416 |
| Verdades16×9 em três resoluções | 432 |
| Kernel independente/candidato:16×9×32×2 | 9.216 |
| Dois níveis ORF adicionais:16×9×16×2 | 4.608 |
| ε=0 da fixture C06:32×9×2 | 576 |
| **Total candidato** | **14.977.152** |

O teto original permanece15.000.000;22.848 valores ficam sem alocação. Essa diferença não autoriza retentativas. A capacidade é separada da contagem de trabalho: cada callback ainda reserva seu custo efetivo antes da avaliação, e uma falha retém a cobrança. O ledger é de um processo numérico, com atualização atômica; não é compartilhado por fork. O lifecycle externo ainda precisa somar CPU dos filhos e conservar recibos de falhas/encerramento. Não há retomada implícita do ledger existente.

Uma referência de evento tem no máximo256 novos valores de likelihood escalar, somando centros, subdivisões e todas as quadraturas. Seu engine contém **um** dado e **um** modelo solicitado; o código rejeita engineR>1 para impedir densidades ocultas descartadas. Chaves de cache incluem a identidade do ID/modelo/massa/componente; reutilização dentro da fatia usa o float64 exato de ε.

## Contorno por células, sem hipótese de duas raízes

Para u fixo, `C=C0+εC1`; as médias das estatísticas têm grau1 e suas covariâncias grau2, com o termo cruzado completo. B usa `w` na média e `w²` na covariância. `PolynomialEvent` restringe esses polinômios exatamente à coordenada local de cada célula e chama as cópias congeladas de `d1/envelope.py`/`polynomial.py` de C09. A0 usa o envelope CN; os outros quatro métodos usam o envelope normal apropriado.

A classificação cobre todo[0,1]: dentro, fora ou ambígua em relação ao intervalo do limiar. Não conta raízes. O refinamento é determinístico, escolhendo a maior massa superior ambígua, com até16 divisões e profundidade16. Se um filho falhar, o pai continua cobrindo o intervalo. O teto256 também limita o trabalho de todas as referências; esgotá-lo produz UNRESOLVED, preservando a partição e o cache.

GL16/32 referencia as massas das uniões mescladas dentro/ambíguas e o denominador, na mesma escala e medida. Há confrontos das referências com os envelopes celulares e a massa total. A diferença GL é **diagnóstico operacional de quadratura**, não limite rigoroso de erro. As desigualdades matriciais têm fundamento em aritmética exata; a execução float64 não usa arredondamento dirigido. Uma allowance de logL precisa de validação própria e não vira uma margem de probabilidade.

Aprovação de uma fatia não aprova a CDF2D. Ainda são necessárias integração u192/u384, propagação dos três níveis harmônicos, comparação com o interpolante bilinear e controle de underflow/massa omitida. O pacote **não transforma** tolerâncias10⁻¹⁰/.001/.002 em erros de probabilidade observados. A ausência desses controles mantém[0,1]. O auxiliar `report_io.py` serializa envelopes ilimitados como null, com caminho e sinal explícitos, mantendo a ambiguidade; NaN é rejeitado.

O argumento de derivada CN recebido na revisão independente dá limite genérico de até2r cruzamentos isolados, sendo r o número de autovalores distintos não nulos nos blocos. Esse limite pode ser grande e não justificava duas raízes. Por isso a alocação de scans/bisseções foi descartada **antes** de qualquer execução física; não consta do spec ativo.

## Custos por fase

- **ORF:**583 massas novas (576 GL192/384 mais sete verdades fora do mestre), cinco casos D1/D2/D3/CB2/CB3, dois setores e três resoluções:17.490 matrizes novas;162.540.400.000 multiplicações BLAS reais,6.716.160.000 de contração como proxy e construção separada. Zero céu novo. Os50.240.000 pontos históricos permanecem sob70M. CPU histórica combinada133,905984s; o teto600s deixa466,094016s. A previsão heurística das novas ORFs é129,444905s (quatro vezes o custo histórico por massa, mais imports), sem garantir tempo nem precisão.
- **Memória:**≈119.547.640 B de arrays numéricos conhecidos por fases. Uma grade de rota é processada por vez; o evento é por alvo/u e não mantém todos os workspaces. Permanecem o alvo2GiB e teto4GiB do protocolo; a fase ORF preserva512MiB. Estimativas de arrays não são certificados RSS.
- **Disco:**292.807.072 B estimados sem contar com compressão, incluindo todas as Γ nodais, grades, pontos de cache de ε/logL, células, referências e reservas de metadados. Propõe-se teto1GiB, explicitamente **novo e pendente de aprovação**, pois o protocolo não fixava um número de disco.
- **CPU do piloto:**o protocolo anterior não fixava esse teto. Propõe-se1800s agregados, ainda pendentes de aprovação. Um TOY de dimensõesP10/K3/D10/R16, sem geometria/dados físicos, dá previsão heurística1183,731765s para trabalho numérico/controle/I/O, usando fator8, mais129,444905s ORF:1313,176670s. Não é benchmark físico nem evidência de que a campanha principal caberá em3600s; esse gate original permanece.

O controle de fontes e a contabilização final da geração, processos filhos, I/O e falhas precisam integrar o lifecycle físico antes de executar. A estimativa e a alocação podem ser rejeitadas na revisão ROOT. Nenhum teto histórico foi aumentado.

## Evidência e reprodução

`validation.json`: sete testes PASS,0,350893s CPU incluindo imports, RSS87.457.792 B; comparação densa dos envelopes CN/normal, cache, orçamento, reuso, platô, quatro cruzamentos e interrupção mantendo suporte. O timing usa matrizes aleatórias sintéticas próprias, seed910100501. Um oitavo controle de transporte, separado em `serialization_validation.json`, passou. Não foi repetida a suíte da API seletiva nem qualquer física de C06.

Leitura independente de `/root/fundamentos_c04/audit_local_c08` confirmou escala comum N/A/Z, confrontos com células/total, preservação do pai em falha e roteamento w/w². Foi somente leitura; não repetiu TOYs. Sua observação sobre ±inf motivou o writer separado, sem mudar a fonte numérica lida.

```sh
.venv/bin/python tmp/c10_exact_selected_preflight_v1/inspect_preflight.py \
  --spec tmp/c10_exact_selected_preflight_v1/preflight_ready.json
```

`preflight_ready.json` é o spec ativo. `preflight_candidate.json` e `preflight_final.json` preservam estágios de fechamento de metadados, sem qualquer execução associada. `manifest.json` lista arquivos/SHAs; caches Python ficam fora. `prepare.py`, `finalize_metadata.py` e `validate_and_time.py` documentam como os artefatos foram gerados; para reproduzi-los, usar nova pasta e preservar os registros presentes.

**Entrega parcial explícita:** o cálculo seletivo de grades, reuso e referências de ε está implementado. A preparação não fornece ainda um produtor físico nem orquestrador monolítico autorizado, e não fecha a propagação final de N/A/Z entre u/resoluções. Esses são os próximos pontos concretos para revisão/integração; este pacote não se apresenta como piloto executado ou pronto para campanha.
