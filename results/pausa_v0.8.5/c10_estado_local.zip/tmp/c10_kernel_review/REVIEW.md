# Revisão independente do kernel condicional C10

O código original foi lido e preservado em `review_sources/`, sem modificação.
O inventário identifica os bytes revisados. A auditoria confirma a álgebra das
cinco densidades no nível de covariâncias sintéticas, com uma pendência no
estimador de memória. Isso não aprova um kernel físico PTA nem uma campanha.

## Álgebra conferida

Para CN circular própria, a normalização é
`−Σk[q*k Ck⁻¹ qk + log det Ck + P log π]`. A resolução triangular complexa e
o módulo quadrado implementam essa expressão; a soma sobre canais está correta.
As leis gaussianas reais usam `−(Mahalanobis²+log det Σ+dimension log(2π))/2`.
A e B têm dimensões K·D e D; seus determinantes e constantes são distintos.

Para estimadores quadráticos hermitianos, `μi=tr(Hi C)` e
`Σij=Re tr(Hi C Hj C)`. Ao substituir C=C0+εC1, o termo linear da covariância
é `Re tr(Hi C0 Hj C1)+Re tr(Hi C1 Hj C0)`. Pela ciclicidade do traço, isso
corresponde a `s01+s01.T`, como no código. Não falta fator dois nos termos
mistos e não se deve incluir o fator dois da fórmula real para a CN própria.
A compressão usa `Σk wk μk` e `Σk wk² Σk` para canais independentes. Os índices
de realização, canal, lote ε e modelo foram conferidos.

Os dados, H e pesos são copiados no construtor. A reserva de cinco densidades
por realização ocorre antes das avaliações; uma falha posterior consome a
reserva. A rejeição de matrizes não SPD permanece explícita. A aceitação de
PSD/Hermiticidade até arredondamento é informada, sem jitter ou projeção PSD.

## Oito controles adicionais

Passaram oito controles independentes em **0,06221 s de CPU**, semente 910110702:
invariância unitária complexa; jacobianos de uma transformação invertível dos
estimadores; jacobiano de escala da CN; permutação simultânea dos índices;
lotes singleton; incremento PSD de posto um; incremento exatamente zero; e
mutação posterior de todas as entradas originais do construtor.

O teste de transformação dos estimadores exige deslocamentos diferentes em
A e B, `−K log|det T|` e `−log|det T|`, respectivamente, verificando suas
normalizações sem apenas repetir o cálculo interno. Os resultados numéricos
estão em `independent_results.json`; `independent_checks.py` os reproduz.

## K1 — orçamento conhecido omitido

`preflight` não inclui um termo que cresça como **E·K·D²** para os lotes de
covariâncias normais, seus Cholesky e temporários. Um exemplo sem avaliação
de densidade e sem alocação grande usa R=K=1, P=10, D=100, E=100:

- estimativa aprovada: 1.972.000 bytes, sob teto de 2 MiB;
- somente o array `sigma`: 8.000.000 bytes.

Portanto, ainda que a estimativa seja corretamente rotulada como algo distinto
de um certificado de RSS, ela não é conservadora nem mesmo para os arrays
numericamente conhecidos da API genérica. Incluir explicitamente os termos
quadráticos em D e uma margem para os temporários é necessário antes de usar
essa estimativa como controle prospectivo de recursos. O exemplo não demonstra
excesso de memória nas dimensões específicas da futura campanha C10.

Não foram usados dados PTA, ORFs ou posterior física. Não foram atribuídas
calibração, recuperação escalar, falsos positivos ou precisão de interpolação
a estes testes de componentes.
