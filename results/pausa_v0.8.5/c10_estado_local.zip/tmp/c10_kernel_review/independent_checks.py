"""Light independent covariance-level checks; no ORF or PTA likelihood."""
from pathlib import Path
import hashlib
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'review_sources'))
from conditional_kernel import ConditionalLikelihood


def main():
    start=time.process_time()
    rng=np.random.default_rng(910110702)
    R,K,P,D=4,3,4,3
    a=rng.normal(size=(K,P,P))+1j*rng.normal(size=(K,P,P))
    c0=a@a.swapaxes(-1,-2).conj()+np.eye(P)
    a=rng.normal(size=(K,P,P))+1j*rng.normal(size=(K,P,P))
    c1=.2*(a@a.swapaxes(-1,-2).conj())
    h=rng.normal(size=(D,P,P))+1j*rng.normal(size=(D,P,P));h=(h+h.swapaxes(-1,-2).conj())/2
    q=rng.normal(size=(R,K,P))+1j*rng.normal(size=(R,K,P))
    x=rng.normal(size=(R,K,D));g=rng.normal(size=(R,K,D));w=np.array([-.2,.7,1.4]);eps=np.array([0,.01,.4,1.])
    def engine(q=q,x=x,g=g,h=h,w=w,**kwargs):
        return ConditionalLikelihood(q,x,g,h,w,maximum_logl_values=10000,**kwargs)
    reference=engine().evaluate(c0,c1,eps)[0]
    checks=[]
    def compare(name,actual,expected,tol=2e-10):
        error=float(np.max(np.abs(actual-expected)))
        checks.append(dict(name=name,max_absolute_error=error,tolerance=tol,passed=error<=tol))
    # Unitary basis change has unit real Jacobian and preserves each q*Hq.
    u,_=np.linalg.qr(rng.normal(size=(P,P))+1j*rng.normal(size=(P,P)))
    ct0=u@c0@u.conj().T;ct1=u@c1@u.conj().T;ht=u@h@u.conj().T
    qt=np.einsum('ab,rkb->rka',u,q)
    compare('complex unitary invariance',engine(q=qt,h=ht).evaluate(ct0,ct1,eps)[0],reference)
    # Estimator change x'=Tx shifts A and B density by their separate Jacobians.
    t=np.array([[1.2,.1,-.2],[0,.8,.1],[.1,0,1.4]])
    ht=np.einsum('ab,bij->aij',t,h);xt=x@t.T;gt=g@t.T
    transformed=engine(x=xt,g=gt,h=ht).evaluate(c0,c1,eps)[0]
    expected=reference.copy();logdet=np.linalg.slogdet(t)[1]
    expected[:,[1,3]]-=K*logdet;expected[:,[2,4]]-=logdet
    compare('normal density statistic Jacobians',transformed,expected)
    # q'=s q, C'=s² C and H'=H/s² preserve estimators; only CN changes density.
    scale=1.7
    transformed=engine(q=q*scale,h=h/scale**2).evaluate(c0*scale**2,c1*scale**2,eps)[0]
    expected=reference.copy();expected[:,0]-=2*K*P*np.log(scale)
    compare('CN scale Jacobian',transformed,expected)
    # Order and batching must preserve experiment/epsilon index mapping.
    rp=np.array([2,0,3,1]);kp=np.array([2,0,1]);ep=np.array([2,0,3,1])
    permuted=engine(q=q[rp][:,kp],x=x[rp][:,kp],g=g[rp][:,kp],w=w[kp]).evaluate(c0[kp],c1[kp],eps[ep])[0]
    compare('realization channel epsilon index mapping',permuted,reference[ep][:,:,rp])
    split=np.concatenate([engine().evaluate(c0,c1,[e])[0] for e in eps])
    compare('independent singleton batches',split,reference)
    # Finite PSD rank-one increment is permitted, including exactly zero.
    rank1=np.ones_like(c1)
    actual,info=engine().evaluate(c0,rank1,eps)
    compare('rank-one increment epsilon zero',actual[0],reference[0])
    actual,info=engine().evaluate(c0,np.zeros_like(c1),eps)
    compare('zero increment all epsilon',actual,np.repeat(reference[:1],len(eps),axis=0))
    # Construction owns arrays so a caller cannot change one data representation.
    qc=q.copy();xc=x.copy();gc=g.copy();hc=h.copy();wc=w.copy()
    owned=engine(q=qc,x=xc,g=gc,h=hc,w=wc)
    for value in [qc,xc,gc,hc,wc]: value[...] = 0
    compare('constructor ownership all caller arrays',owned.evaluate(c0,c1,eps)[0],reference)
    # No large allocation or density evaluation is needed to show missing E K D².
    tiny=ConditionalLikelihood(np.zeros((1,1,10),complex),np.zeros((1,1,100)),
        np.zeros((1,1,100)),np.zeros((100,10,10)),[1.],maximum_logl_values=10000,
        maximum_workspace_bytes=2*1024**2)
    forecast=tiny.preflight(100)
    finding=dict(id='K1',estimated_bytes=forecast['estimated_numeric_workspace_bytes'],
        configured_limit_bytes=2*1024**2,sigma_array_alone_bytes=8*100*100**2,
        no_density_evaluated=tiny.logl_values==0,
        reproduced=forecast['estimated_numeric_workspace_bytes']<2*1024**2<8*100*100**2)
    report=dict(status='SYNTHETIC_DENSITY_CHECKS_PASS_WITH_WORKSPACE_ESTIMATOR_FINDING',
        scope='Covariance-level synthetic only; no ORF or PTA likelihood',seed=910110702,
        cpu_seconds=time.process_time()-start,checks=checks,checks_passed=sum(v['passed'] for v in checks),
        workspace_finding=finding,
        source_sha256=hashlib.sha256((HERE/'review_sources/conditional_kernel.py').read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (HERE/'independent_results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['status','cpu_seconds','checks_passed']}))
    if not all(v['passed'] for v in checks): raise SystemExit(1)


if __name__=='__main__':main()
