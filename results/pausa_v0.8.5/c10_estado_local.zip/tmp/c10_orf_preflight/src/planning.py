"""Read-only C06 fixture checks and arithmetic preflight; no quadratures."""
from pathlib import Path
import hashlib,json,math
from numbers import Real,Integral
import numpy as np


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_inputs(config_file,root):
    config=json.loads(Path(config_file).read_text());root=Path(root)
    if config['schema']!='C10_ORF_PREFLIGHT_CANDIDATE_V1' or config['unique_case_names']!=['D1','D2','D3','CB2','CB3']:
        raise ValueError('Unsupported candidate schema/case order.')
    if config['mass_grid_sizes']!=[129,257,513] or len(config['harmonic_resolutions'])!=3 or len(config['direct_resolutions'])!=2:
        raise ValueError('This runner requires three nested mass/harmonic levels and two direct levels.')
    if config['output_mapping']!={'dispersive':[0,1,2],'C_beta':[0,3,4],'C_full':[0,0,0]}:raise ValueError('Invalid physical/frozen mapping.')
    if len(config['mass_probes'])!=8 or len(set(config['mass_probes']))!=8 or .6 not in config['mass_probes']:
        raise ValueError('Eight distinct prospective probes including C06 u=.6 required.')
    for value in config['mass_probes']:
        if isinstance(value,bool) or not isinstance(value,Real) or not np.isfinite(value) or not .001<=value<=1:raise ValueError('Invalid mass probe.')
    for value in [config['batch_size'],config['tile_points']]:
        if isinstance(value,bool) or not isinstance(value,Integral) or value<1:raise ValueError('Positive integer batch/tile required.')
    if config['batch_size']>16:raise ValueError('Batch exceeds the inherited backend contract.')
    for value in [config['atol'],config['rtol'],config['psd_relative_roundoff_allowance']]:
        if isinstance(value,bool) or not isinstance(value,Real) or not np.isfinite(value) or value<=0:raise ValueError('Positive finite numeric tolerances required.')
    for name,expected in config['source_hashes'].items():
        if sha(root/name)!=expected:raise ValueError('Source hash mismatch: '+name)
    gc=json.loads((root/config['geometry_config']).read_text())
    with np.load(root/config['geometry_source'],allow_pickle=False) as data:
        points=data['directions'].copy();distances=data['distances_m'].copy();frequencies=data['frequencies_hz'].copy()
        fixture_gamma=np.concatenate([data['Gamma_dispersive'],data['Gamma_C_beta'][1:]],axis=0)
    if points.shape!=(10,3) or distances.shape!=(10,) or frequencies.shape!=(3,):raise ValueError('C06 P10/K3 shapes required.')
    if not np.allclose(np.sum(points*points,axis=1),1,rtol=0,atol=64*np.finfo(float).eps):raise ValueError('Fixture directions must be unit.')
    year=365.25*86400;c=299792458.;T=15*year
    if gc['duration_years']!=15 or gc['positive_fourier_channels']!=[1,2,3]:raise ValueError('C06 T15/K123 contract differs.')
    if not np.allclose(frequencies,np.arange(1,4)/T,rtol=1e-14,atol=0):raise ValueError('Unexpected physical frequencies.')
    if not np.allclose(distances/(c*year),gc['geometry']['distances_light_years'],rtol=1e-14,atol=0):raise ValueError('Distances differ from C06.')
    y=2*np.pi*frequencies[:,None]*distances[None,:]/c
    if np.max(y)>120*np.pi*(1+1e-14):raise ValueError('Phase envelope larger than120pi.')
    zero=json.loads((root/config['zero_scalar_validation']).read_text())
    if zero.get('status')!='PASS_FIXED_C06_COVARIANCE_EPSILON_ZERO_NOT_SCALAR_RECOVERY' or zero.get('ORF_evaluations')!=0 or zero.get('logl_values')!=480:
        raise ValueError('Unexpected epsilon-zero evidence scope.')
    for name,expected in zero['sha256'].items():
        if sha(root/name)!=expected:raise ValueError('Epsilon-zero source hash mismatch: '+name)
    if max(row['maximum_absolute_logl_difference'] for row in zero['checks'])>1e-10:
        raise ValueError('Epsilon-zero kernel comparison gate failed.')
    return config,dict(points=points,distances=distances,frequencies=frequencies,phases=y,
        duration_seconds=T,distance_light_years=distances/(c*year),fixture_gamma=fixture_gamma,zero_scalar_evidence=zero)


def case_inputs(u,phases):
    if isinstance(u,(bool,np.bool_)) or not isinstance(u,Real) or not np.isfinite(u) or not .001<=u<=1:raise ValueError('Mass prior coordinate u in[.001,1] required.')
    beta=[math.sqrt((1-u/k)*(1+u/k)) for k in [1,2,3]]
    return [(beta[0],phases[0]),(beta[1],phases[1]),(beta[2],phases[2]),(beta[0],phases[1]),(beta[0],phases[2])]


def mass_grid(n):
    if n not in [129,257,513]:raise ValueError('Only prospectively declared mass grids allowed.')
    result=.001+(1-.001)*(1-np.cos(np.pi*np.arange(n)/(n-1)))/2
    result[0]=.001;result[-1]=1.
    return result


def report(config,geometry):
    nmass=len(config['mass_probes']);ncases=5;P=10
    sky_base=nmass*ncases*sum(r['nmu']*r['nphi'] for r in config['direct_resolutions'])
    sky_rotation=len(config['rotated_checks'])*config['direct_resolutions'][-1]['nmu']*config['direct_resolutions'][-1]['nphi']
    sky=sky_base+sky_rotation
    # TT uses ell2..lmax; scalar ell0..lmax. Real and imaginary BLAS separately.
    per_case_blas=sum(2*P*r['nmu']*((r['lmax']-1)+(r['lmax']+1)) for r in config['harmonic_resolutions'])
    per_case_contraction=sum(8*P*P*((r['lmax']-1)+(r['lmax']+1)) for r in config['harmonic_resolutions'])
    table_n=max(config['mass_grid_sizes']);table_cases=table_n*ncases
    stored_bytes=3*table_n*ncases*2*P*P*16
    construction=sum(16*r['nmu']*(r['lmax']+1)+20*P*P*(r['lmax']+1) for r in config['harmonic_resolutions'])
    # Sum of both basis/temporary estimates at max resolution plus retained
    # table and conservative direct tiles, even though stages are sequential.
    from direct_sky import workspace_estimate
    largest=config['harmonic_resolutions'][-1];B=config['batch_size'];N=largest['nmu'];L=largest['lmax']+1
    two_basis_and_buffers=2*(8*N*L+8*P*P*L+128*N+64*P*P+16*B*P*N+96*B*N+96*B*P*L+128*B*P*P)
    direct_workspace=workspace_estimate(P,config['tile_points'],600,1200)
    maximum_estimate=stored_bytes+two_basis_and_buffers+direct_workspace+8*1024**2
    result=dict(status='PREFLIGHT_ONLY_REQUIRES_ROOT_REVIEW_BEFORE_QUADRATURE',execution_enabled=config['execution_enabled'],
        geometry=dict(P=P,K=3,T_years=15,L_min_ly=float(np.min(geometry['distance_light_years'])),
            L_max_ly=float(np.max(geometry['distance_light_years'])),
            maximum_fL_cycles=float(np.max(geometry['phases'])/(2*np.pi)),maximum_phase_radians=float(np.max(geometry['phases']))),
        unique_cases_per_mass=ncases,mappings=config['output_mapping'],
        probes=dict(masses=nmass,unique_configurations=nmass*ncases,harmonic_mode_matrices=nmass*ncases*3*2,
            direct_base_sky_configuration_points=sky_base,rotation_sky_configuration_points=sky_rotation,
            total_sky_configuration_points=sky,total_mode_points=3*sky,pulsar_mode_responses=3*sky*P,
            complex_expm1_transfer_values=sky*P,geometry_sin_cos_values=2*sky,
            direct_gram_complex_multiplications=3*sky*P*P,
            direct_gram_real_multiplications_estimate=12*sky*P*P,
            direct_geometry_Q_transfer_real_operations_proxy=4096*sky,
            harmonic_blas_real_multiplications=nmass*ncases*per_case_blas,
            harmonic_contraction_real_multiplications_estimate=nmass*ncases*per_case_contraction),
        table=dict(nested_mass_grid_sizes=config['mass_grid_sizes'],maximum_unique_mass_nodes=table_n,
            unique_beta_phase_configurations=table_cases,all_resolutions_mode_matrices=table_cases*3*2,
            retained_complex_table_bytes=stored_bytes,
            harmonic_blas_real_multiplications=table_cases*per_case_blas,
            harmonic_contraction_real_multiplications_estimate=table_cases*per_case_contraction,
            basis_construction_real_operations_proxy=construction,
            direct_new_sky_points=0,
            note='All3 harmonic resolutions at513 nodes;129/257 are exact nested subsets; no uniform/global interpolation certificate.'),
        memory=dict(known_arrays_conservative_estimate_bytes=maximum_estimate,maximum_bytes=config['limits']['maximum_memory_bytes'],
            table_bytes=stored_bytes,two_harmonic_basis_buffer_estimate_bytes=two_basis_and_buffers,direct_tile_estimate_bytes=direct_workspace,
            scope='Known arrays plus8MiB reserve; not RSS certificate; actual RSS must also be monitored.'),
        cpu=dict(limit_seconds=config['limits']['process_cpu_seconds'],measured_seconds=None,feasibility='UNMEASURED_NO_HEAVY_EXECUTION'),
        limits=config['limits'],likelihood_values_requested=0,posterior_targets_requested=0,
        zero_scalar_evidence_file=config['zero_scalar_validation'],zero_scalar_scope=config['zero_scalar_scope'])
    result['zero_scalar_evidence_summary']=dict(status=geometry['zero_scalar_evidence']['status'],
        historical_logl_values=480,new_logl_values=0,ORF_evaluations=0,
        maximum_absolute_logl_difference=max(row['maximum_absolute_logl_difference'] for row in geometry['zero_scalar_evidence']['checks']),
        source_hashes_verified=True)
    result['arithmetic_limits_pass']=bool(sky+config['limits']['light_test_sky_configuration_points']<=config['limits']['sky_configuration_points'] and maximum_estimate<=config['limits']['maximum_memory_bytes'])
    return result
