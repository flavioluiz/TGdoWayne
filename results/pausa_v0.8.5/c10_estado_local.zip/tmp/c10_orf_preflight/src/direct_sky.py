"""Independent common-sky TT(+/cross) and linked FP scalar, tiled and budgeted.

Q_FP=(P-2 chi Omega Omega)/sqrt(3), chi=1-beta², is the COMPLETE observer-
corrected response derived from H00,H0i,Hij. Its stable reduced expression is
used here; no subtraction of individual metric terms of size1/chi is performed.
"""
import time
import resource
import sys
from numbers import Integral,Real
import numpy as np
from scipy.special import roots_legendre


class WorkBudget:
    def __init__(self, *, maximum_sky_points, maximum_cpu_seconds, maximum_memory_bytes):
        for value in [maximum_sky_points,maximum_memory_bytes]:
            if isinstance(value,(bool,np.bool_)) or not isinstance(value,Integral):raise ValueError('Integer resource limits required.')
        if isinstance(maximum_cpu_seconds,(bool,np.bool_)) or not isinstance(maximum_cpu_seconds,Real):raise ValueError('Real CPU limit required.')
        self.maximum_sky_points=int(maximum_sky_points)
        self.maximum_cpu_seconds=float(maximum_cpu_seconds)
        self.maximum_memory_bytes=int(maximum_memory_bytes)
        if self.maximum_sky_points<=0 or not np.isfinite(self.maximum_cpu_seconds) or self.maximum_cpu_seconds<=0 or self.maximum_memory_bytes<=0:
            raise ValueError('Positive finite resource limits required.')
        self.reserved_sky_points=0;self.completed_sky_points=0
        self.reserved_harmonic_mode_matrices=0;self.harmonic_blas_multiplications=0
        self.started_cpu=time.process_time();self.started_wall=time.perf_counter()

    def check_cpu(self):
        if time.process_time()-self.started_cpu>self.maximum_cpu_seconds:
            raise RuntimeError('C10 ORF CPU budget exhausted.')
        peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        if (peak if sys.platform=='darwin' else 1024*peak)>self.maximum_memory_bytes:
            raise RuntimeError('Observed process RSS exceeded the C10 ORF budget.')

    def reserve(self,points,memory):
        self.check_cpu()
        if self.reserved_sky_points+points>self.maximum_sky_points:
            raise RuntimeError('Common-sky configuration point budget exhausted before work.')
        if memory>self.maximum_memory_bytes:
            raise RuntimeError('Known direct-sky workspace estimate exceeds memory limit.')
        self.reserved_sky_points+=points

    def report(self):
        return dict(reserved_sky_configuration_points=self.reserved_sky_points,
            completed_sky_configuration_points=self.completed_sky_points,
            reserved_mode_points=3*self.reserved_sky_points,
            reserved_harmonic_mode_matrices=self.reserved_harmonic_mode_matrices,
            harmonic_blas_real_multiplications=self.harmonic_blas_multiplications,
            cpu_seconds=time.process_time()-self.started_cpu,
            wall_seconds=time.perf_counter()-self.started_wall)


def workspace_estimate(npulsars,tile_points,nmu,nphi):
    # Q/frame, transfer, three mode responses, weighting/conjugation and BLAS
    # buffers; deliberately includes Np² scratch even though no outer sky cube
    # is constructed. Known numeric arrays only, not an RSS certificate.
    return int(tile_points*(1024+256*npulsars+32*npulsars**2)+32*(nmu+nphi)+128*npulsars**2)


def direct_tt_fp(beta,points,phases,*,nmu,nphi,tile_points,budget):
    if isinstance(beta,(bool,np.bool_)) or not isinstance(beta,Real) or not np.isfinite(beta) or not 0<=beta<1:
        raise ValueError('Require beta in[0,1); beta1 canonical FP metric excluded.')
    p=np.asarray(points);y=np.asarray(phases)
    if p.dtype.kind not in 'fiu' or p.ndim!=2 or p.shape[1]!=3 or not len(p) or not np.isfinite(p).all():
        raise ValueError('Nonempty finite real(N,3) directions required.')
    if not np.allclose(np.sum(p*p,axis=1),1,rtol=0,atol=64*np.finfo(float).eps):raise ValueError('Unit directions required without repair.')
    if y.dtype.kind not in 'fiu' or y.shape!=(len(p),) or not np.isfinite(y).all() or np.any(y<0):raise ValueError('Matching nonnegative finite phases required.')
    for value in [nmu,nphi,tile_points]:
        if isinstance(value,(bool,np.bool_)) or not isinstance(value,(int,np.integer)) or value<1:raise ValueError('Explicit positive integer resolutions required.')
    nmu,nphi,tile_points=map(int,[nmu,nphi,tile_points]);p=p.astype(float,copy=True);y=y.astype(float,copy=True)
    estimate=workspace_estimate(len(p),tile_points,nmu,nphi)
    budget.reserve(nmu*nphi,estimate)
    x,wx=roots_legendre(nmu)
    gram=np.zeros((2,len(p),len(p)),complex)
    chi=(1-float(beta))*(1+float(beta));peak_q=0.
    for start in range(0,nmu*nphi,tile_points):
        budget.check_cpu()
        index=np.arange(start,min(start+tile_points,nmu*nphi))
        i,j=index//nphi,index%nphi
        z=x[i];phi=2*np.pi*(j+.25)/nphi;r=np.sqrt(1-z*z)
        cs,sn=np.cos(phi),np.sin(phi)
        omega=np.column_stack((r*cs,r*sn,z))
        e_theta=np.column_stack((z*cs,z*sn,-r))
        e_phi=np.column_stack((-sn,cs,np.zeros_like(z)))
        oo=omega[:,:,None]*omega[:,None,:]
        Q=(np.eye(3)-oo-2*chi*oo)/np.sqrt(3)
        peak_q=max(peak_q,float(np.max(abs(Q))))
        mu=omega@p.T;denominator=1+beta*mu
        with np.errstate(over='ignore',invalid='ignore'):
            argument=denominator*y
        if not np.isfinite(argument).all():raise ValueError('Nonfinite direct phase.')
        numerator=-np.expm1(-1j*argument)
        factor=np.divide(numerator,denominator,out=np.broadcast_to(1j*y,denominator.shape).copy(),where=denominator!=0)
        pt=e_theta@p.T;pf=e_phi@p.T
        contractions=(pt*pt-pf*pf,2*pt*pf,np.einsum('ai,nij,aj->na',p,Q,p,optimize=False))
        square_weight=np.sqrt(wx[i]*(2*np.pi/nphi)*(3/(8*np.pi)))
        for mode,contraction in enumerate(contractions):
            response=.5*contraction*factor*square_weight[:,None]
            # Gamma_ab=R_a R_b*, not its complex conjugate.
            gram[0 if mode<2 else 1]+=response.T@response.conj()
        budget.completed_sky_points+=len(index)
    residual=float(np.max(abs(gram-gram.swapaxes(-1,-2).conj())))
    gram=(gram+gram.swapaxes(-1,-2).conj())/2
    return gram,dict(beta=float(beta),chi=chi,maximum_phase_radians=float(np.max(y)),
        sky_configuration_points=nmu*nphi,mode_points=3*nmu*nphi,
        pulsar_mode_responses=3*nmu*nphi*len(p),
        gram_complex_multiplications=3*nmu*nphi*len(p)**2,
        estimated_workspace_bytes=estimate,pre_symmetrization_residual=residual,
        maximum_absolute_complete_Q_element=peak_q,
        Q_scope='stable_complete_observer_corrected_Q_not_subtracted_singular_metric',
        component_order=['TT_sum_plus_cross','one_linked_FP_scalar'])
