# Probes executados após autorização explícita ROOT

Os probes concluíram com status `COMPONENT_ORF_PROBES_PASS`. Foram avaliadas
oito massas, cinco combinações únicas de β/fases, três resoluções harmônicas,
dois céus diretos e duas rotações: **50.240.000 pontos céu/configuração**,
150.720.000 modo-pontos e240 matrizes harmônicas de modo.

O tempo registrado foi **108,729863 s CPU**, deixando491,270137 s do orçamento
combinado de600 s. O runner monitorou RSS contra512MiB a cada checkpoint; sua
versão aprovada não serializou o valor máximo exato de RSS. Não se atribui um
valor de pico não medido no relatório. O processo concluiu sem acionar o limite.

| Gate | Máxima diferença absoluta | Resultado |
|---|---:|---|
| nμ900→1000 com ℓmax460 | 4,613×10⁻¹³ | PASS |
| ℓmax460→520 com nμ1000 | 7,889×10⁻³¹ | PASS |
| Céu500×1000→600×1200 | 4,658×10⁻¹⁴ | PASS |
| Harmônico fino versus céu independente fino | 3,278×10⁻¹² | PASS |
| Rotação u=.001/D3 | 7,094×10⁻¹⁴ | PASS |
| Rotação u=1/CB3 | 7,641×10⁻⁴¹ | PASS |
| ΓTT da fixture C06 à resolução fina | 3,084×10⁻¹² | PASS, limite10⁻¹⁰ |

Para os gates ORF, manteve-se a tolerância `10⁻⁵+10⁻³|referência|`; o maior
quociente erro/tolerância foi1,258×10⁻⁸. Os menores autovalores foram
−2,399×10⁻¹⁶ na família harmônica e−2,366×10⁻¹⁶ no céu, sem clipping.
A fase máxima realmente usada foi **376,9911184307751 radianos**, com
β∈[0,0,999999944444443]. Os números sustentam somente os casos e a geometria
avaliados; não demonstram um limite uniforme em toda a priori.

Os hashes das18 fontes e da configuração foram conferidos antes e depois,
e o NPZ foi reaberto sem pickle e teve SHA256 verificado. Suas formas são
`harmonic[3,8,5,2,10,10]` e `direct[2,8,5,2,10,10]`.
O arquivo contém os dados necessários para repetir as comparações, sem
preservar um cubo gigante de respostas por ponto de céu.

Registros: `results/ROOT_approval_probes_v1.json`, `results/probes.json`,
`results/probes.npz` e `results/probes_execution.log`. Nenhum logL, dado PTA,
posterior, BF, SBC ou recuperação escalar foi calculado por esta etapa. ROOT
posteriormente autorizou a tabela em um registro separado; a aprovação dos
probes não antecipa o resultado dos gates de interpolação dessa tabela.
