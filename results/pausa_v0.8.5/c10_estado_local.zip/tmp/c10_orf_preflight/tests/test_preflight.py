from pathlib import Path
import importlib.util,json,sys,unittest
from unittest.mock import patch
import numpy as np

BASE=Path(__file__).resolve().parents[1];ROOT=BASE.parents[1]
sys.path[:0]=[str(BASE/'src'),str(ROOT/'src'),str(ROOT/'tmp/c10_scalar_blas/src/inference')]
from direct_sky import direct_tt_fp,WorkBudget,workspace_estimate
from planning import load_inputs,case_inputs,mass_grid,report
from scalar_blas import RealScalarHarmonicBasis
from pta.orf import raw_harmonic_orf,gr_auto_exact

spec=importlib.util.spec_from_file_location('c10_orf_runner_tests',BASE/'scripts/run_orf_preflight.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
METRICS={};SKY_POINTS=0


class PreflightTests(unittest.TestCase):
    def setUp(self):
        self.config,self.geometry=load_inputs(BASE/'configs/orf_candidate_v1.json',ROOT)

    def budget(self,points=100000):
        return WorkBudget(maximum_sky_points=points,maximum_cpu_seconds=30,maximum_memory_bytes=256*1024**2)

    def test_real_fixture_and_arithmetic_only(self):
        r=report(self.config,self.geometry)
        self.assertEqual(r['geometry']['P'],10);self.assertEqual(r['geometry']['K'],3)
        self.assertAlmostEqual(r['geometry']['maximum_phase_radians'],120*np.pi,places=11)
        self.assertEqual(r['probes']['total_sky_configuration_points'],50240000)
        self.assertEqual(r['probes']['total_mode_points'],150720000)
        self.assertEqual(r['table']['all_resolutions_mode_matrices'],15390)
        self.assertTrue(r['arithmetic_limits_pass'])
        self.assertEqual(r['likelihood_values_requested'],0)
        self.assertEqual(r['zero_scalar_evidence_summary']['new_logl_values'],0)
        self.assertLessEqual(r['zero_scalar_evidence_summary']['maximum_absolute_logl_difference'],1e-10)

    def test_cases_freeze_beta_and_full_distinctly(self):
        phase=self.geometry['phases'];cases=case_inputs(.6,phase)
        self.assertEqual(len(cases),5)
        self.assertEqual(cases[0][0],cases[3][0]);self.assertEqual(cases[0][0],cases[4][0])
        np.testing.assert_array_equal(cases[1][1],cases[3][1])
        np.testing.assert_array_equal(cases[2][1],cases[4][1])
        self.assertNotEqual(cases[1][0],cases[3][0])
        self.assertEqual(self.config['output_mapping']['C_full'],[0,0,0])
        self.assertEqual(case_inputs(1,phase)[0][0],0.)
        for u in [0,1.1,np.nan,True,.5+0j]:
            with self.assertRaises(ValueError):case_inputs(u,phase)

    def test_light_complete_Q_sky_against_independent_harmonics(self):
        global SKY_POINTS
        points=self.geometry['points'];phase=self.geometry['phases'][2]*(20/(120*np.pi))
        betas=[0,.8,case_inputs(.001,self.geometry['phases'])[2][0]]
        scalar=RealScalarHarmonicBasis(points,lmax=64,nmu=128,planned_batch=3).evaluate(betas,phase)
        maximum_tt=maximum_fp=0.;budget=self.budget()
        for ib,beta in enumerate(betas):
            value,resources=direct_tt_fp(beta,points,phase,nmu=64,nphi=128,tile_points=512,budget=budget)
            SKY_POINTS+=64*128
            maximum_fp=max(maximum_fp,float(np.max(abs(value[1]-scalar[ib]))))
            for a,b in [(0,0),(0,1),(2,4),(7,9)]:
                expected=raw_harmonic_orf(beta,float(np.clip(points[a]@points[b],-1,1)),float(phase[a]),float(phase[b]),lmax=64,nmu=128)[0]
                maximum_tt=max(maximum_tt,float(abs(value[0,a,b]-expected)))
            self.assertTrue(runner.psd_report(value,self.config)['passed'])
            self.assertEqual(resources['Q_scope'],'stable_complete_observer_corrected_Q_not_subtracted_singular_metric')
        self.assertLess(maximum_tt,2e-11);self.assertLess(maximum_fp,2e-11)
        self.assertEqual(budget.completed_sky_points,3*64*128)
        METRICS.update(maximum_TT_difference=maximum_tt,maximum_FP_difference=maximum_fp,maximum_tested_phase_radians=float(np.max(phase)))

    def test_tensor_u0_control_excludes_canonical_scalar(self):
        value=raw_harmonic_orf(1,1,19,19,lmax=64,nmu=128)[0]
        self.assertLess(abs(value-gr_auto_exact(19)),2e-12)
        budget=self.budget()
        with self.assertRaises(ValueError):direct_tt_fp(1,self.geometry['points'],np.ones(10),nmu=16,nphi=32,tile_points=64,budget=budget)
        with self.assertRaises(ValueError):direct_tt_fp(.5+0j,self.geometry['points'],np.ones(10),nmu=16,nphi=32,tile_points=64,budget=budget)
        self.assertEqual(budget.reserved_sky_points,0)

    def test_limits_before_quadrature_and_failures_retained(self):
        budget=self.budget(points=1)
        with self.assertRaises(RuntimeError):direct_tt_fp(.5,self.geometry['points'],np.ones(10),nmu=16,nphi=32,tile_points=64,budget=budget)
        self.assertEqual(budget.reserved_sky_points,0)
        budget=self.budget()
        with self.assertRaises(ValueError):direct_tt_fp(.5,self.geometry['points'],np.full(10,1.7e308),nmu=16,nphi=32,tile_points=64,budget=budget)
        self.assertEqual(budget.reserved_sky_points,512);self.assertEqual(budget.completed_sky_points,0)
        with self.assertRaises(ValueError):WorkBudget(maximum_sky_points=True,maximum_cpu_seconds=30,maximum_memory_bytes=100)

    def test_nested_mass_linear_interpolation_TOY_no_ORF(self):
        for n,stride in [(129,4),(257,2),(513,1)]:
            np.testing.assert_array_equal(mass_grid(n),mass_grid(513)[::stride])
        # Analytic positive matrix toy only: interpolation and model axes, no sky.
        values=np.zeros((3,513,5,2,2,2),complex)
        values[:]=np.eye(2)*(1+mass_grid(513)[None,:,None,None,None,None])
        with patch.object(runner,'harmonic_matrices',return_value=values):
            result,arrays=runner.run_table(self.config,self.geometry,ROOT,self.budget())
        self.assertEqual(result['status'],'COMPONENT_ORF_TABLE_PASS')
        self.assertEqual(result['physical_likelihood_values'],0)
        self.assertEqual(arrays['gamma'].shape,values.shape)

    def test_complex_comparison_all_modes_and_psd_failure(self):
        array=np.ones((2,2),complex);bad=array.copy();bad[0,1]+=1j*.1
        self.assertFalse(runner.error_report(bad,array,self.config)['passed'])
        self.assertFalse(runner.psd_report(np.diag([1.,-1e-5]),self.config)['passed'])
        self.assertGreater(workspace_estimate(10,4096,600,1200),4096*10*3*16)
