# Preflight prospectivo das ORFs C10 na geometria C06

**Somente preflight e testes leves executados.** As oito massas, as quadraturas
grandes e a tabela 129/257/513 continuam sem execução. Não foram alteradas
fontes ROOT, calculadas likelihoods novas ou produzidas posteriors.

O candidato está em `configs/orf_candidate_v1.json`; o preflight verificável,
com hashes das fontes e da configuração, está em `results/preflight.json`.
Seu estado exige revisão ROOT antes de executar quadraturas. O teto de CPU
é um critério de interrupção prospectivo; não há medição que demonstre que a
campanha completa de ORFs cabe nele.

## Dados físicos e cinco configurações únicas

São lidos os arrays exatos de `results/C06/massive/fixture.npz`, cujo hash e
configuração são verificados: **10 pulsares, T=15 anos, canais k=1,2,3 e
distâncias 100–300 anos-luz**. Nenhum banco ORF C07 é construído ou carregado.
O máximo é fL/c=60 ciclos e **y=120π≈376,991 radianos**. Isso amplia o domínio
em relação aos testes leves de y≤20 e precisa da nova validação proposta.

Para cada massa u, existem cinco combinações de β e fases:

| Índice/nome | β | Fases |
|---|---|---|
| 0 / D1 | √[(1−u)(1+u)] | y1 |
| 1 / D2 | √[(1−u/2)(1+u/2)] | y2 |
| 2 / D3 | √[(1−u/3)(1+u/3)] | y3 |
| 3 / CB2 | β de D1 | y2 |
| 4 / CB3 | β de D1 | y3 |

As saídas dispersivas usam [0,1,2], Cβ usa [0,3,4] e Cfull usa [0,0,0].
Cfull congela somente a ORF, incluindo suas fases; espectros/ruídos nos canais
reais permanecem responsabilidade do kernel subsequente. Cβ congela também χ
do numerador escalar vinculado, coerentemente com β, sem trocar sua amplitude
longitudinal por um parâmetro independente.

## Respostas e métodos independentes

O caminho harmônico reutiliza o backend TT existente e
`RealScalarHarmonicBasis`. O corte ℓ e a quadratura em μ são comuns a todos os
pares e aos dois setores; TT começa em ℓ=2, FP em ℓ=0. A matriz TT contém a
soma das duas polarizações canônicas; FP contém **uma** helicidade zero
vinculada, na normalização previamente derivada. Sua potência futura é
controlada pela convenção ε=S0/ST por polarização, sem novo ajuste aqui.

O céu direto independente usa eθ/eφ explícitos para TT+/×. Para FP constrói
a matriz espacial completa dos observadores livres

`Q = (P − 2χ ΩΩ)/√3`, `P=I−ΩΩ`, `χ=(1−β)(1+β)`,

e contrai `pᵀQp`, antes de formar o produto entre respostas. Esta expressão
estável já contém a contribuição dos componentes temporais da métrica e dos
observadores. Não se reconstroem numericamente termos H00/H0i de ordem1/χ para
depois cancelá-los; a equivalência vem da derivação independente preservada.
A fase usa `expm1`, enquanto o backend harmônico usa a transferência sinc.
Os três modos compartilham nós, pesos positivos e transferência por pulsar;
o produto R_a R_b* preserva a orientação da matriz complexa.

u=0 tensorial permanece um controle separado. O runner físico exige u≥.001;
o céu FP canônico rejeita β=1. A existência de um limite escalar do observável
não o transforma em amostra da métrica singular.

## Probes e critérios congelados

Massas: `.001, .1, .6, .9, .99, .995, .9999, 1`.

- H00: ℓmax460/nμ900.
- H01: ℓmax460/nμ1000, isolando o refinamento angular.
- H11: ℓmax520/nμ1000, isolando depois o corte harmônico.
- D0: céu 500×1000; D1: céu 600×1200.
- Duas rotações adicionais em D1: u=.001/D3 e u=1/CB3; rotação determinada
  pela semente 910120101 antes dos resultados.

Todos os elementos complexos dos dois setores são confrontados com
`|diferença|≤10⁻⁵+10⁻³|referência|`, sem afrouxar a meta. Os relatórios separam
H00/H01, H01/H11, D0/D1, H11/D1 e rotações. Também examinam Hermiticidade e
autovalores; não há clipping de autovalores ou jitter. A tolerância relativa
de arredondamento PSD é10⁻¹⁰. O teste adicional da matriz TT em u=.6 compara
com a fixture C06 à mesma resolução fina, com diferença absoluta≤10⁻¹⁰.

O caminho ε=0 do kernel já possui a evidência ROOT
`tmp/c10_kernel_v2/c06_zero_scalar_validation.json`: **480 logL históricos,
diferença máxima7,105×10⁻¹⁵, zero ORFs novas nesse controle**. Seu hash e os
hashes das fontes do controle são conferidos. Ele só valida densidades para
as covariâncias C06 fixas; não valida ε>0, interpolação ou recuperação escalar.
O presente pacote não repetiu essas480 avaliações.

## Tabela posterior aos probes

A etapa separada da tabela exige um relatório de probes aprovado, com mesmos
hashes de código/configuração e arquivo de matrizes íntegro. Constrói as três
resoluções harmônicas nos513 nós Chebyshev–Lobatto de u∈[.001,1]. Os129/257 nós
são subconjuntos bit a bit, e os índices correspondentes são salvos. Isso dá
15.390 matrizes de modo (3 resoluções×513 massas×5 casos×2 setores).

Além do refinamento angular/harmônico e PSD em todos esses nós, o runner
compara, nos novos nós de257 e513, a referência calculada com a interpolação
linear da malha anterior. Os pesos convexos preservam PSD em aritmética exata.
Esses testes nodais não são um certificado de erro global entre nós, nem um
limite sobre ΔlogL físico. A meta posterior ΔlogL≤.001, a integração bilinear,
os contornos físicos, BF e SBC ainda exigem seus próprios gates.

## Contas e limites, incluindo os três modos

| Item | Quantidade prospectiva |
|---|---:|
| Céus básicos: 8×5×(500.000+720.000) | 48.800.000 pontos/configuração |
| Duas rotações finas | 1.440.000 pontos/configuração |
| Total do estágio de probes | **50.240.000 pontos/configuração** |
| TT+, TT× e FP nos mesmos pontos | **150.720.000 modo-pontos** |
| Respostas por pulsar e modo | **1.507.200.000** |
| Transferências complexas `expm1` compartilhadas pelos modos | 502.400.000 |
| Produtos complexos dos Grams diretos | 15.072.000.000 |
| Produtos reais correspondentes, quatro por complexo | 60.288.000.000 |
| Produtos BLAS harmônicos dos probes, ambos os setores | 2.230.400.000 |
| Produtos BLAS da tabela513, três resoluções, ambos os setores | **143.024.400.000** |
| Contrações harmônicas estimadas da tabela | 5.909.760.000 produtos reais |

O número de céus não é uma contagem de operações totais. O JSON registra também
trigonometria, um proxy separado para geometria/Q/transferências e construção
das bases. Esses proxies não são FLOPs medidos nem uma previsão de CPU a partir
de uma taxa nominal. A tabela não consome novos céus diretos, mas seu custo
BLAS é substancial. É uma etapa opcional posterior ao gate, sem execução
automática ou incremento de resolução ao observar falha.

O limite proposto é **70 milhões de pontos céu/configuração**, incluindo uma
reserva de100.000 para testes leves; com a definição de três modos explicitada
acima. O limite de **600 s CPU é combinado**: o estágio de tabela desconta o
CPU reportado pelos probes. Configuração de threads é fixa em1. As verificações
ocorrem por tile/lote; uma chamada já iniciada pode ultrapassar o limite até
o próximo checkpoint. Falhas consomem o trabalho reservado, ficam registradas
e não autorizam uma nova tentativa automática.

A memória de arrays conhecidos é estimada conservadoramente em **82.612.032
bytes**, incluindo24.624.000 bytes da tabela complexa, ambas as bases/buffers,
tile direto e reserva de8MiB. É inferior ao teto proposto de **512MiB**, mas
não constitui um certificado de RSS. O processo também monitora seu RSS real.
O céu é processado em tiles4096; não se materializa o cubo completo de pares
por direção. Não há custo de500/1000 posteriors ou banco ORF C07 neste pacote.

## Verificações efetivamente realizadas

Sete testes leves passaram em **1,371 s CPU** (0,143 s no teste propriamente
dito), RSS máximo89.030.656 bytes. Foram usados **24.576 pontos de céu** com
fases reduzidas a≤20 radianos. Diferenças máximas: TT1,17×10⁻¹⁴ e FP1,77×10⁻¹⁴.
Os controles incluem o β quase unitário correspondente a u=.001/k3, mas suas
fases reduzidas não aprovam a quadratura na fase física120π. O teste de malhas
usa uma matriz analítica **TOY**, sem construir a tabela física.

## Comandos e revisão necessária

Reproduzir apenas o preflight:

```sh
.venv/bin/python tmp/c10_orf_preflight/scripts/run_orf_preflight.py \
  --root . --config tmp/c10_orf_preflight/configs/orf_candidate_v1.json \
  --output tmp/c10_orf_preflight/results/preflight.json
```

Reproduzir somente testes leves:

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 \
  .venv/bin/python tmp/c10_orf_preflight/scripts/validate_light.py
```

**ROOT deve revisar este preflight antes dos probes grandes.** Nenhum registro
de aprovação foi criado. O arquivo de configuração mantém seu estado
prospectivo `execution_enabled=false`; isso não é autorização. O comando
pesado exige um registro externo de revisão com `approved=true`, a lista
explícita `stages`, `config_sha256` e o dicionário `source_hashes` completos,
iguais aos do preflight. Essa revisão explícita é a única autorização de
execução aceita pelo runner; o comportamento padrão continua apenas leitura.

Após eventual revisão, a interface preparada é:

```sh
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 OMP_NUM_THREADS=1 \
  .venv/bin/python tmp/c10_orf_preflight/scripts/run_orf_preflight.py \
  --root . --config tmp/c10_orf_preflight/configs/orf_candidate_v1.json \
  --stage probes --approval-json CAMINHO_DA_REVISAO_ROOT.json \
  --output tmp/c10_orf_preflight/results/probes.json
```

`--stage table` exige adicionalmente `--probe-results .../probes.json` e revisão
que autorize explicitamente a etapa table. Resultados pesados existentes não
podem ser sobrescritos. Nenhum dos dois comandos pesados foi executado.
