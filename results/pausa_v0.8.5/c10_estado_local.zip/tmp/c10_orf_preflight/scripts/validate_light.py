"""Only small-phase direct sky tests plus pure arithmetic/TOY; never heavy stages."""
from pathlib import Path
import importlib.util,json,sys,time,unittest,hashlib,resource
start=time.process_time();base=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('c10_orf_light_checks',base/'tests/test_preflight.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
result=unittest.TextTestRunner(verbosity=2).run(suite)
cpu=time.process_time()-start
peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
peak=int(peak if sys.platform=='darwin' else peak*1024)
passed=result.wasSuccessful() and cpu<30 and module.SKY_POINTS<100000 and peak<=256*1024**2
report=dict(status='PASS_LIGHT_ONLY_HEAVY_PROBES_NOT_EXECUTED' if passed else 'FAIL',tests_run=result.testsRun,
    failures=len(result.failures),errors=len(result.errors),CPU_seconds=cpu,process_maximum_resident_bytes=peak,
    actual_direct_sky_configuration_points=module.SKY_POINTS,heavy_sky_configuration_points=0,
    physical_likelihood_values=0,posterior_targets=0,table_built=False,
    TOY_interpolation_used=True,metrics=module.METRICS,
    source_hashes={str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(base.rglob('*.py'))})
(base/'results/light_validation.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:report[k] for k in ['status','tests_run','CPU_seconds','actual_direct_sky_configuration_points']}))
raise SystemExit(0 if passed else 1)
