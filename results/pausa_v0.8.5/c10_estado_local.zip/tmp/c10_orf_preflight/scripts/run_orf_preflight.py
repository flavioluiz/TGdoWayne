"""C10 component runner: preflight by default; heavy stages need exact review record.

No likelihood/posterior generation is performed. A table stage additionally
requires a successful probe report from these exact source/config bytes.
"""
import argparse,hashlib,importlib.util,json,os,sys,time
from pathlib import Path
RUN_CPU_START=time.process_time()

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'src'))
import numpy as np
from planning import load_inputs,case_inputs,mass_grid,report,sha
from direct_sky import WorkBudget,direct_tt_fp


def sources(config,root):
    values=dict(config['source_hashes'])
    zero=json.loads((root/config['zero_scalar_validation']).read_text())
    values.update(zero['sha256'])
    for path in sorted(BASE.rglob('*.py')):
        if '__pycache__' not in path.parts:values[str(path.relative_to(root))]=sha(path)
    return values


def error_report(actual,reference,config):
    error=np.abs(actual-reference);den=config['atol']+config['rtol']*np.abs(reference)
    if not np.isfinite(error).all() or not np.isfinite(den).all():raise ValueError('Nonfinite comparison.')
    nonzero=np.abs(reference)>0
    return dict(passed=bool(np.all(error<=den)),maximum_absolute_error=float(error.max()),
        maximum_tolerance_ratio=float(np.max(error/den)),
        maximum_relative_error_over_nonzero_reference=float(np.max(error[nonzero]/np.abs(reference[nonzero]))) if nonzero.any() else None,
        elements=int(error.size),zero_reference_elements=int(np.sum(~nonzero)))


def psd_report(matrices,config):
    anti=float(np.max(abs(matrices-matrices.swapaxes(-1,-2).conj())))
    eigen=np.linalg.eigvalsh(matrices);scale=np.maximum(np.max(abs(eigen),axis=-1),np.finfo(float).tiny)
    ratio=eigen[...,0]/scale
    return dict(passed=bool(np.all(ratio>=-config['psd_relative_roundoff_allowance'])),
        minimum_eigenvalue=float(eigen.min()),minimum_relative_eigenvalue=float(ratio.min()),
        maximum_hermitian_residual=anti,no_eigenvalue_clipping=True)


def harmonic_matrices(config,geometry,masses,root,budget):
    sys.path.insert(0,str(root/'src'))
    from inference.orf_blas import RealHarmonicBasis,TableBudget
    file=root/'tmp/c10_scalar_blas/src/inference/scalar_blas.py'
    spec=importlib.util.spec_from_file_location('c10_scalar_blas_runner',file)
    scalar=importlib.util.module_from_spec(spec);sys.modules[spec.name]=scalar;spec.loader.exec_module(scalar)
    P=len(geometry['points']);out=np.empty((3,len(masses),5,2,P,P),complex)
    for ir,r in enumerate(config['harmonic_resolutions']):
        budget.check_cpu()
        tt=RealHarmonicBasis(geometry['points'],lmax=r['lmax'],nmu=r['nmu'],
            budget=TableBudget(maximum_estimated_memory_bytes=config['limits']['maximum_memory_bytes'],maximum_batch_size=config['batch_size']),planned_batch=config['batch_size'])
        fp=scalar.RealScalarHarmonicBasis(geometry['points'],lmax=r['lmax'],nmu=r['nmu'],
            budget=scalar.ScalarTableBudget(maximum_estimated_memory_bytes=config['limits']['maximum_memory_bytes'],maximum_batch_size=config['batch_size']),planned_batch=config['batch_size'])
        for case in range(5):
            phases=case_inputs(.001,geometry['phases'])[case][1]
            for start in range(0,len(masses),config['batch_size']):
                budget.check_cpu();stop=min(start+config['batch_size'],len(masses))
                beta=np.array([case_inputs(float(u),geometry['phases'])[case][0] for u in masses[start:stop]])
                budget.reserved_harmonic_mode_matrices+=2*len(beta)
                budget.harmonic_blas_multiplications+=2*len(beta)*P*r['nmu']*(2*r['lmax'])
                out[ir,start:stop,case,0]=tt.evaluate(beta,phases)
                out[ir,start:stop,case,1]=fp.evaluate(beta,phases)
                budget.check_cpu()
        del tt,fp
    return out


def run_probes(config,geometry,root,budget):
    masses=np.asarray(config['mass_probes']);harmonic=harmonic_matrices(config,geometry,masses,root,budget)
    direct=np.empty((2,len(masses),5,2,10,10),complex);records=[]
    for im,u in enumerate(masses):
        for case,(beta,phase) in enumerate(case_inputs(float(u),geometry['phases'])):
            for ir,resolution in enumerate(config['direct_resolutions']):
                gamma,record=direct_tt_fp(beta,geometry['points'],phase,nmu=resolution['nmu'],nphi=resolution['nphi'],tile_points=config['tile_points'],budget=budget)
                direct[ir,im,case]=gamma
                records.append(dict(u=float(u),case=config['unique_case_names'][case],resolution=resolution['name'],**record))
    gates={
        'angular_nodes_only':error_report(harmonic[0],harmonic[1],config),
        'harmonic_cutoff_only':error_report(harmonic[1],harmonic[2],config),
        'direct_resolution':error_report(direct[0],direct[1],config),
        'harmonic_vs_independent_direct':error_report(harmonic[2],direct[1],config),
        'harmonic_PSD':psd_report(harmonic,config),'direct_PSD':psd_report(direct,config)}
    rng=np.random.default_rng(config['rotation_matrix_seed']);rotation,_=np.linalg.qr(rng.normal(size=(3,3)))
    rotation_records=[]
    for check in config['rotated_checks']:
        im=config['mass_probes'].index(check['u']);case=config['unique_case_names'].index(check['case'])
        beta,phase=case_inputs(check['u'],geometry['phases'])[case];r=config['direct_resolutions'][-1]
        value,record=direct_tt_fp(beta,geometry['points']@rotation.T,phase,nmu=r['nmu'],nphi=r['nphi'],tile_points=config['tile_points'],budget=budget)
        comparison=error_report(value,direct[-1,im,case],config)
        gates['rotation_'+check['case']+'_'+str(check['u'])]=comparison
        rotation_records.append(dict(**check,comparison=comparison,resources=record))
    at_c06=config['mass_probes'].index(.6)
    difference=float(np.max(abs(harmonic[-1,at_c06,:,0]-geometry['fixture_gamma'])))
    gates['C06_tensor_fixture_same_fine_resolution']=dict(passed=difference<=1e-10,maximum_absolute_error=difference,tolerance=1e-10)
    return dict(status='COMPONENT_ORF_PROBES_PASS' if all(v['passed'] for v in gates.values()) else 'COMPONENT_ORF_PROBES_FAIL',
        gates=gates,direct_records=records,rotation_records=rotation_records,
        physical_likelihood_values=0,posterior_targets=0,
        scope='C06_GEOMETRY_ORF_COMPONENT_PROBES_ONLY_NO_GLOBAL_INTERPOLATION_CERTIFICATE'),dict(masses=masses,harmonic=harmonic,direct=direct)


def run_table(config,geometry,root,budget):
    masses=mass_grid(513);gamma=harmonic_matrices(config,geometry,masses,root,budget)
    gates={'angular_nodes_only':error_report(gamma[0],gamma[1],config),
        'harmonic_cutoff_only':error_report(gamma[1],gamma[2],config),'PSD':psd_report(gamma,config)}
    for coarse,fine in [(129,257),(257,513)]:
        stride=512//(fine-1);fine_values=gamma[-1,::stride];fine_u=masses[::stride]
        low_values=fine_values[::2];low_u=fine_u[::2]
        fraction=(fine_u[1::2]-low_u[:-1])/(low_u[1:]-low_u[:-1])
        shape=(len(fraction),)+(1,)*(low_values.ndim-1)
        prediction=(1-fraction.reshape(shape))*low_values[:-1]+fraction.reshape(shape)*low_values[1:]
        gates[f'mass_linear_{coarse}_to_{fine}_new_nodes']=error_report(prediction,fine_values[1::2],config)
    return dict(status='COMPONENT_ORF_TABLE_PASS' if all(v['passed'] for v in gates.values()) else 'COMPONENT_ORF_TABLE_FAIL',
        gates=gates,physical_likelihood_values=0,posterior_targets=0,
        scope='NESTED_NODAL_CONVERGENCE_ONLY_NOT_GLOBAL_OR_PHYSICAL_LOGL_ERROR_CERTIFICATE'),dict(masses=masses,gamma=gamma,
            grid129_indices=np.arange(0,513,4),grid257_indices=np.arange(0,513,2),grid513_indices=np.arange(513))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--root',type=Path,default=Path.cwd());parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--stage',choices=['preflight','probes','table'],default='preflight')
    parser.add_argument('--approval-json',type=Path);parser.add_argument('--probe-results',type=Path)
    args=parser.parse_args();root=args.root.resolve()
    config,geometry=load_inputs(args.config,root);preflight=report(config,geometry);source_hashes=sources(config,root)
    identity=dict(config_sha256=sha(args.config),source_hashes=source_hashes)
    if args.stage=='preflight':
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(dict(**preflight,**identity),indent=2)+'\n')
        print(json.dumps(dict(status=preflight['status'],arithmetic_limits_pass=preflight['arithmetic_limits_pass'],execution_enabled=config['execution_enabled'])))
        return
    # ROOT requested a review of this exact preflight before any heavy stage.
    if args.approval_json is None:raise ValueError('Heavy stage requires an explicit ROOT review record; default is preflight only.')
    if args.output.exists() or args.output.with_suffix('.npz').exists():raise ValueError('Preserve existing heavy results; overwriting is forbidden.')
    approval=json.loads(args.approval_json.read_text())
    if approval.get('approved') is not True or args.stage not in approval.get('stages',[]) or approval.get('config_sha256')!=identity['config_sha256'] or approval.get('source_hashes')!=source_hashes:
        raise ValueError('Review record does not approve this exact stage/config/source identity.')
    if not preflight['arithmetic_limits_pass']:raise ValueError('Arithmetic limits failed.')
    for name in ['OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS','OMP_NUM_THREADS']:
        if os.environ.get(name)!='1':raise ValueError('Set '+name+'=1 before heavy execution.')
    prior_cpu=0.
    if args.stage=='table':
        if args.probe_results is None:raise ValueError('Table stage requires preserved successful probes.')
        probe=json.loads(args.probe_results.read_text())
        if probe.get('status')!='COMPONENT_ORF_PROBES_PASS' or probe.get('config_sha256')!=identity['config_sha256'] or probe.get('source_hashes')!=source_hashes:
            raise ValueError('Probe report is not a successful exact-identity gate.')
        if sha(args.probe_results.parent/probe['arrays_file'])!=probe['arrays_sha256']:raise ValueError('Probe arrays hash mismatch.')
        prior_cpu=float(probe['resources']['cpu_seconds'])
    remaining_cpu=config['limits']['process_cpu_seconds']-prior_cpu
    budget=WorkBudget(maximum_sky_points=config['limits']['sky_configuration_points'],maximum_cpu_seconds=remaining_cpu,maximum_memory_bytes=config['limits']['maximum_memory_bytes'])
    budget.started_cpu=RUN_CPU_START
    args.output.parent.mkdir(parents=True,exist_ok=True)
    try:
        result,arrays=(run_probes if args.stage=='probes' else run_table)(config,geometry,root,budget)
        for name,expected in source_hashes.items():
            if sha(root/name)!=expected:raise ValueError('Source changed during work: '+name)
        array_file=args.output.with_suffix('.npz');np.savez_compressed(array_file,**arrays)
        budget.check_cpu()
        result.update(identity,arrays_file=array_file.name,arrays_sha256=sha(array_file),resources=budget.report(),
            approval_file_sha256=sha(args.approval_json),zero_scalar_evidence=config['zero_scalar_validation'],
            zero_scalar_evidence_sha256=config['source_hashes'][config['zero_scalar_validation']],
            previous_probe_cpu_seconds=prior_cpu,combined_cpu_seconds=prior_cpu+budget.report()['cpu_seconds'],
            execution_authorized_by_exact_review_record=True)
    except Exception as exc:
        result=dict(status='COMPONENT_ORF_ABORTED_FAILURE_PRESERVED',stage=args.stage,error=type(exc).__name__+': '+str(exc),
            **identity,resources=budget.report(),physical_likelihood_values=0,posterior_targets=0)
        args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
        raise
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(status=result['status'],resources=result['resources'])))


if __name__=='__main__':main()
