# Tabela executada: nós harmônicos aprovados, interpolação linear reprovada

O estágio autorizado calculou as15.390 matrizes de modo previstas, sem novo
céu direto, logL ou posterior. CPU do estágio: **25,175916 s**; total reportado
com os probes: **133,905984 s**, abaixo do teto600 s. Os hashes das fontes e
do NPZ foram novamente conferidos. A tabela e os erros foram preservados,
sem refinar a malha, alterar tolerâncias ou executar inferência.

Os gates de quadratura angular, corte harmônico e PSD passaram em todos os
513 nós, nas cinco combinações e nos dois setores. Máximos: nμ5,243×10⁻¹³,
ℓ7,889×10⁻³¹; menor autovalor−2,399×10⁻¹⁶. Isso sustenta as matrizes nodais
no escopo dos controles; não aprova a representação linear entre os nós.

**Ambos os gates de interpolação linear falharam:**

| Malhas | Maior erro absoluto | Maior erro/tolerância |
|---|---:|---:|
| 129→257 | 0,2391827855 | 4399,6203 |
| 257→513 | 0,1055269208 | 2481,3646 |

A maior diferença absoluta129→257 ocorre em FP/CB3, auto do pulsar5,
u=0,9999623885686527: referência0,2578601033 e aproximação0,0186773178.
Na comparação257→513 ocorre em FP/CB3, par(3,7), u=0,9995393250124465:
parte real de referência0,1872081392 e aproximação0,0816812200.
Os máximos relativos à tolerância podem ocorrer em pares diferentes, onde a
correlação de referência é pequena. Todos esses índices e os valores complexos
foram salvos em `results/table_failure_locations.json`.

## Medida geométrica das células sinalizadas

Para cada célula grossa com pelo menos um elemento reprovado no novo nó de
teste, somou-se sua largura e dividiu-se pelo comprimento0,999 da priori
uniforme em u. Esta é a **massa de priori das células selecionadas por esse
critério**. Não é massa posterior, nem a medida exata do conjunto contínuo no
qual o erro supera a tolerância; um teste interno não caracteriza a célula toda.

| Caso/setor | Massa de células129→257 | Massa de células257→513 |
|---|---:|---:|
| D1 / TT | 0,679948 | 0,420571 |
| D1 / FP | 0,735698 | 0,645142 |
| D2 / TT | 0 | 0 |
| D2 / FP | 0,348532 | 0 |
| D3 / TT | 0 | 0 |
| D3 / FP | 0 | 0 |
| CB2 / TT | 0,756735 | 0,561186 |
| CB2 / FP | 0,797850 | 0,679948 |
| CB3 / TT | 0,787731 | 0,615405 |
| CB3 / FP | 0,817197 | 0,708215 |

A união dos casos/setores seleciona92 de128 células na primeira comparação
(massa0,8171966421) e163 de256 na segunda (massa0,7082147800). Portanto, embora
os maiores erros estejam perto do limiar u=1, as falhas detectadas não se
restringem a uma única célula final. Intervalos e contagens por setor/caso
estão em `results/table_failure_cell_prior_mass.json`.

## Consequência metodológica e limites

Esta representação linear está reprovada e não deve ser usada entre os nós
em likelihoods. Avaliar a ORF pelos harmônicos nos próprios nós de uma nova
quadratura é outro caminho matemático: ele ainda pode ser investigado, mas
precisa de suas verificações de CDF, evidência, contorno e comparação direta
independente. O resultado presente não demonstra esses controles e não reduz
qualquer tolerância futura.

`results/table.json` mantém o status `COMPONENT_ORF_TABLE_FAIL` e detalha quais
gates passaram/falharam. `results/table.npz` tem SHA256
`0e2d5f8373ca89a556894f52e9d61f8728510340b50106d5475934ee4d314712`.
O wrapper externo `/usr/bin/time -lp` imprimiu tempos, mas não conseguiu ler
`sysctl kern.clockrate` na sandbox e terminou com código1 depois do Python.
Essa limitação de telemetria foi preservada no log; **não causou** a falha
numérica de interpolação. O pico RSS exato continua não disponível, e não será
inferido nem medido por repetir a campanha. O controle interno de512MiB foi
executado nos checkpoints.
