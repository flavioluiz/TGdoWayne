# Limite local de Taylor para o evento em epsilon

Para uma célula com centro x e meia largura h, a expansão escalar usa
`|ell(t)-ell(x)| <= h |ell'(x)| + h² sup|ell''|/2`.
A derivada é a da soma dos canais: seus cancelamentos são conservados.
Os limites absolutos das segundas derivadas são somados. A interseção com
o envelope anterior nunca o alarga; incompatibilidade preserva uma falha.

## CN própria, covariância afim

Escreva `C(t)=C(x)+(t-x)C'`, `L L†=C(x)`, `D=L^-1 C' L^-†`,
`z=L^-1 q`, `s=||D||₂`. Para `h s<1`, `a=(1-h s)^-1` limita a norma
da inversa da covariância embranquecida em toda a célula. Por canal:

- `ell'=-tr(D)+z†Dz`;
- `|ell''| <= d a² s² + 2 ||z||² a³ s²`.

A densidade CN é `-log det C - q†C^-1 q - d log pi`; não se insere o
fator 1/2 da normal real.

## Normal real, média afim e covariância quadrática

No centro, embranqueça `V=Sigma'`, `W=Sigma''`, o resíduo `r` e `b=mu'`
pelo mesmo Cholesky de Sigma. Defina `v0=||V||₂`, `w=||W||₂`,
`rho=h v0+h² w/2`, `a=(1-rho)^-1`, `v=v0+h w`,
`R=||r||+h||b||`, `B=||b||`. Para `rho<1`:

`ell' = -tr(V)/2 + bᵀr + rᵀVr/2`.

A diferenciação de `A=Sigma^-1` fornece

`ell''=tr(AVAV)/2-tr(AW)/2-bᵀAb-2bᵀAVAr+rᵀAWAr/2-rᵀAVAVAr`.

Após embranquecimento, a submultiplicatividade das normas fornece

`|ell''| <= d a²v²/2 + d a w/2 + a B² + 2a²BvR + a²wR²/2 + a³v²R²`.

Não se supõe monotonicidade nem quantidade de raízes do evento. Quando a
condição de Neumann falha, conserva-se o envelope anterior. Os controles
incluem CN complexa comparada a uma normal real de dimensão dobrada,
normal multicanal correlacionada, um ponto estacionário com largura
quadrática e uma célula sem limite de Neumann disponível.

As desigualdades são de aritmética exata para os polinômios fornecidos.
A avaliação float64 usa a margem explícita de logL já empregada no piloto,
mais um termo aritmético escalado. Isso não constitui arredondamento dirigido
nem limite uniforme da ORF física. A validação pontual por caches permanece
um controle finito, não uma prova de todo o contínuo.
