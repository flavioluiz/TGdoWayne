"""Synthetic checks independent of PTA draws and the selected density kernel."""
import sys
from pathlib import Path
import unittest
import numpy as np
from scipy.stats import multivariate_normal
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'src'))
from pta.epsilon_taylor import cn_taylor,normal_taylor


class TaylorChecks(unittest.TestCase):
    def test_complex_multichannel(self):
        rng=np.random.default_rng(6220101);K=3;d=4
        M=rng.normal(size=(K,d,d))+1j*rng.normal(size=(K,d,d))
        c0=np.einsum('kij,klj->kil',M,M.conj())+2*np.eye(d)
        B=rng.normal(size=(K,d,d))+1j*rng.normal(size=(K,d,d))
        c1=.1*np.einsum('kij,klj->kil',B,B.conj());q=rng.normal(size=(K,d))+1j*rng.normal(size=(K,d))
        def density(e):
            total=0.
            for C,z in zip(c0+e*c1,q):
                cov=.5*np.block([[C.real,-C.imag],[C.imag,C.real]])
                total+=multivariate_normal.logpdf(np.r_[z.real,z.imag],cov=cov)
            return total
        for a,b in ((0.,1.),(.49,.51),(.9,1.)):
            mid=(a+b)/2;out=cn_taylor(np.stack([c0,c1]),q,a,b,density(mid),roundoff_allowance=1e-10)
            self.assertTrue(out['available'])
            fd=(density(mid+1e-5)-density(mid-1e-5))/2e-5
            self.assertAlmostEqual(fd,out['derivative'],places=7)
            for e in np.linspace(a,b,201):self.assertLessEqual(out['lower'],density(e));self.assertLessEqual(density(e),out['upper'])

    def test_quadratic_correlated_normal(self):
        rng=np.random.default_rng(6220102);K=2;d=3
        B=rng.normal(size=(K,d,d));D=.08*rng.normal(size=(K,d,d))
        s0=B@B.transpose(0,2,1)+2*np.eye(d)
        s1=B@D.transpose(0,2,1)+D@B.transpose(0,2,1)
        s2=D@D.transpose(0,2,1)
        mu=rng.normal(size=(2,K,d));y=rng.normal(size=(K,d));s=np.stack([s0,s1,s2])
        def density(e):return sum(multivariate_normal.logpdf(y[k],mean=mu[0,k]+e*mu[1,k],cov=s0[k]+e*s1[k]+e*e*s2[k]) for k in range(K))
        for a,b in ((0.,1.),(.49,.51),(.9,1.)):
            mid=(a+b)/2;out=normal_taylor(mu,s,y,a,b,density(mid),roundoff_allowance=1e-10)
            self.assertTrue(out['available']);fd=(density(mid+1e-5)-density(mid-1e-5))/2e-5
            self.assertAlmostEqual(fd,out['derivative'],places=7)
            for e in np.linspace(a,b,201):self.assertLessEqual(out['lower'],density(e));self.assertLessEqual(density(e),out['upper'])

    def test_stationary_point_second_order_width(self):
        mu=np.array([[[0.]],[[1.]]]);s=np.array([[[[1.]]],[[[0.]]],[[[0.]]]]);y=np.array([[.5]])
        center=float(multivariate_normal.logpdf([.5],mean=[.5],cov=[[1.]]))
        wide=normal_taylor(mu,s,y,.4,.6,center,roundoff_allowance=0)
        narrow=normal_taylor(mu,s,y,.45,.55,center,roundoff_allowance=0)
        self.assertEqual(wide['derivative'],0.)
        self.assertAlmostEqual((wide['upper']-wide['lower'])/(narrow['upper']-narrow['lower']),4.,places=8)

    def test_unavailable_is_not_finite_claim(self):
        c=np.array([[[[.001]]],[[[10.]]]])
        # At midpoint the negative-direction covariance stays barely positive;
        # a much steeper quadratic gives an unavailable whole-cell bound.
        s=np.array([[[[.01]]],[[[0.]]],[[[10.]]]])
        out=normal_taylor(np.zeros((2,1,1)),s,np.zeros((1,1)),0.,1.,0.,roundoff_allowance=1e-10)
        self.assertFalse(out['available']);self.assertNotIn('lower',out)


if __name__=='__main__':unittest.main()
