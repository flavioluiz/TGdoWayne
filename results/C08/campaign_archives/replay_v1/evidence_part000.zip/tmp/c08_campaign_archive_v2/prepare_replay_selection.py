"""Small source/metadata inventory only. No archive/restore or numeric reads."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rel(p):return Path(p).resolve().relative_to(ROOT).as_posix()
def record(p):return dict(path=rel(p),sha256=sha(p))
def write_new(p,value):
    with Path(p).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')

def prepare():
    base=ROOT/'tmp/c08_required_high_replay_with_kl_v1'
    rp=ROOT/'tmp/c08_quantile_replay_design/frozen_c07/replay_plan.json';plan=read(rp)
    rr=ROOT/'tmp/c08_replay_ROOT/result_review.json';review=read(rr)
    if review['status']!='ALL160_REPLAY_PRODUCTS_REVIEWED' or review['execution_complete_sha256']!=sha(base/'complete.json'):
        raise ValueError('Closed replay reviewed by ROOT required')
    include=set()
    # Only explicitly selected small paths. Existing engineering/main bundles,
    # original C07 campaign trees and physical tables are never included.
    for p in [ROOT/'tmp/c08_optional_kl_consumer',ROOT/'tmp/c08_replay_result_audit_v1',
              ROOT/'tmp/c08_quantile_replay_design/frozen_c07/cuts']:
        include.add(rel(p))
    for p in sorted((ROOT/'tmp/c08_replay_ROOT').iterdir()):
        if p.is_file() and not p.name.startswith('.'):include.add(rel(p))
    for name in ['replay_plan.json','diagnostic_protocol.json']:
        include.add(rel(ROOT/'tmp/c08_quantile_replay_design/frozen_c07'/name))
    for name in ['contracts.py','endpoints.py','replay.py','run_replay.py','SCHEMAS.md','README.md']:
        include.add(rel(ROOT/'tmp/c08_quantile_replay_design'/name))
    for p in [ROOT/'tmp/c08_execution_design/quantile_brackets.py',ROOT/'tmp/c08_G0/c07_publication_resource_release.json',
              ROOT/'tmp/c08_G0/combined_LL_allocation_v1.json',ROOT/'configs/calibration/prior_predictive_500_v1.json',
              HERE/'scripts/campanha_compressao.py',Path(__file__),HERE/'README.md',HERE/'tests/test_transport.py',HERE/'tests/test_root_kinds.py']:
        include.add(rel(p))
    deps={}
    def dependency(r,role):
        name=rel(r['path']);value=dict(path=name,sha256=r['sha256'],role=role)
        if name in deps and deps[name]['sha256']!=r['sha256']:raise ValueError('Conflicting external dependency')
        deps[name]=value
    for row in plan['rows']:
        for role,r in row['original_files'].items():dependency(r,'original_C07_'+role)
        dependency(row['original_receipt'],'original_C07_preserved_archive_receipt')
    runtime=read(ROOT/'tmp/c08_replay_ROOT/runtime_inputs.json')
    for name,path in runtime.items():
        dependency(dict(path=path,sha256=plan['original_input_sha256'][name]),'original_C07_runtime_'+name)
    dependency(plan['original_manifest'],'original_C07_runtime_manifest')
    spec=dict(schema='C08_ARCHIVE_SELECTION_v1',original_repository_prefix=str(ROOT),
      campaigns=[dict(kind='replay',path=rel(base),completion_sha256=sha(base/'complete.json'),root_review=record(rr),replay_plan=record(rp))],
      include=sorted(include),external_dependencies=sorted(deps.values(),key=lambda r:r['path']),
      scope='ONLY_CLOSED_REQUIRED_C07_HIGH_REPLAY_PLUS_OPTIONAL_KL_AND_SMALL_PROVENANCE',
      original_C07_campaign_trees_included=False,engineering_main_campaign_trees_included=False,
      large_physical_tables_included=False,numerical_arrays_deserialized_during_selection=0,
      dependency_policy='C07 proposal/checkpoint/numeric/original receipts and runtime inputs stay external by exact relative path/SHA. Restore C07 separately; verificar --dependencias checks them explicitly. No implicit claim that external dependencies were packed.')
    write_new(HERE/'selection_replay_v1.json',spec)
    print(json.dumps(dict(status='REPLAY_ONLY_SELECTION_READY_FOR_REVIEW',selection_sha256=sha(HERE/'selection_replay_v1.json'),
        included_root=rel(base),small_include_paths=len(include),external_dependencies=len(deps),new_physics=0,archive_executed=False),indent=2))

if __name__=='__main__':prepare()
