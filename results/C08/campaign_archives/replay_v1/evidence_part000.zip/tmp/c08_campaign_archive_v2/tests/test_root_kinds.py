"""Two new transport-only types. All records and payloads are synthetic."""
import json
from pathlib import Path
import tempfile
import unittest
from test_transport import m

def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);m.write(p,x);return m.sha(p)

class RootKinds(unittest.TestCase):
    def replay_fixture(self,root):
        base=root/'toy_replay';base.mkdir();(base/'.campaign.lock').touch();ids=list(range(30))+[44,48]
        dep=root/'external_C07/compact.json';save(dep,dict(TOY=True));external=dict(path=str(dep),sha256=m.sha(dep))
        rows=[];optional=[1500+d for d in [25,26,44,48]]+[2000+d for d in [25,26,44,48]]
        def ref(p):return dict(path=str(p),sha256=m.sha(p))
        for model_index,model in enumerate(['A0_CN','A_CN','B_CN','A_G','B_G']):
            for datum in ids:
                target=500*model_index+datum;cp=[]
                cut=root/f'cuts/{target}.json';save(cut,dict(TOY_LOW=True))
                for r in range(4):
                    c=dict(replicate=r,raw_file=f'TOY_{target}_{r}.npz',raw_sha256=f'{target*4+r:064x}',rng_state_before={'TOY':r},rng_state_after={'TOY':r+1});cp.append(c)
                    save(base/f'replicas/target_{target:06d}_rep{r}.json',dict(status='BIT_EXACT_HIGH_REPLAY',target=target,samples=65536,raw_sha256=c['raw_sha256'],original_raw_sha256=c['raw_sha256'],original_rng_state_before=c['rng_state_before'],original_rng_state_after=c['rng_state_after'],new_seed=False,uses_truth=False))
                rows.append(dict(target=target,datum=datum,scientific_model=model,original_files={'proposal':external},original_receipt=external,cut_manifest=ref(cut),high_checkpoints=cp))
        planpath=root/'plan.json';save(planpath,dict(identity='TOY_ORIGINAL',rows=rows));plansha=m.sha(planpath)
        for row in rows:
            t=row['target'];raw={c['raw_file']:c['raw_sha256'] for c in row['high_checkpoints']}
            dp=base/f'diagnostics/{t}.json';save(dp,dict(TOY=True,numerical_flags={'passed':False}));npz=base/f'diagnostics/{t}.npz';npz.write_bytes(b'TOY_TRANSPORT_NOT_A_NUMERIC_ARRAY')
            artifacts=[ref(dp),ref(npz),row['cut_manifest']]
            if t in optional:
                ra=[]
                for j in range(9 if t<2000 else 2):
                    f=base/f'optional_kl/toy_artifacts/{t}_{j}.json';save(f,dict(TOY=True,passed=False));ra.append(ref(f))
                rp=base/f'optional_kl/receipts/target_{t:06d}.json';save(rp,dict(status='CONSUMPTION_COMPLETE',target=t,raw_sha256=raw,all_failures_retained=True,artifacts=ra));artifacts.append(ref(rp))
            ap=base/f'archives/target_{t:06d}.json';save(ap,dict(target=t,plan_sha256=plansha,status='REPLAY_COMPACT_PRESERVED',all_failures_retained=True,no_SBC_or_physical_approval=True,original_files=row['original_files'],original_receipt=external,raw_sha256=raw,artifacts=artifacts))
            save(base/f'state/target_{t:06d}.json',dict(status='C08_REPLAY_TARGET_ARCHIVED',target=t,archive_sha256=m.sha(ap)))
        for d in [25,26,44,48]:
            a=base/f'optional_kl/toy_artifacts/{1500+d}_0.json';b=base/f'optional_kl/toy_artifacts/{2000+d}_0.json'
            save(base/f'optional_kl/pairs/datum_{d:03d}.json',dict(datum=d,clipped=False,no_uniform_certificate=True,AG_statistics=ref(a),BG_statistics=ref(b)))
        ledger=dict(training=0,production=41943040,other=0,total=41943040,unclosed_reservations=0);cross=dict(ledger,production=1048576,total=1048576)
        completion=base/'complete.json';save(completion,dict(status='ALL160_MATCHED_HIGH_REPLAYS_ARCHIVED',identity='TOY_REPLAY',plan_sha256=plansha,targets=[r['target'] for r in rows],ledger=ledger,optional_KL=dict(cross_ledger=cross,status='EIGHT_RAW_PRODUCTS_CONSUMED_FOUR_KL_PAIRS',extra_replay_LL=0,additional_banks=0)))
        save(base/'replay_execution.json',dict(identity='TOY_REPLAY',authorization_sha256='TOY_AUTH'))
        review=root/'root_review.json';save(review,dict(schema='ROOT_C08_REPLAY_RESULT_REVIEW_v1',status='ALL160_REPLAY_PRODUCTS_REVIEWED',execution_complete_sha256=m.sha(completion),plan_sha256=plansha,identity='TOY_REPLAY',original_runtime_identity='TOY_ORIGINAL',authorization_sha256='TOY_AUTH',cohort_ids=ids,by_model={k:32 for k in ['A0_CN','A_CN','B_CN','A_G','B_G']},ledger=ledger,cross_ledger=cross,raw_empty=True,endpoint_statistics_retained=True,all_failures_preserved=True,original_all3200_brackets=[0.,1.],counts={'archive_artifacts_verified':488,'endpoint_statistics':68697},common_failure_counts={'TOY_failure_preserved':1}))
        spec=dict(schema='C08_ARCHIVE_SELECTION_v1',original_repository_prefix=str(root),campaigns=[dict(kind='replay',path='toy_replay',completion_sha256=m.sha(completion),root_review={'path':'root_review.json','sha256':m.sha(review)},replay_plan={'path':'plan.json','sha256':plansha})],include=['root_review.json','plan.json','cuts'],external_dependencies=[dict(path='external_C07/compact.json',sha256=m.sha(dep))])
        sel=root/'selection.json';save(sel,spec);return sel,base

    def test_replay_only_roundtrip_and_missing_C07_dependency_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve();selection,base=self.replay_fixture(root);inv=root/'inventory.json'
            m.plan(selection,root,inv);frozen=m.read(inv)
            self.assertEqual(frozen['audits'][0]['kind'],'replay');self.assertEqual(len(frozen['audits'][0]['retired_raw_sha256']),640)
            self.assertFalse(any(r['path'].startswith('external_C07/') for r in frozen['files']))
            bundle=root/'bundle';m.pack(inv,root,bundle);m.verify(bundle,root);dest=root/'restored';m.restore(bundle,dest)
            self.assertFalse((dest/'external_C07').exists());self.assertEqual(m.sha(dest/'toy_replay/complete.json'),m.sha(base/'complete.json'))
            self.assertFalse(m.read(dest/'toy_replay/diagnostics/25.json')['numerical_flags']['passed'])
            bad=m.read(selection);bad['external_dependencies']=[];badpath=root/'bad_selection.json';save(badpath,bad)
            with self.assertRaisesRegex(ValueError,'Unlisted C07'):m.plan(badpath,root,root/'bad_inventory.json')

    def test_offline_requires_explicit_ROOT_consolidation_and_preserves_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve();base=root/'offline';base.mkdir();(root/'shared').mkdir();(root/'shared/.campaign.lock').touch()
            data=base/'partial.json';save(data,dict(status='UNRESOLVED',passed=False))
            c=base/'closed.json';save(c,dict(schema='C08_OFFLINE_ROOT_COMPLETE_v1',status='ALL_SELECTED_ANALYSIS_BYTES_PRESERVED',workers_exited=True,all_failures_preserved=True,no_uniform_proof=True,identity='TOY_OFFLINE',scope='TOY_ONLY',artifacts=[dict(file='partial.json',sha256=m.sha(data),bytes=data.stat().st_size)]))
            review=root/'review.json';save(review,dict(schema='ROOT_C08_OFFLINE_ROOT_REVIEW_v1',status='OFFLINE_ROOT_COMPLETE_REVIEWED',root_path='offline',lock_path='shared/.campaign.lock',completion_sha256=m.sha(c),identity='TOY_OFFLINE',artifact_count=1))
            selection=root/'selection.json';save(selection,dict(schema='C08_ARCHIVE_SELECTION_v1',original_repository_prefix=str(root),campaigns=[dict(kind='offline',path='offline',completion_file='closed.json',completion_sha256=m.sha(c),lock_path='shared/.campaign.lock',root_review=dict(path='review.json',sha256=m.sha(review)))],include=['review.json'],external_dependencies=[]))
            inv=root/'inventory.json';m.plan(selection,root,inv);bundle=root/'bundle';m.pack(inv,root,bundle);m.restore(bundle,root/'restored')
            self.assertFalse(m.read(root/'restored/offline/partial.json')['passed'])
            changed=m.read(review);changed['status']='PENDING';review.write_text(json.dumps(changed))
            with self.assertRaises(ValueError):m.plan(selection,root,root/'bad.json')

if __name__=='__main__':unittest.main()
