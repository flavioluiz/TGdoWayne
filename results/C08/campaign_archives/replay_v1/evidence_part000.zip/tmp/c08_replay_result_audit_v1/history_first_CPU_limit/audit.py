"""Read-only completed-replay audit: JSON, compact NPZ and file SHA only.

Never imports inference, builds a bank, evaluates likelihood or regenerates
draws. Cross NPZs are hashed as bytes, never decoded. Writes only HERE.
"""
from pathlib import Path
import collections,fcntl,hashlib,itertools,json,math,resource,sys,time
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
OUT=ROOT/'tmp/c08_required_high_replay_with_kl_v1'
PLAN=ROOT/'tmp/c08_quantile_replay_design/frozen_c07/replay_plan.json'
AUTH=ROOT/'tmp/c08_replay_ROOT/authorization.json'
MODEL=['A0_CN','A_CN','B_CN','A_G','B_G'];IDS_KL=[25,26,44,48]
HASHED={};CHECKS=collections.Counter()

def need(ok,label):
    if not ok:raise AssertionError(label)
    CHECKS[label]+=1
def sha(p):
    p=Path(p).resolve();h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    value=h.hexdigest()
    if str(p) in HASHED:need(HASHED[str(p)]==value,'Revisited file unchanged')
    HASHED[str(p)]=value;return value
def read(p):
    p=Path(p);sha(p)
    return json.loads(p.read_text())
def canonical(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def bound(r):
    p=Path(r['path']).resolve();need(ROOT in p.parents and not Path(r['path']).is_symlink(),'Bound repository regular path')
    need(sha(p)==r['sha256'],'Bound SHA');return p
def same(a,b,label,atol=1e-12):need(np.allclose(a,b,rtol=2e-12,atol=atol,equal_nan=True),label)

def ledger(path,identity,expected_count,total,stage):
    intents=sorted(path.glob('*.intent.json'));ends=sorted(path.glob('*.end.json'))
    need(len(intents)==len(ends)==expected_count,'Ledger event count and zero open reservations')
    sums=collections.Counter();targets=collections.Counter()
    for i,p in enumerate(intents):
        need(p.name==f'event_{i:06d}.intent.json','Contiguous ledger sequence')
        a=read(p);b=read(p.with_name(p.name.replace('.intent','.end')))
        need(a['driver_identity']==identity and a['kind']=='production' and a['stage']==stage,'Ledger identity/kind/stage')
        need(b['intent_sha256']==sha(p) and b['status']=='COMPLETED','Ledger completion binding')
        need(type(b['likelihood_evaluations'])is int and b['likelihood_evaluations']==a['reserved_likelihood_values']==65536,'Exact counted likelihood reservation')
        need(len(a['targets'])==1,'Single-target ledger event');targets[a['targets'][0]]+=1;sums[a['kind']]+=b['likelihood_evaluations']
    need(sums['production']==total,'Ledger arithmetic total')
    return dict(training=0,production=total,other=0,total=total,unclosed_reservations=0),dict(targets)

def recompose(saved,bounds):
    """Independent sufficient-stat algebra, no original KL module import."""
    reps=saved['replica_sufficient_statistics'];need(len(reps)==4 and all(r['N']==65536 for r in reps),'Four high sufficient-stat replicas')
    N=sum(r['N'] for r in reps);J=len(reps[0]['V']);maxlog=max(r['shift'] for r in reps)
    scales=np.exp([r['shift']-maxlog for r in reps]);S=sum(t*r['S'] for t,r in zip(scales,reps))
    sum2=sum(t*t*r['S2'] for t,r in zip(scales,reps));first=np.sum([t*np.array(r['V']) for t,r in zip(scales,reps)],axis=0)
    secondfirst=np.sum([t*t*np.array(r['T']) for t,r in zip(scales,reps)],axis=0)
    secondouter=np.sum([t*t*np.array(r['U']) for t,r in zip(scales,reps)],axis=0)
    mu=first/S;logZ=maxlog+math.log(S/N);c=N/(S*S*(N-1))
    covariance=np.empty((J+1,J+1));covariance[:J,:J]=c*(secondouter-np.outer(mu,secondfirst)-np.outer(secondfirst,mu)+sum2*np.outer(mu,mu))
    covariance[:J,J]=c*(secondfirst-mu*sum2);covariance[J,:J]=covariance[:J,J];covariance[J,J]=(N*sum2/S**2-1)/(N-1)
    block=[]
    for t,r in zip(scales,reps):
        zratio=4*t*r['S']/S
        block.append(np.r_[zratio*(np.array(r['V'])/r['S']-mu),zratio-1])
    between=np.cov(np.array(block),rowvar=False,ddof=1)/4
    same(mu,saved['mean_features'],'Recomposed weighted first/second/logratio moments')
    same(logZ,saved['logZ'],'Recomposed logZ')
    same(covariance,saved['estimator_covariance_pooled'],'Recomposed pooled influence covariance',atol=1e-10)
    same(between,saved['estimator_covariance_between'],'Recomposed replica influence covariance',atol=1e-10)
    def se(g):return math.sqrt(max(0.,float(g@covariance@g),float(g@between@g)))
    eye=np.eye(J+1);same(se(eye[-1]),saved['logZ_MCSE'],'Recomposed logZ MCSE')
    widths=bounds[:,1]-bounds[:,0]
    need(len(saved['means'])==5 and len(saved['covariances'])==15,'All first and covariance moments retained')
    for i,r in enumerate(saved['means']):
        same([mu[i],bounds[i,0]+widths[i]*mu[i],se(eye[i]),widths[i]*se(eye[i])],
             [r['unit'],r['physical'],r['unit_MCSE'],r['physical_MCSE']],'Recomposed mean and affine MCSE')
    for k,(i,j) in enumerate((i,j) for i in range(5) for j in range(i,5)):
        r=saved['covariances'][k];v=mu[5+k]-mu[i]*mu[j];g=eye[5+k]-mu[j]*eye[i]-mu[i]*eye[j]
        same([v,v*widths[i]*widths[j],se(g),se(g)*widths[i]*widths[j]],
             [r['unit'],r['physical'],r['unit_MCSE'],r['physical_MCSE']],'Recomposed covariance and affine MCSE')
    failures=[]
    for r in reps:
        p=r['maximum_weight']
        if p>=1 or p/(1-p)>.00335:failures.append('original_single_deletion_weight_guard')
        if r['saturated_weight']>1e-12:failures.append('original_saturation_guard')
    need(sorted(set(failures))==saved['failures'],'KL weight/saturation failures preserved')
    if J==21:
        term=mu[20]-logZ;g=eye[20]-eye[-1]
        same([mu[20],term,covariance[20,-1],se(g)],
             [saved['mean_logratio'],saved['AG_KL_term'],saved['covariance_mean_logratio_logZA'],saved['AG_KL_term_uncertainty']['MCSE']],'AG logratio minus logZ with covariance')
        same([g@covariance@g,g@between@g],[saved['AG_KL_term_uncertainty']['pooled_variance'],saved['AG_KL_term_uncertainty']['between_variance']],'AG functional variances')
        return term,se(g),failures
    need(J==20,'BG twenty moment features');return logZ,se(eye[-1]),failures

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30))
    plan=read(PLAN);auth=read(AUTH);external=read(ROOT/'tmp/c08_replay_ROOT/external_end.json')
    launch=read(ROOT/'tmp/c08_replay_ROOT/launch_inputs.json');complete=read(OUT/'complete.json');execution=read(OUT/'replay_execution.json')
    plan_sha=sha(PLAN);original=plan['identity'];ident=canonical(dict(plan_sha256=plan_sha,authorization_sha256=sha(AUTH)))
    need(external['exit_code']==0 and external['workers_exited'] is True,'External child finished successfully')
    need(external['launch_inputs_sha256']==sha(ROOT/'tmp/c08_replay_ROOT/launch_inputs.json') and launch['authorization_sha256']==sha(AUTH),'External launch/auth binding')
    need(external['execution_log_sha256']==sha(ROOT/'tmp/c08_replay_ROOT/execution.log'),'External log SHA')
    need(external['launcher_source_sha256']==sha(ROOT/'tmp/c08_replay_ROOT/launch.py'),'External launcher SHA')
    need(launch['preflight_sha256']==sha(ROOT/'tmp/c08_replay_ROOT/approved_preflight.json') and launch['review_sha256']==sha(ROOT/'tmp/c08_replay_ROOT/code_review.json'),'ROOT review and preflight binding')
    need(auth['approved'] is True and auth['approved_by']=='ROOT' and auth['original_identity']==original and auth['plan_sha256']==plan_sha,'ROOT replay authorization')
    need(auth['evidence_index_sha256'] is None and auth['optional_KL_enabled'] is True,'Frozen missing-evidence and optional scope')
    need(execution['source_sha256']==auth['source_sha256'] and execution['authorization_sha256']==sha(AUTH) and execution['identity']==ident,'Execution source/auth identity')
    need(complete['identity']==ident and complete['plan_sha256']==plan_sha and complete['status']=='ALL160_MATCHED_HIGH_REPLAYS_ARCHIVED','Complete replay identity')
    # Explicit map avoids importing any campaign/runtime source for auditing.
    for k,h in auth['source_sha256'].items():
        if k in ['consumer.py','kl_statistics.py','run_replay_with_kl.py']:p=ROOT/'tmp/c08_optional_kl_consumer'/k
        elif k in ['contracts.py','endpoints.py','replay.py','run_replay.py']:p=ROOT/'tmp/c08_quantile_replay_design'/k
        elif k=='frozen_bracket_helper':p=ROOT/'tmp/c08_execution_design/quantile_brackets.py'
        elif k=='original_driver':p=ROOT/'scripts/run_calibration_campaign.py'
        else:p=ROOT/'src/inference'/('__init__.py' if k=='inference_package_init' else k+'.py')
        need(sha(p)==h,'Current replay/consumer source SHA')
    om=read(bound(plan['original_manifest']));snap=OUT/'provenance'/original
    need(read(snap/'manifest.json')==om,'Original runtime provenance manifest copied exactly')
    for k,h in om['source_sha256'].items():
        p=ROOT/'src/inference/native/likelihood.cpp' if k=='native_cpp' else ROOT/'src/pta'/(k[4:]+'.py') if k.startswith('pta.') else ROOT/'src/inference'/(k+'.py')
        need(sha(p)==h,'Original runtime source closure SHA')
        filename=k+'.py' if k!='native_cpp' else 'native_cpp.cpp'
        # Snapshot native C++ is named from source-key + suffix; current source
        # and manifest remain independently checked above.
        q=snap/filename
        if q.exists():need(sha(q)==h,'Runtime source snapshot SHA')
    ids=sorted(set(r['datum'] for r in plan['rows']));expected=[500*i+d for i in range(5) for d in ids]
    need(len(ids)==32 and [r['target'] for r in plan['rows']]==expected==complete['targets'],'All five models times same32 original IDs')
    need(len(list((OUT/'archives').glob('target_*.json')))==len(list((OUT/'state').glob('target_*.json')))==160,'All160 archives and states')
    need(len(list((OUT/'replicas').glob('*.json')))==640,'All640 replay receipts')
    need(not any((OUT/'raw').iterdir()),'All replay raw retired')
    replayledger,bytarget=ledger(OUT/'ledger',ident,640,41943040,'replay_high')
    need(replayledger==complete['ledger'] and bytarget=={t:4 for t in expected},'Replay total and four reservations per target')
    endpoints=quantiles=replicas=artifacts=0;failures=collections.Counter();modelcounts=collections.Counter();raws={};optional_rows={}
    for row in plan['rows']:
        t=row['target'];modelcounts[row['scientific_model']]+=1
        archive=read(OUT/'archives'/f'target_{t:06d}.json');state=read(OUT/'state'/f'target_{t:06d}.json')
        need(archive['target']==t and archive['plan_sha256']==plan_sha and archive['status']=='REPLAY_COMPACT_PRESERVED','Archive identity/status')
        need(archive['original_files']==row['original_files'] and archive['original_receipt']==row['original_receipt'],'Original archive provenance preserved')
        for record in list(row['original_files'].values())+[row['original_receipt'],row['cut_manifest']]:bound(record)
        need(state['target']==t and state['plan_sha256']==plan_sha and state['status']=='C08_REPLAY_TARGET_ARCHIVED' and state['archive_sha256']==sha(OUT/'archives'/f'target_{t:06d}.json'),'Retirement state archive SHA')
        need(archive['all_failures_retained'] and archive['no_SBC_or_physical_approval'],'Archive limitations retained')
        rawmap={c['raw_file']:c['raw_sha256'] for c in row['high_checkpoints']}
        need(archive['raw_sha256']==rawmap and not set(raws).intersection(rawmap),'Original raw mapping unique and preserved');raws.update(rawmap)
        for cp in row['high_checkpoints']:
            rep=read(OUT/'replicas'/f'target_{t:06d}_rep{cp["replicate"]}.json')
            need(rep['identity']==original and rep['plan_sha256']==plan_sha and rep['target']==t and rep['samples']==65536 and rep['status']=='BIT_EXACT_HIGH_REPLAY','Original replay receipt identity')
            need(rep['raw_sha256']==rep['original_raw_sha256']==cp['raw_sha256'] and rep['raw_file']=='raw/'+cp['raw_file'],'Original raw SHA matched')
            need(rep['original_rng_state_before']==cp['rng_state_before'] and rep['original_rng_state_after']==cp['rng_state_after'],'Original RNG before and after preserved')
            need(rep['uses_truth'] is False and rep['new_seed'] is False and rep['numerical_accuracy_approval'] is False,'No new seed/truth/accuracy claim')
            need(rep['proposal_sha256']==row['original_files']['proposal']['sha256'],'Replica proposal SHA');replicas+=1
        optional=t in [1500+d for d in IDS_KL]+[2000+d for d in IDS_KL]
        need(len(archive['artifacts'])==3+optional,'All required compact/consumer artifacts')
        for r in archive['artifacts']:bound(r);artifacts+=1
        d=read(OUT/'diagnostics'/f'target_{t:06d}.json');cut=read(bound(row['cut_manifest']))
        need(d['target']==t and d['identity']==original and d['raw_sha256']==rawmap and d['cut_manifest_content_sha256']==cut['content_sha256'],'Diagnostic identity/raw/LOW binding')
        need(d['cut_manifest_sha256']==row['cut_manifest']['sha256'] and d['evidence'] is None and d['all20_retained'] and d['truth_read'] is False and d['physical_LL_evaluations']==0,'Missing evidence and all20 retained without new LL')
        need(len(d['rows'])==20 and d['samples_per_replication']==65536 and d['replications']==4,'High diagnostic dimensions')
        npz=OUT/'diagnostics'/d['numeric_file'];need(sha(npz)==d['numeric_sha256'] and npz.stat().st_size==d['numeric_bytes'],'Diagnostic NPZ SHA/size')
        with np.load(npz,allow_pickle=False) as z:
            need(z['cdf'].shape==(20,23) and z['replication_estimates'].shape==(20,23,4) and z['replication_consistent'].shape==(20,23,6),'Preserved compact statistics shapes')
            need(np.array_equal(z['quantile_bounds'],np.tile([0.,1.],(20,1))) and not z['quantile_resolved'].any(),'All20 original brackets remain0to1 unresolved')
            for i,r in enumerate(d['rows']):
                coordinate,pi=divmod(i,4);n=len(r['cuts']);quantiles+=1;endpoints+=n
                need(r['parameter']==coordinate and r['probability_index']==pi and r['cuts']==cut['cuts'][coordinate][pi],'Own LOW cut order unchanged')
                need(r['lower_quantile']==0 and r['upper_quantile']==1 and r['width']==1 and r['status'].startswith('UNRESOLVED'),'Original quantile unresolved')
                need('deterministic_evidence_missing' in r['common_failures'] and r['deterministic_status']=='unresolved','Missing finite evidence preserved')
                failures.update(r['common_failures'])
                need(r['family_tests']==(6624 if coordinate==0 and pi==3 else 125856) and r['alpha']==.025,'Original bracket family unchanged')
                need(len(r['endpoint_statistics'])==n<=23 and z['endpoint_present'][i,:n].all() and not z['endpoint_present'][i,n:].any(),'Every endpoint preserved with padding')
                need(np.array_equal(z['cuts'][i,:n],np.array(r['cuts'])),'Compact cuts equal JSON')
                for j,e in enumerate(r['endpoint_statistics']):
                    need(e['threshold']==r['cuts'][j] and z['structural'][i,j]==e['structural'] and z['usable'][i,j]==e['endpoint_usable'],'Endpoint statuses preserved')
                    for key,field in [('estimate','cdf'),('mcse','mcse')]:
                        if e[key] is None:need(not np.isfinite(z[field][i,j]),'Unresolved numeric sentinel preserved')
                        else:need(z[field][i,j]==e[key],'Endpoint numerical value preserved exactly')
                    if not e['structural']:
                        need(len(e['replication_estimates'])==4 and len(e['replication_contrasts'])==6,'Replica statistics retained')
                        same(z['replication_estimates'][i,j],e['replication_estimates'],'Replica estimates compact equality',atol=0)
                        need(z['replication_consistent'][i,j].tolist()==[a['consistent'] for a in e['replication_contrasts']],'Replica flags compact equality')
        if optional:optional_rows[t]=row
    need(quantiles==3200 and endpoints==plan['counts']['actual_cut_endpoints']==68697 and replicas==len(raws)==640,'Final quantile endpoint replica counts')
    need(modelcounts=={m:32 for m in MODEL},'Every model retains32 data')
    intentpath=ROOT/'tmp/c08_optional_kl_consumer/intent.json';intent=read(intentpath);intent_sha=sha(intentpath)
    need(intent_sha==auth['optional_KL_intent_sha256']==complete['optional_KL']['intent_sha256'],'Optional intent authorized and completed')
    klroot=OUT/'optional_kl';crossledger,crossby=ledger(klroot/'cross_ledger',intent_sha,16,1048576,'optional_B_G_on_A_G')
    need(crossledger==complete['optional_KL']['cross_ledger'] and crossby=={2000+d:4 for d in IDS_KL},'Cross ledger B_G targets')
    need(len(list((klroot/'receipts').glob('*.json')))==8 and len(list((klroot/'cross').glob('*.json')))==16 and len(list((klroot/'cross').glob('*.npz')))==16 and len(list((klroot/'pairs').glob('*.json')))==4,'All optional products present')
    bounds=np.asarray(read(ROOT/'configs/calibration/prior_predictive_500_v1.json')['prior']['bounds']);terms={};pairs=[];optional_artifacts=0
    for target,row in optional_rows.items():
        rec=read(klroot/'receipts'/f'target_{target:06d}.json');saved=read(klroot/'statistics'/f'target_{target:06d}.json')
        rawmap={c['raw_file']:c['raw_sha256'] for c in row['high_checkpoints']}
        need(rec['target']==target and rec['status']=='CONSUMPTION_COMPLETE' and rec['raw_sha256']==rawmap and rec['intent_sha256']==intent_sha,'Optional consumer receipt identity')
        need(len(rec['artifacts'])==(9 if target<2000 else 2),'Optional9or2 artifacts')
        for r in rec['artifacts']:bound(r);optional_artifacts+=1
        need(saved['target']==target and saved['runtime_identity']==original and saved['raw_sha256']==rawmap and saved['intent_sha256']==intent_sha and saved['original_checkpoints']==row['high_checkpoints'],'Optional moment provenance')
        need(saved['no_unseen_tail_certificate'] and saved['is_uniform_proof'] is False and rec['all_failures_retained'],'Optional limitations/failures retained')
        need(rec['numerical_status']==(saved['failures'] or ['FINITE_ESTIMATE_NO_TAIL_CERTIFICATE']),'Receipt does not discard numerical failures')
        terms[target]=recompose(saved,bounds)
        if target<2000:
            for cp in row['high_checkpoints']:
                cache=read(klroot/'cross'/f'target_{target:06d}_rep{cp["replicate"]}.json');bound(cache['artifact'])
                need(cache['source_target']==target and cache['evaluation_target']==target+500 and cache['samples']==65536 and cache['replicate']==cp['replicate'] and cache['source_raw_sha256']==cp['raw_sha256'] and cache['runtime_identity']==original and cache['intent_sha256']==intent_sha and cache['status']=='CROSS_VALUES_COMPLETE','Cross provenance and original raw binding')
    for datum in IDS_KL:
        k=read(klroot/'pairs'/f'datum_{datum:03d}.json');a,sa,fa=terms[1500+datum];b,sb,fb=terms[2000+datum]
        same([a+b,math.hypot(sa,sb)],[k['KL_A_G_to_B_G'],k['MCSE']],'Independent KL and MCSE recomposition')
        need(k['failures']==sorted(set(fa+fb)) and k['clipped'] is False and k['no_population_ordering_claim'] and k['no_uniform_certificate'],'KL failures/no-clipping/limitations')
        bound(k['AG_statistics']);bound(k['BG_statistics']);pairs.append(dict(datum=datum,KL_A_G_to_B_G=k['KL_A_G_to_B_G'],MCSE=k['MCSE'],failures=k['failures'],status=k['status']))
    # Final reread detects a changed closed product during the audit itself.
    for name,expected_sha in list(HASHED.items()):need(sha(name)==expected_sha,'Final closed-file inventory unchanged')
    need(not any((OUT/'raw').iterdir()),'Raw remains empty at audit end')
    r=resource.getrusage(resource.RUSAGE_SELF);need(r.ru_maxrss<=256*1024**2,'Audit RSS bound')
    result=dict(schema='C08_REPLAY_RESULT_INDEPENDENT_AUDIT_v1',status='ALL160_REPLAY_PRODUCTS_REVIEWED',
      execution_complete_sha256=sha(OUT/'complete.json'),authorization_sha256=sha(AUTH),external_end_sha256=sha(ROOT/'tmp/c08_replay_ROOT/external_end.json'),
      plan_sha256=plan_sha,identity=ident,original_runtime_identity=original,cohort_ids=ids,by_model=dict(modelcounts),
      counts=dict(archives=160,quantiles=quantiles,endpoint_statistics=endpoints,replicas=replicas,original_raw_SHA=640,archive_artifacts_verified=artifacts,
        optional_receipts=8,optional_artifacts_verified=optional_artifacts,cross_arrays_SHA_verified_only=16,KL_pairs=4),
      ledger=replayledger,cross_ledger=crossledger,combined_LL=42991616,raw_empty=True,
      original_all3200_brackets=[0.,1.],missing_evidence_quantiles=3200,common_failure_counts=dict(failures),
      endpoint_statistics_retained=True,optional_pairs=pairs,all_failures_preserved=True,
      execution_resources=dict(child_CPU_seconds_including_exit=external['child_CPU_seconds_including_exit'],wall_seconds=external['wall_seconds'],
        child_RSS_peak_bytes=external['child_RSS_peak_bytes'],launcher_RSS_peak_bytes=external['launcher_RSS_peak_bytes'],launcher_CPU_seconds=external['launcher_CPU_seconds']),
      audit_resources=dict(CPU_since_process_start=r.ru_utime+r.ru_stime,RSS_peak_bytes=r.ru_maxrss,CPU_cap=30,RSS_cap=256*1024**2),
      verified_file_count=len(HASHED),checks=dict(CHECKS),source_sha256=sha(__file__),
      scope=dict(new_LL=0,new_ORF=0,new_bank=0,new_draws=0,raw_arrays_deserialized=0,cross_arrays_deserialized=0,compact_diagnostic_NPZs_read=160),
      limitations=['Retired raw cannot be rehashed: matched SHA/RNG proof is the source-bound original/replay receipts plus successful authorized lifecycle.',
        'Compact recomposition independently validates KL/moment algebra, not response accuracy or unseen-tail behavior.',
        'Missing finite deterministic evidence preserves original3200 UNRESOLVED brackets; no uniform/CDF/SBC approval inferred.'])
    return result

if __name__=='__main__':
    with (OUT/'.campaign.lock').open('rb') as f:
        fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        result=main()
    with (HERE/'result.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
    with (HERE/'verified_file_sha256.json').open('x') as f:json.dump(HASHED,f,indent=2);f.write('\n')
    print(json.dumps({k:result[k] for k in ['status','counts','combined_LL','optional_pairs','audit_resources','verified_file_count']},indent=2))
