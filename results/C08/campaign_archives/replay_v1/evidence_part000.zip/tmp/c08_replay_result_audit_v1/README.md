# Auditoria do replay C08 concluído

`result.json` declara `ALL160_REPLAY_PRODUCTS_REVIEWED`. A auditoria leu
somente metadados, arquivos para SHA e os pequenos NPZ de estatísticas de
endpoint. Não importou runtime/inferência, construiu banco, avaliou LL/ORF,
recriou draws ou deserializou os caches cross/raw HIGH.

Foram conferidos4.164 arquivos:160 archives/states,3.200 quantis,68.697
estatísticas de endpoint,640 recibos com SHA original e RNG antes/depois,
fontes autorizadas e closure C07,488 artifacts de archive e44 artifacts dos
oito consumidores opcionais. Os16 caches cross tiveram SHA verificado como
bytes. Os quatro pares KL e suas MCSE foram recompostos por álgebra
independente a partir dos suficientes compactos, incluindo covariância de
log-ratio/logZA e momentos físicos. Os quatro pares preservam failures[].

Ledger replay41.943.040, cross1.048.576, soma42.991.616; nenhuma reserva aberta
e diretório raw vazio. Todos os3.200 brackets originais seguem[0,1] por falta
de evidência finita determinística. Quarenta linhas também preservam falha
LOW de peso. As estimativas, MCSE, réplicas e flags de endpoint permanecem
nos compactos e correspondem ao JSON/cortes LOW.

Isso confirma transporte, proveniência e álgebra compacta; não revalida os
raws já aposentados, precisão da resposta, caudas, SBC ou uma margem uniforme.
A prova de reprodução raw é a cadeia de recibos/source/SHAs/RNG da execução
autorizada bem-sucedida, e não uma nova geração de draws.

A primeira tentativa atingiu o cap30CPU devido à descompressão redundante
do mesmo pequeno membro NPZ para cada endpoint. Fonte e falha estão em
`history_first_CPU_limit/`; não houve produto científico alterado. A única
correção foi carregar cada compacto uma vez por alvo. A tentativa final
passou em11.21088CPU, RSS48.709.632bytes. O custo exato final da primeira
tentativa terminada por sinal não foi medido; não foi apagado ou contado zero.

Os recursos da execução auditada vêm do receipt externo ROOT:561.850045CPU
do child incluindo saída,366.328987s de parede, RSS child3.673.718.784bytes
e launcher20.791.296bytes. Estes valores não são o custo desta auditoria.
