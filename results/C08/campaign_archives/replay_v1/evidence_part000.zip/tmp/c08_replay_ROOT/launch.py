"""One external lifecycle; no automatic retry or alternate numerical backend."""
from pathlib import Path
import hashlib,json,os,resource,subprocess,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    inputs=read(HERE/'launch_inputs.json');package=ROOT/'tmp/c08_optional_kl_consumer'
    assert sha(HERE/'prepare.py')==inputs['preparation_source_sha256']
    assert sha(HERE/'authorization.json')==inputs['authorization_sha256']
    assert sha(HERE/'code_review.json')==inputs['review_sha256']
    assert sha(package/'manifest.json')==inputs['package_manifest_sha256']
    for name,digest in read(package/'manifest.json')['files'].items():assert sha(package/name)==digest
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
    start=dict(schema='ROOT_C08_REPLAY_EXTERNAL_LIFECYCLE_v1',argv=inputs['argv'],
        launch_inputs_sha256=sha(HERE/'launch_inputs.json'),launcher_source_sha256=sha(__file__),
        package_manifest_sha256=inputs['package_manifest_sha256'],
        thread_env={k:env[k] for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS')},
        one_bank_shared_lock=str(ROOT/'tmp/c08_posterior_campaign'),
        required_replay_LL=41943040,optional_cross_LL=1048576,automatic_retry=False)
    write(HERE/'external_start.json',start)
    before=resource.getrusage(resource.RUSAGE_CHILDREN);clock=time.monotonic()
    with (HERE/'execution.log').open('x') as f:
        p=subprocess.Popen(inputs['argv'],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
        print(json.dumps(dict(event='REPLAY_CHILD_STARTED',pid=p.pid)),flush=True)
        code=p.wait()
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    start.update(exit_code=code,wall_seconds=time.monotonic()-clock,
        child_CPU_seconds_including_exit=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,
        child_RSS_peak_bytes=after.ru_maxrss,launcher_CPU_seconds=time.process_time(),
        launcher_RSS_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        execution_log_sha256=sha(HERE/'execution.log'),workers_exited=True)
    write(HERE/'external_end.json',start)
    print(json.dumps({k:v for k,v in start.items() if k not in ('argv','thread_env')}),flush=True)
    return code
if __name__=='__main__':raise SystemExit(main())
