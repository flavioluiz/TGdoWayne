"""ROOT metadata-only preparation for the separately reviewed C07 HIGH replay."""
from pathlib import Path
import hashlib,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts'),str(ROOT/'tmp/c08_quantile_replay_design'),str(ROOT/'tmp/c08_optional_kl_consumer')]
from inference.campaign_io import read_json,sha256,canonical_hash,write_json_new
from contracts import protocol,bound_file
from replay import validate_execution
from consumer import validate_intent
import run_replay_with_kl as runner

def main():
    out=ROOT/'tmp/c08_required_high_replay_with_kl_v1'
    planpath=ROOT/'tmp/c08_quantile_replay_design/frozen_c07/replay_plan.json'
    plan=read_json(planpath);package=ROOT/'tmp/c08_optional_kl_consumer'
    helper=ROOT/'tmp/c08_execution_design/quantile_brackets.py'
    g0path=ROOT/'tmp/c08_G0/c07_publication_resource_release.json'
    allocationpath=ROOT/'tmp/c08_G0/combined_LL_allocation_v1.json'
    g0=read_json(g0path);allocation=read_json(allocationpath)
    assert sha256(planpath)=='ebf97eeca6cb6c3b2a97e931f08027fdd267f187d15227fb1b43c27843431ef8'
    assert sha256(allocationpath)=='9c2da9861f791091608b8179b534803218abf9ccf9635da5c0680bb03da81b52'
    for variant in ('C_beta','C_full'):
        end=read_json(ROOT/f'tmp/c08_main_ROOT/{variant}_external_end.json')
        assert end['exit_code']==0 and end['workers_exited'] is True
        assert (ROOT/f'tmp/c08_main_ROOT/{variant}_result_review.json').is_file()
    # This file is produced only after ROOT's source reading and the separate
    # reviewer conclude. It binds the final package and independent review.
    reviewpath=HERE/'code_review.json';review=read_json(reviewpath)
    assert review['approved_for_execution'] is True
    assert review['package_manifest_sha256']==sha256(package/'manifest.json')
    for name,digest in read_json(package/'manifest.json')['files'].items():bound_file(package/name,digest)
    for item in review['review_files']:bound_file(item['path'],item['sha256'])
    inputs=dict(experiment='configs/calibration/prior_predictive_500_v1.json',
        data='results/C07/prior_predictive/data.npz',
        table='results/C07/orf_interpolation/orf_table_pilot12x4.npz',
        table_manifest='results/C07/orf_interpolation/orf_table_manifest.json',
        validation_config='configs/calibration/pilot_initial.json',
        settings='configs/calibration/campaign_500_execution_v1.json',
        native_library='tmp/native/c586a0637ce30e440b8a5235/libpta_likelihood.dylib',
        native_build_manifest='tmp/native/c586a0637ce30e440b8a5235/build_manifest.json')
    inputs={k:str(bound_file(ROOT/p,plan['original_input_sha256'][k])) for k,p in inputs.items()}
    sources=runner.runner_sources(ROOT,helper)
    assert sources['inference_package_init']==sha256(ROOT/'src/inference/__init__.py')
    auth=dict(schema='C08_HIGH_REPLAY_AUTHORIZATION_v1',approved=True,approved_by='ROOT',
        stages=['required_C07_high_replay','endpoint_diagnostics'],plan_sha256=sha256(planpath),
        output=str(out),source_sha256=sources,maximum_LL=41943040,original_identity=plan['identity'],
        G0_content_sha256=canonical_hash(g0),allocation_content_sha256=canonical_hash(allocation),
        resource_lock_root=allocation['resource_lock_root'],evidence_index_sha256=None,consumers_index_sha256=None,
        diagnostic_protocol_content_sha256=canonical_hash(protocol()),
        optional_KL_enabled=True,optional_KL_intent_sha256=sha256(package/'intent.json'),
        optional_KL_output=str(out/'optional_kl'),ROOT_code_review_sha256=sha256(reviewpath),
        deterministic_evidence_policy='Absent at execution: preserve original UNRESOLVED and endpoint statistics; supplemental assessment only after independent finite controls.',
        automatic_retry_authorized=False)
    validate_execution(plan,auth,g0,allocation,plan_path=planpath,output=out,repository=ROOT,source_hashes=sources)
    validate_intent(package/'intent.json',auth,allocation,plan,planpath,out)
    pre=runner.prepare_preflight(planpath,out,repository=ROOT,helper=helper)
    write_json_new(HERE/'runtime_inputs.json',inputs);write_json_new(HERE/'authorization.json',auth)
    write_json_new(HERE/'approved_preflight.json',pre)
    args=[str(ROOT/'.venv/bin/python'),str(package/'run_replay_with_kl.py'),'--repository',str(ROOT),'--helper',str(helper),'run','--execute',
        '--plan',str(planpath),'--output',str(out),'--authorization',str(HERE/'authorization.json'),
        '--g0',str(g0path),'--allocation',str(allocationpath),'--runtime-inputs',str(HERE/'runtime_inputs.json'),
        '--kl-intent',str(package/'intent.json')]
    write_json_new(HERE/'launch_inputs.json',dict(argv=args,output=str(out),
        package_manifest_sha256=sha256(package/'manifest.json'),authorization_sha256=sha256(HERE/'authorization.json'),
        preparation_source_sha256=sha256(__file__),review_sha256=sha256(reviewpath),
        preflight_sha256=sha256(HERE/'approved_preflight.json'),metadata_only=True,new_LL=0,bank_built=False))
    print(json.dumps(dict(status='METADATA_PREPARED_NO_BANK',maximum_replay_LL=41943040,optional_cross_LL=1048576,
        launch_inputs_sha256=sha256(HERE/'launch_inputs.json'))))
if __name__=='__main__':main()
