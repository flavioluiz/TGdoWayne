import json,tempfile,unittest
from pathlib import Path
import numpy as np
from kl_statistics import summarize_replica,combine,finish_kl
import consumer

class Toy(unittest.TestCase):
    def fixture(self):
        x=np.linspace(.03,.97,4*64*5).reshape(4,64,5)
        lw=1.5*x[:,:,0];f=2.1*x[:,:,1]-.3*x[:,:,2]
        summaries=[summarize_replica(x[r],lw[r],f[r]) for r in range(4)]
        return x,lw,f,summaries

    def test_logratio_logZ_covariance_matches_direct_IF(self):
        x,lw,f,s=self.fixture();a=combine(s,np.array([[0.,1.]]*5))
        w=np.exp(lw.ravel()-lw.max());p=w/w.sum();n=len(p);F=float(p@f.ravel())
        ifmean=n*p*(f.ravel()-F);ifz=n*p-1
        expected=np.var(ifmean-ifz,ddof=1)/n
        self.assertAlmostEqual(a['AG_KL_term_uncertainty']['pooled_variance'],expected,places=13)
        covariance=np.cov(ifmean,ifz,ddof=1)[0,1]/n
        self.assertAlmostEqual(a['covariance_mean_logratio_logZA'],covariance,places=13)
        independent=(np.var(ifmean,ddof=1)+np.var(ifz,ddof=1))/n
        self.assertGreater(abs(independent-expected),1e-5)

    def test_moments_and_physical_covariance(self):
        x,lw,f,s=self.fixture();bounds=np.array([[2.,5.]]*5);a=combine(s,bounds)
        p=np.exp(lw.ravel()-lw.max());p/=p.sum();xx=x.reshape(-1,5);m=p@xx
        np.testing.assert_allclose([r['unit'] for r in a['means']],m,atol=2e-15)
        self.assertAlmostEqual(a['covariances'][0]['physical'],9*(p@(xx[:,0]**2)-m[0]**2),places=13)

    def test_negative_noisy_KL_not_clipped_and_BG_has_no_logratio(self):
        x,lw,f,s=self.fixture();a=combine(s,np.array([[0.,1.]]*5))
        b=combine([summarize_replica(x[r],lw[r]-8) for r in range(4)],np.array([[0.,1.]]*5))
        k=finish_kl(a,b);self.assertLess(k['KL_A_G_to_B_G'],0);self.assertFalse(k['clipped'])
        self.assertAlmostEqual(k['MCSE'],np.hypot(a['AG_KL_term_uncertainty']['MCSE'],b['logZ_MCSE']))

    def test_overweight_and_nonfinite_are_not_removed(self):
        x,lw,f,s=self.fixture();lw[0,0]=50
        a=combine([summarize_replica(x[r],lw[r],f[r]) for r in range(4)],np.array([[0.,1.]]*5))
        self.assertIn('original_single_deletion_weight_guard',a['failures'])
        f[0,0]=np.nan
        with self.assertRaises(ValueError):summarize_replica(x[0],lw[0],f[0])

    def test_frozen_intent_not_future_output_receipt_and_allocation_guard(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);plan={'identity':'TOY','rows':[]}
            for target in consumer.TARGETS:
                plan['rows'].append(dict(target=target,high_checkpoints=[dict(raw_file=f'{target}_{r}.npz',raw_sha256=f'{r:064x}') for r in range(4)]))
            planpath=p/'plan.json';planpath.write_text(json.dumps(plan))
            intent=dict(schema='C08_OPTIONAL_KL_INTENT_v1',execution_enabled=False,datum_ids=consumer.IDS,targets=consumer.TARGETS,
              cross_LL_cap=consumer.CROSS_CAP,N=consumer.N,replicas=4,source_sha256=consumer.source_hashes(),
              plan_sha256=consumer.sha(planpath),original_identity='TOY',expected_raw_sha256={str(r['target']):{c['raw_file']:c['raw_sha256'] for c in r['high_checkpoints']} for r in plan['rows']})
            ip=p/'intent.json';ip.write_text(json.dumps(intent))
            auth=dict(optional_KL_enabled=True,optional_KL_intent_sha256=consumer.sha(ip),optional_KL_output=str((p/'optional_kl').resolve()),resource_lock_root=str(p/'lock'))
            alloc=dict(allocations={'optional_KL_cross':consumer.CROSS_CAP},resource_lock_root=auth['resource_lock_root'])
            self.assertEqual(consumer.validate_intent(ip,auth,alloc,plan,planpath,p),intent)
            alloc['allocations']['optional_KL_cross']=0
            with self.assertRaises(RuntimeError):consumer.validate_intent(ip,auth,alloc,plan,planpath,p)

    def test_two_stage_consumption_after_AG_raw_retirement_has_zero_BG_LL(self):
        # Strictly TOY namespace and analytic callback; no CampaignRuntime or
        # PTA imports. Smaller N exercises the identical lifecycle arithmetic.
        oldN,oldcap=consumer.N,consumer.CROSS_CAP;consumer.N=8;consumer.CROSS_CAP=128
        try:
            with tempfile.TemporaryDirectory() as tmp:
                p=Path(tmp);(p/'raw').mkdir()
                class Runtime:
                    identity='TOY';bounds=np.array([[0.,1.]]*5);likelihood_evaluations=0
                    def likelihood(self,theta,targets):
                        self.likelihood_evaluations+=len(theta)
                        return -.5*(theta*theta).sum(axis=1)
                    def verify_unchanged(self):pass
                runtime=Runtime()
                class Ledger:
                    def totals(self):return dict(total=runtime.likelihood_evaluations)
                    def call(self,rt,kind,reserved,stage,targets,fn):
                        before=rt.likelihood_evaluations;value=fn()
                        assert rt.likelihood_evaluations-before==reserved
                        return value
                rows=[]
                for target,model in [(1525,'A_G'),(2025,'B_G')]:
                    row=dict(target=target,datum=25,scientific_model=model,original_files={'proposal':{'path':'TOY','sha256':'0'*64}},high_checkpoints=[])
                    for r in range(4):
                        name=f'toy_{target}_{r}.npz';path=p/'raw'/name
                        x=np.linspace(.1,.9,8*5).reshape(8,5)
                        np.savez(path,x_unit=x,log_weights=np.zeros(8),log_likelihood=np.zeros(8),target=np.array(target),replicate=np.array(r))
                        row['high_checkpoints'].append(dict(raw_file=name,raw_sha256=consumer.sha(path),replicate=r,samples=8))
                    rows.append(row)
                obj=consumer.InlineConsumer.__new__(consumer.InlineConsumer)
                obj.root=p/'optional_kl';obj.replay_output=p;obj.runtime=runtime;obj.ledger=Ledger();obj.plan={'rows':rows}
                obj.intent={'source_sha256':consumer.source_hashes()};obj.intent_path=p/'intent.json';obj.intent_path.write_text(json.dumps(obj.intent));obj.intent_sha=consumer.sha(obj.intent_path)
                ag=obj.consume(rows[0]);self.assertEqual(runtime.likelihood_evaluations,32)
                self.assertEqual(obj.consume(rows[0]),ag);self.assertEqual(runtime.likelihood_evaluations,32)
                for cp in rows[0]['high_checkpoints']:(p/'raw'/cp['raw_file']).unlink()
                bg=obj.consume(rows[1]);self.assertEqual(runtime.likelihood_evaluations,32)
                receipt=consumer.read(bg[0]['path']);self.assertEqual(receipt['status'],'CONSUMPTION_COMPLETE')
                self.assertTrue((obj.root/'pairs/datum_025.json').exists())
                cache=obj.root/'cross/target_001525_rep0.npz';cache.write_bytes(b'TOY_CORRUPTION')
                with self.assertRaises(RuntimeError):obj.existing(rows[0])
        finally:consumer.N=oldN;consumer.CROSS_CAP=oldcap

if __name__=='__main__':unittest.main()
