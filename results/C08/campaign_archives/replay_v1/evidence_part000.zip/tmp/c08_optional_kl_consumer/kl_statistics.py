"""Finite IID SNIS moments and KL sufficient statistics. No physics or I/O.

AG contributes E_A[ell_A-ell_B]-logZ_A with its full covariance. BG contributes
logZ_B from a separate target RNG stream. Negative noisy KL is never clipped.
"""
import numpy as np

PAIRS=[(i,j) for i in range(5) for j in range(i,5)]


def summarize_replica(unit,logw,logratio=None):
    x=np.asarray(unit,float);lw=np.asarray(logw,float)
    if x.ndim!=2 or x.shape[1]!=5 or lw.shape!=(len(x),) or len(x)<2 or len(x)>65536:
        raise ValueError('One bounded IID replica required')
    if not np.isfinite(x).all() or not np.isfinite(lw).all() or np.any((x<0)|(x>1)):
        raise ValueError('Finite unclipped unit points/weights required')
    h=np.column_stack([x]+[x[:,i]*x[:,j] for i,j in PAIRS])
    if logratio is not None:
        f=np.asarray(logratio,float)
        if f.shape!=lw.shape or not np.isfinite(f).all():raise ValueError('Finite pointwise logratio')
        h=np.column_stack([h,f])
    shift=float(lw.max());w=np.exp(lw-shift);w2=w*w
    S=float(w.sum());p=w/S;H=h*w[:,None]
    saturated=np.any((x==0)|(x==1),axis=1)
    return dict(N=len(x),shift=shift,S=S,S2=float(w2.sum()),V=(w@h).tolist(),
      T=(w2@h).tolist(),U=(H.T@H).tolist(),maximum_weight=float(p.max()),
      maximum_raw_scaled_weight=float(w.max()),saturated_weight=float(p[saturated].sum()),
      has_logratio=logratio is not None,feature_count=h.shape[1])


def combine(replicas,bounds):
    if len(replicas)!=4 or len({r['N'] for r in replicas})!=1 or len({r['feature_count'] for r in replicas})!=1:
        raise ValueError('Four equal-sized independent replicas')
    bounds=np.asarray(bounds,float)
    if bounds.shape!=(5,2) or not np.isfinite(bounds).all() or np.any(bounds[:,1]<=bounds[:,0]):raise ValueError('Physical bounds')
    N=sum(r['N'] for r in replicas);a=max(r['shift'] for r in replicas)
    scale=np.exp([r['shift']-a for r in replicas]);S=sum(s*r['S'] for s,r in zip(scale,replicas))
    S2=sum(s*s*r['S2'] for s,r in zip(scale,replicas));V=sum(s*np.array(r['V']) for s,r in zip(scale,replicas))
    T=sum(s*s*np.array(r['T']) for s,r in zip(scale,replicas));U=sum(s*s*np.array(r['U']) for s,r in zip(scale,replicas))
    mu=V/S;factor=N/(S*S*(N-1));cov_mean=factor*(U-np.outer(mu,T)-np.outer(T,mu)+S2*np.outer(mu,mu))
    cov_logz=factor*(T-mu*S2);var_logz=(N*S2/(S*S)-1)/(N-1)
    # Last component is logZ. This matrix is the covariance of ESTIMATORS,
    # not posterior covariance, and explicitly preserves its cross terms.
    cov=np.empty((len(mu)+1,len(mu)+1));cov[:-1,:-1]=cov_mean;cov[:-1,-1]=cov_logz;cov[-1,:-1]=cov_logz;cov[-1,-1]=var_logz
    ratios=np.array([4*s*r['S']/S for s,r in zip(scale,replicas)])
    rep_mu=np.array([np.array(r['V'])/r['S'] for r in replicas])
    block=np.column_stack([ratios[:,None]*(rep_mu-mu),ratios-1])
    between=np.cov(block,rowvar=False,ddof=1)/4
    def se(gradient):
        g=np.asarray(gradient,float);v=float(g@cov@g);b=float(g@between@g)
        # Roundoff can make a theoretically PSD sufficient-stat covariance
        # slightly negative. Bound only numerical variance at zero, no values.
        tolerance=1e-10*max(1.,float(np.max(np.abs(cov))))*float(g@g)
        if min(v,b)<-tolerance:raise ArithmeticError('Negative variance beyond rounding')
        return dict(MCSE=float(np.sqrt(max(0.,v,b))),pooled_variance=v,between_variance=b)
    eye=np.eye(len(mu)+1);means=[];covariance=[];width=bounds[:,1]-bounds[:,0]
    for i in range(5):
        stat=se(eye[i]);means.append(dict(parameter=i,unit=float(mu[i]),physical=float(bounds[i,0]+width[i]*mu[i]),
          unit_MCSE=stat['MCSE'],physical_MCSE=width[i]*stat['MCSE']))
    for k,(i,j) in enumerate(PAIRS):
        value=float(mu[5+k]-mu[i]*mu[j]);g=eye[5+k]-mu[j]*eye[i]-mu[i]*eye[j];stat=se(g)
        covariance.append(dict(i=i,j=j,unit=value,physical=value*width[i]*width[j],unit_MCSE=stat['MCSE'],physical_MCSE=stat['MCSE']*width[i]*width[j]))
    logz=a+np.log(S/N);failure=[]
    for r in replicas:
        p=r['maximum_weight']
        if p>=1 or p/(1-p)>.00335:failure.append('original_single_deletion_weight_guard')
        if r['saturated_weight']>1e-12:failure.append('original_saturation_guard')
    result=dict(N=N,replicas=4,logZ=float(logz),logZ_MCSE=se(eye[-1])['MCSE'],
      mean_features=mu.tolist(),estimator_covariance_pooled=cov.tolist(),estimator_covariance_between=between.tolist(),
      means=means,covariances=covariance,failures=sorted(set(failure)),
      maximum_replica_normalized_weight=max(r['maximum_weight'] for r in replicas),
      maximum_pooled_normalized_weight=max(s*r['maximum_raw_scaled_weight']/S for s,r in zip(scale,replicas)),
      no_unseen_tail_certificate=True,is_uniform_proof=False)
    if replicas[0]['has_logratio']:
        g=eye[20]-eye[-1];stat=se(g)
        result.update(mean_logratio=float(mu[20]),AG_KL_term=float(mu[20]-logz),AG_KL_term_uncertainty=stat,
          covariance_mean_logratio_logZA=float(cov[20,-1]),AG_combination='E_A[ell_A-ell_B]-logZ_A; covariance retained')
    return result


def finish_kl(ag,bg):
    if 'AG_KL_term' not in ag or 'AG_KL_term' in bg:raise ValueError('Ordered AG and BG summaries')
    a=ag['AG_KL_term_uncertainty'];b=bg['logZ_MCSE']
    value=ag['AG_KL_term']+bg['logZ'];mcse=float(np.hypot(a['MCSE'],b))
    failures=sorted(set(ag['failures']+bg['failures']))
    return dict(KL_A_G_to_B_G=float(value),MCSE=mcse,clipped=False,failures=failures,
      status='FINITE_KL_ESTIMATE_GUARDS_PASS' if not failures else 'UNRESOLVED_WEIGHT_OR_SATURATION',
      independence_scope='Distinct frozen A_G/B_G target RNG streams conditional on the same data; AG logratio/logZA covariance retained',
      no_population_ordering_claim=True,no_uniform_certificate=True,
      formula='E_A[ell_A-ell_B]+logZ_B-logZ_A')
