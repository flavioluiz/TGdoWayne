"""Inline, separately authorized AG/BG consumer for an already resident bank.

No bank construction or replay entry point lives here. Cross calls have a
separate durable ledger. Future output receipt hashes are bound after consume,
while the immutable INTENT/source/scope is bound before execution.
"""
from pathlib import Path
import hashlib,json
import numpy as np
from kl_statistics import summarize_replica,combine,finish_kl

IDS=[25,26,44,48]
TARGETS=[1500+d for d in IDS]+[2000+d for d in IDS]
CROSS_CAP=1048576
N=65536

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_text())
def bind(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def bound(item):
    p=Path(item['path'])
    if p.is_symlink() or not p.is_file() or sha(p)!=item['sha256']:raise RuntimeError('Bound consumer file mismatch: '+str(p))
    return p
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    payload=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
    if path.exists():
        if path.read_bytes()!=payload:raise RuntimeError('Immutable consumer output differs')
    else:
        with path.open('xb') as f:f.write(payload)

def source_hashes():
    return {name:sha(Path(__file__).parent/name) for name in ('consumer.py','kl_statistics.py','run_replay_with_kl.py')}

def validate_intent(path,authorization,allocation,plan,plan_path,output):
    intent=read(path)
    if (intent.get('schema')!='C08_OPTIONAL_KL_INTENT_v1' or intent.get('execution_enabled') is not False
        or intent.get('datum_ids')!=IDS or intent.get('targets')!=TARGETS or intent.get('cross_LL_cap')!=CROSS_CAP
        or intent.get('N')!=N or intent.get('replicas')!=4 or intent.get('source_sha256')!=source_hashes()
        or intent.get('plan_sha256')!=sha(plan_path) or intent.get('original_identity')!=plan['identity']):
        raise RuntimeError('Frozen KL intent/source/plan differs')
    expected={str(r['target']):{c['raw_file']:c['raw_sha256'] for c in r['high_checkpoints']}
              for r in plan['rows'] if r['target'] in TARGETS}
    if len(expected)!=8 or intent.get('expected_raw_sha256')!=expected:raise RuntimeError('All eight original high products must be bound')
    if (authorization.get('optional_KL_intent_sha256')!=sha(path) or authorization.get('optional_KL_enabled') is not True
        or authorization.get('optional_KL_output')!=str((Path(output)/'optional_kl').resolve())
        or allocation.get('allocations',{}).get('optional_KL_cross')!=CROSS_CAP
        or authorization.get('resource_lock_root')!=allocation.get('resource_lock_root')):
        raise RuntimeError('Separate ROOT KL intent/allocation/shared-lock authorization required')
    return intent


class InlineConsumer:
    def __init__(self,runtime,plan,output,intent_path,authorization,allocation,plan_path):
        self.intent=validate_intent(intent_path,authorization,allocation,plan,plan_path,output)
        self.intent_sha=sha(intent_path);self.intent_path=Path(intent_path);self.runtime=runtime
        self.root=Path(output)/'optional_kl';self.replay_output=Path(output);self.plan=plan
        if runtime.identity!=self.intent['original_identity']:raise RuntimeError('One original resident C07 bank required')
        from run_calibration_campaign import Ledger
        self.ledger=Ledger(self.root/'cross_ledger',self.intent_sha,
          dict(maximum_training_likelihood_values=0,maximum_production_likelihood_values=CROSS_CAP,maximum_total_likelihood_values=CROSS_CAP))
        self.check_remaining()

    def check_remaining(self):
        remaining=0
        for target in TARGETS[:4]:
            for rep in range(4):
                if not (self.root/'cross'/f'target_{target:06d}_rep{rep}.json').exists():remaining+=N
        if self.ledger.totals()['total']+remaining>CROSS_CAP:
            raise RuntimeError('Cross spent plus missing exceeds 1048576; no automatic retry')

    def cross(self,row,cp,x):
        if row['target'] not in TARGETS[:4] or x.shape!=(N,5):raise ValueError('Only A_G four approved clouds')
        dest=self.root/'cross'/f'target_{row["target"]:06d}_rep{cp["replicate"]}.npz';receipt=dest.with_suffix('.json')
        expected=dict(intent_sha256=self.intent_sha,source_raw_sha256=cp['raw_sha256'],
          source_target=row['target'],evaluation_target=2000+row['datum'],replicate=cp['replicate'],samples=N,
          runtime_identity=self.runtime.identity)
        if receipt.exists():
            old=read(receipt)
            if any(old.get(k)!=v for k,v in expected.items()) or old.get('status')!='CROSS_VALUES_COMPLETE':raise RuntimeError('Cross cache identity differs')
            p=bound(old['artifact'])
            if p.resolve()!=dest.resolve():raise RuntimeError('Cross cache path differs')
            with np.load(p,allow_pickle=False) as z:
                if z.files!=['log_likelihood']:raise RuntimeError('Cross cache fields')
                value=z['log_likelihood'].copy()
            if value.shape!=(N,) or value.dtype!=np.dtype('float64') or not np.isfinite(value).all():raise RuntimeError('Cross cache values')
            return value
        if dest.exists():raise RuntimeError('Uncommitted cross orphan preserved; no recomputation/forged receipt')
        self.check_remaining()
        def compute():
            value=np.empty(N);bounds=np.asarray(self.runtime.bounds)
            for begin in range(0,N,2048):
                stop=min(N,begin+2048)
                theta=bounds[:,0]+x[begin:stop]*(bounds[:,1]-bounds[:,0])
                value[begin:stop]=self.runtime.likelihood(theta,np.full(stop-begin,2000+row['datum'],int))
            if not np.isfinite(value).all():raise ArithmeticError('Nonfinite cross likelihood; preserve failure, no substitution')
            dest.parent.mkdir(parents=True,exist_ok=True)
            with dest.open('xb') as f:np.savez(f,log_likelihood=value)
            write(receipt,dict(**expected,artifact=bind(dest),status='CROSS_VALUES_COMPLETE'))
            return value
        return self.ledger.call(self.runtime,'production',N,'optional_B_G_on_A_G',[2000+row['datum']],compute)

    def existing(self,row):
        path=self.root/'receipts'/f'target_{row["target"]:06d}.json'
        if not path.exists():return None
        record=read(path)
        raw={c['raw_file']:c['raw_sha256'] for c in row['high_checkpoints']}
        if (record.get('status')!='CONSUMPTION_COMPLETE' or record.get('target')!=row['target']
            or record.get('intent_sha256')!=self.intent_sha or record.get('raw_sha256')!=raw):
            raise RuntimeError('Consumer receipt mismatch')
        artifacts=record.get('artifacts',[])
        if len(artifacts)!=(9 if row['target']<2000 else 2):raise RuntimeError('Required consumer artifacts missing')
        for item in artifacts:
            p=bound(item)
            if self.root.resolve() not in p.resolve().parents:raise RuntimeError('Consumer artifact escaped namespace')
        statistics=self.root/'statistics'/f'target_{row["target"]:06d}.json'
        if artifacts[0]!=bind(statistics):raise RuntimeError('Consumer statistics binding differs')
        s=read(statistics)
        if (s.get('target')!=row['target'] or s.get('raw_sha256')!=raw
            or s.get('runtime_identity')!=self.runtime.identity or s.get('intent_sha256')!=self.intent_sha):
            raise RuntimeError('Consumer statistics identity differs')
        return bind(path)

    def consume(self,row):
        if row['target'] not in TARGETS:return []
        prior=self.existing(row)
        if prior:return [prior]
        if (self.replay_output/'archives'/f'target_{row["target"]:06d}.json').exists():
            raise RuntimeError('Required KL raw was archived before consumer; no extra replay authorized')
        if sha(self.intent_path)!=self.intent_sha or source_hashes()!=self.intent['source_sha256']:
            raise RuntimeError('Frozen consumer source/intent changed')
        replicas=[];rawmap={}
        for cp in row['high_checkpoints']:
            p=self.replay_output/'raw'/cp['raw_file'];before=sha(p)
            if before!=cp['raw_sha256'] or p.is_symlink():raise RuntimeError('Original raw SHA required before consumer')
            with np.load(p,allow_pickle=False) as z:
                if z['target'].item()!=row['target'] or z['replicate'].item()!=cp['replicate']:raise RuntimeError('Raw target/replicate')
                x=z['x_unit'].copy();lw=z['log_weights'].copy()
                ll=z['log_likelihood'].copy() if row['target']<2000 else None
            if (x.shape!=(N,5) or lw.shape!=(N,) or not np.isfinite(x).all() or not np.isfinite(lw).all()
                or np.any((x<0)|(x>1)) or (ll is not None and (ll.shape!=(N,) or not np.isfinite(ll).all()))):
                raise RuntimeError('Original finite four HIGH65536 clouds required before any cross LL')
            ratio=None if ll is None else ll-self.cross(row,cp,x)
            replicas.append(summarize_replica(x,lw,ratio))
            if sha(p)!=before:raise RuntimeError('Raw changed during consumer')
            rawmap[cp['raw_file']]=before
        summary=combine(replicas,self.runtime.bounds)
        summary.update(target=row['target'],datum=row['datum'],scientific_model=row['scientific_model'],
          runtime_identity=self.runtime.identity,intent_sha256=self.intent_sha,raw_sha256=rawmap,
          original_proposal=row['original_files']['proposal'],original_checkpoints=row['high_checkpoints'],
          replica_sufficient_statistics=replicas,scope='Finite IID importance cloud; conditional-data MCSE, no tail or deterministic certificate')
        dest=self.root/'statistics'/f'target_{row["target"]:06d}.json';write(dest,summary);artifacts=[bind(dest)]
        if row['target']<2000:
            for cp in row['high_checkpoints']:
                cross=self.root/'cross'/f'target_{row["target"]:06d}_rep{cp["replicate"]}.json'
                artifacts.extend([bind(cross),read(cross)['artifact']])
        if row['target']>=2000:
            ag=self.root/'statistics'/f'target_{1500+row["datum"]:06d}.json'
            ar=next(r for r in self.plan['rows'] if r['target']==1500+row['datum'])
            if self.existing(ar) is None:raise RuntimeError('A_G compact must precede B_G; never hold AG raw for BG')
            pair=finish_kl(read(ag),summary);pair.update(datum=row['datum'],AG_statistics=bind(ag),BG_statistics=bind(dest),intent_sha256=self.intent_sha)
            pairpath=self.root/'pairs'/f'datum_{row["datum"]:03d}.json';write(pairpath,pair);artifacts.append(bind(pairpath))
        receipt=self.root/'receipts'/f'target_{row["target"]:06d}.json'
        write(receipt,dict(schema='C08_KL_MOMENTS_CONSUMER_RECEIPT_v1',status='CONSUMPTION_COMPLETE',
          target=row['target'],datum=row['datum'],intent_sha256=self.intent_sha,raw_sha256=rawmap,
          artifacts=artifacts,numerical_status=summary['failures'] or ['FINITE_ESTIMATE_NO_TAIL_CERTIFICATE'],
          all_failures_retained=True,remaining_pair_stage='BG normalization pending' if row['target']<2000 else 'pair finalized'))
        return [bind(receipt)]

    def finish(self):
        for target in TARGETS:
            row=next(r for r in self.plan['rows'] if r['target']==target)
            if self.existing(row) is None:raise RuntimeError('Missing required optional consumer')
        self.runtime.verify_unchanged()
        if source_hashes()!=self.intent['source_sha256']:raise RuntimeError('Consumer closure changed')
        total=self.ledger.totals(audit=True)
        if total['total']!=CROSS_CAP or total['unclosed_reservations']!=0:raise RuntimeError('Complete KL cross count differs')
        return dict(status='EIGHT_RAW_PRODUCTS_CONSUMED_FOUR_KL_PAIRS',cross_ledger=total,
                    extra_replay_LL=0,additional_banks=0,intent_sha256=self.intent_sha)
