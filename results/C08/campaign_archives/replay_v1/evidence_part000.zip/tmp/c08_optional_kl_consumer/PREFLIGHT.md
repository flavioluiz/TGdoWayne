# Consumidor opcional KL/momentos — candidato separado

Este pacote implementa o consumo prospectivo dos oito produtos HIGH A_G/B_G
dos quatro IDs fixos 25/26/44/48. Não executou likelihood PTA, ORF, draws
físicos, bancos ou leitura de raw real. `intent.json` e `manifest.json` serão
criados por `prepare_intent.py`, exclusivamente a partir de metadados.
Execução depende de nova revisão/autorização ROOT para este wrapper.

`run_replay_with_kl.py` é uma cópia separada do runner original, com um hook
explícito depois do diagnóstico e antes de `archive_target`. `wrapper.patch`
mostra todo o delta. Nenhum byte do replay, driver, runtime ou C07 original é
alterado; suas funções replay/diagnóstico/arquivo permanecem chamadas como
biblioteca intacta. A construção do único banco e ambos os locks continuam no
runner. O consumidor recebe esse banco e nunca chama build/init de runtime.

## Contagem e intenção antes dos resultados

Os oito conjuntos HIGH já fazem parte dos 160 replays obrigatórios:
8×4×65.536 = 2.097.152 draws existentes, sem replay adicional. Apenas B_G nos
draws A_G é novo: 4×4×65.536 = **1.048.576 LL**, alocação própria já presente
no planejamento combinado. Os 41.943.040 LL de replay ficam em ledger
inalterado; os cross ficam em ledger próprio. Cada chamada reserva antes,
contabiliza incremento real do runtime, preserva falhas e verifica gasto mais
restante. Soma replay+cross 42.991.616. Não há crédito fictício de cache nem
recálculo automático em uma retomada.

O índice original de consumidores exige SHA de recibos que ainda não existem;
não pode ser congelado com hashes futuros. Aqui ROOT vincula primeiro o SHA
da **intenção imutável**, fontes, oito mapas de raw SHA originais, 4 IDs,
escopo, cap e lock. Depois de consumir, o hook passa o SHA real do recibo
resultante para a função `archive_target` original. Isso não modifica um
índice congelado nem fabrica uma evidência antecipada.

A autorização original de replay deve também conter:

```
optional_KL_enabled: true
optional_KL_intent_sha256: SHA de intent.json revisado
optional_KL_output: <output original do replay>/optional_kl
```

A autorização deve vincular os `source_sha256` produzidos pelo novo wrapper;
a alocação comum precisa conter `optional_KL_cross=1048576`. O G0, publicação,
identidade C07, fontes originais, binário, caminhos e lock continuam sujeitos
a todos os guards originais. A CLI exige `--kl-intent` e `--execute`; sem
`--execute` não constrói banco, abre raw ou avalia likelihood.

## Duas etapas sem manter raw A_G esperando B_G

O replay processa todos os A_G antes dos B_G. No A_G, o consumidor abre uma
réplica por vez, verifica SHA/target/replica, avalia B_G em batch2048 e grava
imediatamente cache cross e recibo vinculados ao raw e runtime. Acumula
momentos, log-ratio e estatísticas suficientes de covariância. Após quatro
réplicas, grava `CONSUMPTION_COMPLETE`, incluindo hashes dos caches e do
compacto, e o arquivo original pode aposentar os quatro raws A_G.

Mais tarde, B_G usa seus quatro raws já exigidos pelo replay, sem nova LL.
O compacto A_G fornece toda sua contribuição à KL; não se reabre raw A_G.
O recibo B_G vincula a normalização/momentos B_G e o par final. Uma retomada
com recibo completo custa zero LL e pode ocorrer com raw já aposentado.
Arquivo cross órfão sem recibo, corrupção de cache, source ou identity provoca
falha preservada; não há autorização de inventar recibo ou repetir seu custo.

## Quantidades e incerteza

Para mesmos priors normalizados em ambos os modelos:

```
KL(A_G || B_G) = E_A[ell_A-ell_B] + logZ_B - logZ_A.
```

Sob a proposta A_G, sejam `r_i=w_i/mean(w)` e `f_i=ell_A-ell_B`.
As influências são `IF_mu=r_i*(f_i-mu)` e `IF_logZA=r_i-1`.
A contribuição A_G usa `IF_mu-IF_logZA`; sua variância inclui **menos duas
vezes a covariância**, calculada da mesma nuvem. B_G usa `IF_logZB=r_i-1`.
As variâncias A_G e B_G podem somar porque as propostas/draws são de streams
de target distintos, condicionados aos mesmos dados. Não se trata mu e logZA
como independentes nem se descarta o erro da normalização B_G.

Para cada funcional, calcula-se a covariância IID pooled com correção de
Bessel e a covariância entre as quatro médias de influência de réplica;
usa-se a maior variância funcional. As estatísticas suficientes preservam
`sum(w),sum(w²),sum(w*h),sum(w²*h),sum(w²*h*h.T)`, em escala log estável,
para cinco primeiros momentos, 15 produtos de segunda ordem e f no A_G.
Os momentos físicos usam transformação afim dos limites de prior. A
covariância posterior `E[x_i*x_j]-E[x_i]E[x_j]` propaga a incerteza completa
por sua influência, em vez de reaproveitar MCSE da média.

Mantêm-se os guards originais de peso (deletion bound .00335 por réplica) e
saturação (massa <=1e-12). Seus failures acompanham todos os produtos;
`CONSUMPTION_COMPLETE` significa transporte concluído e permite liberar raw,
não PASS científico. KL negativa por ruído permanece negativa, sem clipping.
Momentos/KL são estimativas finitas de importance sampling com MCSE
assintótica; não certificam caudas não vistas, erro determinístico uniforme,
Bayes factor isolado ou ordenação populacional. São quatro exemplos fixos.

## Memória, validação e limites

O consumidor processa uma réplica65536 por vez. X ocupa2.62MB; h20/h21
podem coexistir transitoriamente (~21.5MB); a matriz ponderada h custa11MB;
vetores e cross cabem em poucos MB. Reserva própria prospectiva128MiB,
contida na reserva256MiB já disponível para endpoints do replay, que terminou
antes de consumir. Apenas um banco C07 reside; o cap numérico continua4GiB,
raw1GiB. Estimativa não é garantia de RSS. Os caches cross somam8.388.608bytes
numéricos; cap de outputs prospectivo64MiB. Nenhum cap é aumentado pelo hook.

Seis TOYs passam: covariância logratio/logZ contra influência explícita,
momentos físicos, KL negativa sem clipping, preservação de overweight/NaN,
contrato de intenção/alocação, e lifecycle A_G→aposentar raw→B_G com zero
LL B_G adicional e corrupção de cache rejeitada. O último usa32 avaliações
analíticas TOY, nenhuma física. Pico RSS39.5MB, CPU0.106023s; primeira rodada
apenas estatística, também PASS, preservada. A seleção não leu HIGH arrays.

Antes de execução ROOT ainda deve revisar o diff, o fechamento de fontes,
os números deste consumidor e sua inserção no launcher do replay. O launcher
mantém limites de recursos/CPU globais; a alocação600CPU dos controles ORF
finitos é outro estágio e não é silenciosamente usada por este replay.
