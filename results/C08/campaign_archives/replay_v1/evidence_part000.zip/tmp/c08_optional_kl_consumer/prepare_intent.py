"""Metadata-only candidate freeze; reads no raw array, truth or observation."""
from pathlib import Path
import json
from consumer import sha,read,write,source_hashes,IDS,TARGETS,CROSS_CAP,N,bind

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def build():
    plan_path=ROOT/'tmp/c08_quantile_replay_design/frozen_c07/replay_plan.json'
    plan=read(plan_path)
    selected=[r for r in plan['rows'] if r['target'] in TARGETS]
    if [r['target'] for r in selected]!=TARGETS:raise RuntimeError('Frozen four AG and four BG targets differ')
    intent=dict(schema='C08_OPTIONAL_KL_INTENT_v1',execution_enabled=False,datum_ids=IDS,targets=TARGETS,
      selection='Four predeclared engineering datum IDs, no HIGH/truth/error selection',
      N=N,replicas=4,cross_LL_cap=CROSS_CAP,extra_replay_LL=0,simultaneous_banks=1,
      plan_sha256=sha(plan_path),original_identity=plan['identity'],source_sha256=source_hashes(),
      expected_raw_sha256={str(r['target']):{c['raw_file']:c['raw_sha256'] for c in r['high_checkpoints']} for r in selected},
      original_proposal_bindings={str(r['target']):r['original_files']['proposal'] for r in selected},
      shared_resource_lock='Inherited held lock from separately authorized replay wrapper; never construct a second bank',
      lifecycle=['A_G: consume all four raw replicas, evaluate B_G on A_G exactly once; preserve cross cache and compact moments/logratio/logZA/covariance',
        'A_G: emit consumption receipt, then unchanged replay archive retires raw before the next target',
        'B_G: consume its already required four replay raws with zero new likelihood, compute logZB/moments and combine with A_G compact',
        'B_G: emit consumption receipt with final pair, then unchanged replay archive retires raw'],
      posterior_quantities=['five first moments','15 second/covariance moments','KL(A_G||B_G) with full AG logratio/logZA covariance'],
      MCSE='IID influence/sufficient-stat covariance; maximum of pooled and four-replica block variances for each functional; AG/BG streams independent conditional on data',
      guard_policy='Preserve original .00335 deletion-weight and 1e-12 saturation guards. Failed moments/KL remain present with unresolved status; no smoothing/clipping/resampling or uniform/tail certificate.',
      memory=dict(owned_numeric_allowance_bytes=134217728,existing_replay_endpoint_reserve_bytes=268435456,
        high_replica_unit_bytes=N*5*8,feature_matrix_peak_two_copies_bytes=N*41*8,
        weighted_feature_bytes=N*21*8,cross_values_total_bytes=CROSS_CAP*8,
        total_original_bank_plus_endpoint_reserve_bytes=plan['budget']['original_estimated_numeric_bytes']+268435456,
        output_cap_bytes=67108864,scope='Arithmetic estimate, not RSS guarantee; one replica at a time after endpoint evaluation returns. Root launcher maintains original4GiB numeric/1GiB raw caps.'),
      combined_LL=dict(required_replay=41943040,cross=1048576,replay_plus_cross=42991616,
        previously_reserved_cross=True,additional_allocation_beyond_frozen_104928832=0),
      failure_policy='Fail closed on changed source/cache/identity; durable failed counts remain spent. No automatic retry. Complete orphan cross without receipt requires external review, not a fabricated hash.',
      ROOT_authorization=None,pending=['ROOT review of source/TOYs/diff','ROOT replay authorization explicitly binding optional_KL_intent_sha256, enabled=true, output and shared allocation/lock'],
      preparation_scope=dict(physical_calls=0,real_raw_array_reads=0,truth_array_reads=0,observation_array_reads=0,bank_builds=0))
    write(HERE/'intent.json',intent)
    files=['consumer.py','kl_statistics.py','run_replay_with_kl.py','prepare_intent.py','test_toy.py','toy_results.json','wrapper.patch','PREFLIGHT.md','intent.json']
    write(HERE/'manifest.json',dict(schema='C08_OPTIONAL_KL_CANDIDATE_MANIFEST_v1',execution_enabled=False,
      files={name:sha(HERE/name) for name in files},original_replay_runner=bind(ROOT/'tmp/c08_quantile_replay_design/run_replay.py'),
      original_replay_plan=bind(plan_path),counts=intent['combined_LL']))
    print(json.dumps(dict(intent_sha256=sha(HERE/'intent.json'),manifest_sha256=sha(HERE/'manifest.json'),counts=intent['combined_LL']),indent=2))

if __name__=='__main__':build()
