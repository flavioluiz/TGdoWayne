#!/usr/bin/env python3
"""Separate C08 replay candidate with eight inline KL consumers; no default execution."""
from pathlib import Path
import argparse,importlib,json,sys,platform,os
import numpy as np

# An explicit repository path is required when this temporary package is ported.
def bootstrap(repository):
    root=Path(repository).resolve()
    sys.path.insert(0,str(root/'src'));sys.path.insert(0,str(root/'scripts'))
    sys.path.insert(0,str(root/'tmp/c08_quantile_replay_design'))
    return root


def runner_sources(root,helper):
    from inference.campaign_io import sha256
    own=Path(__file__).resolve().parent
    original=root/'tmp/c08_quantile_replay_design'
    sources={name:str(original/name) for name in ['contracts.py','endpoints.py','replay.py','run_replay.py']}
    sources.update({name:str(own/name) for name in ['run_replay_with_kl.py','consumer.py','kl_statistics.py']})
    sources['frozen_bracket_helper']=str(Path(helper).resolve())
    sources['original_driver']=str(root/'scripts/run_calibration_campaign.py')
    sources['inference_package_init']=str(root/'src/inference/__init__.py')
    for name in ['iid_optimized','iid_diagnostics']:
        sources[name]=str(root/'src/inference'/(name+'.py'))
    return {k:sha256(v) for k,v in sources.items()}


def prepare_preflight(plan_path,output,*,repository,helper):
    from contracts import bound_file,source_closure,REPLAY_LL,HIGH_N,HELPER_SHA
    from inference.campaign_io import read_json,sha256,canonical_hash
    plan=read_json(plan_path);bound_file(helper,HELPER_SHA)
    original=read_json(bound_file(plan['original_manifest']['path'],plan['original_manifest']['sha256']))
    closure=source_closure(repository,original)
    sources=runner_sources(Path(repository).resolve(),helper)
    report=dict(schema='C08_HIGH_REPLAY_PREFLIGHT_CANDIDATE_v1',execution_ready=False,
        plan_sha256=sha256(plan_path),original_identity=plan['identity'],output=str(Path(output).resolve()),
        source_sha256=sources,original_source_closure=closure,
        counts=plan['counts'],budgets=plan['budget'],
        backend_build_or_data_loaded=False,new_training_LL=0,new_high_LL_executed=0,
        maximum_LL=REPLAY_LL,optional_KL_cross_LL=1048576,combined_replay_and_cross_LL=42991616,optional_extra_bank=0,raw_bytes_per_target=plan['budget']['actual_stored_bytes_per_target'],
        sampler_estimated_workspace_bytes=128*1024**2,
        endpoint_estimated_owned_peak_bytes=256*1024**2,
        memory_scope='Original numeric estimate plus256MiB endpoint reserve must fit4GiB. One live bank. Estimates are not RSS certificates.',
        active_original_native_banks=1,raw_release_after_all_required_consumers=True,
        current_environment=dict(python=platform.python_version(),numpy=np.__version__,machine=platform.machine()),
        pending=['ROOT authorization bound to this source/plan/output',
                 'G0 published C07 v0.7.0 base plus explicitly named correction release, and released workers/banks',
                 'Shared 110M allocation and common one-bank lock root',
                 'Explicit original runtime paths/native binary; same identity after construction',
                 'Domain-limited deterministic evidence, or record UNRESOLVED brackets',
                 'Required optional moment/KL consumers must finish before their raw retirement'],
        no_physical_execution_authorization=True)
    report['preflight_identity']=canonical_hash(report)
    return report


def compact_arrays(result):
    """At most20x23 endpoints, all MC failure flags and bands; no posterior raw."""
    shape=(20,23);cuts=np.full(shape,np.nan);cdf=cuts.copy();mcse=cuts.copy()
    lo=cuts.copy();hi=cuts.copy();valid=np.zeros(shape,bool);usable=valid.copy()
    structural=valid.copy();rep_mean=np.full(shape+(4,),np.nan);rep_se=rep_mean.copy()
    rep_pass=np.zeros(shape+(6,),bool);rep_resolved=rep_pass.copy()
    for i,row in enumerate(result['rows']):
        n=len(row['cuts']);valid[i,:n]=True;cuts[i,:n]=row['cuts']
        lo[i,:n]=row['lower_CDF_band'];hi[i,:n]=row['upper_CDF_band']
        for k,stat in enumerate(row['endpoint_statistics']):
            cdf[i,k]=stat['estimate'];mcse[i,k]=stat['mcse'];usable[i,k]=stat['endpoint_usable']
            structural[i,k]=stat['structural']
            if not stat['structural']:
                rep_mean[i,k]=stat['replication_estimates'];rep_se[i,k]=stat['replication_mcse']
                rep_pass[i,k]=[s['consistent'] for s in stat['replication_contrasts']]
                rep_resolved[i,k]=[s['resolved'] for s in stat['replication_contrasts']]
    return dict(cuts=cuts,endpoint_present=valid,cdf=cdf,mcse=mcse,usable=usable,
                structural=structural,lower_CDF_band=lo,upper_CDF_band=hi,
                replication_estimates=rep_mean,replication_mcse=rep_se,
                replication_consistent=rep_pass,replication_resolved=rep_resolved,
                quantile_bounds=np.array([[r['lower_quantile'],r['upper_quantile']] for r in result['rows']]),
                quantile_resolved=np.array([not r['status'].startswith('UNRESOLVED') for r in result['rows']]),
                probabilities=np.tile([.05,.5,.9,.95],5),parameters=np.repeat(np.arange(5),4))


def diagnose_replayed(row,output,plan_sha,*,helper,evidence,configuration):
    from contracts import bound_file
    from inference.campaign_io import read_json,sha256,write_npz_new,write_json_new
    from inference.iid_diagnostics import json_safe
    from replay import load_replayed_high
    from endpoints import low_guard_metadata,evaluate_high
    output=Path(output);dest=output/'diagnostics'/f'target_{row["target"]:06d}.json'
    frozen=read_json(bound_file(row['cut_manifest']['path'],row['cut_manifest']['sha256']))
    # The immutable low-only cut manifest is checked BEFORE any high raw access.
    numeric=bound_file(row['original_files']['numeric']['path'],row['original_files']['numeric']['sha256'])
    producer=read_json(bound_file(row['original_files']['producer']['path'],row['original_files']['producer']['sha256']))
    if dest.exists():
        old=read_json(dest)
        if old['plan_sha256']!=plan_sha or old['cut_manifest_sha256']!=row['cut_manifest']['sha256']:
            raise RuntimeError('Existing bracket diagnostic belongs to another replay.')
        bound_file(dest.parent/old['numeric_file'],old['numeric_sha256']);return dest
    with np.load(numeric,allow_pickle=False) as data:low=low_guard_metadata(data,producer)
    x,lw=load_replayed_high(row,output)
    result=evaluate_high(x,lw,frozen,low,helper=helper,evidence=evidence,configuration=configuration)
    numeric_out=dest.with_suffix('.npz');arrays=compact_arrays(result)
    if numeric_out.exists():
        # Preserve an interrupted compact output; compare numerical bytes by
        # equal_nan because padding intentionally encodes absent endpoints.
        with np.load(numeric_out,allow_pickle=False) as old:
            if set(old.files)!=set(arrays):raise RuntimeError('Interrupted compact fields differ.')
            for key,value in arrays.items():
                if old[key].dtype!=value.dtype or not np.array_equal(old[key],value,equal_nan=True):
                    raise RuntimeError('Interrupted compact numerical result differs.')
    else:write_npz_new(numeric_out,**arrays)
    result.update(scope='C08_HORIZONTAL_QUANTILE_DIAGNOSTIC',plan_sha256=plan_sha,target=row['target'],
                  cohort_stratum=row['stratum'],all20_retained=True,
                  cut_manifest_sha256=row['cut_manifest']['sha256'],
                  raw_sha256={c['raw_file']:c['raw_sha256'] for c in row['high_checkpoints']},
                  numeric_file=numeric_out.name,numeric_sha256=sha256(numeric_out),
                  numeric_bytes=numeric_out.stat().st_size)
    write_json_new(dest,json_safe(result));return dest


def run_authorized(args):
    from contracts import bound_file,load_helper,protocol,REPLAY_LL
    from inference.campaign_io import read_json,sha256,canonical_hash,write_json_new
    from replay import validate_execution,replay_replicate,archive_target
    from run_calibration_campaign import Ledger,campaign_lock
    root=Path(args.repository).resolve();plan=read_json(args.plan);out=Path(args.output).resolve()
    if any(os.environ.get(k)!='1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS')):
        raise RuntimeError('Explicit BLAS/OpenMP single-thread environment is required before building the original six-worker likelihood backend.')
    auth=read_json(args.authorization);g0=read_json(args.g0);allocation=read_json(args.allocation)
    from consumer import validate_intent,InlineConsumer
    validate_intent(args.kl_intent,auth,allocation,plan,args.plan,out)
    sources=runner_sources(root,args.helper)
    validate_execution(plan,auth,g0,allocation,plan_path=args.plan,output=out,repository=root,source_hashes=sources)
    inputs=read_json(args.runtime_inputs)
    names={'experiment','data','table','table_manifest','validation_config','settings','native_library','native_build_manifest'}
    if set(inputs)!=names:raise ValueError('Eight explicit original runtime input paths required.')
    # No data are deserialized by these hashes. The original 31 source digests
    # were checked before importing/constructing CampaignRuntime.
    for key,path in inputs.items():bound_file(path,plan['original_input_sha256'][key])
    evidence_index={} if args.evidence_index is None else read_json(args.evidence_index)
    consumers={} if args.consumers is None else read_json(args.consumers)
    evidence_sha=None if args.evidence_index is None else sha256(args.evidence_index)
    consumer_sha=None if args.consumers is None else sha256(args.consumers)
    if auth.get('evidence_index_sha256')!=evidence_sha or auth.get('consumers_index_sha256')!=consumer_sha:
        raise RuntimeError('Authorization does not bind evidence/required raw consumers.')
    if auth.get('diagnostic_protocol_content_sha256')!=canonical_hash(protocol()):
        raise RuntimeError('Endpoint diagnostic guard families not explicitly authorized.')
    lockroot=Path(auth['resource_lock_root']).resolve();plan_sha=sha256(args.plan);helper=load_helper(args.helper)
    # The shared resource lock is acquired BEFORE bank construction, unlike
    # preflight: at most one C07/C08 bank can be live in cooperating drivers.
    with campaign_lock(lockroot),campaign_lock(out):
        identity=canonical_hash(dict(plan_sha256=plan_sha,authorization_sha256=sha256(args.authorization)))
        runtime=None
        budget=dict(maximum_training_likelihood_values=0,maximum_production_likelihood_values=REPLAY_LL,
                    maximum_total_likelihood_values=REPLAY_LL)
        ledger=Ledger(out/'ledger',identity,budget)
        manifest=out/'replay_execution.json'
        execution=dict(schema='C08_EXACT_REPLAY_EXECUTION_v1',identity=identity,plan_sha256=plan_sha,
                       source_sha256=sources,authorization_sha256=sha256(args.authorization))
        if manifest.exists():
            if not args.resume or read_json(manifest)!=execution:raise RuntimeError('Identified --resume required.')
        else:write_json_new(manifest,execution)
        # A completed raw, including an orphan, costs zero new LL to recover by
        # its original SHA. A failed partial computation spends its ledger count;
        # completing the full160 again cannot exceed the original fixed cap.
        remaining=0
        for row in plan['rows']:
            if (out/'archives'/f'target_{row["target"]:06d}.json').exists():continue
            for cp in row['high_checkpoints']:
                raw=out/'raw'/cp['raw_file']
                if raw.exists():bound_file(raw,cp['raw_sha256'])
                else:remaining+=cp['samples']
        if ledger.totals()['total']+remaining>REPLAY_LL:raise RuntimeError('Spent plus remaining exact replay exceeds fixed cap; no retry allocation.')
        try:
            from inference.campaign_runtime import CampaignRuntime
            runtime=CampaignRuntime(inputs['experiment'],inputs['data'],inputs['table'],inputs['table_manifest'],
                inputs['validation_config'],inputs['settings'],build=False,
                threads=plan['original_thread_plan']['production'],training_threads=plan['original_thread_plan']['training'],
                native_library_path=inputs['native_library'],native_build_manifest_path=inputs['native_build_manifest'])
            if runtime.identity!=plan['identity']:raise RuntimeError('Original runtime identity differs; no native fallback.')
            report=runtime.preflight()
            if report['estimated_numeric_bytes']+256*1024**2>4*1024**3:raise RuntimeError('Original bank plus endpoint reserve exceeds C08 cap.')
            runtime.require_execution();runtime.set_phase('production');runtime.snapshot(out)
            consumer=InlineConsumer(runtime,plan,out,args.kl_intent,auth,allocation,args.plan)
            for row in plan['rows']:
                archive=out/'archives'/f'target_{row["target"]:06d}.json'
                dest=out/'diagnostics'/f'target_{row["target"]:06d}.json'
                extra=list(consumers.get(str(row['target']),[]))
                if archive.exists():
                    extra+=consumer.consume(row)
                    archive_target(row,out,dest,plan_sha=plan_sha,consumers=extra);continue
                bound_file(row['cut_manifest']['path'],row['cut_manifest']['sha256'])
                for cp in row['high_checkpoints']:
                    reserve=0 if (out/'raw'/cp['raw_file']).exists() else cp['samples']
                    ledger.call(runtime,'production',reserve,'replay_high',[row['target']],
                        lambda row=row,cp=cp:replay_replicate(runtime,row,cp,out,plan_sha=plan_sha,resume=args.resume))
                key=row['scientific_model']+':'+str(row['datum']);eref=evidence_index.get(key)
                evidence=None if eref is None else read_json(bound_file(eref['path'],eref['sha256']))
                dest=diagnose_replayed(row,out,plan_sha,helper=helper,evidence=evidence,configuration=protocol())
                extra+=consumer.consume(row)
                archive_target(row,out,dest,plan_sha=plan_sha,consumers=extra)
                print(json.dumps(dict(event='replay_target_archived',target=row['target'],ledger=ledger.totals())),flush=True)
            optional_result=consumer.finish()
            runtime.verify_unchanged()
            if runner_sources(root,args.helper)!=sources:raise RuntimeError('Executor sources changed.')
            result=dict(status='ALL160_MATCHED_HIGH_REPLAYS_ARCHIVED',plan_sha256=plan_sha,
                identity=identity,targets=[r['target'] for r in plan['rows']],ledger=ledger.totals(audit=True),
                all_original_raw_SHA_matched=True,no_calibration_or_uniform_error_claim=True,optional_KL=optional_result)
            final=out/'complete.json'
            if final.exists():
                if read_json(final)!=result:raise RuntimeError('Complete replay differs.')
            else:write_json_new(final,result)
            return result
        finally:
            if runtime is not None:runtime.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository',type=Path,required=True)
    parser.add_argument('--helper',type=Path,required=True)
    sub=parser.add_subparsers(dest='command',required=True)
    f=sub.add_parser('freeze-c07');f.add_argument('--campaign',type=Path,required=True)
    f.add_argument('--cohort',type=Path,required=True);f.add_argument('--design',type=Path,required=True)
    f.add_argument('--output',type=Path,required=True)
    p=sub.add_parser('preflight');p.add_argument('--plan',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--report',type=Path,required=True)
    r=sub.add_parser('run');r.add_argument('--execute',action='store_true')
    for name in ['plan','output','authorization','g0','allocation','runtime_inputs']:
        r.add_argument('--'+name.replace('_','-'),type=Path,required=True)
    r.add_argument('--evidence-index',type=Path);r.add_argument('--consumers',type=Path)
    r.add_argument('--resume',action='store_true');r.add_argument('--kl-intent',type=Path,required=True)
    args=parser.parse_args();root=bootstrap(args.repository)
    from inference.campaign_io import write_json_new
    if args.command=='freeze-c07':
        from contracts import freeze_c07
        result=freeze_c07(root,args.campaign,args.cohort,args.design,args.helper,args.output)
        print(json.dumps(result['counts']))
    elif args.command=='preflight':
        result=prepare_preflight(args.plan,args.output,repository=root,helper=args.helper)
        write_json_new(args.report,result);print(json.dumps(dict(execution_ready=False,maximum_LL=result['maximum_LL'])))
    else:
        if not args.execute:raise RuntimeError('No --execute: no runtime, bank, RNG or high raw is opened.')
        print(json.dumps(run_authorized(args)))

if __name__=='__main__':main()
