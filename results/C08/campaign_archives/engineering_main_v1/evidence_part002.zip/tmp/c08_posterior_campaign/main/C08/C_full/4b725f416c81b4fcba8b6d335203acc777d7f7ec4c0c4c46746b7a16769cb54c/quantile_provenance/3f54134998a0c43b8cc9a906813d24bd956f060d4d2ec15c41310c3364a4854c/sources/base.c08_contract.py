"""C08 prospective routing, seeds and work counts. No likelihood or truth loads."""
from pathlib import Path
import copy
from inference.campaign_io import canonical_hash, positive_int, read_json, sha256

VARIANTS = ('C_beta', 'C_full')
PHASES = ('engineering', 'main')
LEVELS = [16384, 65536]
ENGINEERING_SEEDS = {
    'C_beta': dict(training=808120202, production=808120302),
    'C_full': dict(training=808120201, production=808120301),
}
MAIN_SEEDS = {
    'C_beta': dict(training=808110202, production=808110302),
    'C_full': dict(training=808110201, production=808110301),
}


def validate_index(index):
    if (index.get('schema') != 'C08_COHORT_ROUTING_INDEX_v1'
            or index.get('datasets') != 500
            or index.get('truth_coordinates_present') is not False):
        raise ValueError('A C08 routing-only 500-datum index is required.')
    representative, stress = index['representative_ids'], index['stress_ids']
    for rows, size in ((representative, 24), (stress, 8)):
        if (not isinstance(rows, list) or len(rows) != size
                or any(type(x) is not int or not 0 <= x < 500 for x in rows)
                or rows != sorted(set(rows))):
            raise ValueError('Cohort IDs must be sorted, unique and in range.')
    if set(representative) & set(stress):
        raise ValueError('Representative and stress strata must be disjoint.')
    if index['engineering_ids'] != representative[:4]:
        raise ValueError('Engineering uses exactly the first four frozen representative IDs.')
    for key in ('cohort_manifest_sha256', 'design_sha256', 'data_sha256',
                'generation_config_sha256', 'generation_sha256'):
        value = index.get(key)
        if not isinstance(value, str) or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
            raise ValueError('Invalid binding: '+key)
    return index


def target_rows(index, variant, phase):
    validate_index(index)
    if variant not in VARIANTS or phase not in PHASES:
        raise ValueError('Explicit C08 response variant and phase required.')
    ids = index['engineering_ids'] if phase == 'engineering' else sorted(index['representative_ids']+index['stress_ids'])
    return [dict(model=variant+suffix, datum=datum, internal_kernel=kernel,
                 internal_target=base*500+datum, external_target=variant+suffix+':'+str(datum),
                 cohort_stratum='representative' if datum in index['representative_ids'] else 'stress')
            for suffix, kernel, base in (('_CN', 'B_CN', 2), ('_G', 'B_G', 4)) for datum in ids]


def work_counts(targets):
    n = positive_int(targets, 'target count')
    training = (8192+1)*4*n
    production = sum(LEVELS)*4*n
    return dict(targets=n, training=training, production=production, total=training+production)


def combined_budget():
    main, engineering = work_counts(128), work_counts(16)
    replay = 32*5*4*65536
    optional_cross = 1048576
    # Separate direct truth likelihoods: 128 fine + 128 coarse + 128 H01
    # derivative-resolution separation + 128 independent SciPy evaluations.
    # Their ORF construction has a separate, still pending preflight.
    truth_diagnostic = 512
    total = main['total']+engineering['total']+replay+optional_cross+truth_diagnostic
    return dict(main_both_variants=main, engineering_both_variants=engineering,
                C_total_with_engineering=main['total']+engineering['total'],
                C_cap=60000000, required_C07_high_replay=replay,
                optional_KL_cross=optional_cross,
                reserved_direct_truth_likelihoods_all_four_checks=truth_diagnostic,
                maximum_planned_combined=total, combined_cap=110000000,
                unallocated_combined=110000000-total,
                ORF_work_authorized=False, extra_retries_authorized=False)


def settings(index, variant, phase):
    rows = target_rows(index, variant, phase); count = work_counts(len(rows))
    seeds = (ENGINEERING_SEEDS if phase == 'engineering' else MAIN_SEEDS)[variant]
    return dict(schema='C08_DRIVER_SETTINGS_v1', status='PROSPECTIVE_NOT_AUTHORIZED',
        execution_enabled=False, response_variant=variant, phase=phase,
        models=[variant+'_CN', variant+'_G'],
        targets=[dict(model=r['model'], datum=r['datum']) for r in rows],
        training=dict(steps=8192, approved=False, seed=seeds['training'], chains=4,
                      points_for_em=2048, gaussian_broadening=dict(wide_total_probability=.1, variance_multiplier=9)),
        production=dict(levels=LEVELS.copy(), replicates=4, seed=seeds['production'],
                        likelihood_batch=2048, descriptive_points_per_replicate=128, raw_compression='stored'),
        training_targets_per_block=16, production_targets_per_block=1,
        budget=dict(maximum_numeric_bytes=4*1024**3, maximum_loader_owned_numeric_bytes=1024**3,
                    backend_workspace_allowance_bytes=32*1024**2, validation_tile_size=128,
                    maximum_active_raw_bytes=1024**3,
                    maximum_training_likelihood_values=count['training'],
                    maximum_production_likelihood_values=count['production'],
                    maximum_total_likelihood_values=count['total']),
        cohort_index_sha256=None,
        memory_scope='Prospective 32MiB backend allowance; numeric cap is not an RSS guarantee. Runtime v2 must pass actual metadata preflight.',
        no_truth_in_training_or_production=True,
        no_retry_or_replacement=True)


def diagnostic_protocol(index, phase):
    validate_index(index)
    if phase not in PHASES: raise ValueError('Unknown phase.')
    population = 16 if phase == 'engineering' else 128
    return dict(protocol='C08_TARGET_IID_DIAGNOSTICS_v1', phase=phase,
                population_targets=population, execution_targets_per_variant=population//2,
                family_scope='Both C_beta and C_full; engineering is separate from main',
                levels=LEVELS.copy(), independent_replications=4,
                cdf_mcse_target=.00335, alpha_replicate_family=.05, alpha_refinement_family=.05,
                global_replicate_contrasts=204*population, global_refinement_contrasts=7*population,
                maximum_saturated_target_weight=1e-12,
                numerical_failures_retained=True, no_scientific_calibration_claim=True)


def validate_settings_and_protocol(runtime, index, protocol, phase, index_sha):
    rows = target_rows(index, runtime.response_variant, phase)
    expected = settings(index, runtime.response_variant, phase)
    actual = runtime.settings
    if runtime.n != 500 or list(map(int, runtime.targets)) != [r['internal_target'] for r in rows]:
        raise ValueError('Runtime target order/count differs from the frozen C08 cohort.')
    if runtime.target_index != [{k:v for k,v in r.items() if k != 'cohort_stratum'} for r in rows]:
        raise ValueError('Scientific/internal target index differs from routing contract.')
    for key in ('schema', 'response_variant', 'phase', 'models', 'targets', 'production',
                'training_targets_per_block', 'production_targets_per_block', 'budget'):
        if actual.get(key) != expected[key]: raise ValueError('Frozen C08 setting differs: '+key)
    train = copy.deepcopy(actual['training']); train.pop('approved', None)
    reference = copy.deepcopy(expected['training']); reference.pop('approved')
    if train != reference or actual.get('cohort_index_sha256') != index_sha:
        raise ValueError('Training seed/recipe or cohort identity changed.')
    if type(actual.get('execution_enabled')) is not bool or type(actual['training'].get('approved')) is not bool:
        raise ValueError('Execution/training approval switches must be explicit booleans.')
    if protocol != diagnostic_protocol(index, phase):
        raise ValueError('C08 numerical family/criteria changed; 64 executions still use main family128.')
    if runtime.input_hashes['data'] != index['data_sha256']:
        raise ValueError('Runtime observations differ from frozen C07 data.')
    return rows
