"""C08 horizontal quantile brackets with unchanged SNIS influence arithmetic."""
import itertools
import numpy as np
from scipy.special import logsumexp
from scipy.stats import norm
from inference.iid_optimized import TargetIIDContext
from inference.campaign_io import sha256, canonical_hash
from contracts import (PROBABILITIES, protocol, validate_protocol, verify_cut_manifest,
                       bound_file)

PAIRS=tuple(itertools.combinations(range(4),2))


def contrast(a,sa,b,sb,*,family,alpha):
    """Independent SNIS delta errors; no ESS substitution or zero-error pass."""
    se=float(np.hypot(sa,sb)); d=float(a-b); z=float(norm.isf(alpha/(2*family)))
    resolved=bool(np.isfinite(d) and np.isfinite(se) and se>0)
    return dict(difference=d,mcse=se,z=z,resolved=resolved,
                consistent=bool(resolved and abs(d)<=z*se))


def low_guard_metadata(numeric, producer):
    """Selected compact LOW guards only, called after cut freezing.

    The NPZ-like argument is indexed explicitly: no truth/PIT/quantile/high-CDF
    deserialization. Replication flags for logZ at LOW are retained as recorded.
    A caller must verify the external producer/compact receipt before this call.
    """
    spec=numeric['replication_specification']
    resolved=numeric['replication_resolved']; passed=numeric['replication_pass']
    selected=(spec[:,0]==0)&(spec[:,1]==26)
    if int(selected.sum())!=6: raise ValueError('Six recorded LOW logZ contrasts required.')
    r=numeric['log_evidence_by_replicate'][0].copy()
    s=numeric['log_evidence_mcse_by_replicate'][0].copy()
    saturation=[x['saturated_normalized_target_weight'] for x in producer['replicates']
                if x['level']==16384]
    if len(saturation)!=4 or r.shape!=(4,) or s.shape!=(4,):
        raise ValueError('Four LOW replicas required.')
    weight=bool(numeric['weight_deletion_guard_by_level'][0])
    return dict(weight_deletion_pass=weight,
        maximum_saturated_weight=float(max(saturation)),
        logZ_replica_pass=bool(np.all(resolved[selected]&passed[selected])),
        logZ=float(numeric['log_evidence_by_level'][0]),
        logZ_mcse=float(numeric['log_evidence_mcse_by_level'][0]),
        logZ_replicas=r.tolist(),logZ_replica_mcse=s.tolist(),
        low_only=True,source_original_recorded_family_retained=True)


def validate_evidence(evidence, frozen, *, verify_files=True):
    """An explicit domain-limited assessment; never derives CDF error from max logL.

    Missing/failed evidence is a legitimate unresolved result. A malformed or
    mismatched purported evidence record is an integrity error.
    """
    if evidence is None: return False, ['deterministic_evidence_missing']
    if (evidence.get('schema')!='C08_POSTERIOR_CDF_EVIDENCE_v1'
            or evidence.get('identity')!=frozen['identity']
            or evidence.get('scientific_model')!=frozen['scientific_model']
            or evidence.get('datum')!=frozen['datum']
            or evidence.get('cut_manifest_content_sha256')!=frozen['content_sha256']
            or evidence.get('operational_margin')!=.002
            or evidence.get('is_uniform_proof') is not False
            or not isinstance(evidence.get('posterior_domain'),str)
            or not evidence['posterior_domain'].strip()):
        raise ValueError('Domain-specific deterministic evidence identity differs.')
    checks=evidence.get('checks',{})
    if set(checks)!={'coarse_fine','independent_oracle','posterior_domain_controls'} or any(type(x)is not bool for x in checks.values()):
        raise ValueError('Three explicit boolean finite-evidence checks required.')
    files=evidence.get('sources',[])
    if not files: return False,['deterministic_evidence_sources_missing']
    if verify_files:
        for f in files:bound_file(f['path'],f['sha256'])
    failures=['deterministic_'+k for k,v in checks.items() if not v]
    return not failures,failures


def evaluate_high(x,log_weights,frozen,low_guards,*,helper,evidence=None,
                  configuration=None,verify_evidence_files=True):
    """Pure per-target array evaluator; no RNG, physical likelihood or truth.

    The compact result retains all 20 quantiles, every actual cut and every
    numerical failure. Global denominators never depend on this target/model.
    Shared weight/saturation/logZ-consistency failures give trivial intervals.
    A failed interior-cut indicator gets the vacuous CDF band [0,1].
    """
    p=protocol() if configuration is None else configuration;validate_protocol(p)
    verify_cut_manifest(frozen,helper)
    x=np.asarray(x);lw=np.asarray(log_weights)
    if (x.dtype.kind not in 'fiu' or lw.dtype.kind not in 'fiu' or lw.ndim!=2
            or lw.shape[0]!=4 or lw.shape[1]<2 or x.shape!=lw.shape+(5,)
            or not np.isfinite(x).all() or np.any((x<0)|(x>1))):
        raise ValueError('Aligned four-replication real arrays in the unit cube required.')
    required={'weight_deletion_pass','logZ_replica_pass','maximum_saturated_weight',
              'logZ','logZ_mcse','low_only'}
    if (not required<=set(low_guards) or low_guards['low_only'] is not True
            or any(type(low_guards[k])is not bool for k in ['weight_deletion_pass','logZ_replica_pass'])
            or not np.isfinite(low_guards['logZ']) or not np.isfinite(low_guards['maximum_saturated_weight'])
            or not 0<=low_guards['maximum_saturated_weight']<=1
            or np.isnan(low_guards['logZ_mcse']) or low_guards['logZ_mcse']<0):
        raise ValueError('Verified LOW common-guard metadata required.')
    context=TargetIIDContext(lw);weight=context.weights()
    saturated=np.any((x==0)|(x==1),axis=2)
    satmass=[float(np.exp(logsumexp(lw[r,saturated[r]])-logsumexp(lw[r])))
             if saturated[r].any() else 0. for r in range(4)]
    repZ=[contrast(weight['replications'][a]['log_evidence'],
                   weight['replications'][a]['log_evidence_delta_mcse'],
                   weight['replications'][b]['log_evidence'],
                   weight['replications'][b]['log_evidence_delta_mcse'],
                   family=p['additional_replicate_family'],alpha=p['additional_replicate_alpha'])
          for a,b in PAIRS]
    refineZ=contrast(low_guards['logZ'],low_guards['logZ_mcse'],
        weight['log_evidence'],weight['log_evidence_delta_mcse'],
        family=p['logZ_refinement_family'],alpha=p['logZ_refinement_alpha'])
    common=dict(low_weight=low_guards['weight_deletion_pass'],
        high_weight=weight['single_deletion_guard_pass'],
        low_saturation=low_guards['maximum_saturated_weight']<=p['maximum_saturated_weight'],
        high_saturation=max(satmass)<=p['maximum_saturated_weight'],
        low_logZ_replication=low_guards['logZ_replica_pass'],
        high_logZ_replication=all(t['consistent'] for t in repZ),
        logZ_refinement=refineZ['consistent'])
    evidence_ok,evidence_failures=validate_evidence(evidence,frozen,verify_files=verify_evidence_files)
    common_failures=[k for k,v in common.items() if not v]+evidence_failures
    rows=[];local_contrasts=6
    for j in range(5):
        unique=np.unique(np.concatenate([np.asarray(a) for a in frozen['cuts'][j]]))
        interior=unique[(unique>0)&(unique<1)]
        # At most16 indicators per call bounds the rare v1 near-threshold
        # float-matrix fallback too; no N x all460-endpoints allocation.
        values=[]
        for begin in range(0,len(interior),16):
            values.extend(context.cdf(x[:,:,j],interior[begin:begin+16],mcse_target=p['mcse_target']))
        cache={float(c):r for c,r in zip(interior,values)}
        for c,r in cache.items():
            r['replication_contrasts']=[contrast(r['replication_estimates'][a],r['replication_mcse'][a],
                r['replication_estimates'][b],r['replication_mcse'][b],
                family=p['additional_replicate_family'],alpha=p['additional_replicate_alpha']) for a,b in PAIRS]
            r['CDF_range_guard_pass']=bool(0<=r['estimate']<=1)
            r['endpoint_usable']=bool(r['precision_pass'] and r['CDF_range_guard_pass']
                                      and all(t['consistent'] for t in r['replication_contrasts']))
            local_contrasts+=6
        for k,prob in enumerate(PROBABILITIES):
            cuts=frozen['cuts'][j][k]; stats=[]
            for c in cuts:
                if c in (0.,1.):
                    stats.append(dict(threshold=c,estimate=c,mcse=0.,status='exact_continuous_support_endpoint',
                                      structural=True,endpoint_usable=True,replication_contrasts=[]))
                else:stats.append(dict(cache[c],structural=False))
            # Keep every original estimate in endpoint_statistics. A failed
            # range guard supplies a *vacuous band*, never a clipped estimate.
            cdf=[r['estimate'] if 0<=r['estimate']<=1 else .5 for r in stats]
            se=[r['mcse'] if r['endpoint_usable'] else np.inf for r in stats]
            family=p['u95_family'] if (j,k)==(0,3) else p['other19_family']
            result=helper.bracket(cuts,cdf,se,prob,family_tests=family,
                alpha=p['cdf_alpha_per_family'],deterministic_cdf_error=.002 if evidence_ok else None,
                deterministic_status='validated_operational_envelope' if evidence_ok else 'unresolved')
            if common_failures:
                result.update(status='UNRESOLVED_COMMON_NUMERICAL_OR_DETERMINISTIC_GUARD',
                              lower_quantile=0.,upper_quantile=1.,width=1.)
            elif result['width']==1.:
                result['status']='UNRESOLVED_NO_INFORMATIVE_CROSSING'
            result.update(parameter=j,probability=prob,probability_index=k,cuts=cuts,
                          endpoint_statistics=stats,common_failures=common_failures.copy())
            rows.append(result)
    return dict(schema='C08_HORIZONTAL_QUANTILE_BRACKETS_v1',
        identity=frozen['identity'],scientific_model=frozen['scientific_model'],datum=frozen['datum'],
        internal_target=frozen['internal_target'],cut_manifest_content_sha256=frozen['content_sha256'],
        samples_per_replication=lw.shape[1],replications=4,rows=rows,
        common_guards=common,low_guards=low_guards,high_weights=weight,
        high_saturated_weight=satmass,logZ_replicate_contrasts=repZ,logZ_refinement=refineZ,
        replicate_contrasts_executed_unique=local_contrasts,
        additional_replicate_family=p['additional_replicate_family'],
        logZ_refinement_family=p['logZ_refinement_family'],evidence=evidence,
        evidence_precision_required=False,evidence_is_not_a_Bayes_factor_report=True,
        numerical_status='BRACKETS_RECORDED_WITH_FAILURES' if any(r['status'].startswith('UNRESOLVED') for r in rows) else 'BRACKETS_RECORDED_OPERATIONAL',
        inference_accuracy_not_SBC_calibration=True,no_ESS_binomial_interval=True,
        no_unseen_tail_certificate=True,truth_read=False,physical_LL_evaluations=0)


def paired_quantiles(left,right,*,helper):
    """C minus baseline, same datum/parameter/probability; no independence claim."""
    if left['datum']!=right['datum'] or len(left['rows'])!=20 or len(right['rows'])!=20:
        raise ValueError('Paired full20 quantile brackets for one datum required.')
    result=[]
    for a,b in zip(left['rows'],right['rows']):
        if (a['parameter'],a['probability'])!=(b['parameter'],b['probability']):
            raise ValueError('Quantile ordering differs.')
        result.append(dict(parameter=a['parameter'],probability=a['probability'],
                           **helper.paired_difference(a,b)))
    return dict(datum=left['datum'],left_model=left['scientific_model'],
                right_model=right['scientific_model'],direction='left_minus_right',rows=result)


def central_width(quantile05,quantile95):
    """Monotonic quantiles imply a nonnegative width; otherwise interval algebra."""
    if (quantile05['parameter']!=quantile95['parameter'] or quantile05['probability']!=.05
            or quantile95['probability']!=.95):raise ValueError('Matched .05/.95 required.')
    return dict(lower=max(0.,quantile95['lower_quantile']-quantile05['upper_quantile']),
                upper=quantile95['upper_quantile']-quantile05['lower_quantile'],
                unresolved=any(r['status'].startswith('UNRESOLVED') for r in (quantile05,quantile95)))
