"""Opt-in hooks for the immutable C08 driver; no runtime/backend construction.

The caller must bind this additional source/hook in a separate lifecycle
authorization before using it. No driver/runtime v1/v2 file is modified here.
Call freeze_C_low immediately after indexed_production, before standard high
diagnosis. Call diagnose_C_high after the standard compact is written and
before archive/release. A release guard is mandatory, also on resume.
"""
from pathlib import Path
import numpy as np
from inference.campaign_io import read_json,sha256,write_npz_new,write_json_new,canonical_hash
from inference.iid_optimized import TargetIIDContext
from inference.iid_diagnostics import json_safe
from contracts import bound_file,freeze_low,verify_cut_manifest,HIGH_N,PROBABILITIES,validate_cohort
from endpoints import low_guard_metadata,evaluate_high
from run_replay import compact_arrays


def external_metadata(report_path,receipt_path,*,identity,cohort):
    validate_cohort(cohort)
    record=read_json(report_path);receipt=read_json(receipt_path)
    if (receipt.get('schema')!='C08_EXTERNAL_TARGET_RECORD_v1' or receipt.get('identity')!=identity
            or receipt.get('stage')!='production' or receipt.get('internal_record_sha256')!=sha256(report_path)
            or receipt.get('internal_record')!=Path(report_path).name
            or receipt.get('internal_record_unmodified') is not True
            or record.get('identity')!=identity or record.get('uses_truth') is not False
            or record.get('status')!='IID_COMPLETE_AWAITING_DIAGNOSTICS'
            or record.get('datum')!=receipt.get('datum') or record.get('target')!=receipt.get('internal_target')
            or record.get('model')!=receipt.get('internal_kernel')):
        raise RuntimeError('External C08 production receipt differs.')
    variant=receipt.get('response_variant');model=receipt.get('model');datum=receipt['datum']
    if (variant not in ('C_beta','C_full') or model not in (variant+'_CN',variant+'_G')
            or datum not in cohort['representative_ids']+cohort['stress_ids']
            or receipt.get('external_target')!=model+':'+str(datum)
            or record['input_sha256']['data']!=cohort['data_sha256']
            or record['levels']!=[16384,65536]):
        raise RuntimeError('C08 scientific/cohort/levels binding differs.')
    kernel,base=('B_CN',1000) if model.endswith('_CN') else ('B_G',2000)
    if receipt['internal_kernel']!=kernel or record['target']!=base+datum:
        raise RuntimeError('C08 scientific family does not match its internal B kernel.')
    return record,receipt


def read_level(record,raw_root,level):
    checkpoints=sorted([r for r in record['replicates'] if r['level']==level],key=lambda r:r['replicate'])
    if len(checkpoints)!=4 or [r['replicate'] for r in checkpoints]!=list(range(4)):
        raise ValueError('Four independent level replicas required.')
    x=[];w=[]
    for c in checkpoints:
        if Path(c['raw_file']).name!=c['raw_file']:raise ValueError('Raw basename required.')
        path=bound_file(Path(raw_root)/c['raw_file'],c['raw_sha256'])
        with np.load(path,allow_pickle=False) as a:
            if a['target'].item()!=record['target'] or a['replicate'].item()!=c['replicate']:
                raise RuntimeError('Raw target/replicate differs.')
            x.append(a['x_unit'].copy());w.append(a['log_weights'].copy())
    x,w=np.asarray(x),np.asarray(w)
    if x.shape!=(4,level,5) or w.shape!=(4,level):raise ValueError('Wrong raw dimensions.')
    return x,w


def freeze_C_low(report_path,receipt_path,raw_root,output,*,identity,cohort_path,helper):
    """Reads ONLY N16384 x/logw; high files are not opened, nor are truths."""
    cohort=read_json(cohort_path);record,receipt=external_metadata(report_path,receipt_path,identity=identity,cohort=cohort)
    output=Path(output);cuts=output/f'cuts_{record["target"]:06d}.json'
    if cuts.exists():
        old=verify_cut_manifest(read_json(cuts),helper)
        if old['identity']!=identity or old['scientific_model']!=receipt['model']:
            raise RuntimeError('Frozen C08 low cuts collide.')
        bound_file(old['source']['path'],old['source']['sha256']);return cuts
    x,lw=read_level(record,raw_root,16384);ctx=TargetIIDContext(lw)
    low=np.array([ctx.quantiles(x[:,:,j],PROBABILITIES) for j in range(5)])
    numeric=output/f'low_quantiles_{record["target"]:06d}.npz'
    if numeric.exists():
        with np.load(numeric,allow_pickle=False) as old:
            if old.files!=['independent_cuts_unit'] or not np.array_equal(old['independent_cuts_unit'],low):
                raise RuntimeError('Interrupted low freeze differs.')
    else:write_npz_new(numeric,independent_cuts_unit=low)
    frozen=freeze_low(low,helper=helper,identity=identity,model=receipt['model'],datum=record['datum'],
        internal_target=record['target'],source_path=str(numeric.resolve()),source_sha256=sha256(numeric),
        cohort_sha256=sha256(cohort_path))
    frozen['low_raw_sha256']={c['raw_file']:c['raw_sha256'] for c in record['replicates'] if c['level']==16384}
    frozen['external_receipt_sha256']=sha256(receipt_path)
    frozen['content_sha256']=canonical_hash({k:v for k,v in frozen.items() if k!='content_sha256'})
    write_json_new(cuts,frozen);return cuts


def diagnose_C_high(report_path,receipt_path,raw_root,standard_diagnostic_path,cuts_path,output,
                    *,identity,cohort_path,helper,evidence=None,configuration=None):
    """Same endpoint algebra, all9-model denominators; reads no truth/logL field."""
    cohort=read_json(cohort_path);record,receipt=external_metadata(report_path,receipt_path,identity=identity,cohort=cohort)
    frozen=verify_cut_manifest(read_json(cuts_path),helper)
    if (frozen['identity']!=identity or frozen['scientific_model']!=receipt['model']
            or frozen['datum']!=record['datum'] or frozen.get('external_receipt_sha256')!=sha256(receipt_path)):
        raise RuntimeError('C08 low-only freeze differs from production.')
    standard=read_json(standard_diagnostic_path)
    if (standard.get('schema')!='C08_TARGET_IID_DIAGNOSTICS_v1' or standard.get('identity')!=identity
            or standard.get('target')!=record['target'] or standard.get('model')!=receipt['model']
            or standard.get('phase')!='main'):
        raise RuntimeError('Only the main C08 scientific diagnostic belongs to the9-model brackets.')
    dest=Path(output)/f'brackets_{record["target"]:06d}.json'
    if dest.exists():
        old=read_json(dest)
        if (old.get('identity')!=identity or old.get('scientific_model')!=receipt['model']
                or old.get('cut_manifest',{}).get('sha256')!=sha256(cuts_path)
                or old.get('standard_diagnostic',{}).get('sha256')!=sha256(standard_diagnostic_path)
                or old.get('evidence')!=evidence):
            raise RuntimeError('Existing C08 brackets differ from immutable inputs.')
        require_brackets_before_release(dest,identity=identity,target=record['target'],
            raw_sha256={c['raw_file']:c['raw_sha256'] for c in record['replicates']})
        return dest
    npath=bound_file(Path(standard_diagnostic_path).parent/standard['numeric_file'],standard['numeric_sha256'])
    with np.load(npath,allow_pickle=False) as a:
        if not np.array_equal(a['independent_cuts_unit'],read_low_source(frozen)):
            raise RuntimeError('Standard LOW quantiles differ from the prior frozen cuts.')
        low=low_guard_metadata(a,record)
    x,lw=read_level(record,raw_root,HIGH_N)
    result=evaluate_high(x,lw,frozen,low,helper=helper,evidence=evidence,configuration=configuration)
    result.update(scope='C08_HORIZONTAL_QUANTILE_DIAGNOSTIC',all20_retained=True,
        phase='main',response_variant=receipt['response_variant'],target=record['target'],
        cohort_stratum='representative' if record['datum'] in cohort['representative_ids'] else 'stress',
        standard_diagnostic=dict(path=str(Path(standard_diagnostic_path).resolve()),sha256=sha256(standard_diagnostic_path)),
        cut_manifest=dict(path=str(Path(cuts_path).resolve()),sha256=sha256(cuts_path)),
        external_receipt_sha256=sha256(receipt_path),
        raw_sha256={c['raw_file']:c['raw_sha256'] for c in record['replicates']})
    numeric=dest.with_suffix('.npz')
    if numeric.exists():
        with np.load(numeric,allow_pickle=False) as old:
            arrays=compact_arrays(result)
            if set(old.files)!=set(arrays) or any(not np.array_equal(old[k],v,equal_nan=True) for k,v in arrays.items()):
                raise RuntimeError('Interrupted C08 compact differs.')
    else:write_npz_new(numeric,**compact_arrays(result))
    result.update(numeric_file=numeric.name,numeric_sha256=sha256(numeric))
    write_json_new(dest,json_safe(result));return dest


def read_low_source(frozen):
    with np.load(bound_file(frozen['source']['path'],frozen['source']['sha256']),allow_pickle=False) as a:
        return a['independent_cuts_unit'].copy()


def require_brackets_before_release(brackets_path,*,identity,target,raw_sha256):
    """Additional release prerequisite; does not erase the standard C08 flags."""
    row=read_json(brackets_path)
    if (row.get('identity')!=identity or row.get('target')!=target or row.get('raw_sha256')!=raw_sha256
            or row.get('all20_retained') is not True or row.get('scope')!='C08_HORIZONTAL_QUANTILE_DIAGNOSTIC'
            or len(row.get('rows',[]))!=20):raise RuntimeError('Full bracket record required before C raw release.')
    bound_file(Path(brackets_path).parent/row['numeric_file'],row['numeric_sha256'])
    cut=row['cut_manifest'];bound_file(cut['path'],cut['sha256'])
    return dict(path=str(Path(brackets_path).resolve()),sha256=sha256(brackets_path),
                numerical_status=row['numerical_status'],all_failures_retained=True)
