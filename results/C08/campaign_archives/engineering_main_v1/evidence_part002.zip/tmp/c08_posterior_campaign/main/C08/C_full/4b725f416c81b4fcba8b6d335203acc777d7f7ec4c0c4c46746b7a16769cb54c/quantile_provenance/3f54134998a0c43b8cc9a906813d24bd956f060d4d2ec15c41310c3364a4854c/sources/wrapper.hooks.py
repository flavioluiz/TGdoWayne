"""External C08 main hooks; underlying v2 driver and C07 libraries stay intact."""
from pathlib import Path
import json
from inference.campaign_io import read_json,sha256,write_json_new,atomic_new
from c08_adapter import (freeze_C_low,diagnose_C_high,require_brackets_before_release)
from contracts import bound_file,protocol
from memory_phase import inspect_resident


class QuantileHooks:
    def __init__(self,base_operations,*,runtime,output,context,helper,hook_plan,
                 verify_closure,evidence_index=None):
        self.base=base_operations;self.runtime=runtime;self.output=Path(output).resolve()
        self.context=context;self.helper=helper;self.plan=hook_plan
        self.verify_closure=verify_closure;self.evidence_index=evidence_index or {}
        self.qroot=self.output/'quantiles';self.identity=hook_plan['hook_identity']

    def operations(self):
        return dict(train=self.train,produce=self.produce,diagnose=self.diagnose,
                    archive=self.archive,release=self.release)

    def before(self,runtime):
        if runtime is not self.runtime or runtime.identity!=self.plan['runtime_identity']:
            raise RuntimeError('Quantile hooks received another runtime.')
        if runtime.settings['phase']!='main':raise RuntimeError('These hooks apply only to the main32-cohort C campaign.')
        self.verify_closure()

    def train(self,runtime,*args,**kwargs):
        self.before(runtime)
        # No truth access and no altered fit/proposal/seed logic.
        return self.base['train'](runtime,*args,**kwargs)

    def paths(self,target):
        return dict(cuts=self.qroot/'low'/f'cuts_{target:06d}.json',
                    brackets=self.qroot/'diagnostics'/f'brackets_{target:06d}.json',
                    archive=self.output/'production'/f'quantile_archive_target_{target:06d}.json',
                    release=self.output/'production'/f'quantile_release_prerequisite_target_{target:06d}.json')

    def produce(self,runtime,target,training,production,raw,*,resume=False):
        self.before(runtime)
        value=self.base['produce'](runtime,target,training,production,raw,resume=resume)
        p=self.paths(target)
        if not p['cuts'].exists():
            self.memory_receipt(target,'low_freeze')
        # For completed/retired targets this verifies the saved LOW source and
        # returns without opening a missing raw. Never derive cuts from HIGH.
        freeze_C_low(Path(production)/f'target_{target:06d}.json',
            Path(production)/f'c08_target_{target:06d}.json',raw,self.qroot/'low',
            identity=runtime.identity,cohort_path=self.context['cohort_index'],helper=self.helper)
        self.verify_closure();return value

    def memory_receipt(self,target,stage):
        result=inspect_resident(self.runtime)
        path=self.qroot/'memory'/f'target_{target:06d}_{stage}.json'
        row=dict(result,schema='C08_QUANTILE_LIVE_OWNERSHIP_CHECK_v1',arithmetic_schema=result['schema'],
                 hook_identity=self.identity,runtime_identity=self.runtime.identity,target=target,stage=stage)
        if path.exists():
            if read_json(path)!=row:raise RuntimeError('Repeated live memory accounting differs.')
        else:write_json_new(path,row)
        return path

    def evidence(self,target):
        route=next(r for r in self.runtime.target_index if r['internal_target']==target)
        key=route['model']+':'+str(route['datum']);item=self.evidence_index.get(key)
        return None if item is None else read_json(bound_file(item['path'],item['sha256']))

    def diagnose(self,runtime,report_path,raw,truth_data,diagnostic_protocol,diagnostics,*,
                 truth_loglikelihood_path,resume=False):
        self.before(runtime);record=read_json(report_path);target=record['target'];p=self.paths(target)
        # This check precedes the standard diagnostic, which does read HIGH.
        if not p['cuts'].exists():raise RuntimeError('LOW manifest must exist before the standard HIGH diagnostic.')
        frozen=read_json(p['cuts']);bound_file(frozen['source']['path'],frozen['source']['sha256'])
        if frozen.get('uses_high') is not False or frozen.get('uses_truth') is not False:
            raise RuntimeError('LOW selection contract violated.')
        value=self.base['diagnose'](runtime,report_path,raw,truth_data,diagnostic_protocol,diagnostics,
            truth_loglikelihood_path=truth_loglikelihood_path,resume=resume)
        if not p['brackets'].exists():self.memory_receipt(target,'endpoints')
        # The base diagnostic call returned: its transient raw/CDF arrays are
        # no longer live. Returned metadata contain no posterior arrays.
        diagnose_C_high(report_path,Path(report_path).parent/f'c08_target_{target:06d}.json',raw,
            Path(diagnostics)/f'diagnostic_target_{target:06d}.json',p['cuts'],self.qroot/'diagnostics',
            identity=runtime.identity,cohort_path=self.context['cohort_index'],helper=self.helper,
            evidence=self.evidence(target),configuration=protocol())
        self.verify_closure();return value

    def _archive_quantiles(self,target):
        p=self.paths(target);prod=self.output/'production'/f'target_{target:06d}.json';producer=read_json(prod)
        raw={r['raw_file']:r['raw_sha256'] for r in producer['replicates']}
        proof=require_brackets_before_release(p['brackets'],identity=self.runtime.identity,target=target,raw_sha256=raw)
        bracket=read_json(p['brackets']);cut=read_json(p['cuts'])
        if (bracket['scientific_model']!=next(r['model'] for r in self.runtime.target_index if r['internal_target']==target)
                or bracket['cut_manifest']['sha256']!=sha256(p['cuts'])):
            raise RuntimeError('Bracket scientific identity or LOW binding differs.')
        src=[('brackets_json',p['brackets']),('brackets_numeric',p['brackets'].parent/bracket['numeric_file']),
             ('cuts_json',p['cuts']),('low_quantiles',Path(cut['source']['path']))]
        for stage in ('low_freeze','endpoints'):
            src.append(('memory_'+stage,self.qroot/'memory'/f'target_{target:06d}_{stage}.json'))
        artifacts=[]
        for role,source in src:
            if not source.is_file():raise RuntimeError('Missing quantile preservation source: '+role)
            digest=sha256(source);dest=self.qroot/'archive'/f'target_{target:06d}'/(role+source.suffix)
            if dest.exists():bound_file(dest,digest)
            else:atomic_new(dest,lambda path,source=source:path.write_bytes(source.read_bytes()))
            artifacts.append(dict(role=role,file=str(dest.relative_to(self.output)),sha256=digest,bytes=dest.stat().st_size))
        status=bracket['numerical_status'];rows=bracket['rows']
        unresolved=sum(r['status'].startswith('UNRESOLVED') for r in rows)
        expected_status='BRACKETS_RECORDED_WITH_FAILURES' if unresolved else 'BRACKETS_RECORDED_OPERATIONAL'
        if status!=expected_status:raise RuntimeError('Quantile status disagrees with all20 retained rows.')
        receipt=dict(schema='C08_MAIN_QUANTILE_ARCHIVE_v1',status='QUANTILE_PRODUCTS_PRESERVED',
            hook_identity=self.identity,runtime_identity=self.runtime.identity,target=target,
            scientific_model=bracket['scientific_model'],datum=bracket['datum'],
            producer_sha256=sha256(prod),raw_sha256=raw,artifacts=artifacts,
            quantile_numerical_status=status,unresolved_quantiles=unresolved,all20_retained=True,
            no_SBC_or_uniform_CDF_approval=True)
        if p['archive'].exists():
            if read_json(p['archive'])!=receipt:raise RuntimeError('Quantile archive differs.')
        else:write_json_new(p['archive'],receipt)
        return receipt

    def archive(self,runtime,target,training,production,diagnostic_path,*,resume=False):
        self.before(runtime)
        # A complete independent quantile archive exists before core archive.
        q=self._archive_quantiles(target)
        result=self.base['archive'](runtime,target,training,production,diagnostic_path,resume=resume)
        core=Path(production)/f'archive_receipt_target_{target:06d}.json';p=self.paths(target)
        joint=dict(schema='C08_MAIN_QUANTILE_RELEASE_PREREQUISITE_v1',status='BOTH_ARCHIVES_VERIFIED',
            hook_identity=self.identity,runtime_identity=runtime.identity,target=target,
            core_archive_sha256=sha256(core),quantile_archive_sha256=sha256(p['archive']),
            raw_sha256=q['raw_sha256'],original_numerical_flags=result['numerical_flags'],
            original_numerical_status=result['numerical_status'],quantile_numerical_status=q['quantile_numerical_status'],
            all_failures_retained=True,no_scientific_approval=True)
        if p['release'].exists():
            if read_json(p['release'])!=joint:raise RuntimeError('Joint raw-retirement prerequisite differs.')
        else:write_json_new(p['release'],joint)
        return result

    def verify_joint(self,target):
        p=self.paths(target);joint=read_json(p['release']);q=read_json(p['archive'])
        corepath=self.output/'production'/f'archive_receipt_target_{target:06d}.json';core=read_json(corepath)
        producer_path=self.output/'production'/f'target_{target:06d}.json';producer=read_json(producer_path)
        required={r['raw_file']:r['raw_sha256'] for r in producer['replicates']}
        if (joint.get('schema')!='C08_MAIN_QUANTILE_RELEASE_PREREQUISITE_v1'
                or joint.get('status')!='BOTH_ARCHIVES_VERIFIED' or joint.get('hook_identity')!=self.identity
                or joint.get('runtime_identity')!=self.runtime.identity or joint.get('target')!=target
                or joint.get('core_archive_sha256')!=sha256(corepath)
                or joint.get('quantile_archive_sha256')!=sha256(p['archive'])
                or joint.get('raw_sha256')!=required or joint.get('all_failures_retained') is not True
                or joint.get('original_numerical_flags')!=core['numerical_flags']
                or joint.get('original_numerical_status')!=core['numerical_status']
                or q.get('producer_sha256')!=sha256(producer_path) or q.get('raw_sha256')!=required
                or q.get('hook_identity')!=self.identity or q.get('target')!=target
                or q.get('all20_retained') is not True):
            raise RuntimeError('Quantile/core joint prerequisite changed.')
        roles={}
        for a in q['artifacts']:
            rel=Path(a['file']);path=(self.output/rel).resolve()
            if rel.is_absolute() or self.output not in path.parents or a['role'] in roles:
                raise RuntimeError('Quantile archive path/role invalid.')
            bound_file(path,a['sha256']);roles[a['role']]=path
        if set(roles)!={'brackets_json','brackets_numeric','cuts_json','low_quantiles','memory_low_freeze','memory_endpoints'}:
            raise RuntimeError('Full LOW/bracket/ownership archive required.')
        bracket=read_json(roles['brackets_json'])
        statuses=[r['status'].startswith('UNRESOLVED') for r in bracket['rows']]
        expected='BRACKETS_RECORDED_WITH_FAILURES' if any(statuses) else 'BRACKETS_RECORDED_OPERATIONAL'
        if (len(statuses)!=20 or q['unresolved_quantiles']!=sum(statuses)
                or q['quantile_numerical_status']!=expected or joint['quantile_numerical_status']!=expected
                or bracket['numeric_sha256']!=sha256(roles['brackets_numeric'])
                or bracket['cut_manifest']['sha256']!=sha256(roles['cuts_json'])):
            raise RuntimeError('Retained quantile flags/hashes differ.')
        # Retain working compact sources as well: resume hooks can return before
        # reading raw even after release intent has removed some/all raw files.
        require_brackets_before_release(p['brackets'],identity=self.runtime.identity,target=target,raw_sha256=required)
        bound_file(p['brackets'],sha256(roles['brackets_json']));bound_file(p['cuts'],sha256(roles['cuts_json']))
        return joint

    def release(self,runtime,target,production,raw,core_receipt,*,resume=False):
        self.before(runtime);self.verify_joint(target)
        # This wrapper is also passed to v2 finish_interrupted_release, so a
        # partially deleted raw cannot skip the extra preservation prerequisite.
        return self.base['release'](runtime,target,production,raw,core_receipt,resume=resume)

    def audit_completed(self,base):
        records=[]
        for path in sorted((self.output/'state').glob('target_*.json')):
            row=read_json(path);target=row['target']
            if target not in self.plan['target_ids']:raise RuntimeError('Unplanned completed target.')
            joint=self.verify_joint(target)
            records.append(dict(target=target,state_sha256=sha256(path),
                joint_sha256=sha256(self.paths(target)['release']),
                quantile_archive_sha256=joint['quantile_archive_sha256'],
                quantile_numerical_status=joint['quantile_numerical_status']))
        return records
