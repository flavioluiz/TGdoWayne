"""Native-resident phase accounting; no allocation of banks or host-RAM query."""
from pathlib import Path
import math
import numpy as np
from inference.native_likelihood import NativeLikelihood
from inference.likelihood_threads import ThreadedLikelihood

ENDPOINT_WORKSPACE=256*1024**2
BACKEND_ALLOWANCE=32*1024**2
CAP=4*1024**3
NATIVE_SCALARS={'nd','K','P','D','I','dt','library','function'}
RUNTIME_ARRAY_ROOTS={'bounds','targets','exp','data'}
RUNTIME_FIELDS=set('response_variant scientific_models paths cfg settings validation_config manifest gates exp bounds n table_metadata observation_metadata observation_geometry_metadata native_library native_build_record backend_factory input_hashes threads training_threads thread_plan phase source_paths source_hashes targets target_index target_identity identity table reference data likelihood engine likelihood_evaluations _contract_sha256 _domain_paths tested_config domain_compatibility tested_domain runtime_domain tested_observation_metadata tested_geometry_metadata domain_report N K P D stored_K'.split())


def native_layout(N,K,P,D,n):
    vals=(N,K,P,D,n)
    if any(isinstance(v,(bool,np.bool_)) or not isinstance(v,(int,np.integer)) or v<1 for v in vals) or N<2:
        raise ValueError('Positive integer dimensions and N>=2 required.')
    I=N-1
    return dict(bounds=((5,2),'float64'),frequencies=((K,),'float64'),scale=((K,),'float64'),
        nodes=((N,),'float64'),coordinate=((N,),'float64'),
        gamma=((I,4,K,P,P),'complex128'),means=((I,K,6,D),'float64'),
        covpacked=((I,K,21,D*(D+1)//2),'float64'),red2=((P,),'float64'),
        white2=((P,),'float64'),frequency_weights=((K,),'float64'),
        q=((n,K,P),'complex128'),y=((2,n,K,D),'float64'),z=((2,n,D),'float64'))


def phase_arithmetic(N,K=4,P=12,D=10,n=500,targets=64):
    fields={key:math.prod(shape)*np.dtype(dtype).itemsize for key,(shape,dtype) in native_layout(N,K,P,D,n).items()}
    observations=n*K*P*16+2*n*K*D*8
    experiment=P*3*8+P*8*3+K*8*3+D*P*P*16
    runtime_arrays=observations+experiment+5*2*8+targets*8
    resident=sum(fields.values())+runtime_arrays
    total=resident+ENDPOINT_WORKSPACE+BACKEND_ALLOWANCE
    return dict(schema='C08_NATIVE_ENDPOINT_PHASE_ARITHMETIC_v1',dimensions=dict(N=N,K=K,P=P,D=D,n=n,targets=targets),
        native_fields_bytes=fields,native_owned_bytes=sum(fields.values()),runtime_arrays_bytes=runtime_arrays,
        runtime_observations_bytes=observations,experiment_arrays_bytes=experiment,
        retained_numeric_bytes=resident,endpoint_workspace_bytes=ENDPOINT_WORKSPACE,
        backend_allowance_bytes=BACKEND_ALLOWANCE,total_phase_estimated_numeric_bytes=total,
        maximum_numeric_bytes=CAP,within_cap=total<=CAP,
        excludes_freed_reference_table_and_construction_temporaries=True,RSS_guaranteed=False,
        host_RAM_queried=False,bank_constructed=False,physical_LL=0)


def _metadata_without_arrays(value):
    if isinstance(value,np.ndarray):raise RuntimeError('Unexpected ndarray retained outside declared phase owners.')
    if isinstance(value,dict):
        for v in value.values():_metadata_without_arrays(v)
    elif isinstance(value,(list,tuple)):
        for v in value:_metadata_without_arrays(v)
    elif not isinstance(value,(str,int,float,bool,type(None),Path,np.generic)):
        raise RuntimeError('Unexpected object retained in runtime metadata: '+type(value).__name__)


def inspect_resident(runtime):
    """Fail closed before LOW/high readers; scans metadata, not ndarray values.

    Source SHA closure separately freezes the constructor/call implementations.
    ThreadedLikelihood awaits all futures before returning, so these hooks run
    after its production call has no outstanding work item.
    """
    if runtime.reference is not None or runtime.table is not None:
        raise RuntimeError('Reference model/table retained after native build.')
    if type(runtime.engine) is not ThreadedLikelihood or type(runtime.engine.likelihood) is not NativeLikelihood:
        raise RuntimeError('The source-bound owned native backend is required for this phase proof.')
    if set(vars(runtime.engine))!={'likelihood','maximum_workers','workers','pool'}:
        raise RuntimeError('Unexpected retained threaded-backend field.')
    if (getattr(runtime.likelihood,'__self__',None)is not runtime
            or getattr(runtime.likelihood,'__func__',None)is not getattr(runtime.counted_likelihood,'__func__',None)):
        raise RuntimeError('Unexpected likelihood closure retained on runtime.')
    native=runtime.engine.likelihood
    layout=native_layout(runtime.N,runtime.K,runtime.P,runtime.D,runtime.n)
    if set(vars(native))!=set(layout)|NATIVE_SCALARS:
        raise RuntimeError('Unexpected/missing native field; ownership accounting invalid.')
    if (native.I!=runtime.N-1 or (native.K,native.P,native.D,native.nd)!=(runtime.K,runtime.P,runtime.D,runtime.n)):
        raise RuntimeError('Native/runtime dimensions differ.')
    actual={};addresses=[]
    for name,(shape,dtype) in layout.items():
        a=getattr(native,name)
        if (type(a)is not np.ndarray or a.shape!=shape or a.dtype!=np.dtype(dtype)
                or not a.flags.owndata or a.base is not None or a.flags.writeable
                or not a.flags.c_contiguous or not a.flags.aligned):
            raise RuntimeError('Native buffer must be a private aligned readonly copy: '+name)
        actual[name]=a.nbytes;addresses.append(a.__array_interface__['data'][0])
    if len(set(addresses))!=len(addresses):raise RuntimeError('Native owned buffers unexpectedly alias.')
    unknown=set(vars(runtime))-RUNTIME_FIELDS
    if unknown:raise RuntimeError('Unaccounted runtime field(s): '+','.join(sorted(unknown)))
    for name,value in vars(runtime).items():
        if name in RUNTIME_ARRAY_ROOTS or name in {'table','reference','engine','likelihood'}:continue
        _metadata_without_arrays(value)
    if set(runtime.data)!={'q','x_physical','x_gaussian'}:
        raise RuntimeError('Unexpected observation cache; resident accounting invalid.')
    expected_exp={'points','distance_ly','sigma','red','f','scale','H','weights'}
    if {k for k,v in runtime.exp.items() if isinstance(v,np.ndarray)}!=expected_exp:
        raise RuntimeError('Unexpected/missing experiment arrays.')
    runtime_bytes=runtime.bounds.nbytes+runtime.targets.nbytes
    for group in (runtime.data,runtime.exp):
        for value in group.values():
            if isinstance(value,np.ndarray):runtime_bytes+=value.nbytes
            else:_metadata_without_arrays(value)
    estimate=phase_arithmetic(runtime.N,runtime.K,runtime.P,runtime.D,runtime.n,len(runtime.targets))
    if actual!=estimate['native_fields_bytes'] or runtime_bytes!=estimate['runtime_arrays_bytes']:
        raise RuntimeError('Actual resident array sizes differ from the frozen arithmetic.')
    cap=runtime.settings['budget']['maximum_numeric_bytes']
    if type(cap)is not int or cap!=CAP or not estimate['within_cap']:
        raise RuntimeError('Native resident arrays plus endpoint reserves exceed or change cap4GiB.')
    return dict(estimate,bank_constructed=True,bank_constructed_by_this_inspection=False,
                verified_live_metadata_only=True,native_readonly_owned=True,
                reference_and_table_released=True,no_native_work_launched=True)
