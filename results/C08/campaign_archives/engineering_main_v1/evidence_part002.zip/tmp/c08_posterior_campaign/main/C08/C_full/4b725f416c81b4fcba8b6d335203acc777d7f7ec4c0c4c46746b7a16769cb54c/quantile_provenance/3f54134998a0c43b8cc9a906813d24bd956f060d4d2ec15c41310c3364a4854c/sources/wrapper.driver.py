#!/usr/bin/env python3
"""Opt-in external composition around the immutable C08 v2 driver.

Default CLI only constructs the metadata/preflight runtime. Execution needs
the existing runtime/base-driver authorizations AND the additional hook SHA
authorization. It never patches a module global or existing library file.
"""
from pathlib import Path
import argparse,importlib,importlib.util,json,os,sys

BASE_DRIVER_SHA='a56da144b4c36e0e6b6eed693bebdc6766e689767dd46cee1dfdb6eb8fd85080'
QUANTILE_PACKAGE_SHA='eedec44e07315ee5fc593961d367ef802460b620949982862acc2e987fb10abc'
HOOK_STAGES=['freeze_low_after_production_before_diagnosis','high_endpoint_statistics_after_diagnosis',
             'quantile_archive_before_core_archive','joint_prerequisite_before_all_raw_release',
             'verify_quantiles_for_existing_completed_targets']


def load_components(repository,base_driver_source,quantile_package):
    root=Path(repository).resolve();prior=Path(quantile_package).resolve();base_path=Path(base_driver_source).resolve()
    sys.path[:0]=[str(root/'src'),str(root/'scripts')]
    from inference.campaign_io import read_json,sha256
    if sha256(base_path)!=BASE_DRIVER_SHA or sha256(prior/'package_manifest.json')!=QUANTILE_PACKAGE_SHA:
        raise RuntimeError('Reviewed v2 driver or frozen quantile package changed.')
    entries={r['file']:r for r in read_json(prior/'package_manifest.json')['files']}
    for name in ['contracts','endpoints','c08_adapter','run_replay']:
        path=prior/(name+'.py')
        if sha256(path)!=entries[name+'.py']['sha256']:raise RuntimeError('Frozen endpoint source changed.')
        if name in sys.modules and Path(sys.modules[name].__file__).resolve()!=path:
            raise RuntimeError('Conflicting already-imported endpoint module: '+name)
    sys.path.insert(0,str(prior))
    spec=importlib.util.spec_from_file_location('c08_reviewed_base_driver_v2',base_path)
    base=importlib.util.module_from_spec(spec);sys.modules[spec.name]=base;spec.loader.exec_module(base)
    return base


def source_paths(runtime,base,quantile_package,helper_path):
    root=Path(__file__).resolve().parent;prior=Path(quantile_package).resolve()
    result={f'wrapper.{name}':root/(name+'.py') for name in ['driver','hooks','memory_phase']}
    result.update({f'quantile.{name}':prior/(name+'.py') for name in ['contracts','endpoints','c08_adapter','run_replay']})
    result['quantile.package_manifest']=prior/'package_manifest.json';result['quantile.frozen_v4_helper']=Path(helper_path)
    result.update({'base.'+k:Path(v) for k,v in base.extra_sources().items()})
    result.update({'runtime.'+k:Path(v) for k,v in runtime.source_paths.items()})
    # Bind the package initializer even if a historical runtime omitted it.
    result['inference.__init__']=Path(importlib.import_module('inference').__file__)
    return {k:v.resolve() for k,v in result.items()}


def plan_hooks(runtime,base,base_plan,*,quantile_package,helper_path,evidence_index_path=None):
    from inference.campaign_io import sha256,canonical_hash,read_json
    from contracts import protocol,load_helper,validate_cohort
    from memory_phase import phase_arithmetic
    if (base_plan['phase']!='main' or runtime.settings['phase']!='main'
            or runtime.native_library is None or len(base_plan['all_target_ids'])!=64
            or base_plan['population_numerical_family']!=128
            or runtime.settings['production']['levels']!=[16384,65536]
            or runtime.settings['production']['replicates']!=4):
        raise ValueError('Only the frozen native C08 main64/variant and global128 numerical family are accepted.')
    load_helper(helper_path)
    files=source_paths(runtime,base,quantile_package,helper_path);hashes={k:sha256(p) for k,p in files.items()}
    memory=phase_arithmetic(runtime.N,runtime.K,runtime.P,runtime.D,runtime.n,len(runtime.targets))
    if not memory['within_cap']:raise RuntimeError('Declared native resident phase exceeds cap4GiB before execution.')
    evidence_sha=None if evidence_index_path is None else sha256(evidence_index_path)
    data=dict(schema='C08_MAIN_QUANTILE_HOOK_PLAN_v1',scope='EXTERNAL_MAIN_QUANTILE_HOOKS_NO_NEW_LL',
        base_driver_identity=base_plan['driver_identity'],runtime_identity=runtime.identity,
        target_identity=runtime.target_identity,response_variant=runtime.response_variant,phase='main',
        output=base_plan['output'],resource_lock_root=base_plan['resource_lock_root'],
        target_ids=base_plan['all_target_ids'],target_index=base_plan['target_index'],
        base_source_sha256=sha256(Path(base.__file__)),source_sha256=hashes,
        source_paths={k:str(p) for k,p in files.items()},
        cohort_index_sha256=base_plan['extra_input_sha256']['cohort_index'],
        endpoint_protocol=protocol(),endpoint_protocol_sha256=canonical_hash(protocol()),
        evidence_index_sha256=evidence_sha,evidence_mode='absent_means_preserve_all_stats_and_UNRESOLVED',
        stages=HOOK_STAGES,maximum_additional_likelihood_values=0,
        memory_phase=memory,base_construction_preflight_not_replaced=True,
        main_likelihood_budget_unchanged=runtime.settings['budget'],
        no_optional_replay_or_refinement=True,no_uniform_CDF_error_claim=True)
    data['hook_identity']=canonical_hash(data)
    return data


def verify_plan(runtime,base,base_plan,plan,*,quantile_package,helper_path,evidence_index_path=None):
    expected=plan_hooks(runtime,base,base_plan,quantile_package=quantile_package,
                        helper_path=helper_path,evidence_index_path=evidence_index_path)
    if plan!=expected:raise RuntimeError('Hook plan/source/evidence/phase identity changed.')


def authorization(path,plan):
    from inference.campaign_io import read_json,sha256
    if path is None or not Path(path).is_file():raise RuntimeError('Additional main quantile-hook authorization is missing.')
    row=read_json(path)
    expected=dict(schema='C08_MAIN_QUANTILE_HOOK_AUTHORIZATION_v1',execution_allowed=True,
        scope='EXTERNAL_MAIN_QUANTILE_HOOKS_NO_NEW_LL',hook_identity=plan['hook_identity'],
        base_driver_identity=plan['base_driver_identity'],runtime_identity=plan['runtime_identity'],
        response_variant=plan['response_variant'],phase='main',source_sha256=plan['source_sha256'],
        endpoint_protocol_sha256=plan['endpoint_protocol_sha256'],stages=HOOK_STAGES,
        maximum_additional_likelihood_values=0,output=plan['output'],resource_lock_root=plan['resource_lock_root'],
        no_uniform_CDF_error_claim=True)
    if (any(row.get(k)!=v for k,v in expected.items()) or row.get('execution_allowed')is not True
            or row.get('no_uniform_CDF_error_claim')is not True
            or any(not isinstance(row.get(k),str) or not row[k].strip() for k in ['approved_by','decision_id'])):
        raise RuntimeError('Hook authorization does not bind the exact sources/lifecycle.')
    return sha256(path)


def snapshot(plan,authorization_path,output):
    from inference.campaign_io import write_json_new,read_json,sha256,atomic_new
    root=Path(output)/'quantile_provenance'/plan['hook_identity']
    for name,source in plan['source_paths'].items():
        source=Path(source);digest=plan['source_sha256'][name];dest=root/'sources'/(name+source.suffix)
        if sha256(source)!=digest:raise RuntimeError('Source changed before hook snapshot.')
        if dest.exists():
            if sha256(dest)!=digest:raise RuntimeError('Hook source snapshot collision.')
        else:atomic_new(dest,lambda path,source=source:path.write_bytes(source.read_bytes()))
    for name,row in [('plan',plan),('authorization',read_json(authorization_path))]:
        dest=root/(name+'.json')
        if dest.exists():
            if read_json(dest)!=row:raise RuntimeError('Hook provenance metadata changed.')
        else:write_json_new(dest,row)
    return root


def run_main(runtime,base,base_plan,hook_plan,protocol_path,truth_data_path,truth_logl_path,*,
             context,quantile_package,helper_path,hook_authorization_path,evidence_index_path=None,resume=False):
    from inference.campaign_io import read_json,sha256,write_json_new
    from contracts import load_helper
    from hooks import QuantileHooks
    output=Path(base_plan['output']);helper=load_helper(helper_path)
    def unchanged():
        verify_plan(runtime,base,base_plan,hook_plan,quantile_package=quantile_package,helper_path=helper_path,
                    evidence_index_path=evidence_index_path)
        authorization(hook_authorization_path,hook_plan)
    unchanged()
    if base_plan['execution_ready']is not True:raise RuntimeError('Existing base-driver/runtime gates remain pending.')
    if any(os.environ.get(k)!='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']):
        raise RuntimeError('Explicit single-thread BLAS/OpenMP required before the base runtime builds.')
    evidence={} if evidence_index_path is None else read_json(evidence_index_path)
    hooks=QuantileHooks(base.actual_operations(context),runtime=runtime,output=output,context=context,
        helper=helper,hook_plan=hook_plan,verify_closure=unchanged,evidence_index=evidence)
    # Same shared resource lock as the reviewed v2 driver, held before bank
    # construction. Calling its locked body avoids taking the same lock twice.
    with base.campaign_lock(Path(base_plan['resource_lock_root'])):
        unchanged();base.verify_frozen_plan(runtime,base_plan,protocol_path,truth_data_path,truth_logl_path,context,output)
        snapshot(hook_plan,hook_authorization_path,output)
        hooks.audit_completed(base)
        result=base._run_locked_c08_campaign(runtime,base_plan,protocol_path,truth_data_path,truth_logl_path,
            output,context=context,resume=resume,operations=hooks.operations())
        unchanged();records=hooks.audit_completed(base)
        if sorted(r['target'] for r in records)!=sorted(hook_plan['target_ids']):
            raise RuntimeError('Quantile wrapper completion requires every planned target, including unresolved.')
        complete=dict(schema='C08_MAIN_QUANTILE_WRAPPER_COMPLETE_v1',status='ALL64_STANDARD_AND_QUANTILE_ARCHIVES_PRESERVED',
            hook_identity=hook_plan['hook_identity'],base_driver_identity=base_plan['driver_identity'],
            response_variant=runtime.response_variant,phase='main',targets=hook_plan['target_ids'],records=records,
            base_complete_sha256=sha256(output/'campaign_complete.json'),
            all_quantile_stats_and_failures_retained=True,additional_likelihood_values=0,
            no_uniform_or_scientific_approval=True)
        dest=output/'quantile_wrapper_complete.json'
        if dest.exists():
            if read_json(dest)!=complete:raise RuntimeError('Wrapper final inventory differs.')
        else:write_json_new(dest,complete)
        return complete


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ['repository','base_driver_source','quantile_package','helper','launch_spec','hook_plan_file']:
        parser.add_argument('--'+name.replace('_','-'),type=Path,required=True)
    parser.add_argument('--hook-authorization',type=Path);parser.add_argument('--evidence-index',type=Path)
    parser.add_argument('--execute',action='store_true');parser.add_argument('--resume',action='store_true')
    args=parser.parse_args();base=load_components(args.repository,args.base_driver_source,args.quantile_package)
    from inference.campaign_io import read_json,write_json_new
    spec=read_json(args.launch_spec)
    if set(spec)!={'runtime_source','runtime_args','runtime_kwargs','driver'}:raise ValueError('Explicit runtime and reviewed-driver argument groups required.')
    if len(spec['runtime_args'])!=7 or any(k in spec['runtime_kwargs'] for k in ['build','backend_factory']):
        raise ValueError('Seven C08 runtime positional paths; no implicit build/backend replacement.')
    cls=base.runtime_factory(spec['runtime_source']);runtime=cls(*spec['runtime_args'],**spec['runtime_kwargs'],build=False)
    d=spec['driver']
    if set(d)!={'protocol_path','truth_data_path','truth_logl_path','output_base','context','driver_authorization_path'}:
        raise ValueError('Exact reviewed driver input mapping required.')
    try:
        bp=base.campaign_plan(runtime,d['protocol_path'],d['truth_data_path'],d['truth_logl_path'],d['output_base'],
            context=d['context'],driver_authorization_path=d['driver_authorization_path'])
        hp=plan_hooks(runtime,base,bp,quantile_package=args.quantile_package,helper_path=args.helper,
                      evidence_index_path=args.evidence_index)
        if args.hook_plan_file.exists():
            if not args.resume or read_json(args.hook_plan_file)!=hp:raise RuntimeError('Immutable hook plan exists; identical --resume required.')
        else:write_json_new(args.hook_plan_file,hp)
        print(json.dumps(dict(status='PROSPECTIVE_HOOK_PLAN',hook_identity=hp['hook_identity'],
            base_execution_ready=bp['execution_ready'],memory=hp['memory_phase'],no_bank_constructed=True)),flush=True)
        if args.execute:
            result=run_main(runtime,base,bp,hp,d['protocol_path'],d['truth_data_path'],d['truth_logl_path'],
                context=d['context'],quantile_package=args.quantile_package,helper_path=args.helper,
                hook_authorization_path=args.hook_authorization,evidence_index_path=args.evidence_index,resume=args.resume)
            print(json.dumps(result),flush=True)
    finally:runtime.close()

if __name__=='__main__':main()
