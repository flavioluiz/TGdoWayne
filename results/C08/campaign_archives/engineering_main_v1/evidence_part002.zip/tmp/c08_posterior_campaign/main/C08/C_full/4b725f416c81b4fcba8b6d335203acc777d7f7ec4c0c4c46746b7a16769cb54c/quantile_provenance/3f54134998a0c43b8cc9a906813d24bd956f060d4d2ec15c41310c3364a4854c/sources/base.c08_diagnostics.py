"""C08 diagnostic-only truth reader; reuses unchanged C07 SNIS algebra."""
from pathlib import Path
from time import perf_counter
import numpy as np
from inference.campaign_io import read_json, sha256, write_json_new, write_npz_new
from inference.campaign_diagnostic_io import load_target_levels
from inference.campaign_diagnostics import numerical_statistics
from inference.iid_diagnostics import json_safe
from c08_contract import target_rows, validate_index, diagnostic_protocol

SCHEMA = 'C08_TARGET_IID_DIAGNOSTICS_v1'
TRUTH_SCHEMA = 'C08_DIRECT_TRUTH_LOGL_v1'


def external_production_record(runtime, report_path):
    """Validate an existing external C08 receipt before loading any raw array."""
    report_path = Path(report_path); record = read_json(report_path)
    rows = [r for r in runtime.target_index if r['internal_target'] == record.get('target')]
    if len(rows) != 1: raise ValueError('Unplanned/ambiguous C08 target.')
    row = rows[0]
    receipt_path = report_path.parent/f'c08_target_{record["target"]:06d}.json'
    receipt = read_json(receipt_path)
    expected = dict(schema='C08_EXTERNAL_TARGET_RECORD_v1', identity=runtime.identity,
                    target_identity=runtime.target_identity, response_variant=runtime.response_variant,
                    stage='production', **row, internal_record=report_path.name,
                    internal_record_sha256=sha256(report_path), internal_record_unmodified=True)
    if (receipt != expected or record.get('identity') != runtime.identity
            or record.get('status') != 'IID_COMPLETE_AWAITING_DIAGNOSTICS'
            or record.get('model') != row['internal_kernel'] or record.get('datum') != row['datum']
            or record.get('input_sha256') != runtime.input_hashes):
        raise RuntimeError('External scientific/internal C08 production binding mismatch.')
    return record, row, receipt_path


def _check_evidence(record, source):
    """Hash-bound finite evidence, never a global posterior-domain certificate."""
    for group in ('sources', 'evidence'):
        items = record.get(group)
        if not isinstance(items, list) or not items:
            raise ValueError('Direct truth record needs explicit '+group)
        seen = set()
        for item in items:
            if not isinstance(item, dict) or set(item) != {'path', 'sha256'}:
                raise ValueError('Malformed truth source/evidence binding.')
            path = Path(item['path'])
            if not path.is_absolute(): path = Path(source).parent/path
            path = path.resolve()
            if path in seen or path == Path(source).resolve() or sha256(path) != item['sha256']:
                raise RuntimeError('Truth source/evidence hash mismatch, duplicate or self-reference.')
            seen.add(path)


def load_c08_truth(runtime, datum, model, truth_data_path, truth_logl_path, *,
                   index_path, c07_config_path, c07_generation_path):
    """Called only by diagnosis, after frozen proposal and IID production exist."""
    index = validate_index(read_json(index_path))
    bindings = dict(data_sha256=sha256(truth_data_path),
                    generation_config_sha256=sha256(c07_config_path),
                    generation_sha256=sha256(c07_generation_path))
    if any(bindings[k] != index[k] for k in bindings) or bindings['data_sha256'] != runtime.input_hashes['data']:
        raise RuntimeError('C07 truth data/config/generation binding differs from the cohort.')
    if runtime.input_hashes['runtime_generation'] != bindings['generation_sha256']:
        raise RuntimeError('Runtime uses a different generation record.')
    cfg, generation = read_json(c07_config_path), read_json(c07_generation_path)
    if (generation.get('data_sha256') != bindings['data_sha256']
            or generation.get('config_sha256') != bindings['generation_config_sha256']
            or generation.get('realizations') != runtime.n
            or cfg.get('n_realizations') != runtime.n
            or cfg.get('parameters') != runtime.cfg['parameters']
            or cfg.get('prior') != runtime.cfg['prior']):
        raise RuntimeError('C07 generation provenance or prior differs.')
    with np.load(truth_data_path, allow_pickle=False) as archive:
        if str(archive['config_sha256']) != bindings['generation_config_sha256']:
            raise RuntimeError('NPZ internal generating-config SHA differs.')
        truth = np.array(archive['truth'][datum], dtype=float, copy=True)
    bounds = runtime.bounds
    if truth.shape != (5,) or not np.isfinite(truth).all(): raise ValueError('Finite five-parameter truth required.')
    unit = (truth-bounds[:,0])/(bounds[:,1]-bounds[:,0])
    if np.any((unit < 0) | (unit > 1)): raise ValueError('Truth outside the registered prior.')
    value = read_json(truth_logl_path)
    required = dict(schema=TRUTH_SCHEMA, status='DIRECT_RESPONSE_TRUTH_LOGL_DIAGNOSTIC_ONLY',
                    scope='FINITE_TRUE_PARAMETER_POINTS_DIAGNOSTIC_ONLY',
                    response_variant=runtime.response_variant, **bindings,
                    runtime_experiment_sha256=runtime.input_hashes['experiment'],
                    cohort_index_sha256=sha256(index_path),
                    models=[runtime.response_variant+'_CN', runtime.response_variant+'_G'],
                    parameters=runtime.cfg['parameters'], prior_bounds=bounds.tolist(),
                    interpolation_used=False, posterior_domain_certificate=False)
    if (any(value.get(k) != v for k,v in required.items())
            or value.get('interpolation_used') is not False
            or value.get('posterior_domain_certificate') is not False):
        raise RuntimeError('Own C08 direct-response truth likelihood header differs.')
    expected_rows = target_rows(index, runtime.response_variant, 'main')
    records = value.get('records')
    if not isinstance(records, list) or len(records) != len(expected_rows):
        raise ValueError('Exactly64 scientific truth records per variant required, including engineering subset.')
    max_difference = 0.; selected = None
    for item, expected in zip(records, expected_rows):
        if any(item.get(k) != expected[k] for k in ('internal_target', 'model', 'datum')):
            raise ValueError('Direct truth record order/target identity differs.')
        t = np.asarray(item.get('truth_physical'), float)
        fine, coarse = item.get('log_likelihood_fine'), item.get('log_likelihood_coarse')
        if (t.shape != (5,) or not np.isfinite(t).all()
                or any(type(v) not in (int,float) or not np.isfinite(v) for v in (fine,coarse))):
            raise ValueError('Finite direct coarse/fine likelihoods and truth coordinates required.')
        max_difference = max(max_difference, abs(fine-coarse))
        if item['datum'] == datum and item['model'] == model:
            if not np.array_equal(t, truth): raise RuntimeError('Direct record truth differs from final C07 data.')
            selected = float(fine)
    refinement = value.get('response_refinement', {})
    if (refinement.get('matrix_absolute_tolerance') != 1e-8
            or refinement.get('log_likelihood_absolute_tolerance') != .001
            or refinement.get('maximum_log_likelihood_difference') != max_difference
            or type(refinement.get('maximum_matrix_absolute_difference')) not in (int,float)
            or not np.isfinite(refinement['maximum_matrix_absolute_difference'])
            or not 0 <= refinement['maximum_matrix_absolute_difference'] <= 1e-8
            or max_difference > .001 or selected is None):
        raise RuntimeError('Finite direct-response refinement evidence did not pass the registered tolerances.')
    _check_evidence(value, truth_logl_path)
    return truth, unit, selected


def diagnose_c08_target(runtime, report_path, raw_root, truth_data_path, protocol_path,
                         output_root, *, truth_loglikelihood_path, context, resume=False):
    start = perf_counter()
    record, row, external_path = external_production_record(runtime, report_path)
    index = validate_index(read_json(context['cohort_index']))
    protocol = read_json(protocol_path); phase = runtime.settings['phase']
    if protocol != diagnostic_protocol(index, phase): raise ValueError('C08 diagnostic protocol changed.')
    expected = target_rows(index, runtime.response_variant, phase)
    planned = next((r for r in expected if r['internal_target'] == record['target']), None)
    if planned is None or protocol['levels'] != record['levels']:
        raise ValueError('Target/IID levels differ from the frozen C08 phase.')
    inputs = dict(producer_report_sha256=sha256(report_path), external_receipt_sha256=sha256(external_path),
                  protocol_sha256=sha256(protocol_path), truth_data_sha256=sha256(truth_data_path),
                  truth_loglikelihood_sha256=sha256(truth_loglikelihood_path),
                  context_sha256={k:sha256(v) for k,v in context.items()},
                  source_sha256={k:sha256(p) for k,p in diagnostic_sources().items()})
    output = Path(output_root); destination = output/f'diagnostic_target_{record["target"]:06d}.json'
    if destination.exists():
        if not resume: raise FileExistsError('Existing diagnostic requires explicit resume.')
        old = read_json(destination)
        if (old.get('schema') != SCHEMA or old.get('identity') != runtime.identity
                or old.get('target') != record['target'] or old.get('diagnostic_inputs') != inputs
                or Path(old['numeric_file']).name != old['numeric_file']
                or sha256(output/old['numeric_file']) != old['numeric_sha256']):
            raise RuntimeError('Completed C08 diagnostic identity or arrays changed.')
        return old
    record, loaded = load_target_levels(report_path, raw_root)
    truth, unit, truth_logl = load_c08_truth(runtime, record['datum'], row['model'], truth_data_path,
        truth_loglikelihood_path, index_path=context['cohort_index'],
        c07_config_path=context['c07_config'], c07_generation_path=context['c07_generation'])
    arrays, summary = numerical_statistics(*(loaded[n] for n in record['levels']), unit,
        truth_logl, runtime.bounds, population_targets=protocol['population_targets'],
        mcse_target=protocol['cdf_mcse_target'], alpha_replicates=protocol['alpha_replicate_family'],
        alpha_refinement=protocol['alpha_refinement_family'])
    ordered = [sorted((r for r in record['replicates'] if r['level'] == n), key=lambda r:r['replicate']) for n in record['levels']]
    saturated = np.array([[r['saturated_normalized_target_weight'] for r in reps] for reps in ordered], float)
    saturated_rows = np.array([[r['saturated_rows'] for r in reps] for reps in ordered], int)
    if saturated.shape != (2,4) or not np.isfinite(saturated).all() or np.any((saturated < 0)|(saturated > 1)):
        raise ValueError('Invalid saturation weights in complete production report.')
    summary['saturation_guard_pass'] = bool(np.max(saturated) <= protocol['maximum_saturated_target_weight'])
    summary['maximum_saturated_normalized_weight'] = float(np.max(saturated))
    summary['posterior_domain_response_validation_status'] = 'PENDING_SEPARATE_VALIDATION'
    arrays.update(target=np.asarray(record['target']), datum=np.asarray(record['datum']),
        model_index=np.asarray(record['target']//runtime.n), scientific_model=np.asarray(row['model']),
        response_variant=np.asarray(runtime.response_variant), phase=np.asarray(phase),
        truth_unit=unit, truth_physical=truth, truth_log_likelihood=np.asarray(truth_logl),
        saturated_rows=saturated_rows, saturated_weight=saturated)
    numeric = output/f'diagnostic_target_{record["target"]:06d}.npz'
    if numeric.exists():
        if not resume: raise FileExistsError('Incomplete numeric file requires explicit resume.')
        from inference.campaign_iid import verify_arrays
        verify_arrays(numeric, arrays)
    else: write_npz_new(numeric, **arrays)
    runtime.verify_unchanged()
    if (inputs['producer_report_sha256'] != sha256(report_path)
            or inputs['external_receipt_sha256'] != sha256(external_path)
            or inputs['protocol_sha256'] != sha256(protocol_path)
            or inputs['truth_data_sha256'] != sha256(truth_data_path)
            or inputs['truth_loglikelihood_sha256'] != sha256(truth_loglikelihood_path)
            or inputs['context_sha256'] != {k:sha256(v) for k,v in context.items()}
            or inputs['source_sha256'] != {k:sha256(p) for k,p in diagnostic_sources().items()}):
        raise RuntimeError('C08 diagnostic inputs or sources changed during evaluation.')
    meta = dict(status='NUMERICAL_DIAGNOSTICS_COMPLETE', schema=SCHEMA,
        diagnostic_scope='C08_COHORT_POSTERIOR_NUMERICS_ONLY', identity=runtime.identity,
        target_identity=runtime.target_identity, response_variant=runtime.response_variant,
        phase=phase, target=record['target'], datum=record['datum'], model=row['model'],
        internal_kernel=row['internal_kernel'], external_target=row['external_target'],
        cohort_stratum=planned['cohort_stratum'], population_numerical_family=protocol['population_targets'],
        numeric_file=numeric.name, numeric_sha256=sha256(numeric), numeric_bytes=numeric.stat().st_size,
        diagnostic_inputs=inputs, raw_sha256={r['raw_file']:r['raw_sha256'] for r in record['replicates']},
        proposal_sha256=record['proposal_sha256'], levels=record['levels'], summary=summary,
        truth_read_only_for_diagnostic=True, truth_likelihood_evaluations_this_reader=0,
        truth_likelihood_source='independent direct response, finite true-parameter checks',
        raw_release_authorized=False, no_SBC500_claim=True, seconds=perf_counter()-start)
    write_json_new(destination, json_safe(meta)); return meta


def diagnostic_sources():
    import inference.campaign_diagnostic_io as io
    import inference.campaign_diagnostics as algebra
    import inference.iid_optimized as optimized
    import inference.iid_diagnostics as original
    import c08_contract
    return {name:Path(module.__file__).resolve() for name,module in
            [('c08_contract',c08_contract),('campaign_diagnostic_io',io),('campaign_diagnostics',algebra),
             ('iid_optimized',optimized),('iid_diagnostics',original)]} | {'c08_diagnostics':Path(__file__).resolve()}
