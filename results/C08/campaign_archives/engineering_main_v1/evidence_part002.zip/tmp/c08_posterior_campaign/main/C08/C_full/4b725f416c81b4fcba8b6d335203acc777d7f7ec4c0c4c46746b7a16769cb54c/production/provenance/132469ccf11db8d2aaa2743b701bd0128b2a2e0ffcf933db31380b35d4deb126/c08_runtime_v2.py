"""C08 v2 contract: finite engineering evidence is distinct from runtime data.

Inherits v1 coefficient loading, memory checks and unchanged C07 libraries.
Does not equate engineering inputs with a new posterior experiment. Domain
compatibility is a separate, hashed approval; it is not validation of unseen
posterior regions. Init reads hashes/headers and small derived geometry only.
"""
from pathlib import Path
import math
import numpy as np
from c08_runtime import (C08Runtime as C08RuntimeV1, TABLE_SCHEMA, GATE_LIMITS,
                         GEOMETRY_FIELDS, array_sha256, array_metadata,
                         npz_metadata, _digest)
from inference.campaign_io import (OBSERVATION_FIELDS, canonical_hash, positive_int,
                                   read_json, sha256, write_json_new)
from inference.model import experiment

GATE_SCHEMA_V2 = 'C08_RESPONSE_FINITE_GATES_v2'
COMPATIBILITY_SCHEMA = 'C08_ENGINEERING_RUNTIME_DOMAIN_COMPATIBILITY_v1'
SCOPE = 'FINITE_ENGINEERING_DOMAIN_ONLY'
PENDING_POSTERIOR_CHECKS = ['response_accuracy_in_posterior_region',
                            'per_posterior_sampling_and_precision_diagnostics']
REVIEWED_CHECKS = ['generation_records_match_declared_configuration_and_observations',
                   'generation_and_spectral_implementations_correspond',
                   'observed_geometry_and_scale_match_declared_domain',
                   'population_and_model_label_differences_reviewed']
DOMAIN_ARRAYS = ('points', 'distance_ly', 'sigma', 'red', 'f', 'scale', 'H', 'weights')


def domain_descriptor(config, exp=None):
    """Exact expected geometry/spectra/prior/scale, not observed payload proof.

    n_realizations and model labels deliberately do not enter this descriptor.
    Generation artifacts and payload/config correspondence require the separate
    review evidence. This function runs no ORF or likelihood calculation.
    """
    e = experiment(config) if exp is None else exp
    arrays = {}
    for name in DOMAIN_ARRAYS:
        value = np.ascontiguousarray(e[name])
        if not np.isfinite(value).all():
            raise ValueError('Nonfinite expected domain array: '+name)
        arrays[name] = dict(**array_metadata(value), sha256=array_sha256(value))
    scalars = {name: float(e[name]) for name in ('T', 'dt')}
    if not all(math.isfinite(v) and v > 0 for v in scalars.values()):
        raise ValueError('Invalid spectral time scales')
    return dict(schema='C08_EXPECTED_DOMAIN_DESCRIPTOR_v1', arrays=arrays,
                scalars=scalars, prior=config['prior'], parameters=config['parameters'],
                fixed_red_slope=config['fixed_red_slope'],
                positive_channels=config['positive_channels'], n_pulsars=config['n_pulsars'])


class C08Runtime(C08RuntimeV1):
    def __init__(self, *args, tested_experiment_path, tested_generation_path,
                 tested_observations_path, runtime_generation_path,
                 domain_compatibility_path, **kwargs):
        self._domain_paths = {k: Path(v).resolve() for k, v in dict(
            tested_experiment=tested_experiment_path,
            tested_generation=tested_generation_path,
            tested_observations=tested_observations_path,
            runtime_generation=runtime_generation_path,
            domain_compatibility=domain_compatibility_path).items()}
        super().__init__(*args, **kwargs)

    def _validate_domain_bindings(self):
        self.paths.update(self._domain_paths)
        self.input_hashes.update({k: sha256(p) for k, p in self._domain_paths.items()})
        self.tested_config = read_json(self.paths['tested_experiment'])
        self.domain_compatibility = read_json(self.paths['domain_compatibility'])
        tested_n = positive_int(self.tested_config['n_realizations'], 'engineering dataset count')
        if (type(self.tested_config.get('n_pulsars')) is not int
                or self.tested_config['n_pulsars'] != self.P
                or self.tested_config.get('positive_channels') != [1, 2, 3, 4]):
            raise ValueError('Engineering geometry dimensions must match before deriving arrays')
        # Matching a current derived descriptor does not assert that historical
        # generation used this implementation: that is an explicit review item.
        self.tested_domain = domain_descriptor(self.tested_config)
        self.runtime_domain = domain_descriptor(self.cfg, self.exp)
        if self.tested_domain != self.runtime_domain:
            raise ValueError('Engineering/runtime geometry, spectra, prior or scale differ')
        self.tested_observation_metadata = npz_metadata(self.paths['tested_observations'], OBSERVATION_FIELDS)
        self.tested_geometry_metadata = npz_metadata(self.paths['tested_observations'], GEOMETRY_FIELDS)
        expected = dict(q=([tested_n, self.K, self.P], np.dtype('complex128').str),
                        x_physical=([tested_n, self.K, self.D], np.dtype('float64').str),
                        x_gaussian=([tested_n, self.K, self.D], np.dtype('float64').str))
        if any(self.tested_observation_metadata[k]['shape'] != shape
               or self.tested_observation_metadata[k]['dtype'] != dtype
               for k, (shape, dtype) in expected.items()):
            raise ValueError('Engineering observation headers differ from tested configuration')
        if self.tested_geometry_metadata != self.observation_geometry_metadata:
            raise ValueError('Engineering/runtime geometry metadata differ')
        tested = dict(configuration_sha256=self.input_hashes['tested_experiment'],
                      generation_sha256=self.input_hashes['tested_generation'],
                      observations_sha256=self.input_hashes['tested_observations'])
        runtime = dict(configuration_sha256=self.input_hashes['experiment'],
                       generation_sha256=self.input_hashes['runtime_generation'],
                       observations_sha256=self.input_hashes['data'],
                       validation_config_sha256=self.input_hashes['validation_config'])
        scope = dict(dataset_count_per_model=tested_n, observation_models=['CN', 'G'],
                     total_observations=2*tested_n, declared_checks_only=True)
        g, c = self.gates, self.domain_compatibility
        if (g.get('tested_domain_inputs') != tested or g.get('tested_observation_scope') != scope
                or g.get('evidence_scope') != SCOPE
                or g.get('runtime_population_validation_claimed') is not False
                or g.get('posterior_region_checks_status') != 'PENDING'
                or any(k in g for k in ('experiment_sha256', 'observations_sha256',
                                       'validation_config_sha256'))):
            raise ValueError('Finite engineering inputs/scope must be explicit and distinct from runtime bindings')
        descriptor_hash = canonical_hash(self.tested_domain)
        if (c.get('schema') != COMPATIBILITY_SCHEMA
                or c.get('status') != 'APPROVED_DOMAIN_COMPATIBILITY_FINITE_ENGINEERING_ONLY'
                or c.get('response_variant') != self.response_variant
                or c.get('tested_domain_inputs') != tested or c.get('runtime_experiment') != runtime
                or c.get('response_gate_sha256') != self.input_hashes['response_gates']
                or c.get('tested_domain_descriptor_sha256') != descriptor_hash
                or c.get('runtime_domain_descriptor_sha256') != canonical_hash(self.runtime_domain)
                or c.get('evidence_scope') != SCOPE
                or c.get('runtime_population_validation_claimed') is not False
                or c.get('posterior_region_checks_status') != 'PENDING'
                or c.get('pending_posterior_checks') != PENDING_POSTERIOR_CHECKS
                or c.get('reviewed_checks') != {name: True for name in REVIEWED_CHECKS}):
            raise ValueError('Separate approved compatibility must bind tested and runtime experiments without population validation')
        differences = dict(tested_datasets_per_model=tested_n, runtime_datasets_per_model=self.n,
                           tested_model_labels=self.tested_config.get('models'),
                           runtime_model_labels=self.cfg['models'],
                           observation_payloads_may_differ=True)
        if c.get('population_and_label_differences') != differences:
            raise ValueError('Compatibility must state population/model label differences explicitly')
        approval = c.get('approval')
        if (not isinstance(approval, dict)
                or any(not isinstance(approval.get(k), str) or not approval[k].strip()
                       for k in ('approved_by', 'decision_id'))):
            raise ValueError('Compatibility needs an explicit review decision')
        evidence = c.get('review_evidence')
        if not isinstance(evidence, list) or not evidence:
            raise ValueError('Compatibility review needs hashed evidence artifacts')
        for i, item in enumerate(evidence):
            if not isinstance(item, dict) or set(item) != {'path', 'sha256'}:
                raise ValueError('Malformed domain review evidence')
            path = Path(item['path'])
            if not path.is_absolute():
                path = self.paths['domain_compatibility'].parent/path
            path = path.resolve()
            if path == self.paths['domain_compatibility'] or sha256(path) != _digest(item['sha256'], 'domain review evidence'):
                raise ValueError('Domain review evidence hash mismatch or self-reference')
            key = 'domain_review_evidence_'+str(i)
            self.paths[key], self.input_hashes[key] = path, item['sha256']
        self.domain_report = dict(
            schema='C08_RUNTIME_EVIDENCE_SCOPE_v2', evidence_scope=SCOPE,
            tested_domain_inputs=tested, tested_observation_scope=scope,
            runtime_experiment=runtime, population_and_label_differences=differences,
            expected_domain_descriptor_sha256=descriptor_hash,
            compatibility_sha256=self.input_hashes['domain_compatibility'],
            response_gate_sha256=self.input_hashes['response_gates'],
            runtime_population_validation_claimed=False, posterior_region_checks_status='PENDING',
            pending_posterior_checks=PENDING_POSTERIOR_CHECKS.copy(),
            machine_checks='exact file hashes, NPY headers and config-derived domain equality',
            review_scope='generation provenance, observed payload geometry/scale and historical spectral implementation',
            engineering_or_runtime_observation_payload_read_during_init=False)

    def _validate_response_evidence(self):
        m, g = self.manifest, self.gates
        if (m.get('schema') != TABLE_SCHEMA or m.get('status') != 'FROZEN_COEFFICIENT_TABLE'
                or m.get('response_variant') != self.response_variant
                or m.get('coordinate') != 'minus_beta' or m.get('runtime_channels') != 4
                or m.get('file_sha256') != self.input_hashes['table']
                or m.get('array_metadata') != self.table_metadata):
            raise ValueError('Own C08 table manifest/file/metadata identity required; C07 manifests rejected')
        expected_rule = ('all_channels_as_stored' if self.response_variant == 'C_beta'
                         else 'repeat_first_channel_to_four' if self.stored_K == 1
                         else 'all_channels_stored_identical_first')
        if m.get('expansion_rule') != expected_rule:
            raise ValueError('C08 response expansion rule mismatch')
        for field in ('array_sha256', 'expanded_array_sha256'):
            if set(m.get(field, {})) != {'nodes', 'matrices', 'coeff'}:
                raise ValueError('Every stored/expanded array needs an explicit hash')
            for key, value in m[field].items():
                _digest(value, field+'.'+key)
        if self.stored_K == 4 and m['expanded_array_sha256'] != m['array_sha256']:
            raise ValueError('Four stored channels must be used without expansion')
        self._validate_domain_bindings()
        if (g.get('schema') != GATE_SCHEMA_V2 or g.get('status') != 'PASS_STATED_RESPONSE_GATES_ONLY'
                or g.get('response_variant') != self.response_variant
                or g.get('purpose') not in ('response_validation', 'synthetic_contract_test')
                or g.get('table_file_sha256') != self.input_hashes['table']
                or g.get('array_sha256') != m['array_sha256']
                or g.get('expanded_array_sha256') != m['expanded_array_sha256']):
            raise ValueError('Own response-specific C08 v2 finite gate and table bindings required')
        if g.get('thresholds') != GATE_LIMITS or set(g.get('maxima', {})) != set(GATE_LIMITS):
            raise ValueError('Unchanged registered C08 gate thresholds required')
        if set(g.get('provenance', {})) != set(GATE_LIMITS):
            raise ValueError('Every C08 gate maximum needs explicit scoped provenance')
        for key, limit in GATE_LIMITS.items():
            value = g['maxima'][key]
            if (isinstance(value, bool) or not isinstance(value, (int, float))
                    or not math.isfinite(value) or not 0 <= value <= limit):
                raise ValueError('C08 finite gate did not pass: '+key)
            self._gate_evidence(key, g['provenance'][key], allow_inherited=not key.startswith('logL_'))
        additional = g.get('additional_checks', [])
        if not isinstance(additional, list):
            raise ValueError('Additional response checks must be an explicit list')
        names = set()
        for check in additional:
            if (not isinstance(check, dict) or not isinstance(check.get('name'), str)
                    or not check['name'] or check['name'] in names or check.get('status') != 'PASS'):
                raise ValueError('Malformed/failed additional C08 response check')
            names.add(check['name'])
            error, tolerance = check.get('maximum_error'), check.get('absolute_tolerance')
            if (any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
                    for v in (error, tolerance)) or tolerance <= 0 or not 0 <= error <= tolerance):
                raise ValueError('Additional C08 response check exceeds its explicit tolerance')
            self._gate_evidence(check['name'], check.get('provenance'), allow_inherited=False)

    def _initialize_sources(self):
        super()._initialize_sources()
        self.source_paths['c08_runtime_v2'] = Path(__file__).resolve()
        self.source_hashes['c08_runtime_v2'] = sha256(self.source_paths['c08_runtime_v2'])

    def _contract_digest(self):
        return canonical_hash(dict(v1_contract=super()._contract_digest(),
                                   tested_config=self.tested_config,
                                   domain_compatibility=self.domain_compatibility,
                                   tested_domain=self.tested_domain, runtime_domain=self.runtime_domain,
                                   tested_observation_metadata=self.tested_observation_metadata,
                                   tested_geometry_metadata=self.tested_geometry_metadata,
                                   domain_report=self.domain_report))

    def preflight(self):
        report = super().preflight()
        report.update(schema='C08_RUNTIME_PREFLIGHT_v2', domain_compatibility=self.domain_report,
                      runtime_population_validation_claimed=False,
                      posterior_region_checks_status='PENDING',
                      pending_scientific_checks=PENDING_POSTERIOR_CHECKS.copy())
        return report

    def snapshot(self, output_root):
        super().snapshot(output_root)
        path = Path(output_root).resolve()/'provenance'/self.identity/'c08_domain_compatibility.json'
        record = dict(identity=self.identity, target_identity=self.target_identity, **self.domain_report)
        if path.exists():
            if read_json(path) != record:
                raise RuntimeError('C08 domain provenance namespace collision')
        else:
            write_json_new(path, record)
