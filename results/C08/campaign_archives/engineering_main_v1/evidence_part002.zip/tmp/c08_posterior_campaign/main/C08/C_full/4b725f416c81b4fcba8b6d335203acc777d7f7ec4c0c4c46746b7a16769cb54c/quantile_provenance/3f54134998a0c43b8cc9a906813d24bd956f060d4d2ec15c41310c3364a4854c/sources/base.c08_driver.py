#!/usr/bin/env python3
"""Prospective C08 lifecycle using unchanged C07 training, IID and archive APIs.

The orchestration loop is adapted from scripts/run_calibration_campaign.py.
Its exclusive lock and immutable budget Ledger are imported unchanged. C08
uses training/, scientific external receipts and an independent diagnostic
schema. No physical execution occurs without both runtime and driver gates.
"""
from pathlib import Path
import argparse, functools, importlib, importlib.util, json, shutil, sys, time
if __name__ == '__main__':
    boot = argparse.ArgumentParser(add_help=False)
    boot.add_argument('--repository', type=Path, required=True)
    known, _ = boot.parse_known_args()
    sys.path[:0] = [str(known.repository.resolve()/'src'), str(known.repository.resolve()/'scripts')]
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'c08_driver_design'))
import numpy as np
import run_calibration_campaign as baseline_driver
from run_calibration_campaign import Ledger, campaign_lock
from inference.campaign_training import train_block
from inference.campaign_iid import produce_target, release_raw
from inference.campaign_archive import prepare_archive, verify_archive_receipt
from inference.campaign_io import read_json, sha256, canonical_hash, write_json_new, atomic_new
from c08_contract import validate_index, validate_settings_and_protocol, combined_budget
from c08_diagnostics import diagnose_c08_target, diagnostic_sources, external_production_record


def extra_sources():
    return diagnostic_sources() | dict(c07_driver=Path(baseline_driver.__file__).resolve(),
                                      c08_driver=Path(__file__).resolve(),
                                      inference_package_init=Path(importlib.import_module('inference').__file__).resolve())


def bind_inputs(protocol, truth_data, truth_logl, context):
    paths = dict(protocol=Path(protocol), truth_data=Path(truth_data),
                 truth_logl=None if truth_logl is None else Path(truth_logl),
                 **{k:Path(p) for k,p in context.items()})
    # Only byte hashes here. In particular, logL values and truth arrays are
    # not deserialized until diagnose_c08_target is called after production.
    return {k:None if p is None or not p.is_file() else sha256(p) for k,p in paths.items()}


def check_driver_authorization(path, *, identity, runtime, phase, index_sha):
    if path is None or not Path(path).is_file(): return None
    record = read_json(path)
    expected = dict(schema='C08_DRIVER_EXECUTION_AUTHORIZATION_v1', execution_allowed=True,
                    scope='C08_SINGLE_PHASE_VARIANT_LIFECYCLE_ONLY',
                    driver_identity=identity, runtime_identity=runtime.identity,
                    target_identity=runtime.target_identity, response_variant=runtime.response_variant,
                    phase=phase, cohort_index_sha256=index_sha,
                    stages=['training','iid','diagnostics','archive','raw_retirement'],
                    budget_sha256=canonical_hash(runtime.settings['budget']),
                    no_global_response_or_scientific_approval=True)
    if (any(record.get(k) != v for k,v in expected.items())
            or record.get('execution_allowed') is not True
            or record.get('no_global_response_or_scientific_approval') is not True
            or any(not isinstance(record.get(k),str) or not record[k].strip() for k in ('approved_by','decision_id'))):
        raise RuntimeError('Explicit C08 driver authorization does not bind the frozen lifecycle.')
    return sha256(path)


def campaign_plan(runtime, protocol_path, truth_data_path, truth_logl_path, output_base,
                  *, context, driver_authorization_path=None):
    index = validate_index(read_json(context['cohort_index']))
    phase = runtime.settings['phase']; protocol = read_json(protocol_path)
    inputs = bind_inputs(protocol_path, truth_data_path, truth_logl_path, context)
    if any(inputs[k] is None for k in ('protocol','truth_data','cohort_index','c07_config','c07_generation')):
        raise ValueError('C08 metadata/data/config/generation inputs are required before planning.')
    if (inputs['truth_data'] != index['data_sha256']
            or inputs['c07_config'] != index['generation_config_sha256']
            or inputs['c07_generation'] != index['generation_sha256']
            or runtime.input_hashes['runtime_generation'] != inputs['c07_generation']):
        raise RuntimeError('C07 data/config/generation identities differ from cohort/runtime bindings.')
    rows = validate_settings_and_protocol(runtime, index, protocol, phase, inputs['cohort_index'])
    plan = runtime.preflight(); sources = {k:sha256(p) for k,p in extra_sources().items()}
    # Phase prefix is necessary: the runtime target_identity intentionally
    # excludes settings/seeds, and must never collide across independent fits.
    output = runtime.namespace(Path(output_base).resolve()/phase)
    identity = canonical_hash(dict(schema='C08_DRIVER_IDENTITY_v1', runtime_identity=runtime.identity,
        extra_input_sha256=inputs, driver_source_sha256=sources, phase=phase,
        response_variant=runtime.response_variant, target_index=rows,
        output=str(output),resource_lock_root=str(Path(output_base).resolve()), combined_budget=combined_budget()))
    authorization_sha = check_driver_authorization(driver_authorization_path, identity=identity,
        runtime=runtime, phase=phase, index_sha=inputs['cohort_index'])
    pending = list(plan['pending'])
    if inputs['truth_logl'] is None: pending.append('Independent direct C08 truth likelihood record is absent.')
    if authorization_sha is None: pending.append('Separate frozen C08 driver lifecycle authorization is absent.')
    existing = output
    while not existing.exists(): existing = existing.parent
    reserve = runtime.settings['budget']['maximum_active_raw_bytes']+len(rows)*1024**2+512*1024**2
    available = shutil.disk_usage(existing).free
    if reserve > available: raise RuntimeError('Insufficient disk for bounded raw plus complete compact archives.')
    plan.update(schema='C08_DRIVER_PREFLIGHT_v1', driver_identity=identity, phase=phase,
        scope='C08_'+phase.upper()+'_COHORT_NUMERICS_ONLY', output=str(output),resource_lock_root=str(Path(output_base).resolve()),
        levels=runtime.settings['production']['levels'], target_index=rows,
        all_target_ids=[r['internal_target'] for r in rows],
        population_numerical_family=protocol['population_targets'],
        extra_input_sha256=inputs, driver_source_sha256=sources,
        driver_authorization_path=None if driver_authorization_path is None else str(Path(driver_authorization_path).resolve()),
        driver_authorization_sha256=authorization_sha, pending=pending, execution_ready=not pending,
        combined_budget=combined_budget(), free_disk_bytes=available, minimum_free_disk_bytes=reserve,
        truth_deserialized_during_preflight=False, truths_used_for_training_or_production=False,
        raw_strategy='One target at a time; all failures retained before verified raw retirement',
        numerical_uniformity_is_not_a_stopping_rule=True,
        deterministic_response_posterior_region_validation='PENDING_SEPARATE_CHECKS',
        no_publication_or_automatic_scientific_approval=True)
    return plan


def verify_frozen_plan(runtime, plan, protocol_path, truth_data_path, truth_logl_path, context, output):
    runtime.verify_unchanged()
    if (Path(output).resolve() != Path(plan['output'])
            or bind_inputs(protocol_path, truth_data_path, truth_logl_path, context) != plan['extra_input_sha256']
            or {k:sha256(p) for k,p in extra_sources().items()} != plan['driver_source_sha256']):
        raise RuntimeError('C08 driver sources, inputs or output namespace changed.')
    index=validate_index(read_json(context['cohort_index']));protocol=read_json(protocol_path)
    rows=validate_settings_and_protocol(runtime,index,protocol,runtime.settings['phase'],sha256(context['cohort_index']))
    if (plan['all_target_ids'] != [r['internal_target'] for r in rows]
            or plan['target_index'] != rows or plan['phase'] != runtime.settings['phase']
            or plan['response_variant'] != runtime.response_variant
            or plan['population_numerical_family'] != protocol['population_targets']
            or plan['training_blocks'] != runtime.preflight()['training_blocks']):
        raise RuntimeError('Planned C08 target scope or blocks changed.')
    current=canonical_hash(dict(schema='C08_DRIVER_IDENTITY_v1',runtime_identity=runtime.identity,
        extra_input_sha256=plan['extra_input_sha256'],driver_source_sha256=plan['driver_source_sha256'],
        phase=plan['phase'],response_variant=runtime.response_variant,target_index=rows,
        output=str(Path(output).resolve()),resource_lock_root=plan['resource_lock_root'],combined_budget=combined_budget()))
    if current != plan['driver_identity'] or runtime.preflight()['execution_ready'] is not True:
        raise RuntimeError('C08 plan identity or runtime execution gate changed.')
    digest = check_driver_authorization(plan['driver_authorization_path'], identity=plan['driver_identity'],
        runtime=runtime, phase=plan['phase'], index_sha=plan['extra_input_sha256']['cohort_index'])
    if digest is None or digest != plan['driver_authorization_sha256']:
        raise RuntimeError('C08 execution authorization is absent or changed.')


def snapshot_driver(runtime, output, plan, protocol_path, truth_logl_path, context):
    runtime.snapshot(output)
    root = output/'driver_provenance'/plan['driver_identity']
    paths = {k:(p,plan['driver_source_sha256'][k]) for k,p in extra_sources().items()}
    for k,p in dict(protocol=protocol_path,truth_logl=truth_logl_path,**context).items():
        paths['input_'+k] = (Path(p), plan['extra_input_sha256'][k])
    if plan['driver_authorization_path']:
        paths['driver_authorization'] = (Path(plan['driver_authorization_path']),plan['driver_authorization_sha256'])
    for role,(path,digest) in paths.items():
        target = root/(role+path.suffix)
        if sha256(path) != digest: raise RuntimeError('Snapshot source changed.')
        if target.exists():
            if sha256(target) != digest: raise RuntimeError('C08 snapshot collision.')
        else: atomic_new(target, lambda p,path=path:p.write_bytes(path.read_bytes()))


def indexed_training(runtime, targets, directory, *, resume=False):
    value = train_block(runtime, targets, directory, resume=resume)
    for target in targets: runtime._external_record_index(directory, int(target), 'training')
    return value


def indexed_production(runtime, target, training, production, raw, *, resume=False):
    value = produce_target(runtime, target, training, production, raw, resume=resume)
    runtime._external_record_index(production, int(target), 'production')
    return value


def actual_operations(context):
    return dict(train=indexed_training, produce=indexed_production,
                diagnose=functools.partial(diagnose_c08_target, context=context),
                archive=archive_c08_target, release=release_raw)


NUMERICAL_FLAGS=('cdf_precision_pass','pooled_weight_guard_pass','saturation_guard_pass','replication_pass','refinement_pass')


def archive_c08_target(runtime,target,training,production,diagnostic_path,*,resume=False):
    value=read_json(diagnostic_path)
    row=next(r for r in runtime.target_index if r['internal_target']==target)
    if (value.get('schema')!='C08_TARGET_IID_DIAGNOSTICS_v1'
            or value.get('model')!=row['model'] or value.get('phase')!=runtime.settings['phase']
            or any(type(value.get('summary',{}).get(k)) is not bool for k in NUMERICAL_FLAGS)):
        raise RuntimeError('C08 archive requires scientific labels and all five Boolean numerical flags.')
    return prepare_archive(runtime,target,training,production,diagnostic_path,resume=resume)


def verify_done(path, output, plan):
    row = baseline_driver.verify_done(path,output,plan)
    route = next((r for r in plan['target_index'] if r['internal_target'] == row['target']), None)
    if (route is None or row.get('schema') != 'C08_TARGET_STATE_v1'
            or row.get('model') != route['model'] or row.get('internal_kernel') != route['internal_kernel']
            or row.get('external_target') != route['external_target']
            or row.get('phase') != plan['phase'] or row.get('response_variant') != plan['response_variant']):
        raise RuntimeError('Completed C08 target scientific identity differs.')
    diagnostic = read_json(output/'diagnostics'/f'diagnostic_target_{row["target"]:06d}.json')
    receipt=read_json(output/'production'/f'archive_receipt_target_{row["target"]:06d}.json')
    flags={k:diagnostic['summary'][k] for k in NUMERICAL_FLAGS}
    status='RECORDED_NUMERICAL_CHECKS_PASSED' if all(v is True for v in flags.values()) else 'NUMERICALLY_UNRESOLVED'
    if (diagnostic.get('model') != route['model'] or diagnostic.get('phase') != plan['phase']
            or any(type(v) is not bool for v in flags.values())
            or row.get('numerical_flags')!=flags or receipt.get('numerical_flags')!=flags
            or row.get('numerical_status')!=status or receipt.get('numerical_status')!=status):
        raise RuntimeError('Preserved C08 diagnostic has the wrong model/phase.')
    return row


def runtime_factory(source_path):
    source = Path(source_path).resolve()
    sys.path.insert(0,str(source.parent))
    spec = importlib.util.spec_from_file_location('c08_runtime_v2',source)
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.C08Runtime


def run_c08_campaign(runtime,plan,protocol_path,truth_data_path,truth_logl_path,output,*,context,resume=False,operations=None):
    """One active C08 runtime per authorized shared output root, all phases/variants."""
    if plan['execution_ready'] is not True:raise RuntimeError('Prospective execution is disabled or pending.')
    verify_frozen_plan(runtime,plan,protocol_path,truth_data_path,truth_logl_path,context,output)
    with campaign_lock(Path(plan['resource_lock_root'])):
        return _run_locked_c08_campaign(runtime,plan,protocol_path,truth_data_path,truth_logl_path,output,
                                       context=context,resume=resume,operations=operations)


def finish_interrupted_release(runtime,target,production,raw,diagnostic_path,ledger,release,*,resume=False):
    """Roll forward an existing raw-release intent before the producer checks raw.

    Only the orchestration changes. The unchanged C07 release implementation
    validates the preserved archive/intent and removes only still-hashed files.
    No likelihood, proposal fit or raw replay occurs here.
    """
    production=Path(production);intent=production/f'release_intent_target_{target:06d}.json'
    if not intent.exists() or (production/f'released_target_{target:06d}.json').exists():return False
    if not resume:raise RuntimeError('An incomplete raw release requires explicit --resume.')
    record,route,_=external_production_record(runtime,production/f'target_{target:06d}.json')
    diagnostic=read_json(diagnostic_path)
    if (diagnostic.get('schema')!='C08_TARGET_IID_DIAGNOSTICS_v1'
            or diagnostic.get('status')!='NUMERICAL_DIAGNOSTICS_COMPLETE'
            or diagnostic.get('identity')!=runtime.identity or diagnostic.get('target')!=target
            or diagnostic.get('model')!=route['model'] or diagnostic.get('phase')!=runtime.settings['phase']
            or diagnostic.get('raw_release_authorized') is not False
            or any(type(diagnostic.get('summary',{}).get(k)) is not bool for k in NUMERICAL_FLAGS)):
        raise RuntimeError('Interrupted release needs the complete matching C08 numerical diagnostic.')
    receipt_path=production/f'archive_receipt_target_{target:06d}.json'
    required={r['raw_file']:r['raw_sha256'] for r in record['replicates']}
    receipt=verify_archive_receipt(receipt_path,production,runtime.identity,target,required)
    archived=next(a for a in receipt['artifacts'] if a['role']=='diagnostic')
    if sha256(diagnostic_path)!=archived['sha256']:
        raise RuntimeError('Current C08 diagnostic differs from the already-preserved archive.')
    ledger.call(runtime,'other',0,'finish_interrupted_release',[target],
                lambda:release(runtime,target,production,raw,receipt_path,resume=True))
    return True


def _run_locked_c08_campaign(runtime,plan,protocol_path,truth_data_path,truth_logl_path,output,*,context,resume=False,operations=None):
    """Single runtime, trained proposal blocks and strictly sequential raw lifecycle."""
    output=Path(output).resolve();ops=operations or actual_operations(context)
    if not plan['execution_ready']:raise RuntimeError('Prospective execution is disabled or pending.')
    verify_frozen_plan(runtime, plan, protocol_path, truth_data_path, truth_logl_path, context, output)
    started=time.perf_counter()
    with campaign_lock(output):
        manifest=output/'campaign_plan.json'
        if manifest.exists():
            if not resume or read_json(manifest)['driver_identity']!=plan['driver_identity']:raise RuntimeError('Existing campaign requires --resume with identical frozen inputs/sources.')
        else:
            if not resume and any((output/name).exists() for name in ('training','production','diagnostics','state','ledger')):raise RuntimeError('Existing stage outputs require an identified resumed campaign.')
            write_json_new(manifest,plan)
        snapshot_driver(runtime,output,plan,protocol_path,truth_logl_path,context)
        ledger=Ledger(output/'ledger',plan['driver_identity'],runtime.settings['budget'])
        state=output/'state';state.mkdir(parents=True,exist_ok=True);done={}
        for path in state.glob('target_*.json'):
            row=verify_done(path,output,plan)
            if row['target'] not in plan['all_target_ids'] or row['target'] in done:raise RuntimeError('Unplanned/duplicate completed target.')
            done[row['target']]=row
        # Pre-start replay budget includes previous failed calls and unresolved
        # reservations; no restart silently resets the campaign-wide cap.
        remaining=[t for t in plan['all_target_ids'] if t not in done]
        missing=sum(not (output/'training'/f'target_{t:06d}.json').exists() for t in remaining)
        minimum_training=(runtime.settings['training']['steps']+1)*4*missing
        levels=runtime.settings['production']['levels']
        minimum_production=sum(n for t in remaining if not (output/'production'/f'target_{t:06d}.json').exists() for n in levels for r in range(4) if not (output/'production'/f'target_{t:06d}_N{n}_rep_{r:02d}.json').exists())
        spent=ledger.totals();budget=runtime.settings['budget']
        if spent['training']+minimum_training>budget['maximum_training_likelihood_values'] or spent['production']+minimum_production>budget['maximum_production_likelihood_values'] or spent['total']+minimum_training+minimum_production>budget['maximum_total_likelihood_values']:
            raise RuntimeError('Remaining campaign plus recorded/replay-reserved work exceeds its budget before restart.')
        if sum(p.stat().st_size for p in (output/'raw').glob('target_*.npz'))>budget['maximum_active_raw_bytes']:
            raise RuntimeError('Existing raw already exceeds the declared active-raw budget.')
        attempt=len(list(state.glob('attempt_*.start.json')))
        write_json_new(state/f'attempt_{attempt:04d}.start.json',dict(driver_identity=plan['driver_identity'],completed_targets=sorted(done),ledger=ledger.totals()))
        def progress(event,**fields):print(json.dumps(dict(event=event,**fields)),flush=True)
        try:
            for block_index,block in enumerate(plan['training_blocks']):
                pending=[int(t) for t in block if int(t) not in done]
                if not pending:continue
                progress('block_started',block=block_index,targets=pending,completed=len(done))
                new_proposals=[t for t in pending if not (output/'training'/f'target_{t:06d}.json').exists()]
                reserve=(runtime.settings['training']['steps']+1)*4*len(new_proposals)
                ledger.call(runtime,'training',reserve,'train',pending,lambda:ops['train'](runtime,pending,output/'training',resume=resume))
                for target in pending:
                    finish_interrupted_release(runtime,target,output/'production',output/'raw',
                        output/'diagnostics'/f'diagnostic_target_{target:06d}.json',ledger,ops['release'],resume=resume)
                    levels=runtime.settings['production']['levels']
                    production_path=output/'production'/f'target_{target:06d}.json'
                    reserve=0 if production_path.exists() else sum(n for n in levels for r in range(4) if not (output/'production'/f'target_{target:06d}_N{n}_rep_{r:02d}.json').exists())
                    ledger.call(runtime,'production',reserve,'produce',[target],lambda:ops['produce'](runtime,target,output/'training',output/'production',output/'raw',resume=resume))
                    diagnostic_path=output/'diagnostics'/f'diagnostic_target_{target:06d}.json'
                    diagnostic=ledger.call(runtime,'other',0,'diagnose',[target],lambda:ops['diagnose'](runtime,production_path,output/'raw',truth_data_path,protocol_path,output/'diagnostics',truth_loglikelihood_path=truth_logl_path,resume=resume))
                    archive=ledger.call(runtime,'other',0,'archive',[target],lambda:ops['archive'](runtime,target,output/'training',output/'production',diagnostic_path,resume=resume))
                    receipt=output/'production'/f'archive_receipt_target_{target:06d}.json'
                    ledger.call(runtime,'other',0,'release',[target],lambda:ops['release'](runtime,target,output/'production',output/'raw',receipt,resume=resume))
                    files=[output/'training'/f'c08_target_{target:06d}.json',output/'production'/f'c08_target_{target:06d}.json',production_path,diagnostic_path,output/'diagnostics'/diagnostic['numeric_file'],receipt,output/'production'/f'released_target_{target:06d}.json']
                    route=next(r for r in plan['target_index'] if r['internal_target']==target)
                    row=dict(status='TARGET_ARCHIVED',schema='C08_TARGET_STATE_v1',driver_identity=plan['driver_identity'],target=target,model=route['model'],internal_kernel=archive['model'],response_variant=runtime.response_variant,phase=plan['phase'],external_target=route['external_target'],cohort_stratum=route['cohort_stratum'],datum=archive['datum'],numerical_status=archive['numerical_status'],numerical_flags=archive['numerical_flags'],artifacts=[dict(file=str(p.relative_to(output)),sha256=sha256(p)) for p in files],no_scientific_calibration_claim=True)
                    write_json_new(state/f'target_{target:06d}.json',row);done[target]=row
                block_summary=dict(driver_identity=plan['driver_identity'],block=block_index,targets=pending,completed_total=len(done),unresolved_total=sum(r['numerical_status']=='NUMERICALLY_UNRESOLVED' for r in done.values()),ledger=ledger.totals(),seconds_since_attempt_start=time.perf_counter()-started)
                write_json_new(state/f'attempt_{attempt:04d}_block_{block_index:04d}.json',block_summary);progress('block_completed',**{k:v for k,v in block_summary.items() if k!='driver_identity'})
                verify_frozen_plan(runtime,plan,protocol_path,truth_data_path,truth_logl_path,context,output)
            if sorted(done)!=sorted(plan['all_target_ids']):raise RuntimeError('Campaign target inventory is incomplete.')
            ledger.totals(audit=True)
            result=dict(status='ALL_TARGET_PRODUCTS_ARCHIVED',schema='C08_PHASE_VARIANT_COMPLETE_v1',response_variant=runtime.response_variant,phase=plan['phase'],cohort_index_sha256=plan['extra_input_sha256']['cohort_index'],population_numerical_family=plan['population_numerical_family'],driver_identity=plan['driver_identity'],targets=sorted(done),numerically_unresolved_targets=[t for t in sorted(done) if done[t]['numerical_status']=='NUMERICALLY_UNRESOLVED'],ledger=ledger.totals(),seconds=time.perf_counter()-started,no_SBC_uniformity_claim=True,no_publication_or_global_response_approval=True)
            final=output/'campaign_complete.json'
            if final.exists():
                old=read_json(final)
                if old['driver_identity']!=plan['driver_identity'] or old['targets']!=result['targets']:raise RuntimeError('Completed campaign identity changed.')
                write_json_new(state/f'attempt_{attempt:04d}.end.json',dict(status='COMPLETED_ALREADY_VERIFIED',ledger=ledger.totals(),completed=len(done)))
                return old
            write_json_new(final,result);write_json_new(state/f'attempt_{attempt:04d}.end.json',dict(status='COMPLETED',ledger=ledger.totals(),completed=len(done)));return result
        except BaseException as exc:
            write_json_new(state/f'attempt_{attempt:04d}.end.json',dict(status='STOPPED_COMPUTATIONAL_OR_INTEGRITY_ERROR',completed_targets=sorted(done),ledger=ledger.totals(),error_type=type(exc).__name__,error=str(exc)))
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    required = ('repository','runtime_source','experiment','data','table','table_manifest',
                'validation_config','run_config','gate_manifest','tested_experiment',
                'tested_generation','tested_observations','runtime_generation','domain_compatibility',
                'protocol','truth_data','cohort_index','c07_config','c07_generation','output')
    for name in required: parser.add_argument('--'+name.replace('_','-'), type=Path, required=True)
    for name in ('truth_logl','runtime_authorization','driver_authorization','c07_release_receipt',
                 'native_library','native_build_manifest','plan_file'):
        parser.add_argument('--'+name.replace('_','-'), type=Path)
    parser.add_argument('--variant',choices=('C_beta','C_full'),required=True)
    parser.add_argument('--threads',type=int,default=1)
    parser.add_argument('--training-threads',type=int,default=1)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--resume',action='store_true')
    args = parser.parse_args()
    cls = runtime_factory(args.runtime_source)
    runtime = cls(args.experiment,args.data,args.table,args.table_manifest,args.validation_config,
        args.run_config,args.gate_manifest,response_variant=args.variant,
        tested_experiment_path=args.tested_experiment,tested_generation_path=args.tested_generation,
        tested_observations_path=args.tested_observations,runtime_generation_path=args.runtime_generation,
        domain_compatibility_path=args.domain_compatibility,
        execution_authorization_path=args.runtime_authorization,c07_release_receipt_path=args.c07_release_receipt,
        native_library_path=args.native_library,native_build_manifest_path=args.native_build_manifest,
        threads=args.threads,training_threads=args.training_threads,build=False)
    context = dict(cohort_index=args.cohort_index,c07_config=args.c07_config,c07_generation=args.c07_generation)
    try:
        plan = campaign_plan(runtime,args.protocol,args.truth_data,args.truth_logl,args.output,
                             context=context,driver_authorization_path=args.driver_authorization)
        if args.plan_file: write_json_new(args.plan_file,plan)
        print(json.dumps({k:v for k,v in plan.items() if k not in ('target_index','training_blocks','production_blocks','all_target_ids')}),flush=True)
        if args.execute:
            result = run_c08_campaign(runtime,plan,args.protocol,args.truth_data,args.truth_logl,
                plan['output'],context=context,resume=args.resume)
            print(json.dumps(result),flush=True)
    finally: runtime.close()


if __name__ == '__main__': main()
