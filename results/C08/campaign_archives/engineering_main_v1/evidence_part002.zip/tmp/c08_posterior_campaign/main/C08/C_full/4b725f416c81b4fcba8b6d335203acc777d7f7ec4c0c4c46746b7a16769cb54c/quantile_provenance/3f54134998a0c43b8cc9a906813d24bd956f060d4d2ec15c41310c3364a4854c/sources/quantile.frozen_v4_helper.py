"""Prospective C08 brackets from cuts chosen using only independent LOW output.

No high samples are accepted by freeze_cuts. The deterministic CDF uncertainty
must be supplied with an evidence status; finite off-grid logL checks alone do
not certify a uniform bound. The normal simultaneous band remains an
operational asymptotic inference diagnostic, not finite-sample exact coverage.
"""
import hashlib,json
import numpy as np
from scipy.stats import norm
OFFSETS=np.array([0.]+[sign*x for x in [.0005,.001,.002,.004,.008,.016,.032,.064,.128,.256] for sign in [-1.,1.]])

def freeze_cuts(independent_low_cuts):
 low=np.asarray(independent_low_cuts)
 if low.dtype.kind not in 'fiu' or low.shape!=(5,4) or not np.isfinite(low).all() or np.any((low<0)|(low>1)):raise ValueError('Finite five-parameter, four-quantile independent LOW cuts in[0,1] required')
 result=[[np.unique(np.r_[0.,1.,np.clip(low[j,q]+OFFSETS,0.,1.)]).tolist() for q in range(4)] for j in range(5)]
 return dict(schema='C08_FROZEN_QUANTILE_ENDPOINTS_v1',low_cuts_sha256=hashlib.sha256(np.ascontiguousarray(low,dtype=np.float64).tobytes()).hexdigest(),cuts=result,maximum_count=23,actual_count=sum(len(x) for row in result for x in row),uses_high=False,uses_truth=False)

def bracket(cuts,cdf,mcse,probability,*,family_tests,alpha,deterministic_cdf_error,deterministic_status):
 x=np.asarray(cuts,float);f=np.asarray(cdf,float);s=np.asarray(mcse,float)
 if x.ndim!=1 or f.shape!=x.shape or s.shape!=x.shape or len(x)<2 or x[0]!=0 or x[-1]!=1 or np.any(np.diff(x)<=0):raise ValueError('Ordered unique cuts spanning the exact support required')
 if not np.isfinite(x).all() or not np.isfinite(f).all() or np.any((f<0)|(f>1)) or np.any(s<0) or np.any(np.isnan(s)) or not 0<probability<1:raise ValueError('Invalid CDF or MCSE')
 if isinstance(family_tests,bool) or not isinstance(family_tests,(int,np.integer)) or family_tests<1 or not 0<alpha<1:raise ValueError('Explicit positive family size and alpha required')
 if deterministic_status not in ['validated_operational_envelope','rigorous_uniform_bound','unresolved']:raise ValueError('Explicit deterministic evidence status required')
 if deterministic_cdf_error is None:
  if deterministic_status!='unresolved':raise ValueError('A resolved deterministic status requires an explicit error')
  error=np.ones_like(x)
 else:
  error=np.broadcast_to(np.asarray(deterministic_cdf_error,float),x.shape)
  if not np.isfinite(error).all() or np.any((error<0)|(error>1)):raise ValueError('CDF error must be finite in[0,1]')
 z=float(norm.isf(alpha/(2*family_tests)));lower=np.maximum(0,f-z*s-error);upper=np.minimum(1,f+z*s+error)
 # Exact support statements, not an extrapolation of a numerical ECDF.
 lower[0]=upper[0]=0.;lower[-1]=upper[-1]=1.
 il=np.flatnonzero(upper<probability);ih=np.flatnonzero(lower>probability)
 lo=float(x[il[-1]]);hi=float(x[ih[0]])
 inconsistent=lo>hi
 status=('UNRESOLVED_INCONSISTENT_CDF_BAND' if inconsistent else 'UNRESOLVED_DETERMINISTIC_ERROR' if deterministic_status=='unresolved' else 'BRACKET_OPERATIONAL_ASYMPTOTIC')
 if inconsistent:lo,hi=0.,1.
 return dict(status=status,lower_quantile=lo,upper_quantile=hi,width=hi-lo,z=z,family_tests=int(family_tests),alpha=alpha,deterministic_status=deterministic_status,lower_CDF_band=lower.tolist(),upper_CDF_band=upper.tolist(),prior_unit_coordinates=True,no_horizontal_error_from_presumed_density=True)

def paired_difference(left,right):
 return dict(lower=left['lower_quantile']-right['upper_quantile'],upper=left['upper_quantile']-right['lower_quantile'],unresolved=left['status'].startswith('UNRESOLVED') or right['status'].startswith('UNRESOLVED'))
