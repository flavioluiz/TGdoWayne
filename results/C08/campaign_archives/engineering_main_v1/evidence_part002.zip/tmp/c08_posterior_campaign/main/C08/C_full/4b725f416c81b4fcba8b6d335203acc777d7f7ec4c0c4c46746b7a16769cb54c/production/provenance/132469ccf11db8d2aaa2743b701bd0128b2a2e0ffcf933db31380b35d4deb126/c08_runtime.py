"""Prospective C08 adapter around unchanged C07 training/IID libraries.

Init/preflight read metadata and hashes only; they never instantiate a bank.
The response manifest and gate schemas below are C08 contracts, not C07
physical-table validation. No spline fitting path is called. Construction of
likelihood banks requires explicit authorization and a linked C07 publication
and resource-release receipt. Synthetic fixtures can never enable execution.
"""
from pathlib import Path
import hashlib
import importlib
import json
import math
import zipfile
import numpy as np

from inference.campaign_runtime import CampaignRuntime
from inference.campaign_io import (MODELS, OBSERVATION_FIELDS, canonical_hash,
                                   load_observations, positive_int, read_json,
                                   sha256, target_ids, write_json_new)
from inference.model import experiment
from frozen_coefficient_orf_v2 import FrozenCoefficientORF

TABLE_SCHEMA = 'C08_FROZEN_COEFFICIENT_TABLE_v1'
GATE_SCHEMA = 'C08_RESPONSE_FINITE_GATES_v1'
AUTH_SCHEMA = 'C08_RUNTIME_EXECUTION_AUTHORIZATION_v1'
RELEASE_SCHEMA = 'C07_PUBLICATION_AND_RESOURCE_RELEASE_RECEIPT_v1'
GATE_LIMITS = dict(harmonic_matrix_coarse_fine=1e-8, direct_coarse_fine=1e-7,
                   direct_harmonic=1e-7, logL_coarse_fine=1e-3,
                   logL_fine_oracle=1e-3)
GEOMETRY_FIELDS = dict(directions='points', distances_ly='distance_ly', sigma='sigma',
                       red_pattern='red', frequency_hz='f', scale='scale')
LIBRARY_MODULES = (
    'campaign_runtime', 'campaign_archive', 'campaign_io', 'campaign_training',
    'campaign_iid', 'campaign_diagnostic_io', 'pointwise', 'pointwise_preallocated',
    'orf_cubic_reference', 'orf_interpolation', 'linalg_batch', 'gmm_proposal',
    'gmm_proposal_reference', 'gmm_density', 'likelihood_threads', 'gmm_fit',
    'gmm_fit_reference', 'mh_training', 'model', 'iid_diagnostics',
)


def array_sha256(array):
    """Canonical C-order bytes, without a whole-array tobytes copy."""
    if not isinstance(array, np.ndarray) or not array.flags.c_contiguous:
        raise ValueError('C-contiguous array required for canonical array hash')
    return hashlib.sha256(memoryview(array).cast('B')).hexdigest()


def array_metadata(array):
    return dict(shape=list(array.shape), dtype=array.dtype.str, nbytes=array.nbytes)


def npz_metadata(path, names):
    """Inspect only required NPY headers; never deserialize payload or truth."""
    result = {}
    with zipfile.ZipFile(path) as archive:
        for name in names:
            member = name + '.npy'
            if archive.namelist().count(member) != 1:
                raise ValueError('Missing/duplicate NPZ member: ' + name)
            info = archive.getinfo(member)
            with archive.open(member) as stream:
                version = np.lib.format.read_magic(stream)
                if version == (1, 0):
                    shape, fortran, dtype = np.lib.format.read_array_header_1_0(stream)
                elif version == (2, 0):
                    shape, fortran, dtype = np.lib.format.read_array_header_2_0(stream)
                else:
                    raise ValueError('Unsupported NPY header version')
                if dtype.hasobject or fortran or dtype.kind not in 'fciub':
                    raise ValueError('Plain C-order numeric NPZ member required: ' + name)
                nbytes = math.prod(shape) * dtype.itemsize
                if info.file_size != stream.tell() + nbytes:
                    raise ValueError('NPY payload length differs from header: ' + name)
                result[name] = dict(shape=list(shape), dtype=dtype.str, nbytes=nbytes)
    return result


def _digest(value, label):
    if (not isinstance(value, str) or len(value) != 64
            or any(c not in '0123456789abcdef' for c in value)):
        raise ValueError('Expected SHA256: ' + label)
    return value


class C08Runtime(CampaignRuntime):
    """Own C08 init/build/preflight; generic C07 methods remain unchanged."""
    def __init__(self, experiment_path, data_path, table_path, table_manifest_path,
                 validation_config_path, settings_path, gate_manifest_path, *,
                 response_variant, execution_authorization_path=None,
                 c07_release_receipt_path=None, build=False, threads=1,
                 training_threads=1, native_library_path=None,
                 native_build_manifest_path=None):
        # Deliberately do not call CampaignRuntime.__init__ or .build.
        if response_variant not in ('C_beta', 'C_full'):
            raise ValueError('Explicit C_beta or C_full response variant required')
        self.response_variant = response_variant
        self.scientific_models = [response_variant+'_CN', response_variant+'_G']
        self.paths = {k: Path(v).resolve() for k, v in dict(
            experiment=experiment_path, data=data_path, table=table_path,
            table_manifest=table_manifest_path, validation_config=validation_config_path,
            settings=settings_path, response_gates=gate_manifest_path).items()}
        for key, path in (('execution_authorization', execution_authorization_path),
                          ('c07_release_receipt', c07_release_receipt_path)):
            if path is not None:
                self.paths[key] = Path(path).resolve()
        self.cfg = read_json(self.paths['experiment'])
        self.settings = read_json(self.paths['settings'])
        self.validation_config = read_json(self.paths['validation_config'])
        self.manifest = read_json(self.paths['table_manifest'])
        self.gates = read_json(self.paths['response_gates'])
        self._validate_configuration()
        self.exp = experiment(self.cfg)
        self.bounds = np.asarray(self.cfg['prior']['bounds'], dtype=float)
        self.n = positive_int(self.cfg['n_realizations'], 'dataset count')
        self.table_metadata = npz_metadata(self.paths['table'], ('nodes', 'matrices', 'coeff'))
        self.observation_metadata = npz_metadata(self.paths['data'], OBSERVATION_FIELDS)
        self.observation_geometry_metadata = npz_metadata(self.paths['data'], GEOMETRY_FIELDS)
        self._validate_dimensions()
        self.native_library = None
        self.native_build_record = None
        self.backend_factory = None
        if native_library_path is not None:
            if native_build_manifest_path is None:
                raise ValueError('Explicit native build manifest required')
            self.native_library = Path(native_library_path).resolve()
            self.paths['native_library'] = self.native_library
            self.paths['native_build_manifest'] = Path(native_build_manifest_path).resolve()
            self.native_build_record = read_json(self.paths['native_build_manifest'])
            record = self.native_build_record
            if record.get('binary_sha256') != sha256(self.native_library):
                raise ValueError('Native binary/build-manifest mismatch')
            recipe = record['recipe']
            if hashlib.sha256(json.dumps(recipe, sort_keys=True).encode()).hexdigest() != record['recipe_sha256']:
                raise ValueError('Native recipe digest mismatch')
        elif native_build_manifest_path is not None:
            raise ValueError('Native build manifest requires a library')
        self.input_hashes = {key: sha256(path) for key, path in self.paths.items()}
        self._validate_response_evidence()
        self.threads = positive_int(threads, 'production threads')
        self.training_threads = positive_int(training_threads, 'training threads')
        self.thread_plan = dict(training=self.training_threads, production=self.threads)
        self.phase = None
        self._initialize_sources()
        self.targets, self.target_index = self._targets()
        base_inputs = {k: v for k, v in self.input_hashes.items()
                       if k not in ('execution_authorization', 'c07_release_receipt')}
        self.target_identity = canonical_hash(dict(
            schema='C08_TARGET_IDENTITY_v1', response_variant=response_variant,
            inputs={k: v for k, v in base_inputs.items()
                    if k not in ('settings', 'native_library', 'native_build_manifest')},
            stored_array_sha256=self.manifest['array_sha256'],
            expanded_array_sha256=self.manifest['expanded_array_sha256']))
        self.identity = canonical_hash(dict(
            schema='C08_EXECUTION_IDENTITY_v1', target_identity=self.target_identity,
            inputs=base_inputs, sources=self.source_hashes, thread_plan=self.thread_plan,
            backend='native' if self.native_library else 'numpy_reference'))
        self.table = self.reference = self.data = self.likelihood = self.engine = None
        self.likelihood_evaluations = 0
        self._contract_sha256 = self._contract_digest()
        self.bounds.flags.writeable = False
        for array in self.exp.values():
            if isinstance(array, np.ndarray):
                array.flags.writeable = False
        # Metadata-only validation includes numeric and likelihood-count caps.
        self.preflight()
        if build:
            self.build()

    def _validate_configuration(self):
        c = self.cfg
        if (c.get('response_variant') != self.response_variant
                or c.get('models') != self.scientific_models
                or c.get('prior', {}).get('kind') != 'independent uniform in these coordinates'
                or c.get('fixed_red_slope') != 4 or c.get('positive_channels') != [1, 2, 3, 4]):
            raise ValueError('Own C08 configuration with four positive channels required')
        if not 4 <= positive_int(c['n_pulsars'], 'pulsar count') <= 16:
            raise ValueError('C08 adapter supports 4 through 16 pulsars')
        bounds = np.asarray(c['prior']['bounds'], dtype=float)
        if (bounds.shape != (5, 2) or not np.isfinite(bounds).all()
                or np.any(bounds[:, 0] >= bounds[:, 1]) or not np.array_equal(bounds[0], [0., 1.])):
            raise ValueError('Five proper prior bounds and u support [0,1] required')
        if (self.validation_config.get('response_variant') != self.response_variant
                or self.validation_config.get('parameters') != c.get('parameters')
                or self.validation_config.get('prior') != c['prior']):
            raise ValueError('C08 validation domain/configuration mismatch')

    def _validate_dimensions(self):
        h = self.table_metadata
        shape = h['matrices']['shape']
        nshape = h['nodes']['shape']
        stored_K = shape[1] if len(shape) == 4 else None
        if (len(nshape) != 1 or not 2 <= nshape[0] <= 10000
                or stored_K not in ((4,) if self.response_variant == 'C_beta' else (1, 4))
                or shape != [nshape[0], stored_K, self.cfg['n_pulsars'], self.cfg['n_pulsars']]
                or h['coeff']['shape'] != [nshape[0]-1, 4, *shape[1:]]
                or h['nodes']['dtype'] != np.dtype('float64').str
                or any(h[k]['dtype'] != np.dtype('complex128').str for k in ('matrices', 'coeff'))):
            raise ValueError('Canonical float64/complex128 C08 table dimensions required')
        self.N, self.K, self.P, self.D = nshape[0], 4, shape[2], len(self.exp['H'])
        self.stored_K = stored_K
        expected = dict(q=([self.n, self.K, self.P], np.dtype('complex128').str),
                        x_physical=([self.n, self.K, self.D], np.dtype('float64').str),
                        x_gaussian=([self.n, self.K, self.D], np.dtype('float64').str))
        if any(self.observation_metadata[k]['shape'] != shape
               or self.observation_metadata[k]['dtype'] != dtype
               for k, (shape, dtype) in expected.items()):
            raise ValueError('Observation headers differ from C08 experiment dimensions')
        if any(self.observation_geometry_metadata[key] != array_metadata(self.exp[name])
               for key, name in GEOMETRY_FIELDS.items()):
            raise ValueError('Observation geometry headers differ from C08 experiment')

    def _validate_response_evidence(self):
        m, g = self.manifest, self.gates
        if (m.get('schema') != TABLE_SCHEMA or m.get('status') != 'FROZEN_COEFFICIENT_TABLE'
                or m.get('response_variant') != self.response_variant
                or m.get('coordinate') != 'minus_beta' or m.get('runtime_channels') != 4
                or m.get('file_sha256') != self.input_hashes['table']
                or m.get('array_metadata') != self.table_metadata):
            raise ValueError('Own C08 table manifest/file/metadata identity required; C07 manifests rejected')
        expected_rule = ('all_channels_as_stored' if self.response_variant == 'C_beta'
                         else 'repeat_first_channel_to_four' if self.stored_K == 1
                         else 'all_channels_stored_identical_first')
        if m.get('expansion_rule') != expected_rule:
            raise ValueError('C08 response expansion rule mismatch')
        for field in ('array_sha256', 'expanded_array_sha256'):
            if set(m.get(field, {})) != {'nodes', 'matrices', 'coeff'}:
                raise ValueError('Every stored/expanded array needs an explicit hash')
            for key, value in m[field].items():
                _digest(value, field+'.'+key)
        if self.stored_K == 4 and m['expanded_array_sha256'] != m['array_sha256']:
            raise ValueError('Four stored channels must be used without expansion')
        bindings = dict(table_file_sha256=self.input_hashes['table'],
                        experiment_sha256=self.input_hashes['experiment'],
                        validation_config_sha256=self.input_hashes['validation_config'],
                        observations_sha256=self.input_hashes['data'])
        if (g.get('schema') != GATE_SCHEMA or g.get('status') != 'PASS_STATED_RESPONSE_GATES_ONLY'
                or g.get('response_variant') != self.response_variant
                or g.get('purpose') not in ('response_validation', 'synthetic_contract_test')
                or any(g.get(k) != v for k, v in bindings.items())
                or g.get('array_sha256') != m['array_sha256']
                or g.get('expanded_array_sha256') != m['expanded_array_sha256']):
            raise ValueError('Own response-specific C08 finite gate and exact input bindings required')
        if g.get('thresholds') != GATE_LIMITS or set(g.get('maxima', {})) != set(GATE_LIMITS):
            raise ValueError('Unchanged registered C08 gate thresholds required')
        if set(g.get('provenance', {})) != set(GATE_LIMITS):
            raise ValueError('Every C08 gate maximum needs explicit scoped provenance')
        for key, limit in GATE_LIMITS.items():
            value = g['maxima'][key]
            if (isinstance(value, bool) or not isinstance(value, (int, float))
                    or not math.isfinite(value) or not 0 <= value <= limit):
                raise ValueError('C08 finite gate did not pass: '+key)
            self._gate_evidence(key, g['provenance'][key], allow_inherited=not key.startswith('logL_'))
        additional = g.get('additional_checks', [])
        if not isinstance(additional, list):
            raise ValueError('Additional response checks must be an explicit list')
        names = set()
        for check in additional:
            if (not isinstance(check, dict) or not isinstance(check.get('name'), str)
                    or not check['name'] or check['name'] in names or check.get('status') != 'PASS'):
                raise ValueError('Malformed/failed additional C08 response check')
            names.add(check['name'])
            error, tolerance = check.get('maximum_error'), check.get('absolute_tolerance')
            if (any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
                    for v in (error, tolerance)) or tolerance <= 0 or not 0 <= error <= tolerance):
                raise ValueError('Additional C08 response check exceeds its explicit tolerance')
            self._gate_evidence(check['name'], check.get('provenance'), allow_inherited=False)

    def _gate_evidence(self, name, evidence, *, allow_inherited):
        if not isinstance(evidence, dict):
            raise ValueError('Gate needs scoped evidence: '+name)
        inherited = (allow_inherited and self.response_variant == 'C_full'
                     and evidence.get('scope') == 'inherited_first_channel'
                     and type(evidence.get('channel')) is int and evidence['channel'] == 1
                     and isinstance(evidence.get('inherited_from_variant'), str)
                     and bool(evidence['inherited_from_variant']))
        current = evidence.get('scope') == 'current_response' and evidence.get('response_variant') == self.response_variant
        if not (inherited or current):
            raise ValueError('Gate provenance cannot transfer this check across responses: '+name)
        if not isinstance(evidence.get('source_field'), str) or not evidence['source_field']:
            raise ValueError('Gate evidence needs an explicit source field: '+name)
        path = Path(evidence['path'])
        if not path.is_absolute():
            path = self.paths['response_gates'].parent/path
        path = path.resolve()
        digest = _digest(evidence.get('sha256'), 'gate evidence '+name)
        if sha256(path) != digest:
            raise ValueError('Gate evidence artifact hash mismatch: '+name)
        key = 'gate_evidence_'+name
        if key in self.paths:
            raise ValueError('Duplicate gate evidence key: '+name)
        self.paths[key], self.input_hashes[key] = path, digest

    def _initialize_sources(self):
        modules = list(LIBRARY_MODULES)
        if 'gaussian_broadening' in self.settings.get('training', {}):
            modules.append('proposal_broadening')
        if self.native_library:
            modules.append('native_likelihood')
        self.source_paths = {name: Path(importlib.util.find_spec('inference.'+name).origin)
                             for name in modules}
        self.source_paths.update(c08_runtime=Path(__file__).resolve(),
                                 frozen_coefficient_orf_v2=Path(__file__).with_name('frozen_coefficient_orf_v2.py').resolve())
        pta_root = Path(next(iter(importlib.util.find_spec('pta').submodule_search_locations)))
        self.source_paths.update({'pta.'+p.stem: p for p in pta_root.glob('*.py')})
        if self.native_library:
            cpp = self.source_paths['native_likelihood'].parent/'native'/'likelihood.cpp'
            if sha256(cpp) != self.native_build_record['recipe']['source_sha256']:
                raise ValueError('Native C++ source differs from build manifest')
            self.source_paths['native_cpp'] = cpp
        self.source_hashes = {name: sha256(path) for name, path in self.source_paths.items()}

    def _targets(self):
        models = self.settings.get('models', self.scientific_models)
        if (not isinstance(models, list) or not models or len(set(models)) != len(models)
                or any(m not in self.scientific_models for m in models)):
            raise ValueError('External model selection must name this C08 variant')
        mapping = dict(zip(self.scientific_models, ('B_CN', 'B_G')))
        requested = self.settings.get('targets')
        if requested is None:
            requested = [dict(model=m, datum=j) for m in models for j in range(self.n)]
        if not isinstance(requested, list) or not requested:
            raise ValueError('Explicit targets must be C08 model/datum descriptors')
        ids, index = [], []
        for row in requested:
            if not isinstance(row, dict) or set(row) != {'model', 'datum'} or row['model'] not in models:
                raise ValueError('Explicit targets must be C08 model/datum descriptors')
            datum = positive_int(row['datum'], 'datum', allow_zero=True)
            if datum >= self.n:
                raise ValueError('Datum outside experiment')
            kernel = mapping[row['model']]
            target = MODELS.index(kernel)*self.n+datum
            ids.append(target)
            index.append(dict(model=row['model'], datum=datum, internal_kernel=kernel,
                              internal_target=target, external_target=f"{row['model']}:{datum}"))
        targets = target_ids(dict(models=[mapping[m] for m in models], targets=ids), self.n)
        return targets, index

    def _memory_plan(self):
        budget = self.settings['budget']
        tile = min(positive_int(budget.get('validation_tile_size', 128), 'validation_tile_size'), self.N)
        N, I, K, P, D = self.N, self.N-1, self.K, self.P, self.D
        coefficient, matrix = 4*I*K*P*P*16, N*K*P*P*16
        owned = 16*N+coefficient+matrix
        workspace, eigen = 41*tile*K*P*P, 8*tile*K*P
        raw = sum(r['nbytes'] for r in self.table_metadata.values())
        expansion = matrix+coefficient if self.stored_K == 1 else 0
        observation = sum(r['nbytes'] for r in self.observation_metadata.values())
        observation_read_scratch = max(r['nbytes'] for r in (
            *self.observation_metadata.values(), *self.observation_geometry_metadata.values()))
        experiment_bytes = sum(v.nbytes for v in self.exp.values() if isinstance(v, np.ndarray))
        meanbank, covbank = 8*I*K*6*D, 8*I*K*21*D*D
        y_z = 2*self.n*K*D*8+2*self.n*D*8
        backend = positive_int(budget['backend_workspace_allowance_bytes'], 'backend workspace allowance', allow_zero=True)
        bank_scratch = 128*1024**2  # Matches the reference builder's declared allowance.
        # Public observation-only loading may precede table loading.
        loader_peak = raw+expansion+owned+workspace+eigen+observation
        observation_peak = owned+observation+observation_read_scratch
        reference_peak = owned+observation+meanbank+covbank+y_z+bank_scratch
        packed = 8*I*K*21*D*(D+1)//2
        native_owned = (16*N+coefficient+meanbank+packed+observation+y_z
                        +8*(10+3*K+4*P)) if self.native_library else 0
        # The unchanged native wrapper still uses broad Hermiticity/symmetry
        # temporaries. Budget them explicitly instead of hiding them in loader.
        native_validation = max(3*coefficient, 3*covbank, 2*packed) if self.native_library else 0
        native_peak = (owned+observation+meanbank+covbank+y_z+native_owned
                       +native_validation+bank_scratch) if self.native_library else 0
        total = max(loader_peak, observation_peak, reference_peak, native_peak)+experiment_bytes+backend
        loader_cap = positive_int(budget['maximum_loader_owned_numeric_bytes'], 'maximum_loader_owned_numeric_bytes')
        if owned+workspace+eigen > loader_cap:
            raise RuntimeError('C08 loader owned numeric budget exceeded before table loading')
        if total > positive_int(budget['maximum_numeric_bytes'], 'maximum_numeric_bytes'):
            raise RuntimeError('C08 simultaneous numeric budget exceeded before table loading')
        return dict(table_source_arrays_bytes=raw, C_full_expansion_arrays_bytes=expansion,
                    loader_owned_persistent_bytes=owned, loader_workspace_bytes=workspace,
                    loader_eigenvalue_result_bytes=eigen, loader_peak_with_caller_bytes=loader_peak,
                    observation_arrays_bytes=observation, reference_meanbank_bytes=meanbank,
                    reference_covbank_bytes=covbank, reference_construction_allowance_bytes=bank_scratch,
                    reference_peak_bytes=reference_peak, native_owned_estimate_bytes=native_owned,
                    native_validation_temporary_allowance_bytes=native_validation,
                    native_construction_peak_bytes=native_peak, experiment_arrays_bytes=experiment_bytes,
                    backend_workspace_allowance_bytes=backend, estimated_numeric_bytes=total,
                    validation_tile_size=tile, RSS_guarantee=False,
                    scope='simultaneous construction arrays including table caller+owned, '
                          'reference bank and native copies; explicit backend allowance; '
                          'Python/allocator/file-cache overhead and production batches/raw are additional')

    def _execution_pending(self):
        pending = []
        publication = None
        if self.gates['purpose'] == 'synthetic_contract_test':
            pending.append('Synthetic gate permits representation tests only, never execution.')
        release_hash = self.input_hashes.get('c07_release_receipt')
        if not release_hash:
            pending.append('C07 publication and workers/memory release receipt is absent.')
        else:
            release = read_json(self.paths['c07_release_receipt'])
            if (release.get('schema') != RELEASE_SCHEMA or release.get('status') != 'C07_PUBLISHED_AND_RELEASED'
                    or release.get('scope') != 'C07_PUBLISHED_AND_WORKERS_MEMORY_RELEASED'
                    or release.get('released_for_c08') is not True
                    or type(release.get('active_workers')) is not int or release['active_workers'] != 0):
                raise ValueError('C07 must be published and resources released; invalid receipt')
            _digest(release.get('c07_runtime_identity'), 'C07 runtime identity')
            publication = release.get('publication')
            if not isinstance(publication, dict):
                raise ValueError('C07 publication evidence is required before posteriors')
            commit, tag = publication.get('commit'), publication.get('tag')
            if (publication.get('status') != 'PUBLISHED'
                    or not isinstance(commit, str) or len(commit) not in (40, 64)
                    or any(c not in '0123456789abcdef' for c in commit)
                    or not isinstance(tag, str) or not tag.strip()
                    or not isinstance(publication.get('release_url'), str)
                    or not publication['release_url'].startswith('https://')):
                raise ValueError('C07 published commit/tag/release evidence is incomplete')
            publication_evidence = publication.get('evidence')
            if not isinstance(publication_evidence, dict) or set(publication_evidence) != {'path', 'sha256'}:
                raise ValueError('C07 publication needs a hashed evidence artifact')
            publication_path = Path(publication_evidence['path'])
            if not publication_path.is_absolute():
                publication_path = self.paths['c07_release_receipt'].parent/publication_path
            if sha256(publication_path) != _digest(publication_evidence['sha256'], 'publication evidence'):
                raise ValueError('C07 publication evidence hash mismatch')
            evidence = release.get('evidence')
            if not isinstance(evidence, list) or not evidence:
                raise ValueError('C07 release receipt needs hashed release evidence')
            for item in evidence:
                if not isinstance(item, dict) or set(item) != {'path', 'sha256'}:
                    raise ValueError('Malformed C07 release evidence')
                path = Path(item['path'])
                if not path.is_absolute():
                    path = self.paths['c07_release_receipt'].parent/path
                if sha256(path) != _digest(item['sha256'], 'release evidence'):
                    raise ValueError('C07 release evidence hash mismatch')
        if 'execution_authorization' not in self.paths:
            pending.append('Explicit C08 runtime execution authorization is absent.')
        else:
            authorization = read_json(self.paths['execution_authorization'])
            if (authorization.get('schema') != AUTH_SCHEMA
                    or authorization.get('scope') != 'C08_TRAINING_AND_IID_ONLY'
                    or authorization.get('execution_allowed') is not True
                    or authorization.get('runtime_identity') != self.identity
                    or authorization.get('target_identity') != self.target_identity
                    or authorization.get('response_variant') != self.response_variant
                    or authorization.get('budget_sha256') != canonical_hash(self.settings['budget'])
                    or not release_hash or authorization.get('c07_release_receipt_sha256') != release_hash
                    or publication is None or authorization.get('c07_published_commit') != publication['commit']
                    or authorization.get('c07_published_tag') != publication['tag']
                    or authorization.get('c07_publication_evidence_sha256') != publication['evidence']['sha256']):
                raise ValueError('C08 authorization must bind this runtime, budget, C07 publication and release receipt')
        return pending

    def preflight(self):
        self.verify_unchanged()
        s = self.settings
        training, production, budget = s.get('training', {}), s.get('production', {}), s['budget']
        memory = self._memory_plan()
        pending = self._execution_pending()
        steps, levels = training.get('steps'), production.get('levels')
        chains = positive_int(training.get('chains', 4), 'chains')
        if chains != 4 or production.get('replicates', 4) != 4:
            raise ValueError('Exactly four training chains and IID replicates required')
        if steps is None:
            pending.append('C08 training length is not frozen.')
        else:
            positive_int(steps, 'training steps')
            selected = positive_int(training.get('points_for_em', 2048), 'EM points')
            if steps < 1000 or selected % chains or steps//2 < selected//chains:
                raise ValueError('Training length/selection violates the unchanged C07 library design')
        if levels is None:
            pending.append('C08 IID lengths are not frozen.')
        elif (not isinstance(levels, list) or len(levels) != 2
              or any(positive_int(x, 'IID level') != x for x in levels)
              or levels != sorted(set(levels))):
            raise ValueError('Two increasing positive IID levels required')
        if training.get('approved') is not True:
            pending.append('C08 cold-training settings are not approved.')
        if s.get('execution_enabled') is not True:
            pending.append('Prospective C08 settings deliberately disable execution.')
        for phase, phase_settings in (('training', training), ('production', production)):
            if phase_settings.get('seed') is None:
                pending.append('C08 '+phase+' RNG seed is not frozen.')
            else:
                positive_int(phase_settings['seed'], phase+' seed', allow_zero=True)
        active = positive_int(s.get('production_targets_per_block', 16), 'production block size')
        training_active = positive_int(s.get('training_targets_per_block', 64), 'training block size')
        batch = positive_int(production.get('likelihood_batch', 512), 'likelihood batch')
        training_work = None if steps is None else (steps+1)*chains*len(self.targets)
        production_work = None if levels is None else sum(levels)*4*len(self.targets)
        work = None if training_work is None or production_work is None else training_work+production_work
        for field, amount in (('maximum_training_likelihood_values', training_work),
                              ('maximum_production_likelihood_values', production_work),
                              ('maximum_total_likelihood_values', work)):
            cap = positive_int(budget[field], field)
            if amount is not None and amount > cap:
                raise RuntimeError('C08 likelihood-count budget exceeded: '+field)
        raw_per_target = 0 if levels is None else sum(levels)*4*(14*8+1)+len(levels)*4*65536
        raw_block = raw_per_target*min(active, len(self.targets))
        if raw_block > positive_int(budget['maximum_active_raw_bytes'], 'maximum_active_raw_bytes'):
            raise RuntimeError('C08 active raw budget exceeded')
        batch_bytes = batch*self.K*(self.P*self.P*16+21*self.D*self.D*8)
        # C07 IID allocates several target-sized raw arrays; retain a separate
        # conservative allowance instead of folding it into the loader cap.
        production_numeric = memory['estimated_numeric_bytes']+3*raw_per_target+batch_bytes
        training_workspace = None
        training_numeric = None
        if steps is not None:
            concurrent = min(training_active, len(self.targets))
            history = min(4000, steps)*chains*concurrent*5*8
            retained = selected*concurrent*5*8
            training_batch = concurrent*chains*self.K*(self.P*self.P*16+21*self.D*self.D*8)
            # Conservative arrays for history/asarray/centering, retained-state
            # stacking/reshaping, and a full training likelihood batch.
            training_workspace = 4*history+3*retained+training_batch
            training_numeric = memory['estimated_numeric_bytes']+training_workspace
        numeric = max(production_numeric, training_numeric or 0)
        if numeric > budget['maximum_numeric_bytes']:
            raise RuntimeError('C08 training/production arrays plus runtime numeric budget exceeded')
        return dict(schema='C08_RUNTIME_PREFLIGHT_v1', identity=self.identity,
                    target_identity=self.target_identity, response_variant=self.response_variant,
                    models=self.settings.get('models', self.scientific_models), datasets=self.n,
                    targets=len(self.targets), target_index=self.target_index,
                    memory=memory, estimated_numeric_bytes=numeric,
                    estimated_production_numeric_bytes=production_numeric,
                    estimated_training_numeric_bytes=training_numeric,
                    estimated_training_workspace_bytes=training_workspace,
                    estimated_active_raw_bytes=raw_block, production_likelihood_values=production_work,
                    training_likelihood_values_including_initialization=training_work,
                    planned_training_plus_production_likelihood_values=work,
                    likelihood_evaluations_this_process=self.likelihood_evaluations,
                    production_blocks=[self.targets[i:i+active].tolist() for i in range(0, len(self.targets), active)],
                    training_blocks=[self.targets[i:i+training_active].tolist() for i in range(0, len(self.targets), training_active)],
                    pending=pending, execution_ready=not pending, input_sha256=self.input_hashes,
                    truth_deserialized=False, response_gate_purpose=self.gates['purpose'],
                    response_gate_provenance=self.gates['provenance'],
                    additional_response_checks=self.gates.get('additional_checks', []),
                    posterior_precision_claimed=False, thread_plan=self.thread_plan)

    def _contract_digest(self):
        return canonical_hash(dict(config=self.cfg, settings=self.settings,
                                   validation_config=self.validation_config,
                                   table_manifest=self.manifest, gates=self.gates,
                                   table_metadata=self.table_metadata,
                                   observation_metadata=self.observation_metadata,
                                   observation_geometry_metadata=self.observation_geometry_metadata,
                                   target_index=self.target_index, targets=self.targets.tolist(),
                                   response_variant=self.response_variant,
                                   thread_plan=self.thread_plan))

    def verify_unchanged(self):
        super().verify_unchanged()
        if self._contract_digest() != self._contract_sha256:
            raise RuntimeError('In-memory C08 configuration/identity contract changed')

    def load_table(self):
        """Validate/own a frozen representation without constructing a bank."""
        if self.table is not None:
            return self.table
        self.verify_unchanged()
        self._memory_plan()
        with np.load(self.paths['table'], allow_pickle=False) as source:
            arrays = {name: source[name] for name in ('nodes', 'matrices', 'coeff')}
        for name, array in arrays.items():
            if array_metadata(array) != self.table_metadata[name] or array_sha256(array) != self.manifest['array_sha256'][name]:
                raise ValueError('Stored C08 array hash/metadata mismatch: '+name)
        if self.stored_K == 1:
            expanded = dict(nodes=arrays['nodes'])
            for name, axis in (('matrices', 1), ('coeff', 2)):
                shape = list(arrays[name].shape)
                shape[axis] = self.K
                expanded[name] = np.empty(shape, dtype=np.complex128)
                np.copyto(expanded[name], arrays[name])
        else:
            expanded = arrays
        if self.response_variant == 'C_full' and self.stored_K == 4:
            tile = self.settings['budget'].get('validation_tile_size', 128)
            for name in ('matrices', 'coeff'):
                source = arrays[name]
                for start in range(0, len(source), tile):
                    block = source[start:start+tile]
                    first = block[:, 0] if name == 'matrices' else block[:, :, 0]
                    first_hash = array_sha256(np.ascontiguousarray(first))
                    for channel in range(1, 4):
                        other = block[:, channel] if name == 'matrices' else block[:, :, channel]
                        if array_sha256(np.ascontiguousarray(other)) != first_hash:
                            raise ValueError('Stored C_full channels are not bit-identical to the first')
        for name, array in expanded.items():
            if array_sha256(array) != self.manifest['expanded_array_sha256'][name]:
                raise ValueError('Expanded response hash mismatch: '+name)
        table = FrozenCoefficientORF(
            expanded['nodes'], expanded['matrices'], expanded['coeff'],
            maximum_owned_numeric_bytes=self.settings['budget']['maximum_loader_owned_numeric_bytes'],
            validation_tile_size=self.settings['budget'].get('validation_tile_size', 128),
            require_C1=self.settings.get('require_C1', False))
        self.verify_unchanged()
        self.table = table
        return table

    def load_observations_only(self):
        """Use the unchanged observation-only C07 loader; never request truth."""
        if self.data is None:
            self.verify_unchanged()
            self._memory_plan()
            self.data = load_observations(self.paths['data'], self.exp)
            self.verify_unchanged()
        return self.data

    def build(self):
        report = self.preflight()
        if not report['execution_ready']:
            raise RuntimeError('C08 execution pending: '+' '.join(report['pending']))
        if self.engine is not None:
            return self
        from inference.pointwise_preallocated import PreallocatedCubicPointLikelihood
        from inference.linalg_batch import forward_substitution
        table, observations = self.load_table(), self.load_observations_only()
        reference = PreallocatedCubicPointLikelihood(
            self.exp, observations, table,
            maximum_estimated_numeric_bytes=self.settings['budget']['maximum_numeric_bytes'])
        reference.solve = forward_substitution
        self.reference = reference
        engine = reference
        if self.native_library:
            from inference.native_likelihood import NativeLikelihood
            from inference.likelihood_threads import ThreadedLikelihood
            engine = ThreadedLikelihood(NativeLikelihood(reference, self.bounds, self.native_library),
                                        max(self.thread_plan.values()))
            self.reference = self.table = None
        self.engine, self.likelihood = engine, self.counted_likelihood
        self.verify_unchanged()
        return self

    def require_execution(self):
        report = self.preflight()
        if not report['execution_ready']:
            raise RuntimeError('C08 execution pending: '+' '.join(report['pending']))
        return self.build() if self.engine is None else self

    def counted_likelihood(self, theta, targets):
        ids = np.asarray(targets)
        if ids.shape != (len(theta),) or ids.dtype.kind not in 'iu' or not np.isin(ids, self.targets).all():
            raise ValueError('Only the frozen C08 B_CN/B_G internal target routes are permitted')
        if self.engine is None:
            raise RuntimeError('C08 engine has not been explicitly enabled and built')
        return super().counted_likelihood(theta, targets)

    def namespace(self, output_root):
        return Path(output_root).resolve()/'C08'/self.response_variant/self.target_identity

    def snapshot(self, output_root):
        root = Path(output_root).resolve()
        expected = ('C08', self.response_variant, self.target_identity)
        if not any(tuple(root.parts[i:i+3]) == expected for i in range(len(root.parts)-2)):
            raise ValueError('C08 snapshots/output must live inside the variant/target namespace')
        self.verify_unchanged()
        super().snapshot(root)
        path = root/'provenance'/self.identity/'c08_manifest.json'
        record = dict(schema='C08_RUNTIME_PROVENANCE_v1', identity=self.identity,
                      target_identity=self.target_identity, response_variant=self.response_variant,
                      namespace=str(root), target_index=self.target_index,
                      response_gate_sha256=self.input_hashes['response_gates'],
                      coefficient_sha256=self.manifest['expanded_array_sha256']['coeff'],
                      internal_library_records_preserved=True, truth_deserialized=False)
        if path.exists():
            if read_json(path) != record:
                raise RuntimeError('C08 provenance namespace collision')
        else:
            write_json_new(path, record)

    def _external_record_index(self, directory, target, stage):
        source = Path(directory)/f'target_{target:06d}.json'
        record = read_json(source)
        expected = self.target_identity if stage == 'training' else self.identity
        target_row = next(r for r in self.target_index if r['internal_target'] == target)
        if (record.get('identity') != expected or record.get('target') != target
                or record.get('model') != target_row['internal_kernel']
                or record.get('datum') != target_row['datum']):
            raise ValueError('Internal C07 library record does not match C08 target routing')
        value = dict(schema='C08_EXTERNAL_TARGET_RECORD_v1', identity=self.identity,
                     target_identity=self.target_identity, response_variant=self.response_variant,
                     stage=stage, **target_row, internal_record=source.name,
                     internal_record_sha256=sha256(source), internal_record_unmodified=True)
        path = Path(directory)/f'c08_target_{target:06d}.json'
        if path.exists():
            if read_json(path) != value:
                raise RuntimeError('C08 external target index collision')
        else:
            write_json_new(path, value)
        return value

    def train_block(self, targets, output_root, *, resume=False):
        from inference.campaign_training import train_block
        directory = self.namespace(output_root)/'training'
        result = train_block(self, targets, directory, resume=resume)
        for target in targets:
            self._external_record_index(directory, int(target), 'training')
        return result

    def produce_target(self, target, output_root, *, resume=False):
        from inference.campaign_iid import produce_target
        root = self.namespace(output_root)
        result = produce_target(self, target, root/'training', root/'production', root/'raw', resume=resume)
        self._external_record_index(root/'production', int(target), 'production')
        return result
