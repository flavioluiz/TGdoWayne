"""Prospective C08 matched-high replay contracts; no observations or truth loads."""
from pathlib import Path
import importlib.util
import numpy as np
from inference.campaign_io import read_json, sha256, canonical_hash, write_json_new

MODELS = ('A0_CN', 'A_CN', 'B_CN', 'A_G', 'B_G',
          'C_beta_CN', 'C_beta_G', 'C_full_CN', 'C_full_G')
PROBABILITIES = (.05, .5, .9, .95)
HIGH_N = 65536
REPLICATES = 4
REPLAY_LL = 32*5*REPLICATES*HIGH_N
DESIGN_SHA = '188e4a0b5728b7437628152063ff4fe3cd6cbb1d8e89af8887b0824a5e40fb57'
HELPER_SHA = 'b4345a3df31ea4f7fafa34282f06a923f15c8788cce14ee917fd22ce47217c95'
DATA_SHA = '63679c96852f3c0aa1e25c8a3f087c0646ceb22cd7701758491cabdd42ac0103'
CONFIG_SHA = 'f22b0a8cd7c86e477365ea02d3b37a836458d44285b0abd323bccd174c89fdfa'
COMPLETE_SHA = '1daa0948e9d55f6537cd7c25870c609ea9e1c8019dc59dc8abea899ff6b2c9e2'
PLAN_SHA = '987804ca6b8aecb223e35975dfcfb308e64e90bb7a520cbf42ec9e2c7c83604c'


def bound_file(path, expected):
    p = Path(path).resolve()
    if not p.is_file() or sha256(p) != expected:
        raise RuntimeError('Frozen file differs: '+str(path))
    return p


def load_helper(path):
    path = bound_file(path, HELPER_SHA)
    spec = importlib.util.spec_from_file_location('c08_frozen_bracket_v4', path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def validate_cohort(index):
    if (index.get('schema') != 'C08_COHORT_ROUTING_INDEX_v1'
            or index.get('datasets') != 500 or index.get('truth_coordinates_present') is not False
            or index.get('data_sha256') != DATA_SHA or index.get('generation_config_sha256') != CONFIG_SHA
            or index.get('design_sha256') != DESIGN_SHA):
        raise ValueError('Wrong truth-free routing index/data/config/design.')
    r, s = index['representative_ids'], index['stress_ids']
    for ids, n in ((r,24),(s,8)):
        if (len(ids) != n or ids != sorted(set(ids))
                or any(type(x) is not int or not 0 <= x < 500 for x in ids)):
            raise ValueError('Invalid frozen cohort IDs.')
    if set(r)&set(s): raise ValueError('Cohort strata overlap.')
    return sorted(r+s)


def protocol():
    return dict(schema='C08_QUANTILE_REPLAY_DIAGNOSTICS_CANDIDATE_v1',
        execution_authorized=False, parent_design_sha256=DESIGN_SHA,
        algorithm_sha256=HELPER_SHA, high_samples=HIGH_N, replications=REPLICATES,
        probabilities=list(PROBABILITIES), models=list(MODELS), datasets=32,
        u95_family=6624, other19_family=125856, cdf_alpha_per_family=.025,
        deterministic_cdf_margin=.002, mcse_target=.00335,
        maximum_single_deletion_bound=.00335, maximum_saturated_weight=1e-12,
        additional_replicate_family=32*9*(20*23+1)*6,
        additional_replicate_alpha=.05,
        logZ_refinement_family=32*9, logZ_refinement_alpha=.05,
        evidence_precision_target=None,
        statistical_scope='Operational asymptotic SNIS influence; no finite-sample confidence certificate',
        decision_scope='Purpose-specific endpoints; no truth/rank test; failed common guards give [0,1]',
        new_guard_families_status='Prospective candidate requiring ROOT review before samples',
        no_ESS_binomial_interval=True, no_unseen_tail_certificate=True)


def validate_protocol(p):
    if p != protocol(): raise ValueError('Frozen candidate criteria changed.')


def freeze_low(low, *, helper, identity, model, datum, internal_target,
               source_path, source_sha256, cohort_sha256, design_sha256=DESIGN_SHA):
    """Pure cut selection. The caller supplies only the low-level 5x4 matrix."""
    if model not in MODELS or type(datum) is not int or not 0 <= datum < 500:
        raise ValueError('Unknown scientific model/datum.')
    if type(internal_target) is not int or internal_target < 0:
        raise ValueError('Explicit internal target required.')
    result = helper.freeze_cuts(low)
    result.update(schema='C08_LOW_ONLY_CUT_MANIFEST_v1', identity=identity,
                  scientific_model=model, datum=datum, internal_target=internal_target,
                  source=dict(path=str(source_path), sha256=source_sha256,
                              member='independent_cuts_unit'),
                  cohort_sha256=cohort_sha256, design_sha256=design_sha256,
                  probabilities=list(PROBABILITIES), uses_high=False, uses_truth=False)
    result['content_sha256'] = canonical_hash(result)
    return result


def verify_cut_manifest(row, helper):
    unhash = {k:v for k,v in row.items() if k != 'content_sha256'}
    if (row.get('schema') != 'C08_LOW_ONLY_CUT_MANIFEST_v1'
            or row.get('content_sha256') != canonical_hash(unhash)
            or row.get('uses_high') is not False or row.get('uses_truth') is not False
            or row.get('scientific_model') not in MODELS
            or row.get('probabilities') != list(PROBABILITIES)
            or row.get('design_sha256') != DESIGN_SHA):
        raise RuntimeError('Cut manifest contract/hash changed.')
    if len(row['cuts']) != 5 or any(len(v) != 4 for v in row['cuts']):
        raise ValueError('Twenty quantile cut lists required.')
    for lists in row['cuts']:
        for values in lists:
            a=np.asarray(values)
            if (a.dtype.kind not in 'fiu' or len(a)>23 or len(a)<2 or a[0]!=0 or a[-1]!=1
                    or not np.isfinite(a).all() or np.any(np.diff(a)<=0)):
                raise ValueError('Invalid frozen cuts.')
    return row


def read_only_low_member(path, expected_sha):
    """Never iterates NPZ fields or reads high CDFs, quantiles, PITs or truth."""
    path = bound_file(path, expected_sha)
    with np.load(path, allow_pickle=False) as npz:
        low=npz['independent_cuts_unit'].copy()
    return low


def source_closure(repository, original_manifest):
    """Metadata-only comparison; no import of a runtime, data or native binary."""
    root=Path(repository).resolve(); rows={}
    for name, expected in original_manifest['source_sha256'].items():
        if name.startswith('pta.'):
            path=root/'src'/'pta'/(name.split('.',1)[1]+'.py')
        elif name=='native_cpp': path=root/'src/inference/native/likelihood.cpp'
        else: path=root/'src/inference'/(name+'.py')
        actual=sha256(path) if path.is_file() else None
        rows[name]=dict(path=str(path), expected_sha256=expected, current_sha256=actual,
                        matches=actual==expected)
    return dict(all_match=all(r['matches'] for r in rows.values()), files=rows)


def freeze_c07(repository, campaign, cohort_path, design_path, helper_path, output):
    """160 proposals/checkpoints plus LOW compact member only. Zero high/raw/LL."""
    root=Path(repository).resolve(); campaign=Path(campaign).resolve(); output=Path(output).resolve()
    design=read_json(bound_file(design_path, DESIGN_SHA)); helper=load_helper(helper_path)
    index=read_json(cohort_path); ids=validate_cohort(index); index_sha=sha256(cohort_path)
    bound_file(campaign/'campaign_complete.json', COMPLETE_SHA)
    original_plan=read_json(bound_file(campaign/'campaign_plan.json', PLAN_SHA))
    first=read_json(campaign/'production'/f'target_{ids[0]:06d}.json')
    original_path=campaign/'provenance'/first['identity']/'manifest.json'
    original=read_json(original_path)
    rows=[]
    for mi, model in enumerate(MODELS[:5]):
        for datum in ids:
            target=mi*500+datum; prod=campaign/'production'
            receipt_path=prod/f'preserved_archive_receipt_target_{target:06d}.json'
            receipt=read_json(receipt_path)
            if (receipt['status']!='RAW_ARCHIVE_VERIFIED' or receipt['target']!=target
                    or receipt['identity']!=original['identity'] or receipt['model']!=model
                    or receipt['datum']!=datum or receipt['input_sha256']!=original['input_sha256']):
                raise RuntimeError('Original archive identity differs.')
            files={}
            # Verify only the explicitly selected, small original artifacts.
            roles=['producer','proposal','numeric']+[f'checkpoint_N65536_rep{r}' for r in range(4)]
            for role in roles:
                matches=[a for a in receipt['artifacts'] if a['role']==role]
                if len(matches)!=1: raise RuntimeError('Ambiguous/missing original role.')
                art=matches[0]; path=(prod/art['file']).resolve()
                if prod not in path.parents: raise RuntimeError('Archive path escape.')
                bound_file(path,art['sha256']); files[role]=dict(path=str(path),sha256=art['sha256'])
            producer=read_json(files['producer']['path']); proposal=read_json(files['proposal']['path'])
            if (producer['identity']!=original['identity'] or producer['target']!=target
                    or producer['model']!=model or producer['datum']!=datum
                    or producer['proposal_sha256']!=files['proposal']['sha256']
                    or producer['uses_truth'] is not False or proposal.get('uses_truth') is not False
                    or proposal['status']!='FROZEN_PROPOSAL' or proposal['target']!=target
                    or proposal['identity']!=original['target_identity']
                    or canonical_hash({k:v for k,v in proposal.items() if k!='proposal_content_hash'})!=proposal['proposal_content_hash']):
                raise RuntimeError('Original proposal/producer contract differs.')
            high=[]
            for rep in range(4):
                checkpoint=read_json(files[f'checkpoint_N65536_rep{rep}']['path'])
                matches=[r for r in producer['replicates'] if r['level']==HIGH_N and r['replicate']==rep]
                if len(matches)!=1 or checkpoint!=matches[0]: raise RuntimeError('Original checkpoint differs.')
                if (checkpoint['seed']!=907110102 or checkpoint['level_index']!=1
                        or checkpoint['samples']!=HIGH_N or checkpoint['uses_truth'] is not False
                        or checkpoint['proposal_sha256']!=files['proposal']['sha256']
                        or checkpoint['raw_compression']!='stored'
                        or receipt['raw_sha256'][checkpoint['raw_file']]!=checkpoint['raw_sha256']):
                    raise RuntimeError('Original high replay recipe differs.')
                high.append(checkpoint)
            low=read_only_low_member(files['numeric']['path'],files['numeric']['sha256'])
            frozen=freeze_low(low,helper=helper,identity=original['identity'],model=model,datum=datum,
                internal_target=target,source_path=files['numeric']['path'],source_sha256=files['numeric']['sha256'],
                cohort_sha256=index_sha)
            dest=output/'cuts'/f'target_{target:06d}.json'; write_json_new(dest,frozen)
            rows.append(dict(target=target,datum=datum,scientific_model=model,
                stratum='representative' if datum in index['representative_ids'] else 'stress',
                original_files=files,original_receipt=dict(path=str(receipt_path),sha256=sha256(receipt_path)),
                cut_manifest=dict(path=str(dest),sha256=sha256(dest)),high_checkpoints=high))
    closure=source_closure(root,original)
    plan=dict(schema='C08_C07_HIGH_REPLAY_PLAN_v1',status='PROSPECTIVE_FROZEN_LOW_CUTS_NO_REPLAY',
        identity=original['identity'],target_identity=original['target_identity'],
        original_manifest=dict(path=str(original_path),sha256=sha256(original_path)),
        original_input_sha256=original['input_sha256'],original_source_sha256=original['source_sha256'],
        original_thread_plan=original['thread_plan'],original_backend=original['backend'],
        campaign_complete_sha256=COMPLETE_SHA,campaign_plan_sha256=PLAN_SHA,
        design_sha256=DESIGN_SHA,helper_sha256=HELPER_SHA,cohort_path=str(Path(cohort_path).resolve()),
        cohort_sha256=index_sha,source_closure=closure,rows=rows,
        counts=dict(datasets=32,targets=160,replicates=640,high_LL=REPLAY_LL,new_training_LL=0,
                    new_seeds=0,maximum_cut_endpoints=160*20*23,
                    actual_cut_endpoints=sum(read_json(r['cut_manifest']['path'])['actual_count'] for r in rows)),
        budget=dict(maximum_replay_likelihood_values=REPLAY_LL,maximum_combined_likelihood_values=110000000,
                    maximum_active_raw_bytes=1024**3,maximum_numeric_bytes=4*1024**3,active_banks=1,
                    original_estimated_numeric_bytes=original_plan['estimated_numeric_bytes'],
                    conservative_with_endpoint_workspace_bytes=original_plan['estimated_numeric_bytes']+256*1024**2,
                    actual_stored_bytes_per_target=sum(c['raw_bytes'] for c in rows[0]['high_checkpoints'])),
        execution_enabled=False,G0_publication_and_memory_release_pending=True,
        high_samples_deserialized=False,truth_deserialized=False,physical_likelihood_evaluations=0,
        requires_external_authorization=True)
    plan['content_sha256']=canonical_hash(plan)
    write_json_new(output/'replay_plan.json',plan)
    write_json_new(output/'diagnostic_protocol.json',protocol())
    return plan
