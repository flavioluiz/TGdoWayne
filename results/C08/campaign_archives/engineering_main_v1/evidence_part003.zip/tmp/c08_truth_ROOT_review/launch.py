"""External stdlib lifecycle measurement for the reviewed truth-only producer."""
from pathlib import Path
import argparse, hashlib, json, os, resource, subprocess, sys, time

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    for name in ('spec', 'approval', 'c07-release', 'g0', 'output', 'receipt', 'log'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    if args.receipt.exists() or args.log.exists() or args.output.exists():
        raise ValueError('New output, external receipt and log required.')
    root = Path(__file__).resolve().parents[2]
    command = [str(root / '.venv/bin/python'), '-B',
               str(root / 'tmp/c08_truth_diagnostic_runner/run_truth.py'), '--execute']
    bindings = {}
    for name in ('spec', 'approval', 'c07_release', 'g0'):
        path = getattr(args, name).resolve()
        command += ['--' + name.replace('_', '-'), str(path)]
        bindings[str(path)] = digest(path)
    command += ['--output', str(args.output.resolve())]
    environment = os.environ.copy()
    for key in ('VECLIB_MAXIMUM_THREADS', 'OPENBLAS_NUM_THREADS',
                'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
        environment[key] = '1'
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    start = time.perf_counter()
    with args.log.open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                env=environment)
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    child_cpu = after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime
    report = dict(schema='C08_TRUTH_EXTERNAL_LIFECYCLE_v1', command=command,
                  returncode=result.returncode, full_controller_and_descendants_CPU_seconds=child_cpu,
                  launcher_CPU_seconds=time.process_time(), elapsed_seconds=time.perf_counter()-start,
                  child_lifetime_RSS_peak_bytes=int(after.ru_maxrss if sys.platform == 'darwin'
                                                    else 1024*after.ru_maxrss),
                  input_sha256=bindings, inputs_unchanged=all(digest(p)==h for p,h in bindings.items()),
                  log_sha256=digest(args.log), no_retry=True,
                  scope='External full controller/descendant CPU including interpreter exits; RSS is largest child, not simultaneous sum.')
    end_path = args.output / 'execution_end.json'
    if end_path.exists():
        end = json.loads(end_path.read_text())
        report['execution_end_sha256'] = digest(end_path)
        report['internal_status'] = end['status']
        report['conservative_parent_plus_worker_RSS_bytes'] = end['resources']['conservative_parent_plus_worker_RSS_bytes']
    report['resource_cap_pass'] = (child_cpu + report['launcher_CPU_seconds'] <= 600
        and report.get('conservative_parent_plus_worker_RSS_bytes', 2**63) <= 1610612736)
    report['status'] = ('EXTERNAL_LIFECYCLE_PASS' if result.returncode == 0
        and report['inputs_unchanged'] and report['resource_cap_pass']
        and report.get('internal_status') == 'DIAGNOSTIC_PRODUCER_COMPLETE'
        else 'FAILED_PRESERVED_NO_RETRY')
    with args.receipt.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(report))
    if report['status'] != 'EXTERNAL_LIFECYCLE_PASS':
        raise SystemExit(1)

if __name__ == '__main__':
    main()
