# Adapter C08: coefficients, scopes and reuse of the frozen C07 library

Status: design only; no new posterior runtime instantiated and no C07 source changed.

The runtime must not call `CampaignRuntime.build`, which constructs a fresh
`EvenThresholdCubicORF(nodes, matrices)`. The C_beta common knot set contains
algebraically subdivided pieces, including the inherited first curve. A new
spline through those knots need not preserve the original coefficients.

A pure `FrozenCoefficientORF` will own `nodes`, `matrices`, `coeff`, and the
minus-beta coordinate. Its `location`/evaluation are the polynomial formulas
already tested in `curve_algebra_v2.py`. It must check finite float/complex
arrays, increasing transformed knots, exact support, coefficient shape,
continuity at nodes, Hermiticity and Bernstein PSD without clipping. It never
fits a spline. The exported C_beta file holds all four frequencies; the C_full
adapter repeats a validated first-frequency polynomial in all four channels.
The latter operation preserves the first curve exactly, but requires a new
C_full response/likelihood gate before scientific production.

A new C08 runtime constructor will establish its own identity from response
variant, input/config/source hashes, coefficient-array hashes, table file hash,
its own finite-gate report, and the frozen observation/spectral experiment.
The old physical-table manifest is provenance for inherited coefficients, not
approval of C_beta or C_full. An explicit observation-only data loader may be
reused unchanged. No truth field may enter training or proposal fitting.

The C07 `train_block`, `produce_target`, RNG recipe, GMM densities, and raw
archiving machinery can remain byte-identical library functions. Their kernel
IDs B_CN/B_G are internal routing labels for a compressed real-normal density:

| Scientific model | Internal kernel | Required table |
|---|---|---|
| C_beta_CN | B_CN | common beta_ref, actual phases per frequency |
| C_beta_G | B_G | same C_beta table, Gaussian-control observation |
| C_full_CN | B_CN | first-frequency curve repeated |
| C_full_G | B_G | same C_full table, Gaussian-control observation |

The external C08 manifest and target index must always expose the scientific
names, variant, datum, internal target ID and hashes of the unchanged internal
records. Internal library records are not rewritten or reinterpreted as C07
physical B results. Namespaced output directories and identities prevent
proposal/raw collisions between C07, C_beta and C_full.

Building uses `PreallocatedCubicPointLikelihood(exp, observations, table)` and
then `NativeLikelihood(reference, bounds, library)` with the supplied exact
coefficients. Budgets must use four frequencies after C_full expansion and
count simultaneous native/reference buffers. Training/production count caps,
thread phases, explicit enable flag and C07-release prerequisite remain
mandatory. Table validation is finite-domain evidence; final posterior
precision and checks in the C posterior region remain separate gates.

Small tests should compare explicit polynomial evaluations before/after
subdivision, coefficient ownership and shape guards, the two B-kernel routes
against direct compressed-moment Cholesky densities, a tiny native/reference
bank, identities and collision prevention. They should also demonstrate a
case in which resplining the common knot matrices changes the polynomial, so
this regression cannot silently return. No 128-posterior execution belongs
to these adapter tests.
