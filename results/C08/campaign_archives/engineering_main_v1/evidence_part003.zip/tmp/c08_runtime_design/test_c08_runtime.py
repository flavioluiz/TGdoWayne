"""Synthetic adapter contracts only; no banks, likelihoods, or ORF integrals."""
from pathlib import Path
import json
import sys
import tempfile
import unittest
from unittest.mock import patch
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT/'src'))
sys.path.insert(0, str(HERE/'src'))
from c08_runtime import (C08Runtime, TABLE_SCHEMA, GATE_SCHEMA, AUTH_SCHEMA,
                         RELEASE_SCHEMA, GATE_LIMITS, array_sha256,
                         array_metadata, npz_metadata)
from inference.campaign_io import canonical_hash, sha256, MODELS
from inference.campaign_runtime import CampaignRuntime
from inference.model import experiment


def put(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2)+'\n')


def fixture(root, variant='C_beta', *, execution=False, stored_channels=4):
    root.mkdir(parents=True)
    cfg = dict(response_variant=variant, models=[variant+'_CN', variant+'_G'],
               parameters=['u', 'log10_Agw', 'gamma_gw', 'log10_Arn', 'log10_EFAC'],
               prior=dict(kind='independent uniform in these coordinates',
                          bounds=[[0, 1], [-18, -12], [1, 7], [-18, -12], [-1, 1]]),
               fixed_red_slope=4, positive_channels=[1, 2, 3, 4], n_pulsars=4,
               n_realizations=2, geometry_seeds=[11, 12, 13],
               distance_range_light_years=[100, 1000], duration_years=18,
               cadence_days=14, frequency_weights=[.25]*4)
    valid = {k: cfg[k] for k in ('response_variant', 'parameters', 'prior')}
    settings = dict(models=cfg['models'], execution_enabled=execution,
                    training=dict(approved=execution, steps=1000, chains=4, points_for_em=1024, seed=123),
                    production=dict(levels=[2, 4], replicates=4, likelihood_batch=2, seed=124),
                    training_targets_per_block=2, production_targets_per_block=1,
                    budget=dict(maximum_numeric_bytes=2**30,
                                maximum_loader_owned_numeric_bytes=2**20,
                                backend_workspace_allowance_bytes=2**20,
                                validation_tile_size=1,
                                maximum_training_likelihood_values=100000,
                                maximum_production_likelihood_values=1000,
                                maximum_total_likelihood_values=100000,
                                maximum_active_raw_bytes=2**24))
    paths = {k: root/name for k, name in dict(experiment='experiment.json', data='observations.npz',
             table='table.npz', table_manifest='table_manifest.json',
             validation_config='validation.json', settings='settings.json', response_gates='gates.json').items()}
    put(paths['experiment'], cfg)
    put(paths['validation_config'], valid)
    put(paths['settings'], settings)
    exp = experiment(cfg)
    observation = dict(q=np.zeros((2, 4, 4), complex),
                       x_physical=np.zeros((2, 4, 10)), x_gaussian=np.zeros((2, 4, 10)),
                       directions=exp['points'], distances_ly=exp['distance_ly'],
                       sigma=exp['sigma'], red_pattern=exp['red'],
                       frequency_hz=exp['f'], scale=exp['scale'],
                       truth=np.array([{'must_not_deserialize': True}], dtype=object))
    np.savez(paths['data'], **observation)
    n = np.array([0., .5, 1.])
    factors = np.array([1., 1.2, 1.4, 1.6]) if variant == 'C_beta' else np.ones(stored_channels)
    m = np.array([1., 1.2, 2.])[:, None, None, None]*factors[None, :, None, None]*np.eye(4)[None, None]
    c = np.zeros((2, 4, len(factors), 4, 4), complex)
    c[:, 0] = m[:-1]
    c[0, 1] = .2*factors[:, None, None]*np.eye(4)
    c[1, 1] = 1.6*factors[:, None, None]*np.eye(4)
    c[1, 2] = -.8*factors[:, None, None]*np.eye(4)
    arrays = dict(nodes=n, matrices=m.astype(complex), coeff=c)
    np.savez(paths['table'], **arrays)
    expanded = arrays if len(factors) == 4 else dict(
        nodes=n, matrices=np.repeat(arrays['matrices'], 4, axis=1), coeff=np.repeat(c, 4, axis=2))
    hashes = {k: array_sha256(v) for k, v in arrays.items()}
    expanded_hashes = {k: array_sha256(v) for k, v in expanded.items()}
    manifest = dict(schema=TABLE_SCHEMA, status='FROZEN_COEFFICIENT_TABLE',
                    response_variant=variant, coordinate='minus_beta', runtime_channels=4,
                    file_sha256=sha256(paths['table']), array_sha256=hashes,
                    expanded_array_sha256=expanded_hashes,
                    array_metadata={k: array_metadata(v) for k, v in arrays.items()},
                    expansion_rule=('all_channels_as_stored' if variant == 'C_beta'
                                    else 'repeat_first_channel_to_four' if stored_channels == 1
                                    else 'all_channels_stored_identical_first'))
    evidence_path = root/'synthetic_gate_evidence.json'
    put(evidence_path, dict(purpose='SYNTHETIC_CONTRACT_ONLY_NOT_SCIENTIFIC_EVIDENCE',
                            maxima={k: 0. for k in GATE_LIMITS}, moments_trace=0., scipy_logpdf=0.))
    provenance = {key: dict(scope='current_response', response_variant=variant,
                           path=evidence_path.name, sha256=sha256(evidence_path),
                           source_field='maxima.'+key) for key in GATE_LIMITS}
    gates = dict(schema=GATE_SCHEMA, status='PASS_STATED_RESPONSE_GATES_ONLY',
                 response_variant=variant, purpose='synthetic_contract_test',
                 table_file_sha256=sha256(paths['table']),
                 experiment_sha256=sha256(paths['experiment']),
                 observations_sha256=sha256(paths['data']),
                 validation_config_sha256=sha256(paths['validation_config']),
                 array_sha256=hashes, expanded_array_sha256=expanded_hashes,
                 thresholds=GATE_LIMITS.copy(), maxima={k: 0. for k in GATE_LIMITS},
                 provenance=provenance, additional_checks=[])
    put(paths['table_manifest'], manifest)
    put(paths['response_gates'], gates)
    return dict(paths=paths, variant=variant, cfg=cfg, settings=settings,
                manifest=manifest, gates=gates, arrays=arrays, expanded=expanded,
                observations=observation)


def runtime(f, **kwargs):
    p = f['paths']
    return C08Runtime(p['experiment'], p['data'], p['table'], p['table_manifest'],
                      p['validation_config'], p['settings'], p['response_gates'],
                      response_variant=f['variant'], **kwargs)


class Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_init_preflight_never_load_payload_or_build_bank(self):
        f = fixture(self.root/'beta')
        with patch.object(np, 'load', side_effect=AssertionError('payload loaded')), \
             patch.object(CampaignRuntime, '__init__', side_effect=AssertionError('C07 init')), \
             patch.object(CampaignRuntime, 'build', side_effect=AssertionError('C07 build')), \
             patch.object(CampaignRuntime, 'preflight', side_effect=AssertionError('C07 preflight')):
            r = runtime(f)
            report = r.preflight()
        self.assertIsNone(r.table)
        self.assertIsNone(r.data)
        self.assertIsNone(r.engine)
        self.assertEqual(r.likelihood_evaluations, 0)
        self.assertFalse(report['execution_ready'])
        self.assertFalse(report['truth_deserialized'])
        self.assertGreater(report['memory']['reference_covbank_bytes'], 0)

    def test_cbeta_loads_exact_coefficients_without_respline(self):
        f = fixture(self.root/'beta')
        with patch('inference.campaign_runtime.EvenThresholdCubicORF', side_effect=AssertionError('respline')), \
             patch('inference.pointwise_preallocated.PreallocatedCubicPointLikelihood', side_effect=AssertionError('bank')):
            r = runtime(f)
            table = r.load_table()
        np.testing.assert_array_equal(table.coeff, f['arrays']['coeff'])
        np.testing.assert_array_equal(table.matrices, f['arrays']['matrices'])
        self.assertEqual(array_sha256(table.coeff), r.manifest['expanded_array_sha256']['coeff'])
        self.assertIs(r.load_table(), table)
        self.assertFalse(table.representation_checks['spline_fit_performed'])
        self.assertIsNone(r.engine)

    def test_cfull_expands_one_channel_explicitly_and_has_own_identity(self):
        beta, full = fixture(self.root/'beta'), fixture(self.root/'full', 'C_full', stored_channels=1)
        rb, rf = runtime(beta), runtime(full)
        table = rf.load_table()
        self.assertEqual(table.coeff.shape[2], 4)
        np.testing.assert_array_equal(table.coeff, full['expanded']['coeff'])
        self.assertNotEqual(rb.target_identity, rf.target_identity)
        self.assertNotEqual(rb.namespace(self.root/'out'), rf.namespace(self.root/'out'))
        memory = rf.preflight()['memory']
        self.assertGreater(memory['C_full_expansion_arrays_bytes'], 0)
        self.assertGreater(memory['loader_peak_with_caller_bytes'], memory['loader_owned_persistent_bytes'])

    def test_cfull_accepts_stored_four_identical_channels_and_rejects_difference(self):
        f = fixture(self.root/'full', 'C_full')
        r = runtime(f)
        np.testing.assert_array_equal(r.load_table().coeff, f['arrays']['coeff'])
        self.assertEqual(r.preflight()['memory']['C_full_expansion_arrays_bytes'], 0)
        f['arrays']['matrices'][:, 1] *= 1.01
        f['arrays']['coeff'][:, :, 1] *= 1.01
        np.savez(f['paths']['table'], **f['arrays'])
        hashes = {k: array_sha256(v) for k, v in f['arrays'].items()}
        f['manifest'].update(file_sha256=sha256(f['paths']['table']),
                             array_sha256=hashes, expanded_array_sha256=hashes)
        f['gates'].update(table_file_sha256=sha256(f['paths']['table']),
                          array_sha256=hashes, expanded_array_sha256=hashes)
        put(f['paths']['table_manifest'], f['manifest'])
        put(f['paths']['response_gates'], f['gates'])
        with self.assertRaisesRegex(ValueError, 'bit-identical'):
            runtime(f).load_table()

    def test_external_names_internal_routes_and_target_descriptors(self):
        f = fixture(self.root/'beta')
        f['settings']['targets'] = [dict(model='C_beta_G', datum=1), dict(model='C_beta_CN', datum=0)]
        put(f['paths']['settings'], f['settings'])
        r = runtime(f)
        self.assertEqual(r.targets.tolist(), [9, 4])
        self.assertEqual([x['internal_kernel'] for x in r.target_index], ['B_G', 'B_CN'])
        self.assertEqual([x['model'] for x in r.target_index], ['C_beta_G', 'C_beta_CN'])
        self.assertEqual([MODELS[t//r.n] for t in r.targets], ['B_G', 'B_CN'])
        f['settings']['targets'] = [9, 4]
        put(f['paths']['settings'], f['settings'])
        with self.assertRaisesRegex(ValueError, 'descriptors'):
            runtime(f)

    def test_c07_and_representation_only_manifests_are_rejected(self):
        for kind in ('C07', 'representation'):
            with self.subTest(kind=kind):
                f = fixture(self.root/kind)
                if kind == 'C07':
                    f['manifest']['schema'] = 'C07_PHYSICAL_TABLE'
                    f['manifest']['status'] = 'VALIDATED_IN_STATED_NUMERICAL_TEST_DOMAIN'
                    put(f['paths']['table_manifest'], f['manifest'])
                else:
                    f['gates']['status'] = 'REPRESENTATION_CHECKS_PASS'
                    put(f['paths']['response_gates'], f['gates'])
                with self.assertRaises(ValueError):
                    runtime(f)

    def test_cbeta_gate_cannot_authorize_cfull(self):
        f = fixture(self.root/'full', 'C_full')
        f['gates']['response_variant'] = 'C_beta'
        put(f['paths']['response_gates'], f['gates'])
        with self.assertRaisesRegex(ValueError, 'response-specific'):
            runtime(f)

    def test_scoped_inherited_direct_evidence_and_own_additional_checks(self):
        f = fixture(self.root/'full', 'C_full')
        for key in ('harmonic_matrix_coarse_fine', 'direct_coarse_fine', 'direct_harmonic'):
            evidence = dict(f['gates']['provenance'][key])
            evidence.update(scope='inherited_first_channel', channel=1, inherited_from_variant='C07_first_channel')
            f['gates']['provenance'][key] = evidence
        for name in ('moments_trace', 'scipy_logpdf'):
            evidence = dict(f['gates']['provenance']['logL_fine_oracle'], source_field=name)
            f['gates']['additional_checks'].append(dict(name=name, status='PASS', maximum_error=0.,
                                                        absolute_tolerance=1e-10, provenance=evidence))
        put(f['paths']['response_gates'], f['gates'])
        r = runtime(f)
        self.assertIn('gate_evidence_moments_trace', r.input_hashes)
        bad = dict(f['gates']['provenance']['direct_harmonic'])
        f['gates']['provenance']['logL_fine_oracle'] = bad
        put(f['paths']['response_gates'], f['gates'])
        with self.assertRaisesRegex(ValueError, 'across responses'):
            runtime(f)

    def test_file_header_array_and_expansion_mismatches(self):
        for kind in ('file', 'header', 'array', 'expanded'):
            with self.subTest(kind=kind):
                f = fixture(self.root/kind, 'C_full', stored_channels=1 if kind == 'expanded' else 4)
                if kind == 'file':
                    f['manifest']['file_sha256'] = '0'*64
                elif kind == 'header':
                    f['manifest']['array_metadata']['coeff']['shape'][0] = 7
                elif kind == 'array':
                    f['manifest']['array_sha256'] = dict(f['manifest']['array_sha256'], coeff='0'*64)
                    f['gates']['array_sha256'] = f['manifest']['array_sha256']
                    f['manifest']['expanded_array_sha256'] = f['manifest']['array_sha256'].copy()
                    f['gates']['expanded_array_sha256'] = f['manifest']['expanded_array_sha256']
                else:
                    f['manifest']['expanded_array_sha256'] = dict(f['manifest']['expanded_array_sha256'], coeff='0'*64)
                    f['gates']['expanded_array_sha256'] = f['manifest']['expanded_array_sha256']
                put(f['paths']['table_manifest'], f['manifest'])
                put(f['paths']['response_gates'], f['gates'])
                with self.assertRaises(ValueError):
                    runtime(f).load_table()

    def test_failed_or_relaxed_gate_and_wrong_config_rejected(self):
        for kind in ('failed', 'relaxed', 'config'):
            with self.subTest(kind=kind):
                f = fixture(self.root/kind)
                if kind == 'failed':
                    f['gates']['maxima']['logL_coarse_fine'] = .0011
                elif kind == 'relaxed':
                    f['gates']['thresholds']['logL_coarse_fine'] = .01
                else:
                    f['gates']['experiment_sha256'] = '0'*64
                put(f['paths']['response_gates'], f['gates'])
                with self.assertRaises(ValueError):
                    runtime(f)

    def test_no_truth_loader_uses_only_observation_and_geometry_fields(self):
        f = fixture(self.root/'beta')
        r = runtime(f)
        real_load = np.load
        requested = []

        class Guard:
            def __init__(self, value):
                self.value = value
            def __enter__(self):
                return self
            def __exit__(self, *args):
                self.value.close()
            def __contains__(self, name):
                return name in self.value
            def __getitem__(self, name):
                requested.append(name)
                if name == 'truth':
                    raise AssertionError('Truth deserialized')
                return self.value[name]

        with patch.object(np, 'load', side_effect=lambda *a, **kw: Guard(real_load(*a, **kw))):
            observations = r.load_observations_only()
        self.assertEqual(set(observations), {'q', 'x_physical', 'x_gaussian'})
        self.assertNotIn('truth', requested)
        self.assertIsNone(r.table)
        self.assertIsNone(r.engine)

    def test_prospective_build_requires_authorization_and_c07_release(self):
        f = fixture(self.root/'beta', execution=True)
        r = runtime(f)
        text = ' '.join(r.preflight()['pending'])
        self.assertIn('release receipt', text)
        self.assertIn('authorization', text)
        with patch('inference.pointwise_preallocated.PreallocatedCubicPointLikelihood', side_effect=AssertionError('bank')):
            for method in (r.build, r.require_execution):
                with self.assertRaisesRegex(RuntimeError, 'execution pending'):
                    method()
            with self.assertRaisesRegex(RuntimeError, 'execution pending'):
                runtime(f, build=True)

    def test_linked_authorization_receipt_still_cannot_execute_synthetic_gate(self):
        f = fixture(self.root/'beta', execution=True)
        r = runtime(f)
        evidence = self.root/'synthetic_release_evidence.txt'
        evidence.write_text('Synthetic contract evidence only; no real C07 release.\n')
        release_path, auth_path = self.root/'release.json', self.root/'authorization.json'
        publication = dict(status='PUBLISHED', commit='b'*40, tag='synthetic-contract-only',
                           release_url='https://example.invalid/synthetic-only',
                           evidence=dict(path=str(evidence), sha256=sha256(evidence)))
        release = dict(schema=RELEASE_SCHEMA, status='C07_PUBLISHED_AND_RELEASED',
                       scope='C07_PUBLISHED_AND_WORKERS_MEMORY_RELEASED', released_for_c08=True,
                       active_workers=0, c07_runtime_identity='a'*64,
                       publication=publication,
                       evidence=[dict(path=str(evidence), sha256=sha256(evidence))])
        put(release_path, release)
        auth = dict(schema=AUTH_SCHEMA, scope='C08_TRAINING_AND_IID_ONLY',
                    execution_allowed=True, runtime_identity=r.identity,
                    target_identity=r.target_identity, response_variant='C_beta',
                    budget_sha256=canonical_hash(f['settings']['budget']),
                    c07_release_receipt_sha256=sha256(release_path),
                    c07_published_commit=publication['commit'], c07_published_tag=publication['tag'],
                    c07_publication_evidence_sha256=publication['evidence']['sha256'])
        put(auth_path, auth)
        linked = runtime(f, execution_authorization_path=auth_path, c07_release_receipt_path=release_path)
        self.assertEqual(linked.identity, r.identity)
        self.assertEqual(linked.preflight()['pending'], [
            'Synthetic gate permits representation tests only, never execution.'])
        with self.assertRaisesRegex(RuntimeError, 'Synthetic gate'):
            linked.build()
        auth['runtime_identity'] = '0'*64
        put(auth_path, auth)
        with self.assertRaisesRegex(ValueError, 'authorization must bind'):
            runtime(f, execution_authorization_path=auth_path, c07_release_receipt_path=release_path)

    def test_resource_release_without_c07_publication_cannot_enable_runtime(self):
        f = fixture(self.root/'beta', execution=True)
        release_path = self.root/'release_without_publication.json'
        release = dict(schema=RELEASE_SCHEMA, status='C07_PUBLISHED_AND_RELEASED',
                       scope='C07_PUBLISHED_AND_WORKERS_MEMORY_RELEASED', released_for_c08=True,
                       active_workers=0, c07_runtime_identity='a'*64)
        put(release_path, release)
        with self.assertRaisesRegex(ValueError, 'publication evidence'):
            runtime(f, c07_release_receipt_path=release_path)

    def test_low_memory_budget_rejected_before_payload_load(self):
        for key in ('maximum_numeric_bytes', 'maximum_loader_owned_numeric_bytes'):
            with self.subTest(key=key):
                f = fixture(self.root/key)
                f['settings']['budget'][key] = 1
                put(f['paths']['settings'], f['settings'])
                with patch.object(np, 'load', side_effect=AssertionError('payload loaded')):
                    with self.assertRaisesRegex(RuntimeError, 'budget exceeded'):
                        runtime(f)

    def test_gate_coefficients_and_settings_change_the_required_identities(self):
        f = fixture(self.root/'beta')
        r = runtime(f)
        f['gates']['maxima']['logL_fine_oracle'] = 1e-9
        put(f['paths']['response_gates'], f['gates'])
        changed_gate = runtime(f)
        self.assertNotEqual(r.target_identity, changed_gate.target_identity)
        self.assertNotEqual(r.identity, changed_gate.identity)
        f['settings']['production']['likelihood_batch'] = 3
        put(f['paths']['settings'], f['settings'])
        changed_settings = runtime(f)
        self.assertEqual(changed_gate.target_identity, changed_settings.target_identity)
        self.assertNotEqual(changed_gate.identity, changed_settings.identity)
        for name in ('matrices', 'coeff'):
            f['arrays'][name] *= 1.01
        np.savez(f['paths']['table'], **f['arrays'])
        hashes = {k: array_sha256(v) for k, v in f['arrays'].items()}
        f['manifest'].update(file_sha256=sha256(f['paths']['table']),
                             array_sha256=hashes, expanded_array_sha256=hashes)
        f['gates'].update(table_file_sha256=sha256(f['paths']['table']),
                          array_sha256=hashes, expanded_array_sha256=hashes)
        put(f['paths']['table_manifest'], f['manifest'])
        put(f['paths']['response_gates'], f['gates'])
        changed_coefficients = runtime(f)
        self.assertNotEqual(changed_settings.target_identity, changed_coefficients.target_identity)
        changed_coefficients.load_table()

    def test_mutated_file_or_in_memory_settings_are_detected(self):
        f = fixture(self.root/'beta')
        r = runtime(f)
        r.settings['execution_enabled'] = True
        with self.assertRaisesRegex(RuntimeError, 'In-memory'):
            r.preflight()
        r = runtime(f)
        f['gates']['purpose'] = 'response_validation'
        put(f['paths']['response_gates'], f['gates'])
        with self.assertRaisesRegex(RuntimeError, 'frozen campaign'):
            r.preflight()

    def test_namespace_snapshot_and_external_index_preserve_internal_record(self):
        f = fixture(self.root/'beta')
        r = runtime(f)
        with self.assertRaisesRegex(ValueError, 'namespace'):
            r.snapshot(self.root/'unscoped')
        directory = r.namespace(self.root/'out')/'training'
        r.snapshot(directory)
        r.snapshot(directory)
        target = int(r.targets[0])
        path = directory/f'target_{target:06d}.json'
        internal = dict(identity=r.target_identity, target=target, model='B_CN', datum=0,
                        status='FROZEN_PROPOSAL', synthetic_contract_record=True)
        put(path, internal)
        before = sha256(path)
        external = r._external_record_index(directory, target, 'training')
        self.assertEqual(sha256(path), before)
        self.assertEqual(external['model'], 'C_beta_CN')
        self.assertEqual(external['internal_kernel'], 'B_CN')
        self.assertEqual(external['internal_record_sha256'], before)
        self.assertTrue((directory/'provenance'/r.identity/'c08_manifest.json').exists())

    def test_metadata_does_not_deserialize_object_truth(self):
        f = fixture(self.root/'beta')
        metadata = npz_metadata(f['paths']['data'], ('q', 'x_physical', 'x_gaussian'))
        self.assertEqual(set(metadata), {'q', 'x_physical', 'x_gaussian'})
        with self.assertRaisesRegex(ValueError, 'numeric'):
            npz_metadata(f['paths']['data'], ('truth',))

    def test_geometry_headers_are_checked_before_observation_payloads(self):
        f = fixture(self.root/'beta')
        f['observations']['directions'] = np.zeros((100, 3))
        np.savez(f['paths']['data'], **f['observations'])
        with patch.object(np, 'load', side_effect=AssertionError('payload loaded')):
            with self.assertRaisesRegex(ValueError, 'geometry headers'):
                runtime(f)


if __name__ == '__main__':
    unittest.main(verbosity=2)
