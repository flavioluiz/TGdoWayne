"""Tiny synthetic v2 contracts only; no payload loads, table builds or logL."""
from pathlib import Path
import copy
import json
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from test_c08_runtime import fixture as fixture_v1, put, runtime as runtime_v1
from c08_runtime_v2 import (C08Runtime, GATE_SCHEMA_V2, COMPATIBILITY_SCHEMA,
                            SCOPE, PENDING_POSTERIOR_CHECKS, REVIEWED_CHECKS,
                            domain_descriptor)
from inference.campaign_io import canonical_hash, sha256
from inference.campaign_runtime import CampaignRuntime
from inference.model import experiment


def observations(path, cfg):
    e = experiment(cfg)
    n, k, p, d = cfg['n_realizations'], 4, cfg['n_pulsars'], len(e['H'])
    np.savez(path, q=np.zeros((n, k, p), complex),
             x_physical=np.zeros((n, k, d)), x_gaussian=np.zeros((n, k, d)),
             directions=e['points'], distances_ly=e['distance_ly'], sigma=e['sigma'],
             red_pattern=e['red'], frequency_hz=e['f'], scale=e['scale'],
             truth=np.array([{'poison': 'never deserialize'}], dtype=object))


def fixture(root):
    f = fixture_v1(root)
    p = f['paths']
    f['cfg']['n_realizations'] = 500
    put(p['experiment'], f['cfg'])
    observations(p['data'], f['cfg'])
    # Tiny selected targets keep contract tests lightweight; no full campaign.
    f['settings']['targets'] = [dict(model='C_beta_CN', datum=0), dict(model='C_beta_G', datum=499)]
    put(p['settings'], f['settings'])
    tested = copy.deepcopy(f['cfg'])
    tested.pop('response_variant')
    tested.update(n_realizations=16, models=['A0_CN', 'A_CN', 'B_CN', 'A_G', 'B_G'])
    p.update(tested_experiment=root/'engineering_configuration.json',
             tested_generation=root/'engineering_generation.json',
             tested_observations=root/'engineering_observations.npz',
             runtime_generation=root/'runtime_generation.json',
             domain_compatibility=root/'domain_compatibility.json')
    put(p['tested_experiment'], tested)
    observations(p['tested_observations'], tested)
    put(p['tested_generation'], dict(scope='SYNTHETIC_ONLY', n=16, seed=20))
    put(p['runtime_generation'], dict(scope='SYNTHETIC_ONLY', n=500, seed=30))
    tested_inputs = dict(configuration_sha256=sha256(p['tested_experiment']),
                         generation_sha256=sha256(p['tested_generation']),
                         observations_sha256=sha256(p['tested_observations']))
    runtime_inputs = dict(configuration_sha256=sha256(p['experiment']),
                          generation_sha256=sha256(p['runtime_generation']),
                          observations_sha256=sha256(p['data']),
                          validation_config_sha256=sha256(p['validation_config']))
    g = f['gates']
    for key in ('experiment_sha256', 'observations_sha256', 'validation_config_sha256'):
        g.pop(key)
    g.update(schema=GATE_SCHEMA_V2, tested_domain_inputs=tested_inputs,
             tested_observation_scope=dict(dataset_count_per_model=16, observation_models=['CN', 'G'],
                                           total_observations=32, declared_checks_only=True),
             evidence_scope=SCOPE, runtime_population_validation_claimed=False,
             posterior_region_checks_status='PENDING')
    put(p['response_gates'], g)
    review_path = root/'synthetic_domain_review.json'
    put(review_path, dict(scope='SYNTHETIC_ONLY_NOT_SCIENTIFIC_EVIDENCE',
                          reviewed_checks=REVIEWED_CHECKS))
    dh = canonical_hash(domain_descriptor(tested))
    compat = dict(schema=COMPATIBILITY_SCHEMA,
                  status='APPROVED_DOMAIN_COMPATIBILITY_FINITE_ENGINEERING_ONLY', response_variant='C_beta',
                  tested_domain_inputs=tested_inputs, runtime_experiment=runtime_inputs,
                  response_gate_sha256=sha256(p['response_gates']),
                  tested_domain_descriptor_sha256=dh, runtime_domain_descriptor_sha256=dh,
                  evidence_scope=SCOPE, runtime_population_validation_claimed=False,
                  posterior_region_checks_status='PENDING', pending_posterior_checks=PENDING_POSTERIOR_CHECKS.copy(),
                  reviewed_checks={name: True for name in REVIEWED_CHECKS},
                  population_and_label_differences=dict(tested_datasets_per_model=16, runtime_datasets_per_model=500,
                      tested_model_labels=tested['models'], runtime_model_labels=f['cfg']['models'],
                      observation_payloads_may_differ=True),
                  approval=dict(approved_by='SYNTHETIC_TEST_ONLY', decision_id='SYNTHETIC_TEST_ONLY'),
                  review_evidence=[dict(path=review_path.name, sha256=sha256(review_path))])
    put(p['domain_compatibility'], compat)
    f.update(tested=tested, compatibility=compat, review_path=review_path)
    return f


def runtime(f, **kwargs):
    p = f['paths']
    return C08Runtime(p['experiment'], p['data'], p['table'], p['table_manifest'],
                      p['validation_config'], p['settings'], p['response_gates'],
                      tested_experiment_path=p['tested_experiment'],
                      tested_generation_path=p['tested_generation'],
                      tested_observations_path=p['tested_observations'],
                      runtime_generation_path=p['runtime_generation'],
                      domain_compatibility_path=p['domain_compatibility'],
                      response_variant=f['variant'], **kwargs)


def refresh_gate(f):
    put(f['paths']['response_gates'], f['gates'])
    f['compatibility']['response_gate_sha256'] = sha256(f['paths']['response_gates'])
    put(f['paths']['domain_compatibility'], f['compatibility'])


class Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_16_and_500_bindings_are_distinct_and_only_finite_scope(self):
        f = fixture(self.root/'main')
        with patch.object(np, 'load', side_effect=AssertionError('payload load')), \
             patch.object(CampaignRuntime, '__init__', side_effect=AssertionError('C07 init')), \
             patch.object(CampaignRuntime, 'build', side_effect=AssertionError('C07 build')), \
             patch('inference.campaign_runtime.EvenThresholdCubicORF', side_effect=AssertionError('respline')):
            r = runtime(f)
            report = r.preflight()
        d = report['domain_compatibility']
        self.assertEqual(d['tested_observation_scope']['total_observations'], 32)
        self.assertEqual(report['datasets'], 500)
        self.assertNotEqual(d['tested_domain_inputs']['configuration_sha256'], d['runtime_experiment']['configuration_sha256'])
        self.assertNotEqual(d['tested_domain_inputs']['observations_sha256'], d['runtime_experiment']['observations_sha256'])
        self.assertFalse(report['runtime_population_validation_claimed'])
        self.assertEqual(report['posterior_region_checks_status'], 'PENDING')
        self.assertFalse(report['execution_ready'])
        self.assertIsNone(r.table)
        self.assertIsNone(r.data)
        self.assertIsNone(r.engine)
        self.assertEqual(r.likelihood_evaluations, 0)
        self.assertIn('c08_runtime_v2', r.source_hashes)
        self.assertEqual(r.target_index[1]['internal_target'], 2499)

    def test_expected_descriptor_excludes_only_population_and_labels(self):
        f = fixture(self.root/'desc')
        self.assertEqual(domain_descriptor(f['tested']), domain_descriptor(f['cfg']))
        for field, value in [('duration_years', 17), ('cadence_days', 15),
                             ('geometry_seeds', [20, 30, 40]), ('frequency_weights', [.1, .2, .3, .4]),
                             ('distance_range_light_years', [200, 900]), ('fixed_red_slope', 3)]:
            with self.subTest(field=field):
                c = copy.deepcopy(f['tested'])
                c[field] = value
                self.assertNotEqual(domain_descriptor(c), domain_descriptor(f['cfg']))

    def test_incompatible_domain_rejected_before_any_payload(self):
        for field, value in [('duration_years', 17), ('frequency_weights', [.1, .2, .3, .4]),
                             ('distance_range_light_years', [200, 900]), ('fixed_red_slope', 3)]:
            with self.subTest(field=field):
                f = fixture(self.root/field)
                f['tested'][field] = value
                put(f['paths']['tested_experiment'], f['tested'])
                with patch.object(np, 'load', side_effect=AssertionError('payload')), self.assertRaisesRegex(ValueError, 'geometry, spectra, prior or scale'):
                    runtime(f)
        f = fixture(self.root/'prior')
        f['tested']['prior']['bounds'][1][0] = -19
        put(f['paths']['tested_experiment'], f['tested'])
        with self.assertRaisesRegex(ValueError, 'geometry, spectra, prior or scale'):
            runtime(f)

    def test_generation_and_observation_bindings_cannot_be_substituted(self):
        for field in ('tested_generation', 'runtime_generation'):
            with self.subTest(field=field):
                f = fixture(self.root/field)
                put(f['paths'][field], dict(scope='changed'))
                with self.assertRaises(ValueError):
                    runtime(f)
        f = fixture(self.root/'obs')
        f['gates']['tested_domain_inputs']['observations_sha256'] = sha256(f['paths']['data'])
        refresh_gate(f)
        with self.assertRaisesRegex(ValueError, 'engineering inputs/scope'):
            runtime(f)

    def test_no_legacy_ambiguous_gate_fields(self):
        f = fixture(self.root/'legacy')
        f['gates']['observations_sha256'] = sha256(f['paths']['data'])
        refresh_gate(f)
        with self.assertRaisesRegex(ValueError, 'engineering inputs/scope'):
            runtime(f)

    def test_no_population_promotion_or_completed_posterior_claim(self):
        for field, value in [('runtime_population_validation_claimed', True),
                             ('posterior_region_checks_status', 'PASS'), ('evidence_scope', 'POSTERIOR500_VALIDATED')]:
            for where in ('gates', 'compatibility'):
                with self.subTest(field=field, where=where):
                    f = fixture(self.root/(field+where))
                    f[where][field] = value
                    refresh_gate(f)
                    with self.assertRaises(ValueError):
                        runtime(f)

    def test_review_approval_and_hashed_evidence_are_required(self):
        for field, value in [('approval', {}), ('review_evidence', []), ('reviewed_checks', {}),
                             ('pending_posterior_checks', []), ('population_and_label_differences', {})]:
            with self.subTest(field=field):
                f = fixture(self.root/field)
                f['compatibility'][field] = value
                put(f['paths']['domain_compatibility'], f['compatibility'])
                with self.assertRaises(ValueError):
                    runtime(f)
        f = fixture(self.root/'evidence')
        put(f['review_path'], dict(changed=True))
        with self.assertRaisesRegex(ValueError, 'evidence hash mismatch'):
            runtime(f)

    def test_wrong_variant_gate_and_C07_manifest_rejected(self):
        f = fixture(self.root/'variant')
        f['gates']['response_variant'] = 'C_full'
        refresh_gate(f)
        with self.assertRaisesRegex(ValueError, 'response-specific'):
            runtime(f)
        f = fixture(self.root/'C07')
        f['manifest']['schema'] = 'C07_PHYSICAL_TABLE_v1'
        put(f['paths']['table_manifest'], f['manifest'])
        with self.assertRaisesRegex(ValueError, 'C07 manifests rejected'):
            runtime(f)

    def test_malformed_engineering_observation_header_rejected(self):
        f = fixture(self.root/'header')
        c = copy.deepcopy(f['tested'])
        c['n_realizations'] = 15
        observations(f['paths']['tested_observations'], c)
        with self.assertRaisesRegex(ValueError, 'Engineering observation headers'):
            runtime(f)

    def test_tested_geometry_allocation_bound_precedes_derivation(self):
        f = fixture(self.root/'dimension_cap')
        f['tested']['n_pulsars'] = 1000000
        put(f['paths']['tested_experiment'], f['tested'])
        with patch('c08_runtime_v2.domain_descriptor', side_effect=AssertionError('derived arrays')):
            with self.assertRaisesRegex(ValueError, 'dimensions must match before deriving'):
                runtime(f)

    def test_identity_changes_with_compatibility_decision(self):
        f = fixture(self.root/'identity')
        a = runtime(f)
        f['compatibility']['approval']['decision_id'] = 'SYNTHETIC_NEW_REVIEW'
        put(f['paths']['domain_compatibility'], f['compatibility'])
        b = runtime(f)
        self.assertNotEqual(a.identity, b.identity)
        self.assertNotEqual(a.target_identity, b.target_identity)
        with self.assertRaises(RuntimeError):
            a.preflight()

    def test_inmemory_compatibility_tampering_rejected(self):
        f = fixture(self.root/'tamper')
        r = runtime(f)
        r.domain_compatibility['runtime_population_validation_claimed'] = True
        with self.assertRaisesRegex(RuntimeError, 'In-memory C08'):
            r.preflight()

    def test_synthetic_build_blocked_before_any_loader_or_bank(self):
        f = fixture(self.root/'blocked')
        r = runtime(f)
        with patch.object(r, 'load_table', side_effect=AssertionError('table load')), \
             patch.object(r, 'load_observations_only', side_effect=AssertionError('data load')), \
             self.assertRaisesRegex(RuntimeError, 'Synthetic gate'):
            r.build()

    def test_v1_source_still_works_and_rejects_v2_contract(self):
        original = fixture_v1(self.root/'original')
        self.assertEqual(runtime_v1(original).preflight()['schema'], 'C08_RUNTIME_PREFLIGHT_v1')
        f = fixture(self.root/'new')
        with self.assertRaisesRegex(ValueError, 'Own response-specific'):
            runtime_v1(f)

    def test_snapshot_serializes_distinct_domains(self):
        f = fixture(self.root/'snapshot')
        r = runtime(f)
        dest = r.namespace(self.root/'out')
        r.snapshot(dest)
        record = json.loads((dest/'provenance'/r.identity/'c08_domain_compatibility.json').read_text())
        self.assertEqual(record['tested_observation_scope']['total_observations'], 32)
        self.assertEqual(record['population_and_label_differences']['runtime_datasets_per_model'], 500)
        self.assertFalse(record['runtime_population_validation_claimed'])
        r.snapshot(dest)


if __name__ == '__main__':
    unittest.main(verbosity=2)
