# C08 runtime v2 — engenharia e posterior têm vínculos distintos

Candidato implementado em `src/c08_runtime_v2.py`, preservando `src/c08_runtime.py` e os loaders v1/v2 existentes. Foram executados **15 testes sintéticos de contrato**, em cerca de 1 segundo de testes; nenhum banco real, payload real, quadratura ou logL foi executado. A revisão independente da separação de domínios não encontrou bloqueador. Isso não constitui aprovação científica, autorização de inferência ou manifestação PASS de uma tabela real.

O gate v2 vincula `tested_domain_inputs`: SHA256 da configuração, do registro de geração e das observações efetivamente usadas na engenharia. Declara `tested_observation_scope` com 16 conjuntos por modelo CN/G e 32 observações no total no caso considerado. Esses valores vêm da configuração de engenharia; não são substituídos por 500. Os antigos campos ambíguos de gate `experiment_sha256`, `observations_sha256` e `validation_config_sha256` são rejeitados. Permanecem os vínculos próprios da variante, arquivo da tabela, arrays armazenados/expandidos, limites, proveniência de cada gate e verificações adicionais opcionais do candidato v1. Nenhum número de gate novo foi produzido.

A aprovação separada `C08_ENGINEERING_RUNTIME_DOMAIN_COMPATIBILITY_v1` vincula o gate, os três arquivos de engenharia e `runtime_experiment`: configuração, geração, observações e configuração de validação do novo experimento. Exige decisão de aprovação identificada, evidência de revisão com hash e a declaração das diferenças de população/rótulos. A aprovação de compatibilidade entra na identidade do alvo e na identidade de execução. Uma decisão diferente produz namespace diferente.

O verificador compara descritores derivados das duas configurações: direções, distâncias, ruído branco/vermelho, frequências, escala, estimadores H, pesos, T/dt, prior, parâmetros, inclinação vermelha fixa e canais. Tamanho da população e rótulos dos modelos não entram nesse descritor. As dimensões da configuração de engenharia são limitadas antes de derivar arrays. A igualdade é exata neste contrato prospectivo; não há tolerância silenciosa para domínios apenas aproximadamente semelhantes.

Essa comparação prova correspondência do domínio **esperado pelas configurações sob a biblioteca registrada**. Não prova que o gerador histórico usou aquela implementação, nem que o payload contém a geometria declarada. A revisão separada exige evidência desses pontos, inclusive correspondência de implementações espectrais/geração. Os registros de geração são vinculados por hash, mas seu formato interno não é reinterpretado pelo adaptador. Durante init/preflight são lidos hashes e headers NPY; o loader NoTruth existente permanece responsável pela validação das observações runtime quando futuramente chamado. Nenhum arquivo `truth` é solicitado.

Todos os relatórios mantêm `FINITE_ENGINEERING_DOMAIN_ONLY`, `runtime_population_validation_claimed=false` e `posterior_region_checks_status=PENDING`. Continuam pendentes a precisão da resposta na região posterior e os diagnósticos/precisão amostral de cada posterior. Compatibilidade de domínio permite propor o uso da representação em novos dados; não promove 32 observações de engenharia a validação de 500 dados. As pendências científicas são reportadas separadamente das condições operacionais, para que uma autorização futura possa permitir coletar os diagnósticos sem declará-los já concluídos.

A execução continua exigindo o contrato v1 completo: autorização vinculada às identidades e orçamento, evidência de C07 **publicado** com commit/tag/release, recursos liberados, configurações aprovadas e sementes congeladas. Fixtures `synthetic_contract_test` continuam bloqueadas antes de loader/banco. Neste trabalho não foi criada aprovação de compatibilidade nem autorização de execução para dados reais.

## Verificação e limites

`test_c08_runtime_v2.py` verifica 16/500 distintos, metadados sem payload/respline/C07 init, incompatibilidade de geometria/espectros/prior/escala, hashes de geração/observações, campos legados, promoção indevida, aprovação/evidência ausentes, variante errada, manifest C07, headers malformados, limite pré-alocação, mudança de identidade, mutação em memória, bloqueio sintético, funcionamento preservado de v1 e snapshot com os dois domínios. A cobertura positiva nova é C_beta; o caminho C_full K1/K4 continua herdado do v1 já testado, sem novo teste positivo C_full nesta suíte.

`memory_v2_arithmetic.json` e `MEMORY_V2_ARITHMETIC.md` quantificam N=9248, K=4, P=12, D=10, n=500 com a receita numérica atual (8192 passos, 2048 pontos EM, IID 16384/65536, lote 2048). Essa leitura não transfere a autorização, os rótulos ou as sementes de C07. O teto permanece 4 GiB.

| Estimativa | Referência | Nativo |
|---|---:|---:|
| Fórmula genérica atual | 1.739.472.896 B | 2.668.119.040 B |
| Envelope C08, sem reserva adicional do backend | 1.469.913.376 B | 4.035.765.872 B |
| Margem C08 até 4 GiB | 2.825.053.920 B | 259.201.424 B |

O pico nativo C08 é 3,758600 GiB; sua margem aritmética é 247,19 MiB **antes** de reserva adicional do backend. A produção domina os blocos de treinamento 64/32/16; reduzir somente esse bloco não reduz o máximo. Caller + loader + observações somam 856.219.904 bytes na fase correspondente. O banco soma 639.152.640 bytes; a validação nativa existente tem allowance de 1.864.195.200 bytes. A fórmula conserva um envelope, sem garantir coincidência temporal exata ou RSS. Python, allocator e cache de arquivos ficam fora da base; nenhuma reserva backend ou aumento de teto foi adotado automaticamente.

Fontes, testes, logs, aritmética e hashes de v1 preservadas estão em `runtime_v2_review.json`. Reprodução dos testes: `.venv/bin/python -B tmp/c08_runtime_design/test_c08_runtime_v2.py`. Reprodução da aritmética: `python3 -B tmp/c08_runtime_design/memory_v2_arithmetic.py`.
