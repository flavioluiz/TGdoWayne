# C08 v2: aritmética de memória prospectiva

Somente aritmética inteira, com N=9.248, K=4, P=12, D=10 e n=500. Não foram abertos dados/tabelas, construídos bancos, carregado backend, nem executadas verossimilhanças ou quadraturas. O limite permanece **4.294.967.296 bytes (4 GiB)**.

A receita numérica é lida de `configs/calibration/campaign_500_execution_v1.json`: 8.192 passos, quatro cadeias, 2.048 pontos para EM, níveis IID 16.384/65.536, quatro réplicas, lote de verossimilhança 2.048 e 16 alvos por bloco de produção. Esse uso aritmético não transfere autorização, rótulos ou sementes de C07 a C08.

A reserva adicional de backend é **zero apenas como base de comparação**. Cada margem abaixo é o teto aritmético disponível para uma reserva explicitamente aprovada; não é uma reserva escolhida nem garantia de RSS.

| Backend | Bloco treinamento | Genérico atual (bytes) | C08 treinamento (bytes) | C08 produção/máximo (bytes) | Margem C08 até 4 GiB (bytes) |
|---|---:|---:|---:|---:|---:|
| reference | 64 | 1,739,472,896 | 1,399,888,160 | 1,469,913,376 | 2,825,053,920 |
| reference | 32 | 1,739,472,896 | 1,300,322,592 | 1,469,913,376 | 2,825,053,920 |
| reference | 16 | 1,739,472,896 | 1,250,539,808 | 1,469,913,376 | 2,825,053,920 |
| native | 64 | 2,668,119,040 | 3,965,740,656 | 4,035,765,872 | 259,201,424 |
| native | 32 | 2,668,119,040 | 3,866,175,088 | 4,035,765,872 | 259,201,424 |
| native | 16 | 2,668,119,040 | 3,816,392,304 | 4,035,765,872 | 259,201,424 |

No cálculo C08 a produção domina os três tamanhos de bloco. O máximo de referência é **1.469.913.376 bytes (1,368964 GiB)**; o máximo nativo é **4.035.765.872 bytes (3,758600 GiB)**, deixando **259.201.424 bytes (247,193741 MiB)** antes de qualquer reserva adicional de backend. Reduzir somente o bloco de treinamento não reduz esse máximo.

A fórmula genérica atual retorna 1.739.472.896 bytes na referência e 2.668.119.040 bytes no nativo para qualquer bloco. Ela contém um pico de construção de spline e um proxy de cópia nativa, mas não representa o histórico de treinamento por bloco, o chamador simultâneo ao loader ou os grandes temporários de validação nativa da estimativa C08. Os números não são medições intercambiáveis de RSS.

## Componentes da conta

| Componente | Bytes |
|---|---:|
| Coeficientes complex128 | 340,881,408 |
| Matrizes complex128 | 85,229,568 |
| Arrays da tabela no chamador | 426,184,960 |
| Loader: propriedade persistente | 426,258,944 |
| Loader: buffers de validação | 3,022,848 |
| Loader: resultado de autovalores | 49,152 |
| Loader: pico próprio | 429,330,944 |
| Chamador + loader, sem observações | 855,515,904 |
| Chamador + loader + observações | 856,219,904 |
| Observações q/x_physical/x_gaussian | 704,000 |
| Arrays do experimento | 23,712 |
| Banco de médias | 17,754,240 |
| Banco de covariâncias | 621,398,400 |
| Cópias y/z | 400,000 |
| Reserva de construção de referência | 134,217,728 |
| Pico de construção de referência antes do experimento/backend | 1,200,733,312 |
| Covariâncias nativas empacotadas | 341,769,120 |
| Cópias próprias nativas estimadas | 701,657,296 |
| Temporários de validação nativa | 1,864,195,200 |
| Pico de construção nativa antes do experimento/backend | 3,766,585,808 |
| Raw por alvo | 37,552,128 |
| Raw ativo, 16 alvos | 600,834,048 |
| Reserva de três arrays raw por alvo na produção | 112,656,384 |
| Lote de verossimilhança da produção | 156,499,968 |

`H` é **complex128**, conforme `angular_estimators`: shape (10,12,12), 23.040 bytes. Somam-se points, distâncias, sigma, padrão vermelho, frequências, scale e weights para 23.712 bytes de arrays do experimento. Os pesos são assumidos float64. Os escalares T/dt e metadados Python não entram nesta soma.

| Bloco | Histórico simples | Reserva 4× histórico | Pontos retidos simples | Reserva 3× retidos | Lote LL treinamento | Workspace total |
|---:|---:|---:|---:|---:|---:|---:|
| 64 | 40,960,000 | 163,840,000 | 5,242,880 | 15,728,640 | 19,562,496 | 199,131,136 |
| 32 | 20,480,000 | 81,920,000 | 2,621,440 | 7,864,320 | 9,781,248 | 99,565,568 |
| 16 | 10,240,000 | 40,960,000 | 1,310,720 | 3,932,160 | 4,890,624 | 49,782,784 |

O histórico simples usa min(4.000, passos) × 4 cadeias × bloco × 5 parâmetros × 8 bytes; os retidos simples usam 2.048 × bloco × 5 × 8. Os fatores 4 e 3 e o lote de treinamento reproduzem o allowance conservador de `c08_runtime.py`. A produção acrescenta três vezes o raw por alvo e 2.048 × 4 × (12² × 16 + 21 × 10² × 8). O raw ativo ocupa 600.834.048 bytes e fica abaixo do teto independente de 1 GiB.

A validação nativa acrescenta max(3 × coeficientes, 3 × banco de covariância, 2 × covariância empacotada) = 1.864.195.200 bytes. A conta preserva a estimativa conservadora do candidato, inclusive sua soma do envelope de construção aos workspaces de fase; não determina o pico físico exato.

## Reprodução e limites

Execute `python3 -B tmp/c08_runtime_design/memory_v2_arithmetic.py` na raiz. `memory_v2_arithmetic.json` contém todos os componentes, fórmulas concretizadas, hipóteses e hashes das fontes/configuração e do script. Somente biblioteca padrão Python é importada. Nenhuma configuração de campanha é alterada.

Overhead de Python/allocator, cache de arquivos e workspaces efetivos de backend permanecem fora da base. Não há garantia de RSS, medição de backend, autorização de execução ou validação de posterior neste artefato.
