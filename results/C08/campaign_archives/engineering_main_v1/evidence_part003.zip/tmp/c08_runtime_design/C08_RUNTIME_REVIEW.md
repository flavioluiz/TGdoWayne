# Adaptador C08 prospectivo

Fonte: `src/c08_runtime.py`. Testes: `test_c08_runtime.py`.
O pacote modifica apenas arquivos novos em `tmp/c08_runtime_design`.
Nenhum manifesto de gate real, tabela C08 real, banco ou campanha foi criado
ou carregado por este trabalho. Os fixtures sintéticos são temporários.

## Separação do C07

`C08Runtime` subclassifica `CampaignRuntime` sem chamar seu `__init__`,
`build` ou `preflight`. Possui inicialização, manifesto, identidade, orçamento
e gates próprios. Reutiliza os métodos genéricos de snapshot, verificação de
arquivos, contagem, fase de threads e fechamento, acrescentando verificações
C08. `train_block` e `produce_target` chamam as funções C07 intactas, com os
mesmos IDs internos, RNGs e formatos de registros. Não existe caminho para
`EvenThresholdCubicORF` ou outro reajuste de spline no adaptador.

| Variante externa | Modelos externos | Rotas internas |
|---|---|---|
| C_beta | C_beta_CN, C_beta_G | B_CN, B_G |
| C_full | C_full_CN, C_full_G | B_CN, B_G |

Os IDs internos permanecem `2*n + datum` e `4*n + datum`. Seleções explícitas
em `settings.targets` usam descritores `{"model": "C_beta_CN", "datum": 0}`,
evitando IDs C07 ambíguos na interface externa. A configuração científica
deve declarar `response_variant` e os dois modelos externos correspondentes.

As saídas são namespaced em `output_root/C08/variant/target_identity/`.
Os registros C07 permanecem byte a byte intactos, com seus rótulos internos;
sidecars `c08_target_*.json` registram modelo externo, datum, rota interna e
SHA256 do registro original. Um manifesto C08 acompanha a proveniência.
Snapshots fora desse namespace são rejeitados.

`target_identity` inclui variante, configuração, observações, gate, hash do
arquivo e hashes dos arrays armazenados/expandidos. `identity` acrescenta
settings, fontes, backend e plano de threads. Autorização e receipt ficam na
proveniência, mas fora do hash que autorizam, evitando referência circular.
Alterações em arquivos ou no contrato em memória são rejeitadas.

## Carregamento e memória

O init/preflight lê JSONs, hashes e apenas headers dos membros NPZ necessários.
Valida shapes, dtype, ordem C e tamanho de payload antes de carregar arrays.
Os headers de geometria também são conferidos antes do loader C07 lê-los.
Nem o init nem o preflight instanciam bancos. `load_table()` carrega e confere
os hashes dos arrays, depois chama `FrozenCoefficientORF` v2. Os coeficientes
originais são usados diretamente.

C_beta exige quatro canais já armazenados. C_full aceita o artefato de quatro
canais explicitamente repetidos, com regra `all_channels_stored_identical_first`
e igualdade bit a bit verificada por tiles. Opcionalmente aceita fonte de um
canal, expansão explícita para quatro e hashes próprios dos arrays expandidos.
A parcela de expansão só existe no caso K armazenado = 1. Nenhuma dessas
representações promove um gate C_beta/C07 para C_full.

`load_observations_only()` chama o loader C07 original, que lê exclusivamente
observações e geometria. Truth não é desserializada. O SHA256 do arquivo NPZ
cobre os bytes do arquivo sem interpretar qualquer campo truth.

O preflight reporta parcelas separadas para inputs da tabela, expansão C_full,
arrays próprios e tiles do loader, observações, bancos de média/covariância,
cópias nativas e temporários de validação do wrapper nativo intacto. Conta
as parcelas simultâneas por estágio, uma allowance de construção de 128 MiB
do banco de referência e `backend_workspace_allowance_bytes` explícitos.
O wrapper nativo ainda faz operações amplas; seus temporários recebem uma
parcela conservadora própria, não são escondidos no orçamento do loader.

O total também considera arrays de produção e uma estimativa conservadora
do histórico/seleção de treinamento e do seu batch completo. Os limites de
logL, raw ativo, quatro chains/replicates, seleção de EM e seeds são conferidos
sem executar treinamento. São estimativas numéricas, sem garantia de RSS;
overhead Python/allocator/file cache requer margem operacional adicional.

Chaves adicionais de `settings.budget`:

- `maximum_loader_owned_numeric_bytes`: cap do loader v2.
- `backend_workspace_allowance_bytes`: reserva externa explícita, ≥0.
- `validation_tile_size`: opcional, padrão 128.

Permanecem os caps C07 de numeric bytes, raw ativo e logL por fase/total.
`settings.require_C1` é opcional, padrão falso; C0, paridade e Bernstein são
checados pelo loader v2, e não substituem gates de resposta/likelihood.

## Schemas prospectivos para revisão ROOT

O produtor dos manifestos reais não foi implementado. Estes nomes e campos
constituem um contrato proposto que precisa de revisão antes da integração.

1. `C08_FROZEN_COEFFICIENT_TABLE_v1`: status `FROZEN_COEFFICIENT_TABLE`,
   variante, `coordinate: minus_beta`, `runtime_channels: 4`, `file_sha256`,
   `array_metadata` com shape/dtype/nbytes e `array_sha256` para nodes,
   matrices e coeff. Exige também `expanded_array_sha256` e a regra
   `all_channels_as_stored` (C_beta), `all_channels_stored_identical_first`
   (C_full K4) ou `repeat_first_channel_to_four` (C_full K1 opcional).
2. `C08_RESPONSE_FINITE_GATES_v1`: status
   `PASS_STATED_RESPONSE_GATES_ONLY`, variante própria, finalidade
   `response_validation` ou `synthetic_contract_test`, hashes do arquivo,
   arrays armazenados/expandidos, experimento, configuração de validação e
   observações. Exige máximos finitos abaixo dos cinco limiares registrados:
   `harmonic_matrix_coarse_fine` 1e-8, direto coarse/fine e direto/harmônico
   1e-7, ambos ΔlogL 1e-3. O primeiro limite é convergência da quadratura
   harmônica; **não limita diferenças entre splines coarse/fine**.
   Um status de representação, um manifesto C07 ou gate de outra variante
   são rejeitados. Gate sintético sempre bloqueia execução.
   Cada máximo precisa de `provenance` com scope, path/SHA256 do artefato e
   `source_field`. O scope `current_response` deve nomear a variante atual.
   C_full pode herdar somente convergência harmônica/direta com scope
   `inherited_first_channel`, `channel: 1` e `inherited_from_variant` explícito.
   Os gates de logL não podem ser herdados. O adaptador confere os hashes e
   os escopos; o produtor/revisor do gate responde pela extração dos máximos
   dos campos indicados. Não se fabricam zeros para evidência real ausente.
   `additional_checks` pode registrar checks próprios como moments/trace e
   SciPy: name, status PASS, maximum_error, absolute_tolerance e provenance
   de `current_response`. Eles são validados e reportados explicitamente,
   sem presumir que já existam quando a lista está vazia.
3. `C07_PUBLICATION_AND_RESOURCE_RELEASE_RECEIPT_v1`: status
   `C07_PUBLISHED_AND_RELEASED`, scope
   `C07_PUBLISHED_AND_WORKERS_MEMORY_RELEASED`, `released_for_c08: true`,
   `active_workers: 0`, identidade C07 e evidência de liberação com path/hash.
   Exige `publication` com status PUBLISHED, commit, tag, release_url HTTPS e
   evidência de publicação com path/hash. Zero workers, sozinho, não basta.
   O adaptador confere campos/hashes; a confirmação operacional de publicação
   e liberação pertence ao emissor do receipt e à revisão ROOT.
4. `C08_RUNTIME_EXECUTION_AUTHORIZATION_v1`: scope
   `C08_TRAINING_AND_IID_ONLY`, `execution_allowed: true`, variante,
   `runtime_identity`, `target_identity`, SHA256 canônico do budget e SHA256
   do receipt C07. Exige também `c07_published_commit`, `c07_published_tag`
   e `c07_publication_evidence_sha256` iguais aos do receipt. A autorização
   precisa corresponder ao runtime exato e à publicação confirmada.

`build()` e `require_execution()` verificam todos esses vínculos, além de
settings habilitados e treinamento aprovado, **antes** de construir banco.
Não é criado receipt ou autorização real automaticamente. Nenhuma alegação
de precisão posterior resulta destes testes ou dos gates finitos de tabela.

## Testes realizados

Comando: `VECLIB_MAXIMUM_THREADS=1 .venv/bin/python -B tmp/c08_runtime_design/test_c08_runtime.py`

Os testes usam matrizes sintéticas de 3 nós, quatro pulsars e quatro canais
(C_full também é testado com um canal armazenado). Cobrem init/preflight sem payloads/bancos,
coeficientes preservados sem respline, expansão C_full, identidade/namespace,
modelos externos e rotas internas, rejeições de manifests/gates/hashes/config,
NoTruth, orçamento antes do carregamento, autorização/publicação/receipt ligados,
mutação em memória/arquivo e preservação dos registros internos. Mesmo
autorização e receipt sintéticos válidos não habilitam um gate sintético.
Nenhuma chamada de likelihood ou quadratura integra a suíte.
