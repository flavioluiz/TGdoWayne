#!/usr/bin/env python3
"""Pure integer arithmetic for a prospective C_beta runtime; no scientific imports.

Reads only source text/settings and writes this calculation's JSON/Markdown.
It never opens a table, observation array, bank, native library, or truth file.
"""
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCES = [
    'configs/calibration/campaign_500_execution_v1.json',
    'src/inference/campaign_runtime.py',
    'tmp/c08_runtime_design/src/c08_runtime.py',
    'tmp/c08_runtime_design/src/frozen_coefficient_orf_v2.py',
    'src/inference/model.py',
    'src/pta/statistics.py',
    'src/inference/campaign_io.py',
    'src/inference/pointwise_preallocated.py',
    'src/inference/native_likelihood.py',
    'src/inference/campaign_training.py',
    'src/inference/mh_training.py',
]


def calculate():
    settings = json.loads((ROOT / SOURCES[0]).read_text())
    N, K, P, D, n, tile = 9248, 4, 12, 10, 500, 128
    I = N - 1
    steps = settings['training']['steps']
    selected = settings['training']['points_for_em']
    chains = settings['training']['chains']
    levels = settings['production']['levels']
    replicates = settings['production']['replicates']
    batch = settings['production']['likelihood_batch']
    cap = settings['budget']['maximum_numeric_bytes']
    assert (steps, selected, chains, levels, replicates, batch, cap) == (
        8192, 2048, 4, [16384, 65536], 4, 2048, 4 * 1024**3)
    coefficient, matrix = 4*I*K*P*P*16, N*K*P*P*16
    table_raw = 8*N + coefficient + matrix
    owned = 16*N + coefficient + matrix
    workspace, eigen = 41*tile*K*P*P, 8*tile*K*P
    observations = dict(q=n*K*P*16, x_physical=n*K*D*8, x_gaussian=n*K*D*8)
    geometry = dict(directions=P*3*8, distances_ly=P*8, sigma=P*8,
                    red_pattern=P*8, frequency_hz=K*8, scale=K*8)
    experiment = dict(points=P*3*8, distance_ly=P*8, sigma=P*8, red=P*8,
                      f=K*8, scale=K*8, H=D*P*P*16, weights=K*8)
    obs, exp_bytes = sum(observations.values()), sum(experiment.values())
    obs_scratch = max(*observations.values(), *geometry.values())
    mean, covariance = 8*I*K*6*D, 8*I*K*21*D*D
    packed = 8*I*K*21*D*(D+1)//2
    yz = 2*n*K*D*8 + 2*n*D*8
    bank_scratch = 128*1024**2
    loader_peak = table_raw + owned + workspace + eigen + obs
    observation_peak = owned + obs + obs_scratch
    reference_peak = owned + obs + mean + covariance + yz + bank_scratch
    native_owned = 16*N + coefficient + mean + packed + obs + yz + 8*(10+3*K+4*P)
    native_validation_terms = dict(three_coefficient_copies=3*coefficient,
                                   three_covariance_copies=3*covariance,
                                   two_packed_copies=2*packed)
    native_validation = max(native_validation_terms.values())
    native_peak = reference_peak + native_owned + native_validation
    raw_per_target = sum(levels)*replicates*(14*8+1) + len(levels)*replicates*65536
    production_batch = batch*K*(P*P*16 + 21*D*D*8)
    generic_spline = 4*coefficient + matrix + bank_scratch
    generic_retained = mean + covariance + coefficient + matrix + bank_scratch
    raw_active = raw_per_target*settings['production_targets_per_block']
    rows = []
    for backend in ('reference', 'native'):
        native = backend == 'native'
        construction = max(loader_peak, observation_peak, reference_peak,
                           native_peak if native else 0) + exp_bytes
        generic = max(generic_spline, generic_retained*(2 if native else 1)
                      + 3*raw_per_target) + production_batch
        production = construction + 3*raw_per_target + production_batch
        for block in (64, 32, 16):
            history = min(4000, steps)*chains*block*5*8
            retained = selected*block*5*8
            training_batch = block*chains*K*(P*P*16 + 21*D*D*8)
            training_workspace = 4*history + 3*retained + training_batch
            training = construction + training_workspace
            numeric = max(production, training)
            rows.append(dict(
                backend=backend, training_targets_per_block=block,
                generic_current_formula_bytes=generic,
                generic_formula_headroom_bytes=cap-generic,
                construction_numeric_base_bytes=construction,
                training_history_single_bytes=history,
                training_history_four_copy_allowance_bytes=4*history,
                training_retained_single_bytes=retained,
                training_retained_three_copy_allowance_bytes=3*retained,
                training_likelihood_batch_bytes=training_batch,
                training_workspace_bytes=training_workspace,
                training_numeric_base_bytes=training,
                production_numeric_base_bytes=production,
                maximum_numeric_base_bytes=numeric,
                dominating_phase='production' if production >= training else 'training',
                explicit_backend_allowance_bytes=0,
                remaining_4GiB_headroom_bytes=cap-numeric,
                remaining_4GiB_headroom_MiB=(cap-numeric)/1024**2,
                within_numeric_cap_before_backend_allowance=numeric <= cap,
                backend_allowance_rule='base + explicitly approved backend allowance <= cap; '
                                       'headroom is not an approved allowance or an RSS margin',
            ))
    result = dict(
        schema='C08_MEMORY_V2_ARITHMETIC_ONLY_v1',
        status='PURE_ARITHMETIC_NO_RUNTIME_OR_SCIENTIFIC_EXECUTION',
        dimensions=dict(response_variant='C_beta', N=N, intervals=I, K=K, P=P, D=D,
                        n_realizations=n, validation_tile_size=tile, stored_K=K),
        settings_extract=dict(training_steps=steps, points_for_em=selected, chains=chains,
                              production_levels=levels, production_replicates=replicates,
                              likelihood_batch=batch, production_targets_per_block=16,
                              maximum_numeric_bytes=cap,
                              maximum_active_raw_bytes=settings['budget']['maximum_active_raw_bytes']),
        unchanged_policy=dict(maximum_numeric_bytes=cap, settings_modified=False,
                              backend_allowance_approved=False, execution_authorized=False),
        assumptions=[
            'There are at least 64 selected targets; the C_beta CN/G 500-per-model '
            'domain would have 1000 targets. These memory formulas depend only on the active blocks.',
            'All table channels are stored (K=4), so there is no C_full channel expansion.',
            'Arrays use float64 or complex128. H is complex128: angular_estimators '
            'creates every estimator with np.zeros((P,P), complex), including imaginary cross bins.',
            'experiment weights are float64; source experiment returns the listed ndarray fields. '
            'T/dt, labels, Python metadata and allocator overhead are outside the numeric-array sum.',
            'The 128 MiB reference construction allowance is retained from source, '
            'distinct from an explicit backend workspace allowance.',
            'Native owned and validation terms reproduce the conservative C08 candidate formula, '
            'including its observation overestimate; these are arithmetic estimates, not measured RSS.',
            'C08 adds phase workspaces to the maximum construction envelope, conservatively '
            'combining allocations that need not peak simultaneously.',
            'The current generic formula does not include a training-block-dependent workspace '
            'or the C08 caller/owned/explicit native validation accounting. Its lower native result '
            'is not evidence that the C08 estimate can be replaced by that proxy.',
            'The generic settings supply only numeric recipe values here. Their existing '
            'C07 authorization/model labels/seeds do not authorize a C08 campaign.',
        ],
        arrays_and_components_bytes=dict(
            coefficient=coefficient, matrix=matrix, table_source_nodes=8*N,
            table_source_arrays=table_raw, loader_owned_persistent=owned,
            loader_workspace=workspace, loader_eigenvalue_result=eigen,
            loader_owned_peak=owned+workspace+eigen,
            loader_caller_plus_owned_peak_without_observations=table_raw+owned+workspace+eigen,
            loader_caller_plus_owned_peak_with_observations=loader_peak,
            observation_arrays=obs, observation_fields=observations,
            observation_read_scratch=obs_scratch, observation_loading_peak=observation_peak,
            experiment_arrays=exp_bytes, experiment_fields=experiment,
            reference_meanbank=mean, reference_covbank=covariance,
            reference_bank_total=mean+covariance, reference_y_z=yz,
            reference_construction_allowance=bank_scratch, reference_peak=reference_peak,
            native_packed_covariance=packed, native_owned_estimate=native_owned,
            native_validation_terms=native_validation_terms,
            native_validation_temporary_allowance=native_validation,
            native_construction_peak=native_peak,
            raw_per_target=raw_per_target, raw_per_active_block=raw_active,
            production_three_target_raw_allowance=3*raw_per_target,
            production_likelihood_batch=production_batch,
            generic_spline_proxy=generic_spline, generic_retained_proxy=generic_retained,
        ),
        active_raw_within_cap=raw_active <= settings['budget']['maximum_active_raw_bytes'],
        rows=rows,
        limitations=dict(RSS_guaranteed=False, backend_workspace_measured=False,
                         numeric_arrays_allocated=False, scientific_library_imports=False,
                         real_table_opened=False, observations_opened=False,
                         bank_built=False, native_library_loaded=False,
                         likelihood_evaluations=0, quadratures=0,
                         posterior_validated=False),
        source_sha256={path: hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in SOURCES},
        calculation_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    )
    return result


def markdown(result):
    c = result['arrays_and_components_bytes']
    lines = [
        '# C08 v2: aritmética de memória prospectiva', '',
        'Somente aritmética inteira, com N=9.248, K=4, P=12, D=10 e n=500. '
        'Não foram abertos dados/tabelas, construídos bancos, carregado backend, '
        'nem executadas verossimilhanças ou quadraturas. O limite permanece '
        '**4.294.967.296 bytes (4 GiB)**.', '',
        'A receita numérica é lida de `configs/calibration/campaign_500_execution_v1.json`: '
        '8.192 passos, quatro cadeias, 2.048 pontos para EM, níveis IID 16.384/65.536, '
        'quatro réplicas, lote de verossimilhança 2.048 e 16 alvos por bloco de produção. '
        'Esse uso aritmético não transfere autorização, rótulos ou sementes de C07 a C08.', '',
        'A reserva adicional de backend é **zero apenas como base de comparação**. '
        'Cada margem abaixo é o teto aritmético disponível para uma reserva explicitamente '
        'aprovada; não é uma reserva escolhida nem garantia de RSS.', '',
        '| Backend | Bloco treinamento | Genérico atual (bytes) | C08 treinamento (bytes) | '
        'C08 produção/máximo (bytes) | Margem C08 até 4 GiB (bytes) |',
        '|---|---:|---:|---:|---:|---:|',
    ]
    for row in result['rows']:
        lines.append('| {backend} | {training_targets_per_block} | '
                     '{generic_current_formula_bytes:,} | {training_numeric_base_bytes:,} | '
                     '{maximum_numeric_base_bytes:,} | {remaining_4GiB_headroom_bytes:,} |'.format(**row))
    lines.extend([
        '',
        'No cálculo C08 a produção domina os três tamanhos de bloco. O máximo de referência '
        'é **1.469.913.376 bytes (1,368964 GiB)**; o máximo nativo é '
        '**4.035.765.872 bytes (3,758600 GiB)**, deixando **259.201.424 bytes '
        '(247,193741 MiB)** antes de qualquer reserva adicional de backend. '
        'Reduzir somente o bloco de treinamento não reduz esse máximo.', '',
        'A fórmula genérica atual retorna 1.739.472.896 bytes na referência e '
        '2.668.119.040 bytes no nativo para qualquer bloco. Ela contém um pico de '
        'construção de spline e um proxy de cópia nativa, mas não representa o histórico '
        'de treinamento por bloco, o chamador simultâneo ao loader ou os grandes '
        'temporários de validação nativa da estimativa C08. Os números não são '
        'medições intercambiáveis de RSS.', '',
        '## Componentes da conta', '',
        '| Componente | Bytes |', '|---|---:|',
    ])
    component_labels = [
        ('Coeficientes complex128', 'coefficient'), ('Matrizes complex128', 'matrix'),
        ('Arrays da tabela no chamador', 'table_source_arrays'),
        ('Loader: propriedade persistente', 'loader_owned_persistent'),
        ('Loader: buffers de validação', 'loader_workspace'),
        ('Loader: resultado de autovalores', 'loader_eigenvalue_result'),
        ('Loader: pico próprio', 'loader_owned_peak'),
        ('Chamador + loader, sem observações', 'loader_caller_plus_owned_peak_without_observations'),
        ('Chamador + loader + observações', 'loader_caller_plus_owned_peak_with_observations'),
        ('Observações q/x_physical/x_gaussian', 'observation_arrays'),
        ('Arrays do experimento', 'experiment_arrays'),
        ('Banco de médias', 'reference_meanbank'),
        ('Banco de covariâncias', 'reference_covbank'),
        ('Cópias y/z', 'reference_y_z'),
        ('Reserva de construção de referência', 'reference_construction_allowance'),
        ('Pico de construção de referência antes do experimento/backend', 'reference_peak'),
        ('Covariâncias nativas empacotadas', 'native_packed_covariance'),
        ('Cópias próprias nativas estimadas', 'native_owned_estimate'),
        ('Temporários de validação nativa', 'native_validation_temporary_allowance'),
        ('Pico de construção nativa antes do experimento/backend', 'native_construction_peak'),
        ('Raw por alvo', 'raw_per_target'), ('Raw ativo, 16 alvos', 'raw_per_active_block'),
        ('Reserva de três arrays raw por alvo na produção', 'production_three_target_raw_allowance'),
        ('Lote de verossimilhança da produção', 'production_likelihood_batch'),
    ]
    lines.extend(f'| {label} | {c[key]:,} |' for label, key in component_labels)
    lines.extend([
        '',
        '`H` é **complex128**, conforme `angular_estimators`: shape (10,12,12), '
        '23.040 bytes. Somam-se points, distâncias, sigma, padrão vermelho, frequências, '
        'scale e weights para 23.712 bytes de arrays do experimento. Os pesos são '
        'assumidos float64. Os escalares T/dt e metadados Python não entram nesta soma.', '',
        '| Bloco | Histórico simples | Reserva 4× histórico | Pontos retidos simples | '
        'Reserva 3× retidos | Lote LL treinamento | Workspace total |',
        '|---:|---:|---:|---:|---:|---:|---:|',
    ])
    for row in result['rows'][:3]:
        lines.append('| {training_targets_per_block} | {training_history_single_bytes:,} | '
                     '{training_history_four_copy_allowance_bytes:,} | {training_retained_single_bytes:,} | '
                     '{training_retained_three_copy_allowance_bytes:,} | {training_likelihood_batch_bytes:,} | '
                     '{training_workspace_bytes:,} |'.format(**row))
    lines.extend([
        '',
        'O histórico simples usa min(4.000, passos) × 4 cadeias × bloco × 5 parâmetros × 8 bytes; '
        'os retidos simples usam 2.048 × bloco × 5 × 8. Os fatores 4 e 3 e o lote de '
        'treinamento reproduzem o allowance conservador de `c08_runtime.py`. '
        'A produção acrescenta três vezes o raw por alvo e '
        '2.048 × 4 × (12² × 16 + 21 × 10² × 8). O raw ativo ocupa '
        '600.834.048 bytes e fica abaixo do teto independente de 1 GiB.', '',
        'A validação nativa acrescenta max(3 × coeficientes, 3 × banco de covariância, '
        '2 × covariância empacotada) = 1.864.195.200 bytes. A conta preserva a '
        'estimativa conservadora do candidato, inclusive sua soma do envelope de '
        'construção aos workspaces de fase; não determina o pico físico exato.', '',
        '## Reprodução e limites', '',
        'Execute `python3 -B tmp/c08_runtime_design/memory_v2_arithmetic.py` na raiz. '
        '`memory_v2_arithmetic.json` contém todos os componentes, fórmulas concretizadas, '
        'hipóteses e hashes das fontes/configuração e do script. Somente biblioteca padrão '
        'Python é importada. Nenhuma configuração de campanha é alterada.', '',
        'Overhead de Python/allocator, cache de arquivos e workspaces efetivos de backend '
        'permanecem fora da base. Não há garantia de RSS, medição de backend, autorização '
        'de execução ou validação de posterior neste artefato.', '',
    ])
    return '\n'.join(lines)


if __name__ == '__main__':
    result = calculate()
    (OUT/'memory_v2_arithmetic.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    (OUT/'MEMORY_V2_ARITHMETIC.md').write_text(markdown(result))
    print(json.dumps(dict(status=result['status'], rows=result['rows']), indent=2))
