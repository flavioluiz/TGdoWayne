"""Tiny synthetic representation/kernel test, not a PTA response approval."""
from pathlib import Path
import sys,json,unittest,hashlib
import numpy as np
from scipy.stats import multivariate_normal
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(HERE/'src'));sys.path.insert(0,str(ROOT/'tmp/c08_beta_table'))
from frozen_coefficient_orf import FrozenCoefficientORF
from inference.model import experiment
from inference.pointwise_preallocated import PreallocatedCubicPointLikelihood
from inference.native_likelihood import NativeLikelihood
from inference.linalg_batch import forward_substitution
from gate_kernel import direct_trace_moments
class Tests(unittest.TestCase):
 def test_compressed_CN_G_internal_routes(self):
  cfg=json.loads((ROOT/'configs/calibration/pilot_initial.json').read_text());e=experiment(cfg);rng=np.random.default_rng(808130301);P=12;K=4;D=10;R=2
  n=np.array([0.,.5,1.]);m=np.array([1.,1.2,2.])[:,None,None,None]*np.array([1.,.8,1.3,.6])[None,:,None,None]*np.eye(P)[None,None]
  c=np.zeros((2,4,K,P,P),complex);c[:,0]=m[:-1];c[0,1]=m[1]-m[0];c[1,1]=2*(m[2]-m[1]);c[1,2]=-(m[2]-m[1])
  table=FrozenCoefficientORF(n,m.astype(complex),c,maximum_owned_numeric_bytes=2**20)
  data=dict(q=(rng.normal(size=(R,K,P))+1j*rng.normal(size=(R,K,P)))/np.sqrt(2),x_physical=rng.normal(size=(R,K,D)),x_gaussian=rng.normal(size=(R,K,D)))
  reference=PreallocatedCubicPointLikelihood(e,data,table,maximum_estimated_numeric_bytes=256*1024**2);reference.solve=forward_substitution
  native_dir=ROOT/'tmp/native/c586a0637ce30e440b8a5235';manifest=json.loads((native_dir/'build_manifest.json').read_text());library=native_dir/'libpta_likelihood.dylib'
  self.assertEqual(hashlib.sha256(library.read_bytes()).hexdigest(),manifest['binary_sha256'])
  bounds=np.array(cfg['prior']['bounds']);kernel=NativeLikelihood(reference,bounds,library);theta=bounds[:,0]+rng.uniform(size=(64,5))*np.diff(bounds)[:,0];targets=np.array([(2 if j%2==0 else 4)*R+(j//2)%R for j in range(64)])
  actual=kernel(theta,targets);ref=reference(theta,targets);np.testing.assert_allclose(actual,ref,rtol=2e-12,atol=1e-8)
  z=np.einsum('rkd,k->rd',np.concatenate([data['x_physical'],data['x_gaussian']]),e['weights']);direct=[]
  for t,target in zip(theta,targets):
   mu,cov=direct_trace_moments(t[None,1:],table(t[:1])[0],e);i=target%R+(R if target//R==4 else 0);direct.append(multivariate_normal.logpdf(z[i],mean=mu[0],cov=cov[0]))
  np.testing.assert_allclose(actual,direct,rtol=2e-12,atol=1e-8)
  report=dict(status='SMALL_SYNTHETIC_COEFFICIENT_NATIVE_ROUTES_PASS',points=64,internal_routes=['B_CN','B_G'],max_native_reference=float(np.max(abs(actual-ref))),max_native_direct_trace_scipy=float(np.max(abs(actual-direct))),no_spline_fit=True,no_PTA_response_or_posterior_validation_claim=True,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),coefficient_loader_sha256=hashlib.sha256((HERE/'src/frozen_coefficient_orf.py').read_bytes()).hexdigest(),native_binary_sha256=manifest['binary_sha256'])
  with (HERE/'small_native_routes.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
if __name__=='__main__':unittest.main(verbosity=2)
