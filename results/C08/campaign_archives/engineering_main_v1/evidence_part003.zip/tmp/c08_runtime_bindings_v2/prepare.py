"""Bind finite response evidence to the declared C08 domain; no execution approval."""
from pathlib import Path
import hashlib, json, sys, math
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'tmp/c08_runtime_design/src')]
from c08_runtime_v2 import domain_descriptor, REVIEWED_CHECKS, PENDING_POSTERIOR_CHECKS
from c08_runtime import GATE_LIMITS
from inference.campaign_io import canonical_hash

def read(path):return json.loads(Path(path).read_text())
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
    return h.hexdigest()
def write(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
def evidence(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))

def main():
    source=ROOT/'tmp/c08_runtime_inputs/finite_evidence_aggregate.json'
    aggregate=read(source)
    for p,h in aggregate['source_sha256'].items():assert sha(ROOT/p)==h,p
    domain_review=ROOT/'tmp/c08_domain_review/review.json'
    review=read(domain_review)
    for p,h in review['source_sha256'].items():assert sha(ROOT/p)==h,p
    tested_config=ROOT/'configs/calibration/pilot_initial.json'
    tested_data=ROOT/'results/C07/fixtures/pilot_data.npz'
    generating_config=ROOT/'configs/calibration/prior_predictive_500_v1.json'
    generating_record=ROOT/'results/C07/prior_predictive/generation.json'
    runtime_data=ROOT/'results/C07/prior_predictive/data.npz'
    tested_provenance=HERE/'tested_generation_provenance.json'
    write(tested_provenance,dict(schema='C08_REVIEWED_HISTORICAL_FIXTURE_GENERATION_PROVENANCE_v1',
        status='REVIEWED_ARCHIVED_FIXTURE_NOT_ORIGINAL_EXECUTION_RECEIPT',
        configuration_sha256=sha(tested_config),observations_sha256=sha(tested_data),
        datasets_per_model=16,observation_models=['CN','G'],
        evidence=[evidence(domain_review),evidence(ROOT/'results/C07/fixtures/copied_fixture_inventory.json'),
                  evidence(ROOT/'results/C07/pilot_initial/README.md'),
                  evidence(ROOT/'results/C07/publication_portability/local_tests.log')],
        interpretation='Historical fixture copied byte for byte; geometry/statistics correspondence reviewed and all16 draws reproduced by the preserved exact-node test. Source-at-integration snapshot is not claimed to be the exact original source of every earlier execution.',
        original_execution_source_snapshot_claimed=False,new_draws_in_this_preparation=0))
    tested_inputs=dict(configuration_sha256=sha(tested_config),generation_sha256=sha(tested_provenance),
                       observations_sha256=sha(tested_data))
    descriptor=domain_descriptor(read(tested_config))
    variants={}
    for variant in ('C_beta','C_full'):
        analysis=ROOT/('tmp/c08_truth_diagnostic_runner/configs/'+variant+'_analysis.json')
        cfg=read(analysis);assert domain_descriptor(cfg)==descriptor
        table_manifest=ROOT/('tmp/c08_runtime_inputs/'+variant+'_table_manifest.json')
        manifest=read(table_manifest)
        original_manifest=table_manifest
        for metadata in manifest['array_metadata'].values():
            assert metadata['dtype'] in ('<f8','<c16')
            metadata['nbytes']=math.prod(metadata['shape'])*(8 if metadata['dtype']=='<f8' else 16)
        manifest['metadata_correction']=dict(original_path=str(original_manifest),original_sha256=sha(original_manifest),
            reason='Add required nbytes from shape/dtype; no array, coefficient or file hash changes.')
        table_manifest=HERE/(variant+'_table_manifest.json')
        write(table_manifest,manifest)
        validation=HERE/(variant+'_validation_domain.json')
        write(validation,dict(schema='C08_VALIDATION_DOMAIN_v1',response_variant=variant,
              parameters=cfg['parameters'],prior=cfg['prior'],scope='Finite engineering domain, no posterior certificate'))
        gate=HERE/(variant+'_response_gates.json')
        maxima=aggregate['maxima'][variant]
        assert set(maxima)==set(GATE_LIMITS) and all(0<=maxima[k]<=v for k,v in GATE_LIMITS.items())
        write(gate,dict(schema='C08_RESPONSE_FINITE_GATES_v2',status='PASS_STATED_RESPONSE_GATES_ONLY',
            response_variant=variant,purpose='response_validation',table_file_sha256=manifest['file_sha256'],
            array_sha256=manifest['array_sha256'],expanded_array_sha256=manifest['expanded_array_sha256'],
            thresholds=GATE_LIMITS,maxima=maxima,tested_domain_inputs=tested_inputs,
            tested_observation_scope=dict(dataset_count_per_model=16,observation_models=['CN','G'],
                                          total_observations=32,declared_checks_only=True),
            evidence_scope='FINITE_ENGINEERING_DOMAIN_ONLY',runtime_population_validation_claimed=False,
            posterior_region_checks_status='PENDING',
            provenance={k:dict(**evidence(source),source_field='maxima.'+variant+'.'+k,
                               scope='current_response',response_variant=variant) for k in GATE_LIMITS},
            additional_checks=[],interpretation=aggregate['derivation'],
            limits=aggregate['limits'],reviewer='ROOT'))
        compatibility=HERE/(variant+'_domain_compatibility.json')
        write(compatibility,dict(schema='C08_ENGINEERING_RUNTIME_DOMAIN_COMPATIBILITY_v1',
            status='APPROVED_DOMAIN_COMPATIBILITY_FINITE_ENGINEERING_ONLY',response_variant=variant,
            tested_domain_inputs=tested_inputs,
            runtime_experiment=dict(configuration_sha256=sha(analysis),generation_sha256=sha(generating_record),
                                    observations_sha256=sha(runtime_data),validation_config_sha256=sha(validation)),
            response_gate_sha256=sha(gate),tested_domain_descriptor_sha256=canonical_hash(descriptor),
            runtime_domain_descriptor_sha256=canonical_hash(domain_descriptor(cfg)),
            evidence_scope='FINITE_ENGINEERING_DOMAIN_ONLY',runtime_population_validation_claimed=False,
            posterior_region_checks_status='PENDING',pending_posterior_checks=PENDING_POSTERIOR_CHECKS,
            reviewed_checks={k:True for k in REVIEWED_CHECKS},
            population_and_label_differences=dict(tested_datasets_per_model=16,runtime_datasets_per_model=500,
                tested_model_labels=read(tested_config)['models'],runtime_model_labels=cfg['models'],
                observation_payloads_may_differ=True),
            approval=dict(approved_by='ROOT',decision_id='C08_DOMAIN_BINDING_FINITE_RESPONSE_v1'),
            review_evidence=[evidence(domain_review),evidence(tested_provenance),
                             evidence(ROOT/'results/C07/data500_independent_review/review.json')],
            scope_note='The historical generation provenance review is explicit; no exact original source snapshot or new runtime-population validation is asserted.'))
        variants[variant]=dict(experiment=str(analysis),table_manifest=str(table_manifest),
             validation_config=str(validation),gate_manifest=str(gate),tested_experiment=str(tested_config),
             tested_generation=str(tested_provenance),tested_observations=str(tested_data),
             runtime_generation=str(generating_record),domain_compatibility=str(compatibility),
             data=str(runtime_data),c07_config=str(generating_config),c07_generation=str(generating_record))
    write(HERE/'bindings.json',dict(schema='C08_RUNTIME_BINDINGS_PREPARATION_v1',variants=variants,
          preparation_source_sha256=sha(__file__),ORF_evaluations=0,likelihood_evaluations=0,
          truth_arrays_read=False,bank_constructed=False,execution_authorized=False))
    print('Two finite gate/domain bindings prepared; execution remains disabled.')

if __name__=='__main__':main()
