"""Metadata-only real-domain C08 runtime/driver preflight; never builds a bank."""
from pathlib import Path
import json, sys, resource, time
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts'),str(ROOT/'tmp/c08_driver_design'),
              str(ROOT/'tmp/c08_runtime_design/src')]
from c08_runtime_v2 import C08Runtime
from run_c08_campaign import campaign_plan

def main():
    bindings=json.loads((HERE/'bindings.json').read_text())
    for variant,p in bindings['variants'].items():
        table=(ROOT/'tmp/c08_beta_table_v2_continuation/results/C_beta_common_table.npz'
               if variant=='C_beta' else ROOT/'tmp/c08_full_local_v2_execution/results/C_full_table.npz')
        for phase in ('engineering','main'):
            runtime=C08Runtime(p['experiment'],p['data'],table,p['table_manifest'],p['validation_config'],
                ROOT/f'tmp/c08_driver_design/configs/{variant}_{phase}_settings.json',p['gate_manifest'],
                response_variant=variant,tested_experiment_path=p['tested_experiment'],
                tested_generation_path=p['tested_generation'],tested_observations_path=p['tested_observations'],
                runtime_generation_path=p['runtime_generation'],domain_compatibility_path=p['domain_compatibility'],
                c07_release_receipt_path=ROOT/'tmp/c08_G0/c07_publication_resource_release.json',
                native_library_path=ROOT/'tmp/native/c586a0637ce30e440b8a5235/libpta_likelihood.dylib',
                native_build_manifest_path=ROOT/'tmp/native/c586a0637ce30e440b8a5235/build_manifest.json',
                threads=6,training_threads=1,build=False)
            try:
                context=dict(cohort_index=ROOT/'tmp/c08_driver_design/configs/cohort_index.json',
                             c07_config=p['c07_config'],c07_generation=p['c07_generation'])
                plan=campaign_plan(runtime,ROOT/f'tmp/c08_driver_design/configs/diagnostics_{phase}.json',
                                   p['data'],None,ROOT/'tmp/c08_posterior_campaign',context=context)
                assert not plan['execution_ready'] and runtime.engine is None and runtime.table is None
                with (HERE/f'{variant}_{phase}_preflight.json').open('x') as f:
                    json.dump(plan,f,indent=2);f.write('\n')
                print(json.dumps(dict(variant=variant,phase=phase,targets=plan['targets'],
                    numeric_bytes=plan['estimated_numeric_bytes'],LL=plan['planned_training_plus_production_likelihood_values'],
                    pending=plan['pending'])),flush=True)
            finally:runtime.close()
    print(json.dumps(dict(CPU_seconds=time.process_time(),RSS_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                          ORF_calls=0,likelihood_values=0,bank_constructed=False)))

if __name__=='__main__':main()
