"""Prospective truth-diagnostic contract. Stdlib only; never reads numeric arrays."""
from pathlib import Path
import hashlib,json,math,platform,resource,sys
from importlib.metadata import version
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SCOPE='C08_FIXED_TRUTH_DIAGNOSTIC_ONLY_NO_TRAINING_OR_POSTERIOR'
AUTH_SCHEMA='ROOT_C08_TRUTH_DIAGNOSTIC_AUTHORIZATION_v1'
CAPS=dict(real_proxy=350000000000,CPU_seconds=600,RSS_bytes=1610612736,numeric_ORF_bytes=1073741824,
 moment_bytes=268435456,likelihood_values=512,raw_direct_sky_points=0,output_bytes=20*1024**2,workers=13,concurrency=1,BLAS_threads=1,batch_size=4)
PARENT_RESERVE_BYTES=64*1024**2

def require(ok,message):
 if not ok:raise ValueError(message)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def read(path):return json.loads(Path(path).read_text())
def rss():
 r=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 return int(r if sys.platform=='darwin' else r*1024)
def saved_bytes(path):return sum(p.stat().st_size for p in Path(path).rglob('*') if p.is_file())
def write_new(path,value,root=None):
 payload=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
 if root is not None:require(saved_bytes(root)+len(payload)<=CAPS['output_bytes'],'Output cap before write')
 with Path(path).open('xb') as f:f.write(payload)
def canonical_sha(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def input_hashes(spec):return {p:sha(ROOT/p) for p in spec['input_sha256']}
def source_hashes(spec):return {p:sha(ROOT/p) for p in spec['source_sha256']}
def unchanged(spec):return input_hashes(spec)==spec['input_sha256'] and source_hashes(spec)==spec['source_sha256']

def validate_spec(spec):
 require(spec.get('schema')=='C08_TRUTH_DIAGNOSTIC_EXECUTION_SPEC_v1' and spec.get('scope')==SCOPE
  and spec.get('execution_allowed') is False,'Prospective fixed diagnostic spec required')
 require(spec['caps']==CAPS and all(type(v) is int for v in spec['caps'].values()),'Frozen integer caps required')
 ids=spec['cohort_ids'];require(type(ids) is list and len(ids)==32 and ids==sorted(set(ids)) and all(type(i) is int and 0<=i<500 for i in ids),'Frozen32 unique data IDs required')
 candidate=read(ROOT/spec['paths']['arithmetic_candidate'])
 require(ids==candidate['cohort_ids'],'Cohort differs from reviewed arithmetic')
 require(len(spec['jobs'])==13 and spec['jobs'][-1]==dict(name='moments',kind='moments',real_proxy=0,likelihood_values=512),'Twelve harmonic jobs plus one moment worker required')
 total=0
 for index,job in enumerate(spec['jobs'][:-1]):
  require({key:job[key] for key in candidate['jobs'][index]}==candidate['jobs'][index],'Exact three harmonic resolutions/allowances changed')
  k,j=divmod(index,3);require(job['channel']==k+1 and job['level']==j and job['name']==f'harmonic_{k+1:02d}_{j}' and job['kind']=='harmonic','Harmonic order changed')
  l,n=job['lmax']-1,job['nmu'];P,N=12,32
  expected=4*n*l+6*P*P*l+2*N*P*n*l+6*N*P*P*l+40*N*P*n
  require(job['real_proxy']==expected and job['requested_frequency_nodes']==32 and job['likelihood_values']==0,'No coarse/fine reuse credit; full32 nodes per resolution')
  require(job['numeric_allowance_bytes']<=CAPS['numeric_ORF_bytes'],'ORF estimate exceeds cap')
  total+=expected
 require(total==289936637860 and total<=CAPS['real_proxy'],'Exact inherited arithmetic differs')
 require(spec['versions']==dict(python=platform.python_version(),numpy=version('numpy'),scipy=version('scipy')),'Numerical versions changed')
 require(spec['counts']==dict(physical_frequency_nodes=128,matrices_all_resolutions=384,likelihood_per_resolution=128,likelihood_resolutions=3,SciPy_likelihood_values=128,total_likelihood_values=512,new_physical_draws=0,new_raw_direct_sky_points=0),'Work scope changed')
 require(set(spec['runtime_experiments'])=={'C_beta','C_full'},'Both runtime config bindings required')
 cfg=read(ROOT/spec['paths']['c07_config']);index=read(ROOT/spec['paths']['cohort_index']);generation=read(ROOT/spec['paths']['generation'])
 require(cfg['parameters']==spec['parameters'] and cfg['prior']['bounds']==spec['prior_bounds'] and cfg['n_realizations']==500,'Original coordinates/prior/data size')
 require(ids==sorted(index['representative_ids']+index['stress_ids']),'Driver frozen cohort differs')
 for key,path in [('data_sha256','data'),('generation_config_sha256','c07_config'),('generation_sha256','generation'),('design_sha256','c08_design'),('cohort_manifest_sha256','cohort_manifest')]:
  require(index[key]==spec['input_sha256'][spec['paths'][path]],'Driver cohort binding differs: '+key)
 require(generation['data_sha256']==index['data_sha256'] and generation['config_sha256']==index['generation_config_sha256'] and generation['realizations']==500,'Original generation binding differs')
 for variant,path in spec['runtime_experiments'].items():
  derived=read(ROOT/path)
  require(derived.get('response_variant')==variant and derived.get('models')==[variant+'_CN',variant+'_G'],'Own variant-specific experiment required')
  allowed={'models','response_variant','status','scope'}
  require({k:v for k,v in derived.items() if k not in allowed}=={k:v for k,v in cfg.items() if k not in allowed},'C08 config changed C07 physical experiment or prior')
  rows=read(ROOT/spec['paths'][variant+'_target_index'])
  require(rows==spec['target_indexes'][variant] and len(rows)==64,'Frozen exact target index')
  for row,(suffix,base,datum) in zip(rows,[(s,b,d) for s,b in [('_CN',1000),('_G',2000)] for d in ids]):
   require(row['model']==variant+suffix and row['datum']==datum and row['internal_target']==base+datum,'Scientific/internal target binding differs')
 require(unchanged(spec),'Frozen input/source changed')
 return total

def evidence_items(path,items):
 require(isinstance(items,list) and bool(items),'Nonempty hashed evidence required')
 seen=set()
 for item in items:
  require(isinstance(item,dict) and set(item)=={'path','sha256'},'Malformed evidence binding')
  p=Path(item['path']);p=p if p.is_absolute() else Path(path).parent/p;p=p.resolve()
  require(p not in seen and p!=Path(path).resolve() and sha(p)==item['sha256'],'Evidence hash/duplicate/self-reference')
  seen.add(p)

def validate_release(path,spec):
 r=read(path)
 require(r.get('schema')=='C07_PUBLICATION_AND_RESOURCE_RELEASE_RECEIPT_v1'
  and r.get('status')=='C07_PUBLISHED_AND_RELEASED' and r.get('scope')=='C07_PUBLISHED_AND_WORKERS_MEMORY_RELEASED'
  and r.get('released_for_c08') is True and type(r.get('active_workers')) is int and r['active_workers']==0,
  'C07 publication and workers/memory release required; resource-only receipt is insufficient')
 p=r.get('publication',{});commit=p.get('commit');tag=p.get('tag')
 require(p.get('status')=='PUBLISHED' and isinstance(commit,str) and len(commit) in (40,64)
  and all(c in '0123456789abcdef' for c in commit) and isinstance(tag,str) and bool(tag.strip())
  and isinstance(p.get('release_url'),str) and p['release_url'].startswith('https://'),'Published commit/tag/release evidence required')
 evidence_items(path,[p.get('evidence')]);evidence_items(path,r.get('evidence'))
 require(isinstance(r.get('c07_runtime_identity'),str) and len(r['c07_runtime_identity'])==64
  and all(c in '0123456789abcdef' for c in r['c07_runtime_identity']),'C07 runtime identity required')
 return r

def validate_g0(path,release_path,spec):
 g=read(path)
 expected=dict(schema='C08_G0_FROZEN_DIAGNOSTIC_INPUTS_v1',status='G0_PASS',approved_by='ROOT',
  c07_release_receipt_sha256=sha(release_path),data_sha256=spec['input_sha256'][spec['paths']['data']],
  generation_config_sha256=spec['input_sha256'][spec['paths']['c07_config']],
  generation_sha256=spec['input_sha256'][spec['paths']['generation']],
  c08_design_sha256=spec['input_sha256'][spec['paths']['c08_design']],
  cohort_manifest_sha256=spec['input_sha256'][spec['paths']['cohort_manifest']],
  cohort_index_sha256=spec['input_sha256'][spec['paths']['cohort_index']],
  runtime_experiment_sha256={v:spec['input_sha256'][p] for v,p in spec['runtime_experiments'].items()})
 require(all(g.get(k)==v for k,v in expected.items()),'G0 must bind published C07 and the frozen C08 contract/cohort/configs')
 evidence_items(path,g.get('evidence'));return g

def load_authorized(spec_path,approval_path,release_path,g0_path):
 spec=read(spec_path);validate_spec(spec)
 release=validate_release(release_path,spec);validate_g0(g0_path,release_path,spec);a=read(approval_path)
 require(a.get('schema')==AUTH_SCHEMA and a.get('approved_by')=='ROOT' and a.get('execution_allowed') is True
  and a.get('scope')==SCOPE and a.get('execution_spec_sha256')==sha(spec_path) and a.get('caps')==CAPS
  and a.get('source_sha256')==spec['source_sha256'] and a.get('input_sha256')==spec['input_sha256']
  and a.get('c07_release_receipt_sha256')==sha(release_path) and a.get('g0_sha256')==sha(g0_path)
  and a.get('c07_published_commit')==release['publication']['commit']
  and a.get('c07_publication_evidence_sha256')==release['publication']['evidence']['sha256']
  and a.get('truth_access')=='DIAGNOSTIC_PRODUCER_ONLY' and a.get('no_training_or_proposal_use') is True,
  'Exact separate ROOT truth-diagnostic approval required')
 require(all(type(v) is int for v in a['caps'].values()),'Authorization caps must be integers, not booleans')
 return spec,a

def preflight(spec_path):
 spec=read(spec_path);validate_spec(spec)
 return dict(status='PROSPECTIVE_C08_TRUTH_PRODUCER_G0_PUBLICATION_AUTHORIZATION_PENDING',execution_enabled=False,
  spec_sha256=sha(spec_path),source_count=len(spec['source_sha256']),input_count=len(spec['input_sha256']),
  counts=spec['counts'],planned_real_proxy=289936637860,real_margin=CAPS['real_proxy']-289936637860,
  maximum_ORF_numeric_allowance_bytes=max(j.get('numeric_allowance_bytes',0) for j in spec['jobs']),
  caps=CAPS,truth_or_observation_arrays_read=False,physical_calls=0,
  pending=['C07 publication/resource release receipt','G0 frozen-inputs receipt','separate ROOT producer authorization'])
