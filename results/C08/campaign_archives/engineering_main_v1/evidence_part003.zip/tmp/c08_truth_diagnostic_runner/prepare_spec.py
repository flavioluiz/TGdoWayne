"""Metadata-only specification builder. Never deserializes a real numeric array."""
from pathlib import Path
import ast,copy,json,platform,struct,zipfile
from importlib.metadata import version
from contract import HERE,ROOT,CAPS,SCOPE,sha,read,require,write_new


def exact_or_new(path,value):
 payload=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
 if path.exists():require(path.read_bytes()==payload,'Existing metadata differs; preserve it and revise prospectively: '+str(path))
 else:path.write_bytes(payload)


def headers(path):
 result={}
 with zipfile.ZipFile(path) as z:
  for member in z.infolist():
   with z.open(member) as f:
    require(f.read(6)==b'\x93NUMPY','Expected NPY member header')
    major,minor=f.read(2);size=struct.unpack('<H' if major==1 else '<I',f.read(2 if major==1 else 4))[0]
    require(size<16384,'Small bounded NPY header')
    header=ast.literal_eval(f.read(size).decode('latin1'))
   result[member.filename]=dict(shape=list(header['shape']),dtype=header['descr'],expanded_member_bytes=member.file_size)
 return result


def build():
 paths=dict(data='results/C07/prior_predictive/data.npz',c07_config='configs/calibration/prior_predictive_500_v1.json',
  generation='results/C07/prior_predictive/generation.json',arithmetic_candidate='tmp/c08_truth_diagnostic_design/preflight_candidate.json',
  cohort_manifest='tmp/c08_cohort_frozen/cohort_manifest.json',cohort_index='tmp/c08_driver_design/configs/cohort_index.json',
  c08_design='tmp/c08_execution_design/config_prospectiva.json',
  C_beta_target_index='tmp/c08_driver_design/configs/C_beta_main_target_index.json',
  C_full_target_index='tmp/c08_driver_design/configs/C_full_main_target_index.json',
  truth_reader_contract='tmp/c08_driver_design/TRUTH_LOGL_CONTRACT.md')
 candidate=read(ROOT/paths['arithmetic_candidate']);cfg=read(ROOT/paths['c07_config']);index=read(ROOT/paths['cohort_index'])
 for path,digest in candidate['input_sha256'].items():require(sha(ROOT/path)==digest,'Reviewed arithmetic provenance changed')
 require(sha(ROOT/paths['data'])==candidate['data_sha256'],'Frozen C07 data SHA changed')
 require(candidate['cohort_ids']==sorted(index['representative_ids']+index['stress_ids']),'Frozen cohort differs')
 runtime={}
 for variant in ('C_beta','C_full'):
  value=copy.deepcopy(cfg);value.update(response_variant=variant,models=[variant+'_CN',variant+'_G'],
   status='PROSPECTIVE_C08_ANALYSIS_EXPERIMENT_NOT_GENERATING_CONFIG',
   scope='Same frozen C07 experiment, observations and five-parameter prior; own '+variant+' analysis labels. No execution authorization.')
  path=HERE/'configs'/(variant+'_analysis.json');exact_or_new(path,value);runtime[variant]=str(path.relative_to(ROOT))
 sources=[str((HERE/name).relative_to(ROOT)) for name in ('contract.py','worker.py','numeric.py','output_contract.py','run_truth.py','prepare_spec.py')]
 sources += ['src/inference/'+name+'.py' for name in ('__init__','model','orf_blas','likelihood_reference')]
 sources += ['src/pta/'+name+'.py' for name in ('__init__','simulation','statistics','response','validation','orf','_domain')]
 supporting=['tmp/c08_domain_review/review.json','tmp/c08_runtime_inputs/finite_evidence_aggregate.json',
  'tmp/c08_driver_design/c08_diagnostics.py','tmp/c08_driver_design/c08_contract.py']
 aggregate=read(ROOT/supporting[1])
 for path,digest in aggregate['source_sha256'].items():require(sha(ROOT/path)==digest,'Finite supporting evidence changed');supporting.append(path)
 inputs=sorted(set(paths.values())|set(runtime.values())|set(candidate['input_sha256'])|set(supporting))
 jobs=[dict(**job,name=f"harmonic_{job['channel']:02d}_{job['level']}",kind='harmonic',likelihood_values=0) for job in candidate['jobs']]
 jobs.append(dict(name='moments',kind='moments',real_proxy=0,likelihood_values=512))
 # Explicit arithmetic only. The moment worker owns 12 small Gamma caches and at
 # most one four-channel truth covariance/moment workspace. No posterior bank.
 bank_bytes=12*(32*12*12*16+3*32*8)
 spec=dict(schema='C08_TRUTH_DIAGNOSTIC_EXECUTION_SPEC_v1',scope=SCOPE,execution_allowed=False,
  caps=CAPS,cohort_ids=candidate['cohort_ids'],parameters=cfg['parameters'],prior_bounds=cfg['prior']['bounds'],
  paths=paths,runtime_experiments=runtime,target_indexes={v:read(ROOT/paths[v+'_target_index']) for v in runtime},jobs=jobs,
  versions=dict(python=platform.python_version(),numpy=version('numpy'),scipy=version('scipy')),
  counts=dict(physical_frequency_nodes=128,matrices_all_resolutions=384,likelihood_per_resolution=128,likelihood_resolutions=3,
   SciPy_likelihood_values=128,total_likelihood_values=512,new_physical_draws=0,new_raw_direct_sky_points=0),
  moment_memory_estimated_bytes=64*1024**2,
  memory_arithmetic=dict(stored_harmonic_bank_bytes=bank_bytes,selected_truth_bytes=32*5*8,
   selected_observation_bytes=2*32*4*10*8,compressed_observation_bytes=32*2*10*8,
   moment_basis_HC_bytes=4*3*10*12*12*16,expanded_original_NPZ_headers=headers(ROOT/paths['data']),
   moment_numeric_allowance_bytes=64*1024**2,parent_RSS_reserved_bytes=64*1024**2,
   maximum_harmonic_estimate_bytes=max(j.get('numeric_allowance_bytes',0) for j in jobs),
   harmonic_estimate_with_128MiB_library_allowance_and_parent_bytes=max(j.get('numeric_allowance_bytes',0) for j in jobs)+192*1024**2,
   scope='Arithmetic allowance, not RSS guarantee; live guards and before-allocation numeric preflight remain mandatory'),
  numerical_gates=dict(matrix_angular_H01_H00_absolute=1e-8,matrix_ell_H11_H01_absolute=1e-8,matrix_total_H11_H00_absolute=1e-8,
   likelihood_angular_absolute=.001,likelihood_ell_absolute=.001,likelihood_total_absolute=.001,SciPy_fine_absolute=1e-8),
  source_sha256={p:sha(ROOT/p) for p in sources},input_sha256={p:sha(ROOT/p) for p in inputs},
  supporting_response_evidence=supporting[:2]+list(aggregate['source_sha256']),
  pending=['C07 publication/resource release','G0 input/config/cohort freeze receipt','specific ROOT execution authorization'],
  preparation_scope=dict(real_truth_or_observation_array_reads=0,ORF_calls=0,PTA_likelihood_values=0,physical_draws=0,posterior_calls=0),
  no_prior_cache_credit=True,no_automatic_retry=True,
  CPU_accounting='600 seconds aggregate controller since process start plus all fresh-child RUSAGE_CHILDREN including imports/startup/exit; own final self-receipt/exit cannot be measured by that self-sample',
  independent_reference_scope='SciPy normal density and direct HC-trace moments at H11. No new sparse sky quadrature; prior finite response-domain evidence remains finite and separate.',
  runtime_config_policy='These exact derived C08 analysis hashes must be used by the future runtime, or replace the spec prospectively before approval; the C07 generation-config SHA remains distinct.')
 exact_or_new(HERE/'execution_spec.json',spec)
 return dict(spec_sha256=sha(HERE/'execution_spec.json'),source_count=len(sources),input_count=len(inputs),counts=spec['counts'])


if __name__=='__main__':print(json.dumps(build(),indent=2))
