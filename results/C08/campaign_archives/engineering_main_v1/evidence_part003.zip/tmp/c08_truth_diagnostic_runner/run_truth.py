"""Stdlib-only diagnostic controller. Default prints metadata; no physical work."""
from pathlib import Path
import argparse,json,math,os,resource,subprocess,sys,time
from contract import HERE,ROOT,CAPS,SCOPE,PARENT_RESERVE_BYTES,sha,read,write_new,require,rss,saved_bytes,unchanged,load_authorized,preflight


def run_child(command,log,limits):
 def apply_limits():
  resource.setrlimit(resource.RLIMIT_CPU,limits)
  resource.setrlimit(resource.RLIMIT_FSIZE,(CAPS['output_bytes'],CAPS['output_bytes']))
 before=resource.getrusage(resource.RUSAGE_CHILDREN)
 with log.open('x') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,preexec_fn=apply_limits)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 return result.returncode,(after.ru_utime-before.ru_utime)+(after.ru_stime-before.ru_stime)


class Ledger:
 def __init__(self):self.real=0;self.reserved_values=0;self.observed_values=0;self.child_CPU=0.;self.max_worker_RSS=0;self.workers=[]
 def cpu(self):return time.process_time()+self.child_CPU
 def reserve(self,job):
  require(rss()<=PARENT_RESERVE_BYTES,'Small controller RSS reserve before allocating a worker')
  require(self.real+job['real_proxy']<=CAPS['real_proxy'] and self.reserved_values+job['likelihood_values']<=512,'Work cap before worker allocation')
  previous=self.cpu();soft=math.floor(CAPS['CPU_seconds']-previous-2)
  require(soft>=1,'Keep two CPU seconds for controller final checks/exports; no worker budget remains')
  self.real+=job['real_proxy'];self.reserved_values+=job['likelihood_values']
  return previous,(soft,soft+1)
 def report(self):return dict(real_proxy_reserved=self.real,likelihood_values_reserved=self.reserved_values,
  likelihood_values_observed=self.observed_values,controller_CPU_seconds_since_start=time.process_time(),child_CPU_seconds=self.child_CPU,
  combined_CPU_seconds=self.cpu(),controller_RSS_peak_bytes=rss(),maximum_worker_RSS_peak_bytes=self.max_worker_RSS,
  conservative_parent_plus_worker_RSS_bytes=rss()+self.max_worker_RSS)


def execute(args,spec,approval):
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
 identity=dict(schema='C08_TRUTH_PRODUCER_EXECUTION_IDENTITY_v1',scope=SCOPE,spec_sha256=sha(args.spec),approval_sha256=sha(args.approval),
  release_sha256=sha(args.c07_release),g0_sha256=sha(args.g0),source_sha256=spec['source_sha256'],input_sha256=spec['input_sha256'],
  own_budget_not_charged_to_training_or_production=True,no_retry_or_replacement=True)
 write_new(out/'execution_identity.json',identity,out)
 with (out/'execution_spec_snapshot.json').open('xb') as f:f.write(args.spec.read_bytes())
 ledger=Ledger();successful=False
 try:
  for job in spec['jobs']:
   load_authorized(args.spec,args.approval,args.c07_release,args.g0)
   previous,limits=ledger.reserve(job)
   request=dict(schema='C08_TRUTH_FRESH_WORKER_REQUEST_v1',job=job,identity=identity,spec_path=str(args.spec.resolve()),
    approval_path=str(args.approval.resolve()),release_path=str(args.c07_release.resolve()),g0_path=str(args.g0.resolve()),
    campaign=str(out),previous_CPU_seconds=previous,CPU_limits=list(limits))
   path=out/(job['name']+'_request.json');write_new(path,request,out)
   write_new(out/(job['name']+'_reserved.json'),dict(job=job,resources=ledger.report(),reserved_is_not_completed_work=True),out)
   command=[sys.executable,'-B',str(HERE/'worker.py'),'--request',str(path),'--request-sha256',sha(path)]
   code,cpu=run_child(command,out/(job['name']+'.log'),limits);ledger.child_CPU+=cpu
   end_path=out/job['name']/'worker_end.json';end=read(end_path) if end_path.exists() else None
   if end is not None:
    require(end.get('request_sha256')==sha(path),'Worker receipt identity')
    r=end['resources'];require(type(r['likelihood_values']) is int and 0<=r['likelihood_values']<=job['likelihood_values'],'Worker observed count exceeds own job')
    ledger.observed_values+=r['likelihood_values'];ledger.max_worker_RSS=max(ledger.max_worker_RSS,r['RSS_peak_bytes'])
   ledger.workers.append(dict(job=job['name'],returncode=code,child_CPU_seconds_including_startup_and_exit=cpu,
    worker_end_sha256=sha(end_path) if end else None,observed_counter_available=end is not None))
   write_new(out/(job['name']+'_measured.json'),dict(resources=ledger.report(),worker=ledger.workers[-1]),out)
   require(code==0 and end is not None and end['status']=='WORKER_COMPLETED' and end['inputs_unchanged'] is True,'Worker failed; preserved, no retry')
   report=read(out/job['name']/'report.json');require(report['passed'] is True and report['identity']==identity,'Worker complete report identity')
   require(end['report_sha256']==sha(out/job['name']/'report.json'),'Final worker receipt must bind its numerical report')
   require(report['resources']['real_proxy']==job['real_proxy'] and report['resources']['likelihood_values']==job['likelihood_values'],'Completed worker counts differ')
   if job['kind']=='harmonic':require(report['job']==job and report['arrays_sha256']==sha(out/job['name']/'arrays.npz'),'Harmonic cache exact job/hash')
   require(ledger.cpu()<=600 and rss()+ledger.max_worker_RSS<=CAPS['RSS_bytes'],'Combined CPU/RSS cap after child exit')
   require(saved_bytes(out)<=CAPS['output_bytes'],'Output cap')
   print(json.dumps(dict(job=job['name'],completed=True,combined_CPU_seconds=ledger.cpu())),flush=True)
  require(ledger.real==289936637860 and ledger.observed_values==ledger.reserved_values==512,'Complete384 Gamma and512 values required')
  load_authorized(args.spec,args.approval,args.c07_release,args.g0)
  require(unchanged(spec) and sha(args.spec)==identity['spec_sha256'],'Final source/input/spec identity')
  r=ledger.report();require(r['combined_CPU_seconds']<=598 and r['conservative_parent_plus_worker_RSS_bytes']<=CAPS['RSS_bytes'],'Final export CPU reserve/RSS gate')
  receipt=dict(schema='C08_TRUTH_PRODUCER_FINAL_RECEIPT_v1',status='ALL_WORKERS_AND_FINITE_GATES_COMPLETE',identity=identity,
   resources=r,workers=ledger.workers,inputs_unchanged=True,all_children_exited=True,
   CPU_scope='Controller since process start + every child RUSAGE_CHILDREN including startup/exit; final receipt/JSON serialization follows this sample',
   no_global_posterior_certificate=True,diagnostic_use_only=True)
  write_new(out/'producer_final_receipt.json',receipt,out)
  raw=read(out/'moments'/'diagnostic_records.json');moment_report=read(out/'moments'/'report.json')
  require(moment_report['records_sha256']==sha(out/'moments'/'diagnostic_records.json')
   and moment_report['response_refinement_sha256']==sha(out/'moments'/'response_refinement.json'),'Final diagnostic records changed')
  refinement=read(out/'moments'/'response_refinement.json')
  require(all(sha(p)==h for p,h in refinement['cache_sha256'].items()),'Final consumed cache identity')
  evidence_paths=[out/'producer_final_receipt.json',out/'execution_spec_snapshot.json',out/'moments'/'response_refinement.json',
   args.approval.resolve(),args.g0.resolve(),args.c07_release.resolve()]
  evidence_paths += [ROOT/p for p in spec['supporting_response_evidence']]
  evidence=[dict(path=str(p),sha256=sha(p)) for p in evidence_paths]
  from output_contract import build_document
  documents={v:build_document(spec,v,raw['records'][v],raw['matrix_checks'][v],evidence) for v in ('C_beta','C_full')}
  for variant,value in documents.items():write_new(out/(variant+'_truth_log_likelihood.json'),value,out)
  successful=True
 except Exception as exc:
  write_new(out/'execution_failure.json',dict(status='FAILED_PRESERVED_NO_RETRY',error=str(exc),resources=ledger.report(),workers=ledger.workers),out)
  raise
 finally:
  same=(unchanged(spec) and sha(args.spec)==identity['spec_sha256'] and sha(args.approval)==identity['approval_sha256']
   and sha(args.c07_release)==identity['release_sha256'] and sha(args.g0)==identity['g0_sha256']);r=ledger.report()
  within=r['combined_CPU_seconds']<=600 and r['conservative_parent_plus_worker_RSS_bytes']<=CAPS['RSS_bytes'] and saved_bytes(out)<=CAPS['output_bytes']
  write_new(out/'execution_end.json',dict(schema='C08_TRUTH_PRODUCER_EXECUTION_END_v1',status='DIAGNOSTIC_PRODUCER_COMPLETE' if successful and same and within else 'DIAGNOSTIC_PRODUCER_FAILED',
   resources=r,workers=ledger.workers,inputs_unchanged=same,within_resource_limits=within,
   final_self_receipt_and_exit_not_measured_by_this_self_sample=True),out)
  if not same or not within:raise RuntimeError('Final controller inputs/resources failed')


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--spec',type=Path,default=HERE/'execution_spec.json');p.add_argument('--execute',action='store_true')
 for name in ('approval','c07-release','g0','output'):p.add_argument('--'+name,type=Path)
 a=p.parse_args()
 if not a.execute:print(json.dumps(preflight(a.spec),indent=2));return
 require(all(v is not None for v in (a.approval,a.c07_release,a.g0,a.output)),'ROOT approval, C07 publication/release, G0 and new output required')
 for key in ('VECLIB_MAXIMUM_THREADS','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):require(os.environ.get(key)=='1','Set thread environment=1 before process startup')
 spec,approval=load_authorized(a.spec,a.approval,a.c07_release,a.g0);execute(a,spec,approval)

if __name__=='__main__':main()
