"""Metadata-only final package audit; does not import numerical libraries."""
import ast,json,time
from contract import HERE,ROOT,read,sha,preflight,write_new,require,rss


def main():
 for p in HERE.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
 spec=read(HERE/'execution_spec.json');result=preflight(HERE/'execution_spec.json');toy=read(HERE/'toy_test_result.json')
 require(toy['status']=='TOY_PASS' and toy['tests']==15 and toy['returncode']==0,'All new TOY tests required')
 for name,digest in toy['tested_source_sha256'].items():require(sha(HERE/name)==digest,'Source changed after new TOY tests: '+name)
 for path,digest in toy['frozen_reader_sha256'].items():require(sha(ROOT/path)==digest,'Frozen reader changed')
 prior=read(HERE/'draft_history/toy_test_before_canonical_fixture.json')
 result.update(schema='C08_TRUTH_DIAGNOSTIC_RUNNER_PREFLIGHT_v1',
  runtime_experiment_sha256={v:spec['input_sha256'][p] for v,p in spec['runtime_experiments'].items()},
  numerical_gates=spec['numerical_gates'],memory_arithmetic=spec['memory_arithmetic'],
  source_sha256=spec['source_sha256'],input_sha256=spec['input_sha256'],
  toy=dict(status=toy['status'],tests=toy['tests'],report_sha256=sha(HERE/'toy_test_result.json'),
   last_child_CPU_seconds_including_exit=toy['launcher_child_CPU_seconds_including_exit'],last_RSS_peak_bytes=toy['RSS_peak_bytes'],
   both_attempts_child_CPU_seconds_including_exit=sum(v['launcher_child_CPU_seconds_including_exit'] for v in (prior,toy)),
   both_launchers_CPU_seconds_since_start=sum(v['launcher_CPU_seconds_since_process_start'] for v in (prior,toy)),
   first_attempt_preserved='One fixture noncanonical /var path; producer controller already canonicalizes output. Second attempt fixed fixture and added two guards.'),
  scientific_execution=dict(ORF_calls=0,PTA_likelihood_values=0,physical_draws=0,posterior_calls=0,real_truth_or_observation_array_reads=0),
  review_limits=['Prospective capability only; no response PASS produced.',
   'Sparse earlier engineering evidence remains finite; unseen posterior regions remain pending.',
   'Numeric estimate is not an RSS guarantee; native-call peaks are checked when returning.',
   'ROOT must externally meter final controller lifecycle before acceptance.',
   'Exact derived analysis-config hashes must match the future runtime or require a revised spec.'])
 write_new(HERE/'preflight.json',result)
 files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='manifest.json'}
 manifest=dict(schema='C08_TRUTH_DIAGNOSTIC_RUNNER_PACKAGE_MANIFEST_v1',status='PROSPECTIVE_TESTED_CANDIDATE_NOT_AUTHORIZED',
  files_sha256=files,execution_spec_sha256=sha(HERE/'execution_spec.json'),preflight_sha256=sha(HERE/'preflight.json'),
  source_sha256=spec['source_sha256'],input_sha256=spec['input_sha256'],
  default_execution_enabled=False,authorization_created=False,G0_created=False,release_receipt_created=False,
  final_metadata_CPU_seconds_since_process_start=time.process_time(),final_metadata_RSS_peak_bytes=rss(),
  metadata_lifecycle_scope='This self-sample precedes manifest serialization and interpreter exit.')
 write_new(HERE/'manifest.json',manifest)
 print(json.dumps(dict(manifest_sha256=sha(HERE/'manifest.json'),preflight_sha256=manifest['preflight_sha256'],
  execution_spec_sha256=manifest['execution_spec_sha256'],files=len(files),sources=len(spec['source_sha256']),inputs=len(spec['input_sha256']),
  runtime_experiment_sha256=result['runtime_experiment_sha256'],toy=result['toy']),indent=2))


if __name__=='__main__':main()
