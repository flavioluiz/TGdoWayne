"""Fresh harmonic or moment worker; truth access only after all execution guards."""
from pathlib import Path
import argparse,json,math,os,resource,sys,time,traceback,zipfile
from contract import ROOT,HERE,CAPS,SCOPE,PARENT_RESERVE_BYTES,sha,read,write_new,require,rss,unchanged,load_authorized,saved_bytes


def numeric_imports():
 sys.path.insert(0,str(ROOT/'src'))
 import numpy as np
 from inference.model import experiment,YEAR
 from inference.orf_blas import RealHarmonicBasis,TableBudget
 from pta.statistics import compress_frequencies
 from numeric import primary_moments,primary_pair,scipy_pair,refinement,variant_gamma
 from output_contract import rows_from_values
 return locals()


class Resources:
 def __init__(self,previous_cpu):self.previous_cpu=previous_cpu;self.real=0;self.values=0;self.evaluations={}
 def check(self):
  require(self.previous_cpu+time.process_time()<=CAPS['CPU_seconds'],'Combined controller/child CPU cap')
  if rss()>CAPS['RSS_bytes']-PARENT_RESERVE_BYTES:raise MemoryError('Worker RSS cap with parent reserve')
 def reserve_real(self,n):
  self.check();require(type(n) is int and n>=0 and self.real+n<=CAPS['real_proxy'],'Real reservation before work');self.real+=n
 def reserve_values(self,n,key):
  self.check();require(n==2 and key not in self.evaluations and self.values+n<=512,'Exactly one physical/Gaussian pair per variant/datum/stage')
  self.values+=n;self.evaluations[key]=n
 def report(self):return dict(process_CPU_seconds_since_start=time.process_time(),combined_CPU_seconds=self.previous_cpu+time.process_time(),RSS_peak_bytes=rss(),real_proxy=self.real,likelihood_values=self.values,evaluations=self.evaluations)


def npz_load(np,path,max_bytes):
 with zipfile.ZipFile(path) as z:require(sum(i.file_size for i in z.infolist())<=max_bytes,'NPZ expanded-size limit before allocation')
 with np.load(path,allow_pickle=False) as z:return {name:z[name] for name in z.files}


def save_npz(np,path,campaign,**arrays):
 require(saved_bytes(campaign)+sum(a.nbytes for a in arrays.values())+65536<=CAPS['output_bytes'],'Output allowance before array write')
 with path.open('xb') as f:np.savez(f,**arrays)


def load_diagnostic_inputs(spec,n,*,observations):
 np=n['np'];path=ROOT/spec['paths']['data'];require(sha(path)==spec['input_sha256'][spec['paths']['data']],'C07 data changed before diagnostic read')
 with zipfile.ZipFile(path) as z:require(sum(i.file_size for i in z.infolist())<16*1024**2,'Original data payload cap before reading')
 cfg=read(ROOT/spec['paths']['c07_config']);e=n['experiment'](cfg);ids=np.array(spec['cohort_ids'],dtype=np.int64)
 with np.load(path,allow_pickle=False) as z:
  require(str(z['config_sha256'])==spec['input_sha256'][spec['paths']['c07_config']],'NPZ internal generating-config SHA')
  t=z['truth'];require(t.shape==(500,5) and t.dtype==np.float64,'Original truth member shape/dtype')
  truth=t[ids].copy();del t
  for key,member in [('points','directions'),('distance_ly','distances_ly'),('sigma','sigma'),('red','red_pattern'),('f','frequency_hz'),('scale','scale')]:
   require(np.array_equal(e[key],z[member]),'Observed C07 geometry/scale differs from frozen configuration: '+key)
  data={}
  if observations:
   for name in ('x_physical','x_gaussian'):
    value=z[name];require(value.shape==(500,4,10) and value.dtype==np.float64,'Frozen observation shape/dtype')
    data[name]=value[ids].copy();del value
 require(sha(path)==spec['input_sha256'][spec['paths']['data']],'C07 data changed during diagnostic read')
 bounds=np.array(spec['prior_bounds']);require(np.isfinite(truth).all() and np.all(truth>=bounds[:,0]) and np.all(truth<=bounds[:,1]),'Selected true coordinates finite and within registered prior')
 require(e['points'].shape==(12,3) and e['H'].shape==(10,12,12) and np.isfinite(e['H']).all(),'Frozen P12/K4/D10 experiment required')
 require(all(np.isfinite(a).all() for a in data.values()),'Finite selected same-data observations')
 return e,ids,truth,data


def harmonic(spec,job,out,campaign,n,budget,identity):
 np=n['np'];require(job['numeric_allowance_bytes']<=CAPS['numeric_ORF_bytes'],'Numeric basis allowance before allocation')
 e,ids,truth,_=load_diagnostic_inputs(spec,n,observations=False);u=truth[:,0].copy();beta=np.sqrt((1-u)*(1+u));k=job['channel']
 y=2*np.pi*e['f'][k-1]*e['distance_ly']*n['YEAR']
 require(float(y.max())<=6284,'Frozen phase envelope')
 ell,nmu=job['lmax'],job['nmu'];L=ell-1;P=12
 budget.reserve_real(4*nmu*L+6*P*P*L)
 basis=n['RealHarmonicBasis'](e['points'],lmax=ell,nmu=nmu,
  budget=n['TableBudget'](maximum_estimated_memory_bytes=CAPS['numeric_ORF_bytes']-64*1024**2,maximum_multiplications_per_batch=50000000000,maximum_batch_size=4),planned_batch=4)
 budget.check();gamma=np.empty((32,12,12),complex)
 for first in range(0,32,4):
  count=4;budget.reserve_real(2*count*P*nmu*L+6*count*P*P*L+40*count*P*nmu)
  part=basis.evaluate(beta[first:first+count],y)
  require(np.isfinite(part).all() and np.max(abs(part-part.swapaxes(-1,-2).conj()))<=1e-12 and np.linalg.eigvalsh(part).min()>=-1e-12,'Finite Hermitian PSD harmonic batch; no repair')
  gamma[first:first+count]=part
  save_npz(np,out/f'batch_{first:03d}.npz',campaign,datum=ids[first:first+count],u=u[first:first+count],beta=beta[first:first+count],Gamma=part)
  budget.check()
 save_npz(np,out/'arrays.npz',campaign,datum=ids,u=u,beta=beta,Gamma=gamma)
 require(budget.real==job['real_proxy'],'Completed per-worker charge equals full prospective charge')
 return dict(status='HARMONIC_CACHE_COMPLETE',passed=True,job=job,identity=identity,arrays_sha256=sha(out/'arrays.npz'),
  numeric_arrays_bytes=int(sum(a.nbytes for a in (ids,u,beta,gamma))),phase_formula='2*pi*f_k*L/c',
  beta_formula='sqrt((1-u)*(1+u)) for every channel; no k-dependent dispersive beta',
  maximum_phase_radians=float(y.max()),minimum_eigenvalue=float(np.linalg.eigvalsh(gamma).min()),
  Hermiticity_absolute=float(np.max(abs(gamma-gamma.swapaxes(-1,-2).conj()))),truth_read_only_for_diagnostic=True)


def load_bank(spec,campaign,identity,n,truth,ids):
 np=n['np'];require(spec['moment_memory_estimated_bytes']<=CAPS['moment_bytes'],'Moment/bank allowance before loading')
 bank={};u=truth[:,0];beta=np.sqrt((1-u)*(1+u))
 for job in spec['jobs'][:-1]:
  base=campaign/job['name'];r=read(base/'report.json');end=read(base/'worker_end.json')
  request_path=campaign/(job['name']+'_request.json');request=read(request_path)
  require(r['passed'] is True and r['status']=='HARMONIC_CACHE_COMPLETE' and r['job']==job and r['identity']==identity
   and end['status']=='WORKER_COMPLETED' and end['inputs_unchanged'] is True and r['arrays_sha256']==sha(base/'arrays.npz')
   and end['report_sha256']==sha(base/'report.json')
   and request['schema']=='C08_TRUTH_FRESH_WORKER_REQUEST_v1' and request['job']==job and request['identity']==identity
   and end['request_sha256']==sha(request_path),'Exact completed cache identity required; no fake coarse cache')
  a=npz_load(np,base/'arrays.npz',4*1024**2)
  require(set(a)=={'datum','u','beta','Gamma'} and a['datum'].dtype==np.int64 and a['datum'].tobytes()==ids.tobytes()
   and a['u'].dtype==np.float64 and a['u'].tobytes()==u.tobytes() and a['beta'].dtype==np.float64 and a['beta'].tobytes()==beta.tobytes()
   and a['Gamma'].dtype==np.complex128 and a['Gamma'].shape==(32,12,12),'Cache exact nodes/dtype/shape')
  require(np.isfinite(a['Gamma']).all() and np.max(abs(a['Gamma']-a['Gamma'].swapaxes(-1,-2).conj()))<=1e-12 and np.linalg.eigvalsh(a['Gamma']).min()>=-1e-12,'Invalid cached Gamma')
  require(sha(base/'arrays.npz')==r['arrays_sha256'],'Cache changed after loading')
  bank[job['channel'],job['level']]=a
 require(sum(x.nbytes for a in bank.values() for x in a.values())<2*1024**2,'Actual small bank size differs')
 return bank


def moments(spec,out,campaign,n,budget,identity):
 np=n['np'];e,ids,truth,data=load_diagnostic_inputs(spec,n,observations=True);bank=load_bank(spec,campaign,identity,n,truth,ids)
 cache_paths=[campaign/j['name']/name for j in spec['jobs'][:-1] for name in ('report.json','worker_end.json','arrays.npz')]
 cache_paths += [campaign/(j['name']+'_request.json') for j in spec['jobs'][:-1]]
 cache_hashes={str(p):sha(p) for p in cache_paths}
 observed=np.stack([n['compress_frequencies'](data[name],e['weights']) for name in ('x_physical','x_gaussian')],axis=1)
 require(observed.shape==(32,2,10),'Same compressed B data/control pair required')
 values={};matrix_checks={};failures=[]
 for variant in ('C_beta','C_full'):
  matrix_checks[variant]=n['refinement'](bank,variant)
  if max(matrix_checks[variant].values())>1e-8:failures.append(variant+' matrix refinement')
 # Do not spend likelihood budget after an unresolved response gate.
 if failures:
  write_new(out/'response_refinement.json',dict(status='FAILED_RESPONSE_REFINEMENT',matrix_checks=matrix_checks,failures=failures),campaign)
  raise ArithmeticError('Response refinement unresolved before likelihoods')
 for variant in ('C_beta','C_full'):
  for row,datum in enumerate(ids.tolist()):
   per=[];fine_c=None
   for level in range(3):
    gamma=n['variant_gamma'](bank,variant,level,row)
    mean,covariance,c=n['primary_moments'](truth[row,1:],gamma,e)
    budget.reserve_values(2,f'{variant}:{datum}:H{level}')
    per.append(n['primary_pair'](mean,covariance,observed[row]));budget.check()
    if level==2:fine_c=c
   budget.reserve_values(2,f'{variant}:{datum}:SciPy')
   direct=n['scipy_pair'](fine_c,e['H'],e['weights'],observed[row]);budget.check()
   for index,suffix in enumerate(('_CN','_G')):values[variant+suffix,datum]=[float(v[index]) for v in per]+[float(direct[index])]
 require(budget.values==512 and len(budget.evaluations)==256,'Exactly512 values and256 two-observation calls required')
 require(all(sha(p)==h for p,h in cache_hashes.items()),'Consumed exact-node cache changed during moments')
 truth_by_datum={i:t.tolist() for i,t in zip(ids.tolist(),truth)}
 records={v:n['rows_from_values'](spec['target_indexes'][v],truth_by_datum,values) for v in ('C_beta','C_full')}
 checks={}
 for variant,rows in records.items():
  checks[variant]={name:max(abs(r[a]-r[b]) for r in rows) for a,b,name in
   [('log_likelihood_H01','log_likelihood_coarse','angular'),('log_likelihood_fine','log_likelihood_H01','ell'),
    ('log_likelihood_fine','log_likelihood_coarse','coarse_fine'),('log_likelihood_fine','log_likelihood_SciPy','SciPy')]}
  if max(checks[variant][k] for k in ('angular','ell','coarse_fine'))>.001 or checks[variant]['SciPy']>1e-8:failures.append(variant+' likelihood refinement/SciPy')
 evidence=dict(status='FINITE_TRUTH_GATES_PASS' if not failures else 'FINITE_TRUTH_GATES_FAILED',scope='FINITE_32_TRUE_PARAMETER_POINTS_PER_VARIANT_DIAGNOSTIC_ONLY',
  matrix_checks=matrix_checks,likelihood_checks=checks,failures=failures,likelihood_values=512,maximum_global_posterior_error_certificate=False,
  levels=[dict(channel=j['channel'],level=j['level'],lmax=j['lmax'],nmu=j['nmu']) for j in spec['jobs'][:-1]],
  normalization='Same C07 fixed scale and TT Earth+pulsar normalization; covariance and moment basis from frozen C07 source',
  C_full_expansion='Repeat first-channel Gamma at each level and same truth, bitexact; keep f_k spectra/noise/scale at each k',
  C_beta_response='Common beta_ref(u) with each channel phase y_k',raw_direct_sky_calls=0,new_data_draws=0,
  SciPy_reference='Independent direct HC trace moments at H11; scipy.stats.multivariate_normal.logpdf with allow_singular=False; same observed physical/Gaussian B vectors',
  previous_first_channel_cache_reuse_credit=0,truth_not_used_in_training_or_proposals=True,identity=identity,cache_sha256=cache_hashes)
 write_new(out/'response_refinement.json',evidence,campaign)
 write_new(out/'diagnostic_records.json',dict(status='RECORDS_NOT_READER_DOCUMENTS_AWAITING_CONTROLLER_FINAL_CHECKS',records=records,matrix_checks=matrix_checks),campaign)
 return dict(status='MOMENT_LIKELIHOOD_COMPLETE' if not failures else 'MOMENT_LIKELIHOOD_FAILED',passed=not failures,
  identity=identity,real_proxy=0,likelihood_values=512,response_refinement_sha256=sha(out/'response_refinement.json'),records_sha256=sha(out/'diagnostic_records.json'))


def validate_request(request,request_path,spec):
 require(request.get('schema')=='C08_TRUTH_FRESH_WORKER_REQUEST_v1','Explicit fresh-worker request schema')
 campaign=Path(request['campaign']);identity=read(campaign/'execution_identity.json')
 require(identity==request['identity'] and identity.get('schema')=='C08_TRUTH_PRODUCER_EXECUTION_IDENTITY_v1' and identity.get('scope')==SCOPE
  and identity['spec_sha256']==sha(request['spec_path']) and identity['approval_sha256']==sha(request['approval_path'])
  and identity['release_sha256']==sha(request['release_path']) and identity['g0_sha256']==sha(request['g0_path'])
  and identity['source_sha256']==spec['source_sha256'] and identity['input_sha256']==spec['input_sha256'],
  'Worker/campaign exact authorization, release, G0 and closure identity')
 job=request['job'];require(job in spec['jobs'] and request_path.resolve()==campaign/(job['name']+'_request.json'),'Only exact prospective job allowed')
 previous=request['previous_CPU_seconds']
 require(type(previous) in (int,float) and math.isfinite(previous) and 0<=previous<598,'Valid cumulative CPU before worker imports required')
 soft=math.floor(600-previous-2)
 require(soft>=1 and request['CPU_limits']==[soft,soft+1],'Declared CPU limit must preserve the controller reserve')
 return campaign,identity,job


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--request',type=Path,required=True);p.add_argument('--request-sha256',required=True);a=p.parse_args()
 require(sha(a.request)==a.request_sha256,'Worker request hash');request=read(a.request)
 spec,approval=load_authorized(Path(request['spec_path']),Path(request['approval_path']),Path(request['release_path']),Path(request['g0_path']))
 campaign,identity,job=validate_request(request,a.request,spec)
 require(list(resource.getrlimit(resource.RLIMIT_CPU))==request['CPU_limits'],'Controller pre-exec CPU limits required')
 for key in ('VECLIB_MAXIMUM_THREADS','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):require(os.environ.get(key)=='1','Thread environment must be1 before numerical imports')
 out=campaign/job['name'];out.mkdir(exist_ok=False);budget=Resources(request['previous_CPU_seconds']);complete=False;report=None
 try:
  n=numeric_imports();budget.check()
  report=harmonic(spec,job,out,campaign,n,budget,identity) if job['kind']=='harmonic' else moments(spec,out,campaign,n,budget,identity)
  budget.check();report['resources']=budget.report();write_new(out/'report.json',report,campaign)
  require(report['passed'] is True,'Finite diagnostic gate failed; no automatic retry');complete=True
 except Exception as exc:
  write_new(out/'failure.json',dict(status='FAILED_PRESERVED_NO_RETRY',error=str(exc),traceback=traceback.format_exc(),resources=budget.report()),campaign)
  raise
 finally:
  same=(unchanged(spec) and sha(request['spec_path'])==identity['spec_sha256']
   and sha(request['approval_path'])==identity['approval_sha256'] and sha(request['release_path'])==identity['release_sha256']
   and sha(request['g0_path'])==identity['g0_sha256'])
  r=budget.report();within=r['combined_CPU_seconds']<=600 and r['RSS_peak_bytes']<=CAPS['RSS_bytes']-PARENT_RESERVE_BYTES
  write_new(out/'worker_end.json',dict(status='WORKER_COMPLETED' if complete and same and within else 'WORKER_FAILED',
   request_sha256=a.request_sha256,report_sha256=sha(out/'report.json') if (out/'report.json').exists() else None,
   inputs_unchanged=same,resources=r,child_exit_measured_by_controller=True),campaign)
  if not same or not within:raise RuntimeError('Final worker input/resource guard failed')

if __name__=='__main__':main()
