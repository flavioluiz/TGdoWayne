"""Small diagnostic covariance algebra. No generator, ORF table or posterior."""
import numpy as np
from scipy.stats import multivariate_normal
from inference.model import covariance_batch,moment_basis
from inference.likelihood_reference import normal_logpdf
from pta.statistics import compress_independent_moments


def variant_gamma(bank,variant,level,row):
 if variant not in ('C_beta','C_full'):raise ValueError('Explicit scientific variant required')
 return np.stack([bank[(k if variant=='C_beta' else 1),level]['Gamma'][row] for k in range(1,5)])


def primary_moments(eta,gamma,e):
 # Same frozen B moment-basis algebra; do not call the five-model Likelihood wrapper.
 c,w=covariance_batch(eta,gamma,e);bm,bs=moment_basis(gamma,e)
 mu=np.einsum('nks,ksd->nkd',w,bm,optimize=True)
 covariance=np.einsum('nks,nkt,kstij->nkij',w,w,bs,optimize=True)
 mb,cb=compress_independent_moments(mu,covariance,e['weights'])
 return mb[0],cb[0],c[0]


def primary_pair(mean,covariance,observed_pair):
 if observed_pair.shape!=(2,len(mean)):raise ValueError('Exactly physical/Gaussian B observations required')
 result=normal_logpdf(mean[None,None,:],covariance[None,None,:,:],observed_pair[:,None,:])[0]
 if not np.isfinite(result).all():raise ArithmeticError('Nonfinite primary normal likelihood')
 return result


def direct_compressed_moments(c,H,weights):
 # Independent direct trace products at the same covariance; no basis expansion.
 k,p,p2=c.shape;d=len(H)
 if p!=p2 or H.shape!=(d,p,p) or weights.shape!=(k,):raise ValueError('Moment shapes differ')
 means=np.empty((k,d),complex);covariances=np.empty((k,d,d),complex)
 for n in range(k):
  hc=H@c[n]
  for i in range(d):
   mean=np.trace(hc[i])
   means[n,i]=mean
   for j in range(d):
    value=np.trace(hc[i]@hc[j])
    covariances[n,i,j]=value
 for array in (means,covariances):
  if np.max(abs(array.imag))>1e-11*max(float(np.max(abs(array))),np.finfo(float).tiny):raise ArithmeticError('Nonreal moment residual')
 mean=np.sum(weights[:,None]*means.real,axis=0)
 covariance=np.sum(weights[:,None,None]**2*covariances.real,axis=0)
 if not np.isfinite(mean).all() or not np.isfinite(covariance).all():raise ArithmeticError('Nonfinite direct moments')
 return mean,covariance


def scipy_pair(c,H,weights,observed_pair):
 mean,covariance=direct_compressed_moments(c,H,weights)
 result=np.asarray(multivariate_normal.logpdf(observed_pair,mean=mean,cov=covariance,allow_singular=False),float)
 if result.shape!=(2,) or not np.isfinite(result).all():raise ArithmeticError('Nonfinite SciPy reference')
 return result


def refinement(bank,variant):
 changes={}
 for a,b,name in ((0,1,'angular_H01_H00'),(1,2,'ell_H11_H01'),(0,2,'total_H11_H00')):
  channels=range(1,5) if variant=='C_beta' else (1,)
  changes[name]=max(float(np.max(abs(bank[k,b]['Gamma']-bank[k,a]['Gamma']))) for k in channels)
 return changes
