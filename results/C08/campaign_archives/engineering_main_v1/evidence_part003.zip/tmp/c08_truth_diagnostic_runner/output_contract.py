"""Pure JSON assembly of the independent diagnostic reader contract."""
import math
from pathlib import Path
from contract import ROOT,sha,require
SCHEMA='C08_DIRECT_TRUTH_LOGL_v1'


def rows_from_values(index_rows,truth_by_datum,values):
 records=[]
 for row in index_rows:
  item={key:row[key] for key in ('internal_target','model','datum')}
  datum=row['datum'];entry=values[row['model'],datum]
  require(len(entry)==4 and all(type(x) in (int,float) and math.isfinite(x) for x in entry),'Four finite diagnostic likelihood values required')
  truth=truth_by_datum[datum]
  require(len(truth)==5 and all(type(x) in (int,float) and math.isfinite(x) for x in truth),'Five finite true coordinates required')
  item.update(truth_physical=truth,log_likelihood_coarse=entry[0],log_likelihood_H01=entry[1],
   log_likelihood_fine=entry[2],log_likelihood_SciPy=entry[3])
  records.append(item)
 return records


def build_document(spec,variant,records,matrix_checks,evidence):
 require(variant in ('C_beta','C_full'),'Explicit scientific variant')
 expected=spec['target_indexes'][variant]
 require(len(records)==64 and len(expected)==64,'Exactly64 rows per variant')
 for item,row in zip(records,expected):
  require(all(item.get(k)==row[k] for k in ('internal_target','model','datum')),'Scientific target order changed')
  require(isinstance(item.get('truth_physical'),list) and len(item['truth_physical'])==5
   and all(type(v) in (int,float) and math.isfinite(v) for v in item['truth_physical']),'Finite true coordinates required')
  require(all(type(item.get(k)) in (int,float) and math.isfinite(item[k]) for k in
   ('log_likelihood_coarse','log_likelihood_H01','log_likelihood_fine','log_likelihood_SciPy')),'Finite values required')
 ll_changes={name:max(abs(r[a]-r[b]) for r in records) for a,b,name in
  [('log_likelihood_H01','log_likelihood_coarse','angular_H01_H00'),
   ('log_likelihood_fine','log_likelihood_H01','ell_H11_H01'),
   ('log_likelihood_fine','log_likelihood_coarse','total_H11_H00'),
   ('log_likelihood_fine','log_likelihood_SciPy','SciPy_fine')]}
 require(set(matrix_checks)=={'angular_H01_H00','ell_H11_H01','total_H11_H00'}
  and all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=1e-8 for v in matrix_checks.values()),'Finite separate and total matrix refinements must pass')
 require(max(ll_changes[k] for k in ('angular_H01_H00','ell_H11_H01','total_H11_H00'))<=.001 and ll_changes['SciPy_fine']<=1e-8,'Likelihood refinements or independent SciPy gate failed')
 require(bool(evidence),'Explicit evidence required')
 bindings=spec['input_sha256'];paths=spec['paths']
 return dict(schema=SCHEMA,status='DIRECT_RESPONSE_TRUTH_LOGL_DIAGNOSTIC_ONLY',scope='FINITE_TRUE_PARAMETER_POINTS_DIAGNOSTIC_ONLY',
  response_variant=variant,data_sha256=bindings[paths['data']],generation_config_sha256=bindings[paths['c07_config']],
  generation_sha256=bindings[paths['generation']],runtime_experiment_sha256=bindings[spec['runtime_experiments'][variant]],
  cohort_index_sha256=bindings[paths['cohort_index']],models=[variant+'_CN',variant+'_G'],
  parameters=spec['parameters'],prior_bounds=spec['prior_bounds'],interpolation_used=False,posterior_domain_certificate=False,
  records=records,response_refinement=dict(matrix_absolute_tolerance=1e-8,log_likelihood_absolute_tolerance=.001,
   maximum_matrix_absolute_difference=max(matrix_checks.values()),maximum_log_likelihood_difference=ll_changes['total_H11_H00'],
   separate_matrix_differences=matrix_checks,separate_likelihood_differences=ll_changes,SciPy_absolute_tolerance=1e-8),
  sources=[dict(path=str(ROOT/path),sha256=digest) for path,digest in spec['source_sha256'].items()],
  evidence=evidence,truth_used_only_for_independent_diagnostic=True,
  likelihood_interpretation='Same B normal moment likelihood; CN names physical quadratic data, G names paired Gaussian controls. Neither is a new q likelihood or importance weight.')
