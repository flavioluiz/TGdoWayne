# C08 — preflight do produtor diagnóstico na verdade

**Prospectivo, física não executada, G0/publicação/autorização pendentes.** O desenho segue `tmp/c08_truth_diagnostic_design/preflight_candidate.json` e `tmp/c08_driver_design/TRUTH_LOGL_CONTRACT.md`. Os limites são próprios: 350 G do proxy real, 600 s de CPU agregada, 1,5 GiB de RSS agregado, 1 GiB numérico de ORF, 256 MiB de momentos, 512 valores de likelihood e 20 MiB de arquivos. Não há orçamento de céu novo, dados novos, posterior, treino, retry ou substituição de alvo.

## Dados, coordenadas e likelihood

A coorte é a união imutável dos 24 IDs representativos e 8 de stress do índice C08: 25, 26, 30, 44, 48, 102, 138, 142, 157, 184, 189, 191, 197, 249, 272, 285, 313, 327, 333, 346, 355, 359, 380, 409, 424, 446, 453, 458, 461, 463, 479, 489. Engenharia é 25, 26, 44, 48; não há seleção adicional pelos resultados diagnósticos.

Somente o produtor diagnóstico, após todos os guards, lê `truth` dos dados finais C07. São usadas as cinco coordenadas originais `[u, log10_Agw, gamma_gw, log10_Ar, log10_EFAC]`, sem transformação de medida ou Jacobiano de posterior: calcula-se `log L(theta_true; mesmo dado)`. Prior, P12/K4/D10, duração 4,5 anos, geometria/sementes, `scale`, frequência, ruído, pesos e estimadores H permanecem C07. A reconstrução determinística da geometria é comparada bit a bit com os campos observados salvos. Não há nova realização física; o membro `q` não é deserializado.

Para cada massa verdadeira, `beta_ref = sqrt((1-u)*(1+u))`. C_beta avalia o mesmo beta em cada `y_k = 2*pi*f_k*L/c`. Não aplica a relação dispersiva dependente de k. C_full repete bit a bit a matriz do canal1 em todos os quatro canais, **em cada resolução**, mas mantém os espectros, o ruído e `scale_k` próprios de cada frequência.

CN e G designam, respectivamente, o vetor observado físico de estatísticas quadráticas e seu controle Gaussiano pareado. Ambos usam a mesma densidade normal de momentos B, comprimindo `x_physical`/`x_gaussian` com os pesos C07. Não se chama o wrapper de cinco modelos, nem `cn_logpdf(q)`. A álgebra primária usa `covariance_batch`, `moment_basis`, `compress_independent_moments` e `normal_logpdf` intactos. Para cada par, SciPy usa os momentos independentes `tr(H_i C_k)` e `tr(H_i C_k H_j C_k)` diretamente na covariância fina, soma os pesos/pesos ao quadrado e chama `multivariate_normal.logpdf(..., allow_singular=False)`. Sem jitter, clipping de autovalores ou ajuste pela verdade.

## Jobs e contagens

Cada linha é um worker novo, com uma única base, BLAS=1 e oito batches de quatro massas. As três resoluções são H00=(ell0,mu0), H01=(ell0,mu1), H11=(ell1,mu1). Os 32 nós são recalculados integralmente em cada linha; não se inventa um cache coarse a partir do fine nem se desconta o antigo cache C07.

| Canal | H00: lmax/nmu | H01: lmax/nmu | H11: lmax/nmu | Proxy real das três linhas |
|---|---:|---:|---:|---:|
| 1 | 1497/3013 | 1497/3093 | 1537/3093 | 10.989.946.304 |
| 2 | 2893/5806 | 2893/5886 | 2933/5886 | 39.945.333.024 |
| 3 | 4289/8598 | 4289/8678 | 4329/8678 | 86.951.009.472 |
| 4 | 5686/11391 | 5686/11471 | 5726/11471 | 152.050.349.060 |

Com L=lmax−1, P=12, N=32, a cobrança por linha é `4*nmu*L + 6*P²*L + 2*N*P*nmu*L + 6*N*P²*L + 40*N*P*nmu`. É o proxy aritmético herdado, não uma medição de instruções do processador. Construção e cada batch são reservados antes de calcular. Total: **289.936.637.860**, margem **60.063.362.140**. São 128 nós frequência/massa e **384 matrizes** nas três resoluções. O C_full compartilha o canal1 já calculado, sem ORF adicional.

O 13º worker começa somente quando os 12 anteriores terminaram com recibos válidos. Lê as matrizes pequenas e os dois dados B selecionados, nunca mantém bases harmônicas. Cada resolução gera 32 dados ×2 variantes ×2 modelos =128 valores; três resoluções dão384. As 128 referências SciPy finas completam **512**. São256 chamadas de dois dados. Contadores por `(variant,datum,stage)` recusam duplicata; reserva integral e valores efetivamente observados são registrados separadamente em caso de falha.

## Gates e alcance

Exige-se `max|Gamma_H01−Gamma_H00| <= 1e-8` e `max|Gamma_H11−Gamma_H01| <= 1e-8`, separadamente, e também `max|Gamma_H11−Gamma_H00| <= 1e-8` para o contrato coarse/fine do leitor. C_full tem seus próprios máximos no canal1; C_beta cobre os quatro canais. Nenhuma likelihood é calculada se esses gates falharem. As matrizes devem ser finitas, Hermitianas a 1e-12 e sem autovalor abaixo de −1e-12; esse último tolera apenas residual numérico e não altera a matriz.

Depois são exigidos, por variante, os dois refinamentos adjacentes e o total de logL <=0,001, além de fine/SciPy <=1e-8. Todos os campos exportados são finitos. O máximo coarse/fine do JSON é calculado com a mesma expressão Python sobre os 64 registros que o leitor congelado verifica; H01 e SciPy ficam explicitamente registrados. Gates adjacentes evitam que cancelamentos no total mascarem uma falha.

“Direto” significa ORF harmônico explícito nos nós verdadeiros, sem interpolação. Este produtor não executa céu bruto novo. A evidência de resposta anterior permanece vinculada como evidência **finita**, com os pontos/fases/pares e a normalização declarados nos relatórios originais. Os 32 vetores de engenharia antigos não são promovidos a validação das 500 observações. A compatibilidade geométrica é vinculada separadamente, e estes novos gates abrangem somente os 32 pontos verdadeiros de cada variante. Não certificam regiões posteriores ainda não testadas nem limites uniformes.

## Memória, CPU e persistência

O maior allowance numérico harmônico é **630.648.664 B**. A soma ilustrativa com 128 MiB para bibliotecas e 64 MiB reservados ao controlador é **831.975.256 B**, abaixo de 1,5 GiB, mas não é garantia RSS. O controlador stdlib exige seu pico <=64 MiB antes de lançar um filho. O filho exige RSS <=1,5 GiB−64 MiB, e o controlador verifica sua própria máxima mais a máxima de cada filho. Não há limite de endereço virtual usado como suposta garantia RSS; o backend faz seu preflight numérico antes da base, e RSS é observado após imports, construção e batches. Um pico durante uma chamada nativa só é detectado ao voltar; falha encerra o pacote, sem elevar teto.

As 12 coleções finais pequenas ocupam893.952 B incluindo IDs/u/beta. Verdades selecionadas:1.280 B; observações selecionadas:20.480 B; observações comprimidas:5.120 B; maior tensor HC:276.480 B. Reserva-se64 MiB numéricos para todo o worker de momentos, dentro dos256 MiB. Os tamanhos expandidos do ZIP são limitados antes de ler arrays. Os arrays originais de verdade/observação são pequenos membros NPZ carregados temporariamente para selecionar os32; apenas a seleção é mantida/serializada. Não há banco nativo posterior nem cópia de coeficientes de tabela.

CPU agrega `time.process_time()` do controlador desde o início e deltas `RUSAGE_CHILDREN` de todos os filhos até a saída, incluindo imports/preflight/encerramento. Antes de cada filho, `preexec_fn` fixa `RLIMIT_CPU` a `floor(600−CPU_previa−2)`/mais1 e `RLIMIT_FSIZE` a20 MiB; duas CPU-segundos ficam reservadas aos metadados finais. Os workers verificam o próprio limite antes de imports numéricos. O recibo do worker é uma amostra anterior à saída; a cobrança final usa o contador externo do controlador, não esse recibo. Como em qualquer autorrelato, a serialização/saída do próprio controlador posteriores à sua última amostra não são medidas por ele; `execution_end.json` declara isso. ROOT deve medir o ciclo completo externamente antes de aceitar o resultado. Não há promessa de conclusão dentro do teto; ultrapassagem observada reprova.

Cada batch de quatro Γ é salvo imediatamente; depois salva-se o cache final da linha. O hash do pedido vincula identidade, autorização/G0/release e job; o recibo final vincula o report, que vincula o NPZ. Antes do reuso, IDs/u/beta são comparados por dtype/bytes; os hashes são rechecados após load, após momentos e pelo controlador antes da exportação. Fontes/inputs/spec/autorizações são verificados novamente. Saída exige pasta nova; falhas e reservas permanecem, sem autoretry ou inventar trabalho completo.

São emitidos apenas dois documentos finais, 64 registros cada, ordenados exatamente como os índices congelados. Evidência inclui recibos de workers/controle, resoluções e refinamentos, fontes, dados/configs, autorização/G0/release e relatórios finitos anteriores. A futura revisão de ROOT deve exigir `execution_end.json` completo, além dos JSONs; o leitor congelado verifica hashes/cabeçalho/refinamento, mas não substitui a revisão do lifecycle do produtor. Nenhum desses documentos finais ou recibos de autorização foi fabricado na preparação.

## Verificação permitida

15 testes inventados passaram: aritmética e closure; expansão C_beta/C_full nas três resoluções; momentos de duas matrizes 2×2 versus fórmula analítica e SciPy; gates adjacentes; publicação/evidência/G0; autorização diagnóstico-only; pedido/identidade antes de imports; contadores/limites; subprocesso stdlib fresco com RLIMIT/RUSAGE; compatibilidade com os corpos exatos do leitor; rejeição de modelos/configs/ordem/verdade/máximos errados, não finitos e caches adulterados; bloqueio de CLI sem autorização. Não houve ORF, experimento PTA, likelihood PTA ou arrays físicos nos testes. `toy_test_result.json` e o histórico preservam custos e a única falha inicial do fixture de caminho.
