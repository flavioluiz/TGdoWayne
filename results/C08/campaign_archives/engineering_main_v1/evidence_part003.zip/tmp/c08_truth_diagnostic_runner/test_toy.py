"""Only small invented fixtures. Never construct an ORF or a PTA experiment."""
from pathlib import Path
import ast,copy,json,math,os,resource,sys,tempfile,time,unittest
from types import SimpleNamespace
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(HERE),str(ROOT/'src')]
import contract,worker,run_truth,output_contract
assert 'numpy' not in sys.modules and 'scipy' not in sys.modules,'Controller/worker contracts imported heavy modules'
import numpy as np
from scipy.stats import multivariate_normal
import numeric


def dump(path,value):path.write_text(json.dumps(value,allow_nan=False));return path
def load_functions(path,names,env):
 tree=ast.parse(path.read_text());selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names]
 assert len(selected)==len(names)
 exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),env)
 return env


class Toys(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(prefix='c08_truth_TOY_');self.d=Path(self.tmp.name).resolve()
 def tearDown(self):self.tmp.cleanup()

 def test_01_arithmetic_and_source_closure(self):
  spec=contract.read(HERE/'execution_spec.json');self.assertEqual(contract.validate_spec(spec),289936637860)
  self.assertIn('src/inference/__init__.py',spec['source_sha256']);self.assertEqual(len(spec['jobs']),13)
  self.assertEqual(sum(j['requested_frequency_nodes'] for j in spec['jobs'][:-1]),384)
  bad=copy.deepcopy(spec);bad['jobs'][1]['requested_frequency_nodes']=0
  with self.assertRaises(ValueError):contract.validate_spec(bad)
  bad=copy.deepcopy(spec);bad['runtime_experiments']['C_full']=bad['runtime_experiments']['C_beta']
  with self.assertRaises(ValueError):contract.validate_spec(bad)

 def test_02_variant_expansion_all_three_levels(self):
  bank={(k,l):dict(Gamma=np.full((2,2,2),100*k+10*l+np.arange(2)[:,None,None],complex)) for k in range(1,5) for l in range(3)}
  for level in range(3):
   beta=numeric.variant_gamma(bank,'C_beta',level,1);full=numeric.variant_gamma(bank,'C_full',level,1)
   np.testing.assert_array_equal(beta[:,0,0],[100*k+10*level+1 for k in range(1,5)])
   for k in range(4):self.assertEqual(full[k].tobytes(),bank[1,level]['Gamma'][1].tobytes())
  with self.assertRaises(ValueError):numeric.variant_gamma(bank,'B_CN',0,0)

 def test_03_independent_trace_moments_and_normal_pair(self):
  H=np.array([[[1,0],[0,0]],[[0,0],[0,1]],[[0,.5],[.5,0]]],complex)
  C=np.array([[[2,.3+.2j],[.3-.2j,1.3]],[[1.7,-.1+.15j],[-.1-.15j,1.1]]],complex);w=np.array([.25,.75])
  means=[];covs=[]
  for c in C:
   a,b=c[0,0].real,c[1,1].real;r=c[0,1].real;z=c[0,1]
   means.append([a,b,r]);covs.append([[a*a,abs(z)**2,a*r],[abs(z)**2,b*b,b*r],[a*r,b*r,.5*(a*b+(z*z).real)]])
  expected_mean=np.sum(w[:,None]*np.array(means),axis=0);expected_cov=np.sum(w[:,None,None]**2*np.array(covs),axis=0)
  mean,cov=numeric.direct_compressed_moments(C,H,w)
  np.testing.assert_allclose(mean,expected_mean,rtol=0,atol=1e-15);np.testing.assert_allclose(cov,expected_cov,rtol=0,atol=1e-15)
  observed=np.array([[1.9,.9,.15],[2.5,1.6,-.1]])
  primary=numeric.primary_pair(mean,cov,observed);reference=numeric.scipy_pair(C,H,w,observed)
  np.testing.assert_allclose(primary,reference,rtol=0,atol=3e-14);self.assertNotEqual(primary[0],primary[1])
  with self.assertRaises(ValueError):numeric.primary_pair(mean,cov,observed[:1])
  with self.assertRaises(np.linalg.LinAlgError):numeric.primary_pair(mean,np.zeros((3,3)),observed)

 def test_04_separate_refinements_cannot_cancel(self):
  bank={(k,l):dict(Gamma=np.full((2,2,2),[1,1+2e-8,1][l],complex)) for k in range(1,5) for l in range(3)}
  check=numeric.refinement(bank,'C_beta');self.assertEqual(check['total_H11_H00'],0.)
  self.assertGreater(check['angular_H01_H00'],1e-8);self.assertGreater(check['ell_H11_H01'],1e-8)

 def release_fixture(self):
  evidence=dump(self.d/'evidence.json',{'scope':'TOY_ONLY_NOT_A_PHYSICAL_AUTHORIZATION'})
  item=dict(path=str(evidence),sha256=contract.sha(evidence))
  r=dict(schema='C07_PUBLICATION_AND_RESOURCE_RELEASE_RECEIPT_v1',status='C07_PUBLISHED_AND_RELEASED',
   scope='C07_PUBLISHED_AND_WORKERS_MEMORY_RELEASED',released_for_c08=True,active_workers=0,c07_runtime_identity='a'*64,
   publication=dict(status='PUBLISHED',commit='b'*40,tag='TOY_ONLY',release_url='https://example.invalid/TOY_ONLY',evidence=item),evidence=[item])
  path=dump(self.d/'release.json',r);return path,r,item

 def test_05_publication_and_evidence_required(self):
  path,r,item=self.release_fixture();self.assertEqual(contract.validate_release(path,{}),r)
  for key,value in [('status','RESOURCE_RELEASE'),('active_workers',True),('active_workers',1)]:
   bad=copy.deepcopy(r);bad[key]=value;dump(path,bad)
   with self.assertRaises(ValueError):contract.validate_release(path,{})
  bad=copy.deepcopy(r);bad['publication']['evidence']['sha256']='0'*64;dump(path,bad)
  with self.assertRaises(ValueError):contract.validate_release(path,{})

 def g0_fixture(self):
  release,r,item=self.release_fixture();keys=['data','c07_config','generation','c08_design','cohort_manifest','cohort_index']
  spec=dict(paths={k:k for k in keys},input_sha256={k:str(i)*64 for i,k in enumerate(keys)},runtime_experiments=dict(C_beta='beta',C_full='full'))
  spec['input_sha256'].update(beta='6'*64,full='7'*64)
  g=dict(schema='C08_G0_FROZEN_DIAGNOSTIC_INPUTS_v1',status='G0_PASS',approved_by='ROOT',c07_release_receipt_sha256=contract.sha(release),
   data_sha256='0'*64,generation_config_sha256='1'*64,generation_sha256='2'*64,c08_design_sha256='3'*64,
   cohort_manifest_sha256='4'*64,cohort_index_sha256='5'*64,runtime_experiment_sha256=dict(C_beta='6'*64,C_full='7'*64),evidence=[item])
  path=dump(self.d/'g0.json',g);return spec,release,r,path,g

 def test_06_g0_exact_inputs_and_distinct_runtime_configs(self):
  spec,release,r,path,g=self.g0_fixture();contract.validate_g0(path,release,spec)
  for key in ('data_sha256','generation_config_sha256','c08_design_sha256','cohort_index_sha256'):
   bad=copy.deepcopy(g);bad[key]='f'*64;dump(path,bad)
   with self.assertRaises(ValueError):contract.validate_g0(path,release,spec)
  bad=copy.deepcopy(g);bad['runtime_experiment_sha256']['C_full']=bad['runtime_experiment_sha256']['C_beta'];dump(path,bad)
  with self.assertRaises(ValueError):contract.validate_g0(path,release,spec)

 def test_07_root_truth_only_authorization_exact_scope(self):
  spec,release,r,g0,g=self.g0_fixture();spec['source_sha256']={'TOY_ONLY':'e'*64}
  path=dump(self.d/'spec.json',spec)
  a=dict(schema=contract.AUTH_SCHEMA,approved_by='ROOT',execution_allowed=True,scope=contract.SCOPE,
   execution_spec_sha256=contract.sha(path),caps=contract.CAPS,source_sha256=spec['source_sha256'],input_sha256=spec['input_sha256'],
   c07_release_receipt_sha256=contract.sha(release),g0_sha256=contract.sha(g0),c07_published_commit=r['publication']['commit'],
   c07_publication_evidence_sha256=r['publication']['evidence']['sha256'],truth_access='DIAGNOSTIC_PRODUCER_ONLY',no_training_or_proposal_use=True)
  auth=dump(self.d/'auth_TOY_ONLY.json',a)
  # Only the spec validator is replaced: malformed TOY paths must never become a physical spec.
  with patch.object(contract,'validate_spec',return_value=0):
   contract.load_authorized(path,auth,release,g0)
   for key,value in [('scope','training'),('execution_allowed',False),('truth_access','training'),('g0_sha256','0'*64),('no_training_or_proposal_use',False)]:
    bad=copy.deepcopy(a);bad[key]=value;dump(auth,bad)
    with self.assertRaises(ValueError):contract.load_authorized(path,auth,release,g0)
  with self.assertRaises(ValueError):contract.validate_spec(spec)

 def test_08_request_identity_before_numeric_imports(self):
  paths={k:dump(self.d/(k+'.json'),{'TOY_ONLY':k}) for k in ('spec','approval','release','g0')}
  job=dict(name='harmonic_01_0',kind='harmonic');spec=dict(jobs=[job],source_sha256={'TOY_ONLY':'e'*64},input_sha256={'TOY_ONLY':'f'*64})
  identity=dict(schema='C08_TRUTH_PRODUCER_EXECUTION_IDENTITY_v1',scope=contract.SCOPE,
   **{k+'_sha256':contract.sha(p) for k,p in paths.items()},source_sha256=spec['source_sha256'],input_sha256=spec['input_sha256'])
  dump(self.d/'execution_identity.json',identity)
  req=dict(schema='C08_TRUTH_FRESH_WORKER_REQUEST_v1',campaign=str(self.d),identity=identity,job=job,
   **{k+'_path':str(p) for k,p in paths.items()},previous_CPU_seconds=4.,CPU_limits=[594,595])
  path=self.d/'harmonic_01_0_request.json';worker.validate_request(req,path,spec)
  for key,value in [('schema','old'),('previous_CPU_seconds',float('nan')),('CPU_limits',[595,596])]:
   bad=copy.deepcopy(req);bad[key]=value
   with self.assertRaises(ValueError):worker.validate_request(bad,path,spec)
  dump(paths['release'],{'TOY_ONLY':'changed'})
  with self.assertRaises(ValueError):worker.validate_request(req,path,spec)

 def test_09_reserve_before_work_and_no_duplicate_pairs(self):
  with patch.object(worker,'rss',return_value=32*1024**2),patch.object(worker.time,'process_time',return_value=1.):
   b=worker.Resources(0.);b.reserve_values(2,'TOY:C_beta:25:H0')
   with self.assertRaises(ValueError):b.reserve_values(2,'TOY:C_beta:25:H0')
   b.values=512
   with self.assertRaises(ValueError):b.reserve_values(2,'TOY:new')
   b.real=350000000000
   with self.assertRaises(ValueError):b.reserve_real(1)
  with patch.object(run_truth,'rss',return_value=32*1024**2),patch.object(run_truth.time,'process_time',return_value=50.):
   ledger=run_truth.Ledger();ledger.child_CPU=20.;previous,limits=ledger.reserve(dict(real_proxy=17,likelihood_values=2))
   self.assertEqual((previous,limits),(70.,(528,529)));self.assertEqual(ledger.real,17)
   self.assertEqual(ledger.reserved_values,2);self.assertEqual(ledger.observed_values,0)
   ledger.child_CPU=549.
   with self.assertRaises(ValueError):ledger.reserve(dict(real_proxy=1,likelihood_values=2))

 def test_10_fresh_child_preexec_limits_and_final_cpu(self):
  log=self.d/'TOY_child.log'
  code,cpu=run_truth.run_child([sys.executable,'-B','-c',
   "import json,resource,time; t=time.process_time(); assert resource.getrlimit(resource.RLIMIT_CPU)==(2,3); sum(i*i for i in range(10000)); print(json.dumps({'TOY_ONLY':True,'cpu':time.process_time()}))"],log,(2,3))
  self.assertEqual(code,0);result=json.loads(log.read_text());self.assertTrue(result['TOY_ONLY']);self.assertGreaterEqual(cpu,result['cpu'])

 def reader_fixture(self,variant):
  cfg=dict(n_realizations=500,parameters=['u','a','b','c','d'],prior=dict(kind='uniform TOY',bounds=[[0.,1.]]*5))
  cfgpath=dump(self.d/'C07_TOY.json',cfg);truth=np.tile(np.array([.2,.3,.4,.5,.6]),(500,1));data=self.d/'TOY_data.npz'
  np.savez(data,truth=truth,config_sha256=np.asarray(contract.sha(cfgpath)))
  gen=dump(self.d/'TOY_generation.json',dict(data_sha256=contract.sha(data),config_sha256=contract.sha(cfgpath),realizations=500))
  idx=dict(schema='C08_COHORT_ROUTING_INDEX_v1',datasets=500,truth_coordinates_present=False,representative_ids=list(range(24)),stress_ids=list(range(24,32)),
   engineering_ids=list(range(4)),cohort_manifest_sha256='a'*64,design_sha256='b'*64,data_sha256=contract.sha(data),generation_config_sha256=contract.sha(cfgpath),generation_sha256=contract.sha(gen))
  env=load_functions(ROOT/'tmp/c08_driver_design/c08_contract.py',{'validate_index','target_rows'},{'VARIANTS':('C_beta','C_full'),'PHASES':('engineering','main')})
  rows=env['target_rows'](idx,variant,'main');index=dump(self.d/'TOY_index.json',idx)
  own=dump(self.d/(variant+'_TOY_config.json'),dict(cfg,response_variant=variant,models=[variant+'_CN',variant+'_G']))
  evidence=dump(self.d/'TOY_evidence.json',dict(scope='INVENTED_FIXTURE_NO_SCIENCE'));source=self.d/'TOY_source.txt';source.write_text('TOY only')
  spec=dict(paths=dict(data=str(data),c07_config=str(cfgpath),generation=str(gen),cohort_index=str(index)),runtime_experiments={variant:str(own)},
   input_sha256={str(p):contract.sha(p) for p in (data,cfgpath,gen,index,own)},source_sha256={str(source):contract.sha(source)},
   target_indexes={variant:rows},parameters=cfg['parameters'],prior_bounds=cfg['prior']['bounds'])
  values={(r['model'],r['datum']):[-3.,-3.+.0001,-3.+.0002,-3.+.0002+1e-10] for r in rows}
  records=output_contract.rows_from_values(rows,{i:truth[i].tolist() for i in range(32)},values)
  doc=output_contract.build_document(spec,variant,records,dict(angular_H01_H00=2e-10,ell_H11_H01=2e-10,total_H11_H00=4e-10),[dict(path=str(evidence),sha256=contract.sha(evidence))])
  docpath=dump(self.d/(variant+'_TOY_truth.json'),doc)
  reader=load_functions(ROOT/'tmp/c08_driver_design/c08_diagnostics.py',{'_check_evidence','load_c08_truth'},
   dict(np=np,Path=Path,read_json=contract.read,sha256=contract.sha,TRUTH_SCHEMA=output_contract.SCHEMA,validate_index=env['validate_index'],target_rows=env['target_rows']))['load_c08_truth']
  runtime=SimpleNamespace(n=500,cfg=contract.read(own),response_variant=variant,bounds=np.array(cfg['prior']['bounds']),
   input_hashes=dict(data=contract.sha(data),runtime_generation=contract.sha(gen),experiment=contract.sha(own)))
  def call():return reader(runtime,2,variant+'_G',data,docpath,index_path=index,c07_config_path=cfgpath,c07_generation_path=gen)
  return spec,records,docpath,doc,call

 def test_11_actual_frozen_reader_both_variant_compatibility(self):
  for variant in ('C_beta','C_full'):
   spec,rows,path,doc,call=self.reader_fixture(variant);truth,unit,value=call()
   np.testing.assert_array_equal(truth,[.2,.3,.4,.5,.6]);np.testing.assert_array_equal(truth,unit)
   self.assertEqual(value,doc['records'][34]['log_likelihood_fine'])
   self.assertEqual(doc['response_refinement']['maximum_log_likelihood_difference'],max(abs(r['log_likelihood_fine']-r['log_likelihood_coarse']) for r in rows))

 def test_12_reader_rejects_mismatch_order_maximum_and_truth(self):
  spec,rows,path,doc,call=self.reader_fixture('C_beta')
  for which in range(5):
   bad=copy.deepcopy(doc)
   if which==0:bad['response_variant']='C_full'
   if which==1:bad['records'][0],bad['records'][1]=bad['records'][1],bad['records'][0]
   if which==2:bad['response_refinement']['maximum_log_likelihood_difference']=0.
   if which==3:bad['records'][34]['truth_physical'][0]=.25
   if which==4:bad['runtime_experiment_sha256']='0'*64
   dump(path,bad)
   with self.assertRaises((ValueError,RuntimeError)):call()

 def test_13_export_rejects_cancellation_and_nonfinite(self):
  spec,rows,path,doc,call=self.reader_fixture('C_beta');matrix=dict(angular_H01_H00=0.,ell_H11_H01=0.,total_H11_H00=0.)
  for which in range(4):
   bad=copy.deepcopy(rows)
   if which==0:bad[0]['log_likelihood_H01']=bad[0]['log_likelihood_coarse']+.002
   if which==1:bad[0]['log_likelihood_SciPy']=bad[0]['log_likelihood_fine']+2e-8
   if which==2:bad[0]['log_likelihood_fine']=float('nan')
   if which==3:bad[0]['truth_physical'][0]=float('inf')
   with self.assertRaises(ValueError):output_contract.build_document(spec,'C_beta',bad,matrix,doc['evidence'])

 def test_14_cache_bound_receipt_and_exact_nodes_before_reuse(self):
  job=dict(name='harmonic_01_0',channel=1,level=0,kind='harmonic');base=self.d/job['name'];base.mkdir()
  identity={'TOY_ONLY':True};ids=np.arange(32,dtype=np.int64);truth=np.full((32,5),.25);beta=np.sqrt((1-truth[:,0])*(1+truth[:,0]))
  arrays=dict(datum=ids,u=truth[:,0],beta=beta,Gamma=np.broadcast_to(np.eye(12,dtype=complex),(32,12,12)).copy())
  np.savez(base/'arrays.npz',**arrays)
  request=dump(self.d/(job['name']+'_request.json'),dict(schema='C08_TRUTH_FRESH_WORKER_REQUEST_v1',job=job,identity=identity))
  report=dump(base/'report.json',dict(passed=True,status='HARMONIC_CACHE_COMPLETE',job=job,identity=identity,arrays_sha256=contract.sha(base/'arrays.npz')))
  end=dict(status='WORKER_COMPLETED',inputs_unchanged=True,report_sha256=contract.sha(report),request_sha256=contract.sha(request));dump(base/'worker_end.json',end)
  spec=dict(moment_memory_estimated_bytes=2*1024**2,jobs=[job,dict(name='moments')]);bank=worker.load_bank(spec,self.d,identity,dict(np=np),truth,ids)
  self.assertEqual(bank[1,0]['Gamma'].tobytes(),arrays['Gamma'].tobytes())
  bad=copy.deepcopy(end);bad['report_sha256']='0'*64;dump(base/'worker_end.json',bad)
  with patch.object(worker,'npz_load',side_effect=AssertionError('Must reject before allocating')):
   with self.assertRaises(ValueError):worker.load_bank(spec,self.d,identity,dict(np=np),truth,ids)
  dump(base/'worker_end.json',end)
  truth[0,0]=.3
  with self.assertRaises(ValueError):worker.load_bank(spec,self.d,identity,dict(np=np),truth,ids)

 def test_15_execute_without_explicit_guards_stops_before_imports(self):
  log=self.d/'TOY_missing_auth.log';code,cpu=run_truth.run_child([sys.executable,'-B',str(HERE/'run_truth.py'),'--execute'],log,(2,3))
  self.assertNotEqual(code,0);self.assertIn('ROOT approval, C07 publication/release, G0 and new output required',log.read_text())


if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Toys))
 child=resource.getrusage(resource.RUSAGE_CHILDREN);total=time.process_time()+child.ru_utime+child.ru_stime
 report=dict(status='TOY_PASS' if result.wasSuccessful() else 'TOY_FAIL',tests=result.testsRun,
  failures=len(result.failures),errors=len(result.errors),CPU_seconds_since_process_start_plus_children=total,
  RSS_peak_bytes=contract.rss(),limits=dict(CPU_seconds=30,RSS_bytes=128*1024**2),
  ORF_calls=0,PTA_experiment_calls=0,PTA_likelihood_values=0,physical_draws=0,real_truth_or_observation_array_reads=0,
  toy_normal_density_values=4,reader_functions='Exact AST bodies of frozen load_c08_truth/_check_evidence/validate_index/target_rows',
  tested_source_sha256={p.name:contract.sha(p) for p in HERE.glob('*.py')},
  frozen_reader_sha256={str(p.relative_to(ROOT)):contract.sha(p) for p in [ROOT/'tmp/c08_driver_design/c08_diagnostics.py',ROOT/'tmp/c08_driver_design/c08_contract.py']})
 print(json.dumps(report,indent=2))
 if total>30 or contract.rss()>128*1024**2:raise RuntimeError('TOY preparation cap exceeded')
 if not result.wasSuccessful():sys.exit(1)
