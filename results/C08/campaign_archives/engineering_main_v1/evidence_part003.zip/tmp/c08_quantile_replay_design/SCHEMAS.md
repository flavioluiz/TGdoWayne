# Contratos externos necessários — candidatos, sem aprovação

## Autorização de replay

O arquivo deve conter:

```
schema: C08_HIGH_REPLAY_AUTHORIZATION_v1
approved: true
stages: [required_C07_high_replay, endpoint_diagnostics]
plan_sha256: SHA do replay_plan.json congelado
original_identity: identity original C07
source_sha256: dicionário exato do preflight candidato
output: caminho absoluto do output novo
maximum_LL: 41943040
G0_content_sha256: canonical_hash do recibo G0
allocation_content_sha256: canonical_hash da alocação
resource_lock_root: diretório compartilhado com os drivers C08
diagnostic_protocol_content_sha256: canonical_hash(protocol())
evidence_index_sha256: SHA do índice ou null se ausente
consumers_index_sha256: SHA do índice ou null se ausente
```

As palavras `true` acima descrevem campos requeridos de uma futura decisão
ROOT. Este documento não preenche essa decisão. A comparação usa o algoritmo
`canonical_hash` C07 (JSON ordenado, sem NaN, separadores compactos).

## G0 e alocação

G0 usa diretamente o recibo ROOT já existente:
`schema=C07_PUBLICATION_AND_RESOURCE_RELEASE_RECEIPT_v1`,
`status=C07_PUBLISHED_AND_RELEASED`,
`scope=C07_PUBLISHED_AND_WORKERS_MEMORY_RELEASED`, `released_for_c08=true`,
`active_workers=0` inteiro e `c07_runtime_identity` original. `publication`
contém `status=PUBLISHED`, commit de40 caracteres, tag explícita da série
v0.7.x e `evidence={path,sha256}`. A lista `evidence` externa deve incluir o
complete C07 com SHA original; todas as evidências são verificadas. A
autorização vincula o conteúdo completo de G0. Nenhum recibo substituto é
fabricado; a versão atual fornecida pelo ROOT declara v0.7.1.

Alocação: `schema=C08_COMBINED_LL_ALLOCATION_v1`, `cap=110000000`,
`active_banks=1`, `raw_cap=1073741824`, `numeric_cap=4294967296`,
`resource_lock_root`, e `allocations` com inteiros não negativos por operação.
`required_C07_high_replay=41943040` é obrigatório. A soma não pode ultrapassar
110M. Esse inventário deve ser usado por todos os executores participantes;
o Ledger local deste replay não pode consumir a alocação de outro estágio.

## Caminhos do runtime original

`runtime_inputs.json` contém exatamente oito chaves com caminhos explícitos:
`experiment`, `data`, `table`, `table_manifest`, `validation_config`, `settings`,
`native_library`, `native_build_manifest`. Seus SHA devem ser idênticos aos
originais. Não se religa a rotina a uma tabela C08 ou a outro binário. A
construção futura deve reproduzir a identity C07 completa, incluindo fontes e
threads; não há fallback NumPy implícito para um replay bit a bit.

## Evidência determinística por posterior

O índice opcional mapeia `MODELO:datum` para `{path,sha256}`. Cada arquivo:

```
schema: C08_POSTERIOR_CDF_EVIDENCE_v1
identity: identidade do runtime daquele posterior
scientific_model: uma das nove famílias
datum: ID original C07
cut_manifest_content_sha256: hash interno do manifesto LOW
operational_margin: 0.002
is_uniform_proof: false
posterior_domain: descrição concreta do domínio e limites dos controles
checks:
  coarse_fine: booleano
  independent_oracle: booleano
  posterior_domain_controls: booleano
sources: lista não vazia de {path,sha256}
```

São afirmações operacionais finitas que exigem revisão científica externa;
o leitor só confere identidade, fontes, domínio explícito e flags. Não gera
esses flags a partir de `max_abs_logL`, da verdade, ou da aprovação de um nó.
Qualquer flag falso ou registro ausente resulta em [0,1]/UNRESOLVED. Um falso
`is_uniform_proof=true` é rejeitado: a hipótese uniforme não foi demonstrada.

## Produtos compactos e consumidores opcionais

Por alvo, JSON mantém todas as20 linhas, cortes, estimativas e MCSE, seis
contrastes por corte interior, flags e causas comuns, pesos/caudas/logZ,
saturação, domínio/evidência e hashes originais. NPZ armazena arrays20×23,
padding NaN marcado por `endpoint_present`, réplicas20×23×4, contrastes
20×23×6, bounds20×2 e flags de resolução. NaN de padding não é uma CDF.
Infinitos não resolvidos permanecem no NPZ; JSON usa a convenção `json_safe`
C07 (null) junto do status explícito. Os denominadores não diminuem.

O índice de consumidores associa target original a uma lista de `{path,sha256}`.
Cada recibo deve declarar `status=CONSUMPTION_COMPLETE`, target e mapa completo
dos quatro `raw_sha256` altos. O nome/escopo do consumidor deve ser aprovado
externamente. Índice ausente significa opcionais desativados, não realizados.

O arquivo próprio `C08_REPLAY_COMPACT_ARCHIVE_v1` aponta para os artefatos
preservados e o recibo C07 original. `C08_REPLAY_TARGET_ARCHIVED` só afirma
completude de transporte e conservação das falhas, nunca calibração, passagem
de todos os brackets ou validade física global.
