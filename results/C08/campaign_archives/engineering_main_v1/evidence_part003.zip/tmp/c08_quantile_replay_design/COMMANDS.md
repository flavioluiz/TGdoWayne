# Comandos utilizados e reprodução

Seleção de metadados/LOW, executada sem high/truth/ORF/LL:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
.venv/bin/python tmp/c08_quantile_replay_design/run_replay.py \
  --repository . --helper tmp/c08_execution_design/quantile_brackets.py \
  freeze-c07 --campaign tmp/c07_posterior500_v1 \
  --cohort tmp/c08_driver_design/configs/cohort_index.json \
  --design tmp/c08_execution_design/config_prospectiva.json \
  --output tmp/c08_quantile_replay_design/frozen_c07
```

O output é exclusivo: para reproduzir a seleção, usar outro diretório. O
primeiro manifesto/cortes permanece preservado. Caminhos absolutos dos
artefatos e saídas fazem parte dos bindings; a portagem exige novo manifesto
de caminhos/autorização, sem mudar os valores/cortes originais.

Testes TOY (os logs/tempos medidos incluem uma execução instrumentada com
`resource.setrlimit(RLIMIT_CPU,(30,30))`):

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
PYTHONPATH=src:tmp/c08_quantile_replay_design \
.venv/bin/python -m unittest -v test_candidate test_c08_adapter
```

Preflight somente de metadados:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
.venv/bin/python tmp/c08_quantile_replay_design/run_replay.py \
  --repository . --helper tmp/c08_execution_design/quantile_brackets.py \
  preflight --plan tmp/c08_quantile_replay_design/frozen_c07/replay_plan.json \
  --output tmp/c08_required_high_replay_v1 \
  --report tmp/c08_quantile_replay_design/preflight_candidate.json
```

**Não executado:** sintaxe futura após autorização ROOT e insumos reais.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
.venv/bin/python tmp/c08_quantile_replay_design/run_replay.py \
  --repository . --helper tmp/c08_execution_design/quantile_brackets.py \
  run --execute \
  --plan tmp/c08_quantile_replay_design/frozen_c07/replay_plan.json \
  --output tmp/c08_required_high_replay_v1 \
  --authorization AUTORIZACAO_ROOT.json --g0 G0_ROOT.json \
  --allocation ALOCACAO_CONJUNTA.json --runtime-inputs CAMINHOS_ORIGINAIS.json
```

Se aprovados, acrescentar `--evidence-index` e `--consumers` com os arquivos
vinculados à autorização. Acrescentar `--resume` apenas para o mesmo plano,
fontes, output, autorização e Ledger. Nenhum caminho fictício acima foi usado
para criar um recibo de execução/aprovação.
