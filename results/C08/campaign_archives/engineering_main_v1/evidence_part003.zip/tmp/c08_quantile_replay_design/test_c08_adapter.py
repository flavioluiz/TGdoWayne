"""One small external-routing/LOW interception TOY; no high/raw physics."""
from pathlib import Path
import tempfile,unittest,json
from unittest.mock import patch
import numpy as np
from contracts import load_helper
from inference.campaign_io import write_json_new,sha256,read_json
from c08_adapter import external_metadata,freeze_C_low
ROOT=Path(__file__).resolve().parents[2]

class C08AdapterTest(unittest.TestCase):
    def test_low_interception_and_external_kernel_guard(self):
        helper=load_helper(ROOT/'tmp/c08_execution_design/quantile_brackets.py')
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory);cohort=read_json(ROOT/'tmp/c08_driver_design/configs/cohort_index.json')
            cp=p/'cohort.json';write_json_new(cp,cohort)
            producer=dict(identity='TOY',uses_truth=False,status='IID_COMPLETE_AWAITING_DIAGNOSTICS',
                datum=25,target=1025,model='B_CN',levels=[16384,65536],replicates=[],
                input_sha256=dict(data=cohort['data_sha256']))
            pp=p/'producer.json';write_json_new(pp,producer)
            receipt=dict(schema='C08_EXTERNAL_TARGET_RECORD_v1',identity='TOY',stage='production',
                internal_record_sha256=sha256(pp),internal_record=pp.name,internal_record_unmodified=True,
                datum=25,internal_target=1025,internal_kernel='B_CN',response_variant='C_beta',
                model='C_beta_CN',external_target='C_beta_CN:25')
            rp=p/'receipt.json';write_json_new(rp,receipt)
            calls=[]
            def low_only(record,raw,level):
                self.assertEqual(level,16384);calls.append(level)
                x=np.random.default_rng(808130903).random((4,32,5));return x,np.log1p(.2*x[:,:,0])
            with patch('c08_adapter.read_level',side_effect=low_only):
                cuts=freeze_C_low(pp,rp,p/'never_opened',p/'cuts',identity='TOY',cohort_path=cp,helper=helper)
                second=freeze_C_low(pp,rp,p/'never_opened',p/'cuts',identity='TOY',cohort_path=cp,helper=helper)
            self.assertEqual(cuts,second);self.assertEqual(calls,[16384])
            frozen=read_json(cuts);self.assertFalse(frozen['uses_high']);self.assertEqual(frozen['scientific_model'],'C_beta_CN')
            receipt['model']='C_beta_G';receipt['external_target']='C_beta_G:25'
            # Deliberately inconsistent scientific G -> internal CN; no arrays.
            rp.write_text(json.dumps(receipt))
            with self.assertRaises(RuntimeError):external_metadata(pp,rp,identity='TOY',cohort=cohort)

if __name__=='__main__':unittest.main()
