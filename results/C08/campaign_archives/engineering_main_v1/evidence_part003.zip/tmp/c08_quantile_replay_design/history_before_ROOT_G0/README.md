# C08: replay alto pareado e brackets horizontais — candidato prospectivo

O pacote implementa o replay das cinco famílias C07 nos 32 IDs congelados e a
avaliação dos 20 quantis por bandas simultâneas de CDF. **Nenhum replay físico,
treino, ORF ou cálculo de likelihood PTA foi executado neste pacote.** As fontes
C07 e os candidatos anteriores de driver/runtime C08 permanecem intactos.

Já foi feito: leitura de metadados/propostas/checkpoints arquivados, verificação
dos seus SHA e leitura exclusiva do membro `independent_cuts_unit` dos 160
compactos. `frozen_c07/replay_plan.json` vincula 640 receitas altas e **68.697
endpoints efetivos**. Nenhum membro high, PIT ou verdade foi deserializado para
selecionar cortes. Os 24 casos representativos e oito de estresse continuam
rotulados separadamente. O acervo original C07 não foi modificado.

## Operações reais disponíveis

* `contracts.py`: inventário 32×5, verificação da origem, congelamento LOW e
  comparação somente de metadados da árvore importada C07.
* `replay.py`: receita original PCG64/stage420, proposta arquivada sem retreino,
  ordem de operações/arrays original, escrita ZIP_STORED e exigência do **SHA
  original do arquivo inteiro**. Confere estados RNG antes/depois. Um arquivo
  divergente fica preservado como falha; não se troca semente/backend.
* `endpoints.py`: `evaluate_high(x[R,N,5], log_weights[R,N], frozen, low_guards,
  helper=..., evidence=...)`. Reutiliza `TargetIIDContext` sem alterar suas
  fórmulas. Aceita as nove famílias científicas e conserva denominadores globais.
* `run_replay.py`: CLI `freeze-c07`, `preflight`, `run`. O último exige
  `--execute` **e** autorização de fonte/plano/output, G0, alocação e insumos
  originais. Usa o Ledger e o lock C07 sem editar suas fontes. Constrói uma única
  instância do backend original depois desses controles.
* `c08_adapter.py`: funções externas para congelar LOW dos novos C imediatamente
  após a produção indexada e **antes** do diagnóstico que lê HIGH; depois lê o
  compacto normal e os raws altos, calcula brackets e verifica sua preservação
  antes da liberação. O adaptador não está instalado no driver C08 anterior.

## Critérios congelados e significado

Para cada quantil LOW, os cortes são centro e
±{0,0005; 0,001; 0,002; 0,004; 0,008; 0,016; 0,032; 0,064; 0,128; 0,256},
mais extremos exatos 0 e1. Somente os cortes são truncados ao suporte; valores
da cadeia, pesos e CDFs não são corrigidos por clipping. Há até23 cortes por
quantil. O arquivo original `quantile_brackets.py` é importado pelo SHA
congelado no protocolo C08 v4.

A família u95 tem6.624 testes e α=0,025; os outros19 quantis têm125.856 e o
mesmo α. Os limites usam z bilateral Bonferroni, MCSE de influência SNIS e
dispersão entre quatro réplicas, somados à margem operacional de CDF0,002.
**Não se usa intervalo binomial ou Clopper–Pearson para uma CDF SNIS, nem N=ESS.**

A consistência entre réplicas nos novos cortes tem família adicional separada
de796.608 contrastes, α=0,05, aceita prospectivamente pelo ROOT para este
candidato. A expressão é32×9×(20×23+1)×6, incluindo logZ. São avaliados somente
cortes interiores distintos por parâmetro; duplicatas/extremos não reduzem o
denominador. A estabilidade low–high de logZ usa uma família candidata de288,
α=0,05, ainda dependente de aceitação explícita no recibo de execução. Essa
comparação só diagnostica o denominador da razão SNIS: não exige MCSE(logZ)
0,001 e não produz Bayes factors. Os seis contrastes LOW de logZ já registrados
mantêm sua família original. Testes de PIT/verdades não são reabertos.

Um corte interior só pode estreitar o bracket se MCSE≤0,00335, réplicas
resolvidas e contrastes consistentes. Um indicador constante permanece não
resolvido; somente os extremos exatos do suporte contínuo recebem MCSE0.
Falha de peso máximo/deleção, saturação>10⁻¹², consistência de logZ ou evidência
determinística ausente/falha torna os20 brackets desse posterior **[0,1]**.
Cortes sem precisão têm banda vazia de informação [0,1], mantendo estatísticas
originais; eles não são descartados do relatório. Não há refinamento automático.

O bracket é o maior corte com banda superior abaixo de p até o menor corte com
banda inferior acima de p. Não se divide o erro de CDF por uma densidade
presumida. A diferença pareada é `[l_C−h_B, h_C−l_B]`; larguras usam aritmética
de intervalos. Não se promete precisão horizontal0,001, nem uma conclusão
populacional sobre deslocamentos pequenos nos500 casos.

O contrato de evidência em `SCHEMAS.md` exige avaliação explícita coarse/fine,
oráculo e controles no domínio posterior relevante. É **evidência finita e
operacional**, sem prova uniforme. O código não transforma um máximo finito de
|ΔlogL|, nem o valor na verdade, em certificado uniforme de CDF. Se essa
evidência estiver ausente, os cálculos descritivos podem ser preservados, mas
os brackets ficam não resolvidos. Aprovação de uma resposta física e calibração
estatística permanecem tarefas distintas.

## Custos e ciclo de armazenamento

O replay obrigatório custa exatamente32×5×4×65.536 = **41.943.040 LL**, sem
treino e sem sementes novas. O Ledger próprio não pode exceder esse total.
O custo combinado prospectivo já registrado, incluindo novas C, engenharia,
reserva de512 LL de verdade e eventual KL cruzado, é94.897.216 sob110M.
O replay não consome a reserva restante nem executa o KL opcional.

Por alvo são29.631.512 bytes armazenados de HIGH (quatro arquivos); o conjunto
completo ultrapassaria1GiB. O ciclo é alvo → replay → diagnóstico compacto →
verificação de consumidores obrigatórios → arquivo e liberação. Não há banco
novo por alvo. A estimativa C07 original é2.457.994.240 bytes; a reserva extra
de256MiB para os endpoints leva a2.726.429.696, abaixo de4GiB. As chamadas de
CDF agrupam no máximo16 cortes, incluindo o fallback de influência do v1.
Esses números são estimativas de memória, não medição/certificado futuro de RSS.

Usa-se o backend nativo original, seis workers de likelihood e BLAS/OpenMP1,
preservando o plano original. O lock de recursos deve ser **o mesmo diretório
compartilhado** do driver C08, adquirido antes da construção do banco. O input
de alocação deve reservar41.943.040 para este executor e respeitar110M na soma
de todos os consumidores registrados; ele não é uma autorização por si só.

Os hashes originais são um oráculo de reprodução estrita. O TOY confirmou a
igualdade da serialização no ambiente atual; **não se garante** a mesma
reprodução em outro NumPy/SciPy/BLAS/SO ou compilador. Uma diferença física de
roundoff também reprova o replay exato: não se relaxa esse requisito para
transportar os resultados. As versões locais são registradas na validação.

Um orphan cujo SHA já é igual ao original pode ser recuperado sem repetir LL.
Chamadas interrompidas gastam a reserva/count do Ledger; a soma do gasto e do
trabalho faltante deve continuar cabendo no orçamento original. Isso pode
impedir a retomada de uma computação parcial, que exigiria decisão separada.
Interrupção durante liberação retoma pelo recibo e pelos hashes, sem recomputar.
Falhas numéricas são arquivadas, não convertidas em aprovação.

Se forem desejados momentos/KL nos quatro IDs opcionais, seus consumidores
devem constar do índice **antes da execução**. O executor aguardará os recibos
correspondentes antes de retirar aqueles raws. Não há implementação de KL nem
autorização de avaliações cruzadas neste pacote.

## Comandos e pendências de integração

Os comandos executados aqui estão em `COMMANDS.md`. Preflight não constrói banco
nem abre dados observados; o `run` só funciona após todos os insumos reais.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
.venv/bin/python tmp/c08_quantile_replay_design/run_replay.py \
  --repository . --helper tmp/c08_execution_design/quantile_brackets.py \
  preflight --plan tmp/c08_quantile_replay_design/frozen_c07/replay_plan.json \
  --output tmp/c08_required_high_replay_v1 --report NOVO_RELATORIO.json
```

Antes da execução física: ROOT revisar fontes/protocolo; criar G0 com a versão
publicada C07 e encerramento/liberação; fixar a alocação conjunta e lock;
fornecer os oito caminhos originais em `runtime_inputs.json`; decidir o índice
de consumidores; vincular evidências operacionais ou aceitar o resultado
explicitamente não resolvido; emitir a autorização exata descrita em
`SCHEMAS.md`. `--execute` e `--resume` não substituem esses documentos.

Para as novas C: ligar os três hooks externos de LOW/diagnóstico/liberação em
um **novo wrapper autorizado**, incluir suas fontes e recibos no manifesto
externo e verificar os brackets também ao retomar alvos já arquivados. Não
alterar retroativamente o driver v1/v2 nem considerar os hooks já instalados.
O adaptador evita reler high numa retomada com resultado completo verificado.

Neste fechamento, C07 foi publicado como v0.7.0 e o ROOT prepara correção
v0.7.1 de harness/CI. **G0 segue pendente**. Nenhum recibo de aprovação foi
inventado ou salvo por este pacote.
