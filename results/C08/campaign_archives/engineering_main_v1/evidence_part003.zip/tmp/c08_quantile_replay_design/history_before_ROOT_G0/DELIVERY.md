# Entrega ao ROOT

**Candidato prospectivo concluído, sem execução física.** Foram verificados os
metadados/propostas/checkpoints e congelados os cortes LOW dos160 posteriors
C07 da coorte32. São68.697 endpoints reais e640 receitas HIGH, com zero LL,
ORF, treino novo, leitura de raw HIGH ou deserialização de verdade.

Arquivos centrais:

* `run_replay.py`, `contracts.py`, `replay.py`: preflight, execução autorizada,
  replay idêntico e ciclo de conservação dos compactos.
* `endpoints.py`: bandas, falhas por finalidade e diferenças pareadas.
* `c08_adapter.py`: interceptação externa LOW e análise HIGH dos novos C;
  **não instalado** no driver C08 em revisão.
* `frozen_c07/replay_plan.json` e `frozen_c07/cuts/`:160 cortes/manifestações
  de origem, propostas/checkpoints referenciados por SHA e receitas preservadas.
* `preflight_candidate.json`, `SCHEMAS.md`, `README.md`, `COMMANDS.md`:
  fontes, limites, operações e insumos de autorização ainda pendentes.
* `validation/toy_validation.json`, `validation/toy_tests.log`:11 testes PASS,
 3,550605 s CPU com imports, pico RSS126.353.408 bytes. As versões preliminares
  dos logs/preflight ficaram preservadas, explicitamente anteriores aos guards
  finais; não houve falha física nem reclassificação de campanha.

SHA do plano: `ebf97eeca6cb6c3b2a97e931f08027fdd267f187d15227fb1b43c27843431ef8`.
SHA do preflight final: `29dcd2c24cb0d703ca679dedb5c0a201e315fe1d996f1d64573aa23d9167e402`.
O manifesto de pacote registra cada arquivo selecionado, seu tamanho e SHA;
exclui caches e não duplica tabelas/bancos/datasets.

Os31 arquivos da closure original C07 continuam com os SHA originais. A
reprodução estrita custa41.943.040 LL e conserva o plano original de seis
workers externos/BLAS1, uma instância de banco, estimativa com reserva
2.726.429.696 bytes sob4GiB e quatro raws/alvo totalizando29.631.512 bytes.
A reserva global permanece110M; não há refinamento, retry ou sementes novos.

Pendências concretas, sem aprovação implícita:

1. ROOT revisar/autorizar o candidato, inclusive a família de estabilidade de
   logZ288/α0,05. A família adicional796.608/α0,05 foi mantida como acordado.
2. G0 após a correção/publicação C07 e liberação de workers/bancos; declarar
   a versão efetiva no recibo. Nenhum recibo foi produzido por este pacote.
3. Fornecer alocação/lock compartilhados, oito caminhos originais e autorização
   que vincule plano/fontes/protocolo/output. A closure e o binário devem
   reproduzir a identity original; diferença de SHA do raw interrompe e preserva.
4. Fornecer evidência operacional do domínio de cada posterior ou conservar
   brackets não resolvidos. Não é exigida/alegada uma prova uniforme inexistente.
5. Decidir consumidores opcionais antes da liberação de seus raws. O código
   não implementa/reexecuta KL ou momentos; apenas exige seus recibos se listados.
6. Para os novos C, ligar o adaptador em wrapper externo com fontes/recibos
   próprios e interceptação declarada antes da leitura HIGH. Preservar também
   esses arquivos na retomada/arquivo. O driver anterior segue byte a byte.

Nada foi copiado para `src/`, `scripts/`, `results/` oficiais ou commitado.
