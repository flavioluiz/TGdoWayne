"""Analytic/transport TOYs only. No PTA bank, ORF or physical likelihood."""
from pathlib import Path
import hashlib,json,tempfile,unittest
from unittest.mock import patch
import numpy as np
from scipy.special import expit
from inference.campaign_io import (rng_for,sha256,write_npz_new,write_json_new,canonical_hash)
from inference.gmm_proposal import GaussianDefensiveProposal
from inference.campaign_iid import sample_single_target
from inference.iid_optimized import TargetIIDContext
from contracts import (load_helper,freeze_low,protocol,validate_protocol,read_only_low_member,
                       verify_cut_manifest,validate_cohort)
from endpoints import evaluate_high,paired_quantiles,central_width,contrast
from replay import replay_arrays,archive_target,validate_G0
from run_replay import compact_arrays

ROOT=Path(__file__).resolve().parents[2]
HELPER=load_helper(ROOT/'tmp/c08_execution_design/quantile_brackets.py')


def frozen(model='A0_CN',datum=25,low=None):
    if low is None:low=np.tile([.05,.5,.9,.95],(5,1))
    return freeze_low(low,helper=HELPER,identity='TOY',model=model,datum=datum,internal_target=25,
                      source_path='TOY_LOW_ONLY',source_sha256='0'*64,cohort_sha256='1'*64)


def evidence(f):
    return dict(schema='C08_POSTERIOR_CDF_EVIDENCE_v1',identity='TOY',scientific_model=f['scientific_model'],
        datum=f['datum'],cut_manifest_content_sha256=f['content_sha256'],operational_margin=.002,
        is_uniform_proof=False,posterior_domain='TOY analytic bounded target; API test, not PTA validation',
        checks=dict(coarse_fine=True,independent_oracle=True,posterior_domain_controls=True),
        sources=[dict(path='TOY_analytic_fixture',sha256='0'*64)])


class CandidateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rng=np.random.default_rng(808130901)
        cls.x=cls.rng.random((4,8192,5));cls.lw=np.log1p(.2*cls.x[:,:,0])
        w=TargetIIDContext(cls.lw).weights()
        cls.low=dict(weight_deletion_pass=True,logZ_replica_pass=True,maximum_saturated_weight=0.,
                     logZ=w['log_evidence'],logZ_mcse=w['log_evidence_delta_mcse'],low_only=True)
        cls.f=frozen();cls.result=evaluate_high(cls.x,cls.lw,cls.f,cls.low,helper=HELPER,
                          evidence=evidence(cls.f),verify_evidence_files=False)

    def test_01_frozen_offsets_edges_and_families(self):
        f=frozen(low=np.tile([0.,.5,.99,1.],(5,1)))
        self.assertEqual(verify_cut_manifest(f,HELPER),f)
        self.assertEqual(f['cuts'][0][1],np.unique(np.r_[0,1,np.clip(.5+HELPER.OFFSETS,0,1)]).tolist())
        self.assertLessEqual(max(len(c) for row in f['cuts'] for c in row),23)
        p=protocol();self.assertEqual((p['u95_family'],p['other19_family'],p['additional_replicate_family']),(6624,125856,796608))
        p['u95_family']=23
        with self.assertRaises(ValueError):validate_protocol(p)

    def test_02_low_loader_never_accesses_other_members(self):
        class LowOnly:
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def __getitem__(self,key):
                if key!='independent_cuts_unit':raise AssertionError('HIGH/truth accessed')
                return np.tile([.05,.5,.9,.95],(5,1))
        with patch('contracts.bound_file',return_value='TOY'),patch('contracts.np.load',return_value=LowOnly()):
            low=read_only_low_member('TOY','0'*64)
        self.assertEqual(low.shape,(5,4))

    def test_03_influence_matches_direct_and_family_fixed(self):
        row=self.result['rows'][5];stats=[r for r in row['endpoint_statistics'] if not r['structural']]
        direct=TargetIIDContext(self.lw).cdf(self.x[:,:,1],[r['threshold'] for r in stats])
        for a,b in zip(stats,direct):
            for key in ['estimate','mcse','pooled_iid_influence_mcse','between_replications_influence_mcse']:
                self.assertAlmostEqual(a[key],b[key],places=12)
            self.assertEqual(a['precision_pass'],b['precision_pass'])
        self.assertEqual(self.result['rows'][3]['family_tests'],6624)
        self.assertTrue(all(r['family_tests']==125856 for i,r in enumerate(self.result['rows']) if i!=3))
        # Independent analytical mean of w=1+.2x under a uniform proposal is1.1.
        self.assertLess(abs(np.exp(self.result['high_weights']['log_evidence'])-1.1),.002)

    def test_04_missing_deterministic_and_common_failure_are_vacuous(self):
        missing=evaluate_high(self.x[:,:128],self.lw[:,:128],self.f,self.low,helper=HELPER)
        self.assertTrue(all((r['lower_quantile'],r['upper_quantile'])==(0.,1.) for r in missing['rows']))
        low=dict(self.low,weight_deletion_pass=False)
        failed=evaluate_high(self.x[:,:128],self.lw[:,:128],self.f,low,helper=HELPER,
            evidence=evidence(self.f),verify_evidence_files=False)
        self.assertTrue(all(r['width']==1 and r['status'].startswith('UNRESOLVED') for r in failed['rows']))

    def test_05_constant_indicators_do_not_pass_but_support_is_exact(self):
        x=np.full((4,32,5),.5);lw=np.tile(np.linspace(-.2,.2,32),(4,1))
        result=evaluate_high(x,lw,self.f,self.low,helper=HELPER,evidence=evidence(self.f),verify_evidence_files=False)
        for row in result['rows']:
            self.assertEqual((row['endpoint_statistics'][0]['estimate'],row['endpoint_statistics'][-1]['estimate']),(0.,1.))
            self.assertTrue(row['endpoint_statistics'][0]['structural'])
            self.assertTrue(all(not s['endpoint_usable'] and np.isinf(s['mcse']) for s in row['endpoint_statistics'][1:-1]))

    def test_06_paired_interval_arithmetic(self):
        import copy
        a=copy.deepcopy(self.result);b=copy.deepcopy(self.result)
        a['scientific_model']='C_beta_CN';b['scientific_model']='B_CN'
        for row in a['rows']:row.update(lower_quantile=.3,upper_quantile=.6)
        for row in b['rows']:row.update(lower_quantile=.2,upper_quantile=.4)
        paired=paired_quantiles(a,b,helper=HELPER)
        self.assertAlmostEqual(paired['rows'][0]['lower'],-.1)
        self.assertAlmostEqual(paired['rows'][0]['upper'],.4)
        width=central_width(a['rows'][0],a['rows'][3]);self.assertEqual(width['lower'],0.)
        self.assertAlmostEqual(width['upper'],.3)
        b['datum']=26
        with self.assertRaises(ValueError):paired_quantiles(a,b,helper=HELPER)

    def test_07_exact_serialization_and_original_draw_order_toy(self):
        p=GaussianDefensiveProposal(np.array([[1.]]),np.zeros((1,1,5)),np.eye(5)[None,None],
                                    np.zeros((1,5)),np.eye(5)[None])
        n=127;seed=808130902;target=9;rep=2;rng=rng_for(seed,420,target,rep);before=rng.bit_generator.state
        z,c=sample_single_target(p,rng,n);after=rng.bit_generator.state
        cp=dict(samples=n,replicate=rep,seed=seed,rng_state_before=before,rng_state_after=after)
        class ToyRuntime:
            bounds=np.array([[0.,1.]]*5)
            def __init__(self):self.calls=0
            def likelihood(self,theta,targets):
                self.calls+=len(theta);return -.5*np.sum(theta*theta,axis=1)+targets*.001
        rt=ToyRuntime();arrays=replay_arrays(rt,p,target,cp,batch=17)
        self.assertEqual(rt.calls,n);np.testing.assert_array_equal(arrays['z'],z)
        np.testing.assert_array_equal(arrays['proposal_component'],c.astype(np.uint8))
        x=expit(z);lp=(-np.logaddexp(0,-z)-np.logaddexp(0,z)).sum(1)
        expected=dict(z=z,x_unit=x,log_likelihood=-.5*np.sum(x*x,axis=1)+target*.001,
            log_weights=-.5*np.sum(x*x,axis=1)+target*.001+lp-p.logpdf(z),
            log_proposal=p.logpdf(z),log_prior_logit=lp,proposal_component=c.astype(np.uint8),
            target=np.asarray(target),replicate=np.asarray(rep))
        for key in arrays:np.testing.assert_array_equal(arrays[key],expected[key])
        with tempfile.TemporaryDirectory() as directory:
            a=Path(directory)/'a.npz';b=Path(directory)/'b.npz'
            write_npz_new(a,compressed=False,**arrays);write_npz_new(b,compressed=False,**expected)
            self.assertEqual(sha256(a),sha256(b))
        cp['rng_state_before']=dict(before,state={'state':0,'inc':1})
        with self.assertRaises(RuntimeError):replay_arrays(rt,p,target,cp,batch=17)
        self.assertEqual(rt.calls,n)

    def test_08_compact_retains_all_flags(self):
        arrays=compact_arrays(self.result)
        self.assertEqual(arrays['cuts'].shape,(20,23));self.assertEqual(arrays['quantile_bounds'].shape,(20,2))
        self.assertTrue(np.isnan(arrays['cuts'][~arrays['endpoint_present']]).all())
        self.assertEqual(int(arrays['endpoint_present'].sum()),sum(len(r['cuts']) for r in self.result['rows']))
        self.assertEqual(int(arrays['structural'].sum()),40)

    def test_09_exact_file_retirement_resumes_and_preserves_unresolved(self):
        with tempfile.TemporaryDirectory() as directory:
            out=Path(directory);raw=out/'raw'/'toy.npz';write_npz_new(raw,compressed=False,x=np.arange(3))
            cut=out/'cut.json';write_json_new(cut,dict(toy=True))
            num=out/'diagnostics'/'toy.npz';write_npz_new(num,a=np.arange(20))
            d=out/'diagnostics'/'toy.json';rawhash=sha256(raw)
            diag=dict(plan_sha256='TOY',target=25,raw_sha256={'toy.npz':rawhash},all20_retained=True,
                      scope='C08_HORIZONTAL_QUANTILE_DIAGNOSTIC',numeric_file='toy.npz',numeric_sha256=sha256(num),
                      numerical_status='BRACKETS_RECORDED_WITH_FAILURES')
            write_json_new(d,diag)
            row=dict(target=25,datum=25,scientific_model='A0_CN',original_receipt={},original_files={},
                cut_manifest=dict(path=str(cut),sha256=sha256(cut)),high_checkpoints=[dict(raw_file='toy.npz',raw_sha256=rawhash)])
            first=archive_target(row,out,d,plan_sha='TOY',consumers=[])
            self.assertFalse(raw.exists());self.assertEqual(first['numerical_status'],'BRACKETS_RECORDED_WITH_FAILURES')
            second=archive_target(row,out,d,plan_sha='TOY',consumers=[]);self.assertEqual(first,second)
            num.write_bytes(b'tampered')
            with self.assertRaises(RuntimeError):archive_target(row,out,d,plan_sha='TOY',consumers=[])

    def test_10_guards_and_nonfinite_precision(self):
        self.assertFalse(contrast(.5,0,.5,0,family=796608,alpha=.05)['consistent'])
        self.assertFalse(contrast(.5,np.inf,.5,.1,family=796608,alpha=.05)['resolved'])
        bad=evidence(self.f);bad['is_uniform_proof']=True
        with self.assertRaises(ValueError):evaluate_high(self.x[:,:8],self.lw[:,:8],self.f,self.low,helper=HELPER,evidence=bad)
        with self.assertRaises(ValueError):evaluate_high(self.x[:,:8].astype(complex),self.lw[:,:8],self.f,self.low,helper=HELPER)
        index=json.load(open(ROOT/'tmp/c08_driver_design/configs/cohort_index.json'))
        index['stress_ids'][0]=index['representative_ids'][0]
        with self.assertRaises(ValueError):validate_cohort(index)
        # A synthetic receipt checks the existing ROOT schema and Boolean guard;
        # it neither asserts that G0 is satisfied nor reads physical artifacts.
        g0=dict(schema='C07_PUBLICATION_AND_RESOURCE_RELEASE_RECEIPT_v1',status='C07_PUBLISHED_AND_RELEASED',
            scope='C07_PUBLISHED_AND_WORKERS_MEMORY_RELEASED',released_for_c08=True,active_workers=0,
            c07_runtime_identity='TOY',publication=dict(status='PUBLISHED',tag='v0.7.1',commit='0'*40,
                evidence=dict(path='TOY_release',sha256='2'*64)),evidence=[dict(path='TOY_complete',sha256='1'*64)])
        with patch('replay.bound_file',return_value='TOY') as check:
            self.assertTrue(validate_G0(g0,dict(identity='TOY',campaign_complete_sha256='1'*64)))
            self.assertEqual(check.call_count,2)
            g0['active_workers']=False
            with self.assertRaises(RuntimeError):validate_G0(g0,dict(identity='TOY',campaign_complete_sha256='1'*64))

if __name__=='__main__':unittest.main()
