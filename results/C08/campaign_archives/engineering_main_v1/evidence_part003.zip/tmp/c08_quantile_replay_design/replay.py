"""Exact C07 HIGH-only replay into a separate bounded C08 output namespace."""
from pathlib import Path
import re
import numpy as np
from scipy.special import expit,logsumexp
from inference.campaign_io import (read_json,sha256,canonical_hash,rng_for,
    write_npz_new,write_json_new)
from inference.campaign_iid import sample_single_target
from inference.campaign_training import validate_proposal
from contracts import HIGH_N,REPLAY_LL,bound_file,source_closure


def replay_arrays(runtime,proposal,target,checkpoint,*,batch):
    """The original arithmetic, array insertion order and RNG recipe.

    Private numerical routine: production CLI must authorize and reserve before
    calling it. Tests use an explicitly analytic TOY runtime, never PTA kernels.
    """
    n=checkpoint['samples'];rep=checkpoint['replicate']
    rng=rng_for(checkpoint['seed'],420,target,rep)
    if rng.bit_generator.state!=checkpoint['rng_state_before']:
        raise RuntimeError('Original PCG64 starting state differs.')
    z,component=sample_single_target(proposal,rng,n)
    if rng.bit_generator.state!=checkpoint['rng_state_after']:
        raise RuntimeError('Original PCG64 final state differs; no likelihood evaluated.')
    x=expit(z);logq=proposal.logpdf(z)
    logprior=(-np.logaddexp(0,-z)-np.logaddexp(0,z)).sum(axis=1)
    theta=runtime.bounds[:,0]+x*np.diff(runtime.bounds,axis=1)[:,0];ll=np.empty(n)
    for begin in range(0,n,batch):
        stop=min(n,begin+batch)
        ll[begin:stop]=runtime.likelihood(theta[begin:stop],np.full(stop-begin,target,int))
    logw=ll+logprior-logq
    if not all(np.isfinite(a).all() for a in (z,x,ll,logq,logprior,logw)):
        raise ArithmeticError('Nonfinite raw; no clipping or replacement.')
    return dict(z=z,x_unit=x,log_likelihood=ll,log_weights=logw,log_proposal=logq,
                log_prior_logit=logprior,proposal_component=component.astype(np.uint8),
                target=np.asarray(target),replicate=np.asarray(rep))


def replay_replicate(runtime,row,checkpoint,output,*,plan_sha,resume=False):
    target=row['target'];output=Path(output);rep=checkpoint['replicate']
    if (checkpoint['samples']!=HIGH_N or checkpoint['level_index']!=1
            or checkpoint['seed']!=907110102 or checkpoint['raw_compression']!='stored'
            or rep not in range(4) or checkpoint['target']!=target):
        raise ValueError('Only the original fixed HIGH recipe is accepted.')
    raw=output/'raw'/checkpoint['raw_file']
    if raw.name!=checkpoint['raw_file']:raise ValueError('Raw basename required.')
    receipt=output/'replicas'/f'target_{target:06d}_rep{rep}.json'
    expected=dict(schema='C08_EXACT_HIGH_REPLAY_RECEIPT_v1',plan_sha256=plan_sha,
        identity=runtime.identity,target=target,replicate=rep,samples=HIGH_N,
        proposal_sha256=row['original_files']['proposal']['sha256'],
        raw_file=str(raw.relative_to(output)),raw_sha256=checkpoint['raw_sha256'],
        original_raw_sha256=checkpoint['raw_sha256'],original_rng_state_before=checkpoint['rng_state_before'],
        original_rng_state_after=checkpoint['rng_state_after'],uses_truth=False,new_seed=False,
        numerical_accuracy_approval=False)
    if receipt.exists():
        if not resume:raise FileExistsError('Replay exists; explicit --resume required.')
        old=read_json(receipt)
        if any(old.get(k)!=v for k,v in expected.items()) or old.get('status')!='BIT_EXACT_HIGH_REPLAY':
            raise RuntimeError('Replay receipt differs.')
        bound_file(raw,checkpoint['raw_sha256']);return old
    orphan=raw.exists()
    if orphan:
        if not resume:raise FileExistsError('Uncommitted raw requires explicit resume.')
        # The *original* complete file hash is already a deterministic oracle:
        # recovering a fully written orphan needs no repeated likelihood call.
        bound_file(raw,checkpoint['raw_sha256'])
    else:
        active=sum(p.stat().st_size for p in (output/'raw').glob('*.npz'))
        if active+checkpoint['raw_bytes']>1024**3:raise RuntimeError('Active raw cap exceeded before replay.')
        propfile=bound_file(row['original_files']['proposal']['path'],expected['proposal_sha256'])
        proposal_record=read_json(propfile)
        if (proposal_record.get('uses_truth') is not False
                or proposal_record['identity']!=runtime.target_identity
                or proposal_record['target']!=target
                or canonical_hash({k:v for k,v in proposal_record.items() if k!='proposal_content_hash'})!=proposal_record['proposal_content_hash']):
            raise RuntimeError('Archived proposal contract changed.')
        proposal=validate_proposal(proposal_record)
        arrays=replay_arrays(runtime,proposal,target,checkpoint,batch=runtime.settings['production']['likelihood_batch'])
        write_npz_new(raw,compressed=False,**arrays)
        actual=sha256(raw)
        if actual!=checkpoint['raw_sha256']:
            write_json_new(output/'failures'/f'target_{target:06d}_rep{rep}.json',dict(
                status='FAILED_EXACT_REPLAY_PRESERVE_RAW',expected=checkpoint['raw_sha256'],actual=actual,
                plan_sha256=plan_sha,target=target,replicate=rep,no_retry_authorized=True))
            raise RuntimeError('Replayed raw differs from original SHA; preserve failed bytes, no retry.')
    expected.update(status='BIT_EXACT_HIGH_REPLAY',orphan_recovered_without_LL=orphan)
    write_json_new(receipt,expected);return expected


def load_replayed_high(row,output):
    """Only after the frozen low-cut receipt exists and replay SHAs match."""
    output=Path(output);xs=[];ws=[]
    # 4*(N*5+N)*8 bytes, plus one NPZ input array: < 20MiB, no raw z/logL load.
    for checkpoint in row['high_checkpoints']:
        path=bound_file(output/'raw'/checkpoint['raw_file'],checkpoint['raw_sha256'])
        with np.load(path,allow_pickle=False) as data:
            if (data['target'].item()!=row['target'] or data['replicate'].item()!=checkpoint['replicate']):
                raise RuntimeError('Raw target/replicate mismatch.')
            xs.append(data['x_unit'].copy());ws.append(data['log_weights'].copy())
    x=np.asarray(xs);w=np.asarray(ws)
    if x.shape!=(4,HIGH_N,5) or w.shape!=(4,HIGH_N):raise RuntimeError('Wrong replay raw shapes.')
    return x,w


def validate_execution(plan,authorization,g0,allocation,*,plan_path,output,
                       repository,source_hashes):
    """Metadata gate before loading observations, native bank, RNG or high raws."""
    payload={k:v for k,v in plan.items() if k!='content_sha256'}
    if (plan.get('schema')!='C08_C07_HIGH_REPLAY_PLAN_v1'
            or canonical_hash(payload)!=plan.get('content_sha256')
            or plan['counts']['targets']!=160 or plan['counts']['high_LL']!=REPLAY_LL):
        raise RuntimeError('Frozen replay plan changed.')
    from contracts import validate_cohort,MODELS
    cohort=read_json(bound_file(plan['cohort_path'],plan['cohort_sha256']))
    ids=validate_cohort(cohort)
    expected=[(i*500+d,d,m) for i,m in enumerate(MODELS[:5]) for d in ids]
    actual=[(r['target'],r['datum'],r['scientific_model']) for r in plan['rows']]
    if actual!=expected:raise RuntimeError('All32x5 matched targets in frozen order are required.')
    for row in plan['rows']:
        cp=row['high_checkpoints']
        if len(cp)!=4 or [c['replicate'] for c in cp]!=list(range(4)):
            raise RuntimeError('Four ordered original checkpoints per target required.')
    original_root=Path(plan['original_manifest']['path']).resolve().parents[2]
    dest=Path(output).resolve()
    if dest==original_root or original_root in dest.parents:
        raise RuntimeError('Replay output must be outside the original C07 campaign.')
    if not source_closure(repository,read_json(bound_file(plan['original_manifest']['path'],plan['original_manifest']['sha256'])))['all_match']:
        raise RuntimeError('Current original C07 import closure differs; no alternate backend selected.')
    if (authorization.get('schema')!='C08_HIGH_REPLAY_AUTHORIZATION_v1'
            or authorization.get('stages')!=['required_C07_high_replay','endpoint_diagnostics']
            or authorization.get('approved') is not True
            or authorization.get('plan_sha256')!=sha256(plan_path)
            or authorization.get('output')!=str(Path(output).resolve())
            or authorization.get('source_sha256')!=source_hashes
            or authorization.get('maximum_LL')!=REPLAY_LL
            or authorization.get('original_identity')!=plan['identity']):
        raise RuntimeError('Explicit frozen replay authorization missing or mismatched.')
    validate_G0(g0,plan)
    if (authorization.get('G0_content_sha256')!=canonical_hash(g0)
            or authorization.get('allocation_content_sha256')!=canonical_hash(allocation)):
        raise RuntimeError('Authorization does not bind G0/allocation.')
    entries=allocation.get('allocations',{})
    if (allocation.get('schema')!='C08_COMBINED_LL_ALLOCATION_v1'
            or entries.get('required_C07_high_replay')!=REPLAY_LL
            or any(type(v)is not int or v<0 for v in entries.values())
            or sum(entries.values())>110000000 or allocation.get('cap')!=110000000
            or allocation.get('active_banks')!=1 or allocation.get('raw_cap')!=1024**3
            or allocation.get('numeric_cap')!=4*1024**3
            or authorization.get('resource_lock_root')!=allocation.get('resource_lock_root')):
        raise RuntimeError('Shared 110M/one-bank allocation differs.')
    return True


def validate_G0(g0,plan):
    """Read the ROOT G0 receipt directly; no invented replacement approval."""
    pub=g0.get('publication',{});files=g0.get('evidence',[])
    if (g0.get('schema')!='C07_PUBLICATION_AND_RESOURCE_RELEASE_RECEIPT_v1'
            or g0.get('status')!='C07_PUBLISHED_AND_RELEASED'
            or g0.get('scope')!='C07_PUBLISHED_AND_WORKERS_MEMORY_RELEASED'
            or g0.get('released_for_c08') is not True
            or type(g0.get('active_workers'))is not int or g0['active_workers']!=0
            or g0.get('c07_runtime_identity')!=plan['identity']
            or pub.get('status')!='PUBLISHED'
            or not re.fullmatch(r'v0\.7\.[0-9]+',str(pub.get('tag','')))
            or not re.fullmatch(r'[0-9a-f]{40}',str(pub.get('commit','')))
            or not pub.get('evidence') or not files
            or not any(f.get('sha256')==plan['campaign_complete_sha256'] for f in files)):
        raise RuntimeError('ROOT G0 publication/resource identity differs.')
    for f in files+[pub['evidence']]:bound_file(f['path'],f['sha256'])
    return True


def archive_target(row,output,diagnostic_path,*,plan_sha,consumers):
    """Preserve compact products and failures before own replay raw retirement.

    `consumers` is preauthorized metadata. Any required optional moments/KL
    consumer must provide its own hashed receipt first; this module never runs
    those additional operations. It never modifies the original C07 archive.
    """
    output=Path(output);dpath=Path(diagnostic_path).resolve();d=read_json(dpath)
    if (d.get('plan_sha256')!=plan_sha or d.get('target')!=row['target']
            or d.get('raw_sha256')!={c['raw_file']:c['raw_sha256'] for c in row['high_checkpoints']}
            or d.get('all20_retained') is not True or d.get('scope')!='C08_HORIZONTAL_QUANTILE_DIAGNOSTIC'):
        raise RuntimeError('Complete matched diagnostic required before raw retirement.')
    numeric=bound_file(dpath.parent/d['numeric_file'],d['numeric_sha256'])
    artifacts=[dict(path=str(dpath),sha256=sha256(dpath)),dict(path=str(numeric),sha256=sha256(numeric)),
               dict(path=row['cut_manifest']['path'],sha256=row['cut_manifest']['sha256'])]
    for consumer in consumers:
        path=bound_file(consumer['path'],consumer['sha256']);c=read_json(path)
        if c.get('target')!=row['target'] or c.get('raw_sha256')!=d['raw_sha256'] or c.get('status')!='CONSUMPTION_COMPLETE':
            raise RuntimeError('Required optional raw consumer is incomplete.')
        artifacts.append(dict(path=str(path),sha256=consumer['sha256']))
    archive=output/'archives'/f'target_{row["target"]:06d}.json'
    receipt=dict(schema='C08_REPLAY_COMPACT_ARCHIVE_v1',status='REPLAY_COMPACT_PRESERVED',
        plan_sha256=plan_sha,target=row['target'],scientific_model=row['scientific_model'],datum=row['datum'],
        original_receipt=row['original_receipt'],original_files=row['original_files'],
        raw_sha256=d['raw_sha256'],artifacts=artifacts,numerical_status=d['numerical_status'],
        all_failures_retained=True,no_SBC_or_physical_approval=True)
    if archive.exists():
        if read_json(archive)!=receipt:raise RuntimeError('Own compact archive changed.')
    else:
        for checkpoint in row['high_checkpoints']:bound_file(output/'raw'/checkpoint['raw_file'],checkpoint['raw_sha256'])
        write_json_new(archive,receipt)
    for item in artifacts:bound_file(item['path'],item['sha256'])
    # The immutable archive acts as the release intent; interrupted retirement
    # safely resumes by checking each still-existing raw against the original.
    for checkpoint in row['high_checkpoints']:
        raw=output/'raw'/checkpoint['raw_file']
        if raw.is_symlink():raise RuntimeError('Never retire a symlinked raw.')
        if raw.exists():
            bound_file(raw,checkpoint['raw_sha256']);raw.unlink()
    done=output/'state'/f'target_{row["target"]:06d}.json'
    state=dict(status='C08_REPLAY_TARGET_ARCHIVED',target=row['target'],plan_sha256=plan_sha,
               archive_path=str(archive),archive_sha256=sha256(archive),numerical_status=d['numerical_status'])
    if done.exists():
        if read_json(done)!=state:raise RuntimeError('Replay state changed.')
    else:write_json_new(done,state)
    return state
