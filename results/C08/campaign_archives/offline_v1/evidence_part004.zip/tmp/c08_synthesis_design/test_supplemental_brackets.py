"""Verify stored-statistic assessment against original TOY array evaluation."""
from pathlib import Path
import copy,hashlib,json,resource,sys,tempfile,time,unittest
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'tmp/c08_quantile_replay_design')]
import numpy as np
from contracts import freeze_low,load_helper,protocol
from endpoints import evaluate_high,validate_evidence
from supplemental_brackets import assess

class SupplementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(dir=ROOT/'tmp')
        cls.helper=load_helper(ROOT/'tmp/c08_execution_design/quantile_brackets.py')
        rng=np.random.default_rng(177);cls.x=rng.random((4,8192,5));cls.lw=rng.normal(0,.05,(4,8192))
        cls.low=dict(weight_deletion_pass=True,logZ_replica_pass=True,maximum_saturated_weight=0.,logZ=.00125,logZ_mcse=.005,low_only=True)
        cls.frozen=freeze_low(np.tile([.05,.5,.9,.95],(5,1)),helper=cls.helper,identity='toy-identity',model='A_G',datum=25,internal_target=1525,source_path='toy-low',source_sha256='a'*64,cohort_sha256='b'*64)
        cls.original=evaluate_high(cls.x,cls.lw,cls.frozen,cls.low,helper=cls.helper)
        cls.original.update(scope='C08_HORIZONTAL_QUANTILE_DIAGNOSTIC',all20_retained=True)
        source=Path(cls.tmp.name)/'finite_toy_evidence.txt';source.write_text('Analytic TOY only; not a PTA validation.\n')
        cls.evidence=dict(schema='C08_POSTERIOR_CDF_EVIDENCE_v1',identity='toy-identity',scientific_model='A_G',datum=25,
            cut_manifest_content_sha256=cls.frozen['content_sha256'],operational_margin=.002,is_uniform_proof=False,
            posterior_domain='Artificial unit-cube TOY, no physical interpretation',
            checks=dict(coarse_fine=True,independent_oracle=True,posterior_domain_controls=True),
            sources=[dict(path=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest())])
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_compact_reassessment_equals_full_toy_array_evaluation(self):
        saved=copy.deepcopy(self.original)
        actual=assess(self.original,self.frozen,self.evidence,helper=self.helper,validate_evidence=validate_evidence,protocol=protocol)
        direct=evaluate_high(self.x,self.lw,self.frozen,self.low,helper=self.helper,evidence=self.evidence)
        for a,b in zip(actual['rows'],direct['rows']):
            for k in ('lower_quantile','upper_quantile','status','lower_CDF_band','upper_CDF_band','endpoint_statistics','common_failures'):
                self.assertEqual(a[k],b[k])
        self.assertEqual(self.original,saved)
        self.assertTrue(all(r['width']==1 for r in self.original['rows']))
        self.assertTrue(any(r['width']<1 for r in actual['rows']))
    def test_evidence_does_not_override_sampling_failure(self):
        original=copy.deepcopy(self.original);original['common_guards']['high_weight']=False
        result=assess(original,self.frozen,self.evidence,helper=self.helper,validate_evidence=validate_evidence,protocol=protocol)
        self.assertTrue(all(r['width']==1 and 'high_weight' in r['common_failures'] for r in result['rows']))
    def test_wrong_identity_rejected(self):
        evidence=copy.deepcopy(self.evidence);evidence['datum']=26
        with self.assertRaises(ValueError):assess(self.original,self.frozen,evidence,helper=self.helper,validate_evidence=validate_evidence,protocol=protocol)
    def test_failed_evidence_retains_unresolved(self):
        evidence=copy.deepcopy(self.evidence);evidence['checks']['posterior_domain_controls']=False
        result=assess(self.original,self.frozen,evidence,helper=self.helper,validate_evidence=validate_evidence,protocol=protocol)
        self.assertTrue(all(r['width']==1 for r in result['rows']))

if __name__=='__main__':
    r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SupplementTests))
    v=dict(schema='C08_SUPPLEMENTAL_BRACKET_TOY_TESTS_v1',tests=r.testsRun,passed=r.wasSuccessful(),CPU_seconds_including_imports=time.process_time(),
        RSS_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,physical_LL=0,ORF=0,PTA_posterior_arrays_read=False)
    print(json.dumps(v));Path(__file__).with_name('supplemental_validation.json').write_text(json.dumps(v,indent=2)+'\n')
    raise SystemExit(not r.wasSuccessful())
