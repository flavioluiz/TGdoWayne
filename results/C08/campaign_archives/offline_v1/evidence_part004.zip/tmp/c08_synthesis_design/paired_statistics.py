"""C08 paired summaries: keep all data and separate horizontal numerical ranges."""
import numpy as np

CONTRASTS=(('A_CN','A0_CN'),('B_CN','A_CN'),('B_G','A_G'),
 ('C_beta_CN','B_CN'),('C_beta_G','B_G'),
 ('C_full_CN','C_beta_CN'),('C_full_G','C_beta_G'))

def classify(lower,upper,tolerance=.01):
    lower,upper=np.broadcast_arrays(np.asarray(lower,float),np.asarray(upper,float))
    if not np.isfinite(lower).all() or not np.isfinite(upper).all() or np.any(lower>upper):
        raise ValueError('Finite ordered bounds required, including unresolved ranges.')
    answer=np.full(lower.shape,'inconclusive',dtype='<U32')
    answer[(lower>=-tolerance)&(upper<=tolerance)]='within_operational_band'
    answer[lower>tolerance]='positive_material_effect'
    answer[upper<-tolerance]='negative_material_effect'
    return answer

def paired_bounds(new,old):
    new=np.asarray(new,float);old=np.asarray(old,float)
    if new.shape!=old.shape or new.shape[-1]!=2 or not np.isfinite(new).all() or not np.isfinite(old).all():
        raise ValueError('Matched finite interval arrays required.')
    if np.any(new[...,0]>new[...,1]) or np.any(old[...,0]>old[...,1]):raise ValueError('Intervals reversed.')
    return np.stack((new[...,0]-old[...,1],new[...,1]-old[...,0]),axis=-1)

def bootstrap_primary(point,bounds,*,seed=808110601,replicates=10000,batch=100):
    """Seven paired contrasts by N data; fixed family7, no IID-replica pseudo-data.

    Numeric bounds may be trivial; rows are never filtered. Bootstrap draws
    jointly resample the datum axis. This is an operational percentile envelope,
    not a finite-sample or combined 95% coverage certificate.
    """
    point=np.asarray(point,float);bounds=np.asarray(bounds,float)
    if point.ndim!=2 or point.shape[0]!=7 or bounds.shape!=point.shape+(2,) or point.shape[1]<2:
        raise ValueError('All seven contrasts and at least two paired data required.')
    if not np.isfinite(point).all() or not np.isfinite(bounds).all() or np.any(bounds[...,0]>bounds[...,1]):
        raise ValueError('No missing/omitted datum or reversed numerical interval allowed.')
    if type(replicates)is not int or replicates<2 or type(batch)is not int or batch<1:raise ValueError('Positive bootstrap sizes required.')
    rng=np.random.default_rng(seed);n=point.shape[1]
    means=np.empty((replicates,7,3))
    inputs=np.stack((point,bounds[...,0],bounds[...,1]),axis=-1)
    for start in range(0,replicates,batch):
        stop=min(start+batch,replicates);ids=rng.integers(0,n,size=(stop-start,n))
        means[start:stop]=inputs[:,ids,:].mean(axis=2).transpose(1,0,2)
    alpha=.05;tail=alpha/(2*7)
    percentiles=np.quantile(means,[tail,1-tail],axis=0,method='linear')
    return dict(point_mean=point.mean(axis=1),mean_numeric_bounds=bounds.mean(axis=1),
        point_bootstrap_interval=percentiles[:,:,0].T,
        bootstrap_numeric_envelope=np.column_stack((percentiles[0,:,1],percentiles[1,:,2])),
        bootstrap_means=means,replicates=replicates,seed=seed,family_size=7,alpha=alpha,
        coverage_is_approximate=True,all_data_retained=True)
