"""Supplemental evidence assessment from preserved endpoint summaries only.

The original unresolved diagnostic remains immutable. No cutoff selection,
new Monte Carlo, posterior raw access, likelihood or statistical guard change
occurs here. Finite response checks can support an operational margin, never
a uniform posterior-CDF theorem.
"""
import copy
import numpy as np

def assess(original,frozen,evidence,*,helper,validate_evidence,protocol):
    if (original.get('scope')!='C08_HORIZONTAL_QUANTILE_DIAGNOSTIC'
        or original.get('all20_retained') is not True
        or original.get('identity')!=frozen.get('identity')
        or original.get('scientific_model')!=frozen.get('scientific_model')
        or original.get('datum')!=frozen.get('datum')
        or original.get('cut_manifest_content_sha256')!=frozen.get('content_sha256')
        or len(original.get('rows',[]))!=20):
        raise ValueError('Full immutable diagnostic and its frozen low-only cuts required.')
    ok,failures=validate_evidence(evidence,frozen)
    guards=original['common_guards']
    if set(guards)!={'low_weight','high_weight','low_saturation','high_saturation',
        'low_logZ_replication','high_logZ_replication','logZ_refinement'} or any(type(v)is not bool for v in guards.values()):
        raise ValueError('Original shared guards must be retained exactly.')
    failures=[k for k,v in guards.items() if not v]+failures
    p=protocol();new_rows=[]
    for i,old in enumerate(original['rows']):
        j,k=divmod(i,4);cuts=frozen['cuts'][j][k];stats=old['endpoint_statistics']
        if old['parameter']!=j or old['probability']!=p['probabilities'][k] or old['cuts']!=cuts or len(stats)!=len(cuts):
            raise ValueError('No changed cut, parameter or probability is allowed.')
        estimates=[];errors=[]
        for cut,stat in zip(cuts,stats):
            value=stat['estimate'];usable=stat['endpoint_usable']
            if type(usable)is not bool or not np.isfinite(value):raise ValueError('Original finite estimates/boolean guards required.')
            if cut in (0.,1.) and (stat.get('structural') is not True or value!=cut or stat['mcse']!=0):
                raise ValueError('Exact continuous-support endpoints required.')
            estimates.append(value if 0<=value<=1 else .5)
            errors.append(stat['mcse'] if usable else np.inf)
        family=p['u95_family'] if (j,k)==(0,3) else p['other19_family']
        band=helper.bracket(cuts,estimates,errors,p['probabilities'][k],family_tests=family,
            alpha=p['cdf_alpha_per_family'],deterministic_cdf_error=.002 if ok else None,
            deterministic_status='validated_operational_envelope' if ok else 'unresolved')
        if failures:
            band.update(status='UNRESOLVED_COMMON_NUMERICAL_OR_DETERMINISTIC_GUARD',lower_quantile=0.,upper_quantile=1.,width=1.)
        elif band['width']==1.:
            band['status']='UNRESOLVED_NO_INFORMATIVE_CROSSING'
        band.update(parameter=j,probability=p['probabilities'][k],probability_index=k,cuts=copy.deepcopy(cuts),
            endpoint_statistics=copy.deepcopy(stats),common_failures=failures.copy())
        new_rows.append(band)
    out=copy.deepcopy(original)
    out.update(schema='C08_SUPPLEMENTAL_HORIZONTAL_QUANTILE_ASSESSMENT_v1',rows=new_rows,evidence=copy.deepcopy(evidence),
        original_diagnostic_preserved=True,original_endpoint_statistics_unchanged=True,
        original_common_guards_unchanged=True,selection_uses_high=False,physical_LL_evaluations=0,
        no_new_Monte_Carlo=True,posterior_raw_arrays_read=False,
        numerical_status='BRACKETS_RECORDED_WITH_FAILURES' if any(r['status'].startswith('UNRESOLVED') for r in new_rows) else 'BRACKETS_RECORDED_OPERATIONAL')
    return out
