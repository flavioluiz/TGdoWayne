"""Small algebra/axis checks; no posterior, ORF or likelihood evaluations."""
import json, resource, time, unittest
from pathlib import Path
import numpy as np
from paired_statistics import classify,paired_bounds,bootstrap_primary

class PairedTests(unittest.TestCase):
    def test_interval_direction_and_material_boundary(self):
        b=paired_bounds(np.array([[.7,.8],[0,1]]),np.array([[.2,.3],[0,1]]))
        np.testing.assert_allclose(b,[[.4,.6],[-1,1]],atol=1e-15,rtol=0)
        self.assertEqual(classify(b[:,0],b[:,1]).tolist(),['positive_material_effect','inconclusive'])
        self.assertEqual(classify([-.01,.01,-.02],[.01,.04,-.01]).tolist(),['within_operational_band','inconclusive','inconclusive'])
    def test_shared_draws_and_numeric_inflation(self):
        base=np.linspace(-.2,.2,24);point=np.stack([base+j/100 for j in range(7)])
        bounds=np.stack((point-.04,point+.07),axis=-1)
        r=bootstrap_primary(point,bounds)
        draws=r['bootstrap_means']
        np.testing.assert_allclose(draws[:,1:,0]-draws[:,:1,0],np.broadcast_to(np.arange(1,7)/100,(10000,6)),atol=2e-16,rtol=0)
        np.testing.assert_allclose(r['bootstrap_numeric_envelope'],r['point_bootstrap_interval']+[-.04,.07],atol=2e-16,rtol=0)
        np.testing.assert_allclose(draws[:,:,1],draws[:,:,0]-.04,atol=2e-16,rtol=0)
    def test_unresolved_rows_never_vanish(self):
        point=np.zeros((7,24));bounds=np.tile([-1.,1.],(7,24,1))
        r=bootstrap_primary(point,bounds,replicates=80)
        np.testing.assert_array_equal(r['bootstrap_numeric_envelope'],np.tile([-1.,1.],(7,1)))
        with self.assertRaises(ValueError):bootstrap_primary(point[:6],bounds[:6])
        point[0,0]=np.nan
        with self.assertRaises(ValueError):bootstrap_primary(point,bounds)
    def test_batch_boundary_preserves_draw_stream(self):
        point=np.arange(7*24).reshape(7,24)/200;bounds=np.stack((point-.01,point+.01),axis=-1)
        a=bootstrap_primary(point,bounds,replicates=103,batch=17)
        b=bootstrap_primary(point,bounds,replicates=103,batch=100)
        np.testing.assert_array_equal(a['bootstrap_means'],b['bootstrap_means'])

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(PairedTests))
    report=dict(schema='C08_PAIRED_STATISTICS_TOY_TESTS_v1',tests=result.testsRun,passed=result.wasSuccessful(),
        CPU_seconds_including_imports=time.process_time(),RSS_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        physical_LL=0,ORF=0,posterior_arrays_read=False)
    print(json.dumps(report));Path(__file__).with_name('validation.json').write_text(json.dumps(report,indent=2)+'\n')
    raise SystemExit(not result.wasSuccessful())
