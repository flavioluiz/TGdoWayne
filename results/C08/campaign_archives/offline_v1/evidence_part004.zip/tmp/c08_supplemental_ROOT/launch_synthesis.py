"""ROOT full-source review and external lifecycle of compact paired synthesis."""
from pathlib import Path
import hashlib,json,os,resource,subprocess,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    spec=ROOT/'tmp/c08_paired_synthesis_v1/execution_with_index.json';index=HERE/'supplemental_index.json'
    assert sha(spec)=='b73043e8a5dde19f5a3659a13bf78a08d48de7311c946b2c2457349527c86568'
    assert sha(index)=='9dd442882c7677ac1d903aef13d8e77897e484fa852e2b19ab4daf994660377c'
    s=json.loads(spec.read_text())
    for group in ('sources','inputs'):
        for r in s[group].values():assert sha(r['path'])==r['sha256']
    review=dict(schema='ROOT_C08_PAIRED_SYNTHESIS_SOURCE_REVIEW_v1',reviewer='ROOT',
        all_sources_read=['reader.py','run.py','paired_core.py','plots.py','prepare.py','paired_statistics.py'],
        thirteen_TOYs_passed=True,all288_supplemental_records_produced_and_reviewed=True,
        no_changed_cuts_MCSE_guards_or_cohort=True,all_failures_retained=True,
        no_uniform_CDF_or_population_equivalence_proof=True,execution_spec_sha256=sha(spec))
    write(HERE/'synthesis_source_review.json',review)
    auth=dict(schema='C08_PAIRED_SYNTHESIS_AUTHORIZATION_v1',scope='compact288_only_no_physical_computation',
        execution_spec_sha256=sha(spec),supplemental_index_path=str(index),supplemental_index_sha256=sha(index),
        all288_index_records_reviewed=True,bootstrap_replicates=10000,bootstrap_seed=808110601,
        maximum_CPU_seconds=60,maximum_array_workspace_bytes=67108864,
        ROOT_source_review_sha256=sha(HERE/'synthesis_source_review.json'))
    ap=HERE/'synthesis_authorization.json';write(ap,auth)
    argv=[str(ROOT/'.venv/bin/python'),'-B',str(ROOT/'tmp/c08_paired_synthesis_v1/run.py'),
        '--spec',str(spec),'--execute','--index',str(index),'--index-sha256',sha(index),
        '--authorization',str(ap),'--output',str(ROOT/'tmp/c08_paired_synthesis_OUTPUT')]
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',MKL_NUM_THREADS='1',MPLCONFIGDIR=str(ROOT/'tmp/mplconfig'))
    start=dict(argv=argv,launcher_sha256=sha(__file__),authorization_sha256=sha(ap),spec_sha256=sha(spec),automatic_retry=False)
    write(HERE/'synthesis_external_start.json',start);clock=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
    with (HERE/'synthesis_execution.log').open('x') as f:
        p=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
        print(json.dumps(dict(event='COMPACT_PAIRED_SYNTHESIS_STARTED',pid=p.pid)),flush=True);code=p.wait()
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    end=dict(**start,exit_code=code,workers_exited=True,wall_seconds=time.monotonic()-clock,
        child_CPU_including_exit=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,
        child_RSS=after.ru_maxrss,launcher_CPU=time.process_time(),log_sha256=sha(HERE/'synthesis_execution.log'))
    write(HERE/'synthesis_external_end.json',end);print(json.dumps(end),flush=True);return code
if __name__=='__main__':raise SystemExit(main())
