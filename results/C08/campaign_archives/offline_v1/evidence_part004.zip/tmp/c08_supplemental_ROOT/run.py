"""Offline supplemental brackets, from unchanged archived endpoint statistics."""
from pathlib import Path
import collections,hashlib,json,sys,time,resource
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'tmp/c08_quantile_replay_design'),str(ROOT/'tmp/c08_synthesis_design')]
from contracts import protocol,load_helper,bound_file,verify_cut_manifest
from endpoints import validate_evidence
from supplemental_brackets import assess

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def bind(p):return dict(path=str(Path(p).resolve()),sha256=sha(p))
def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')

def inputs():
    replay=read(ROOT/'tmp/c08_quantile_replay_design/frozen_c07/replay_plan.json')
    output=ROOT/'tmp/c08_required_high_replay_with_kl_v1';rows=[]
    for r in replay['rows']:
        rows.append(dict(scientific_model=r['scientific_model'],datum=r['datum'],identity=replay['identity'],
            source_diagnostic=bind(output/'diagnostics'/f"target_{r['target']:06d}.json"),cut_manifest=r['cut_manifest'],
            stratum=r['stratum']))
    cohort=read(ROOT/'tmp/c08_driver_design/configs/cohort_index.json')
    for v in ('C_beta','C_full'):
        plan=read(ROOT/f'tmp/c08_main_ROOT/{v}_approved_hook_plan.json');output=Path(plan['output'])
        for r in plan['target_index']:
            t=r['internal_target'];datum=r['datum']
            rows.append(dict(scientific_model=r['model'],datum=datum,identity=plan['runtime_identity'],
                source_diagnostic=bind(output/'quantiles/diagnostics'/f'brackets_{t:06d}.json'),
                cut_manifest=bind(output/'quantiles/low'/f'cuts_{t:06d}.json'),
                stratum='representative' if datum in cohort['representative_ids'] else 'stress'))
    assert len(rows)==288 and len({(r['scientific_model'],r['datum']) for r in rows})==288
    return rows

def main():
    reviewpath=ROOT/'tmp/c08_finite_ROOT/result_review.json';review=read(reviewpath)
    assert review['status']=='ALL_FINITE_OUTPUTS_REVIEWED' and review['all_288_clouds_and_324_bindings_retained'] is True
    assert review['no_uniform_proof'] is True
    assert read(ROOT/'tmp/c08_replay_ROOT/result_review.json')['status']=='ALL160_REPLAY_PRODUCTS_REVIEWED'
    expected={'main:C08':288}
    reports={}
    for r in review['assessment_records']:
        a=read(bound_file(r['path'],r['sha256']))
        if a['scope']=='main':reports[a['scientific_model'],a['datum']]=(r,a)
    assert len(reports)==288
    helper=load_helper(ROOT/'tmp/c08_execution_design/quantile_brackets.py')
    assert sha(ROOT/'tmp/c08_synthesis_design/supplemental_brackets.py')=='00aa198db7395a2cff521da2a5ec91e981e29f43a4b968121c77a74f8423a116'
    index=[];counts=collections.Counter()
    for row in inputs():
        key=row['scientific_model'],row['datum'];ref,a=reports[key]
        original_path=bound_file(**dict(path=row['source_diagnostic']['path'],expected=row['source_diagnostic']['sha256']))
        original=read(original_path);frozen=read(bound_file(row['cut_manifest']['path'],row['cut_manifest']['sha256']))
        verify_cut_manifest(frozen,helper)
        assert a['posterior_identity']==frozen['identity']==row['identity'] and a['cut_sha256']==row['cut_manifest']['sha256']
        cloud=read(bound_file(a['source_cloud']['path'],a['source_cloud']['sha256']))
        complete=cloud['status']=='FINITE_CLOUD_COMPLETE'
        maxima=cloud.get('logL_maxima',{})
        coarse=bool(complete and all(maxima.get(k,float('inf'))<=.001 for k in ('H00_H01','H01_H11','H00_H11'))
            and max(cloud.get('matrix_maxima',[float('inf')]))<=1e-8)
        oracle=bool(complete and maxima.get('native_H11',float('inf'))<=.001 and maxima.get('SciPy_H11',float('inf'))<=1e-8)
        domain=bool(a['status']=='FINITE_RULES_PASS_AWAITING_REVIEW' and a['summary']['all_rows_finite_rule_pass'] and a['kernel_finite_gates'])
        evidence=dict(schema='C08_POSTERIOR_CDF_EVIDENCE_v1',identity=row['identity'],scientific_model=key[0],datum=key[1],
            cut_manifest_content_sha256=frozen['content_sha256'],operational_margin=.002,is_uniform_proof=False,
            posterior_domain='Prespecified 17 mass nodes with positive trapezoid weights and 4x128 independent nuisance clusters from the frozen LOW marginal proposal. Paired finite CDF discrepancy and refinement only; no continuous-CDF accuracy or uniform bound is proved.',
            checks=dict(coarse_fine=coarse,independent_oracle=oracle,posterior_domain_controls=domain),
            sources=[bind(reviewpath),ref,a['source_cloud'],bind(Path(ref['path']).parent/a['numeric_file'])],
            interpretation='Operational allowance limited by finite control coverage. Original missing-evidence diagnostic remains immutable; no MCSE, cut, guard or sample is changed.',
            finite_control_rules_unchanged=True,failed_finite_controls_retained=True)
        name=f'{key[0]}_{key[1]:03d}';ep=HERE/'evidence'/f'{name}.json';write(ep,evidence)
        result=assess(original,frozen,evidence,helper=helper,validate_evidence=validate_evidence,protocol=protocol)
        result['supplemental_provenance']=dict(original=row['source_diagnostic'],cut_manifest=row['cut_manifest'],
            evidence=bind(ep),ROOT_control_review=bind(reviewpath),script_sha256=sha(__file__),
            original_numerical_status=original['numerical_status'])
        dest=HERE/'diagnostics'/f'{name}.json';write(dest,result)
        assert sha(original_path)==row['source_diagnostic']['sha256']
        for old,new in zip(original['rows'],result['rows']):assert old['endpoint_statistics']==new['endpoint_statistics']
        counts.update(r['status'] for r in result['rows'])
        index.append(dict(**row,supplemental=bind(dest),evidence=bind(ep),all20_retained=True))
    record=dict(schema='C08_SUPPLEMENTAL_INDEX_v1',status='ALL288_OFFLINE_SUPPLEMENTAL_ASSESSMENTS_RECORDED',
        records=index,records_count=288,quantiles_count=5760,status_counts=dict(counts),
        all_original_diagnostics_unchanged=True,all_original_endpoint_statistics_unchanged=True,
        no_new_Monte_Carlo=True,physical_LL=0,posterior_raw_reads=0,no_uniform_proof=True,
        CPU_seconds=time.process_time(),RSS_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        script_sha256=sha(__file__),ROOT_control_review=bind(reviewpath))
    write(HERE/'supplemental_index.json',record)
    print(json.dumps(dict(status=record['status'],counts=dict(counts),index_sha256=sha(HERE/'supplemental_index.json'))))
if __name__=='__main__':main()
