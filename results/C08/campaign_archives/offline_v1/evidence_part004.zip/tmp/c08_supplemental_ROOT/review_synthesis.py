"""ROOT read-only reconstruction of final paired products, no new random draws."""
from pathlib import Path
import csv,hashlib,json,time,resource
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def main():
    out=ROOT/'tmp/c08_paired_synthesis_OUTPUT';complete=read(out/'complete.json');r=read(out/'summary.json')
    ext=read(HERE/'synthesis_external_end.json')
    assert ext['exit_code']==0 and ext['workers_exited'] and ext['child_CPU_including_exit']+ext['launcher_CPU']<60
    assert complete['status']=='ALL32_BY9_RECORDED_WITH_UNRESOLVED_RETAINED'
    assert r['all288_posteriors_retained'] and r['all5760_quantiles_retained'] and r['stress_excluded_from_representative_bootstrap']
    for ref in complete['products']:assert sha(ref['path'])==ref['sha256'] and Path(ref['path']).stat().st_size==ref['bytes']
    with np.load(out/'arrays.npz',allow_pickle=False) as a:z={k:a[k] for k in a.files}
    p=z['point_quantiles_unit'];b=z['quantile_bounds_unit'];mask=z['representative_mask'];models=r['models']
    assert p.shape==(9,32,5,4) and b.shape==p.shape+(2,) and mask.sum()==24 and (~mask).sum()==8
    w=p[:,:,:,3]-p[:,:,:,0]
    wb=np.stack([b[:,:,:,3,0]-b[:,:,:,0,1],b[:,:,:,3,1]-b[:,:,:,0,0]],axis=-1)
    assert np.array_equal(w,z['posterior_widths_unit']) and np.array_equal(wb,z['posterior_width_bounds_unit'])
    for i,c in enumerate(r['contrasts']):
        n,o=models.index(c['new']),models.index(c['previous'])
        assert np.array_equal(p[n]-p[o],z['delta_quantiles_unit'][i])
        assert np.array_equal(np.stack([b[n,...,0]-b[o,...,1],b[n,...,1]-b[o,...,0]],axis=-1),z['delta_quantile_bounds_unit'][i])
        assert np.array_equal(w[n]-w[o],z['delta_widths_unit'][i])
        assert np.array_equal(np.stack([wb[n,...,0]-wb[o,...,1],wb[n,...,1]-wb[o,...,0]],axis=-1),z['delta_width_bounds_unit'][i])
    primary=z['delta_quantiles_unit'][:,:,0,3];pb=z['delta_quantile_bounds_unit'][:,:,0,3]
    assert np.array_equal(primary[:,mask].mean(axis=1),r['bootstrap']['point_mean'])
    assert np.all(z['primary_classification']=='inconclusive') and np.all((pb[...,0]<=.01)&(pb[...,1]>=-.01))
    means=z['bootstrap_means'];assert means.shape==(10000,7,3)
    tails=np.quantile(means,[.05/14,1-.05/14],axis=0,method='linear')
    assert np.array_equal(tails[:,:,0].T,r['bootstrap']['point_bootstrap_interval'])
    assert np.array_equal(np.column_stack([tails[0,:,1],tails[1,:,2]]),r['bootstrap']['bootstrap_numeric_envelope'])
    assert r['bootstrap']['pilot_mean_classification']==['inconclusive']*7
    assert np.array_equal((p<b[...,0])|(p>b[...,1]),z['point_outside_supplemental_interval'])
    assert r['point_outside_interval_count']==0
    for name,key,count in [('paired_quantiles.csv','point_difference',4480),('paired_widths.csv','point_width_difference',1120)]:
        with (out/name).open() as f:rows=list(csv.DictReader(f))
        assert len(rows)==count and all(np.isfinite(float(x[key])) for x in rows)
    summary=dict(schema='ROOT_C08_PAIRED_RESULT_REVIEW_v1',status='ALL_PAIRED_PRODUCTS_REVIEWED',
        complete_sha256=sha(out/'complete.json'),summary_sha256=sha(out/'summary.json'),arrays_sha256=sha(out/'arrays.npz'),
        all_288_posteriors_and_5760_quantiles_retained=True,all_224_primary_individual_comparisons_inconclusive=True,
        all_seven_pilot_means_inconclusive=True,representative24_stress8_separate=True,
        independent_direct_interval_and_width_recomposition_exact=True,stored_bootstrap_percentiles_recomposed_exact=True,
        new_bootstrap_draws=0,new_physical_calls=0,point_outside_numeric_interval=0,
        sources_reviewed=True,no_uniform_proof=True,CPU_external=ext['child_CPU_including_exit']+ext['launcher_CPU'],
        own_CPU=time.process_time(),own_RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,source_sha256=sha(__file__))
    with (HERE/'synthesis_result_review.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
    print(json.dumps(summary))
if __name__=='__main__':main()
